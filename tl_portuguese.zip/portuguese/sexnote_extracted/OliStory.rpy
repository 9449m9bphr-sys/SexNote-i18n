# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/OliStory.rpy
translate portuguese strings:

    # say L8 oli
    old "Did you see my notes report?!"
    new "A:oli: Tu és um idiota!"

    # say L12 oli
    old "You're a fucking moron!"
    new "B:oli: Viste o meu relatório de notas?!"

    # say L23 mik
    old "B- but, I- I really did teach you what was needed for the exam... I mean, I did well..."
    new "A:oli: Estás a sugerir que sou burro? Ou que foi minha a culpa?"

    # say L24 oli
    old "Are you suggesting that I'm dumb? Or that it was my fault?"
    new "A:mik: Não, não, o que estou a dizer é que..."

    # say L25 mik
    old "No, no, what I'm saying is that..."
    new "A:oli: Tu asseguraste-me que se eu passasse tempo contigo e te deixasse fazer 'aquilo' a mim..."

    # say L44 oli
    old "You assured me that if I spent time with you and let you do 'that' to me..."
    new "B:mik: Não, não, o que eu estou a dizer é que..."

    # say L47 oli
    old "... You were going to help me pass the exams."
    new "B: Oli: Tu garantiste-me que se eu passasse tempo contigo e deixasse que tu fizesse \"aquilo\" a mim..."

    # say L48 oli
    old "But I ended up failing anyway!"
    new "B:oli:... Ias ajudar-me a passar os exames."

    # say L51 oli
    old "If you didn't actually understand the subjects, you could've just told me that..."
    new "Se não tinhas percebido as matérias, podias ter-me dito... Assim, não teria desperdiçado o meu tempo contigo."

    # say L52 oli
    old "That way I wouldn't have wasted my time with you."
    new "B:oli: Se não entendeste os assuntos, podias ter-me dito..."

    # say L56 oli
    old "What? [pla]? What does he have to do with all this?"
    new "B:mik: Mas eu não sei o que aconteceu, expliquei-te tudo como o [pla] fez com o m-..."

    # say L60 mik
    old "Maybe you just didn't understand the topics I explained well."
    new "B:mik: N- nada, nada, eu quis dizer que também o ajudei e ele teve um bom resultado no exame..."

    # say L79 pla
    old "Hey man... That sounded rough. What's going on?"
    new "A:mik: Aparentemente, ela teve um desempenho muito ruim nas últimas provas que fizemos."

    # say L81 mik
    old "Apparently, she did really poorly on the last set of exams we took."
    new "B:pla: Ei, mano... Parece que foi complicado. O que se passa?"

    # say L83 mik
    old "And now she's blaming me!"
    new "T(mik|tu|diz): E agora ela está a culpar-me!"

    # say L84 mik
    old "Like it's my fault..."
    new "T(mik|tu|say): Como se fosse minha culpa..."

    # say L86 pla
    old "Well, you did promise her you'd help her with her exams."
    new "B:mik: Como se fosse minha culpa..."

    # say L87 pla
    old "But you didn't really follow through..."
    new "B:pla: Bem, tu prometeste que ias ajudá-la nos exames dela."

    # say L89 mik
    old "W- well, t- that's just because..."
    new "B:pla: Mas tu não foste até ao fim..."

    # say L91 mik
    old "I don't know, man, I really helped her!"
    new "B:mik: B- bem, é só porque..."

    # say L92 mik
    old "I- I mean, I even got good grades, man!"
    new "B:mik: Não sei, mano, eu realmente ajudei-a!"

    # say L93 pla
    old "Well, yeah, but it doesn't matter how well you did."
    new "B:mik: Eu... Quero dizer, eu até tive boas notas, cara!"

    # say L94 pla
    old "What matters is that she didn't do well."
    new "B:pla: Bem, sim, mas não importa o quão bem tu fizeste."

    # say L96 pla
    old "I think you just didn't know how to explain the subjects to her."
    new "B:pla: O que importa é que ela não se saiu bem."

    # say L97 mik
    old "Alright! You don't have to repeat what she said!"
    new "B:pla: Acho que tu simplesmente não sabias como explicar os assuntos a ela."

    # say L99 mik
    old "Besides, I don't think you get to say anything to me, this is your fault after all."
    new "B:mik: Tudo bem! Não precisas de repetir o que ela disse!"

    # say L100 pla
    old "Excuse me? What's that supposed to mean?"
    new "A:mik: O que eu disse! Tu devias ter-me explicado os temas para eu poder ajudar a Olivia!"

    # say L101 mik
    old "What I said! You were supposed to explain the subjects to me so that I could help Olivia!"
    new "B:pla: Desculpa? O que é que isso quer dizer?"

    # say L103 mik
    old "But look at the results she got."
    new "T(mik|tu|diz): Mas olha para as notas que ela conseguiu."

    # say L105 pla
    old "That has nothing to do with me!"
    new "T(pla|tu|say): Isso não tem nada a ver comigo!"

    # say L106 pla
    old "If she didn't learn anything, it's just because you're such a shit teacher!"
    new "T(pla|tu|dizes): Se ela não aprendeu nada, é só porque tu és um professor de merda!"

    # say L108 pla
    old "Maybe you should've taught her properly instead of spending your time staring at her tits."
    new "B:pla: Se ela não aprendeu nada, é só porque tu és um professor de merda!"

    # say L110 mik
    old "Yeah well, whatever the reason is, she's super angry with me now."
    new "B:pla: Talvez devesse ter-lhe ensinado direito em vez de passar o tempo a olhar para as tetas dela."

    # say L112 mik
    old "If she fails the coming exams, that's going to really suck, man."
    new "T(mik|tu|diz): Se ela falhar nos exames que vêm, isso vai ser realmente chato, mano."

    # say L113 pla
    old "Well, it would be bad, but she'll have other chances to pass."
    new "B:mik: Se ela falhar nos exames que vêm, isso vai ser realmente chato, mano."

    # say L115 mik
    old "What? That's not what I mean, dude."
    new "B:pla: Bem, seria mau, mas ela terá outras oportunidades para passar."

    # say L117 mik
    old "If she fails, she'll just blame me, and I won't be able to move forward with her."
    new "T(mik|tu|dizer): Se ela falhar, vai apenas culpar-me, e eu não conseguirei avançar com ela."

    # say L119 mik
    old "I'm so close to hooking up with her, dude, so close."
    new "T(mik|tu|dizer): Estou tão perto de ficar com ela, cara, tão perto."

    # say L120 mik
    old "She was just about to let me hit it, and now this."
    new "T(mik|tu|say): Ela estava quase a deixar-me fazer isso, e agora isto."

    # say L121 pla
    old "... Sure, dude."
    new "T(pla|tu|say):... Claro, mano."

    # say L126 pla
    old "Hey, come on, let's go to class."
    new "B:pla:... Claro, meu."

    # say L127 pla
    old "You can keep worrying about this later."
    new "B:pla: Ei, vamos, vamos para a aula."

    # say L129 mik
    old "Yeah... Okay."
    new "B:pla: Podes preocupar-te com isso mais tarde."

    # say L174 oli
    old "Yeah, I need to talk to you about something."
    new "T(oli|tu|diz): Sim, preciso falar contigo sobre uma coisa."

    # say L175 pla
    old "Uh... Alright, what is it?"
    new "B:oli: Sim, preciso falar contigo sobre algo."

    # say L177 oli
    old "Well, as you probably already know."
    new "B:pla: Uh... Tudo bem, o que foi?"

    # say L179 oli
    old "I've been having some problems with my grades lately."
    new "B:oli: Bem, como tu provavelmente já sabes."

    # say L180 pla
    old "Hmph, I mean... I haven't really paid attention to what you've been doing or anything..."
    new "B:oli: Tenho tido alguns problemas com as minhas notas lately."

    # say L182 oli
    old "Oh please, don't pretend you haven't talked with that dumbass Mike."
    new "B:pla: Hmph, eu quero dizer... não tenho realmente prestado atenção ao que tu tens feito ou algo assim..."

    # say L183 oli
    old "I know he told you about him giving me lessons in the subjects I'm failing, so don't play dumb."
    new "A:pla: Bem, ele mencionou algo sobre isso."

    # say L185 pla
    old "Well, he did mention something about that."
    new "B:oli: Eu sei que ele te contou sobre ele me dar aulas nas disciplinas em que estou a falhar, então não finjas que não sabes."

    # say L186 pla
    old "But what about it?"
    new "B:pla: Bem, ele mencionou algo sobre isso."

    # say L188 oli
    old "The thing is, I haven't really learned much of anything."
    new "B:pla: Mas e daí?"

    # say L189 oli
    old "Because he's so fucking bad at teaching!"
    new "A:oli: Mas nas últimas provas, notei que as notas dele melhoraram."

    # say L191 oli
    old "But on the last exams, I did notice his grades got better."
    new "B:oli: Porque ele é tão fucking mau a ensinar!"

    # say L193 oli
    old "I thought that was strange, very strange."
    new "B:oli: Mas nas últimas provas, notei que as notas dele melhoraram."

    # say L195 oli
    old "While spending time with him, I realized he's not the brightest guy."
    new "B:oli: Achei isso estranho, muito estranho."

    # say L197 oli
    old "Actually, he's a fucking idiot!"
    new "B:oli: Enquanto estava com ele, percebi que ele não é o cara mais inteligente."

    # say L199 pla
    old "Okay, okay, but what does this have to do with me?"
    new "B:oli: Na verdade, ele é um idiota da pior espécie!"

    # say L201 oli
    old "As I told you, spending time with your friend made me realize he's a fucking idiot."
    new "Como te disse, passar tempo com o teu amigo fez-me perceber que ele é um idiota. Não fazia sentido para mim que ele tivesse melhorado tanto nas notas de repente."

    # say L203 oli
    old "It just didn't make sense to me that he would suddenly make such an improvement in his grades."
    new "A:oli: Então, encontrei-me com ele sob o pretexto de que era um encontro."

    # say L205 oli
    old "So, I met him under the pretense that it was a date."
    new "B:oli: Não fazia sentido para mim que ele tivesse melhorado tanto as notas de repente."

    # say L207 oli
    old "And I pushed him until he spilled the beans about how he'd suddenly managed to get good grades in the exams."
    new "B:oli: Então, encontrei-me com ele sob o pretexto de que era um encontro."

    # say L209 oli
    old "After a while, he confessed that he wasn't any good at studying."
    new "Depois de um tempo, ele confessou que não era bom a estudar, mas que foi graças a TI que conseguiu melhores notas."

    # say L211 oli
    old "But that it was thanks to YOU that he was able to get better grades."
    new "B:oli: Depois de um tempo, ele confessou que não era bom a estudar."

    # say L212 pla
    old "T- that's what he told you?"
    new "B:oli: Mas foi graças a TI que ele conseguiu melhores notas."

    # say L213 oli
    old "He did! And I should've known from the start that his grades didn't get better because of him!"
    new "B:pla: T- isso foi o que ele te disse?"

    # say L215 oli
    old "But anyway, that's not what I care about."
    new "B:oli: Ele fez! E eu devia ter percebido desde o início que as notas dele não melhoraram por mérito dele!"

    # say L217 oli
    old "Because I'm still stuck with my bad grades."
    new "Porque ainda estou preso com as minhas más notas."

    # say L219 oli
    old "I got to thinking about it."
    new "B:oli: Porque ainda estou preso com as minhas más notas."

    # say L225 oli
    old "Well, if you were able to teach that dumbass Mike enough to get good scores on the exams."
    new "B:oli: Estive a pensar nisso."

    # say L227 oli
    old "You should be more than capable of bringing me to the top of the class."
    new "T(oli|tu|dizes): Deves ser mais do que capaz de me levar para o topo da turma."

    # say L229 pla
    old "Yeah, I mean, thanks for the compliment."
    new "T: Mas, por que é que eu faria isso?"

    # say L231 pla
    old "But, why would I do that?"
    new "B:pla: Yeah, I mean, thanks for the compliment."

    # say L235 pla
    old "In case you don't remember, every time you and Ruby are around."
    new "B:pla: Mas, por que eu faria isso?"

    # say L236 pla
    old "You attack and bully my friends and me. The only thing you know how to do is be rude to us."
    new "T(pla|tu|say): Tu atacas e intimidas os meus amigos e a mim. A única coisa que sabes fazer é ser mal-educado connosco."

    # say L238 pla
    old "Especially towards Belle and Hinn."
    new "B: Tu atacas e intimidas os meus amigos e a mim. A única coisa que sabes fazer é ser mal-educado connosco."

    # say L240 pla
    old "So no, I think I'll pass."
    new "A:oli: É assim que é... De qualquer forma, tu TENS de me ajudar, gostes ou não."

    # say L245 oli
    old "So that's how it is... Either way, you HAVE to help me whether you like it or not."
    new "T(oli|tu|dizes): E é assim que é... De qualquer maneira, tu TENS de me ajudar, queiras ou não."

    # say L247 pla
    old "And why would that be?"
    new "E porquê?"

    # say L249 oli
    old "I'll tell you why."
    new "T(oli|tu|dizes): Vou-te dizer porquê."

    # say L253 oli
    old "You better help me, or I'll spill what I know."
    new "T(oli|tu|dizes): Tu melhor ajudas-me, ou eu conto tudo o que sei."

    # say L254 oli
    old "And everyone will know just what kind of guy you are and the stuff you’re up to."
    new "Mas quero esclarecer uma coisa."

    # say L265 pla
    old "But I want to make something clear."
    new "Mas eu quero esclarecer uma coisa. Se eu fizer isto, tu não podes voltar a mencioná-lo, seja o que for."

    # say L267 pla
    old "If I do this, you can't bring it up ever again, no matter what."
    new "B:pla: Mas eu quero esclarecer uma coisa."

    # say L269 pla
    old "SO, after I'm done helping you, you can't tell anyone about it!"
    new "B:pla: Se eu fizer isto, tu não podes voltar a mencioná-lo, não importa o quê."

    # say L271 pla
    old "Are we clear?"
    new "B:pla: ENTÃO, depois de eu te ajudar, você não pode contar a ninguém sobre isso!"

    # say L272 oli
    old "Sure, I don't care about you or what you're doing."
    new "T(oli|tu|dizes): Claro, não me importo contigo nem com o que estás a fazer."

    # say L273 oli
    old "So I won't tell anyone."
    new "B:oli: Tudo bem, não me importo contigo nem com o que estás a fazer."

    # say L275 oli
    old "But that's only if I do well on the exams."
    new "B:oli: Então não vou contar a ninguém."

    # say L277 oli
    old "So you better outdo Mike, for your own sake."
    new "B:oli: Mas isso só acontece se eu me sair bem nos exames."

    # say L280 pla
    old "Hmph, sure."
    new "T(pla|tu|say): Hmph, claro."

    # say L282 pla
    old "So... Should I go to your house?"
    new "B:pla: Hmph, claro."

    # say L283 oli
    old "No, today's not a good day."
    new "B:pla: Então... Devo ir à tua casa?"

    # say L285 oli
    old "There are a couple of things I have to deal with at home."
    new "B:oli: Não, hoje não é um bom dia."

    # say L286 oli
    old "Just keep your schedule open for now, and I'll let you know when we can start."
    new "B:oli: Tenho umas coisas para tratar em casa."

    # say L287 pla
    old "Hmm, alright..."
    new "B:oli: Mantém a tua agenda livre por agora, e aviso-te quando pudermos começar."

    # say L315 mik
    old "I'm alright, but hey, don't dodge the question."
    new "B:pla: Oh, e-ei, o que foi?"

    # say L317 mik
    old "What were you doing talking to my girl?"
    new "B:mik: Estou bem, mas ei, não fujas à pergunta."

    # say L319 mik
    old "Are you trying to snatch her from me?"
    new "B:mik: O que estavas a fazer a falar com a minha namorada?"

    # say L324 pla
    old "Well, I think she just wants to do some extra studying, and she asked for my notes."
    new "B:pla: Não é o que tu pensas, cara. Ela estava só a pedir-me as minhas notas da aula."

    # say L326 mik
    old "And why your notes? She could've asked for mine..."
    new "B:pla: Bem, acho que ela só quer estudar um bocado mais e pediu as minhas notas."

    # say L327 pla
    old "Your notes? Do you even have any notes?"
    new "T(tu|say): Tu tens alguma nota?"

    # say L329 pla
    old "Did you even bring a notebook today?"
    new "B:pla: As tu notas? Tu tens alguma nota?"

    # say L331 mik
    old "Well, I- I didn't."
    new "B:pla: Trouxeste sequer um caderno hoje?"

    # say L332 mik
    old "I understand, dude, but still, I hope you're not thinking of using this to take my girl away from me!"
    new "B:mik: Bem, eu- eu não fiz."

    # say L333 pla
    old "Don't worry, dude..."
    new "T(pla|tu|diz): Não te preocupes, cara... A:pla: Garanto-te que isso não está nos meus planos."

    # say L334 pla
    old "I assure you that's not on my mind."
    new "B:pla: Não te preocupes, meu..."

    # say L336 mik
    old "Alright, I'll believe you."
    new "T(mik|tu|say): Tudo bem, acredito em ti."

    # say L337 mik
    old "We're pretty close, you know?"
    new "T(mik|tu|say): Estamos bastante próximos, sabes?"

    # say L338 mik
    old "In no time she'll be mine, don't doubt it."
    new "B:mik: Estamos bem perto, sabes?"

    # say L339 pla
    old "Sure dude, no doubt..."
    new "T(pla|tu|diz): Claro, meu, sem dúvida..."

    # say L345 pla
    old "Anyway, I have to go home now, are you leaving too?"
    new "B:pla: Claro, sem dúvida..."

    # say L347 mik
    old "Yeah sure, let's go."
    new "B:pla: De qualquer forma, tenho de ir para casa agora, tu também vais embora?"

    # say L375 pla
    old "Oh, damn, I'm really late. Has the class already ended?"
    new "B:mik: Claro, vamos lá."

    # say L395 rub
    old "Oh, look who decided to show up. Class ended a while ago, dumbass."
    new "B:pla: Oh, merda, estou mesmo atrasado. A aula já acabou?"

    # say L396 pla
    old "Oh crap, I totally lost track of time..."
    new "B:rub: Oh, olha quem decidiu aparecer. A aula acabou há um bom tempo, idiota."

    # say L397 rub
    old "Really? I hadn't noticed. It's not like anyone wants to see your ugly face around here."
    new "B:pla: Oh merda, perdi completamente a noção do tempo..."

    # say L398 pla
    old "{b}*Sigh*{/b} Really? Do you want to do this now?"
    new "T(pla|tu|say): {b}*Suspiro*{/b} Realmente? Queres fazer isto agora?"

    # say L401 pla
    old "You know? I don't have time to deal with you right now."
    new "T: Tu sabes? Não tenho tempo para lidar contigo agora."

    # say L411 rub
    old "Can you believe that loser?"
    new "B:pla: Sabes? Não tenho tempo para lidar contigo agora."

    # say L412 oli
    old "Yeah... What an idiot."
    new "B:rub: Acreditas naquele perdedor?"

    # say L413 oli
    old "Hey, listen, I think we'll have to cancel our plans for today."
    new "B:oli: Sim... Que idiota."

    # say L416 rub
    old "I thought you wanted to meet those cute guys today."
    new "A:oli: Eu quero! Eu realmente quero."

    # say L418 oli
    old "I do! I really do."
    new "T: Eu quero! Eu realmente quero. Mas lembrei-me que a minha mãe precisa de mim para ajudar com algumas coisas em casa."

    # say L419 oli
    old "But I just remembered my mom needs me to help her with some stuff at home."
    new "B:oli: Eu faço! Eu realmente faço."

    # say L420 oli
    old "So I have to go home early."
    new "B:oli: Mas lembrei-me que a minha mãe precisa de mim para ajudar com algumas coisas em casa."

    # say L422 rub
    old "Hmm, alright, I guess that's okay."
    new "B:oli: Tenho de ir para casa mais cedo."

    # say L423 rub
    old "I guess I'll be hanging out with the guys by myself."
    new "B:rub: Hmm, bem, acho que isso está bem."

    # say L424 oli
    old "Sure, but next time I'll definitely be going out with you guys."
    new "B:rub: Acho que vou ficar à conversa com os rapazes sozinho."

    # say L426 rub
    old "Alright, I guess that's fine."
    new "Tudo bem, acho que isso está bom."

    # say L446 pla
    old "Yeah?"
    new "A:oli: Ouve, estava a pensar que hoje podia ser um bom dia para tu virem cá a casa."

    # say L448 oli
    old "Listen, I was thinking today could be a good day for you to come over."
    new "B:pla: Sim?"

    # say L449 oli
    old "So we can start studying."
    new "B:oli: Ouve, estava a pensar que hoje podia ser um bom dia para tu virem cá."

    # say L450 pla
    old "W- what... Now?"
    new "T(pla|tu|say): W- what... Agora?"

    # say L452 oli
    old "Yes, why? I told you to clear your schedule."
    new "B:pla: O- o quê... Agora?"

    # say L453 pla
    old "No, no, you just caught me off guard."
    new "B:oli: Sim, porquê? Disse-te para limpar a tua agenda."

    # say L454 oli
    old "Well, you don't have to come if you don't want to."
    new "B:pla: Não, não, tu apenas me apanhaste de surpresa."

    # say L456 oli
    old "That is, if you don't care about everyone knowing you're fucking Mike's mom."
    new "B:oli: Bem, tu não tens de vir se não quiseres."

    # say L483 oli
    old "I- I thought you were going to be out this afternoon."
    new "B:oli: Oh, m- mãe, tu estás aqui."

    # say L484 vee
    old "That was the plan, but the appointment got canceled, so I just came back home."
    new "T: Era para ser, mas a consulta foi cancelada, então voltei para casa. Mas enfim, meu amor, quem é o teu amigo? Não vais apresentá-lo a mim?"

    # say L486 vee
    old "But anyway honey, who's your friend here? Aren't you going to introduce me to him?"
    new "B:vee: Era esse o plano, mas a consulta foi cancelada, então voltei para casa."

    # say L488 oli
    old "Well... Yeah."
    new "B:vee: Mas enfim, querida, quem é o teu amigo aqui? Não vais apresentá-lo a mim?"

    # say L494 oli
    old "[pla], this is my mother, her name's Priya."
    new "B:oli: O nome dele é [pla], ele é um amigo da escola."

    # say L502 oli
    old "[pla]'s going to help me study some topics for school."
    new "B:vee: Nice to meet you too, [pla]."

    # say L507 oli
    old "And [pla] here is a great student. He always gets top grades."
    new "E [pla] aqui é um ótimo aluno. Ele sempre obtém as melhores notas."

    # say L510 vee
    old "Oh, that's so good to hear, honey!"
    new "T(vee|tu|say): Oh, que bom ouvir isso, meu amor!"

    # say L513 vee
    old "I'm so glad you're finally taking your studies seriously."
    new "B:vee: Oh, que bom ouvir isso, meu amor!"

    # say L514 vee
    old "Your father's going to be very pleased if you do well in school, you know that."
    new "B:vee: Fico tão contente que finalmente estás a levar os estudos a sério."

    # say L517 oli
    old "Yeah, yeah, I know what he wants..."
    new "B:vee: O teu pai vai ficar muito contente se fores bem na escola, sabes disso."

    # say L519 vee
    old "Honey, don't take that attitude."
    new "B:oli: Sim, sim, eu sei o que ele quer..."

    # say L522 vee
    old "I know your father can be hard to deal with sometimes."
    new "B:vee: Meu amor, não tenhas essa atitude."

    # say L525 vee
    old "But you have to understand that he just wants what's best for you."
    new "B:vee: Eu sei que o teu pai pode ser difícil de lidar às vezes."

    # say L527 vee
    old "As do I."
    new "T: Assim o faço."

    # say L529 vee
    old "So, I'm very happy to see you making an effort to improve your grades."
    new "T(vee|tu|diz): Então, estou muito feliz por ver que estás a fazer um esforço para melhorar as tuas notas."

    # say L535 oli
    old "Hey mom, [pla] and I are going to study in my room, alright?"
    new "B:oli: Sim... Obrigado. T(oli|tu|dizes): Mãe, [pla] e eu vamos estudar no meu quarto, tudo bem? A:vee: Claro, querido."

    # say L550 oli
    old "I'm sorry you had to see that."
    new "Não estava à espera que a minha mãe estivesse aqui."

    # say L552 oli
    old "I wasn't expecting my mom to be here."
    new "B:oli: Sinto muito que tenhas tido de ver isso."

    # say L554 pla
    old "It's okay."
    new "Tudo bem. Não tens de pedir desculpa."

    # say L556 pla
    old "You don't have to apologize."
    new "B:pla: Tudo bem."

    # say L559 oli
    old "Anyway, I guess it's a good thing she met you right away."
    new "B:pla: Não tens de pedir desculpa."

    # say L561 oli
    old "That will make things easier in the future."
    new "A:oli: Então, vamos começar?"

    # say L564 oli
    old "So, should we get to it?"
    new "B:oli: Isso vai facilitar as coisas no futuro."

    # say L574 pla
    old "Okay, let's start with this topic."
    new "B:oli: Então, vamos começar?"

    # say L575 pla
    old "And we'll work our way to the others. Alright?"
    new "B:pla: Okay, vamos começar com este tópico."

    # say L577 oli
    old "Uhh... Sure, whatever you say."
    new "T(oli|tu|diz): Hum... Claro, como tu disseres."

    # say L585 pla
    old "See? This is the right way to prove that result."
    new "B:oli: Uhh... Claro, como tu quiseres."

    # say L587 oli
    old "I see, that makes a lot of sense."
    new "B:pla: Vês? Esta é a maneira certa de provar esse resultado."

    # say L589 pla
    old "Alright, I think we can move on to the next topic!"
    new "B:oli: Entendo, isso faz muito sentido."

    # say L595 pla
    old "I never could have guessed you'd be so good at this, you know?"
    new "T(pla|tu|say): Nunca pensei que fosses tão bom nisto, sabes?"

    # say L597 oli
    old "I know, everyone assumes that just because I'm pretty and popular, I'm just an airhead..."
    new "T(oli|tu|dizes): Eu sei, todos assumem que, só porque sou bonita e popular, sou só uma cabeçinha oca..."

    # say L599 oli
    old "But everyone is wrong, I'm not dumb at all..."
    new "B:oli: Eu sei, todo mundo assume que, só porque sou bonita e popular, sou só uma cabeça de vento..."

    # say L601 oli
    old "Even if it doesn't look like it, I do pay attention, just to what really interests me."
    new "B:oli: Mas todos estão errados, eu não sou burro de todo..."

    # say L602 pla
    old "Uhh... What do you mean?"
    new "B:oli: Mesmo que não pareça, eu presto atenção, só no que realmente me interessa."

    # say L604 oli
    old "Well, I want to be a fashion designer, and for that, I don't need to memorize differential calculus formulas, you know what I mean?"
    new "B:pla: Uhh... O que queres dizer?"

    # say L606 pla
    old "Hmm, so why do you want to improve your grades now?"
    new "B:oli: Bem, quero ser designer de moda, e para isso não preciso memorizar fórmulas de cálculo diferencial, sabes o que quero dizer?"

    # say L607 pla
    old "Is it because of what you were talking to your mom about your dad?"
    new "B:pla: Hmm, então por que queres melhorar as tuas notas agora?"

    # say L609 oli
    old "Hmm, well, yeah... Something like that."
    new "Mas espera!"

    # say L611 oli
    old "But wait!"
    new "B:oli: Hmm, bem, sim... Algo assim."

    # say L613 oli
    old "What does this have to do with you?"
    new "B:oli: Mas espera!"

    # say L615 oli
    old "How about we stop with the questions and get back to studying?"
    new "B:oli: O que isto tem a ver contigo?"

    # say L617 pla
    old "Hmm, yeah right, let's keep going."
    new "B:oli: E se pararmos com as perguntas e voltarmos ao estudo?"

    # say L627 pla
    old "Alright, it was just our first session, but we got a lot done."
    new "Bem, foi só a nossa primeira sessão, mas conseguimos fazer muito. Estamos muito limitados no tempo."

    # say L628 pla
    old "We're very short on time."
    new "B:pla: Tudo bem, foi só a nossa primeira sessão, mas conseguimos fazer muito."

    # say L630 pla
    old "But I think at this pace, we should be able to cover everything we need to before the exams."
    new "B:pla: Estamos muito apertados no tempo."

    # say L640 aye
    old "Hey sis, can I borrow your blue dress today for a- "
    new "B:pla: Mas a este ritmo, devemos conseguir cobrir tudo o que precisamos antes dos exames."

    # say L642 aye
    old "Oh, I didn't know you had company..."
    new "B:aye: Ei mana, posso emprestar o teu vestido azul hoje para..."

    # say L643 aye
    old "What were you two doing in here? Does Dad know you're bringing boys into your room?"
    new "B:aye: Oh, não sabia que tinhas companhia..."

    # say L645 oli
    old "We were studying... And it's none of your business..."
    new "B:aye: O que vocês estavam a fazer aqui? O pai sabe que estás a trazer rapazes para o teu quarto?"

    # say L646 aye
    old "Oh Olivia, where are your manners? You should introduce us."
    new "B:oli: Estavamos a estudar... E não é da tua conta..."

    # say L647 aye
    old "Hi, my name is Ayeshaa, nice to meet you."
    new "B:aye: Olá Olivia, onde estão as tuas maneiras? Deverias apresentar-nos."

    # say L649 pla
    old "Uhh, hi, nice to meet you too, my name's [pla]."
    new "T: Uhh, olá, também é bom conhecer-te, o meu nome é [pla]."

    # say L654 aye
    old "I just wanted to see if you could let me borrow the dress—"
    new "B:oli: Tudo bem, tudo bem, o que te disse sobre entrares no meu quarto sem avisar?"

    # say L656 oli
    old "No, you can't borrow my blue dress."
    new "B:aye: Só queria ver se podias emprestar-me o vestido..."

    # say L658 oli
    old "Now get the hell out of here."
    new "B:oli: Não, não podes emprestar o meu vestido azul."

    # say L660 aye
    old "Ugh, why do you always have to have that nasty attitude?!"
    new "Tu sabes o quê? Eu realmente espero que tu falhes nas tuas notas..."

    # say L663 aye
    old "You know what? I actually hope you screw up your grades..."
    new "B:aye: Ugh, porque é que tu sempre tens que ter essa atitude nojenta?!"

    # say L666 aye
    old "So dad will take you to India with him!"
    new "B:aye: Sabes o quê? Na verdade espero que tu falhes nas tuas notas..."

    # say L668 aye
    old "Maybe then you'll learn some humility."
    new "B:aye: Então o pai vai levar-te à Índia com ele!"

    # say L670 aye
    old "Alright, alright!"
    new "B:aye: Talvez assim aprendas alguma humildade."

    # say L671 aye
    old "Bye, cutie."
    new "Adeus, querida."

    # say L672 pla
    old "B- bye..."
    new "A:oli: Lamento isso."

    # say L679 oli
    old "I'm sorry about that."
    new "A:oli: Ela é só uma pestinha, e a minha mãe deixa-a sempre fazer tudo o que quer, por isso é que se comporta assim."

    # say L681 oli
    old "She's just a brat, and my mom always lets her get away with everything, that's why she acts like that."
    new "B:oli: Desculpa por isso."

    # say L683 pla
    old "Uhh... S- sure, no problem."
    new "Uhmm, a propósito, o que ela disse sobre tu ires à Índia..."

    # say L684 pla
    old "Uhmm, by the way, w- what she said about you going to India..."
    new "B:pla: Hmm... C- claro, sem problemas."

    # say L686 oli
    old "I told you! I'm not talking about that!"
    new "B:pla: Hmm, a propósito, o que ela disse sobre tu ires à Índia..."

    # say L690 oli
    old "Anyway, I think we were done studying for today, right?"
    new "B:oli: Já te disse! Não vou falar sobre isso!"

    # say L692 pla
    old "Uhh, yeah, we made good progress today, but we still have more to do. You need to get a high grade to boost your average..."
    new "B:oli: Então, acho que já estudámos o suficiente para hoje, certo?"

    # say L693 pla
    old "I know you're worried, but I think we can handle it."
    new "B:pla: Uhh, sim, fizemos bons progressos hoje, mas ainda temos mais a fazer. Precisas de tirar uma boa nota para melhorar a tua média..."

    # say L695 oli
    old "If you say so..."
    new "B:pla: Eu sei que estás preocupado, mas acho que conseguimos lidar com isso."

    # say L697 pla
    old "Alright, I think I have to go. So, are afternoons good for you to keep studying?"
    new "B:oli: Se tu dizes..."

    # say L699 oli
    old "Right, make sure to come by my house in the afternoons. Don't miss it, or you know what will happen..."
    new "B:pla: Tudo bem, acho que tenho de ir. Então, as tardes são boas para continuares a estudar?"

    # say L700 pla
    old "Yeah, sure, you don't have to remind me."
    new "B:oli: Certo, passa pela minha casa à tarde. Não faltes, ou sabes o que acontece..."

    # say L701 pla
    old "Anyway, see you later."
    new "B:pla: Claro, não precisas de me lembrar."

    # say L703 oli
    old "Ok, see you."
    new "T(oli|tu|diz): Ok, até logo."

    # say L721 oli
    old "Hey, I was waiting for you. You’re here to help me study, right?"
    new "T(oli|tu|dizer): Olá, estava à espera de ti. Vim para te ajudar a estudar, certo?"

    # say L722 pla
    old "Yeah, I'm here to keep working on the stuff we still need to cover."
    new "B:oli: Olá, estava à espera de ti. Vim aqui para te ajudar a estudar, certo?"

    # say L724 oli
    old "Great! I was getting worried you might take too long to come back."
    new "B:pla: Sim, estou aqui para continuar a trabalhar no que ainda precisamos de fazer."

    # say L726 oli
    old "Let's not waste any time and get started."
    new "B:oli: Ótimo! Estava a ficar preocupado que pudesses demorar-te demasiado a voltar."

    # say L727 pla
    old "Alright, let's continue where we left off last time."
    new "T: Bem, continuemos onde paramos da última vez."

    # say L729 oli
    old "Sure, let's do it."
    new "B:pla: Tudo bem, vamos continuar onde paramos da última vez."

    # say L758 pla
    old "Alright, I think that's enough for today."
    new "T(tu|diz): Tudo bem, acho que já chega por hoje."

    # say L759 pla
    old "We still have some other things to cover, but I'll be back soon so we can continue with what's left."
    new "B:pla: Está bem, acho que já chega por hoje."

    # say L760 pla
    old "And then we can move on to the next topic."
    new "B:pla: Ainda temos algumas coisas para tratar, mas volto logo para continuarmos com o que falta."

    # say L762 oli
    old "Alright, sure, thanks for coming."
    new "B:pla: E depois podemos passar ao próximo tópico."

    # say L763 oli
    old "I'll see you soon."
    new "B:oli: Tudo bem, claro, obrigado por vires."

    # say L796 pla
    old "Hi Mrs. Priya, how are you today?"
    new "Estou bem, querida."

    # say L798 vee
    old "I'm doing alright sweetheart."
    new "B:pla: Olá Sra. Priya, como está hoje? T(vee|tu|say): Estou bem, querida. A:vee: Meu amor, veio ver a Olivia?"

    # say L799 vee
    old "Honey, did you come to see Olivia?"
    new "B:vee: Estou bem, querida."

    # say L800 vee
    old "Because right now it's time for school."
    new "B:vee: Meu amor, vieste ver a Olivia?"

    # say L802 vee
    old "Shouldn't you be there?"
    new "B:vee: Porque agora é hora de ir à escola."

    # say L803 pla
    old "Oh, yeah, Mrs. Priya, I just have the day off school to run a couple of errands."
    new "T(pla|tu|diz): Oh, sim, Sra. Priya, só tenho o dia de folga da escola para fazer uns recados."

    # say L804 pla
    old "And I wanted to say hi."
    new "B:pla: Oh, yeah, Mrs. Priya, só tenho o dia de folga da escola para fazer uns recados."

    # say L805 vee
    old "I see, I'm glad to see you dear."
    new "B:pla: E queria dizer olá."

    # say L806 vee
    old "I'll be sure to tell Olivia you stopped by."
    new "B:vee: Vejo, fico contente por te ver, querida."

    # say L811 vee
    old "Hello, [pla]!"
    new "Olá, [pla]!"

    # say L814 vee
    old "It's good to see you, dear. How are you today?"
    new "T(vee|tu|say): É bom ver-te, querida. Como estás hoje?"

    # say L816 pla
    old "I'm fine, Mrs. Priya, and you?"
    new "B:vee: É bom ver-te, querida. Como estás hoje?"

    # say L818 vee
    old "I'm doing alright, dear. Keeping busy as usual, thanks for asking."
    new "T(vee|tu|diz): Estou bem, querida. A manter-me ocupada como sempre, obrigada por perguntar."

    # say L819 vee
    old "Tell me, did you come to see Olivia?"
    new "B:vee: Estou bem, querida. A manter-me ocupada como sempre, obrigada por perguntar."

    # say L823 vee
    old "Great! She's in her bedroom right now, dear."
    new "B:vee: Diz-me, vieste ver a Olivia?"

    # say L824 vee
    old "Don't mind me, you can go right in."
    new "B:vee: Ótimo! Ela está no quarto agora, querida."

    # say L826 pla
    old "Thanks, Mrs. Priya. I'll catch up with you later."
    new "B:vee: Não te preocupes, podes entrar."

    # say L828 vee
    old "That's alright, dear. Nice seeing you."
    new "B:pla: Obrigado, Sra. Priya. Vou apanhar o autocarro mais tarde."

    # say L829 vee
    old "And if you kids need anything, just let me know."
    new "B:vee: Tudo bem, querida. Foi bom ver-te."

    # say L840 pla
    old "Alright, that's it, that's the right method."
    new "B:vee: E se precisarem de algo, é só me dizer."

    # say L842 pla
    old "Great, you got it!"
    new "B:pla: Tudo bem, é esse o método certo. T(pla|tu|say): Ótimo, tu conseguiu! A:pla: Sabes, estamos a fazer muito bom progresso."

    # say L844 pla
    old "You know, we're making very good progress."
    new "B:pla: Ótimo, tu conseguiu!"

    # say L846 pla
    old "At this rate we'll manage to go over every topic before the exams."
    new "B:pla: Sabes, estamos a fazer muito bons progressos."

    # say L847 oli
    old "Yeah, ok... Great."
    new "T(oli|tu|dizes): Sim, claro... Ótimo."

    # say L849 pla
    old "That doesn't seem like you're too sure about it."
    new "T: Não parece que estás muito convencido disso."

    # say L856 oli
    old "I just feel like this isn't working [pla]."
    new "T(oli|tu|dizes): Sinto apenas que isto não está a resultar [pla]."

    # say L860 oli
    old "But how well am I really going to do in them?"
    new "T(oli|tu|dizer): Mas como é que vou realmente me sair neles?"

    # say L861 oli
    old "With so little time, there's only so much I can learn."
    new "Vamos, não sejas tão negativo."

    # say L863 pla
    old "Come on, don't be so negative."
    new "B:oli: Com tão pouco tempo, há apenas tanto que posso aprender."

    # say L865 pla
    old "I know what you mean. But it's worth giving it a shot."
    new "B:pla: Vamos, não sejas tão negativo."

    # say L866 oli
    old "I know it is."
    new "A:oli: É só que quando vejo quanto mais temos que estudar."

    # say L868 oli
    old "It's just that when I see how much more we have to study."
    new "E o tempo que falta até aos exames."

    # say L869 oli
    old "And the time that's left before the exams."
    new "E o tempo que falta até aos exames."

    # say L873 oli
    old "That was just a huge waste of time!"
    new "B:oli: E o tempo que falta até aos exames."

    # say L874 pla
    old "Hey, hey, come on."
    new "B:oli: Isso foi um desperdício de tempo enorme!"

    # say L875 pla
    old "I understand how you feel, but let's not get discouraged."
    new "B:pla: Ei, ei, vem cá."

    # say L877 pla
    old "I'm sure you'll do well in these exams."
    new "T: Tenho a certeza de que vais bem nestes exames."

    # say L879 pla
    old "I mean... Yeah, it would be very difficult to get perfect scores."
    new "B:pla: Tenho a certeza de que vais bem nestes exames."

    # say L880 pla
    old "But I'm sure that if we keep studying at this pace, and with a little luck."
    new "B:pla: Quero dizer... Sim, seria muito difícil obter notas perfeitas."

    # say L882 pla
    old "You'll get grades that are good enough for you to pass all the subjects."
    new "B:pla: Mas tenho a certeza de que se continuarmos a estudar a este ritmo, e com um pouco de sorte."

    # say L887 pla
    old "Uh, ok?"
    new "B:oli: Se não tiver as notas máximas, não vai ser suficiente!"

    # say L889 pla
    old "But why, though?"
    new "A:pla: Quer dizer, percebo que estudar e as notas sejam importantes."

    # say L890 pla
    old "I mean, I understand that studying and grades are important."
    new "Mas por que é tão importante obter as melhores notas?"

    # say L892 pla
    old "But why is it so important to get the maximum grades?"
    new "B:pla: Quero dizer, eu percebo que estudar e as notas são importantes."

    # say L900 oli
    old "I didn't want to tell you about this, but I guess it's better if you understand the full picture."
    new "T(oli|tu|dizes): Não queria contar-te isto, mas é melhor que percebas toda a situação. A:oli: Ouve, se não tiver as melhores notas no final do trimestre, vou ser enviado para a Índia viver com o meu pai."

    # say L902 oli
    old "Listen, if I don't get maximum or top grades by the end of the term, I'll be sent to India to live with my dad."
    new "B:oli: Não queria contar-te isto, mas acho melhor que percebas toda a situação."

    # say L905 oli
    old "Well, you know my parents are from India, right?"
    new "B:oli: Ouve, se não tiver as melhores notas no final do trimestre, vou ser mandado para a Índia viver com o meu pai."

    # say L906 pla
    old "Hmm, yeah sure..."
    new "B:oli: Bem, tu sabes que os meus pais são da Índia, certo?"

    # say L908 oli
    old "See, my father is still living there. He comes here often, but his business is located there."
    new "Enquanto nós ficamos aqui com a minha mãe."

    # say L909 oli
    old "While we stay here with my mother."
    new "B:oli: Vê, o meu pai ainda vive lá. Vem aqui frequentemente, mas o seu negócio está lá."

    # say L913 oli
    old "Well, my dad's a very traditional guy."
    new "B:oli: Enquanto estamos aqui com a minha mãe."

    # say L915 oli
    old "He cares a lot about upholding tradition and customs."
    new "B:oli: Bem, o meu pai é um homem muito tradicional."

    # say L917 oli
    old "And since I'm the oldest daughter, he wants me to take part in a lot of those traditions."
    new "E como sou a filha mais velha, ele quer que eu participe de muitas dessas tradições. Sem me consultar ou informar sobre isso!"

    # say L921 oli
    old "Without consulting me or letting me know about it!"
    new "B:oli: E como sou a filha mais velha, ele quer que eu participe de muitas dessas tradições."

    # say L922 pla
    old "Uh, I- I see."
    new "A: pla: B- mas, não achas que se falasses com ele, ele entenderia que não estás apaixonada pelo homem que ele quer que cases?"

    # say L925 pla
    old "B- but, don’t you think if you talked to him, he’d understand you’re not in love with the guy he wants you to marry?"
    new "B:pla: Uh, e-eu vejo."

    # say L932 oli
    old "He knows that by getting me married to him, he would get a big opportunity to do business."
    new "B: O homem com quem me comprometeu é o herdeiro de uma empresa muito bem-sucedida."

    # say L934 oli
    old "He thinks that since I'm the oldest daughter, it is my duty to the family to go through with his plan!"
    new "B:oli: Ele sabe que, ao me casar com ele, teria uma grande oportunidade de fazer negócios."

    # say L935 pla
    old "B- but, isn't there anything that you can do?"
    new "B- mas, não há nada que tu possas fazer?"

    # say L937 oli
    old "Well, that's why I need to get good grades."
    new "B: B- mas, não há nada que tu possas fazer?"

    # say L939 oli
    old "My mom's a little more open-minded than my dad. She knows I don't want to live my life that way."
    new "B:oli: Por isso é que preciso de ter boas notas."

    # say L941 oli
    old "She's been supporting me, and interceding on my behalf with my dad."
    new "B:oli: A minha mãe é um pouco mais aberta de mente do que o meu pai. Ela sabe que não quero viver a minha vida dessa maneira."

    # say L943 oli
    old "That's been a huge problem between them, they've been fighting over it."
    new "B:oli: Ela tem estado a apoiar-me e a interceder por mim junto do meu pai."

    # say L945 oli
    old "But my mom finally convinced him to let me off the hook if I get good grades by the end of the term."
    new "B:oli: Isso tem sido um grande problema entre eles, eles têm estado a discutir por causa disso."

    # say L946 oli
    old "That's why I'm so desperate to get the highest scores! Because I really have to!"
    new "B:oli: Mas a minha mãe finalmente convenceu-o a deixar-me de castigo se eu tiver boas notas até ao fim do trimestre."

    # say L948 pla
    old "I- I see. I understand."
    new "B:oli: É por isso que estou tão desesperada para ter as melhores notas! Porque realmente preciso!"

    # say L949 pla
    old "I didn't know how important the exam results would be for you."
    new "T(pla|tu|say): Não sabia o quanto os resultados do exame eram importantes para ti."

    # say L951 pla
    old "I'm not sure, but I think we can make it so that you'll be able to get the top grades."
    new "B:pla: Não sabia o quanto os resultados do exame eram importantes para ti."

    # say L953 oli
    old "Do you really mean it?"
    new "T(oli|tu|dizes): Tu estás a falar a sério?"

    # say L955 oli
    old "I know there's too little time to do this."
    new "B:oli: Tu estás a falar a sério?"

    # say L956 pla
    old "But I know we can make it, come on let's keep going!"
    new "B:oli: Eu sei que há muito pouco tempo para fazer isto."

    # say L958 oli
    old "Okay, okay."
    new "B:pla: Mas eu sei que conseguimos, vamos lá, continua!"

    # say L968 pla
    old "I think that's enough for today, but I'll be back soon so we can keep going."
    new "B:oli: Ok, ok."

    # say L969 pla
    old "Don't worry, we'll get this done before you know it."
    new "T(pla|tu|say): Não te preocupes, vamos acabar isto antes que te apercebas."

    # say L980 pla
    old "I'll go for now, but I'll see you later."
    new "T(pla|tu|say): Vou-me embora por agora, mas vejo-te mais tarde."

    # say L1005 vee
    old "Yeah, that's right. Your aunt Fatima said she'd be sending Devika here to spend some time with us."
    new "B:pla: Vou-me embora por agora, mas vejo-te mais tarde."

    # say L1008 vee
    old "Oh honey, don't make that face."
    new "B:vee: Sim, é verdade. A tua tia Fatima disse que ia enviar a Devika cá para passar algum tempo connosco."

    # say L1011 oli
    old "I just don't know if she should come here."
    new "A:oli: Onde é que ela vai dormir?"

    # say L1014 oli
    old "Where is she going to sleep?"
    new "B:oli: Não sei se ela deve vir aqui."

    # say L1016 vee
    old "You don't need to worry about that."
    new "B:oli: Onde é que ela vai dormir?"

    # say L1018 vee
    old "Besides, I know you like your cousin. You two used to be very close!"
    new "B:vee: Não precisas de te preocupar com isso."

    # say L1019 oli
    old "Hmm, that was a long time ago."
    new "B:vee: Além disso, sei que tu gostas da tua prima. Vocês costumavam ser muito próximos!"

    # say L1021 oli
    old "But I guess it's alright if she comes here. I like Aunty Fatima, so it shouldn't be too much of a problem."
    new "B:oli: Hmm, isso foi há muito tempo."

    # say L1027 pla
    old "Uh, s- sorry for interrupting."
    new "A:pla: Olá, Olivia, vim continuar as nossas sessões de estudo."

    # say L1030 pla
    old "Hi Olivia, I came to continue our study sessions."
    new "B:pla: Uh, s- desculpa por interromper."

    # say L1032 oli
    old "[pla], I'm so glad you're here! I was just waiting for you!"
    new "T(oli|tu|diz): [pla], estou tão contente que tu estás aqui! Estava à espera de ti!"

    # say L1034 pla
    old "W- well, here I am, I guess."
    new "B:pla: Uh... Tu estavas?"

    # say L1035 oli
    old "Yeah, I was just waiting for you to make our announcement."
    new "B:pla: B- bem, aqui estou eu, acho."

    # say L1043 oli
    old "Mom, there's something that [pla] and I have been wanting to tell you."
    new "T(oli|tu|dizer): Mãe, há algo que [pla] e eu queríamos te contar."

    # say L1046 vee
    old "Hmm, o-kay? What is it?"
    new "B:oli: E decidimos que este é o momento certo para o fazer."

    # say L1055 oli
    old "What you just heard, Mom. [pla] and I have been dating for a while now."
    new "T(oli|tu|dizes): O que acabaste de ouvir, Mãe. [pla] e eu estamos a namorar há algum tempo."

    # say L1057 vee
    old "I'm sorry, and why hadn't I heard about this until now?"
    new "T(vee|tu|say): Desculpa, e por que não soube disso antes?"

    # say L1059 oli
    old "Because I just wanted to be sure about what he and I feel, and of our relationship."
    new "T(oli|tu|dizes): Porque só queria ter a certeza dos sentimentos dele e meus, e da nossa relação."

    # say L1062 oli
    old "Also, I knew that you and Dad wouldn't have approved."
    new "B:oli: Porque queria ter a certeza do que ele e eu sentimos, e da nossa relação."

    # say L1064 vee
    old "Oh, you think so?"
    new "T(vee|tu|say): Oh, tu pensas isso?"

    # say L1067 vee
    old "Not only are you dating someone without our approval."
    new "Não só estás a namorar alguém sem a nossa aprovação. Agora também vens dizer-me assim?"

    # say L1069 vee
    old "Now you also come and tell me like this?"
    new "B:vee: Não só estás a namorar alguém sem a nossa aprovação."

    # say L1072 vee
    old "You know full well that this is not how we do things, Olivia!"
    new "T(tu|tu|dizer): Tu sabes muito bem que não fazemos as coisas assim, Olivia!"

    # say L1074 vee
    old "I can't even imagine the face Vihaan's going to make when he finds out about this."
    new "B:vee: Tu sabes muito bem que não fazemos as coisas assim, Olivia!"

    # say L1078 oli
    old "Mom, [pla] and I are in love."
    new "T(oli|tu|dizer): Mãe, [pla] e eu estamos apaixonados."

    # say L1082 oli
    old "So I need your help to convince him that this is okay."
    new "B:oli: Mas sei que se contar ao pai, ele nunca vai aprovar."

    # say L1085 vee
    old "It's not that simple, honey. You know I have no problem with you having a boyfriend."
    new "T: Não é assim tão simples, querida. Sabes que não tenho problema com tu teres um namorado. Mas Vihaan é muito mais tradicional do que eu."

    # say L1088 vee
    old "But Vihaan is a lot more traditional than me."
    new "B:vee: Não é assim tão simples, querida. Sabes que não tenho problema com tu teres um namorado."

    # say L1089 vee
    old "And he won't be pleased with this at all."
    new "T(vee|tu|dizes): E ele não vai gostar nada disto."

    # say L1092 oli
    old "I know that, Mom, but I don't want to go along with Dad's plan."
    new "T(oli|tu|dizes): Eu sei, mãe, mas não quero seguir o plano do pai."

    # say L1093 oli
    old "You know what he wants..."
    new "B:oli: Eu sei, mãe, mas não quero seguir o plano do pai."

    # say L1096 oli
    old "If it was up to him, I would already be wedded to that guy he wants me to marry."
    new "B:oli: Tu sabes o que ele quer..."

    # say L1099 oli
    old "But I don't want to live my life like that, Mom!"
    new "B:oli: Se dependesse dele, eu já estaria casada com aquele homem que ele quer que eu case."

    # say L1102 oli
    old "I don't care about that guy I don't know."
    new "B:oli: Mas não quero viver a minha vida assim, Mãe!"

    # say L1105 oli
    old "He's not what I want for my life."
    new "B:oli: Não me importo com esse cara que eu não conheço."

    # say L1118 vee
    old "Alright, I can see you're serious about this."
    new "T(vee|tu|diz): Claro, posso ver que estás a levar isto a sério."

    # say L1119 oli
    old "That means you'll help me?"
    new "B:vee: Tudo bem, vejo que estás a levar isto a sério."

    # say L1121 vee
    old "Well, what choice do I have?"
    new "B:oli: Isso significa que vais ajudar-me?"

    # say L1123 vee
    old "You're putting me in a tough spot right now, honey."
    new "B:vee: Bem, que escolha tenho eu?"

    # say L1126 vee
    old "But I wouldn't want to force your hand."
    new "B:vee: Estás a colocar-me numa situação difícil neste momento, querida."

    # say L1129 vee
    old "And to be honest, I'm not too keen on this whole arranged marriage situation."
    new "E para ser sincera, não estou muito entusiasmada com toda esta situação de casamento arranjado."

    # say L1132 vee
    old "So I'll help you with your father for now."
    new "B:vee: E a ser sincera, não estou muito entusiasmada com toda esta situação de casamento arranjado."

    # say L1134 oli
    old "That's great, Mom, thank you!"
    new "B:vee: Então vou ajudar-te com o teu pai por agora."

    # say L1137 vee
    old "Yeah well, that's only if you get good grades, you know."
    new "B:oli: Isso é ótimo, mãe, obrigado!"

    # say L1138 vee
    old "Remember, that's a deal we already made with your father, so don't disappoint us."
    new "B:vee: Pois, isso só acontece se tiveres boas notas, sabes."

    # say L1140 oli
    old "Don't worry, I promise you I'm working very hard."
    new "B:vee: Lembra-te, é um acordo que já fizemos com o teu pai, por isso não nos desiludas."

    # say L1161 oli
    old "Ok, that went well."
    new "A:pla: Tu poderias explicar-me do que se trata esta história de estarmos a namorar?"

    # say L1164 pla
    old "Would you mind telling me what this business of us dating is about?"
    new "B:oli: Ok, correu bem."

    # say L1165 oli
    old "Well, you heard me talking to my mom."
    new "B:pla: Tu não te importas de me dizer do que se trata este assunto de sairmos juntos?"

    # say L1167 oli
    old "Listen, after the last time you came here, I got to thinking about how much work is still left to do."
    new "B:oli: Ouve, ouviste a conversa que tive com a minha mãe."

    # say L1169 oli
    old "And I got worried about the possibility of not finishing it."
    new "B:oli: Ouve, depois da última vez que vieste aqui, comecei a pensar no quanto de trabalho ainda falta fazer."

    # say L1171 oli
    old "So I figured I needed a contingency plan in case my grades don't turn out to be good."
    new "B:oli: E fiquei preocupado com a possibilidade de não terminar."

    # say L1172 pla
    old "So you came up with the idea of us dating? How is that going to help?"
    new "T(pla|tu|say): Então pensaste em namorarmos? Como é que isso vai ajudar?"

    # say L1174 oli
    old "Think about it [pla], if I can convince my Dad that I'm in love with you."
    new "T(oli|tu|dizes): Pensa bem, [pla], se eu conseguir convencer o meu pai que estou apaixonado por ti. A:oli: E que as coisas são sérias o suficiente para eu considerar casar-me contigo."

    # say L1178 oli
    old "Maybe he'll give up on trying to push me into that marriage."
    new "B:oli: E que as coisas são sérias o suficiente para eu considerar casar-me contigo."

    # say L1180 oli
    old "I'm sorry, is this a problem for you?"
    new "B:oli: Talvez ele desista de tentar me obrigar a casar."

    # say L1182 pla
    old "No, not really. I promised to help you with this, and I get what you're doing."
    new "B:oli: Desculpa, isto é um problema para ti?"

    # say L1183 pla
    old "So it's alright, I'll help you with it."
    new "B:pla: Não, não realmente. Prometi ajudar-te com isto, e percebo o que estás a fazer."

    # say L1185 pla
    old "I'm happy to help you."
    new "Agora, vamos estudar para garantir que não precisas do teu plano B."

    # say L1186 pla
    old "Now, let's get to studying, to ensure that you don't need your contingency plan."
    new "B:pla: Estou feliz em ajudar-te."

    # say L1196 oli
    old "Ugh! This is pointless!"
    new "T(oli|tu|diz): Isto é inútil!"

    # say L1197 pla
    old "W-what? What do you mean?"
    new "A:oli: Estou a falar desta coisa toda de estudar para os exames!"

    # say L1199 oli
    old "I'm talking about this whole studying for exams thing!"
    new "B:pla: Q-que? O que queres dizer?"

    # say L1200 oli
    old "It's pointless!"
    new "É inútil!"

    # say L1203 oli
    old "Think about it, [pla]..."
    new "Pensa bem, [pla]... Olha para tudo o que ainda tenho a fazer!"

    # say L1206 oli
    old "There are so many topics!"
    new "A:oli: Não há como eu enfiar tudo isso na cabeça antes dos exames!"

    # say L1207 oli
    old "There's no way I can cram all of this into my head before the exams!"
    new "Oh! A Olivia está outra vez no quarto com o namorado?"

    # say L1220 aye
    old "Oh! Olivia is with her boyfriend in her room again?"
    new "B:oli: Não há maneira de eu conseguir meter tudo isto na cabeça antes dos exames!"

    # say L1221 aye
    old "I wonder what they talk about when they're alone..."
    new "B:aye: Oh! A Olivia está com o namorado no quarto dela de novo?"

    # say L1222 aye
    old "Or maybe they're doing some dirty stuff?"
    new "B:aye: Que se calhar falam quando estão sozinhos..."

    # say L1228 aye
    old "I guess a little eavesdropping won't hurt."
    new "B:aye: Ou talvez estejam a fazer coisas sujas?"

    # say L1235 pla
    old "I can see why you're worried."
    new "B:aye: Acho que uma pequena bisbilhotice não fará mal."

    # say L1237 pla
    old "But you still have to try."
    new "B:pla: Consigo perceber por que estás preocupado."

    # say L1238 pla
    old "Look at how much work you've put in already."
    new "B:pla: Mas ainda tens de tentar."

    # say L1240 pla
    old "You can't give up now."
    new "B:pla: Olha quanto trabalho já fizeste."

    # say L1242 oli
    old "I know I've put in a lot of work, [pla]."
    new "T(oli|tu|dizes): Sei que já trabalhei muito, [pla]."

    # say L1247 aye
    old "{i}(She seems to be struggling.){/i}"
    new "B:aye: {i}(Hmm, acho que estão a falar das notas dela.){/i}"

    # say L1248 aye
    old "{i}(Ha! That's great!){/i}"
    new "B:aye: {i}(Parece que ela está a lutar.){/i}"

    # say L1249 aye
    old "{i}(When Dad finds out, he'll bring her to India right away!){/i}"
    new "B:aye: {i}(Ha! Isso é ótimo!){/i}"

    # say L1252 pla
    old "I get it, I know you're stressed and frustrated."
    new "Mas vamos, não podes desistir."

    # say L1254 pla
    old "But come on, you can't give up."
    new "B:pla: Entendo, sei que estás stressado e frustrado."

    # say L1256 oli
    old "I don't know, I think we should make another plan."
    new "B:pla: Mas vamos, tu não podes desistir."

    # say L1261 aye
    old "{i}(He's not her boyfriend?){/i}"
    new "B: aye: {i}(E-então? Do que é que ela está a falar?){/i}"

    # say L1275 oli
    old "{b}*Sigh*{/b} What do you want?"
    new "Olá, mana! Como estás? {b}*Suspiro*{/b} O que queres? Oh, não muito."

    # say L1283 oli
    old "I- I don't know what you're talking about."
    new "B:aye: Que será isso?"

    # say L1284 aye
    old "Oh yeah, I bet you don't."
    new "B:oli: I- Não sei do que estás a falar."

    # say L1287 aye
    old "You know, dad's going to be very displeased about this."
    new "T: Sabes, o pai vai ficar muito desagradado com isto."

    # say L1289 aye
    old "I can already imagine his face when I tell him that you're apparently faking having a boyfriend."
    new "B:aye: Sabes, o pai vai ficar muito desagradado com isto."

    # say L1291 aye
    old "I can't wait."
    new "E-Espera! Tu não percebes."

    # say L1293 oli
    old "W-wait! You don't understand."
    new "T(oli|tu|diz): E-e-espera! Tu não percebes."

    # say L1294 oli
    old "I think you misheard us or something."
    new "T(oli|tu|dizes): Acho que mal interpretaste o que dissemos ou algo assim."

    # say L1296 aye
    old "Oh no, don't give me that. I didn't mishear anything!"
    new "T: Oh não, não me venhas com isso. Eu não ouvi nada mal!"

    # say L1299 aye
    old "You know, I thought it was strange."
    new "T: Sabes, achei estranho quando tu de repente trouxeste um namorado para casa."

    # say L1300 aye
    old "When you suddenly brought a boyfriend home."
    new "E não só isso, de repente decidiste começar a estudar."

    # say L1303 aye
    old "And not only that, from one moment to the next, you decided to start studying."
    new "E não só isso, de repente decidiste começar a estudar. Quando nunca te tinha visto levar os estudos a sério."

    # say L1305 aye
    old "When I had never seen you take your studies seriously."
    new "B:aye: E não só isso, de repente decidiste começar a estudar."

    # say L1307 aye
    old "I see now that this is just a ploy to avoid going to India with dad, isn't it?"
    new "B:aye: Quando nunca te vi levar os estudos a sério."

    # say L1308 pla
    old "{i}(W-wow, she's sharp. She figured it out just like that!){/i}"
    new "T(pla|tu|say): {i}(Caramba, ela é perspicaz. Descobriu assim tão rápido!){/i}"

    # say L1314 oli
    old "Now get out of my room before I throw you out!"
    new "B:oli: Ugh, cala-te! Isto não tem nada a ver com isso!"

    # say L1316 aye
    old "Oh, I'll get out of here!"
    new "B:oli: Agora sai do meu quarto antes que eu te expulse!"

    # say L1319 aye
    old "And I'll go call Dad right away!"
    new "B:aye: Oh, vou sair daqui!"

    # say L1320 aye
    old "With all the work Dad's doing to grant you a future!"
    new "B:aye: E vou já chamar o pai!"

    # say L1323 aye
    old "And this is how you decide to repay him, by lying to him!"
    new "E esta é a forma como decides recompensá-lo, mentindo para ele! Não vejo a hora de lhe contar o quão má a sua filha favorita realmente é!"

    # say L1325 aye
    old "I can't wait to let him know how bad his favorite daughter really is!"
    new "E tu não vês que isto é a forma como decidiste recompensá-lo, mentindo-lhe!"

    # say L1336 aye
    old "Yes? What do you want?"
    new "B:aye: Mal posso esperar para lhe dizer o quão má a sua filha favorita realmente é!"

    # say L1345 oli
    old "I swear to God, one day."
    new "B:aye: Hmm... Talvez, se me convenceres, claro."

    # say L1365 aye
    old "What? Happy?"
    new "B:oli: Lá, estás contente?"

    # say L1370 aye
    old "I could kiss him right now too."
    new "B: aye: O quê? Feliz?"

    # say L1372 aye
    old "That doesn't prove anything!"
    new "B:aye: Eu também podia beijá-lo agora."

    # say L1374 oli
    old "What are you insinuating?"
    new "T(oli|tu|dizes): O que estás a insinuar?"

    # say L1376 aye
    old "Come on sis, prove to me that you're really a couple."
    new "A:oli: O que queres dizer com isso?"

    # say L1378 oli
    old "What do you mean by that?"
    new "A:aye: Oh, vai lá! Eu sabia que eras parva, mas não pensava que fosses tanto."

    # say L1379 aye
    old "Oh come on! I knew you were dumb, but I didn't think this much."
    new "T: Oh, vai lá! Sabia que eras parvo, mas não pensava que fosses tanto."

    # say L1384 oli
    old "W- what? What are you talking about? Do you think I just go around doing that?"
    new "B:aye: Oh, vamos lá! Eu sabia que eras parvo, mas não tanto assim."

    # say L1385 oli
    old "I don't do that sort of thing!"
    new "T(oli|tu|dizes): Não faço esse tipo de coisa!"

    # say L1388 aye
    old "Don't treat me like I'm stupid!"
    new "B:oli: Não faço esse tipo de coisa!"

    # say L1393 pla
    old "H- hey, hey! L- let's not get carried away, girls."
    new "T: H- hey, hey! N- não vamos nos exaltar, meninas."

    # say L1397 oli
    old "Stay out of this!"
    new "B: H- hey, hey! N- não vamos exagerar, raparigas."

    # say L1403 oli
    old "Listen, you little bitch."
    new "B:oli: Fica fora disto!"

    # say L1405 oli
    old "First, be very careful about who you're calling a whore."
    new "B:oli: Escuta, tu putinha."

    # say L1407 oli
    old "Second, there must be something really wrong with your head if you want to see me fuck this guy in front of you."
    new "B:oli: Primeiro, sejas muito cuidadoso com quem chamas de puta."

    # say L1410 oli
    old "And if you think I'll let you watch that."
    new "B:oli: Segundo, deve haver algo realmente errado com a tua cabeça se queres ver-me a foder este gajo à tua frente."

    # say L1411 oli
    old "So why don't you get the hell out of here?!"
    new "B:oli: E se pensas que vou deixar-te ver isso."

    # say L1414 aye
    old "Oh, I can leave, I told you I have no problem with that."
    new "B:oli: Então porque não saís daqui?!"

    # say L1416 aye
    old "But you know what I'll do right away!"
    new "B:aye: Oh, posso ir, já te disse que não tenho problema com isso."

    # say L1419 aye
    old "Because I don't have any proof that this guy is your real boyfriend."
    new "B:aye: Mas sabes o que vou fazer já!"

    # say L1422 aye
    old "Thinking about it, right now it must be early morning in India."
    new "B:aye: Porque não tenho qualquer prova de que este tipo é o teu namorado de verdade."

    # say L1423 aye
    old "Daddy must be waiting for me to send him his good morning message."
    new "B:aye: A pensar nisso, agora deve ser de madrugada na Índia."

    # say L1424 aye
    old "I'm sure he'll appreciate the extra news!"
    new "B:aye: O pai deve estar à espera da minha mensagem de bom dia."

    # say L1433 oli
    old "I'm NOT going to have sex with this guy in front of you."
    new "T(oli|tu|dizes): Não vou fazer sexo com esse cara na tua frente."

    # say L1434 oli
    old "But if I do something sexual with him..."
    new "B:oli: Não vou ter relações com este rapaz na tua frente."

    # say L1437 oli
    old "Will you stop saying he's not my boyfriend and leave us alone?"
    new "B:oli: Mas se eu fizer algo sexual com ele..."

    # say L1438 aye
    old "Hmm, I don't know, that really depends on you."
    new "B:oli: Vais parar de dizer que ele não é o meu namorado e deixar-nos em paz?"

    # say L1441 aye
    old "It has to look real, sis."
    new "T(aye|tu|diz): Tem que parecer real, mana."

    # say L1442 oli
    old "I get it..."
    new "B:aye: Tem de parecer real, mana."

    # say L1445 oli
    old "I will do this then."
    new "B:oli: Entendo..."

    # say L1450 oli
    old "The only reason I'm going along with this sick game of yours."
    new "B:oli: Vou fazer isto então."

    # say L1453 oli
    old "Is because I don't have any other way of proving to you that this guy and I have a relationship."
    new "B:oli: A única razão pela qual estou a participar neste jogo doentio teu."

    # say L1455 oli
    old "But this is the last time I'll let you push me into something like this."
    new "B:oli: É porque não tenho outra forma de provar que este tipo e eu temos uma relação."

    # say L1458 oli
    old "If you ever try this again, I don't care what you have to say to anyone, I'll fucking make you pay!"
    new "B:oli: Mas esta é a última vez que te deixo empurrar-me para algo assim."

    # say L1460 aye
    old "Very clear, sis, but I don't see you proving anything, so why don't you get to it?"
    new "B:oli: Se alguma vez tentares isto de novo, não me importa o que tenhas para dizer a quem quer que seja, vou fazer-te pagar!"

    # say L1461 aye
    old "And remember, make it convincing."
    new "B:aye: Muito claro, mana, mas não vejo tu a provar nada, então porque não te pões a isso?"

    # say L1466 pla
    old "W- woah! Woah! Is this for real? Do you want to do this in front of her?"
    new "T(pla|tu|say): W- woah! Woah! Isto é a sério? Queres fazer isto à frente dela?"

    # say L1484 aye
    old "Oh gosh! You're actually doing it!"
    new "B:oli: Claro que estou a ser sério..."

    # say L1485 aye
    old "This is for real! I can't believe it!"
    new "B:aye: Ai caramba! Tu estás realmente a fazê-lo!"

    # say L1496 aye
    old "I have to say, sis, that was quite the spectacle."
    new "B:aye: Isto é sério! Não posso acreditar!"

    # say L1497 oli
    old "Are you satisfied?"
    new "B:aye: Tenho de dizer, mana, que foi bastante espectacular."

    # say L1498 aye
    old "Oh! Of course, I am!"
    new "B:oli: Estás satisfeito?"

    # say L1499 aye
    old "I can tell how much you liked it!"
    new "B:aye: Oh! Claro, sou eu!"

    # say L1502 aye
    old "You can just tell how much love there is between the two of you!"
    new "B: aye: Consigo perceber o quanto tu gostaste!"

    # say L1504 oli
    old "Alright, you have what you wanted. Now get the hell out of here!"
    new "B:aye: Tu consegues ver o quanto de amor há entre vocês dois!"

    # say L1506 oli
    old "And remember what I told you."
    new "B:oli: Tudo bem, tens o que querias. Agora sai daqui!"

    # say L1508 oli
    old "I won't allow this to happen a second time, now get the hell out of my room, you bitch!"
    new "E não vais permitir que isto aconteça de novo, agora sai da minha sala, tua cadela!"

    # say L1510 aye
    old "Oh, I'm leaving alright."
    new "B:oli: Não vou permitir que isso aconteça de novo, agora sai da minha sala, tua vaca!"

    # say L1521 pla
    old "Uhmm... A- are you alright?"
    new "B:oli: Fora!"

    # say L1525 oli
    old "And not a lot of time, so let's just get back to studying."
    new "B:oli: Ainda temos muito terreno a percorrer."

    # say L1526 pla
    old "R- right."
    new "B:oli: E não temos muito tempo, então vamos voltar aos estudos."

    # say L1545 pla
    old "I guess I'll go home for now. And I'll come back later."
    new "Mas antes de ires, quero esclarecer uma coisa."

    # say L1548 oli
    old "But before you leave, I want to make something clear."
    new "B:pla: Acho que vou para casa por agora. E volto mais tarde."

    # say L1550 oli
    old "What just happened here was just a one-time thing, alright?"
    new "B:oli: Mas antes de ires, quero esclarecer uma coisa."

    # say L1552 oli
    old "Don't get any ideas about it happening again."
    new "B:oli: O que aconteceu aqui foi apenas uma coisa de uma vez, percebes?"

    # say L1555 pla
    old "S-sure, of course."
    new "T(pla|tu|say): C-certo, claro."

    # say L1557 oli
    old "Alright, then I'll see you later."
    new "B:pla: C-certo, claro."

    # say L1558 pla
    old "Sure, bye."
    new "Tudo bem, adeus."

    # say L1574 pla
    old "Alright, we somehow managed to cover everything."
    new "Tudo bem, de alguma forma conseguimos cobrir tudo."

    # say L1575 pla
    old "It might not have been too thorough."
    new "T(pla|tu|say): Pode não ter sido muito aprofundado."

    # say L1576 pla
    old "But I'm sure you know enough now to shoot for the highest grades."
    new "B:pla: Pode não ter sido muito completo."

    # say L1581 pla
    old "I'm sure you'll do great."
    new "B:pla: Mas tenho a certeza de que já sabes o suficiente para conseguir as melhores notas."

    # say L1583 pla
    old "Just remember, all you have to do is stay calm while you're answering the questions."
    new "B:pla: Tenho a certeza de que vais fazer bem."

    # say L1585 pla
    old "As long as you don't worry too much, you should be fine to answer everything."
    new "B:pla: Só te peço para ficares calmo enquanto respondes às perguntas."

    # say L1589 oli
    old "I'll do my best to answer everything as well as I can!"
    new "B:pla: Contanto que não te preocupes demasiado, deves estar bem para responder a tudo."

    # say L1591 oli
    old "I'm so thankful for your help!"
    new "B:oli: Vou fazer o meu melhor para responder a tudo o melhor que puder!"

    # say L1593 oli
    old "Without you, I couldn't have gone through all those topics."
    new "B:oli: Estou tão grato pela tua ajuda!"

    # say L1594 oli
    old "Really, thank you so much."
    new "B:oli: Sem ti, não teria conseguido passar por todos esses tópicos."

    # say L1596 pla
    old "It's alright, I'm glad I was able to help you."
    new "T(tu|diz): Não há de quê, fico contente por poder ajudar-te."

    # say L1598 pla
    old "And I'm sure you'll do great on the exam."
    new "B:pla: Tudo bem, fico contente por ter conseguido ajudar-te."

    # say L1600 pla
    old "So, I'll leave for now, and I'll see you later."
    new "B:pla: E tenho a certeza de que vais fazer bem no exame."

    # say L1602 oli
    old "Alright, I'll be sure to let you know how I do in the exams."
    new "B:pla: Então, vou-me embora por agora, e vejo-te mais tarde."

    # say L1630 pla
    old "Hmm, I just remembered, I need to check my exam results when I get home."
    new "B:oli: Tudo bem, vou-te dizer como correram os exames. T(pla|tu|say): Hmm, lembrei-me agora, preciso de verificar os resultados dos meus exames quando chegar a casa. A:pla: Oh! Olá Olivia."

    # say L1637 pla
    old "Oh! Hey Olivia."
    new "B:pla: Hmm, lembrei-me agora, preciso de verificar os resultados do exame quando chegar a casa."

    # say L1640 pla
    old "How did you do on the exams? Have you checked the results yet?"
    new "A:pla: Como achas que te saíste neles?"

    # say L1642 pla
    old "How do you think you did on them?"
    new "B:pla: Como foste nos exames? Já viste os resultados?"

    # say L1644 oli
    old "Well, about that, do you think you could come with me to my house?"
    new "B:pla: Como é que achas que te saíste neles?"

    # say L1645 pla
    old "Uh, s-sure. Is there anything wrong?"
    new "B:oli: Bem, a propósito, tu achas que podes vir comigo à minha casa?"

    # say L1647 oli
    old "You have no idea... But I'll tell you at my house."
    new "B:pla: Uh, c-certo. Há algo errado?"

    # say L1648 oli
    old "Come on, let's go."
    new "B:oli: Tu não fazes ideia... Mas conto-te em casa."

    # say L1673 vee
    old "Yeah, yeah, I know."
    new "B:oli: Vamos, anda."

    # say L1676 vee
    old "Oh my god, Vihaan! I said I got it!"
    new "B:vee: Sim, sim, eu sei."

    # say L1682 vee
    old "What do you mean my fault?"
    new "B:vee: Ai meu Deus, Vihaan! Eu disse que já tinha resolvido!"

    # say L1684 vee
    old "Maybe if you were here too..."
    new "T(vee|tu|dizes): Talvez se tu também estivesses aqui..."

    # say L1687 vee
    old "Yeah, I know..."
    new "T(vee|tu|diz): Sim, eu sei..."

    # say L1692 vee
    old "You know, this really isn't as bad as you're making it out to be."
    new "B:vee: Sim, eu sei..."

    # say L1693 vee
    old "Well, because this isn't the end of the world."
    new "B:vee: Sabes, isto realmente não é tão mau como estás a fazer parecer."

    # say L1697 vee
    old "She can always try again..."
    new "B:vee: Bem, porque isto não é o fim do mundo."

    # say L1698 vee
    old "Oh! I know full well what you think about that!"
    new "B:vee: Ela pode sempre tentar de novo..."

    # say L1702 vee
    old "But that's beside the point."
    new "E o que tu propões que façamos em relação ao namorado dela?"

    # say L1712 vee
    old "And what do you propose we do about her boyfriend?"
    new "E o que tu propões que façamos em relação ao namorado dela?"

    # say L1716 vee
    old "Of course it's important, Vihaan!"
    new "B:vee: E o que tu propões que façamos em relação ao namorado dela?"

    # say L1721 vee
    old "What do you mean why?"
    new "B:vee: Claro que é importante, Vihaan!"

    # say L1725 vee
    old "Because her feelings are important!"
    new "Porque os sentimentos dela são importantes!"

    # say L1729 vee
    old "I know that."
    new "Não, ele não é rico."

    # say L1734 vee
    old "No, he's not rich."
    new "B:vee: Eu sei."

    # say L1735 vee
    old "But I think that's beside the..."
    new "B:vee: Não, ele não é rico."

    # say L1739 vee
    old "Hmm, yeah that's true."
    new "B:vee: Mas acho que isso é irrelevante..."

    # say L1744 vee
    old "{b}*Sigh*{/b} Yeah, you're very right."
    new "T(vee|tu|diz): {b}*Suspiro*{/b} Sim, tens toda a razão."

    # say L1746 vee
    old "Yes, you're right."
    new "B:vee: Sim, acho que vou falar com ela."

    # say L1748 vee
    old "You should talk to her as well."
    new "B:vee: Sim, tens razão."

    # say L1749 vee
    old "Yeah, talk to you later then."
    new "B:vee: Deves falar com ela também."

    # say L1753 vee
    old "So, I guess you got what your father said in that conversation."
    new "B:vee: Pois, falamos mais tarde então."

    # say L1754 oli
    old "Yeah, I can figure."
    new "B:vee: Então, acho que percebeste o que o teu pai disse nessa conversa."

    # say L1756 aye
    old "Oh! You're in trouble!"
    new "O que se passa, mana?"

    # say L1760 aye
    old "What's the matter, sis?"
    new "B:aye: Oh! Estás em apuros!"

    # say L1761 aye
    old "Is the favorite daughter not living up to expectations?"
    new "B: aye: Qual é o problema, mana?"

    # say L1764 oli
    old "Why don't you shut your mouth before I shut it for you?"
    new "B:aye: A filha favorita não está à altura das expectativas?"

    # say L1765 vee
    old "OK! That's enough."
    new "T: OK! Chega."

    # say L1766 vee
    old "Listen, Olivia, I don't like the attitude your father's taking on this."
    new "T(vee|tu|diz): Olha, Olivia, não gosto da atitude que o teu pai está a tomar nisto."

    # say L1767 vee
    old "But you were aware of what he wanted you to do."
    new "B:vee: Olha, Olivia, não gosto da atitude que o teu pai está a tomar nisto."

    # say L1768 vee
    old "And the only way that you could stop him from sending you to India was by getting good grades."
    new "E a única maneira de tu conseguires evitar que ele te mandasse para a Índia era tirando boas notas."

    # say L1770 vee
    old "I know, I know, this isn't fair."
    new "B:vee: E a única maneira de te impedir de ir para a Índia era tirar boas notas."

    # say L1771 vee
    old "But it is the way things are."
    new "B:vee: Eu sei, eu sei, isto não é justo."

    # say L1774 aye
    old "Because you're too stupid."
    new "A:vee: O ponto é que o teu pai decidiu que não vai esperar por ti terminares o ano letivo."

    # say L1775 vee
    old "The point is that your dad decided that he's not going to wait for you to finish the school year."
    new "T: O ponto é que o teu pai decidiu que não vai esperar por ti terminares o ano letivo. A: Ele disse-me que quer que comeces a arrumar as tuas coisas."

    # say L1778 vee
    old "He told me that he wants you to start organizing your things."
    new "B:vee: O ponto é que o teu pai decidiu que não vai esperar por ti terminares o ano letivo."

    # say L1782 vee
    old "After the next batch of exams, you're transferring to a school in India."
    new "B:vee: Ele disse-me que queres começar a organizar as tuas coisas."

    # say L1785 oli
    old "But that's not fair! He doesn't get to decide that for me!"
    new "B:vee: Depois do próximo exame, vais transferir-te para uma escola na Índia."

    # say L1786 vee
    old "Well, apparently he does."
    new "B:oli: Mas isso não é justo! Ele não pode decidir isso por mim!"

    # say L1790 vee
    old "And honestly, Olivia, you should've known this was going to happen."
    new "B:vee: Bem, parece que sim."

    # say L1791 vee
    old "I'm sorry, honey, but at this point, there's not a lot more that I can do for you."
    new "B:vee: E a sério, Olivia, tu deves ter sabido que isto ia acontecer."

    # say L1792 aye
    old "It looks like you're taking a plane to our motherland, sis! Hahaha!"
    new "B:vee: Sinto muito, querida, mas neste momento não há muito mais que eu possa fazer por ti."

    # say L1797 vee
    old "You shouldn't be gloating too much, young lady."
    new "T(vee|tu|say): Não deves estar demasiado orgulhosa, jovem."

    # say L1799 vee
    old "With the way your grades are going, you'll be joining your sister."
    new "B:vee: Não deves estar demasiado orgulhosa, jovem."

    # say L1805 vee
    old "You heard me, your father wasn't only talking about Olivia."
    new "B:vee: Com a forma como as tuas notas estão, vais acabar como a tua irmã."

    # say L1806 vee
    old "And your grades aren't much better than hers."
    new "E as tuas notas não são muito melhores que as dela."

    # say L1807 aye
    old "But, I mean... Mom!"
    new "B:vee: E as tuas notas não são muito melhores que as dela."

    # say L1810 vee
    old "We'll talk about this later, I have to run some errands."
    new "B:aye: Mas, quero dizer... Mãe!"

    # say L1814 vee
    old "Listen, honey, I'm sorry about this, but I guess that's just how it is."
    new "B:vee: Falamos sobre isso mais tarde, tenho que fazer algumas compras."

    # say L1820 aye
    old "Wait, Mom, let me go with you! We still need to talk about Dad!"
    new "B:vee: Ouve, querida, sinto muito, mas acho que é assim mesmo."

    # say L1829 oli
    old "I imagine you can guess what happened..."
    new "A:pla: Acho que sim... Os exames não correram bem?"

    # say L1830 pla
    old "I think so... The exams didn't go well?"
    new "Não correram bem."

    # say L1832 oli
    old "They didn't."
    new "T(oli|tu|dizes): Não correram bem."

    # say L1833 pla
    old "But you studied so hard."
    new "B:oli: Não fizeram."

    # say L1835 oli
    old "I did, and you did a great job teaching me [pla]."
    new "T(oli|tu|dizes): Fiz isso, e tu fizeste um ótimo trabalho a ensinar-me [pla]."

    # say L1838 oli
    old "I just kept thinking about how important it was to get top marks."
    new "B:oli: Mas quando estava a fazer os exames, não conseguia concentrar-me."

    # say L1840 oli
    old "And the more I thought about it, the more scared I got."
    new "E no final, não consegui responder nada corretamente."

    # say L1842 oli
    old "In the end, I couldn't answer anything correctly."
    new "E no final, não consegui responder nada corretamente."

    # say L1844 pla
    old "I mean, I get it."
    new "T: Tu sabes, percebo. Com tanta pressão, era difícil conseguir fazer bem."

    # say L1846 pla
    old "With that much pressure, it would be hard to do well."
    new "T(pla|tu|say): Com tanta pressão, seria difícil fazer bem."

    # say L1847 pla
    old "I'm sorry, Olivia."
    new "B:pla: Com tanta pressão, seria difícil dar o melhor."

    # say L1848 oli
    old "Well, it happens. Nothing I can do about it."
    new "B:pla: Desculpa, Olivia."

    # say L1849 oli
    old "But that doesn't mean I won't deal with this."
    new "B:oli: Bem, acontece. Não posso fazer nada em relação a isso."

    # say L1850 pla
    old "Oh... Okay, what do you have in mind?"
    new "B:oli: Mas isso não significa que eu não vou lidar com isso."

    # say L1852 oli
    old "Well, this is going to surprise you."
    new "B:pla: Oh... Okay, o que tens em mente?"

    # say L1854 oli
    old "But I don't have an easy way to say this."
    new "B:oli: Bem, isto vai surpreender-te."

    # say L1858 pla
    old "W- WHAT?! What are you talking about?!"
    new "B:oli: Mas não tenho uma forma fácil de dizer isto."

    # say L1860 oli
    old "You heard me, I'm going to get pregnant."
    new "B:pla: Q- QUE?! Do que estás a falar?!"

    # say L1861 pla
    old "Yeah, that doesn't explain anything."
    new "A:pla: Desculpa, como uma gravidez de verdade?"

    # say L1863 pla
    old "I'm sorry, like an actual pregnancy?"
    new "T(pla|tu|say): Desculpa, estás a falar de uma gravidez real?"

    # say L1864 pla
    old "Or are you talking about pretending to be pregnant?"
    new "B:pla: Desculpa, uma gravidez de verdade?"

    # say L1865 oli
    old "No, I mean literally pregnant."
    new "B:pla: Ou estás a falar de fingir estar grávida?"

    # say L1866 pla
    old "W- what? B- but why?"
    new "T: O- o quê? M- mas porquê?"

    # say L1868 oli
    old "Because it's the only way to change my circumstances."
    new "T(oli|tu|dizes): Porque é a única maneira de mudar a minha situação."

    # say L1870 pla
    old "That's putting it mildly!"
    new "A:pla: É isto que queres? Ser mãe?"

    # say L1872 pla
    old "Is this what you want? To be a mother?"
    new "B:pla: Isso é dizer pouco!"

    # say L1874 oli
    old "I don't."
    new "B:pla: É isto que tu queres? Ser mãe?"

    # say L1875 oli
    old "Or at least not yet."
    new "B:oli: Não."

    # say L1884 pla
    old "And how would that work?"
    new "E como é que isso funcionaria?"

    # say L1886 oli
    old "In our culture, when a woman is arranged to marry, she's expected to be virtuous."
    new "T(oli|tu|dizes): Na nossa cultura, quando uma mulher é destinada a casar, espera-se que seja virtuosa."

    # say L1888 oli
    old "Nowadays, there's no way to ensure that the girl is a virgin."
    new "B:oli: Na nossa cultura, quando uma mulher é destinada a casar, espera-se que seja virtuosa."

    # say L1889 oli
    old "So that tends to be overlooked."
    new "B:oli: Hoje em dia, não há forma de garantir que a rapariga seja virgem."

    # say L1891 oli
    old "But a pregnancy is a very different thing."
    new "B:oli: Isso tende a ser esquecido."

    # say L1893 oli
    old "The family of the guy my dad chose for me is very illustrious and traditional."
    new "B:oli: Mas uma gravidez é uma coisa muito diferente."

    # say L1895 oli
    old "If they find out I'm pregnant, they'll cancel it immediately."
    new "B: O pai do rapaz que o meu pai escolheu para mim vem de uma família muito ilustre e tradicional."

    # say L1897 oli
    old "And better yet, once the word spreads, it'll be impossible for my father to arrange another marriage for me."
    new "B:oli: Se descobrirem que estou grávida, vão cancelar imediatamente."

    # say L1898 pla
    old "You seem very certain this will work."
    new "T(pla|tu|say): Pareces muito certo de que isto vai resultar."

    # say L1900 oli
    old "Well, because I've seen something like it."
    new "B:pla: Pareces muito certo de que isto vai funcionar."

    # say L1902 oli
    old "I have this cousin who was in a similar situation a couple of years ago."
    new "B:oli: Bem, porque já vi algo parecido."

    # say L1903 oli
    old "The difference is that she actually wanted to get married."
    new "B:oli: Tenho esta prima que estava numa situação semelhante há uns anos."

    # say L1905 oli
    old "The guy my uncle selected for her is a doctor who lives in Delhi."
    new "B:oli: A diferença é que ela realmente queria casar-se."

    # say L1906 oli
    old "So on paper, she had the perfect deal."
    new "T: O problema surgiu quando ela foi a uma festa e se envolveu com um cara."

    # say L1909 oli
    old "The problem came when she went to a party and hooked up with some guy."
    new "B:oli: No papel, ela tinha o acordo perfeito."

    # say L1910 oli
    old "That's not a big deal, but she wasn't careful and ended up getting pregnant."
    new "B:oli: O problema surgiu quando ela foi a uma festa e se envolveu com um cara."

    # say L1911 oli
    old "She tried to keep it under wraps while she dealt with it."
    new "B:oli: Não é nada de mais, mas ela não foi cuidadosa e acabou grávida."

    # say L1913 oli
    old "But that kind of thing is almost impossible to keep hidden in a place like Delhi, to be honest."
    new "B:oli: Ela tentou manter tudo em segredo enquanto lidava com isso."

    # say L1915 oli
    old "So, her marriage was canceled almost immediately, there was nothing she could do."
    new "B:oli: Mas esse tipo de coisa é quase impossível de manter em segredo num lugar como Deli, para ser sincero."

    # say L1917 oli
    old "Moreover, she hasn't been able to get a single meeting to arrange a marriage."
    new "B:oli: Portanto, o casamento dela foi cancelado quase imediatamente, não havia nada que ela pudesse fazer."

    # say L1918 oli
    old "Much less a fiancé."
    new "B:oli: Além disso, ela não conseguiu marcar nem um único encontro para arranjar um casamento."

    # say L1919 pla
    old "Wow, is it really like that?"
    new "B:oli: Muito menos um noivo."

    # say L1921 oli
    old "Of course it is."
    new "T(oli|tu|dizes): Claro que é."

    # say L1923 oli
    old "It's not good to say, but once a woman gets pregnant, she's no longer seen as virtuous."
    new "B:oli: Claro que é."

    # say L1929 pla
    old "Still, it sounds so drastic."
    new "A:pla: Não achas que há algo menos... extremo que possas fazer?"

    # say L1931 pla
    old "Don't you think there's anything less... extreme you could do?"
    new "T(pla|tu|say): Não achas que há algo menos... extremo que possas fazer?"

    # say L1932 pla
    old "How about taking other exams?"
    new "B:pla: Não achas que há algo menos... extremo que podes fazer?"

    # say L1934 oli
    old "What will that do? You already heard my mother, my dad won't even let me finish the year."
    new "B:pla: E quanto a fazer outros exames?"

    # say L1936 oli
    old "And to be honest [pla], I don't think that was ever a real option."
    new "E ser honesto [pla], eu não acho que isso fosse realmente uma opção."

    # say L1940 oli
    old "But that's not what I want for myself [pla]!"
    new "T(oli|tu|dizes): Mas isso não é o que eu quero para mim [pla]!"

    # say L1943 oli
    old "You're not your own person; everything you want to do or have has to come through your husband."
    new "B:oli: A vida num casamento arranjado é restritiva."

    # say L1944 oli
    old "Any social life you might want or access depends on him."
    new "B:oli: Não és uma pessoa independente; tudo o que queres fazer ou ter tem de passar pelo teu marido."

    # say L1946 oli
    old "In the best case, the guy will be understanding and permissive. And you can imagine how it is at the worst."
    new "B:oli: Qualquer vida social que tu queiras ou tenhas acesso depende dele."

    # say L1948 oli
    old "I don't want that for myself! Why do I have to marry some guy I don't know just so my dad can make money from it?!"
    new "B: Oli: No melhor cenário, o cara será compreensivo e permissivo. E tu podes imaginar como seria o pior cenário."

    # say L1949 oli
    old "So, if I have to get pregnant to stop myself from being married to some guy I don't know, I'll gladly do it."
    new "B:oli: Não quero isso para mim! Porque tenho de casar com um homem que nem conheço só para o meu pai ganhar dinheiro com isso?!"

    # say L1951 pla
    old "I see, but are you sure you can do this?"
    new "B:oli: Então, se tiver de engravidar para evitar casar-me com um homem que não conheço, faço-o de bom grado."

    # say L1953 pla
    old "I mean, interrupting a pregnancy's not easy."
    new "B:pla: Entendo, mas tens a certeza de que consegues fazer isto?"

    # say L1957 oli
    old "Well, abortion is legal and pretty common these days."
    new "B:pla: Quero dizer, interromper uma gravidez não é fácil."

    # say L1959 oli
    old "I know a girl who got one."
    new "B:oli: Bem, a interrupção voluntária da gravidez é legal e bastante comum nos dias de hoje."

    # say L1962 oli
    old "Yeah, she's a friend of Ruby."
    new "B:oli: Eu sei de uma rapariga que ficou grávida."

    # say L1964 oli
    old "She got pregnant from a one-night stand with her ex-boyfriend."
    new "B:oli: Sim, ela é amiga da Ruby."

    # say L1965 oli
    old "But she went to the hospital to get an abortion, and it went very well. You know?"
    new "B:oli: Ela ficou grávida de uma noite de amor com o ex-namorado."

    # say L1966 pla
    old "I see... I think I get it."
    new "B:oli: Mas ela foi ao hospital para fazer um aborto, e correu muito bem. Sabes?"

    # say L1967 oli
    old "That's right, so you see it now, it's not a bad plan."
    new "B:pla: Entendo... Acho que percebi."

    # say L1971 pla
    old "{i}(And she did tell me that I had to get as many women as I could pregnant.){/i}"
    new "B:pla: {i}(Agora que penso nisso, Brixxida mencionou que uma gravidez mágica seria mais rápida.){/i}"

    # say L1975 oli
    old "And... That's more or less where you come in."
    new "B:pla: Não, não é um mau plano."

    # say L1979 oli
    old "So I wouldn't tell you that you have to get me pregnant."
    new "B:oli: Não passei nos exames, mas tu ainda me ajudaste da melhor forma possível."

    # say L1981 oli
    old "But if I'm honest, it's hard for me to think of a better person to ask."
    new "B:oli: Então não te diria que tens de me engravidar."

    # say L1982 oli
    old "You know my situation in a way that I couldn't explain to anyone else."
    new "B:oli: Mas se for sincero, é difícil para mim pensar numa pessoa melhor para perguntar."

    # say L1984 oli
    old "And you wouldn't have to worry about it, all I need is your seed."
    new "B:oli: Tu sabes da minha situação de uma forma que não conseguiria explicar a ninguém mais."

    # say L1985 oli
    old "And I would take care of everything regarding the pregnancy and the interruption."
    new "B:oli: E tu não terias de te preocupar com isso, só preciso da tua semente."

    # say L1987 oli
    old "But I would understand if you didn't want to do it."
    new "B:oli: E eu tomaria conta de tudo relacionado com a gravidez e a interrupção."

    # say L1989 pla
    old "Actually, I was thinking that I wanted to help you with it."
    new "B:oli: Mas eu entenderia se tu não quiseres fazer."

    # say L1991 pla
    old "What you say is true. I am fully aware of your situation, both with your parents."
    new "B:pla: Na verdade, estava a pensar que queria ajudar-te com isso."

    # say L1993 pla
    old "And what you're doing to try and deal with it."
    new "B:pla: O que dizes é verdade. Estou plenamente ciente da tua situação, tanto com os teus pais."

    # say L1994 pla
    old "So I agree that I'm probably the best person to help you with this."
    new "E também sou realmente contra o que os teus pais te estão a fazer passar, sabes?"

    # say L1996 pla
    old "Also, I'm really against what your parents are putting you through, you know?"
    new "B:pla: Concordo que provavelmente sou a melhor pessoa para te ajudar com isso."

    # say L1998 pla
    old "I don't think it's fair at all that you have to live your life the way they want you to."
    new "T(pla|tu|say): Não acho justo que tenhas de viver a tua vida como eles querem."

    # say L1999 pla
    old "So I'll help you get out of it."
    new "B:pla: Não acho nada justo que tenhas de viver a tua vida como eles querem."

    # say L2003 oli
    old "OK, let's go to my room."
    new "B:pla: Então vou ajudar-te a sair disso."

    # say L2004 pla
    old "W- what? Do it now?"
    new "B:oli: OK, vamos para o meu quarto."

    # say L2005 oli
    old "Yeah, of course. I don't think there's a better time for it."
    new "B:pla: O- o quê? Agora?"

    # say L2006 oli
    old "My mom will be out with Ayesha running errands until late."
    new "B:oli: Claro, não há melhor altura para isso."

    # say L2008 oli
    old "And we don't have much time. I need to get pregnant soon."
    new "E não temos muito tempo. Preciso engravidar logo. Então devemos fazer agora."

    # say L2009 oli
    old "So we should do it now."
    new "T: Então devemos fazer agora."

    # say L2026 oli
    old "Ok, so... Uhh, let's do it..."
    new "B:oli: Então devemos fazer agora."

    # say L2027 pla
    old "Uhh... Yeah, yeah..."
    new "B:oli: Ok, então... Uhh, vamos lá..."

    # say L2028 oli
    old "Well... Uhh, where do we start? I mean, I know how to do it, but... Uhhh you get what I mean..."
    new "B:pla: Uhh... Sim, sim..."

    # say L2030 pla
    old "Uhh... Well, I think, we should... Uhh..."
    new "B:oli: Bem... Hum, por onde começamos? Quero dizer, sei como fazer, mas... Hum, percebes o que quero dizer..."

    # say L2032 oli
    old "You know what, this is silly, we don't have time for this. After all, I've already sucked your cock..."
    new "B:pla: Uhh... Bem, acho que devíamos... Uhh..."

    # say L2034 oli
    old "Alright, I'll start, after all, I'm the one who needs your help with this."
    new "A:oli: Isto sente-se bem?"

    # say L2043 oli
    old "Does this feel good?"
    new "B:oli: Tudo bem, eu começo, afinal, sou eu quem precisa da tua ajuda com isto."

    # say L2044 pla
    old "U- uh, yeah..."
    new "B:oli: Isto sente-se bem?"

    # say L2045 oli
    old "I have to say, you have a big... dick..."
    new "B:pla: H- hã, sim..."

    # say L2046 pla
    old "Uhh, thanks..."
    new "B:oli: Tenho que dizer, tu tens um pénis... grande..."

    # say L2062 pla
    old "It's alright, I'm happy to help."
    new "De qualquer forma, acho que deves ir antes de a minha mãe voltar."

    # say L2064 oli
    old "Anyway, I think you should get going before my mom gets back."
    new "B:pla: Tudo bem, estou feliz em ajudar."

    # say L2065 pla
    old "Oh! Right, sure, I'll see you later."
    new "B:oli: De qualquer forma, acho que deves ir antes que a minha mãe volte."

    # say L2068 oli
    old "And hey, thank you again."
    new "B:pla: Oh! Claro, claro, vejo-te mais tarde."

    # say L2092 pla
    old "Hey! Brixxida! I have some very good news for you!"
    new "B:oli: E olá, obrigado mais uma vez."

    # say L2095 pla
    old "Well, I made an advancement in our plans!"
    new "B:pla: Ei! Brixxida! Tenho boas notícias para ti!"

    # say L2098 pla
    old "Our plan of getting women pregnant."
    new "B:pla: Bem, fiz um avanço nos nossos planos!"

    # say L2099 pla
    old "You know, so we can use their magical power to feed the portal to the magic world."
    new "B:pla: O nosso plano de engravidar mulheres."

    # say L2101 bri
    old "Okay? How did you make this {i}'advancement?'{/i}"
    new "T(bri|tu|say): Ok? Como é que tu fizeste este {i}'avanço'?{/i}"

    # say L2105 pla
    old "As we studied, we got closer, and I got to know her."
    new "B:pla: Tenho um amigo da escola que me pediu ajuda para estudar."

    # say L2106 pla
    old "It turns out that her problems were a lot bigger than just school."
    new "B:pla: À medida que estudávamos, fomos ficando mais próximos, e eu fui conhecendo-a melhor."

    # say L2108 pla
    old "And that the only way out of them was to get pregnant."
    new "B:pla: Acontece que os problemas dela eram muito maiores do que só a escola."

    # say L2110 bri
    old "So... You're telling me that you got this woman pregnant?"
    new "T(bri|tu|say): Então... Estás a dizer que deixaste esta mulher grávida?"

    # say L2112 pla
    old "I did!"
    new "T(pla|tu|say): Eu fiz! Ou pelo menos acho que fiz, ela disse que vai fazer um teste de gravidez."

    # say L2113 pla
    old "Or at least I think I did, she told me she was going to take a pregnancy test."
    new "B:pla: Fiz!"

    # say L2117 bri
    old "You heard me!"
    new "A:bri: Tu esqueceste-te do que te disse da última vez?"

    # say L2118 bri
    old "Did you forget what I told you last time?"
    new "T(bri|tu|say): Tu esqueceste o que te disse da última vez?"

    # say L2119 pla
    old "Uhmm- We need the magic?"
    new "Não! Tu imbecil!"

    # say L2121 bri
    old "No! You idiot!"
    new "T(bri|tu|say): Não! Tu imbecil!"

    # say L2123 bri
    old "What I told you is that I had to be there when you have sex with the girl!"
    new "B:bri: Não! Tu és um idiota!"

    # say L2126 bri
    old "Ugh, try to pay attention when I speak to you."
    new "B:bri: O que te disse é que tinha de estar lá quando tu tivesses relações com a rapariga!"

    # say L2127 bri
    old "Listen, it's not just about you getting her pregnant and that's it."
    new "B:bri: Ugh, tenta prestar atenção quando eu falo contigo."

    # say L2128 bri
    old "I have to be there to perform a ritual while it's happening."
    new "B:bri: Ouve, não é só tu a deixá-la grávida e já está."

    # say L2131 bri
    old "Of course! Otherwise, it would just be a regular pregnancy."
    new "B:bri: Tenho de estar lá para realizar o ritual enquanto acontece."

    # say L2132 bri
    old "That's why it's so bad that you just went ahead and tried to get her pregnant!"
    new "T(bri|tu|say): É por isso que é tão grave que tu tenhas ido em frente e tentado engravidá-la!"

    # say L2133 bri
    old "Because if she is, then we will have lost the chance of getting a girl pregnant."
    new "B:bri: É por isso que é tão mau que tu tenhas ido em frente e tentado engravidá-la!"

    # say L2135 bri
    old "And we'll have to look for another person."
    new "T(bri|tu|say): E vamos ter de procurar outra pessoa."

    # say L2140 pla
    old "If that's true, why weren't you there when I had sex with Barbie and got her pregnant?"
    new "B:bri: E vamos ter de procurar outra pessoa."

    # say L2148 bri
    old "Exactly, and this is where I spend most of my time."
    new "T(bri|tu|say): Exatamente, e este é o lugar onde passo a maior parte do meu tempo."

    # say L2149 bri
    old "I'm either at the garage, taking care of the portal."
    new "T(bri|tu|say): Ou estou aqui a descansar."

    # say L2150 bri
    old "Or I'm here resting."
    new "B:bri: Estou ou na oficina, a tratar do portal."

    # say L2151 bri
    old "So last time, when you arrived with Barbie, I was able to initiate the spell when you two started to have sex."
    new "B:bri: Ou estou aqui a descansar."

    # say L2152 bri
    old "Otherwise it would've been wasted."
    new "B:bri: Da última vez, quando tu chegaste com a Barbie, consegui iniciar o feitiço quando vocês duas começaram a fazer sexo."

    # say L2154 bri
    old "Yeah... Luckily that time we were fine."
    new "B:bri: Caso contrário, teria sido desperdiçado."

    # say L2155 bri
    old "But I'm not omnipresent [pla]."
    new "T(bri|tu|say): Mas eu não sou onipresente [pla]."

    # say L2157 pla
    old "I- I'm sorry Brixxida, I should have talked it over with you before I had sex with her."
    new "B: Brixxida: Agora há uma hipótese de a rapariga estar grávida e podemos ter perdido a nossa próxima oportunidade."

    # say L2158 pla
    old "But I mean, there's still a chance that she's not pregnant."
    new "B:pla: I- I'm sorry Brixxida, eu devia ter falado contigo antes de ter tido sexo com ela."

    # say L2160 bri
    old "Hmph, for your sake, we better hope she isn't."
    new "A:bri: Agora, para que isto não aconteça de novo."

    # say L2162 bri
    old "Now, in order for this to not happen again."
    new "B:bri: Hmph, por tua causa, melhor será que ela não esteja."

    # say L2163 bri
    old "I think I should teach you a summoning spell."
    new "B:bri: Agora, para que isto não aconteça de novo."

    # say L2164 bri
    old "So that this doesn't happen again."
    new "B:bri: Acho que devo ensinar-te um feitiço de invocação."

    # say L2166 pla
    old "S- summoning spell?!"
    new "T(pla|tu|say): S- feitiço de invocação?!"

    # say L2167 bri
    old "Right, this isn't the most complicated spell, so you should be able to master it easily."
    new "B:pla: S- invocação?!"

    # say L2168 bri
    old "And it's good that you know it."
    new "B:bri: Certo, este não é o feitiço mais complicado, por isso deves ser capaz de o dominar facilmente."

    # say L2169 bri
    old "So that you can call on me whenever you see yourself in a situation where you think we can start the ritual with someone."
    new "E é bom que saibas disso. Assim podes chamar-me sempre que te vires numa situação em que penses que podemos começar o ritual com alguém. Entendo... E como funciona esse feitiço?"

    # say L2170 pla
    old "I see... Alright, so how does this spell work?"
    new "B:bri: Para que possas chamar-me sempre que te vires numa situação em que penses que podemos começar o ritual com alguém."

    # say L2171 bri
    old "I'll tell you, get your SexNote out."
    new "B:pla: Eu percebo... Tudo bem, então como é que este feitiço funciona?"

    # say L2175 bri
    old "Alright, I'll explain everything to you, pay attention."
    new "Tudo bem, isso deve ser suficiente por agora."

    # say L2184 bri
    old "Alright, that should be enough for now."
    new "T(bri|tu|say): Tudo bem, isso deve ser suficiente por agora."

    # say L2185 bri
    old "With that, you should be able to do the spell properly without needing any kind of help from my end."
    new "T(bri|tu|say): Com isso, tu deves ser capaz de fazer o feitiço corretamente sem precisar de qualquer tipo de ajuda da minha parte."

    # say L2187 pla
    old "I got it, I'll keep that in mind."
    new "T: Entendi, vou ter isso em mente."

    # say L2190 pla
    old "By the way, since you say it isn't a normal pregnancy."
    new "A:pla: Como é que uma gravidez mágica é diferente de uma gravidez normal?"

    # say L2192 pla
    old "How is a magical pregnancy different from a normal one?"
    new "B:pla: Por acaso, já que dizes que não é uma gravidez normal."

    # say L2195 bri
    old "Listen, in general, she'll have more or less the same experience she would if this was a normal, human pregnancy."
    new "T(bri|tu|say): Ouve, em geral, ela terá mais ou menos a mesma experiência que teria se esta fosse uma gravidez normal, humana."

    # say L2196 bri
    old "But there will be two big differences."
    new "B:bri: Ouve, em geral, ela vai ter mais ou menos a mesma experiência que teria se fosse uma gravidez humana normal."

    # say L2197 bri
    old "The first one is that it's going to be a lot faster than it would normally be."
    new "T(bri|tu|say): A primeira é que vai ser muito mais rápido do que normalmente seria."

    # say L2198 bri
    old "Since she'll be concentrating magic power within her."
    new "B:bri: O primeiro é que vai ser muito mais rápido do que normalmente seria."

    # say L2199 bri
    old "It's different from woman to woman, but it should be about a third of the time."
    new "B:bri: Como ela estará concentrando poder mágico dentro de si."

    # say L2201 bri
    old "Maybe even a fourth, who knows."
    new "B:bri: É diferente de mulher para mulher, mas deve ser cerca de um terço do tempo."

    # say L2207 pla
    old "It doesn't?"
    new "B:bri: De qualquer forma, não faz diferença para nós."

    # say L2208 pla
    old "That's good to hear."
    new "B:pla: Não?"

    # say L2210 bri
    old "Yeah, what we're doing is using the pregnancy to concentrate the magic in her body."
    new "T(bri|tu|say): Sim, o que estamos a fazer é usar a gravidez para concentrar a magia no corpo dela."

    # say L2212 bri
    old "The baby itself is not actually important to our plans."
    new "B:bri: Sim, o que estamos a fazer é concentrar a magia no corpo dela através da gravidez."

    # say L2214 bri
    old "So, when the moment comes to harvest the magic, it can be done either by the baby being born."
    new "B:bri: O bebé em si não é realmente importante para os nossos planos."

    # say L2215 bri
    old "Or by the pregnancy being interrupted."
    new "B:bri: Então, quando chegar a hora de colher a magia, pode ser feito ou com o nascimento da criança."

    # say L2217 bri
    old "It doesn't matter, as long as I can harvest the magic growing within her."
    new "T(bri|tu|say): Não importa, desde que eu possa colher a magia que está a crescer dentro dela."

    # say L2220 bri
    old "By the way, there's another small difference with a normal pregnancy you have to look out for."
    new "B:bri: Não importa, desde que eu possa colher a magia que está a crescer dentro dela."

    # say L2222 bri
    old "This pregnancy will come with the added need for magic power within her system."
    new "B:bri: Por acaso, há outra pequena diferença com uma gravidez normal de que tens de estar atenta."

    # say L2224 bri
    old "As the baby grows in her womb, she'll naturally absorb it from the environment."
    new "T(bri|tu|say): À medida que o bebé cresce no seu ventre, ela absorverá naturalmente a energia mágica do ambiente."

    # say L2225 bri
    old "But you can expect that she'll still feel the need for sex. Much like how us shinigami need it from you."
    new "T(bri|tu|say): Mas podes esperar que ela ainda sinta necessidade de sexo. Muito parecido com a forma como nós, shinigami, precisamos disso de ti."

    # say L2227 bri
    old "You'll probably have to have sex with her once in a while during her pregnancy."
    new "B:bri: Mas podes esperar que ela ainda sinta necessidade de sexo. Muito parecido com a forma como nós, shinigami, precisamos dele de ti."

    # say L2228 bri
    old "So that's a very good thing for you."
    new "B:bri: Vais ter de ter relações com ela de vez em quando durante a gravidez."

    # say L2233 pla
    old "I'll talk to her, and I'll let you know how things evolve."
    new "B:pla: Entendo, e peço desculpa por não te ter avisado antes de o fazer."

    # say L2234 bri
    old "Alright, I'll be waiting for the news."
    new "T(bri|tu|say): Tudo bem, estou à espera das notícias."

    # say L2254 pla
    old "Hey Olivia, I came to-"
    new "T(pla|tu|say): Olá Olivia, vim para-"

    # say L2256 oli
    old "I can't believe this! I just can't believe it!"
    new "B:pla: Ei Olivia, vim aqui para-"

    # say L2258 vee
    old "I'm sorry honey, but this is not my fault."
    new "E é culpa minha?"

    # say L2260 oli
    old "And is it my fault?"
    new "B:vee: Desculpa, meu amor, mas isto não é culpa minha."

    # say L2261 vee
    old "Well, who else?"
    new "B:oli: E é culpa minha?"

    # say L2262 oli
    old "Oh my God, I can't believe you're saying that!"
    new "T: Oh meu Deus, não acredito que estás a dizer isso!"

    # say L2263 oli
    old "You know what this means, right?!"
    new "B:oli: Ai meu Deus, não acredito que estás a dizer isso!"

    # say L2265 oli
    old "He already decided on the date of the marriage!"
    new "A:oli: Ele não pode fazer isso! Como é que tu vais deixá-lo decidir isso sozinho!"

    # say L2267 oli
    old "He can't do that! How can you just let him decide that by himself!"
    new "B:oli: Ele já decidiu a data do casamento!"

    # say L2269 vee
    old "This isn't my fault, Olivia!"
    new "B:oli: Ele não pode fazer isso! Como é que tu podes deixá-lo decidir isso sozinho!"

    # say L2270 vee
    old "I tried to help you, you know that."
    new "B:vee: Isto não é culpa minha, Olivia!"

    # say L2273 vee
    old "But you didn't do your part!"
    new "T(vee|tu|dizes): Mas tu não fizeste a tua parte!"

    # say L2274 vee
    old "You knew what your father's expectations were."
    new "Mas em vez de estudares para melhorar as tuas notas, decidiste perder tempo."

    # say L2277 vee
    old "But instead of studying to improve your grades, you decided to waste time."
    new "B:vee: Tu sabias quais eram as expetativas do teu pai."

    # say L2278 vee
    old "What do you expect me to do for you then?"
    new "B:vee: Mas em vez de estudar para melhorar as tuas notas, tu decidiste perder tempo."

    # say L2279 vee
    old "It was up to you, and you didn't do what you had to."
    new "B:vee: O que esperas que eu faça por ti então?"

    # say L2282 oli
    old "And that means that I have to be sent away to be married to some stranger?!"
    new "E isso significa que tenho de ser enviada para me casar com um estranho?!"

    # say L2283 oli
    old "That's my punishment for doing badly in algebra?!"
    new "B:oli: E isso significa que tenho de ser enviada para me casar com um estranho?!"

    # say L2284 oli
    old "I can't believe you, Mom! With all that you kept talking about how you don't agree with what Dad wants to do!"
    new "B:oli: Esta é a minha punição por ter ido mal em álgebra?!"

    # say L2287 vee
    old "I don't agree with it! But you know that your father's word is law!"
    new "B:oli: Não posso acreditar em ti, Mãe! Com tudo o que tu dizias sobre não concordares com o que o Pai quer fazer!"

    # say L2290 vee
    old "If you wanted to get out of it so badly, all you had to do was study."
    new "B:vee: Não concordo com isso! Mas sabes que a palavra do teu pai é lei!"

    # say L2292 vee
    old "Now it's too late to cry over spilled milk."
    new "B:vee: Se querias tanto sair disto, bastava estudares."

    # say L2294 vee
    old "You should've thought about that before wasting your time with the likes of Ruby."
    new "B:vee: Agora é tarde demais para chorar sobre o leite derramado."

    # say L2297 vee
    old "I'm sorry honey, but this is just how it is."
    new "B:vee: Deverias ter pensado nisso antes de perderes tempo com alguém como a Ruby."

    # say L2298 vee
    old "And you'll have to learn to live with it."
    new "B:vee: Desculpa, meu amor, mas é assim que as coisas são."

    # say L2299 oli
    old "Yeah... I don't think I will."
    new "B:vee: E vais ter de aprender a viver com isso."

    # say L2301 oli
    old "I don't think I'll have to learn to live with it."
    new "A:oli: Não vou fazer o que o pai quer."

    # say L2302 oli
    old "I won't do what dad wants me to."
    new "B:oli: Acho que não vou ter de me habituar a isso."

    # say L2303 vee
    old "Olivia, be reasonable, how are you planning to go against your father's wishes?"
    new "B:oli: Não vou fazer o que o pai quer."

    # say L2305 oli
    old "I don't plan on doing anything."
    new "B:vee: Olivia, sejas razoável, como vais contra os desejos do teu pai?"

    # say L2308 oli
    old "Especially because I already did it."
    new "B:oli: Não tenho planos de fazer nada."

    # say L2309 vee
    old "Okay now you're just being cryptic, what are you talking about?"
    new "B:oli: Especialmente porque eu já fiz isso."

    # say L2313 vee
    old "W- what?! P- pregnant?! What do you mean?!"
    new "T(vee|tu|diz): W- what?! P- pregnant?! What do you mean?!"

    # say L2316 vee
    old "When did this happen?!"
    new "B:vee: Q- que?! G- grávida?! O que queres dizer?!"

    # say L2318 oli
    old "Well, I only found out last week, but I wouldn't know exactly when I got pregnant."
    new "B:vee: Quando é que isto aconteceu?!"

    # say L2321 oli
    old "But that's how things are, Mom. I wanted to be sure before letting you know, but the situation calls for me to let you know."
    new "B:oli: Bem, só descobri na semana passada, mas não sei exatamente quando fiquei grávida."

    # say L2322 vee
    old "And you think this is the best moment to bring that out?!"
    new "B:oli: Mas é assim que as coisas são, mãe. Quis ter a certeza antes de te contar, mas a situação obriga-me a fazê-lo agora."

    # say L2325 vee
    old "If you already knew, you should've let us know sooner!"
    new "E tu achas que este é o melhor momento para trazer isso à tona?! Se já sabias, devias ter-nos dito antes! Tens alguma ideia do que isto significa?!"

    # say L2327 vee
    old "Do you have any idea about what this means?!"
    new "T(vee|tu|dizes): Tu sabes o que isto significa?!"

    # say L2328 vee
    old "Do you know how your dad will react?!"
    new "B:vee: Tu sabes o que isto significa?!"

    # say L2330 oli
    old "I don't know, but he won't be able to send me to India like this."
    new "T(oli|tu|dizes): Não sei, mas ele não vai poder mandar-me para a Índia assim."

    # say L2333 vee
    old "And you think things are just going to be alright?!"
    new "B:oli: Não sei, mas ele não vai conseguir mandar-me para a Índia assim."

    # say L2340 oli
    old "But you guys were pushing me so hard into it! I just didn't know how to!"
    new "B:vee: Não posso acreditar nisto de ti, Olivia! Não só ficaste grávida, como também o escondeste!"

    # say L2341 vee
    old "No! I don't want to hear anything from you!"
    new "B:oli: Mas vocês estavam a empurrar-me tanto para isso! Eu simplesmente não sabia como!"

    # say L2343 vee
    old "You have no idea about what this that you're doing means."
    new "B:vee: Não! Não quero ouvir nada de ti!"

    # say L2344 vee
    old "So I won't listen to you and I won't talk to you about it for now!"
    new "T(vee|tu|diz): Então não vou ouvir-te e não vou falar contigo sobre isso por agora!"

    # say L2345 oli
    old "What? B- but!"
    new "B:vee: Então eu não vou ouvir-te e não vou falar contigo sobre isso por agora!"

    # say L2346 oli
    old "Ughh...!"
    new "B:oli: O quê? B- mas!"

    # say L2353 pla
    old "I- Uh... E- excuse me!"
    new "O- Oh... D- Desculpa!"

    # say L2363 pla
    old "Hey."
    new "B:pla: H-Hey... D-Desculpa!"

    # say L2366 pla
    old "Sooo... I guess you're pregnant?"
    new "B:pla: Olá."

    # say L2368 oli
    old "Of course I'm not."
    new "B:pla: Sooo... Acho que estás grávida?"

    # say L2370 oli
    old "We only did it once, it can happen but we weren't lucky."
    new "B:oli: Claro que não."

    # say L2372 oli
    old "I only said that to my mom to get both her and my dad off my back."
    new "B:oli: Só fizemos uma vez, pode acontecer mas não tivemos sorte."

    # say L2373 oli
    old "But now I have to be pregnant for real!"
    new "T(oli|tu|dizer): Mas agora tenho de estar realmente grávida! E não pode demorar muito."

    # say L2375 oli
    old "And it can't take too long."
    new "B:oli: Mas agora tenho de ficar grávida de verdade!"

    # say L2376 oli
    old "Because they'll want to check soon for it."
    new "B:oli: E não pode demorar muito."

    # say L2379 pla
    old "So, s- should we do it now?"
    new "Claro que não!"

    # say L2382 oli
    old "Of course not!"
    new "B:pla: Então, n-nós devemos fazer agora?"

    # say L2384 oli
    old "My mom said she didn't want to talk to me for now."
    new "B:oli: Claro que não!"

    # say L2386 oli
    old "But be sure that she's going to barge in here any minute now."
    new "B:oli: A minha mãe disse que não quer falar comigo por agora."

    # say L2388 oli
    old "Actually, I think it would be better if you leave for now."
    new "B:oli: Mas tenha a certeza de que ela vai aparecer aqui a qualquer momento."

    # say L2390 oli
    old "Just to avoid an awkward situation."
    new "B:oli: Na verdade, acho melhor tu ires embora por agora."

    # say L2391 pla
    old "Oh yeah, sure, we can talk later."
    new "B:oli: Só para evitar uma situação embaraçosa."

    # say L2394 oli
    old "Sure, see you..."
    new "B:pla: Oh yeah, claro, podemos falar mais tarde."

    # say L2423 oli
    old "I was just thinking that I have to talk to you."
    new "A:pla: Como é que tudo ficou depois de eu sair da tua casa?"

    # say L2427 pla
    old "How did everything turn out after I left your home?"
    new "T(pla|tu|say): Como é que tudo ficou depois de eu sair da tua casa?"

    # say L2428 oli
    old "Ugh, you have no idea."
    new "T(oli|tu|dizes): Ugh, tu não fazes ideia. A minha mãe ligou ao meu pai e contou-lhe tudo."

    # say L2430 oli
    old "My mom called my dad and told him everything."
    new "A:oli: Ele ficou incrivelmente zangado e começou a gritar sobre honra e responsabilidade."

    # say L2432 oli
    old "He got incredibly angry and started screaming about honor and responsibility."
    new "B:oli: A minha mãe ligou ao meu pai e contou-lhe tudo."

    # say L2434 oli
    old "I'm glad it was only over the phone, I can't imagine what he would've done if I had been in front of him."
    new "B:oli: Ele ficou incrivelmente zangado e começou a gritar sobre honra e responsabilidade."

    # say L2435 pla
    old "It got that bad, huh?"
    new "B:oli: Fico contente por ter sido só ao telefone, não consigo imaginar o que ele teria feito se eu estivesse à frente dele."

    # say L2437 pla
    old "I guess he's that worried about you then."
    new "B:pla: Ficou assim tão mal, hã?"

    # say L2438 oli
    old "I don't think it has anything to do with me."
    new "T: Não acho que tenha nada a ver comigo."

    # say L2440 oli
    old "He's just angry about having to call off the engagement."
    new "B:oli: Não acho que tenha nada a ver comigo."

    # say L2441 pla
    old "Really?! That's what bothers him?"
    new "B:oli: Ele está apenas zangado por ter de cancelar o noivado."

    # say L2446 oli
    old "Because it's a promise of uniting families."
    new "Agora o meu pai tem de ir à casa do amigo dele e explicar-lhe por que razão eu não posso casar."

    # say L2448 oli
    old "Now my dad has to go to his friend's house and explain to him why I can't get married."
    new "B:oli: Porque é uma promessa de unir famílias."

    # say L2449 pla
    old "I see, I guess honor's very important there."
    new "É, mas se for sincera contigo, isso não tem nada a ver com isso."

    # say L2451 oli
    old "It is, but if I'm honest with you, it has nothing to do with that."
    new "T(oli|tu|dizes): É, mas se for sincero contigo, não tem nada a ver com isso. A:oli: Ele está apenas zangado por ter perdido este negócio."

    # say L2454 oli
    old "He's just angry about losing this business."
    new "B:oli: É, mas se for sincero contigo, não tem nada a ver com isso."

    # say L2456 oli
    old "Yeah, those marriages are very honorable and whatever."
    new "B:oli: Ele está apenas zangado por ter perdido este negócio."

    # say L2458 oli
    old "But what he cares about are the business opportunities he could get by marrying his daughters to rich men."
    new "B:oli: Sim, esses casamentos são muito honrados e tal."

    # say L2461 oli
    old "But it doesn't matter now."
    new "Mas uma vez que a notícia da minha gravidez começar a se espalhar, ninguém vai querer se casar comigo."

    # say L2463 oli
    old "Once the news that I'm pregnant starts spreading around, nobody will want to marry me."
    new "T(oli|tu|dizes): Assim que a notícia de que estou grávida se espalhar, ninguém vai querer se casar comigo."

    # say L2464 oli
    old "And Dad will have to leave that alone."
    new "B:oli: Assim que a notícia de que estou grávida se espalhar, ninguém vai querer se casar comigo."

    # say L2465 pla
    old "Ok, so it's all done, right?"
    new "Tudo bem, então está tudo resolvido, certo? Sim, ele tem que me deixar em paz, mas isso só significa que EU TENHO que engravidar."

    # say L2469 oli
    old "Yeah, he has to get off my back, but that only means that I HAVE to get pregnant."
    new "B:pla: Ok, então está tudo feito, certo?"

    # say L2471 oli
    old "And that's where you come in."
    new "A:oli: Queria pedir-te para ires comigo a minha casa."

    # say L2473 oli
    old "I wanted to ask you if you can come to my house with me."
    new "E é aí que tu entras."

    # say L2474 oli
    old "My mom's going to be out with my sister running some errands."
    new "B:oli: Queria perguntar-te se podes vir à minha casa comigo."

    # say L2475 oli
    old "Which means I'll have the house to myself for some hours."
    new "B:oli: A minha mãe vai sair com a minha irmã para fazer algumas compras."

    # say L2477 oli
    old "That's an opportunity that we can't let pass."
    new "B:oli: O que significa que vou ter a casa só para mim durante algumas horas."

    # say L2478 oli
    old "So, can you come with me to my house?"
    new "B:oli: É uma oportunidade que não podemos deixar passar."

    # say L2481 oli
    old "Alright! Let's not waste any time and go then."
    new "B:oli: Então, tu podes vir comigo para minha casa?"

    # say L2502 oli
    old "Alright, are you ready for it?"
    new "Bem, estás pronto para isto?"

    # say L2505 oli
    old "Ok, give me a second to freshen up, and we'll do it."
    new "B:oli: Tudo bem, estás pronta?"

    # say L2512 pla
    old "Ok, I guess now's the time to call Brixxida."
    new "B:oli: Ok, dá-me um segundo para me refrescar, e fazemos isso."

    # say L2525 bri
    old "Wow! What's this?"
    new "B:pla: Ok, acho que agora é a hora de ligar para Brixxida."

    # say L2527 pla
    old "Hey, this girl and I are about to start having sex."
    new "T: Olá, esta rapariga e eu estamos prestes a começar a fazer sexo."

    # say L2529 pla
    old "So I summoned you to make sure everything goes well."
    new "B:pla: Ei, eu e esta rapariga vamos começar a ter relações sexuais."

    # say L2530 bri
    old "I see, good, that's good."
    new "T(bri|tu|say): Entendo, bom, isso é bom."

    # say L2538 oli
    old "Hey, are you ready?"
    new "B:bri: Entendo, bom, isso é bom."

    # say L2539 pla
    old "Sure, sure, let's do it."
    new "A:oli: Ok, só lembra-te de ser suave... Ainda não estou habituado ao teu pénis grande."

    # say L2540 oli
    old "Ok, just remember to be gentle... I'm still not used to your big cock."
    new "Ok, só lembra-te de ser suave... Ainda não estou habituado ao teu pénis grande."

    # say L2541 pla
    old "Sure, of course..."
    new "Claro, claro... Tenho a certeza de que desta vez resultou."

    # say L2559 oli
    old "I'm sure that this time it worked."
    new "B:pla: Claro, claro..."

    # say L2561 pla
    old "Yeah, I'm sure it did."
    new "T: Sim, tenho a certeza que funcionou."

    # say L2562 pla
    old "At least this way you can get your family off your back a little."
    new "T(pla|tu|say): Pelo menos assim podes tirar um pouco a tua família das costas."

    # say L2565 oli
    old "Yeah, well, I wouldn't be so sure about that."
    new "B:pla: Pelo menos assim podes tirar um pouco a pressão da tua família."

    # say L2566 oli
    old "But let's see how everything goes."
    new "Mas agora, acho que tu melhor vais embora antes que a minha mãe volte e nos veja assim."

    # say L2567 oli
    old "But now, I think you better leave before my mom comes back and sees us like this."
    new "B:oli: Mas vamos ver como tudo se passa."

    # say L2568 oli
    old "That shouldn't be a problem if we're supposed to be dating."
    new "B:oli: Mas agora, acho melhor tu ires embora antes que a minha mãe volte e nos veja assim."

    # say L2569 oli
    old "But let's not push our luck."
    new "B:oli: Não deve ser um problema se estamos supostamente a namorar."

    # say L2570 pla
    old "Sure, I understand. I'll leave, but I'll check on you later to see how you're doing."
    new "B:oli: Mas não vamos exagerar."

    # say L2591 bri
    old "I'm sure that this is going to work!"
    new "Bem feito!"

    # say L2592 bri
    old "Well done!"
    new "B:bri: Tenho a certeza de que isto vai resultar!"

    # say L2593 pla
    old "Thank you, I'm glad you're satisfied with the results."
    new "Bem feito!"

    # say L2595 bri
    old "Of course I am."
    new "T(bri|tu|say): Claro que estou. E agora podemos passar para o próximo alvo!"

    # say L2596 bri
    old "And now we can move on to the next target!"
    new "T(bri|tu|say): E agora podemos passar para o próximo alvo!"

    # say L2597 pla
    old "Don't we have to make sure that everything's alright with Olivia before doing that?"
    new "B:bri: E agora podemos passar para o próximo alvo!"

    # say L2598 bri
    old "Oh don't worry, I'm sure that everything's going to be alright!"
    new "B:pla: Não temos de nos certificar de que tudo está bem com a Olivia antes de fazermos isso?"

    # say L2599 bri
    old "There's no doubt about it."
    new "T(bri|tu|say): Não tenho dúvidas disso."

    # say L2601 pla
    old "I guess I'll get to looking for new girls."
    new "B:bri: Não há dúvida."

    # say L2602 pla
    old "I'll let you know what I find."
    new "B:pla: Acho que vou começar a procurar novas raparigas."

    # say L2604 bri
    old "Great! I'll be waiting."
    new "B:pla: Vou-te dizer o que encontrar."

    # say L2628 oli
    old "I'm doing fine."
    new "B:pla: Olá Olivia, como estás?"

    # say L2629 oli
    old "Although I have to say it's been difficult to deal with my family these last few days."
    new "B:oli: Estou bem."

    # say L2630 pla
    old "It has?"
    new "Sim, fiz um teste de gravidez."

    # say L2632 oli
    old "Yeah, I got a pregnancy test done."
    new "T(oli|tu|dizes): Sim, fiz um teste de gravidez."

    # say L2633 oli
    old "My dad and mom wanted to make sure that I actually was pregnant and I wasn't just lying to get out of the marriage."
    new "Sim, o meu pai e a minha mãe queriam ter a certeza de que eu estava realmente grávida e não estava a mentir para fugir do casamento. Então, levaram-me a uma obstetra e pediram-lhe para fazer o teste."

    # say L2634 oli
    old "So, they took me to an ob-gyn and asked them to do the test."
    new "T(oli|tu|dizes): Então, eles levaram-me a uma ginecologista e pediram-lhe para fazer o teste."

    # say L2635 pla
    old "And? What did it say?"
    new "B:oli: Então, levaram-me a uma ginecologista e pediram-lhe para fazer o teste."

    # say L2637 oli
    old "It came out positive!"
    new "B:pla: E? O que disse?"

    # say L2638 oli
    old "It's good that I got pregnant when I did, because otherwise who knows what would've happened."
    new "B:oli: Deu positivo!"

    # say L2639 oli
    old "I would probably be on a plane on my way to India right now."
    new "B:oli: É bom que fiquei grávida quando fiquei, porque senão quem sabe o que poderia ter acontecido."

    # say L2640 pla
    old "Well, I guess it's a good thing that you're pregnant then."
    new "B:oli: Provavelmente estaria num avião a caminho da Índia neste momento."

    # say L2641 pla
    old "Does that mean that your parents are going to back off now?"
    new "B:pla: Bem, acho que é bom que tu estejas grávida então."

    # say L2642 oli
    old "Well, not really, if anything I think they'll just get even more intense."
    new "B:pla: Isso significa que os teus pais vão recuar agora?"

    # say L2644 oli
    old "My dad's incredibly furious right now."
    new "Tu deves ter visto como ele estava, a falar sobre como o seu bom nome está a ser arrastado pela lama."

    # say L2645 oli
    old "You should've seen him, talking about how his good name is being dragged through the mud."
    new "T: Deverias ter visto, ele estava a falar de como o seu bom nome está a ser arrastado pela lama. A: Também me disseram para te avisar que deves preparar-te para um casamento."

    # say L2646 oli
    old "They also told me to let you know that you should get ready for a marriage."
    new "B:oli: Devias ter visto, a falar de como o bom nome dele está a ser arrastado pela lama."

    # say L2647 oli
    old "Because there's no way that I'm having a bastard child."
    new "B:oli: Também me disseram para te avisar que deves preparar-te para um casamento."

    # say L2649 pla
    old "W- what? M- marriage?"
    new "B:oli: Porque não há maneira de eu ter um filho bastardo."

    # say L2650 pla
    old "B- but I thought you said that wasn't going to happen."
    new "B: B- mas eu pensei que tu tinhas dito que isso não ia acontecer."

    # say L2652 oli
    old "And it probably won't, because I won't let it come to that."
    new "B: B- mas eu pensei que tu tinhas dito que isso não ia acontecer."

    # say L2654 oli
    old "Besides, remember that the plan is to interrupt the pregnancy before it gets to term."
    new "B:oli: E provavelmente não vai acontecer, porque não vou deixar chegar a esse ponto."

    # say L2656 oli
    old "So there is some pressure because of it."
    new "B:oli: Além disso, lembra que o plano é interromper a gravidez antes que ela chegue ao fim."

    # say L2658 oli
    old "But I don't think my mom's going to consult you about wedding plans anytime soon."
    new "B:oli: Então há alguma pressão por causa disso."

    # say L2659 pla
    old "I see... I guess that's a little reassuring."
    new "B:oli: Mas não acho que a minha mãe vá consultar-te sobre os planos do casamento tão cedo."

    # say L2660 oli
    old "But anyway, that's not what's most important."
    new "B:pla: Eu vejo... Acho que isso é um pouco reconfortante."

    # say L2665 oli
    old "What's most important is what I'm going to do next after this pregnancy."
    new "O que é mais importante é o que vou fazer a seguir depois desta gravidez."

    # say L2667 pla
    old "Are you planning something else?"
    new "B:oli: O mais importante é o que vou fazer a seguir depois desta gravidez."

    # say L2668 oli
    old "Of course, my plan is not to be a young mom."
    new "B:pla: Tens algo mais planeado?"

    # say L2670 oli
    old "And I didn't get pregnant just to get out of an arranged marriage."
    new "B:oli: Claro, não tenho planos de ser mãe nova."

    # say L2671 oli
    old "This whole situation is just to buy some time for me to start doing some things that I want to do."
    new "B:oli: E não fiquei grávida só para fugir de um casamento arranjado."

    # say L2673 oli
    old "I decided that I want to get into college."
    new "B:oli: Esta situação toda é só para ganhar tempo para eu começar a fazer coisas que quero fazer."

    # say L2675 oli
    old "I need to get on my mother's good side, and to establish a future for myself."
    new "B:oli: Decidi que quero entrar na universidade."

    # say L2677 pla
    old "That sounds great Olivia, it sounds like a great plan."
    new "T: Isso soa ótimo, Olivia, parece um bom plano."

    # say L2679 oli
    old "Yeah, but listen..."
    new "T(oli|tu|diz): Sim, mas ouve... Não sei bem como te pedir isto."

    # say L2681 oli
    old "I don't really know how to ask you this."
    new "T(oli|tu|dizer): Não sei bem como te perguntar isto."

    # say L2683 oli
    old "But I was wondering if you could help me study for the college entrance exams."
    new "B:oli: Não sei bem como te perguntar isto."

    # say L2685 oli
    old "I know that I've already asked way too much of you, more than what would be reasonable."
    new "B:oli: Mas estava a pensar se tu poderias ajudar-me a estudar para os exames de entrada na universidade."

    # say L2687 oli
    old "But the truth is that you're a very good teacher, and I think that to get into college I will really need your help."
    new "T: Mas a verdade é que tu és um professor muito bom, e acho que para entrar na universidade vou mesmo precisar da tua ajuda."

    # say L2689 oli
    old "I would understand it if you don't want to do it."
    new "B:oli: Mas a verdade é que tu és uma professora muito boa, e acho que para entrar na universidade vou mesmo precisar da tua ajuda."

    # say L2690 oli
    old "But if you will, that would be the greatest thing."
    new "B:oli: Eu entenderia se tu não quiseres fazer."

    # say L2692 pla
    old "Oh yeah for sure, I'll help you."
    new "B:oli: Mas se tu quiseres, isso seria ótimo."

    # say L2693 pla
    old "Of course, I don't have a problem with doing that."
    new "B:pla: Claro, vou ajudar-te."

    # say L2694 pla
    old "And I think you need it, that would help you to get out from under your parents."
    new "E eu acho que precisas disso, isso ajudar-te-ia a sair da dependência dos teus pais. Vou estar mais do que feliz em te ajudar a estudar."

    # say L2695 pla
    old "So I'll be more than happy to help you study."
    new "B:pla: E acho que precisas disso, isso ajudaria a saíres da influência dos teus pais."

    # say L2700 pla
    old "Hmm, so I guess we should get going to your house then?"
    new "B:pla: Fico contente por poder ajudar-te."

    # say L2701 oli
    old "No, I don't think right now would be a good idea."
    new "B:pla: Hmm, então acho que devíamos ir para tua casa, então?"

    # say L2703 oli
    old "I have to gather some more information about college admission exams and such."
    new "B:oli: Não, acho que agora não é uma boa altura."

    # say L2704 oli
    old "But as soon as I have it I'll let you know."
    new "B:oli: Tenho de recolher mais informações sobre os exames de admissão à universidade e afins."

    # say L2706 pla
    old "Alright, I'll be waiting."
    new "B:oli: Mas assim que tiver notícias aviso-te."

    # say L2707 pla
    old "I guess I'll see you later."
    new "Olá, Olivia."

    # say L2725 pla
    old "Hey Olivia."
    new "B:pla: Acho que nos vemos mais tarde."

    # say L2727 pla
    old "I'm alright, and you?"
    new "Estou bem, na verdade fico contente por te apanhar aqui."

    # say L2729 oli
    old "I'm doing well, actually I'm glad that I caught you here."
    new "B:pla: Estou bem, e tu?"

    # say L2730 oli
    old "I got to checking the information that I told you about."
    new "B:oli: Estou bem, na verdade fico contente por te encontrar aqui."

    # say L2731 oli
    old "So I was wondering if you could come with me to my house so that we can start studying today."
    new "B:oli: Fui ver as informações de que te falei."

    # say L2733 pla
    old "Sure, I'll gladly come with you to study."
    new "B:oli: Então estava a pensar se tu podias vir comigo a minha casa para começarmos a estudar hoje."

    # say L2734 oli
    old "Great! Let's go then."
    new "Ótimo! Vamos então."

    # say L2748 oli
    old "Alright, I think we should get to it, right?"
    new "Bem, então vamos. T(oli|tu|diz): Certo, acho que devemos começar, certo? A:pla: Certo, então, o que vamos estudar?"

    # say L2759 pla
    old "Alright, so what are we going to study?"
    new "T(pla|tu|say): Tudo bem, então o que vamos estudar?"

    # say L2761 oli
    old "We're going to be covering the entrance exam for the design school."
    new "B:pla: Tudo bem, então o que vamos estudar?"

    # say L2762 oli
    old "It came to my mind that maybe there could be a couple of previous exams online that I could use to study."
    new "T(oli|tu|dizes): Achei que podia haver uns exames anteriores online que eu podia usar para estudar."

    # say L2764 pla
    old "Hmm, so you want to study design..."
    new "B:oli: Achei que podia haver alguns exames anteriores online que eu poderia usar para estudar."

    # say L2765 pla
    old "I mean, do you think I would be the best person to help you with it?"
    new "B:pla: Hmm, então queres estudar design..."

    # say L2767 pla
    old "I don't know anything about the subject, to be honest."
    new "T(pla|tu|say): Não sei nada sobre o assunto, para ser sincero."

    # say L2768 oli
    old "That's alright, you don't actually have to know."
    new "B:pla: Não sei nada sobre o assunto, para ser sincero."

    # say L2769 oli
    old "The college I'm applying to has a fundamental curriculum that every student must complete."
    new "T(oli|tu|dizes): A universidade para a qual estou a candidatar-me tem um currículo fundamental que todos os estudantes devem completar."

    # say L2771 oli
    old "And it's very heavy on chemistry, math, and sciences."
    new "B:oli: A faculdade para a qual estou a candidatar-me tem um currículo fundamental que todos os estudantes devem completar."

    # say L2772 oli
    old "So it's alright if that's what we study. Because those topics are going to be the focus of the admission exam."
    new "B:oli: E tem muita química, matemática e ciências."

    # say L2774 pla
    old "Oh, I see, alright, let's get to it then."
    new "B:oli: Então está bem se é isso que vamos estudar. Porque esses tópicos vão ser o foco do exame de admissão."

    # say L2785 pla
    old "Uhmm, not much, it's just that you're taking very well to this."
    new "B:pla: Oh, percebo, então vamos lá."

    # say L2786 pla
    old "But before, you were struggling so much to learn the school topics."
    new "B:pla: Hmm, não é nada, é só que estás a adaptar-te muito bem a isto."

    # say L2788 oli
    old "Well, as I told you before, I'm not dumb."
    new "B:pla: Mas antes, tu estavas a lutar tanto para aprender os temas da escola."

    # say L2789 oli
    old "It's just that the school topics are so much more boring to me."
    new "B:oli: Bem, como te disse antes, não sou burro."

    # say L2790 oli
    old "They're not interesting in any way."
    new "Não me interessam de maneira nenhuma."

    # say L2791 oli
    old "I mean, these are most of the same topics."
    new "B:oli: Não são interessantes de maneira nenhuma."

    # say L2793 oli
    old "But I'm studying them to get into college and do something that I actually want to do."
    new "T: Mas estou a estudá-los para entrar na universidade e fazer algo que realmente queira fazer."

    # say L2796 oli
    old "It also has to do with the fact that I kinda know I have to push myself through this."
    new "B:oli: Mas estou a estudá-los para entrar na universidade e fazer algo que realmente queira fazer."

    # say L2797 oli
    old "With how far I've come already, it would be a real shame if I gave up now."
    new "B:oli: Também tem a ver com o facto de eu saber que tenho de me esforçar para passar por isto."

    # say L2799 pla
    old "I see, that actually makes a lot of sense."
    new "B:oli: Com o que já conseguimos, seria uma pena desistir agora."

    # say L2800 oli
    old "Come on, let's keep going."
    new "B:pla: Entendo, isso faz bastante sentido."

    # say L2808 pla
    old "Alright, I think that should be enough for today."
    new "Bem, acho que já chega por hoje."

    # say L2810 oli
    old "Really? Already?"
    new "B:pla: Tudo bem, acho que já chega por hoje."

    # say L2812 pla
    old "Yeah sure, this was just an introductory session."
    new "T:pla|tu|diz: Claro, isto foi apenas uma sessão de introdução."

    # say L2813 pla
    old "So we should stop before we get too tired."
    new "B:pla: Claro, isto foi apenas uma sessão de introdução."

    # say L2814 oli
    old "Hmm, yeah I guess you're right."
    new "B:pla: Então devemos parar antes de ficarmos muito cansados."

    # say L2823 pla
    old "Alright, that was very good."
    new "B:oli: Hmm, sim, acho que tens razão."

    # say L2824 pla
    old "If we keep going like that, I'm sure you'll ace that entrance exam."
    new "B:pla: Ótimo, isso foi muito bom."

    # say L2826 oli
    old "For everything, you know?"
    new "B:pla: Se continuarmos assim, tenho a certeza que vais passar no exame de entrada."

    # say L2827 oli
    old "I have been coming up with these crazy plans, and you've kept supporting me."
    new "T: Tu tens estado a apoiar-me com todos os planos malucos que tenho vindo a criar. A: Muito obrigado."

    # say L2828 oli
    old "Thanks a lot."
    new "A:pla: Então, acho que devo ir embora, mas vou voltar logo para continuarmos a estudar."

    # say L2830 pla
    old "So, I guess I should get going, but I'll come back soon so that we can keep studying."
    new "T: E claro, para ver como está a gravidez."

    # say L2831 pla
    old "And of course, to check on the pregnancy."
    new "B:pla: Então, acho que devo ir, mas voltarei em breve para continuarmos a estudar."

    # say L2850 oli
    old "Hey [pla]! Did you come to study again?"
    new "B:oli: Com certeza [pla], muito obrigado."

    # say L2852 oli
    old "Great, let's get to it then."
    new "A:pla: Tudo bem, onde paramos da última vez?"

    # say L2853 pla
    old "Alright, where did we leave off last time?"
    new "Bem, então vamos a isso. Tu: Certo, onde paramos da última vez? A: Acho que foi neste tópico..."

    # say L2854 oli
    old "I think it was this topic here..."
    new "B:pla: Tudo bem, onde paramos da última vez?"

    # say L2856 pla
    old "Oh yeah! For sure!"
    new "B:oli: Acho que foi este tópico aqui..."

    # say L2858 pla
    old "Alright, let's continue from there then."
    new "Bem, isso foi uma boa sessão."

    # say L2895 pla
    old "Alright, that was a good session."
    new "B:pla: Então, vamos continuar daí."

    # say L2896 pla
    old "Just a couple more and I know you'll have what it takes to ace those exams."
    new "B:pla: Tudo bem, foi uma boa sessão."

    # say L2901 pla
    old "Hey, my pleasure."
    new "A:pla: Tenho de ir embora por agora, mas voltarei para te ver em breve, está bem?"

    # say L2902 pla
    old "I have to leave for now, but I'll come back to see you soon, alright?"
    new "T(pla|tu|say): Tenho de ir embora por agora, mas voltarei para te ver em breve, está bem?"

    # say L2903 oli
    old "Sure, no problem, see you."
    new "B:pla: Tenho de ir agora, mas volto para te ver em breve, está bem?"

    # say L2944 pla
    old "Hi Mrs. Priya, how are you?"
    new "Olá Sra. Priya, como estás?"

    # say L2946 vee
    old "Are you here looking for Olivia?"
    new "B:pla: Olá Sra. Priya, como está?"

    # say L2947 pla
    old "Uhh, yeah, I was kinda hoping to catch her here."
    new "B:vee: Estás aqui à procura da Olivia?"

    # say L2948 vee
    old "Well, no, she's at school."
    new "B:pla: Uhh, yeah, eu estava a esperar encontrá-la aqui."

    # say L2949 vee
    old "And you should be there too, you know?"
    new "B:vee: Bem, não, ela está na escola."

    # say L2950 pla
    old "Uh, yeah, yeah, you're probably right."
    new "T: Uh, yeah, yeah, tu provavelmente tens razão."

    # say L2951 pla
    old "I'll come by later then."
    new "B:pla: Uh, yeah, yeah, tu tens razão."

    # say L2953 vee
    old "Sure, I'll let her know you stopped by."
    new "B:pla: Passo mais tarde então."

    # say L2960 pla
    old "I'm alright, thank you."
    new "Estou bem, obrigado."

    # say L2962 vee
    old "That's good to hear..."
    new "T(vee|tu|diz): É bom saber..."

    # say L2964 vee
    old "So tell me, did you come looking for Olivia?"
    new "B:vee: Que bom ouvir isso..."

    # say L2966 pla
    old "That's right. Is she here?"
    new "B:vee: Então, me conta, vieste procurar a Olivia?"

    # say L2968 vee
    old "Great... Yes, she's in her room."
    new "B:pla: É isso mesmo. Ela está aqui?"

    # say L2970 vee
    old "You can go in, go ahead, don't mind me."
    new "B:vee: Ótimo... Sim, ela está no quarto."

    # say L2971 pla
    old "Uh... S- sure, thank you."
    new "B:vee: Podes entrar, vai em frente, não te preocupes comigo."

    # say L2973 pla
    old "I guess I'll see you around, Mrs. Priya."
    new "B:pla: Uh... C-certo, obrigado."

    # say L2985 oli
    old "Ok, that sounds good."
    new "A:vee: Olivia, estás aí? Estou a entrar!"

    # say L2988 vee
    old "Olivia, are you there? I'm coming in!"
    new "B:oli: Ok, isso soa bem."

    # say L3002 oli
    old "We were just studying, Mom, nothing else."
    new "B:pla: H- olá, Sra. Priya."

    # say L3004 vee
    old "Yeah well, I hope it's going better than last time you two studied."
    new "B:oli: Estavamos só a estudar, mãe, nada mais."

    # say L3007 oli
    old "Anyway, what do you want?"
    new "B:vee: Pois, espero que esteja a correr melhor do que da última vez que vocês estudaram."

    # say L3009 vee
    old "What do you mean by that? Did you forget that we have a phone call with your father to talk about your pregnancy?"
    new "B:oli: Então, o que queres?"

    # say L3012 vee
    old "And before you ask, no, we cannot reschedule, you know how Vihaan is about his time."
    new "B:vee: O que queres dizer com isso? Esqueceste-te que temos uma chamada com o teu pai para falar da tua gravidez?"

    # say L3020 oli
    old "This isn't going to take too much time. And we have a lot more to cover in today's session."
    new "B:oli: Mas por favor, não vais embora."

    # say L3022 oli
    old "So, I'll talk to my dad, and I'll come back so that we can keep studying."
    new "B:oli: Isto não vai demorar muito tempo. E temos muito mais para abordar na sessão de hoje."

    # say L3023 pla
    old "Oh, a- alright, sure, no problem."
    new "B:oli: Então, vou falar com o meu pai e volto para continuarmos a estudar."

    # say L3025 vee
    old "Come on, we have to go call him now."
    new "B:pla: Oh, a- alright, sure, no problem."

    # say L3029 oli
    old "Alright, alright, let's go."
    new "B:vee: Vamos, temos de o chamar agora."

    # say L3041 pla
    old "Hmm, I mean, I guess I'll just sit here and wait for her to come back."
    new "Olá, cunhado! Como estás?"

    # say L3049 aye
    old "Hey brother-in-law! How are you?"
    new "B:pla: Hmm, quer dizer, acho que vou ficar aqui à espera dela."

    # say L3050 pla
    old "Uhmm, hi... I'm doing fine."
    new "Mas o que estás a fazer aqui sozinho?"

    # say L3059 aye
    old "But what are you doing here all alone?"
    new "B:pla: Hmm, olá... Estou bem."

    # say L3061 pla
    old "Oh, I was helping your sister study."
    new "B:aye: Mas o que estás a fazer aqui sozinho?"

    # say L3063 pla
    old "And you know, spending time with her and checking that the pregnancy is going well."
    new "B:pla: Estava a ajudar a tua irmã a estudar."

    # say L3065 pla
    old "But she had to step out with your mom for a call they had scheduled with your dad."
    new "B:pla: E sabes, passar tempo com ela e garantir que a gravidez está a correr bem."

    # say L3066 pla
    old "So I'm just waiting here for her to come back."
    new "T(pla|tu|say): Então estou só à espera que ela volte."

    # say L3068 aye
    old "I see, hmm, that's interesting, I guess."
    new "A:aye: Gostas de passar tempo com ela?"

    # say L3070 aye
    old "Do you like spending time with her?"
    new "T: Tu gostas de passar tempo com ela?"

    # say L3071 pla
    old "Uh, I mean, y- yeah sure."
    new "B:aye: Gostas de passar tempo com ela?"

    # say L3072 aye
    old "I see, I see."
    new "E tu gostas de o fazer mesmo que ela seja apenas uma vaca gorda?"

    # say L3074 aye
    old "And you like to do it even though she's just a fat cow?"
    new "E tu gostas de o fazer mesmo sabendo que ela é apenas uma vaca gorda?"

    # say L3075 pla
    old "W- what? What are you talking about?"
    new "T: W- o quê? Do que estás a falar?"

    # say L3077 aye
    old "Nothing much, I was just wondering if you still like to spend time with her."
    new "T: Não muito, só estava a pensar se tu ainda gostas de passar tempo com ela. A: Porque ela já não é tão bonita como era antes."

    # say L3078 aye
    old "Because she no longer looks as beautiful as she did before."
    new "B:aye: Não muito, só estava a pensar se tu ainda gostas de passar tempo com ela."

    # say L3080 aye
    old "You know, she's been getting fatter and fatter."
    new "B:aye: Porque ela já não é tão bonita como era antes."

    # say L3082 aye
    old "I can't imagine that's attractive in any way."
    new "B:aye: Sabes, ela tem engordado cada vez mais."

    # say L3084 pla
    old "Uhmm, to be honest with you that's not even something I had considered."
    new "T: Hummm, para ser sincero contigo, isso nem sequer era algo que eu tinha considerado."

    # say L3086 pla
    old "I mean, she just looks a little bit bigger because of the pregnancy."
    new "B:pla: Hmm, a ser sincero contigo, isso nem era algo que eu tinha considerado."

    # say L3088 pla
    old "But that's completely normal, right?"
    new "A:aye: Sim, sim, como eu estava a dizer, ela é uma vaca gorda."

    # say L3090 aye
    old "Yeah, yeah, as I was saying, she's a fat cow."
    new "B:pla: Mas isso é completamente normal, certo?"

    # say L3092 aye
    old "But anyway, that's not important right now."
    new "B:aye: Pois, pois, como eu estava a dizer, ela é uma vaca gorda."

    # say L3093 aye
    old "You know? I've been thinking a lot about you recently."
    new "T: Sabes? Tenho pensado muito em ti recentemente."

    # say L3094 pla
    old "Y- you have? H- how come?"
    new "T(pla|tu|say): T- tu tens? P- porquê?"

    # say L3095 aye
    old "I just think it's very unfortunate that you had to fall in love with the worst part of our family."
    new "T: Aye, tu sabes, a minha irmã é bonita."

    # say L3097 aye
    old "I mean sure, my sister's pretty."
    new "B:aye: Acho que é muito infeliz que tu tenhas caído apaixonado pela pior parte da nossa família."

    # say L3099 aye
    old "But you know that she doesn't care about you, not really, right?"
    new "B:aye: Quero dizer, a minha irmã é bonita."

    # say L3101 aye
    old "She's just using you to get out of going to India."
    new "B:aye: Mas tu sabes que ela não se importa contigo, verdadeiramente, certo?"

    # say L3102 aye
    old "I'm sorry it has to be like that."
    new "Desculpa, mas tem que ser assim."

    # say L3103 pla
    old "Uh- I uh-"
    new "B: Aye: Sinto muito que tenha de ser assim."

    # say L3104 pla
    old "I'm not sure I know what you're talking about..."
    new "B:pla: Uh- eu uh-"

    # say L3106 aye
    old "Yeah right, of course you don't!"
    new "B:pla: Não tenho a certeza de que estás a falar..."

    # say L3107 aye
    old "But anyway, it's a shame that she's not only using you, but that you also have to have sex with her."
    new "B:aye: Claro, como não!"

    # say L3108 aye
    old "With how bad she is, it surprises me that you're that much into her."
    new "B:aye: Mas enfim, é uma pena que ela não só esteja a usar-te, mas também tenhas de ter sexo com ela."

    # say L3109 pla
    old "Uh... W- what do you mean?"
    new "B:aye: Com o quanto ela é má, surpreende-me que tu estejas tanto interessado nela."

    # say L3113 aye
    old "It only took me the other day to be sure that she's not any good with sex stuff."
    new "B:aye: Sabes que a minha irmã não é nada de especial na cama."

    # say L3115 aye
    old "She was sucking your dick without any interest in doing it."
    new "B:aye: Só me dei conta no outro dia de que ela não é boa nisso."

    # say L3116 aye
    old "Which is a shame because that big dick of yours deserves better."
    new "B:aye: Ela estava a chupar o teu pénis sem qualquer interesse em fazê-lo."

    # say L3123 aye
    old "I mean, it's such an amazing dick. So big and so thick."
    new "B:aye: É uma pena, porque aquele pénis enorme merece melhor."

    # say L3125 aye
    old "My sister's just wasting it with that sloppy technique of hers."
    new "E na cama..."

    # say L3126 aye
    old "And in bed..."
    new "B:aye: A minha irmã está só a desperdiçá-lo com essa técnica desleixada dela."

    # say L3128 aye
    old "I bet she's just a dead fish, she probably isn't anything special there."
    new "B:aye: E na cama..."

    # say L3134 aye
    old "I was thinking that it would do you well to have a small tasting of what you've been missing..."
    new "T: Acho que te faria bem experimentar um pouco do que tens estado a perder..."

    # say L3135 pla
    old "Uh, I uh..."
    new "B: Aye: Estava a pensar que te faria bem ter um pequeno gosto do que tens estado a perder..."

    # say L3136 pla
    old "I- think you shouldn't be here..."
    new "B:pla: Uh, eu uh..."

    # say L3137 pla
    old "Y- your sister could think the wrong thing."
    new "T(pla|tu|say): Y- a tua irmã poderia pensar mal."

    # say L3139 aye
    old "And what would that be?"
    new "B:pla: Y- a tua irmã poderia pensar mal."

    # say L3145 pla
    old "Y- you know... L- like."
    new "B:aye: E o que seria isso?"

    # say L3146 aye
    old "Come on brother-in-law, I know you'll love it."
    new "B:pla: S- sabes... G- gosto."

    # say L3156 pla
    old "W- what are you doing?!!"
    new "B:aye: Vamos, cunhado, sei que vais adorar."

    # say L3157 aye
    old "Come on! I know you'll love this!"
    new "B:pla: O- o que estás a fazer?!!"

    # say L3158 pla
    old "W- what if your sister or your mom comes in here?!"
    new "B:aye: Vamos! Eu sei que vais adorar isto!"

    # say L3159 aye
    old "Ugh, relax, nothing will happen!"
    new "B:pla: E-e se a tua irmã ou a tua mãe entrarem aqui?!"

    # say L3170 aye
    old "I'm sure you've never had anything like it."
    new "B:aye: Ugh, relaxa, nada vai acontecer!"

    # say L3172 aye
    old "Now you can see what you're missing by doing it with my sister."
    new "B:aye: Tenho a certeza de que nunca tiveste nada parecido."

    # say L3173 aye
    old "It's a shame that you have to endure something like that."
    new "B:aye: Agora podes ver o que estás a perder ao fazê-lo com a minha irmã."

    # say L3175 aye
    old "But you never know, maybe you and I can have another one of these sessions sometime."
    new "B:aye: É uma pena que tenhas de suportar algo assim."

    # say L3176 aye
    old "Or maybe we could do something else."
    new "B:aye: Mas nunca se sabe, talvez tu e eu possamos ter outra sessão destas algum dia."

    # say L3177 pla
    old "Yeah... That's great."
    new "T: Sim... Isso é ótimo."

    # say L3179 pla
    old "But it might be better if you leave for now, you know?"
    new "B:pla: Sim... Isso é ótimo."

    # say L3180 aye
    old "Sure, I guess I will."
    new "B:pla: Mas talvez seja melhor tu ires embora por agora, sabes?"

    # say L3181 aye
    old "But I'll be seeing you later."
    new "B:aye: Claro, acho que sim."

    # say L3188 pla
    old "God... She is something else."
    new "B:aye: Mas vou ver-te mais tarde."

    # say L3189 pla
    old "Is everyone in this family so brazen?"
    new "B:pla: Deus... Ela é algo de outro mundo."

    # say L3190 pla
    old "I'm just glad nobody saw us."
    new "B:pla: Esta família toda é assim tão desinibida?"

    # say L3203 oli
    old "Hey [pla], I'm sorry I kept you waiting for so long."
    new "T(oli|tu|dizer): Olá [pla], desculpa por te ter feito esperar tanto tempo."

    # say L3206 pla
    old "I imagine you had a lot to talk with your dad, didn't you?"
    new "B:pla: Hey, está tudo bem, não há problema."

    # say L3208 oli
    old "Oh yeah, a lot, he just kept going and going."
    new "B:pla: Imagino que tiveste muito para falar com o teu pai, não é?"

    # say L3210 pla
    old "I understand. Are you ready to get back to studying?"
    new "T: Entendo. Estás pronto para voltar a estudar?"

    # say L3212 oli
    old "You know what? I think we should stop for the day."
    new "T(oli|tu|dizes): Sabes o quê? Acho que devíamos parar por hoje."

    # say L3213 oli
    old "I just had a very bad conversation with my Dad and mom and I don't feel like studying at the moment."
    new "B:oli: Sabes o que? Acho que devíamos parar por hoje."

    # say L3214 oli
    old "I think I just want to rest a little bit."
    new "B:oli: Acabei de ter uma conversa muito má com o meu pai e a minha mãe e neste momento não me apetece estudar."

    # say L3215 pla
    old "Oh! Sure, sure, no problem."
    new "A:pla: Olá Oli, como estás?"

    # say L3248 pla
    old "Hey Oli, how are you?"
    new "B:pla: Oh! Claro, claro, sem problemas."

    # say L3250 oli
    old "Hey [pla], how are you doing right now?"
    new "T(oli|tu|dizer): Olá [pla], como estás agora?"

    # say L3253 oli
    old "You know? I don't think I am."
    new "B:pla: Estou bem, vim para continuarmos a estudar. Tu estás pronto?"

    # say L3254 oli
    old "I've been feeling really bad all day."
    new "T(oli|tu|dizes): Tenho-me sentido realmente mal o dia todo."

    # say L3255 oli
    old "You know, things from the pregnancy."
    new "B:oli: Tenho-me sentido realmente mal o dia todo."

    # say L3256 oli
    old "So I think I'll just lay down for a while."
    new "B:oli: Sabes, coisas relacionadas com a gravidez."

    # say L3257 oli
    old "I'm sorry that you came all the way here for nothing."
    new "B:oli: Acho que vou deitar um pouco."

    # say L3259 pla
    old "It's alright, I understand."
    new "T(pla|tu|say): Tudo bem, eu entendo."

    # say L3260 pla
    old "You're pregnant, it's only natural that the body would feel that way."
    new "B:pla: Tudo bem, eu entendo."

    # say L3261 pla
    old "The best thing would be for you to rest, and we can see each other later."
    new "B:pla: Estás grávida, é natural que o corpo se sinta assim."

    # say L3294 oli
    old "Oh, sure!"
    new "B:pla: Hmm, tu sabes, acho que preciso de ir à casa de banho."

    # say L3295 oli
    old "No problem, it's down the hallway."
    new "B:oli: Oh, claro!"

    # say L3296 pla
    old "Alright, I'll be back in a minute."
    new "B:oli: Sem problemas, é pelo corredor."

    # say L3305 pla
    old "Hmm, there's a weird sound coming from that room, what's going on in there?"
    new "B:pla: Estarei de volta daqui a um minuto."

    # say L3306 pla
    old "I don't think there's any harm in checking, right?"
    new "B:pla: Hmm, há um som estranho vindo daquele quarto, o que está a acontecer lá?"

    # say L3316 pla
    old "{i}(And she's masturbating!){/i}"
    new "B:pla: {i}(D- droga! É a mãe da Olivia!){/i}"

    # say L3317 pla
    old "{i}(I- I think she's having video sex with her husband.){/i}"
    new "B:pla: {i}(Ela está a masturbar-se!){/i}"

    # say L3318 pla
    old "{i}(S- should I leave? But what if I make noise and she catches me?){/i}"
    new "B:pla: {i}(A- Acho que ela está a ter sexo por vídeo com o marido.){/i}"

    # say L3320 vih
    old "Of course I do! I love what I'm seeing!"
    new "B:vee: Oh sim! Sim, gostas do que estás a ver, meu amor?"

    # say L3330 vee
    old "What the fuck is wrong with you?"
    new "B:vih: Claro que sim! Adoro o que estou a ver!"

    # say L3332 vee
    old "How long were you there just peeping on me?"
    new "B:vee: Que raio de merda se passa contigo?"

    # say L3334 vee
    old "You are my daughter's fiancé! Have you no shame at all?!"
    new "B:vee: Quanto tempo estiveste aí a espreitar-me?"

    # say L3335 pla
    old "I- I'm so sorry Mrs. Priya!"
    new "B:vee: Tu és o noivo da minha filha! Não tens vergonha nenhuma?!"

    # say L3337 pla
    old "But I swear to god that it wasn't my intention to break your privacy."
    new "B:pla: I- I'm so sorry Mrs. Priya!"

    # say L3339 pla
    old "I was just coming back from the bathroom when I heard some weird noise coming from the bedroom."
    new "B:pla: Mas juro a Deus que não foi minha intenção invadir a tua privacidade."

    # say L3341 pla
    old "I just wanted to make sure that there wasn't anything wrong in here."
    new "B:pla: Estava a voltar da casa de banho quando ouvi um som estranho vindo do quarto."

    # say L3342 pla
    old "And I accidentally saw you..."
    new "B:pla: Só queria ter a certeza de que não havia nada errado aqui."

    # say L3344 pla
    old "I thought about leaving, but I didn't want to make any noise that could alert you to my presence."
    new "B:pla: E vi-te acidentalmente..."

    # say L3345 pla
    old "But I swear to god this was just a big misunderstanding ma'am."
    new "T(pla|tu|say): Mas juro-te por Deus que isto foi apenas um grande mal-entendido, senhora."

    # say L3347 vee
    old "I mean, I want to believe you but..."
    new "B:pla: Mas juro a Deus que isto foi apenas um mal-entendido, senhora."

    # say L3353 vee
    old "{i}(How big is he?!){/i}"
    new "B:vee: {i}(Meu Deus, é a mão dele??){/i}"

    # say L3354 vee
    old "{i}(He must be at least twice as big as Vihaan!){/i}"
    new "B:vee: {i}(Que tamanho ele tem?!){/i}"

    # say L3356 pla
    old "Uhmm, ma'am? Is everything alright?"
    new "Que? Ah, sim..."

    # say L3358 vee
    old "What? Oh yeah..."
    new "B:pla: Hmm, senhora? Tudo bem?"

    # say L3360 vee
    old "Listen [pla], I'll believe you for now."
    new "T(vee|tu|diz): Ouve [pla], acredito em ti por agora. Mas ainda não está bem o facto de me teres estado a espiar assim."

    # say L3364 vee
    old "Next time knock or something, so that I can at least be prepared."
    new "B:vee: Mas ainda não está bem que tu estivesses a espiar-me assim."

    # say L3365 pla
    old "Yeah, you're right, I'm sorry."
    new "T(pla|tu|say): Tens razão, desculpa."

    # say L3367 vee
    old "Now, my daughter will think something's happening if you take that long to come back from the bathroom."
    new "B:pla: Sim, tens razão, desculpa."

    # say L3368 vee
    old "So go back already."
    new "B:vee: Agora, a minha filha vai pensar que está a acontecer alguma coisa se demorares tanto tempo na casa de banho."

    # say L3369 pla
    old "Uh... S- sure, excuse me."
    new "B:vee: Então volta já."

    # say L3375 vee
    old "That was a very unpleasant surprise."
    new "B:pla: Uh... C-certo, desculpa."

    # say L3376 vee
    old "But I guess I'll believe him."
    new "Mas não estava à espera de ele ter uma pila tão grande só de me ver."

    # say L3377 vee
    old "But I wasn't expecting him to have such a huge boner from seeing me."
    new "Mas não estava à espera que ele ficasse com um pau tão grande só de me ver."

    # say L3378 vee
    old "Is that what Olivia is enjoying?"
    new "B:vee: Mas não esperava que ele ficasse com um pau tão grande de me ver."

    # say L3379 vee
    old "Meanwhile all I have is my fingers and a laptop..."
    new "B:vee: É isso que a Olivia está a gostar?"

    # say L3384 pla
    old "Damn! I wasn't expecting that!"
    new "Acho que tenho sorte por ela não ter ficado mais zangada comigo."

    # say L3385 pla
    old "I guess I'm lucky that she didn't get angrier with me."
    new "B:pla: Merda! Não estava à espera disso!"

    # say L3386 pla
    old "Next time I should just keep walking and mind my own business."
    new "T(pla|tu|say): Da próxima vez devia simplesmente continuar a caminhar e não me meter."

    # say L3399 oli
    old "Hey, what took you so long? Are you alright?"
    new "B:pla: Da próxima vez devia simplesmente continuar a caminhar e não me meter."

    # say L3400 pla
    old "Me? O- oh yeah."
    new "T(pla|tu|say): Eu? O- oh sim. Acho que comi algo estranho."

    # say L3401 pla
    old "I - I think I just ate something bad."
    new "B: pla: Eu? O- oh yeah."

    # say L3402 pla
    old "But I'm alright now."
    new "B: pla: Acho que acabei de comer algo estranho."

    # say L3404 oli
    old "Well, let's keep studying."
    new "B:pla: Mas estou bem agora."

    # say L3405 oli
    old "We have a lot more to do. Come on."
    new "B:oli: Bem, vamos continuar a estudar."

    # say L3428 pla
    old "Oh! Hi Olivia, how are you today?"
    new "B:oli: Temos muito mais a fazer. Vamos lá."

    # say L3430 oli
    old "I'm doing fine, and you? How are you?"
    new "B:pla: Oh! Olá Olivia, como estás hoje?"

    # say L3432 pla
    old "Oh I'm alright, you know, not much is happening."
    new "B:oli: Estou bem, e tu? Como estás?"

    # say L3433 pla
    old "How are you handling the pregnancy? Is everything alright?"
    new "B:pla: Estou bem, sabes, não está a acontecer muito."

    # say L3435 oli
    old "Oh yeah, for the most part it is."
    new "B:pla: Como estás a lidar com a gravidez? Tudo bem?"

    # say L3436 oli
    old "My mom's still in a bad mood, but I think she'll come around."
    new "B:oli: Oh yeah, para a maior parte é."

    # say L3437 oli
    old "The other thing is that I've been feeling somewhat bad because of nausea and stuff."
    new "B:oli: A minha mãe ainda está de mau humor, mas acho que ela vai melhorar."

    # say L3438 oli
    old "You have seen it, how I get, I start to feel bad and my head hurts and stuff."
    new "B:oli: A outra coisa é que tenho sentido um pouco mal por causa das náuseas e tal."

    # say L3439 pla
    old "Yeah, I know, I'm sorry about that."
    new "B:oli: Tu já viste, como fico, começo a sentir-me mal e a minha cabeça dói e tal."

    # say L3440 pla
    old "I hope that as the pregnancy goes the symptoms will start to decrease."
    new "B:pla: Sim, eu sei, desculpa."

    # say L3442 oli
    old "Yeah, me too. But I mean is not as if I'm not managing to..."
    new "B:pla: Espero que à medida que a gravidez avança, os sintomas comecem a diminuir."

    # say L3450 rub
    old "Hey you idiot! What do you think you're doing bothering her this early in the morning?"
    new "B:oli: Sim, eu também. Mas não é como se eu não estivesse a conseguir..."

    # say L3453 rub
    old "What? Did you think that just because Olivia's pregnant now you could just start harassing her like it was nothing?"
    new "B:rub: Ei tu idiota! O que é que estás a pensar em incomodá-la tão cedo de manhã?"

    # say L3456 rub
    old "Well think again buddy, because I'm not gonna let you bother her anymore!"
    new "B:rub: O quê? Achaste que só porque a Olivia está grávida podes começar a importunar-se como se não fosse nada?"

    # say L3459 rub
    old "Actually, why don't you get out of here before I call the teachers of you for harassing Olivia?"
    new "T(rub|tu|diz): Na verdade, porque não vais embora antes de eu chamar os professores por estares a assediar a Olivia?"

    # say L3461 pla
    old "Hey! I'm not harassing anybody!"
    new "B:rub: Na verdade, porque não vais embora antes que eu chame os professores por estares a assediar a Olivia?"

    # say L3463 rub
    old "Get out of here or I'll call the teachers!"
    new "B:pla: Ei! Não estou a assediar ninguém!"

    # say L3464 rub
    old "We'll see who they believe more..."
    new "B:rub: Sai daqui ou chamo os professores!"

    # say L3465 pla
    old "Jeez, I'm leaving then."
    new "B:rub: Veremos a quem eles acreditam mais..."

    # say L3471 rub
    old "Hpmh finally that stalker left."
    new "B:pla: Puxa, então vou embora."

    # say L3472 rub
    old "How are you? Are you alright?"
    new "B:rub: Hpmh finalmente esse perseguidor foi embora."

    # say L3474 oli
    old "H- hi, I'm doing well, and you?"
    new "B:rub: Como estás? Estás bem?"

    # say L3476 rub
    old "Well, I'm alright, you know. There's nothing much going on in my life."
    new "B:oli: O- olá, estou bem, e tu?"

    # say L3477 rub
    old "Unlike you..."
    new "A:rub: Não posso acreditar que não me tenhas dito isto antes."

    # say L3479 rub
    old "I can't believe you didn't tell me about this before."
    new "B:rub: Ao contrário de ti..."

    # say L3481 rub
    old "I'm only finding out because of your belly."
    new "A:rub: Porque não me disseste antes?"

    # say L3482 rub
    old "Why didn't you let me know before?"
    new "B:rub: Estou só a descobrir por causa da tua barriga."

    # say L3484 oli
    old "W- well, the truth is that even though I found out early, I wasn't really sure about who to tell."
    new "T(oli|tu|dizes): B-bem, a verdade é que, embora tenha descoberto cedo, não tinha a certeza a quem contar."

    # say L3485 rub
    old "Why not? Is everything alright?"
    new "B:oli: B-bem, a verdade é que, embora tenha descoberto cedo, não tinha a certeza a quem contar."

    # say L3486 oli
    old "Uhmm, I guess it is."
    new "B:rub: Porquê? Tudo bem?"

    # say L3487 oli
    old "I've just been dealing with my parents. You know how they are."
    new "T(oli|tu|dizes): Tenho andado a lidar com os meus pais. Sabes como eles são."

    # say L3489 rub
    old "Hmph, yeah, I have an idea."
    new "B:oli: Acabei de lidar com os meus pais. Tu sabes como eles são."

    # say L3491 rub
    old "And what does the father say? Is he helping you?"
    new "B:rub: Hmph, yeah, tenho uma ideia."

    # say L3493 oli
    old "Hmm, w- well... W- we're actually not in contact."
    new "B:rub: E o que diz o pai? Ele está a ajudar-te?"

    # say L3495 rub
    old "What? Is that scumbag not planning on answering for what he did?"
    new "B:oli: Hmm, w- well... W- we're actually not in contact."

    # say L3496 rub
    old "Tell me who he is! I'll make him answer!"
    new "B:rub: Que? Esse canalha não vai responder pelo que fez?"

    # say L3497 oli
    old "N- no, it's nothing like what you're imagining."
    new "B:rub: Diz-me quem ele é! Vou fazer com que ele responda!"

    # say L3498 oli
    old "Is not that he doesn't want to answer for it, is just that..."
    new "B:oli: N- não, não é nada como estás a imaginar."

    # say L3499 oli
    old "I don't know who he is."
    new "T: Não sei quem ele é."

    # say L3500 rub
    old "How come?"
    new "A:oli: Bem, aconteceu nesta festa."

    # say L3501 oli
    old "Well, it happened at this party."
    new "B:rub: Como é que foi?"

    # say L3502 oli
    old "I didn't measure my drinks and got drunk."
    new "B:oli: Bem, aconteceu numa festa."

    # say L3503 oli
    old "And there was this very tall guy that I thought was cute."
    new "B:oli: Não me medi nas bebidas e acabei bêbado."

    # say L3505 oli
    old "I decided to approach him and we ended up spending the night together."
    new "B:oli: E havia este rapaz muito alto que achei fofo."

    # say L3507 oli
    old "But I never asked him his name or where he goes to school or anything."
    new "B:oli: Decidi abordá-lo e acabamos por passar a noite juntos."

    # say L3509 oli
    old "To be honest, I barely remember his face."
    new "B:oli: Mas nunca lhe perguntei o nome ou onde estuda ou qualquer coisa."

    # say L3511 oli
    old "So you see, there's not much use in worrying about the father."
    new "B:oli: Para ser honesto, mal me lembro da cara dele."

    # say L3513 rub
    old "Hmph, I guess you're right."
    new "B:oli: Então vês, não há muito jeito em se preocupar com o pai."

    # say L3516 rub
    old "But it doesn't matter, you don't need that deadbeat to answer for anything."
    new "B:rub: Hmph, acho que tens razão."

    # say L3518 rub
    old "You have your family and you have me, that's all you need."
    new "B:rub: Mas isso não importa, tu não precisas desse inútil para nada."

    # say L3519 oli
    old "Thanks Ruby, I know I can always count on you."
    new "B:rub: Tu tens a tua família e tens a mim, isso é tudo o que precisas."

    # say L3521 oli
    old "But to be honest, I don't know yet if I'll be keeping it you know?"
    new "B:oli: Obrigado, Ruby, sei que posso sempre contar contigo."

    # say L3522 oli
    old "Having a baby is a lot of work, so I'm still figuring out if I'll actually be a mother."
    new "T(oli|tu|dizes): Ter um bebé é muito trabalho, por isso estou ainda a pensar se vou realmente ser mãe."

    # say L3524 rub
    old "I see, I understand... That makes a lot of sense."
    new "T: Entendo, faz sentido... E se decidires não ter o bebé, o que vais fazer?"

    # say L3525 rub
    old "And if you decide not to have it, what are you going to do about it?"
    new "B:rub: Entendo, faz sentido..."

    # say L3527 oli
    old "Well, I was thinking that I could just go to the same doctor your friend went to that other time."
    new "B:rub: E se decidires não o fazer, o que vais fazer a respeito?"

    # say L3528 oli
    old "They did a very good job the last time, didn't they?"
    new "B:oli: Bem, estava a pensar que podia ir ao mesmo médico que a tua amiga foi daquela vez."

    # say L3529 oli
    old "I think I could go to them."
    new "B:oli: Fizeram um excelente trabalho da última vez, não foi?"

    # say L3531 rub
    old "I see, I understand... Well, I agree."
    new "B:oli: Acho que posso ir ter com eles."

    # say L3532 rub
    old "You know I'll help you no matter what, right?"
    new "B:rub: Entendo, compreendo... Bem, concordo."

    # say L3533 rub
    old "Whatever you choose to do, I'm here for you."
    new "A:oli: Eu sei, obrigado."

    # say L3534 oli
    old "I know that thanks."
    new "A:rub: Ei, que tal faltarmos às aulas hoje?"

    # say L3535 rub
    old "Hey, what do you say we skip classes for today?"
    new "B:oli: Eu sei, obrigado."

    # say L3536 rub
    old "Come on, let's go to the mall and have some ice cream."
    new "B:rub: Ei, que tal faltar às aulas hoje?"

    # say L3537 oli
    old "Haha, alright let's do it."
    new "B:rub: Vamos à galeria comercial e comer gelado."

    # say L3557 mik
    old "Dude! I'm so angry!"
    new "B:oli: Haha, bem, vamos lá."

    # say L3562 pla
    old "Y- yeah, s- she is, so?"
    new "A:mik: Então? Não vês o que há de errado nisso?"

    # say L3563 mik
    old "So? Don't you see what's wrong with that?"
    new "B: pla: Y- yeah, s- she is, so?"

    # say L3565 mik
    old "I can't believe this treason!"
    new "T(mik|tu|dizer): Não posso acreditar nesta traição!"

    # say L3566 pla
    old "H- hey man, c- calm down..."
    new "T(pla|tu|say): H- hey, c- calma..."

    # say L3568 mik
    old "What do you mean calm down? Would you be able to if you were in my shoes?"
    new "B:pla: H- hey, calma, c- calma..."

    # say L3569 pla
    old "I know man, this doesn't look good."
    new "T: Sei, mano, isto não tem bom aspeto."

    # say L3570 pla
    old "B- but I can explain, I swear."
    new "B:pla: Eu sei, cara, isto não parece nada bem."

    # say L3572 mik
    old "Explain? You know who the guy is?"
    new "B: B- mas eu posso explicar, juro."

    # say L3573 pla
    old "Uhmm... What?"
    new "A:mik: Sim, tu sabes quem é o tipo que deixou a Olivia grávida?"

    # say L3575 mik
    old "Yeah, do you know who the guy that got Olivia pregnant is?"
    new "B:pla: Hmm... O quê?"

    # say L3577 pla
    old "Oh! S- so you don't know who the father is."
    new "T(pla|tu|say): Oh! S- então tu não sabes quem é o pai."

    # say L3579 mik
    old "Of course I don't, there are some rumors that it might be some jock in the football team."
    new "B:pla: Oh! S- então tu não sabes quem é o pai."

    # say L3581 mik
    old "But nobody knows."
    new "T(mik|tu|diz): Mas já que dizes que podes explicar, imagino que sabes quem é, não é?"

    # say L3583 mik
    old "But since you say you can explain, I imagine you know who it is, don't you?"
    new "B:mik: Mas ninguém sabe."

    # say L3584 pla
    old "Uh... N- no, I- I don't know who the guy is."
    new "T(pla|tu|say): Uh... N- não, n- não sei quem é o tipo."

    # say L3585 mik
    old "Then what did you mean by that?"
    new "B:pla: Uh... N- não, eu... eu não sei quem é o cara."

    # say L3587 pla
    old "Uhmm... I just thought you were going to get into an argument with Olivia or something."
    new "B:mik: Então o que quis dizer com isso?"

    # say L3588 pla
    old "And I figured I had to stop you."
    new "E porque ela está grávida?"

    # say L3590 mik
    old "What? Because she's pregnant?"
    new "B:pla: E pensei que tinha de te parar."

    # say L3591 mik
    old "No man, not at all."
    new "T(mik|tu|dizer): Não, meu, de todo."

    # say L3593 mik
    old "I'm hurt by her betrayal that's for certain!"
    new "T(mik|tu|dizer): Estou magoado com a traição dela, isso é certo!"

    # say L3595 mik
    old "But there's no way that I would ever be angry or fight with my beloved Olivia."
    new "B:mik: Estou ferido pela traição dela, isso é certo!"

    # say L3597 mik
    old "I love her too much for it."
    new "B:mik: Mas não há como eu ficar zangado ou discutir com a minha querida Olivia."

    # say L3598 pla
    old "Is that so?"
    new "T: É verdade?"

    # say L3599 mik
    old "Of course, it doesn't matter what she did to me."
    new "T(mik|tu|say): Claro, não importa o que ela me fez."

    # say L3601 mik
    old "But that son of a bitch that got her pregnant, he's a different story."
    new "T(mik|tu|say): Mas aquele filho da puta que a deixou grávida, isso é uma história diferente."

    # say L3603 mik
    old "When I catch the guy I swear to god that I'll make him pay for getting with my woman!"
    new "T(mik|tu|dizer): Quando apanhar o tipo, juro por deus que o vou fazer pagar por ter ficado com a minha mulher! E com o quão perto eu estava de conseguir com ela."

    # say L3604 mik
    old "And with how close I was to scoring with her."
    new "B:mik: Quando apanhar o tipo juro por deus que vou fazer com que ele pague por estar com a minha mulher!"

    # say L3606 pla
    old "Yeah, I understand buddy."
    new "B:mik: E com o quão perto eu estava de marcar com ela."

    # say L3607 pla
    old "Must be rough."
    new "B:pla: Claro, percebo."

    # say L3609 mik
    old "It's alright dude, nothing I can do about it."
    new "T(mik|tu|say): Tudo bem, não posso fazer nada em relação a isso."

    # say L3610 mik
    old "But anyway this doesn't mean that I won't be there for her anyway."
    new "T(mik|tu|say): Mas isso não significa que eu não vou estar lá para ela de qualquer maneira."

    # say L3613 mik
    old "Think about it dude, if no one knows who the father is it means he's a bum or a deadbeat."
    new "A:mik: O que significa que a minha pobre Olivia tem de lidar com isto sozinha."

    # say L3614 mik
    old "Which means my poor Olivia is having to go at this by herself."
    new "B:mik: Pensa nisso, se ninguém sabe quem é o pai, significa que ele é um vagabundo ou um irresponsável."

    # say L3616 mik
    old "But she won't have to worry about anything man!"
    new "T(mik|tu|dizer): Mas ela não vai ter que se preocupar com nada, mano! Vou assumir! Vou responder por tudo o que a miúda precisar."

    # say L3618 mik
    old "I'll step up! I'll answer for everything the kid needs."
    new "T(mik|tu|say): Vou assumir! Vou responder por tudo de que o miúdo precisa."

    # say L3620 mik
    old "I'll even give him my last name so that they'll know I'm their father."
    new "B:mik: Vou assumir! Vou responder a tudo de que o miúdo precisa."

    # say L3621 pla
    old "Oh, I mean, that's great man."
    new "B:mik: Vou até dar o meu sobrenome para que saibam que sou o pai deles."

    # say L3623 pla
    old "But what does Olivia think about your noble intentions? Have you talked to her?"
    new "B:pla: Oh, eu quero dizer, isso é ótimo, mano."

    # say L3624 mik
    old "Hmm, no, not really. I haven't been able to talk to her."
    new "B:pla: Mas o que é que a Olivia pensa sobre as tuas intenções nobres? Já falaste com ela?"

    # say L3625 mik
    old "But I will, don't doubt dude!"
    new "B:mik: Hmm, não, não realmente. Não tenho conseguido falar com ela."

    # say L3645 luc
    old "This will also be at the end of term exam, so be sure to take good notes."
    new "T(luc|tu|diz): Isto também vai estar no exame final, por isso certifica-te de tomar boas notas."

    # say L3656 luc
    old "Remember to practice the subject at home, the exam is very close, so don't relax too much and forget to study."
    new "T(luc|tu|say): Lembra-te de praticar o assunto em casa, a prova está muito perto, por isso não te relaxes demasiado e esqueças de estudar."

    # say L3657 luc
    old "I know it sounds like a lot of work, but you have to do this if you want to properly learn all your subjects before the end of term exams."
    new "B:luc: Lembra-te de praticar o assunto em casa, a prova está muito próxima, por isso não te relaxes demasiado e esqueças de estudar."

    # say L3667 pla
    old "Hmph, that was a surprise."
    new "B:luc: Eu sei que parece muito trabalho, mas tens de fazer isto se quiseres aprender todas as disciplinas antes dos exames finais."

    # say L3668 pla
    old "I thought Mike had figured out it was me who got Olivia pregnant."
    new "B:pla: Hmph, isso foi uma surpresa."

    # say L3669 pla
    old "Thinking about it, now I have two things to keep hidden from him."
    new "B:pla: Eu pensei que Mike já tinha descoberto que fui eu quem deixou a Olivia grávida."

    # say L3684 oli
    old "Hey [pla], did you come to study again?"
    new "T(oli|tu|diz): Ei [pla], vieste estudar de novo?"

    # say L3687 oli
    old "Hmm, that's a good idea."
    new "B:pla: Sim, temos avançado bem ultimamente, pensei que poderíamos ter outra sessão de estudo."

    # say L3688 oli
    old "But... To be honest I'm not sure I'm up to it right now."
    new "Mas... Para ser honesto, não tenho a certeza se estou à altura disso agora."

    # say L3689 pla
    old "Are you feeling bad again because of the pregnancy?"
    new "Não, não é isso."

    # say L3690 oli
    old "No, it's not that."
    new "B:pla: Estás a sentir-te mal de novo por causa da gravidez?"

    # say L3691 oli
    old "Or rather, I think it is..."
    new "B:oli: Não, não é isso."

    # say L3695 pla
    old "Is there anything I can do to help you?"
    new "B:pla: Entendo, compreendo."

    # say L3696 pla
    old "Could I get you something for the discomfort you're feeling?"
    new "T(pla|tu|say): Podia arranjar-te algo para o desconforto que estás a sentir?"

    # say L3699 oli
    old "I mean, I'm not in pain or anything like that."
    new "B:pla: Posso fazer algo para aliviar o desconforto que estás a sentir?"

    # say L3701 pla
    old "I'm asking you in case there's anything I could do to help."
    new "T(pla|tu|dizer): Estou a perguntar-te se há algo que eu possa fazer para ajudar."

    # say L3703 oli
    old "I don't know [pla]..."
    new "Não sei [pla]... É um pouco embaraçante, sabes?"

    # say L3705 pla
    old "Is it? Why? What's happening?"
    new "T(pla|tu|say): É? Porquê? O que se passa?"

    # say L3711 oli
    old "You know, ever since I got pregnant I've been feeling this kind of..."
    new "T(oli|tu|say): Sabes, desde que fiquei grávida tenho sentido uma espécie de..."

    # say L3712 oli
    old "Tiredness? Fatigue?"
    new "B:oli: Sabes, desde que fiquei grávida tenho sentido uma espécie de..."

    # say L3713 oli
    old "It's hard to explain, but since the pregnancy started that's how I've been feeling."
    new "B:oli: Cansaço? Fadiga?"

    # say L3716 pla
    old "{i}(I wonder if it's because her body needs more magic.){/i}"
    new "B:pla: {i}(Isso é semelhante ao que a Brixxida me disse que ia acontecer.){/i}"

    # say L3718 oli
    old "They said that it's uncommon, but I might be experiencing some sort of chronic fatigue because of the pregnancy."
    new "B:oli: Fui ao médico e perguntei se isso é normal."

    # say L3719 oli
    old "But they ran several tests and concluded that I'm in good health."
    new "T(oli|tu|dizes): Mas fizeram vários exames e concluíram que estou em boa saúde."

    # say L3721 pla
    old "Alright, and is it that fatigue the reason why you don't feel like studying?"
    new "Bem, e é por causa dessa fadiga que não te apetece estudar?"

    # say L3723 oli
    old "Not really..."
    new "B:pla: E é por causa desse cansaço que não te apetece estudar?"

    # say L3724 oli
    old "I think it's related, but it's so hard to explain..."
    new "B:oli: Não realmente..."

    # say L3725 pla
    old "I think you can explain it to me. No problem."
    new "B:oli: Acho que está relacionado, mas é tão difícil de explicar..."

    # say L3726 oli
    old "Hmm, you think so?"
    new "Hmm, tu pensas isso?"

    # say L3727 oli
    old "Ok, well..."
    new "B:oli: Hmm, achas mesmo?"

    # say L3728 oli
    old "The thing that has me feeling bad is this weird..."
    new "A:oli: H- essa estranha excitação que tenho sentido desde que fiquei grávida."

    # say L3730 oli
    old "H- horniness that I've been feeling ever since I got pregnant."
    new "B:oli: A coisa que me tem deixado mal é este sentimento estranho..."

    # say L3731 pla
    old "O- oh! I- I see..."
    new "B:oli: H- hormonais que tenho sentido desde que fiquei grávida."

    # say L3733 oli
    old "Y- yeah... And it's a very weird type of being horny."
    new "B:pla: O- oh! I- I percebi..."

    # say L3734 oli
    old "At first I thought it was just because of the hormones."
    new "B:oli: Y- yeah... E é um tipo muito estranho de tesão."

    # say L3735 oli
    old "But as that fatigue that I told you about has kept growing, so has this weird feeling of horniness."
    new "B:oli: No início pensei que fosse só por causa das hormonas."

    # say L3736 oli
    old "And lately sex is the only thing that I've been able to think about, you know?"
    new "B:oli: Mas à medida que a fadiga de que te falei tem vindo a aumentar, também este sentimento estranho de excitação sexual."

    # say L3737 pla
    old "I think I understand."
    new "B:oli: E ultimamente o sexo é a única coisa em que tenho conseguido pensar, sabes?"

    # say L3738 pla
    old "But if that's the case, why didn't you tell me about it before?"
    new "Mas se é assim, por que não me contaste antes?"

    # say L3739 pla
    old "I mean... It's not as if we don't know each other."
    new "B:pla: Mas se é assim, por que não me contaste antes?"

    # say L3740 pla
    old "I could've helped you with it."
    new "B:pla: Quero dizer... Não é como se não nos conhecêssemos."

    # say L3742 oli
    old "I don't know [pla], you've already done so much for me."
    new "T(oli|tu|dizes): Não sei [pla], tu já fizeste tanto por mim."

    # say L3746 oli
    old "I wouldn't even know how to bring up the subject."
    new "B:oli: E não é como se fôssemos um casal, esta coisa toda da gravidez é só tu a ajudar-me com um problema que tenho."

    # say L3747 pla
    old "Hey, I get that, but come on, if it's something that you need, I'll be more than happy to help you."
    new "B:oli: Nem sabia como abordar o assunto."

    # say L3748 pla
    old "So... i- if you think you could use my help, maybe I can do something for you."
    new "B:pla: Hey, percebo, mas vamos lá, se é algo de que precisas, estou mais do que disposto a ajudar-te."

    # say L3750 oli
    old "Ok, m- maybe we can give it a go then..."
    new "B:pla: Então... s- se achas que podes precisar da minha ajuda, talvez eu possa fazer algo por ti."

    # say L3759 oli
    old "Ngnh! Oh god! This is amazing!"
    new "Esta pica grande é simplesmente incrível!"

    # say L3760 oli
    old "This big dick is just so great!"
    new "B:oli: Ngnh! Oh deus! Isto é incrível!"

    # say L3770 oli
    old "Oh God [pla]! That feels so much better!"
    new "B:oli: Oh [pla]! Não consigo acreditar no quanto isto é bom!"

    # say L3772 oli
    old "If I had known before that it was going to be that way, I would've told you about this sooner."
    new "B:oli: Não sei porquê, mas parece que a cansaço saiu do meu corpo de repente."

    # say L3773 pla
    old "I'm very happy that you feel better."
    new "B:oli: Se soubesse antes que ia ser assim, teria-te dito mais cedo."

    # say L3774 pla
    old "That was the whole point, it's good that this worked."
    new "B:pla: Estou muito feliz que te sintas melhor."

    # say L3776 oli
    old "You're the best, [pla]. Thank you so much."
    new "T(oli|tu|dizes): Tu és o melhor, [pla]. Muito obrigado."

    # say L3778 oli
    old "But I think we can do it later."
    new "B:oli: Acho que não vamos conseguir estudar agora."

    # say L3782 pla
    old "I guess I'll get going to my house and I'll see you later, alright?"
    new "B:pla: Com prazer, afinal, estamos nisto juntos."

    # say L3812 pla
    old "Oh! Hey Olivia, how are you?"
    new "B:pla: Acho que vou para casa, então nos vemos mais tarde, tudo bem?"

    # say L3816 pla
    old "What? Did something happen?"
    new "A:oli: Quero dizer, a minha família ainda é um pouco chata."

    # say L3818 oli
    old "I mean, my family's still a little annoying."
    new "T(oli|tu|dizes): Quero dizer, a minha família ainda é um pouco irritante."

    # say L3820 oli
    old "It's been a little hard, you know, all this with my dad and mom..."
    new "T(oli|tu|dizes): Tem sido um pouco difícil, sabes, tudo isto com o meu pai e a minha mãe..."

    # say L3821 oli
    old "And with my body getting fatter and fatter..."
    new "B:oli: Tem sido um pouco difícil, sabes, com o meu pai e a minha mãe..."

    # say L3823 pla
    old "You know... This makes me feel kinda guilty."
    new "B:oli: E com o meu corpo a ficar cada vez mais gordo..."

    # say L3825 pla
    old "Well... I mean, it is kinda my fault that you're in this situation."
    new "B:pla: Sabes... Isto faz-me sentir um bocado culpado."

    # say L3827 pla
    old "And I don't only mean the pregnancy."
    new "B:pla: Bem... Quero dizer, é um pouco culpa minha que tu te encontres nesta situação."

    # say L3829 pla
    old "But also what's happening with your family."
    new "E não me refiro apenas à gravidez."

    # say L3830 pla
    old "I can't avoid thinking that this is my responsibility."
    new "B:pla: Mas também o que está a acontecer com a tua família."

    # say L3832 oli
    old "I understand why you would feel that way."
    new "B:pla: Não consigo evitar pensar que isto é minha responsabilidade."

    # say L3837 oli
    old "After all, I was the one that came up with this idea."
    new "B:oli: Mas não acho que deves sentir culpa por isso."

    # say L3839 oli
    old "Not to mention I'm the one who dragged you into this whole situation."
    new "B:oli: Afinal, fui eu que tive esta ideia."

    # say L3840 pla
    old "Well, yeah, but still, you're the one bearing all the weight of this whole thing."
    new "B:oli: Nem falo do facto de ter sido eu quem te arrastou para esta situação toda."

    # say L3841 pla
    old "Both figuratively and literally."
    new "B:pla: Bem, sim, mas ainda assim, tu és quem suporta todo o peso disto tudo."

    # say L3843 oli
    old "Yeah, but is something that was needed."
    new "B:pla: Tanto figurativamente como literalmente."

    # say L3844 oli
    old "So don't beat yourself up too much for putting me in this state."
    new "B:oli: Sim, mas era algo necessário."

    # say L3846 oli
    old "Besides, it's not as if we didn't both enjoy it, right?"
    new "B:oli: Então, não te martirizes tanto por me teres deixado neste estado."

    # say L3847 pla
    old "Well, yeah, we did."
    new "B:oli: Além disso, não foi como se nenhum de nós tivesse gostado, certo?"

    # say L3848 oli
    old "There you go. So don't beat yourself up over it. There's no problem."
    new "B:pla: Bem, sim, fizemos."

    # say L3849 pla
    old "I guess so."
    new "B:oli: Aqui está. Então, não te martirizes por isso. Não há problema."

    # say L3850 pla
    old "But still, I'd like it if you could feel a little bit more comfortable."
    new "B:pla: Acho que sim."

    # say L3852 oli
    old "Oh, I think there's something that you could do to help me with that."
    new "A:oli: Vamos, não penses muito no meu desconforto."

    # say L3854 oli
    old "Come on, don't think too much about me being uncomfortable."
    new "B:oli: Oh, acho que há algo que tu podes fazer para me ajudar com isso."

    # say L3857 oli
    old "Now, let's go to my house."
    new "A:oli: As provas de entrada estão a chegar, por isso quero estudar um pouco mais."

    # say L3858 oli
    old "The entrance exams are coming, so I want to study a little more."
    new "B:oli: Agora, vamos à minha casa."

    # say L3876 mik
    old "W- w- what was that?! W- what did I just hear?!"
    new "B:oli: As provas de entrada estão a chegar, então quero estudar um pouco mais."

    # say L3878 mik
    old "N- no way! I- it can't be..."
    new "N- não! E- ele não faria isso!"

    # say L3879 mik
    old "No! H- he wouldn't do that!"
    new "B:mik: N- não! I- isso não pode ser..."

    # say L3880 mik
    old "With my girl?! What the hell?!"
    new "B:mik: Não! E-ele não faria isso!"

    # say L3898 pla
    old "Oh! Brixxida, hi."
    new "B:mik: Com a minha namorada?! Que raio?!"

    # say L3900 bri
    old "Hey, good morning."
    new "B:pla: Oh! Brixxida, olá."

    # say L3901 pla
    old "What are you doing here in my room so early?"
    new "B:bri: Olá, bom dia."

    # say L3902 bri
    old "Well, I was about to wake you up actually.."
    new "B:pla: O que estás a fazer aqui no meu quarto tão cedo?"

    # say L3903 pla
    old "Oh! How come?"
    new "B:bri: Bem, eu estava prestes a acordar-te..."

    # say L3905 bri
    old "Well, how long has it been since you implanted the magic in that girl?"
    new "B:pla: Oh! E então?"

    # say L3906 bri
    old "And you haven't given me any update on how things are going with her."
    new "B:bri: Bem, quanto tempo já se passou desde que implantaste a magia nessa rapariga?"

    # say L3907 pla
    old "Uh, well, there haven't been any new updates."
    new "B:bri: E tu ainda não me deste qualquer atualização sobre como as coisas estão a correr com ela."

    # say L3908 pla
    old "The only thing that's happened is what you told me."
    new "B:pla: Hum, bem, não houve atualizações novas."

    # say L3909 pla
    old "She's been feeling a little tired, so she asked me to have sex with her."
    new "B:pla: A única coisa que aconteceu foi o que tu me contaste."

    # say L3910 bri
    old "And that's it? How's her pregnancy going?"
    new "B:pla: Ela tem estado um pouco cansada, por isso pediu-me para fazer sexo com ela."

    # say L3911 pla
    old "How's it going?"
    new "T: Como está a correr?"

    # say L3912 pla
    old "Uhmm, it's very advanced, I would say."
    new "B:pla: Como está a correr?"

    # say L3913 pla
    old "Just as you told me, her belly grew so quickly."
    new "B:pla: Hummm, é muito avançado, diria eu."

    # say L3914 pla
    old "You would think she's going to give birth any time now."
    new "B:pla: Como me disseste, a barriga dela cresceu tão depressa."

    # say L3916 bri
    old "That's exactly what I mean you dimwit!!"
    new "T(bri|tu|say): É exactamente isso que eu quero dizer, idiota!!"

    # say L3917 pla
    old "W- why are you angry?"
    new "A:bri: E tu achas porquê?"

    # say L3919 bri
    old "Why do you think?"
    new "T(bri|tu|say): Porque é que pensas isso?"

    # say L3920 bri
    old "I told you [pla]! This isn't a normal human pregnancy!"
    new "T(bri|tu|dizes): Já te disse [pla]! Isto não é uma gravidez humana normal!"

    # say L3923 pla
    old "What are you talking about? Closing ritual?"
    new "B:bri: A qualquer momento ela pode dar à luz! E nós ainda não fizemos o ritual de encerramento para o feitiço!"

    # say L3924 bri
    old "Yes [pla]! A closing ritual."
    new "T(bri|tu|diz): Sim [pla]! Um ritual de encerramento."

    # say L3930 pla
    old "E- extraction? What are you talking about?"
    new "E- extração? Do que estás a falar?"

    # say L3931 pla
    old "You never told me about any kind of extraction!"
    new "T(pla|tu|dizes): Tu nunca me contaste nada sobre nenhum tipo de extração!"

    # say L3933 pla
    old "Where was all of this with Barbie?"
    new "B:pla: Tu nunca me contaste sobre qualquer tipo de extração!"

    # say L3934 bri
    old "Well, for your information, we were never even close to finishing anything with Barbie because you decided to interrupt the spell!"
    new "B:pla: Onde é que isto tudo estava com a Barbie?"

    # say L3936 bri
    old "Besides, I decided to modify the spell after your stupid tantrum last time with Barbie."
    new "B:bri: Bem, para tua informação, nunca chegámos perto de terminar nada com a Barbie porque tu decidiste interromper o feitiço!"

    # say L3939 pla
    old "Uh, o- ok? But I don't get it, why?"
    new "B:bri: Além disso, decidi modificar o feitiço depois do teu estúpido acesso de raiva da última vez com a Barbie."

    # say L3940 bri
    old "As I told you, after what happened last time with Barbie, I gave it a thought and decided the best thing to do was modify the spell."
    new "B:pla: Uh, o- ok? Mas não percebo, porquê?"

    # say L3941 bri
    old "This is because last time we ended up losing a lot of magic power."
    new "B:bri: Como te disse, depois do que aconteceu da última vez com a Barbie, pensei nisso e decidi que o melhor a fazer era modificar o feitiço."

    # say L3943 bri
    old "You see, the way it should work is that the condensation spell is over at the same time that the pregnancy is."
    new "B:bri: Isto é porque da última vez acabámos por perder muito poder mágico."

    # say L3945 bri
    old "But I realized that this approach only works if we let things come to term naturally."
    new "B:bri: Tu vês, a forma como deve funcionar é que o feitiço de condensação termina ao mesmo tempo que a gravidez."

    # say L3947 bri
    old "But if it's something like what happened with Barbie were to happen again."
    new "Mas se algo como o que aconteceu com a Barbie voltar a acontecer."

    # say L3948 bri
    old "We would end up losing all of the already cultivated magic power."
    new "T(bri|tu|say): Acabaríamos por perder todo o poder mágico já cultivado."

    # say L3951 pla
    old "But how did you solve it then?"
    new "B:bri: Acabaríamos por perder todo o poder mágico já cultivado."

    # say L3953 bri
    old "I did it by making a change to the way the spell works."
    new "T(bri|tu|say): Fiz isso alterando a forma como o feitiço funciona."

    # say L3955 bri
    old "Instead of letting it end by itself, we're directly extracting the magic power from the girl."
    new "B:bri: Fiz isso alterando a forma como o feitiço funciona."

    # say L3957 bri
    old "This way it affords me a lot more control over the magic, and the moment it's extracted."
    new "B:bri: Em vez de deixar que acabe por si só, estamos a extrair diretamente o poder mágico da rapariga."

    # say L3958 bri
    old "So, even if something similar to what happened last time with Barbie were to happen again."
    new "B:bri: Desta forma, tenho muito mais controlo sobre a magia, e no momento em que é extraída."

    # say L3960 bri
    old "We could simply cancel the cultivation process and we wouldn't lose anything."
    new "B:bri: Então, mesmo que algo semelhante ao que aconteceu da última vez com a Barbie acontecesse de novo."

    # say L3962 pla
    old "That's awesome Brixxida! And it's very reassuring!"
    new "T: Isso é ótimo, Brixxida! E é muito reconfortante!"

    # say L3964 bri
    old "Yeah, it's very good."
    new "Mas há uma condição para o feitiço nesta nova forma: tem de haver uma extração."

    # say L3966 bri
    old "But there's a condition to the spell in this new form: there HAS to be an extraction."
    new "B:bri: Sim, é muito bom."

    # say L3968 bri
    old "There's no point if we don't do it and the pregnancy just ends without us doing the extraction! We will lose all the magic!!"
    new "T(bri|tu|say): Não faz sentido se não fizermos a extração e a gravidez terminar sem isso! Vamos perder toda a magia!!"

    # say L3969 pla
    old "I- I'm sorry Brixxida, I didn't know."
    new "B:bri: Não há sentido se não o fizermos e a gravidez terminar sem extrairmos! Vamos perder toda a magia!!"

    # say L3970 bri
    old "Hmph, as long as you understand."
    new "T(bri|tu|say): Hmph, desde que percebas. Mas depois tens de te lembrar, mais cedo do que tarde, precisamos de extrair o poder mágico dela."

    # say L3972 bri
    old "But then you have to remember, sooner rather than later, we need to extract the magic power from her."
    new "B:bri: Hmph, desde que entendas."

    # say L3973 bri
    old "Otherwise, she'll have a human with a magic supercharge."
    new "B:bri: Mas então tens de te lembrar, mais cedo do que tarde, precisamos extrair o poder mágico dela."

    # say L3974 bri
    old "And honestly, I don't know what that means in the long term."
    new "B:bri: Caso contrário, ela terá um humano com uma supercarga mágica."

    # say L3979 bri
    old "By the way, [pla], there's something else you should know."
    new "T(bri|tu|say): Por acaso, [pla], há mais uma coisa que deves saber."

    # say L3984 bri
    old "This is because when we extract the magic power, I need to know if I'll take it all or just a small part."
    new "T(bri|tu|say): Isto é porque, quando extraírmos o poder mágico, preciso de saber se vou tirar tudo ou apenas uma pequena parte."

    # say L3985 pla
    old "What happens either way?"
    new "B:bri: Isto é porque, quando extraímos o poder mágico, preciso saber se vou tirar tudo ou apenas uma pequena parte."

    # say L3987 bri
    old "Well, if she decides not to go through with the whole process, I'll extract all the magic power from her."
    new "B:pla: O que acontece de qualquer maneira?"

    # say L3989 bri
    old "And her pregnancy will be reversed."
    new "B:bri: Bem, se ela decidir não continuar com o processo todo, vou extrair todo o poder mágico dela."

    # say L3991 bri
    old "So in the end, it'll be like she was never pregnant."
    new "T(bri|tu|say): Então no final, será como se ela nunca tivesse ficado grávida."

    # say L3993 bri
    old "On the other hand, if she decides to go through the whole process."
    new "B:bri: Então no final, será como se ela nunca tivesse ficado grávida."

    # say L3995 bri
    old "I'll take most of it, but I'll leave a small amount of power, so a life will be created."
    new "B:bri: Por outro lado, se ela decidir passar por todo o processo."

    # say L3996 pla
    old "I see... So that's how it is."
    new "B:bri: Vou levar a maior parte, mas vou deixar uma pequena quantidade de poder, para que uma vida seja criada."

    # say L3997 pla
    old "Alright, I'll be sure to talk to her about it."
    new "B:pla: Entendo... É assim que é."

    # say L3999 bri
    old "Good, make sure you do that."
    new "B:pla: Tudo bem, vou falar com ela sobre isso."

    # say L4000 pla
    old "Yeah, I'll do it and let you know."
    new "T: Sim, vou fazer e aviso-te."

    # say L4014 pla
    old "Alright! That's it!"
    new "A:pla: Acho que foram todos os assuntos que precisávamos estudar para o exame de entrada."

    # say L4015 pla
    old "I think that's all the subjects we needed to study for the entrance exam."
    new "B:pla: Pronto! É isso!"

    # say L4017 pla
    old "I think with that, you should ace the exam!"
    new "B:pla: Acho que foram todos os assuntos que precisávamos estudar para o exame de entrada."

    # say L4019 oli
    old "Oh my god! Thank you so much, [pla]!"
    new "T(oli|tu|dizes): Oh meu Deus! Muito obrigada, [pla]!"

    # say L4023 oli
    old "But we did it!"
    new "B:oli: No início, não acreditava que conseguiríamos cobrir tudo."

    # say L4025 oli
    old "I can't believe it, this is the best thing ever, [pla]!"
    new "T(oli|tu|dizes): Não posso acreditar, isto é a melhor coisa de sempre, [pla]!"

    # say L4028 pla
    old "But you've been so disciplined, Olivia. It's amazing how much effort you've put in such a short time."
    new "B:pla: Sim, durante um momento, também pensei que não teríamos tempo para cobrir tudo."

    # say L4029 pla
    old "This is definitely all because of your hard work."
    new "B:pla: Mas foste tão disciplinada, Olivia. É incrível o esforço que puseste em tão pouco tempo."

    # say L4031 oli
    old "Still, you've been an amazing teacher, [pla]."
    new "T(oli|tu|dizes): Ainda assim, foste uma professora incrível, [pla]."

    # say L4032 oli
    old "Thinking about it, we had a very rocky start."
    new "T(oli|tu|dizes): A pensar nisso, tivemos um início muito atribulado."

    # say L4034 oli
    old "With me blackmailing you with what I saw you do at Mike's house."
    new "B:oli: A pensar nisso, tivemos um início muito conturbado."

    # say L4035 oli
    old "I'm sorry about that, by the way."
    new "B:oli: Comigo a chantagear-te com o que viste fazer na casa do Mike."

    # say L4037 pla
    old "I mean, it's alright, given the situation you were in."
    new "T: Quero dizer, está bem, dado a situação em que estavas."

    # say L4039 pla
    old "I'm not saying it's okay, but I understand you were in a desperate position."
    new "T(pla|tu|say): Não estou a dizer que está bem, mas entendo que estavas numa posição desesperada."

    # say L4041 pla
    old "But it's alright."
    new "B:pla: Não estou a dizer que está bem, mas compreendo que estavas numa situação desesperada."

    # say L4045 oli
    old "Thank you for your understanding."
    new "B:pla: Mas está tudo bem."

    # say L4047 oli
    old "And for being so helpful."
    new "E tiveste tanta paciência com a minha ideia louca, decidindo ajudar-me com ela."

    # say L4048 oli
    old "I came up with such a crazy idea, and you decided to help me with it."
    new "E além disso, tu até dedicaste tempo para me explicar todos estes temas."

    # say L4050 oli
    old "And on top of that, you even took time to explain all these topics to me."
    new "B:oli: Tive uma ideia tão louca, e tu decidiste ajudar-me com ela."

    # say L4053 oli
    old "I don't know how to show my gratitude."
    new "B:oli: E além disso, tu até tiraste tempo para me explicar todos esses tópicos."

    # say L4055 oli
    old "But I can think of a couple of ways."
    new "A:oli: Sabes, tenho andado um pouco cansada ultimamente."

    # say L4056 oli
    old "You know, I've been feeling a little tired lately."
    new "T(oli|tu|dizes): Sabes, tenho andado um bocado cansado lately."

    # say L4057 pla
    old "Y- you are?"
    new "B:oli: Sabes, tenho andado um pouco cansado ultimamente."

    # say L4059 oli
    old "Yeah, I'm not feeling my best lately."
    new "B:pla: Tu és?"

    # say L4060 oli
    old "I was thinking maybe you could help me a bit with that."
    new "B:oli: Sim, não me tenho sentido no meu melhor ultimamente."

    # say L4061 oli
    old "And at the same time, maybe I can show my thanks for everything you've done for me."
    new "B:oli: Estava a pensar que talvez tu pudesses ajudar-me um bocadinho com isso."

    # say L4063 pla
    old "Uh, y- yeah sure, I don't see why not."
    new "B:oli: E ao mesmo tempo, talvez eu possa mostrar a minha gratidão por tudo o que tu fizeste por mim."

    # say L4065 oli
    old "Great! Give me a second to go to the bathroom, and I'll be right back."
    new "B:pla: Uh, y- yeah sure, não vejo porquê."

    # say L4066 oli
    old "Don't worry, you won't have to wait long."
    new "B:oli: Ótimo! Vou à casa de banho um momento, já volto."

    # say L4068 pla
    old "Oh right! By the way."
    new "Não te preocupes, não vais ter de esperar muito. Oh, certo! Aliás, queria perguntar-te uma coisa."

    # say L4069 pla
    old "I wanted to ask you something."
    new "T(pla|tu|dizer): Queria perguntar-te uma coisa."

    # say L4070 pla
    old "Maybe this isn't what you expect right now."
    new "Mas estava a pensar que ainda não falámos da tua decisão sobre a gravidez."

    # say L4072 pla
    old "But I was thinking we still haven't talked about your decision regarding your pregnancy."
    new "B:pla: Talvez isto não seja o que esperavas agora."

    # say L4074 pla
    old "D- don't get me wrong, I'm not trying to convince you of anything."
    new "B:pla: Mas estava a pensar que ainda não falámos da tua decisão sobre a gravidez."

    # say L4076 pla
    old "I just want to know where you stand on it, you know?"
    new "B: D- não me entendas mal, não estou a tentar convencerte de nada."

    # say L4077 pla
    old "Just because I worry about you."
    new "B:pla: Só quero saber o que tu pensas sobre isso, sabes?"

    # say L4079 oli
    old "Well... I have to say I originally thought about waiting for the entrance exam results."
    new "B:pla: Só porque me preocupo contigo."

    # say L4080 oli
    old "You know, because I wanted to know if I got into college."
    new "B:oli: Bem... Tinha pensado em esperar pelos resultados do exame de entrada."

    # say L4081 oli
    old "But I thought about it and understood what I want."
    new "B:oli: Sabes, porque queria saber se entrei na universidade."

    # menu L4084 
    old "Extract the whole magic power."
    new "B:oli: Mas pensei nisso e percebi o que quero."

    # say L4087 oli
    old "I've decided that I don't want to be a mother."
    new "B: n: Extrair todo o poder mágico."

    # say L4089 oli
    old "I- it's just that it wasn't my original plan, you know?"
    new "B:oli: Decidi que não quero ser mãe."

    # say L4091 oli
    old "When I got myself into this situation, it was only to get my parents off my back."
    new "B:oli: É que... não era o meu plano inicial, sabes?"

    # say L4093 oli
    old "But I have to say, I've never considered being a mother so young."
    new "B:oli: Quando me meti nesta situação, foi só para tirar os meus pais de cima de mim."

    # say L4094 oli
    old "There are still so many things I want to do, and being a mother would get in the way of all that."
    new "B:oli: Mas tenho de dizer que nunca considerei ser mãe tão nova."

    # say L4096 oli
    old "Besides, I would be dragging you into this situation too."
    new "B:oli: Ainda há tantas coisas que quero fazer, e ser mãe atrapalharia tudo isso."

    # say L4098 oli
    old "You've done a lot for me, [pla], but I can't ask any more from you."
    new "T(oli|tu|dizes): Tu já fizeste muito por mim, [pla], mas não posso pedir mais nada."

    # say L4102 pla
    old "You know? I completely understand what you mean."
    new "T: Tu sabes? Eu compreendo completamente o que queres dizer."

    # say L4103 pla
    old "I'm happy you're thinking about your future."
    new "T(pla|tu|dizes): Fico feliz que estejas a pensar no teu futuro."

    # say L4104 pla
    old "And hey, thanks for trusting me."
    new "B:pla: Fico feliz que estejas a pensar no teu futuro."

    # say L4106 oli
    old "I'm glad you've been my partner through this whole process, [pla]. Thank you so much."
    new "T(oli|tu|dizes): Fico contente por teres sido meu parceiro neste processo todo, [pla]. Muito obrigado."

    # say L4112 oli
    old "Well, I don't know how to tell you this."
    new "B: n: Extrair a maior parte do poder mágico, mas deixar uma pequena parte."

    # say L4114 oli
    old "But I decided that I want to be a mother."
    new "B:oli: Bem, não sei como te dizer isto."

    # say L4120 oli
    old "Ever since this happened, I've been feeling better and better about the possibility of being a mother."
    new "B:oli: É só que tenho pensado e acho que quero dar uma hipótese."

    # say L4121 pla
    old "And you decided that you want to do it?"
    new "B:oli: Desde que isto aconteceu, tenho-me sentido cada vez melhor com a possibilidade de ser mãe."

    # say L4122 oli
    old "Well, yeah."
    new "B:pla: E decidiste que queres fazê-lo?"

    # say L4124 oli
    old "I've been thinking about it and I think it's possible."
    new "B:oli: Bem, sim."

    # say L4126 oli
    old "Lately, my father has come around to the idea of me being a mom."
    new "B:oli: Tenho pensado nisso e acho que é possível."

    # say L4128 oli
    old "And my mom's pretty excited about it too."
    new "E a minha mãe também está bastante entusiasmada com isso. Então pensei em experimentar."

    # say L4130 oli
    old "So I figured I could try it."
    new "A:oli: M-mas não estou a tentar fazer de ti pai!"

    # say L4132 oli
    old "B- but I'm not trying to make you a father!"
    new "B:oli: Então pensei que podia experimentar."

    # say L4134 oli
    old "I don't expect you to get involved or anything."
    new "B: B- mas não estou a tentar fazer de ti pai!"

    # say L4135 oli
    old "It's just what I want to do, [pla]."
    new "T(oli|tu|dizes): É só o que eu quero fazer, [pla]."

    # say L4137 pla
    old "It's alright, I understand. And I would never try to convince you otherwise."
    new "A:pla: Só queria saber quais eram os teus planos."

    # say L4138 pla
    old "I just wanted to know what your plans were."
    new "B:pla: Tudo bem, eu entendo. E nunca tentaria convencê-lo do contrário."

    # say L4140 pla
    old "And I'm happy you're in a position where you can decide this."
    new "B:pla: Só queria saber quais eram os teus planos."

    # say L4141 pla
    old "I'll help you in any way you need me to."
    new "B:pla: E fico feliz que tu estejas numa posição em que podes decidir isto."

    # say L4146 oli
    old "Thanks for all your support, [pla]!"
    new "Obrigado pelo teu apoio, [pla]!"

    # say L4148 oli
    old "But when I come back, I want to see you ready."
    new "B:oli: Ouve, tenho de ir à casa de banho."

    # say L4154 pla
    old "Ok, I should take this chance to bring Brixxida here!"
    new "B:oli: Mas quando eu voltar, quero ver-te preparado."

    # say L4164 bri
    old "What do you need?"
    new "B:pla: Ok, devo aproveitar esta oportunidade para trazer a Brixxida aqui!"

    # say L4165 bri
    old "That really surprised me."
    new "B:bri: O que precisas?"

    # say L4178 oli
    old "Come on, I want you to fuck me right now."
    new "B:oli: Vamos lá, vamos fazer isto."

    # say L4179 pla
    old "S- sure, right away!"
    new "B:oli: Vamos, quero que me fodes agora."

    # say L4190 bri
    old "Oh yeah, [pla]! That's just what I wanted!"
    new "B:oli: Oh Deus sim! Isto é exactamente o que eu andava a precisar, [pla]!"

    # say L4201 oli
    old "That was sooo good, [pla]!"
    new "T(oli|tu|dizes): Foi tão bom, [pla]!"

    # say L4203 pla
    old "I'm glad you liked it."
    new "B:oli: Como sempre, o teu pénis nunca desilude."

    # say L4206 oli
    old "Well, mostly, yeah."
    new "B:pla: Fico contente que tenhas gostado."

    # say L4207 oli
    old "But you know? I still feel a little bit tired."
    new "B:oli: Bem, na maior parte, sim."

    # say L4208 oli
    old "And I feel like I haven't thanked you enough for everything."
    new "E eu sinto que ainda não te agradeci o suficiente por tudo. Então, tenho mais uma coisa para ti. Vem aqui."

    # say L4209 oli
    old "So I have another thing for you. Come here."
    new "E sinto que ainda não te agradeci o suficiente por tudo."

    # say L4218 oli
    old "Slrrp! Oh yeah!"
    new "B:oli: Tenho mais uma coisa para ti. Vem aqui."

    # say L4219 oli
    old "Hmm! I wanted to taste this dick again!"
    new "B:oli: Slrrp! Oh yeah!"

    # say L4240 pla
    old "I'm completely sure of it."
    new "T(tu|diz): Tenho a certeza absoluta disso."

    # say L4242 pla
    old "You've worked very hard to get a good result."
    new "B:pla: Estou completamente certo disso."

    # say L4243 pla
    old "There's no doubt that you'll ace it."
    new "B:pla: Tu trabalhaste muito para ter um bom resultado."

    # say L4248 pla
    old "So you'll have time to rest properly."
    new "B:pla: Hey, acho que devo ir para casa, certo?"

    # say L4264 pla
    old "Okay, I think that settles everything with the spell, right?"
    new "B:pla: De nada, Olivia."

    # say L4266 bri
    old "That's right. Now that we stopped the spell, she'll return to normal soon."
    new "T(bri|tu|say): Isso mesmo. Agora que paramos o feitiço, ela vai voltar ao normal em breve. A:bri: E não te preocupes com a saúde dela; ela vai ficar completamente bem."

    # say L4267 bri
    old "And don't worry about her health; she'll be completely fine."
    new "B:bri: Isso mesmo. Agora que paramos o feitiço, ela voltará ao normal em breve."

    # say L4268 bri
    old "So it should be all good."
    new "A:bri: Agora, ainda não podemos extrair o poder mágico de ti."

    # say L4272 bri
    old "Now, we can't extract the magic power from you yet."
    new "T(bri|tu|say): Agora, não podemos extrair o poder mágico de ti ainda. Precisamos de um pouco de tempo para que a magia que extraíste dela se estabilize dentro de ti."

    # say L4273 bri
    old "Because we need a little bit of time for the magic you extracted from her to settle within you."
    new "B:bri: Agora, ainda não podemos extrair o poder mágico de ti."

    # say L4292 pla
    old "Hmm? Hello?"
    new "B:bri: Porque precisamos de um pouco de tempo para que a magia que extraíste dela se assente em ti."

    # say L4293 pla
    old "Yes, this is him speaking."
    new "B:pla: Hmm? Olá?"

    # say L4294 pla
    old "W- what?! N- now?!"
    new "B:pla: Sim, é ele que está a falar."

    # say L4295 pla
    old "I- I'll be there right away!"
    new "T(pla|tu|say): V- Vou já a caminho!"

    # say L4300 pla
    old "I can't believe Olivia's already in the hospital!"
    new "B:pla: Vou estar aí já já!"

    # say L4301 pla
    old "I better hurry!"
    new "A:pla: I- I não acredito que tu já estás aqui!"

    # say L4314 pla
    old "I- I can't believe you're already here!"
    new "B:pla: Tenho de me apressar!"

    # say L4316 oli
    old "Me too, but my obgyn decided that now was the best time."
    new "B:pla: I- I não posso acreditar que tu já estejas aqui!"

    # say L4318 oli
    old "So you know, I guess it's fine."
    new "B:oli: Eu também, mas o meu obstetra decidiu que agora era a melhor altura."

    # say L4320 pla
    old "And how do you feel? Are you ready?"
    new "B:oli: Então, acho que está tudo bem."

    # say L4324 oli
    old "I'm sure of my decision."
    new "E a minha mãe e irmã já estão aqui para ajudar com tudo, então não te preocupes, ok?"

    # say L4325 oli
    old "And my mom and sister are already here to help with everything, so don't worry, alright?"
    new "B:oli: Tenho a certeza da minha decisão."

    # say L4327 pla
    old "Alright, sure."
    new "Querido, a enfermeira diz que têm de te levar para a sala de operações."

    # say L4334 vee
    old "Honey, the nurse says they have to move you into the operating room."
    new "B:pla: Tudo bem, claro."

    # say L4338 pla
    old "Good luck, I know you've got this."
    new "Bem, isso foi bastante rápido."

    # say L4348 pla
    old "Alright, that was rather fast."
    new "B:pla: Boa sorte, sei que tu consegues."

    # say L4350 oli
    old "I'm doing okay."
    new "B:pla: Bem, isso foi bastante rápido."

    # say L4352 oli
    old "Really, [pla], I'm completely fine with this."
    new "T(oli|tu|dizes): Realmente, [pla], estou completamente bem com isso."

    # say L4356 oli
    old "But she seems to be completely okay with all of this, so there's no problem really."
    new "B:oli: Estava um pouco preocupado que a minha mãe fosse ser toda chata com isso."

    # say L4358 pla
    old "That sounds alright."
    new "A:mar: Peço desculpa por incomodar, mas é hora da paciente descansar."

    # say L4365 mar
    old "I'm sorry to bother you, sir, but it's time for the patient to rest."
    new "B:pla: Isso parece bom."

    # say L4367 pla
    old "Alright, I guess I'll see you later then."
    new "B:mar: Desculpe incomodar-te, mas é hora do paciente descansar."

    # say L4369 oli
    old "Sure, and hey, [pla], thanks again."
    new "Tudo bem, e hey, [pla], obrigado mais uma vez. Esta grande mudança na minha vida não teria sido possível sem ti."

    # say L4373 oli
    old "I hope we'll continue being friends."
    new "B:oli: Esta grande mudança na minha vida não teria sido possível sem ti."

    # say L4375 oli
    old "And hey, come see me whenever you want. We don't have to stop having fun after this."
    new "B:oli: Espero que continuemos a ser amigos."

    # say L4376 pla
    old "Sure, I'll do it."
    new "Claro, vou fazer."

    # say L4385 pla
    old "Hey, how do you feel?"
    new "Estou a correr bem, foi muito mais fácil do que esperava, sabes?"

    # say L4387 oli
    old "I'm doing alright, it was a lot easier than I expected, you know?"
    new "T(oli|tu|dizes): Estou bem, foi muito mais fácil do que eu esperava, sabes?"

    # say L4388 pla
    old "It was?"
    new "T(pla|tu|say): Foi?"

    # say L4390 oli
    old "Yeah, it was. The doctor really helped me."
    new "B:pla: Foi?"

    # say L4391 oli
    old "So I didn't feel a lot of pain."
    new "B:oli: Sim, foi. O médico realmente me ajudou."

    # say L4392 pla
    old "That sounds great, Olivia. That's awesome."
    new "B:oli: Então não senti muita dor."

    # say L4399 mar
    old "Would the new parents like to meet their newborn son?"
    new "B:pla: Isso soa ótimo, Olivia. É incrível."

    # say L4402 oli
    old "But I think I'm a little too tired to hold him right now."
    new "B:mar: Gostariam os novos pais de conhecer o seu filho recém-nascido?"

    # say L4419 oli
    old "How about you, [pla]?"
    new "B:oli: Mas por que não fazes isso, [pla]?"

    # say L4422 pla
    old "I'm actually alright, you know?"
    new "T(tu|dizer): Estou na verdade bem, sabes?"

    # say L4424 pla
    old "I have to say, I never expected to be a father so soon."
    new "T(pla|tu|say): Tenho de dizer, nunca esperei ser pai tão cedo."

    # say L4426 pla
    old "But I can't say that I feel bad about any of this."
    new "B:pla: Tenho de dizer que nunca esperei ser pai tão cedo."

    # say L4428 pla
    old "I never expected to have all these feelings within me."
    new "B:pla: Mas não posso dizer que me sinta mal com nada disto."

    # say L4430 pla
    old "But I think it's great, really."
    new "B:pla: Nunca pensei que tivesse todos estes sentimentos dentro de mim."

    # say L4432 oli
    old "I'm so glad you feel that way, [pla]."
    new "T(oli|tu|dizes): Fico tão contente por tu te sentires assim, [pla]."

    # say L4435 oli
    old "My dad said he's moving here to be closer to his grandson."
    new "B:oli: E por acaso, não precisas de te preocupar com nada relacionado com dinheiro, sabes?"

    # say L4437 oli
    old "So I don't think you'll need to worry about that."
    new "B:oli: O meu pai disse que vai mudar-se para cá para estar mais perto do neto."

    # say L4439 pla
    old "I see, well, that's good."
    new "T: Entendo, bem, isso é bom."

    # say L4441 oli
    old "And by the way, we can still keep in touch."
    new "B:pla: Entendo, bem, isso é bom."

    # say L4442 oli
    old "I'll be expecting some of your visits in the future."
    new "B:oli: E por acaso, ainda podemos manter contacto."

    # say L4443 pla
    old "A- and I'll be sure to visit you."
    new "B:oli: Estarei à espera das tuas visitas no futuro."

    # say L4450 mar
    old "I'm sorry, sir, but the mother needs to rest."
    new "B:pla: A- e eu certamente vou visitar-te."

    # say L4451 mar
    old "And visiting hours are almost over."
    new "B:mar: Lamento, mas a mãe precisa de descansar."

    # say L4453 pla
    old "No problem, I'll leave right now."
    new "B:mar: E as horas de visitas estão quase a terminar."

    # say L4456 oli
    old "Sure, and [pla], thanks again. For everything."
    new "Claro, e [pla], obrigado mais uma vez. Por tudo."

    # say L4468 bri
    old "Alright, [pla]! You are just on time!"
    new "T(bri|tu|diz): Tudo bem, [pla]! Chegaste a tempo! Temos de descarregar a magia do feitiço no portal mágico."

    # say L4471 pla
    old "Oh right, okay, how do we do that?"
    new "B:bri: Temos que desencantar a magia do feitiço e transferi-la para o portal mágico."

    # say L4472 bri
    old "Oh, that's the best part. Come with me."
    new "B:pla: Ah, certo, ok, como fazemos isso?"

    # say L4478 bri
    old "Alright, here we are, I've prepared the portal to receive the magic power you collected from Olivia."
    new "B:bri: Oh, essa é a melhor parte. Vem comigo."

    # say L4479 bri
    old "Now, drop your pants."
    new "B:bri: Tudo bem, aqui estamos. Preparei o portal para receber a energia mágica que recolheste de Olivia."

    # say L4480 pla
    old "Oh! So that's how it's done..."
    new "B:bri: Agora, tira as calças."

    # say L4481 bri
    old "Of course! Were you expecting anything else? Come on, let me help you."
    new "B:pla: Oh! Então é assim que se faz..."

    # say L4492 bri
    old "You just need to focus on enjoying it."
    new "B:bri: Só relaxa e deixa-me fazer o trabalho."

    # say L4503 bri
    old "But now, don't forget that we need to keep looking for other subjects."
    new "B:bri: Isto foi a melhor primeira experiência que poderíamos ter esperado."

    # say L4520 vee
    old "Hi, [pla], how are you doing?"
    new "Olá, [pla], como estás?"

    # say L4522 pla
    old "Hi, Mrs. Priya. I'm doing alright, and you?"
    new "Olá, Sra. Priya. Estou bem, e tu?"

    # say L4524 vee
    old "I'm alright, honey."
    new "B:pla: Olá, Sra. Priya. Estou bem, e tu?"

    # say L4525 vee
    old "A little busy, but that's normal."
    new "B:vee: Estou bem, querida."

    # say L4529 vee
    old "And tell me, what brings you here today, honey?"
    new "B:vee: Um pouco ocupada, mas isso é normal."

    # say L4530 pla
    old "Well, not much. I was just passing by and wanted to say hello."
    new "B:vee: E conta-me, o que te traz aqui hoje, querida?"

    # say L4532 vee
    old "Oh dear, aren't you sweet."
    new "B:pla: Bem, não muito. Estava só a passar e quis dizer olá."

    # say L4534 vee
    old "It's good to see you."
    new "B:vee: Oh, que querido, não és tu doce."

    # say L4535 vee
    old "Be sure to come back soon, dear."
    new "B:vee: É bom ver-te."

    # say L4537 vee
    old "With all the help you've given Olivia, you're always more than welcome."
    new "B:vee: Certifica-te de voltar em breve, querida."

    # say L4538 pla
    old "Thanks a lot, ma'am."
    new "Obrigado, senhora."

    # say L4541 vee
    old "See you, honey."
    new "B:pla: Muito obrigado, senhora."

    # say L4545 vee
    old "Hello, [pla]! It's so good to see you. How are you?"
    new "T(vee|tu|say): Olá, [pla]! É tão bom ver-te. Como estás?"

    # say L4550 vee
    old "I've been a little busy ever since the baby came, you know."
    new "B:vee: Estou bem, querida."

    # say L4552 vee
    old "But he's such a bundle of joy that he's made everything so cheerful around here!"
    new "B:vee: Tenho andado um pouco ocupada desde que o bebé nasceu, sabes."

    # say L4554 pla
    old "That's very good to hear, Mrs. Priya."
    new "T(pla|tu|diz): É muito bom ouvir isso, Sra. Priya."

    # say L4555 vee
    old "Tell me, honey, what brings you here today?"
    new "B:pla: É muito bom ouvir isso, Sra. Priya."

    # say L4557 pla
    old "Oh, I just wanted to say hello."
    new "B:vee: Diz-me, querida, o que te traz aqui hoje?"

    # say L4559 pla
    old "See how you're doing and stuff."
    new "B:pla: Oh, só queria dizer olá."

    # say L4561 vee
    old "Aren't you sweet?"
    new "B:pla: Ver como estás e tal."

    # say L4563 vee
    old "Well, as you can see, we're doing more than alright."
    new "B:vee: Não és doce?"

    # say L4565 vee
    old "It's a shame the baby's sleeping now, otherwise you could see him."
    new "B:vee: Bem, como podes ver, estamos mais do que bem."

    # say L4567 vee
    old "But maybe some other time."
    new "B:vee: É uma pena o bebé estar a dormir agora, senão podias vê-lo."

    # say L4570 pla
    old "Well, it was good seeing you, Mrs. Priya. I'll be sure to come back later."
    new "B:vee: Mas talvez noutra altura."

    # say L4572 vee
    old "Sure, dear, you're welcome anytime."
    new "B:pla: Foi bom ver-te, Sra. Priya. Vou certamente voltar mais tarde."

    # say L4574 vee
    old "Nice seeing you."
    new "B:vee: Claro, querida, és sempre bem-vinda."

    # say L4576 pla
    old "Thanks, ma'am."
    new "Obrigado, senhora."


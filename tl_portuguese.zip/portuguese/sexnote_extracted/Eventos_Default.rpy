# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Eventos Default.rpy
translate portuguese strings:

    # say L9 pla
    old "Alright… time for some practice."
    new "Sente-se bem sentar e jogar agora."

    # say L10 pla
    old "Feels good to just sit down and play now."
    new "T(pla|tu|say): Sente-se bem só sentar e jogar agora."

    # say L11 pla
    old "It’s becoming part of the routine… and I actually look forward to it."
    new "T(pla|tu|diz): Está a tornar-se parte da rotina... e eu até tenho expectativa por isso."

    # say L17 pla
    old "That one came out clean."
    new "B:pla: Está a tornar-se parte da rotina... e eu até me apetece."

    # say L18 pla
    old "The chords are flowing better every day."
    new "B:pla: Essa saiu limpa."

    # say L19 pla
    old "Hand still gets tired, but it doesn’t fight me anymore."
    new "B:pla: As notas estão a fluir melhor todos os dias."

    # say L20 pla
    old "Feels natural now… like the guitar is actually listening."
    new "T(pla|tu|say): Sente-se natural agora... como se a guitarra estivesse realmente a ouvir."

    # say L23 pla
    old "Rhythm’s locking in nicely."
    new "T(pla|tu|say): O ritmo está a encaixar bem."

    # say L24 pla
    old "I can feel the music instead of just chasing the notes."
    new "B:pla: O ritmo está a encaixar-se bem."

    # say L25 pla
    old "({i}This is actually fun… who would’ve thought?{/i})"
    new "T(pla|tu|say): ({i}Isto é na verdade divertido… quem diria?{/i})"

    # say L30 pla
    old "Still a couple of rough spots… but overall it sounded solid."
    new "T(pla|tu|say): Ainda há uns pontos por afinar… mas no geral soou bem sólido."

    # say L31 pla
    old "I’m really starting to enjoy this."
    new "B:pla: Ainda há uns pontos por afinar… mas no geral soou bem."

    # say L32 pla
    old "It doesn’t feel like a chore anymore. It feels… right."
    new "B:pla: Estou realmente a começar a gostar disto."

    # say L33 pla
    old "Who knew picking up the guitar would end up being something I actually look forward to?"
    new "B:pla: Já não parece uma tarefa. Sente-se... certo."

    # say L34 pla
    old "That’s enough for today. Fingers are happy."
    new "B:pla: Quem diria que pegar a guitarra ia acabar sendo algo que eu realmente espero?"

    # say L35 pla
    old "Tomorrow I’ll pick it up again… no pressure, just playing."
    new "B:pla: Chega por hoje. Os dedos estão contentes."

    # say L44 bil
    old "There you are."
    new "Aí estás tu."

    # say L45 pla
    old "Hey Billie."
    new "B:bil: Aí estás tu."

    # say L46 bil
    old "Heh. Back again already?"
    new "B:pla: Olá, Billie."

    # say L47 bil
    old "The guitar at home not doing it for you anymore?"
    new "B:bil: Heh. De volta outra vez?"

    # say L48 pla
    old "Yeah… I’ve been practicing a lot by myself, but I feel like I improve faster when I’m with you."
    new "B:bil: A guitar em casa já não te satisfaz?"

    # say L49 bil
    old "Of course you do."
    new "B:pla: Yeah… Tenho praticado muito sozinho, mas sinto que melhoro mais rápido quando estou contigo."

    # say L50 bil
    old "Heh. Come on. Let’s take this to my room."
    new "B:bil: Claro que sim."

    # say L54 bil
    old "Alright, we're here."
    new "B:bil: Heh. Vamos. Leva-mos isto para o meu quarto."

    # say L55 bil
    old "So... what are we practicing today?"
    new "T(bil|tu|say): Então... o que vamos praticar hoje?"

    # say L66 pla
    old "Uhh, I would say let’s just rehearse the song together today."
    new "B:bil: Então... o que vamos praticar hoje?"

    # say L67 pla
    old "I want to polish the chords even more, youb know..."
    new "B:pla: Uhh, eu diria que vamos só ensaiar a música juntos hoje."

    # say L68 bil
    old "Heh. Going for the safe route first? Fine by me… for now."
    new "B:pla: Quero afinar ainda mais os acordes, sabes..."

    # say L69 bil
    old "Grab the guitar. Show me what you’ve been working on."
    new "B:bil: Heh. A ir pelo caminho seguro primeiro? Tudo bem para mim… por agora."

    # say L75 pla
    old "{i}Now every step just pulls me down…{/i}"
    new "B:bil: {i} costumava flutuar acima do chão… {/i}"

    # say L80 bil
    old "We’re starting to sound like we really belong together on stage."
    new "B:bil: Hmm… as tu tens feito alterações suaves agora. Tens estado a praticar."

    # say L81 bil
    old "Not bad at all. You’re actually carrying your part."
    new "B:bil: Estamos a começar a soar como se realmente pertencêssemos juntos no palco."

    # say L82 pla
    old "Yeah, it feels good."
    new "B:bil: Não está nada mal. Tu estás realmente a fazer a tua parte."

    # say L83 bil
    old "See? When we rehearse like this, we both get better together."
    new "B:pla: Sim, sinto-me bem."

    # say L84 bil
    old "Still… I wouldn’t mind if you picked something a little more fun next time."
    new "B:bil: Vês? Quando ensaiamos assim, os dois nos tornamos melhores juntos."

    # say L87 pla
    old "Uhh, I- I think my fingers could use some... practice."
    new "B:bil: Ainda… não me importava se escolheisses algo um pouco mais divertido da próxima vez."

    # say L88 pla
    old "You know what I mean?"
    new "B:pla: Uhh, A- Acho que os meus dedos precisam de... prática."

    # say L89 bil
    old "Heh. There it is. I was hoping you’d go for this."
    new "B:pla: Tu sabes o que eu quero dizer, certo?"

    # say L90 bil
    old "Good choice. I like when you get straight to it."
    new "B:bil: Heh. Lá está. Esperava que fosses por aí."

    # say L92 bil
    old "Come here, let’s make ourselves comfortable."
    new "B:bil: Boa escolha. Gosto quando vais direto ao assunto."

    # say L94 bil
    old "This is what you wanted, huh?"
    new "B:bil: Vem cá, vamos ficar confortáveis."

    # say L95 pla
    old "*Gulp*"
    new "B:bil: Isto é o que querias, hã?"

    # say L96 bil
    old "They’re all yours today."
    new "B:pla: *Engolir*"

    # say L98 bil
    old "Hands on them. You already know exactly how I like it."
    new "B:bil: São todos teus hoje."

    # say L102 pla
    old "They’re… so soft every time. I can feel them filling my hands."
    new "T: Estão… tão macias sempre. Consigo senti-las a encher as minhas mãos."

    # say L103 bil
    old "Mmm… squeeze them slowly. Open and close your hands… just like that."
    new "B:pla: Eles… são tão macios cada vez. Consigo senti-los a encher as minhas mãos."

    # say L105 bil
    old "Nngh— yeah… a little harder now. Grip them properly."
    new "B:bil: Mmm… aperta-os devagar. Abre e fecha as mãos… assim mesmo."

    # say L107 bil
    old "Fuck… keep that pace. Squeeze them like you mean it."
    new "B:bil: Nngh— sim… mais forte agora. Segura-os direito."

    # say L110 bil
    old "Now the nipples… grab them and pull… slow at first."
    new "B:bil: Merda… mantém esse ritmo. Aperta-os como se significasse alguma coisa."

    # say L112 bil
    old "That’s it… stretch them gently."
    new "B:bil: Agora os mamilos… agarra-los e puxa… devagar no início."

    # say L114 bil
    old "Mmm—harder. Tug them a little more. You’re getting really good at this."
    new "B:bil: É isso… alonga-os suavemente."

    # say L116 bil
    old "Fuck… faster. Pull them nice and firm. I love how confident your hands feel now."
    new "B:bil: Mmm—mais forte. Puxa-os um pouco mais. Estás a ficar mesmo bom nisto."

    # say L118 bil
    old "Mmm… your touch is way more precise lately. You’ve improved a lot."
    new "B: Foda-se… mais rápido. Puxa-os com força. Adoro como as tuas mãos se sentem agora, tão confiantes."

    # say L119 bil
    old "Your fingers are definitely improving. They feel so much more alive and sure of themselves."
    new "T(bil|tu|say): Os teus dedos melhoraram bastante. Sentem-se muito mais vivos e confiantes."

    # say L120 bil
    old "Keep practicing that rhythm at home… or just come back whenever you want more of... this."
    new "B:bil: Os teus dedos estão definitivamente a melhorar. Sentem-se muito mais vivos e confiantes."

    # say L124 pla
    old "Uhh, actually I was wondering if we could try the... 'advanced practice' today..."
    new "B:bil: Continua a praticar esse ritmo em casa… ou volta sempre que quiseres mais… disto."

    # say L125 bil
    old "Heh. Straight to my favorite part. I was really hoping you’d pick this one."
    new "B:pla: Uhh, na verdade estava a pensar se poderíamos tentar a... 'prática avançada' hoje..."

    # say L126 bil
    old "You know I like when you get straight to the fun stuff."
    new "T(bil|tu|say): Sabes que gosto quando vais direto ao assunto divertido."

    # say L128 bil
    old "Get ready. I’m getting on top."
    new "B:bil: Sabes que gosto quando vais direto ao assunto divertido."

    # say L130 bil
    old "I know how much you like to see them, so why don’t we make it more enjoyable for both of us?"
    new "B:bil: Prepara-te. Vou ficar por cima."

    # say L133 bil
    old "Now use those fingers right. Show me what you’ve learned."
    new "B:bil: Eu sei o quanto tu gostas de ver, então por que não tornamos isso mais prazeroso para os dois?"

    # say L135 bil
    old "Mmm… circle my clit first. Gentle, like I showed you."
    new "B:bil: Agora usa esses dedos direito. Mostra-me o que aprendeste."

    # say L145 bil
    old "Shit… your fingers really kept perfect rhythm this time."
    new "B:bil: Mmm… circula o meu clitóris primeiro. Suave, como te mostrei."

    # say L147 bil
    old "This is exactly the kind of dexterity we need… both on stage and off it."
    new "B:bil: Merda… os teus dedos mantiveram mesmo um ritmo perfeito desta vez."

    # say L151 pla
    old "Uhh… I’ve been practicing the guitar a lot by myself lately."
    new "B:bil: Este é exactamente o tipo de destreza que precisamos… tanto em palco como fora dele."

    # say L152 pla
    old "And I was thinking… maybe it would be good if I helped you with your practice too, you know?"
    new "B:pla: Uhh… Tenho estado a praticar bastante a guitarra sozinho ultimamente."

    # say L153 pla
    old "Like… helping you stay steady under pressure… like last time…"
    new "B:pla: E eu estava a pensar… talvez fosse bom se eu te ajudasse com a tua prática também, sabes?"

    # say L154 bil
    old "Heh… look at you trying to be all subtle."
    new "B:pla: Como... ajudar-te a manter a calma sob pressão... como da última vez..."

    # say L155 bil
    old "You’ve been practicing hard, huh? And now you want to 'help' me with my vocal training."
    new "B:bil: Heh… olha tu a tentar ser discreto."

    # say L156 bil
    old "Cute. Real cute."
    new "B:bil: Tu tens estado a treinar muito, hã? E agora queres 'ajudar-me' com o meu treino vocal."

    # say L157 bil
    old "I know exactly what you mean, dummy."
    new "B:bil: Fofo. Muito fofo."

    # say L158 bil
    old "Lie down. Time to put that tongue to good use."
    new "B:bil: Eu sei exactamente o que queres dizer, parvoíce."

    # say L161 bil
    old "Tongue out. Keep me steady while I lose it."
    new "B:bil: Deita-te. É hora de pôr essa língua a bom uso."

    # say L164 pla
    old "You’re already dripping…"
    new "T: Tu já estás a salivar..."

    # say L172 bil
    old "Nngh… your tongue is getting way too good at this."
    new "B:pla: Tu já estás a pingar..."

    # say L174 bil
    old "Every time you do this my voice gets stronger under pressure… and I get to enjoy that mouth of yours."
    new "Ngh… a tua língua está a ficar cada vez melhor nisto."

    # say L178 pla
    old "And sometimes I feel like I still need… a little extra motivation to keep improving."
    new "B:bil: Cada vez que fazes isto a minha voz fica mais forte sob pressão... e eu consigo desfrutar da tua boca."

    # say L179 bil
    old "Heh… so that’s what this is really about."
    new "B:pla: E por vezes sinto que ainda preciso… de um pouco de motivação extra para continuar a melhorar."

    # say L180 bil
    old "All that solo practice and you still need me to give you a little push, huh?"
    new "T(bil|tu|say): Toda essa prática sozinha e ainda precisas de um pouco de ajuda minha, hã?"

    # say L182 bil
    old "Would this be enough motivation for you?"
    new "B:bil: Toda essa prática sozinho e ainda precisas de um empurrãozinho meu, hã?"

    # say L183 bil
    old "Just looking at them… does that help?"
    new "T(bil|tu|say): Apenas olhar para eles… isso ajuda?"

    # say L185 pla
    old "Y-yeah… they look amazing but… I was thinking maybe something more… direct?"
    new "T(pla|tu|say): Y-yeah... eles parecem incríveis, mas... estava a pensar em algo mais... direto?"

    # say L186 bil
    old "Oh? Not satisfied with just the view?"
    new "B:pla: H-hum… eles parecem incríveis, mas… estava a pensar em algo mais… direto?"

    # say L187 bil
    old "Greedy today, aren’t you?"
    new "B:bil: Oh? Não ficas satisfeito só com a vista?"

    # say L188 bil
    old "Heh… fine. I know exactly how to motivate you properly."
    new "B:bil: Com fome hoje, não é?"

    # say L191 bil
    old "Let me take care of that motivation the right way."
    new "B:bil: Heh… tudo bem. Eu sei exatamente como te motivar direito."

    # say L192 bil
    old "Eyes on me the whole time."
    new "B:bil: Deixa-me tratar dessa motivação da maneira certa."

    # say L194 bil
    old "Mmm… look at you. Already so hard just from asking."
    new "B:bil: Olhos em mim o tempo todo."

    # say L195 pla
    old "Billie… that feels so good…"
    new "B:bil: Hmm… olha para ti. Já tão duro só de pedir."

    # say L197 bil
    old "Deeper now… I want to feel every throb."
    new "B:pla: Billie… isso sente-se tão bem…"

    # say L198 pla
    old "Fuck… you’re way too good at this."
    new "T: Tu és... demasiado boa nisto."

    # say L201 pla
    old "I’m— I’m close…!"
    new "B:pla: Merda… tu és demasiado bom nisto."

    # say L204 bil
    old "Mmm… every drop. Good boy."
    new "B:pla: Estou... estou perto...!"

    # say L206 bil
    old "Heh… feeling more motivated already?"
    new "B:bil: Mmm… cada gota. Bom rapaz."

    # say L208 bil
    old "Come back whenever you need some real motivation again… I’ll be waiting."
    new "B:bil: Heh… já estou a sentir-me mais motivado."

    # say L212 bil
    old "Phew, well, that’s enough for today."
    new "B:bil: Volta sempre que precisares de motivação real... Estarei à espera."

    # say L213 bil
    old "You can come back whenever you need more 'practice'."
    new "B:bil: Phew, bem, isso é o suficiente para hoje."

    # say L214 bil
    old "Just text me. I’ll always make time… especially if you want the fun version."
    new "B:bil: Podes voltar sempre que precisares de mais 'prática'."

    # say L215 pla
    old "I’ll be back soon."
    new "B:bil: Só me envia uma mensagem. Eu sempre arranjo tempo… especialmente se quiseres a versão divertida."

    # say L216 bil
    old "You better. Now get out before grandma walks in."
    new "B:pla: Vou voltar já."

    # say L223 bil
    old "Phew… that’s enough for today."
    new "B:bil: Tu melhoras. Agora sai daqui antes que a avó entre."

    # say L224 bil
    old "Not bad. You’re actually starting to sound like you belong up there with me."
    new "B:bil: Phew… isso chega para hoje."

    # say L225 bil
    old "Oh, by the way…"
    new "B:bil: Não está mal. Tu estás realmente a começar a soar como se pertencessem ao meu nível."

    # say L226 bil
    old "Tomorrow we have a practice with Bey. Don’t slack off tonight."
    new "B:bil: Oh, a propósito…"

    # say L227 bil
    old "Get some rest, warm up your fingers, and meet me at school. We’re doing a full run-through with her watching."
    new "B:bil: Amanhã temos um treino com a Bey. Não te disperses esta noite."

    # say L228 pla
    old "Got it. I’ll be there."
    new "B:bil: Descansa um pouco, aquece os dedos e encontra-me na escola. Vamos fazer uma récita completa com ela a assistir."

    # say L229 bil
    old "You better. Don’t make me drag you out of bed."
    new "B:pla: Entendido. Vou estar lá."

    # say L236 bil
    old "You’re getting better every time. I can feel it."
    new "A:bil: Ei… antes de ires."

    # say L237 bil
    old "Hey… before you go."
    new "Preciso de um favor. Liberta a tua tarde amanhã e passa por cá."

    # say L238 bil
    old "I need a favor. Free up your afternoon tomorrow and come over."
    new "B:bil: Hey… antes de ires."

    # say L239 pla
    old "Sure, what for?"
    new "B:bil: Preciso de um favor. Liberta a tarde de amanhã e passa por cá."

    # say L240 bil
    old "Just come. I need you to accompany me somewhere. No questions."
    new "B:pla: Claro, para quê?"

    # say L241 bil
    old "It’s important… and I don’t want to go alone."
    new "B:bil: Vem já. Preciso que me acompanhes a algum lado. Sem perguntas."

    # say L242 pla
    old "A- alright. I’ll be here."
    new "B:bil: É importante... e não quero ir sozinho."

    # say L243 bil
    old "Good. Don’t be late. Now get out before grandma walks in."
    new "Bem. Não cheges atrasado. Agora sai antes que a avó entre."


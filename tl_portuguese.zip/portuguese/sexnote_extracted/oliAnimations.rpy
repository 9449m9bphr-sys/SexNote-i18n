# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/oliAnimations.rpy
translate portuguese strings:

    # say L6 aye
    old "Oh yeah, sis! Woohoo!"
    new "Oh yeah, mana! Woohoo! Tu estás mesmo a matar isto!"

    # say L7 aye
    old "I can tell how good you are at this!"
    new "B:aye: Oh yeah, mana! Woohoo!"

    # say L8 aye
    old "Look at that huge cock filling your mouth!"
    new "B:aye: Consigo ver o quão boa tu és nisso!"

    # say L12 aye
    old "I know you like it, sis!"
    new "B:aye: Olha para esse pénis enorme a encher a tua boca!"

    # say L13 aye
    old "With how big his cock is, I'd say you chose well!"
    new "T: Com o tamanho do pau dele, diria que escolheste bem!"

    # say L14 aye
    old "Look at you go to town on that monster cock!"
    new "B:aye: Com o tamanho do pau dele, diria que escolheste bem!"

    # say L18 aye
    old "How about you, brother-in-law? Do you like it?"
    new "B:aye: Olha para ti a ir à town nesse pénis gigante!"

    # say L19 aye
    old "Come on, tell me! Don't leave me hanging!"
    new "B:aye: E tu, cunhado? Gostas disto?"

    # say L20 oli
    old "Slrrp, j- just answer her!"
    new "B:aye: Vamos, conta-me! Não me deixes em suspense!"

    # say L22 aye
    old "Haha! Oh yeah!"
    new "B:oli: Slrrp, r- responde-lhe!"

    # say L45 pla
    old "O- Olivia! I- I'm about to cum!"
    new "B:aye: Haha! Oh yeah!"

    # say L46 aye
    old "Yeah! Cum in her mouth! Come on!"
    new "B:pla: O- Olivia! V- Vou gozar!"

    # say L47 aye
    old "I want to see that!"
    new "B:aye: Sim! Enche a boca dela! Vai lá!"

    # say L48 oli
    old "I- it's alright, just let it out!"
    new "B:aye: Quero ver isso!"

    # say L55 aye
    old "Oh my gosh look at how much you came!"
    new "B:oli: I- está tudo bem, deixa sair!"

    # say L56 aye
    old "That's amazing!"
    new "A:aye: Tenho que dizer, mana, este gajo pode não parecer grande coisa."

    # say L57 aye
    old "I have to say, sis, this guy may not look like much."
    new "T: Tenho que dizer, mana, este tipo pode não parecer muito. A: Mas ele é certamente bem dotado."

    # say L58 aye
    old "But he is certainly well gifted."
    new "B: aye: Tenho que dizer, mana, este gajo pode não parecer grande coisa."

    # say L59 oli
    old "Oh shut up, just let me clean up and leave us alone."
    new "B:aye: Mas ele certamente é bem dotado."

    # say L71 oli
    old "Oh, wow... Your cock is getting even harder..."
    new "B:oli: Cala-te, deixa-me limpar e deixa-nos em paz."

    # say L72 oli
    old "It feels soft and warm though."
    new "B:oli: Oh, wow... O teu pénis está a ficar ainda mais duro..."

    # say L73 oli
    old "Does my hand feel good?"
    new "B:oli: Sente-se macio e quente, no entanto."

    # say L74 pla
    old "Yes, it feels really nice..."
    new "B:oli: A minha mão está a sentir-se bem?"

    # say L78 oli
    old "To be honest, it's the biggest I've ever seen..."
    new "B:pla: Sim, sente-se mesmo bem..."

    # say L80 oli
    old "I mean, it's pretty impresive..."
    new "B:oli: Para ser honesto, é o maior que já vi..."

    # say L83 oli
    old "I'll do it a little faster..."
    new "A:oli: Isso está bem?"

    # say L84 oli
    old "Is that okay?"
    new "B:oli: Vou fazer um pouco mais rápido..."

    # say L85 pla
    old "Uhh, s- sure..."
    new "T: Uhh, c-certo..."

    # say L110 oli
    old "Ok, I think that's enough... I don't want you to waste your cum..."
    new "B:pla: Uhh, c-certo..."

    # say L111 oli
    old "I mean, I need your sperm, you know the idea is to get pregnant..."
    new "B:oli: Ok, acho que já chega... Não quero que desperdices o teu sêmen..."

    # say L112 pla
    old "Uhh, yeah, you're right..."
    new "B:oli: Quero dizer, preciso do teu esperma, a ideia é engravidar..."

    # say L113 oli
    old "Alright, I'm going to take off my pants and get on the edge of the bed. I guess you know what to do..."
    new "B:pla: Uhh, yeah, tens razão..."

    # say L119 pla
    old "Uhh, yeah, of course..."
    new "B:oli: Vou tirar as calças e sentar-me à beira da cama. Acho que sabes o que fazer..."

    # say L136 oli
    old "Uhh, your cock is so big, so, I'm going to ask you to please be gentle..."
    new "B:pla: Hum, claro..."

    # say L137 pla
    old "Ohh, s- sure, don't worry."
    new "B:oli: Uhh, o teu pénis é tão grande, então, vou pedir-te para seres gentil..."

    # say L142 oli
    old "Hngh! Oh God!"
    new "B:pla: Ohh, s-sim, não te preocupes."

    # say L143 oli
    old "It's even bigger than I thought!"
    new "A- estás bem?"

    # say L144 pla
    old "A- are you alright?"
    new "T: A- estás bem?"

    # say L145 oli
    old "Y- yes, don't worry, don't stop..."
    new "B:pla: A- estás bem?"

    # say L148 oli
    old "Come on, do it a little faster, I want you to cum inside me..."
    new "B:oli: S-sim, não te preocupes, não pares..."

    # say L150 oli
    old "Mmm, it feels so deep... I've never felt anything like this before..."
    new "B:oli: Vamos, faz mais rápido, quero que gozes dentro de mim..."

    # say L151 oli
    old "Uhh... T- this is so good!"
    new "B:oli: Mmm, sente-se tão fundo... Nunca senti nada assim antes..."

    # say L152 pla
    old "Ughh... Yes..."
    new "B:oli: Uhh... I- isto é tão bom!"

    # say L177 oli
    old "Y- yes! Yes! Cum inside me!"
    new "B:pla: M- eu também! Estou prestes a gozar!"

    # say L183 oli
    old "W- woah!"
    new "B:oli: S- sim! Sim! Goza dentro de mim!"

    # say L184 oli
    old "I- I wasn't expecting it to be that way."
    new "B:oli: W- whoa!"

    # say L185 oli
    old "I was a lot better than I thought!"
    new "B:oli: I- I não estava à espera que fosse assim."

    # say L188 oli
    old "Alright, awesome!"
    new "Bem, vamos limpar isto antes que a minha mãe volte e nos veja."

    # say L189 oli
    old "Now, let's get cleaned before my mom comes back and sees us."
    new "B:oli: Ótimo, genial! T(oli|tu|diz): Agora, vamos tomar banho antes que a minha mãe volte e nos veja. A:oli: Ahhh, sim, senti falta desta sensação..."

    # say L201 oli
    old "Ohhh, yeah, I've missed this feeling..."
    new "B:oli: Agora, vamos limpar-nos antes que a minha mãe volte e nos veja."

    # say L207 oli
    old "Oh my God! Your cock is so big!"
    new "B:bri: Consigo ver as emoções dela, ela quer muito ficar grávida!"

    # say L209 oli
    old "Yeah, yeah, just don't stop!"
    new "B:oli: Ai meu Deus! O teu pénis é tão grande!"

    # say L212 oli
    old "Oh God yes!"
    new "A:oli: F- foda-me mais forte! Mais forte!"

    # say L213 oli
    old "F- fuck me harder! Harder"
    new "B:oli: Ah Deus sim!"

    # say L215 oli
    old "Mmm... I love this!"
    new "B:oli: F- foda-me mais forte! Mais forte!"

    # say L238 pla
    old "O- Olivia! I think I'm about to cum!"
    new "O- Olivia! Acho que vou gozar!"

    # say L239 oli
    old "Y- yeah! D- do it!"
    new "B:pla: O- Olivia! Acho que vou gozar!"

    # say L240 oli
    old "Fill me up with your cum!"
    new "Engravidame!"

    # say L241 oli
    old "Get me pregnant!"
    new "B:oli: Enche-me de esperma!"

    # say L247 oli
    old "God! That was fantastic [pla]!"
    new "T(oli|tu|dizes): Meu Deus! Isso foi fantástico [pla]!"

    # say L249 oli
    old "I'm sure this time I'll be pregnant for real."
    new "B:oli: Não acredito como foi bom!"

    # say L250 pla
    old "I hope so..."
    new "A:oli: Bem, vamos levantar-nos e arranjar-nos antes de a minha família voltar."

    # say L251 oli
    old "Alright, let's get up and get cleaned before my family comes back."
    new "B:pla: Espero que sim..."

    # say L263 oli
    old "Ah! ah! I'm loving it!"
    new "B:oli: Vamos levantar e arranjar-nos antes de a minha família voltar."

    # say L275 oli
    old "Oh god yes this is just what I've been missing!"
    new "B:oli: Como é que te sentes?"

    # say L276 oli
    old "I can already start to feel myself getting better!"
    new "B:oli: Oh deus, sim, isto é exactamente o que eu andava a precisar!"

    # say L309 oli
    old "Oh God! That was so great!"
    new "B:oli: Ótimo! Vamos fazer juntos!"

    # say L312 pla
    old "I- I'm glad it helped you."
    new "A:oli: Tu também gostaste?"

    # say L313 oli
    old "Did you like it too?"
    new "B:pla: I- Fico contente por ter ajudado."

    # say L314 pla
    old "Oh yeah, it was very good."
    new "B:oli: Tu também gostaste?"

    # say L315 pla
    old "Now, how about we get up before your Mom comes back."
    new "B:pla: Oh yeah, foi muito bom."

    # say L316 oli
    old "Sure!"
    new "B:pla: Agora, como tal levantamo-nos antes de a tua mãe voltar."

    # say L328 oli
    old "Oh god! Yes! Yes!"
    new "Oh deus! Sim! Sim!"

    # say L329 oli
    old "Oh yes daddy! Fuck me just like that!"
    new "B:oli: Ah deus! Sim! Sim!"

    # say L334 bri
    old "That's it [pla]!"
    new "B:oli: Isto é tão incrível [pla]!"

    # say L342 oli
    old "This is so great!"
    new "B:oli: Tu estás a deixar-me louco!"

    # say L367 oli
    old "Oh fuck yes! I want you to fill me up!"
    new "B:oli: Isto é tão bom!"

    # say L369 bri
    old "You've already extracted the magic power! Let yourself go!"
    new "B:oli: Ah sim! Enche-me!"

    # say L389 oli
    old "Oh god [pla]! The taste of your dick!"
    new "B:oli: Oh Deus [pla] que bom!"

    # say L391 oli
    old "It never disappoints me!"
    new "B:oli: Que pénis incrível!"

    # say L397 oli
    old "I just love feeling it in my mouth!"
    new "B:oli: Nunca me desilude!"

    # say L402 oli
    old "I love this dick!"
    new "A:oli: Adoro o sabor e o cheiro!"

    # say L403 oli
    old "I love it's taste and smell!"
    new "B:oli: Adoro este pénis!"

    # say L426 pla
    old "O- Olivia! I- ugh! I can't hold it in anymore!"
    new "B:oli: Adoro o seu sabor e cheiro!"

    # say L427 oli
    old "That's alright! I don't want you to!"
    new "B:pla: O- Olivia! I- ugh! Não aguento mais!"

    # say L428 oli
    old "You don't need to hold it in!"
    new "A:oli: Deixa ir e enche a minha boca com o teu esperma quente!"

    # say L429 oli
    old "Let go and fill my mouth with your hot cum!"
    new "B:oli: Não precisas de o segurar!"

    # say L439 pla
    old "I- I'm glad you like it."
    new "T: I- I'm feliz que gostes."

    # say L440 oli
    old "Oh yeah, I love it!"
    new "B:pla: I- Fico contente que tu gostes."

    # say L441 oli
    old "Now, I think we should get clean before my mom comes back and finds us like this."
    new "B:oli: Oh yeah, eu adoro!"

    # say L442 pla
    old "Sure, sure!"
    new "Claro, claro!"


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/MomsRoom.rpy
translate portuguese strings:

    # say L22 pla
    old "(Let's try this again...)"
    new "T(pla|tu|say): (Vamos tentar de novo...)"

    # say L26 mo2
    old "Oh! Again, baby? You sure are horny these days."
    new "B:pla: (Vamos tentar de novo...)"

    # say L28 mo2
    old "But I definitely do love it!"
    new "B:mo2: Oh! Outra vez, querida? Estás mesmo com muita vontade ultimamente."

    # say L50 pla
    old "(What if...)"
    new "B:pla: (Vou fazer com muito cuidado...)"

    # say L51 pla
    old "(Oh no... She would kill me... But on the other hand... What if she doesn't notice...)"
    new "B:pla: (E se...)"

    # say L52 pla
    old "(Well... I think there is a chance and if it works I can keep doing it.)"
    new "B:pla: (Oh não... Ela ia matar-me... Mas por outro lado... E se ela não reparar...)"

    # say L53 pla
    old "(All I need to do is be really careful and I'll get out of this alive...)"
    new "B:pla: (Bem... Acho que há uma hipótese e se funcionar posso continuar a fazer isto.)"

    # say L55 pla
    old "(Oh man, I think I will regret this.)"
    new "És tu, meu amor?"

    # say L57 mo2
    old "Is that you, baby?"
    new "B:pla: (Oh man, eu acho que vou me arrepender disto.)"

    # say L58 pla
    old "(OH SHIT! I'M DEAD MEAT!)"
    new "B:mo2: És tu, meu amor?"

    # say L59 mo2
    old "Mmm, is it my turn to be fucked?"
    new "B:pla: (OH SHIT! ESTOU FODIDO!)"

    # say L68 pla
    old "(Yup. I'm definitely the luckiest guy ever!)"
    new "B:mo2: Ah, percebo. Não queres que as crianças nos ouçam. Ok, então fode-me em silêncio..."

    # say L69 mo2
    old "Mmm, fuck! It feels bigger than usual. Are you using a new strap-on?"
    new "B:pla: (Claro, sou definitivamente o homem mais sortudo do mundo!)"

    # say L71 mo2
    old "Fine. Be quiet, just please don't stop!"
    new "B:mo2: Mmm, caralho! Sente-se maior do que o habitual. Estás a usar um novo cinto de castidade?"

    # say L72 mo2
    old "(This is the best I've ever had!)"
    new "B:mo2: Calma. Só não pares, por favor!"

    # say L81 pla
    old "(I will just do it carefully...)"
    new "B:mo2: (Isto é o melhor que já tive!)"

    # say L90 pla
    old "(Damn!... She's amazing but... I should leave. I don't want to wake her up.)"
    new "B:pla: (Vou fazer com cuidado...)"

    # say L100 pla
    old "(Carefully...)"
    new "B:pla: (Merda!... Ela é incrível mas... Devo ir embora. Não quero acordá-la.)"

    # say L104 pla
    old "(Fuck! She is almost naked! So sexy.)"
    new "B:pla: (Com cuidado...)"

    # say L105 pla
    old "(I should go, though. I don't want to wake her up.)"
    new "B: (Merda! Ela está quase nua! Tão sexy.)"

    # say L116 pla
    old "(She's sleeping? I shouldn't make any noise.)"
    new "B:pla: (Devo ir, embora. Não quero acordá-la.)"

    # say L134 pla
    old "(Wait... What was that noise?)"
    new "B:pla: (Ela está a dormir? Não devo fazer barulho.)"


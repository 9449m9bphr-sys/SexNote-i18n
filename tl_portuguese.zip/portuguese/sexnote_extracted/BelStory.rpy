# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/BelStory.rpy
translate portuguese strings:

    # say L30 pla
    old "What were you guys talking about?"
    new "A:bil: Ah, tu sabes, só a ouvir as parvoíces do Mike."

    # say L34 bil
    old "Oh you know, just listening to Mike's dumb stuff."
    new "B:pla: Do que vocês estavam a falar?"

    # say L38 mik
    old "Hey, what do you mean dumb stuff?"
    new "B:bil: Oh, tu sabes, só a ouvir as coisas estúpidas do Mike."

    # say L39 mik
    old "As I recall, you seemed to think it was very interesting."
    new "B:mik: Ei, o que queres dizer com coisas estúpidas?"

    # say L44 bel
    old "Well, it was only because there's nothing else going on this early in the morning."
    new "B:mik: Se me lembro bem, achaste que era muito interessante."

    # say L57 hin
    old "Hey guys, I think we should get going, classes are about to start."
    new "B:bel: Bem, foi só porque não há nada de mais a acontecer esta hora da manhã."

    # say L82 pla
    old "Yeah? What's up?"
    new "A:bel: Hum, a questão é... Que há algo de que preciso da tua ajuda."

    # say L83 bel
    old "Uhm, the thing is... That there's something I need your help with."
    new "T(bel|tu|say): Hum, a questão é... Que preciso da tua ajuda com uma coisa."

    # say L85 pla
    old "Sure, what is it?"
    new "B:bel: Hum, a questão é... Que há algo de que preciso da tua ajuda."

    # say L86 bel
    old "Hmm, I think it would be better if we talk about this somewhere else."
    new "B: pla: Claro, o que é?"

    # say L88 bel
    old "Besides, there's something I have to show you."
    new "B:bel: Hmm, acho que seria melhor falarmos sobre isso noutro sítio."

    # say L89 bel
    old "So, how about you come to my house after classes."
    new "B:bel: Além disso, tenho algo para te mostrar."

    # say L91 pla
    old "Uh, yeah, sure..."
    new "B:bel: Então, como vais à minha casa depois das aulas?"

    # say L103 bel
    old "Good morning Miss Lucy."
    new "B:pla: Bom dia, Miss Lucy."

    # say L106 luc
    old "Guys, classes are about to start."
    new "B:bel: Bom dia, Miss Lucy."

    # say L107 luc
    old "It's not good that you two stay here talking in the hallway."
    new "B:luc: Rapazes, as aulas estão prestes a começar."

    # say L109 luc
    old "Good, now go to the classroom you two..."
    new "B:luc: Não é bom que vocês fiquem aqui a conversar no corredor."

    # say L141 bel
    old "Ugh, that was eternal."
    new "T(bel|tu|say): Ugh, isso foi eterno."

    # say L142 bel
    old "Miss Lucy just kept talking and talking."
    new "B:bel: Ugh, isso foi eterno."

    # say L143 pla
    old "Tell me about it. I thought classes weren't going to end today."
    new "B:bel: A Miss Lucy não parava de falar."

    # say L144 bel
    old "Yeah, but anyway."
    new "B:pla: Conta-me mais. Eu pensei que as aulas não iam acabar hoje."

    # say L145 bel
    old "Now that that is over, will you come with me to my house?"
    new "T(bel|tu|say): Agora que isso acabou, vais comigo a minha casa?"

    # say L146 pla
    old "Uhh, sure."
    new "B:bel: Agora que isso acabou, vais comigo a minha casa?"

    # say L147 bel
    old "Alright, then let's go!"
    new "B:pla: Huh, claro."

    # say L173 pla
    old "What?! Oh."
    new "T(pla|tu|say): Que?! Oh."

    # say L175 pla
    old "I'm just realizing that I have never visited your house before."
    new "T(pla|tu|say): Apenas me apercebi de que nunca visitei a tua casa antes."

    # say L177 bel
    old "Oh, I see."
    new "B:pla: Estou a perceber que nunca visitei a tua casa antes."

    # say L179 bel
    old "Well, I try to avoid inviting people over because my mom tends to be intrusive and it annoys me."
    new "B:bel: Oh, percebo."

    # say L181 bel
    old "Although Mike has been here before."
    new "B:bel: Bem, tento evitar convidar pessoas cá em casa porque a minha mãe costuma ser intrometida e isso irrita-me."

    # say L183 bel
    old "I had to bring him when we were doing that team project."
    new "T(bel|tu|dizer): Tive de o trazer quando estávamos a fazer aquele projeto de equipa."

    # say L185 bel
    old "And he met my mom..."
    new "B:bel: Tive de o trazer quando estávamos a fazer aquele projeto de equipa."

    # say L187 bel
    old "It wasn't any fun to see him constantly trying to hit on her..."
    new "T(bel|tu|say): Não foi nada agradável vê-lo a tentar paquerá-la constantemente..."

    # say L188 pla
    old "I can imagine him doing that."
    new "T(pla|tu|say): Posso imaginar isso."

    # say L189 bel
    old "It was so awkward."
    new "B:pla: Posso imaginar o ZZZ…ZZZ a fazer isso."

    # say L191 bel
    old "But anyway, what do you think about the house?"
    new "B:bel: Foi tão embaraçoso."

    # say L193 pla
    old "Uh... It's very nice. I like the decoration a lot."
    new "B:bel: Mas enfim, o que tu achas da casa?"

    # say L195 bel
    old "You do? My mom would be happy to hear that, she's really into interior design."
    new "T(bel|tu|say): Tu sim? A minha mãe ficaria feliz em ouvir isso, ela adora decoração de interiores."

    # say L196 pla
    old "She is? Really?"
    new "T(pla|tu|say): Ela é? Mesmo?"

    # say L198 bel
    old "Yep, she's a graphic designer, so, she's quite into decorating and stuff."
    new "B:pla: Ela é? A sério?"

    # say L200 pla
    old "Hmm, I guess that makes a lot of sense."
    new "B:bel: Sim, ela é designer gráfico, por isso gosta bastante de decoração e afins."

    # say L206 bel
    old "Well, there's something I want to let you know about."
    new "B:pla: Certo, certo, e- e o que é?"

    # say L208 bel
    old "Something I- I've been keeping hidden about myself."
    new "B:bel: Bem, há algo que quero que saibas."

    # say L209 pla
    old "Uhh... W- what is it?"
    new "B:bel: Algo que- que tenho vindo a esconder sobre mim."

    # say L210 bel
    old "Well, I- I think it's easier if I show you..."
    new "B:pla: Uhh... Q- que é?"

    # say L213 bel
    old "This is it."
    new "B:bel: Bem, a- acho mais fácil se eu mostrar..."

    # say L225 pla
    old "Oh wow, w- what is this?"
    new "B:bel: É isto."

    # say L235 bel
    old "Well, not exactly."
    new "B:pla: Oh wow, w- what is this?"

    # say L236 bel
    old "I'm a webcam model, it's a little different."
    new "B:bel: Bem, não exatamente."

    # say L240 bel
    old "This is something I've been doing for a while now."
    new "B:bel: Sou uma modelo de webcam, é um pouco diferente."

    # say L241 bel
    old "I started by streaming video games, and I enjoyed it a lot."
    new "T(bel|tu|say): Comecei a transmitir jogos de vídeo, e gostei muito disso."

    # say L243 bel
    old "Over time some of my followers started asking me about some..."
    new "T(bel|tu|say): Com o tempo, alguns dos meus seguidores começaram a perguntar-me sobre... conteúdo mais adulto."

    # say L244 bel
    old "More adult content."
    new "B:bel: Com o tempo, alguns dos meus seguidores começaram a perguntar-me sobre..."

    # say L246 bel
    old "I started thinking about it. And decided I should give it a go."
    new "B:bel: Conteúdo mais adulto."

    # say L249 bel
    old "After all, I like being in front of the cameras, and I figured it would be alright as long as my face wasn't shown."
    new "B:bel: Comecei a pensar nisso. E decidi que devia experimentar."

    # say L252 bel
    old "From then on, I kept getting deeper and deeper into it."
    new "B:bel: Afinal, gosto de estar à frente das câmaras e pensei que estaria tudo bem desde que o meu rosto não fosse mostrado."

    # say L254 bel
    old "After all, I discovered I really enjoyed it."
    new "B:bel: Desde então, fui-me envolvendo cada vez mais."

    # say L255 bel
    old "I've gotten a lot of experience doing this now."
    new "B:bel: Afinal, descobri que realmente gostei."

    # say L256 pla
    old "I- I guess I get it."
    new "B:bel: Já tenho bastante experiência a fazer isto agora."

    # say L258 bel
    old "It's been good actually. I've even gotten to make some money off of it."
    new "B:pla: I- Acho que percebi."

    # say L260 pla
    old "Oh! That sounds good."
    new "Mas por que estás a falar disto de repente?"

    # say L262 pla
    old "But why are you suddenly bringing this up?"
    new "Mas por que estás de repente a falar disto?"

    # say L263 pla
    old "It's just that I imagine this is the type of thing you would want to keep secret, right?"
    new "T(pla|tu|say): É que imagino que seja o tipo de coisa que tu queres manter em segredo, certo?"

    # say L265 bel
    old "I guess, so. Yeah."
    new "B:pla: É que imagino que seja o tipo de coisa que queres manter em segredo, certo?"

    # say L266 bel
    old "But there's something happening, and I need some help with it."
    new "E eu acho que tu és a pessoa que pode ajudar-me com isso."

    # say L267 bel
    old "And I think you're the one that could help me with it."
    new "B:bel: Mas está a acontecer algo, e preciso de ajuda com isso."

    # say L269 pla
    old "M- me?!"
    new "T(pla|tu|say): M- eu?!"

    # say L271 bel
    old "You see, this is only my first year camming."
    new "B:pla: M-mim?!"

    # say L273 bel
    old "But my results have been very good. I have received a lot of fan engagement."
    new "B:bel: Vês, este é só o meu primeiro ano a fazer cam."

    # say L276 bel
    old "I even got nominated for an award!"
    new "T(bel|tu|diz): Até fui nomeada para um prémio!"

    # say L277 pla
    old "That's great Belle!"
    new "B:bel: Até fui nomeada para um prémio!"

    # say L278 pla
    old "Uh, I- I mean... I think so..."
    new "B: pla: Que bom, Belle!"

    # say L282 pla
    old "I see, congrats Belle, that's awesome!"
    new "B:bel: E sou uma das precursoras disso!"

    # say L283 pla
    old "But all of that sounds very good."
    new "B:pla: Entendo, parabéns Belle, isso é incrível!"

    # say L284 pla
    old "I don't see what you could need my help with."
    new "Tu: Não vejo em que poderia precisar da minha ajuda."

    # say L286 bel
    old "You see, these awards are measured as a popularity contest."
    new "B:pla: Não vejo o que poderia precisar da minha ajuda."

    # say L288 bel
    old "So, the winner is decided by who gets the most fan votes and tips in their category by the end of the time period."
    new "B:bel: Vês, estes prémios são medidos como um concurso de popularidade."

    # say L290 bel
    old "The number of votes and tips each person receives is put into a public chart, so, we know who's in the lead."
    new "B:bel: Então, o vencedor é decidido pelo número de votos e gorjetas que cada pessoa recebe na sua categoria até ao fim do período."

    # say L291 bel
    old "Well, that's only until the final days of the contest."
    new "B:bel: O número de votos e gorjetas que cada pessoa recebe é colocado num gráfico público, por isso, sabemos quem está na frente."

    # say L292 bel
    old "Some days before it's over the results are hidden and the winner is announced at the end."
    new "B:bel: Bem, isso é só até aos últimos dias do concurso."

    # say L294 pla
    old "I see."
    new "B:bel: Alguns dias antes, os resultados são escondidos e o vencedor é anunciado no final."

    # say L295 bel
    old "I've been doing pretty well on the polls."
    new "B:pla: Entendo."

    # say L297 bel
    old "Since the beginning of the contest I have been at the top of the standings."
    new "B:bel: Tenho-me saído bastante bem nas sondagens."

    # say L298 bel
    old "So much so that I thought I was going to win it easily."
    new "T(bel|tu|say): Tanto que pensei que ia ganhar facilmente."

    # say L300 bel
    old "However, recently a new model has been getting all the attention."
    new "B:bel: Tanto que pensei que ia ganhar com facilidade."

    # say L301 bel
    old "There's this girl named Lana. She just appeared seemingly out of nowhere and overtook me."
    new "B:bel: No entanto, recentemente um novo modelo tem estado a receber toda a atenção."

    # say L303 bel
    old "With the way things are going, she's going to run away with the lead, and beat me."
    new "T(bel|tu|say): Com o rumo que as coisas estão a tomar, ela vai fugir na frente e vencer-me."

    # say L305 pla
    old "Oh, I'm sorry Belle, it sucks that something like this is happening."
    new "B:bel: Com o rumo que as coisas estão a tomar, ela vai fugir com o papel principal e ganhar de mim."

    # say L307 bel
    old "Oh! It really does! Especially because she's not getting the lead in the competition fairly!"
    new "B:pla: Oh, sinto muito Belle, é uma chatice que algo assim esteja a acontecer."

    # say L309 bel
    old "Well, I've been thinking about why this girl is so popular."
    new "B:bel: Oh! Realmente! Especialmente porque ela não está a conseguir o papel principal no concurso de forma justa!"

    # say L311 bel
    old "And I figured it out."
    new "B:bel: Bem, tenho estado a pensar por que esta rapariga é tão popular."

    # say L312 bel
    old "It's just because she's not doing the same things I and the other girls in the category are doing."
    new "T(bel|tu|say): É só porque ela não está a fazer as mesmas coisas que eu e as outras raparigas da categoria estão a fazer."

    # say L314 pla
    old "Isn't she doing livestreams like the others?"
    new "B:bel: É só porque ela não está a fazer as mesmas coisas que eu e as outras raparigas da categoria."

    # say L316 bel
    old "Yes, but, as I told you, the category in which I'm competing is called ‘Female Revelation Streamer of the Year.'"
    new "B:pla: Ela não está a fazer diretas como as outras?"

    # say L319 bel
    old "But they have their own category."
    new "T(bel|tu|dizer): Mas eles têm a sua própria categoria."

    # say L320 bel
    old "However, she is doing streams with a guy..."
    new "B:bel: Mas eles têm a sua própria categoria."

    # say L322 bel
    old "Obviously, this type of content is much more appealing to the audience since it's literally a sex live show."
    new "B:bel: No entanto, ela faz streams com um rapaz..."

    # say L323 bel
    old "And this gives her a significant advantage over those of us who participate individually in our category..."
    new "T(bel|tu|say): E isto dá-lhe uma vantagem significativa sobre nós que participamos individualmente na nossa categoria..."

    # say L327 bel
    old "Of course, that makes sense! I even thought they would move her to a different category or suspend her for doing a different type of content..."
    new "T(bel|tu|say): Claro, isso faz sentido! Até pensei que a iriam mover para uma categoria diferente ou suspender por fazer um tipo de conteúdo diferente... A:bel: Mas aparentemente, não há regras contra o que ela está fazendo para competir nesta categoria..."

    # say L328 bel
    old "But apparently, there aren't any rules against what she is doing to compete in this category..."
    new "B:bel: Claro, isso faz sentido! Até pensei que a iriam mover para uma categoria diferente ou suspender por fazer um tipo de conteúdo diferente..."

    # say L329 bel
    old "Since when she was nominated in the category, she was doing solo streams."
    new "B:bel: Mas aparentemente, não há regras contra o que ela está a fazer para competir nesta categoria..."

    # say L330 bel
    old "But then, does that mean she can do whatever she wants and win?"
    new "B:bel: Desde que foi nomeada na categoria, ela tem feito streams sozinha."

    # say L331 bel
    old "Taking advantage of doing things from other categories to get more attention?"
    new "B:bel: Mas isso quer dizer que ela pode fazer o que quiser e ganhar?"

    # say L332 pla
    old "Hmm, yes, I understand. If you look at it a certain way, it's like she's cheating."
    new "B:bel: Aproveitar-se de fazer coisas de outras categorias para chamar mais atenção?"

    # say L333 bel
    old "That's exactly what I think too! But the webcam platform doesn't seem to care..."
    new "B:pla: Hmm, sim, percebo. Se olhares para a situação de uma certa forma, é como se ela estivesse a trair."

    # say L334 bel
    old "After all, is not the same to see a couple fucking on screen, to just seeing somebody playing with a toy or something."
    new "B:bel: É exactamente o que eu penso! Mas a plataforma de webcam não parece ligar..."

    # say L336 bel
    old "And the problem with that is that she's only doing it to win..."
    new "B:bel: Afinal, não é a mesma coisa ver um casal a fazer sexo em ecrã, do que ver alguém a brincar com um brinquedo ou algo assim."

    # say L337 bel
    old "Which means she's only interested in winning in this category now, by using tactics that of course gain her more popularity here."
    new "B:bel: E o problema com isso é que ela está a fazê-lo só para ganhar..."

    # say L338 bel
    old "Because she knows she wouldn't win doing what we do, or doing what she's doing in a couples category!"
    new "Porque ela sabe que não iria ganhar fazendo o que nós fazemos, ou fazendo o que está a fazer na categoria de casais!"

    # say L342 bel
    old "Look, this is a recording from a recent streaming she did."
    new "B:bel: Porque ela sabe que não iria ganhar fazendo o que nós fazemos, ou fazendo o que ela está a fazer numa categoria de casais!"

    # say L361 sis2
    old "I know this is what you guys have been waiting for."
    new "A:sis2: Vocês todos queriam ver-me a chupar um pau grande, não é?"

    # say L362 sis2
    old "You all wanted to see me sucking a big cock didn't you?"
    new "B:sis2: Eu sei que isto é o que vocês estavam à espera."

    # say L382 bel
    old "Do you see? She's practically doing live sex!"
    new "B:sis2: Vocês todos queriam ver-me a chupar um pénis grande, não é?"

    # say L384 bel
    old "She shouldn't be in the 'Female Revelation Streamer' category!"
    new "B:bel: Tu vês? Ela está praticamente a fazer sexo ao vivo!"

    # say L386 pla
    old "I guess that her winning the contest by doing something that no one else is doing is unfair."
    new "B:bel: Ela não deveria estar na categoria 'Streamer Feminina Revelação'!"

    # say L387 pla
    old "I get it, I get it."
    new "E o que tu planeias fazer a respeito?"

    # say L388 pla
    old "And what are you planning to do about it?"
    new "B:pla: Entendi, entendi."

    # say L396 bel
    old "I've worked so hard from the beginning."
    new "B:bel: Gosto muito disto, muito mesmo."

    # say L398 bel
    old "And ever since I started I've put a lot of effort into being number one."
    new "B:bel: Trabalhei tanto desde o início."

    # say L399 bel
    old "In fact, until just a few days ago I was first in the rankings."
    new "B:bel: E desde que comecei, tenho-me esforçado muito para ser o número um."

    # say L400 bel
    old "So, I think I should be the one that wins that award!"
    new "B:bel: Na verdade, até há uns dias estava em primeiro lugar."

    # say L401 bel
    old "Not some rando that just came out nowhere!"
    new "B:bel: Então, acho que devo ser eu a ganhar esse prémio!"

    # say L402 bel
    old "So, I've decided that I'm going to retake the lead in the contest."
    new "B:bel: Nem pensar que é um desconhecido que apareceu do nada!"

    # say L405 bel
    old "That's where I want you to help me."
    new "T(bel|tu|say): É aí que tu podes me ajudar."

    # say L406 pla
    old "Uhm... H- how?"
    new "A:bel: Quero lutar contra o fogo com fogo!"

    # say L409 bel
    old "I want to fight fire with fire!"
    new "B:pla: Hum... C- como?"

    # say L410 bel
    old "I want to see if she will actually beat me if both of us are doing the same."
    new "T(bel|tu|say): Quero ver se ela realmente vai me bater se ambos estivermos a fazer o mesmo."

    # say L414 pla
    old "You want to record yourself having sex on camera?!"
    new "T(pla|tu|say): Tu queres gravar-te a ter sexo à câmara?!"

    # say L416 bel
    old "W- Well... Technically we would be having s- sex live, but it would be recorded."
    new "B: Bel: Queres gravar-te a ter sexo em câmara?!"

    # say L418 bel
    old "Well, yeah, that's why I need your help..."
    new "B:bel: B- Bem... Tecnicamente estaríamos a ter s- sexo ao vivo, mas seria gravado."

    # say L419 bel
    old "T- that way, I- I think I'll manage to get the votes to surpass Lana."
    new "B:bel: Bem, sim, por isso preciso da tua ajuda..."

    # say L421 pla
    old "That's not the point..."
    new "B:bel: P-por isso, acho que vou conseguir os votos para ultrapassar a Lana."

    # say L422 pla
    old "I kinda get what you're saying, but, this is a little unexpected, you know?"
    new "T(pla|tu|say): Entendo um pouco o que estás a dizer, mas isto é um bocado inesperado, sabes?"

    # say L424 bel
    old "I- I know it is. But listen, I've put a lot of effort into this."
    new "B:pla: Eu percebo o que estás a dizer, mas isto é um pouco inesperado, sabes?"

    # say L425 bel
    old "From streaming video games to getting into camming, and growing my fanbase."
    new "B:bel: I- I sei. Mas escuta, eu pus muito esforço nisto."

    # say L427 bel
    old "Losing is just not an option..."
    new "T(bel|tu|say): Perder não é uma opção..."

    # say L429 bel
    old "So I need your help, please."
    new "B:bel: Perder simplesmente não é uma opção..."

    # say L430 bel
    old "It will only be a couple of times, only until I can overtake her."
    new "B:bel: Preciso da tua ajuda, por favor."

    # say L432 pla
    old "I mean, I think I get it."
    new "B:bel: Só vai ser umas poucas de vezes, só até eu a ultrapassar."

    # say L433 pla
    old "What I don't understand is why it has to be me."
    new "T(pla|tu|say): O que eu não entendo é por que tenho que ser eu."

    # say L434 pla
    old "Don't you know somebody that knows about this sort of thing?"
    new "B:pla: O que eu não entendo é por que tenho de ser eu."

    # say L435 pla
    old "You know... a professional?"
    new "B:pla: Não conheces ninguém que saiba destas coisas?"

    # say L437 bel
    old "Actually, I don't know anybody... Any men, I mean."
    new "T(bel|tu|say): Na verdade, não conheço ninguém... Nenhum homem, quero dizer."

    # say L439 bel
    old "I've been doing everything by myself."
    new "B:bel: Na verdade, não conheço ninguém... Nenhum homem, quero dizer."

    # say L442 bel
    old "I haven't ever worked with anybody before, so I don't know any man inside this business that would do it."
    new "B:bel: Tenho feito tudo sozinho."

    # say L444 bel
    old "But if I'm completely honest with you [pla], even if I knew a webcam actor or model I would still prefer to do it with you."
    new "T(bel|tu|say): Mas se for completamente honesto contigo [pla], mesmo que conhecesse um ator ou modelo de webcam, ainda preferiria fazê-lo contigo."

    # say L448 bel
    old "Well, I don't want to do this with some unknown person. For me sex is a very intimate thing."
    new "B:pla: O quê? E-Estás a falar a sério?"

    # say L450 bel
    old "I at least want it to be with someone I trust."
    new "B:bel: Bem, não quero fazer isto com uma pessoa desconhecida. Para mim, o sexo é uma coisa muito íntima."

    # say L451 pla
    old "I- uh... I understand."
    new "T: Eu... eu entendo."

    # say L453 pla
    old "But I'm don't know Belle. I don't think I want people watching me have sex on camera."
    new "B:pla: Eu... eu percebo."

    # say L455 pla
    old "Besides, and I know this is kind of obvious... That also means that you and I would have to have sex, right?"
    new "B:pla: Mas eu não conheço a Belle. Não acho que queira que as pessoas me vejam a ter sexo em câmara."

    # say L456 pla
    old "Are you ok with that?"
    new "B:pla: Além disso, e sei que é óbvio... Isso também significa que tu e eu teríamos de ter relações sexuais, certo?"

    # say L461 bel
    old "This won't be too different from that."
    new "B:bel: E não é como se tu e eu nunca tivéssemos feito isso antes, certo?"

    # say L463 bel
    old "And about the whole appearing on camera thing, you don't have to worry about that."
    new "B: bel: Isto não será muito diferente daquilo."

    # say L465 bel
    old "I will focus the camera so that your face doesn't show in any way."
    new "B:bel: E sobre a questão de aparecer na câmara, não tens de te preocupar com isso."

    # say L476 pla
    old "I guess it's fine if it helps you..."
    new "B:bel: Eu sei que isto é o que preciso para vencer a Lana."

    # say L477 bel
    old "So, you'll do it?"
    new "B:pla: Acho que está bem se te ajuda..."

    # say L480 pla
    old "I can't believe it, but I will."
    new "B:bel: Então, vais fazê-lo?"

    # say L485 bel
    old "I have to let my fans know about it."
    new "B:bel: Então, tenho de preparar tudo em direto."

    # say L488 bel
    old "Let them know there's a surprise coming and stuff."
    new "B:bel: Tenho de avisar os meus fãs."

    # say L489 bel
    old "I'll let you know when we'll do it."
    new "B: bel: Avisa-os que há uma surpresa a caminho e tal."

    # say L497 pla
    old "I think I'll see you later then."
    new "B:pla: Então..."

    # say L499 bel
    old "Sure, I'll prepare everything and let you know when we're ready to stream."
    new "B:pla: Acho que nos vemos mais tarde então."

    # say L500 pla
    old "Alright, great!"
    new "Tudo bem, ótimo! Adeus, Belle."

    # say L501 pla
    old "Bye Belle."
    new "B:pla: Ótimo, então!"

    # say L502 bel
    old "Bye [pla], and thank you so much again."
    new "T(bel|tu|say): Adeus [pla], e muito obrigada mais uma vez."

    # say L531 bel
    old "So, today can be the first day that you come and help me with my stream."
    new "T(bel|tu|say): Então, hoje pode ser o primeiro dia em que tu vens e me ajudas com o meu stream."

    # say L535 bel
    old "Plus, I think this is a good opportunity for you to make your first appearance on camera."
    new "B:bel: Então, hoje pode ser o primeiro dia em que tu vens e me ajudas com o meu stream."

    # say L536 bel
    old "So that you can get a feel for it, and start getting used to beign on camera."
    new "B:bel: Além disso, acho que esta é uma boa oportunidade para ti fazer a tua primeira aparição em câmara."

    # say L538 pla
    old "O- ok sure, no problem."
    new "B:bel: Para te habituares, e começares a sentir-te confortável em frente à câmara."

    # say L539 pla
    old "L- lets do it."
    new "B: pla: O- ok, claro, sem problemas."

    # say L541 bel
    old "Ok, great!"
    new "B: L- vamos fazer isso."

    # say L542 bel
    old "Come to my house in the afternoon."
    new "B:bel: Ótimo!"

    # say L544 pla
    old "I thought I would go with you right after we finished classes."
    new "B:bel: Vem à minha casa à tarde."

    # say L546 bel
    old "No, I will skip classes today. I need to go home and get everything ready for the stream. I just came to let you know."
    new "B:pla: Eu pensei que iria contigo logo depois de terminarmos as aulas."

    # say L547 pla
    old "Alright, no problem."
    new "B:bel: Não, vou faltar às aulas hoje. Preciso ir para casa e preparar tudo para o stream. Vim só para te avisar."

    # say L549 bel
    old "So, see you later at my house."
    new "B:pla: Tudo bem, sem problemas."

    # say L571 pla
    old "Ok, I think Belle must be waiting for me..."
    new "B:bel: Então, até mais tarde na minha casa."

    # say L572 pla
    old "Phew, I don't know how I always get myself into these things..."
    new "A:ash: Oh! Olá."

    # say L593 ash
    old "Oh! Hello."
    new "B:pla: Ufa, não sei como sempre me meto nestas situações..."

    # say L595 pla
    old "Uh... H- hi, g- good afternoon."
    new "B:ash: Oh! Olá."

    # say L597 ash
    old "Good afternoon. Can I help you with something?"
    new "B:pla: Uh... H- hi, g- good afternoon."

    # say L606 pla
    old "Excuse me Mrs. Ashley..."
    new "Desculpe, Ashley..."

    # say L608 ash
    old "Mrs. Ashley? Haha, oh dear no, just call me Ashley. I'm too young to have anyone call me Mrs."
    new "B:pla: Desculpe, Sra. Ashley..."

    # say L610 pla
    old "O- ok, A- Ashley. Is Belle around? She told me to come at this time."
    new "T(tu): O- ok, A- Ashley. A Belle está por perto? Ela disse-me para vir nesta altura."

    # say L612 ash
    old "She is dear, she's in her bedroom."
    new "B:pla: O- ok, A- Ashley. A Belle está por perto? Ela disse-me para vir a esta hora."

    # say L613 ash
    old "I'll let her know you're here."
    new "B:ash: Ela é querida, está no quarto dela."

    # say L630 ash
    old "Well sweety, you didn't tell me you were expecting anyone."
    new "B:bel: Mãe, por que não me disseste que tinha chegado uma visita para mim?"

    # say L633 ash
    old "But I was just about to come and tell you your friend had arrived."
    new "B:ash: Bem querida, tu não me disseste que estavas à espera de alguém."

    # say L635 bel
    old "I- I see...."
    new "B:ash: Mas eu estava a ponto de vir te dizer que o teu amigo tinha chegado."

    # say L641 ash
    old "Well, I guess I'll do my best not to bother you, sweetheart."
    new "B:bel: Então, seria bom se tu pudesses evitar interromper-nos."

    # say L659 bel
    old "Yeah I know, sorry"
    new "B:pla: E aí, o que aconteceu? Eu pensei que tu tinhas dito que ela não ia estar aqui hoje?"

    # say L661 bel
    old "She just suddenly came back home and said she was going to work from home today."
    new "B:bel: Sim, eu sei, desculpa."

    # say L662 bel
    old "I don't know why, I guess something happened at the office."
    new "B:bel: Ela simplesmente voltou a casa e disse que ia trabalhar a partir de casa hoje."

    # say L663 pla
    old "Hmm ok, yeah, I understand."
    new "B:bel: Não sei porquê, acho que aconteceu algo no escritório."

    # say L664 pla
    old "I suppose we're not streaming today then."
    new "B:pla: Hmm ok, yeah, I understand."

    # say L666 bel
    old "Yep, we can't do the stream with my mother here."
    new "T(bel|tu|say): Pois, não podemos fazer o stream com a minha mãe aqui. Ela pode entrar a qualquer momento."

    # say L668 bel
    old "She could come in at any time."
    new "B:bel: Sim, não podemos fazer o stream com a minha mãe aqui."

    # say L670 bel
    old "She'll be bringing some snacks, or knocking on the door to see how we're doing, or something."
    new "B:bel: Ela pode entrar a qualquer momento."

    # say L673 bel
    old "My mom's very controlling, and she'll want to know what we're doing here."
    new "Então, é melhor não corrermos o risco de sermos apanhados no meio disso."

    # say L675 bel
    old "So, it's better if we don't risk being caught in the middle of it."
    new "B:bel: A minha mãe é muito controladora e vai querer saber o que estamos a fazer aqui."

    # say L682 pla
    old "Oh, don't worry. We can do it on any other day. I'll head back home then."
    new "B:bel: Lamento ter-te feito vir aqui à toa."

    # say L684 bel
    old "Well, maybe you should stay for a little while."
    new "B: Oh, não te preocupes. Podemos fazer noutra altura. Vou voltar para casa então."

    # say L685 bel
    old "After all, you just got here. My mom could get suspicious if you leave just after arriving."
    new "B:bel: Bem, talvez deves ficar um pouco mais."

    # say L687 pla
    old "Ok, so what are we going to do?"
    new "B:bel: Afinal, acabaste de chegar. A minha mãe pode desconfiar se fores embora logo depois de chegares."

    # say L689 bel
    old "I was thinking I could let you know a bit more about this whole camming thing, how it works and stuff."
    new "B:pla: Ok, então o que vamos fazer?"

    # say L690 pla
    old "Oh, ok sure."
    new "B:bel: Estava a pensar que podia contar-te um pouco mais sobre esta coisa toda das transmissões, como funciona e tal."

    # say L696 bel
    old "And whatever I'm going to do, I do it live, instead of having it pre-recorded, like in porn."
    new "B:bel: Enquanto estamos a fazê-lo, isso é o mais importante para manter em mente."

    # say L697 bel
    old "Since everything is completely live, tips are very important."
    new "B:bel: E o que quer que eu vá fazer, faço ao vivo, em vez de ter gravado antecipadamente, como na pornografia."

    # say L698 pla
    old "Why?"
    new "B:bel: Como tudo é completamente ao vivo, as gorjetas são muito importantes."

    # say L700 bel
    old "Well, because the livestream is a type of show."
    new "B:pla: Porquê?"

    # say L701 bel
    old "Which means that my fans have to be engage and entertained."
    new "B:bel: Bem, porque o livestream é um tipo de espetáculo."

    # say L703 bel
    old "And the only reliable way I can gauge if they really like it, is by seeing their tips."
    new "T(bel|tu|say): E a única maneira fiável de eu saber se eles realmente gostam é vendo as gorjetas deles."

    # say L704 bel
    old "So, the whole objective of each time I'm on camera is to get them to tip."
    new "B:bel: E a única maneira fiável que tenho de saber se eles realmente gostam é vendo as gorjetas."

    # say L705 pla
    old "Uhh... I see."
    new "B:bel: Então, o objetivo cada vez que estou em câmara é fazer com que eles dêem gorjetas."

    # say L709 bel
    old "If the audience matches the goals by tipping, I do what I promised for that goal, and move into the next one."
    new "B: bel: É o número de gorjetas que quero que os meus fãs me dêem antes de fazer qualquer coisa."

    # say L711 pla
    old "I think I get it."
    new "A:pla: Então, se fazemos algo ou não, depende do público?"

    # say L712 pla
    old "So, whether we do something or not, depends on the audience?"
    new "B:pla: Acho que percebi."

    # say L713 bel
    old "That's right, we decide what to do, but we only do it if the goal is met."
    new "B:pla: Então, se fazemos algo ou não, depende do público?"

    # say L715 pla
    old "That sounds simple."
    new "B:bel: É verdade, decidimos o que fazer, mas só o fazemos se o objetivo for atingido."

    # say L717 bel
    old "Well, it's all about personality, and how much you connect with the audience, you know?"
    new "B:pla: Isso soa simples."

    # say L718 bel
    old "So it's important to talk to them, try and pay attention to their comments, and the demands they make."
    new "B:bel: Bem, tudo se resume à personalidade e a quanto consegues conectar-te com o público, sabes?"

    # say L720 pla
    old "That makes sense."
    new "B:bel: É importante falar com eles, tentar prestar atenção aos seus comentários e às exigências que fazem."

    # say L722 bel
    old "And as I told you before, you don't need to talk or interact with them."
    new "E como te disse antes, não precisas de falar ou interagir com eles. Afinal, os meus fãs querem ver-me a fazer algo com um... c- com um pénis."

    # say L724 bel
    old "After all, my fans want to see me doing something with a... w- with a penis."
    new "B:bel: E como te disse antes, não precisas de falar ou interagir com eles."

    # say L726 bel
    old "But they don't really want to get to know you."
    new "B:bel: Afinal, os meus fãs querem ver-me a fazer algo com um... c- com um pénis."

    # say L728 bel
    old "T- the most important is for you to... have a b- boner during the show."
    new "B:bel: Mas eles não querem realmente te conhecer."

    # say L729 bel
    old "I- I'll take care of the rest."
    new "B:bel: O- o mais importante é tu... teres uma e- ereção durante o espetáculo."

    # say L731 pla
    old "Well... I- I guess I can manage that."
    new "B:bel: Eu... eu cuido do resto."

    # say L742 ash
    old "Hey guys! How are you doing?"
    new "B:pla: Bem... A- Acho que consigo fazer isso."

    # say L744 bel
    old "Uhmm, we're doing fine mom."
    new "B:ash: Ei, pessoal! Como estão?"

    # say L745 bel
    old "But I would've appreciated it if you'd knocked on the door before entering."
    new "B:bel: Hummm, estamos bem, mãe."

    # say L748 ash
    old "I'm sorry honey, but I just wanted to see if you needed anything."
    new "T: Desculpa querida, mas só queria ver se precisavas de algo. A: Talvez queiras que te traga algumas petiscos?"

    # say L750 ash
    old "Maybe you would like me to bring you some snacks?"
    new "B:ash: Desculpa querida, mas só queria ver se precisavas de alguma coisa."

    # say L752 bel
    old "I think we're fine mom, thank you."
    new "B:ash: Talvez queiras que eu te traga algumas petiscos?"

    # say L753 ash
    old "Ok sweety, I'll leave for now then."
    new "B:bel: Acho que estamos bem, mãe, obrigada."

    # say L754 ash
    old "But if you two need anything, just let me know."
    new "B:ash: Ok, querida, vou-me embora então."

    # say L755 bel
    old "Yeah, right, thank you..."
    new "B:ash: Mas se vocês precisarem de algo, é só me dizer."

    # say L763 bel
    old "Sorry, she just came in unannounced."
    new "B:bel: Sim, claro, obrigado..."

    # say L765 pla
    old "It's ok, we kinda knew she was going to do that."
    new "B:bel: Desculpa, ela entrou sem avisar."

    # say L766 bel
    old "Yeah... but that's why we can't do anything whenever she's here."
    new "B:pla: Tudo bem, mais ou menos já esperávamos que ela fosse fazer isso."

    # say L767 pla
    old "Y- yeah, I- I get it..."
    new "B:bel: Sim... mas é por isso que não podemos fazer nada sempre que ela está aqui."

    # say L769 bel
    old "Well, anyway, t- there hasn't been enough time since you came here."
    new "B: pla: Y- yeah, I- I get it..."

    # say L770 bel
    old "So, why don't I show you the webcam platform in the meantime?"
    new "B:bel: Bem, de qualquer forma, n-não passou tempo suficiente desde que tu chegaste aqui."

    # say L771 pla
    old "Yeah... sure."
    new "B:bel: Então, porque não te mostro a plataforma de webcam entretanto?"

    # say L794 pla
    old "Yeah, sure, just tell me when and I'll come to help you."
    new "B:bel: Vou-te dizer quando for a altura certa para viremos de novo."

    # say L796 pla
    old "You're welcome Belle, I'm happy to help you."
    new "B:pla: Claro, só me diz quando e eu vou ajudar-te."

    # say L797 bel
    old "I hope next time we won't have any problems streaming."
    new "B:pla: De nada, Belle, fico feliz em ajudar-te."

    # say L799 bel
    old "The voting period is closing soon, and we won't be able to do anything if we have to postpone it too much."
    new "B:bel: Espero que da próxima vez não tenhamos problemas com o streaming."

    # say L801 pla
    old "I get it, but what happened today was just unexpected."
    new "B:bel: O período de votação está a fechar em breve, e não poderemos fazer nada se tivermos de adiar demasiado."

    # say L802 pla
    old "I bet there won't be any problem going forward."
    new "B:pla: Entendi, mas o que aconteceu hoje foi inesperado."

    # say L804 bel
    old "Yeah, you're probably right."
    new "A:pla: Então, ouve... Acho que devo ir-me embora, certo?"

    # say L805 pla
    old "So, listen... I guess I should get going, right?"
    new "B:bel: Sim, provavelmente tens razão."

    # say L834 pla
    old "Uhm, I'm doing well, and you?"
    new "B:pla: Olá Belle."

    # say L838 bel
    old "So listen, after you left, my mom said it was very nice to meet you."
    new "B:pla: Hum, estou bem, e tu?"

    # say L840 pla
    old "S- she did?"
    new "T(pla|tu|say): S- sim?"

    # say L842 bel
    old "Yeah, she said that you seemed to be a good person."
    new "B:pla: E- ela disse?"

    # say L844 pla
    old "I- I guess that's nice."
    new "B:bel: Sim, ela disse que tu pareces ser uma boa pessoa."

    # say L846 bel
    old "It is, when she met Mike she went on an on about how rude he was."
    new "B:pla: I- Acho que isso é bom."

    # say L848 bel
    old "So, I'm glad she liked you."
    new "T(bel|tu|diz): Então, fico contente que ela tenha gostado de ti."

    # say L849 pla
    old "Uhh, w- well, that's great."
    new "B:bel: Então, fico contente que ela tenha gostado de ti."

    # say L851 bel
    old "Yeah, that may make things easier in the future."
    new "B:pla: Uhh, b- bem, isso é ótimo."

    # say L852 bel
    old "But leaving that aside, my mom told me she won't be home this afternoon."
    new "B:bel: Sim, isso pode facilitar as coisas no futuro."

    # say L854 bel
    old "So we can start streaming today!"
    new "B:bel: Mas deixando isso de lado, a minha mãe disse-me que não vai estar em casa esta tarde."

    # say L856 pla
    old "Ok... that sounds alright."
    new "B:bel: Então podemos começar a transmitir hoje!"

    # say L858 bel
    old "Ok, let's go to my house after classes then."
    new "A:bel: Ok, vamos à minha casa então."

    # say L887 bel
    old "Ok, let's go to my house then."
    new "Tudo bem, antes de começarmos há umas coisas que temos de verificar."

    # say L919 bel
    old "Alright, before we begin there's a couple of things we have to check."
    new "Tudo bem, antes de começarmos há um par de coisas que temos de verificar."

    # say L920 pla
    old "Oh... Ok."
    new "B:bel: Tudo bem, antes de começarmos temos que verificar algumas coisas."

    # say L922 bel
    old "You remember what I told you about how it's important to talk to the audience, right?"
    new "T(bel|tu|say): Tu lembras-te do que te disse sobre a importância de falar com o público, certo?"

    # say L925 bel
    old "You also remember that I told you I'm the one who's going to be talking to them, right?"
    new "B:bel: Tu lembras-te do que te disse sobre a importância de falar com o público, certo?"

    # say L926 pla
    old "Yeah, I do, no problem."
    new "B:bel: Tu também te lembras que eu disse que sou eu quem vai falar com eles, certo?"

    # say L928 bel
    old "Ok, I already announced that I was going to have a big surprise in today's stream."
    new "B:pla: Claro, sem problemas."

    # say L929 bel
    old "So, I'll come in on stream and start the whole thing."
    new "B:bel: Ok, já anunciei que ia ter uma grande surpresa no stream de hoje."

    # say L931 bel
    old "Talking to the audience, and when it's the right time, I'll tell you to come in."
    new "B:bel: Então, eu entro em direto e começo tudo."

    # say L933 pla
    old "Ok, I understand."
    new "B:bel: A falar para a audiência, e quando for o momento certo, direi para entrares."

    # say L935 bel
    old "The camera will be pointing in my direction."
    new "B:pla: Ok, percebi."

    # say L936 bel
    old "You'll wait out of frame while I start the stream, and when I tell you, you come in."
    new "B:bel: A câmara vai estar apontada para mim."

    # say L938 bel
    old "By the way, you won't be naked from the beginning... J- just wearing your shorts will be ok."
    new "B:bel: Vais esperar fora de quadro enquanto eu começo a transmissão, e quando eu te disser, tu entras."

    # say L940 pla
    old "Ok, I think I get it."
    new "B:bel: Por acaso, não vais estar nu desde o início... A- a usar só as tuas calças de banho já chega."

    # say L942 bel
    old "You know, [pla], I'm very thankful to you for doing this."
    new "Tu sabes, [pla], que estou muito grato por estares a fazer isto. Sei que isto é novo para ti e provavelmente não te sentes muito à vontade com isso."

    # say L945 bel
    old "So it means a lot to me that you're willing to help me this way."
    new "T(bel|tu|say): Então significa muito para mim que tu estejas disposto a ajudar-me desta forma."

    # say L950 pla
    old "I will admit I was very surprised when you asked me to do this."
    new "T: Tu deves admitir que fiquei muito surpreendida quando me pediste para fazer isto."

    # say L952 pla
    old "But you're a very good friend, and if this is important for you, then I'm happy to help you."
    new "B:pla: Admito que fiquei muito surpreendido quando me pediste para fazer isto."

    # say L955 bel
    old "Now, we should go to my room."
    new "B:pla: Mas tu és um amigo muito bom, e se isto é importante para ti, então estou feliz por te ajudar."

    # say L976 bel
    old "Now, before we start, I have to change. Wait here a minute."
    new "A:bel: Que cara é essa que estás a fazer?"

    # say L994 bel
    old "What are you making that face for?"
    new "B:bel: Agora, antes de começarmos, tenho que me trocar. Espera aqui um minuto."

    # say L997 pla
    old "Oh, n- nothing, you just..."
    new "B:bel: Porque estás a fazer essa cara?"

    # say L1001 pla
    old "I- I wasn't expecting it."
    new "B:pla: Oh, n- nada, tu apenas..."

    # say L1002 bel
    old "Well... thank you."
    new "B:pla: I- I não estava à espera disso."

    # say L1003 bel
    old "So, I'll start with the stream, and let you know when to come into frame, ok?"
    new "B:bel: Bem... obrigado."

    # say L1005 pla
    old "Right, sure."
    new "B:bel: Então, vou começar com o stream e aviso quando deves entrar em cena, ok?"

    # say L1020 bel
    old "Ok guys!"
    new "A:bel: Olá! Estão todos prontos para uma nova sessão?"

    # say L1021 bel
    old "Hello! Are you all ready for a new session?"
    new "B:bel: Ok pessoal!"

    # say L1022 bel
    old "I've missed you guys!"
    new "B:bel: Olá! Estão todos prontos para uma nova sessão?"

    # say L1023 bel
    old "Yes, I know I didn't stream the other day when I told you I would."
    new "B:bel: Senti a vossa falta!"

    # say L1024 bel
    old "But something came up, and it became impossible to start the stream."
    new "B:bel: Sim, sei que não transmiti naquele dia como tinha prometido."

    # say L1025 bel
    old "But I'm going to make it up to you guys!"
    new "B:bel: Mas surgiu algo e ficou impossível começar a transmissão."

    # say L1026 bel
    old "As I promised you, I have a big surprise today!"
    new "B:bel: Mas vou compensar-vos!"

    # say L1027 bel
    old "This is something a lot of you have been asking me about!"
    new "B:bel: Como te prometi, tenho uma grande surpresa para ti hoje!"

    # say L1028 bel
    old "So I decided to treat you!"
    new "B:bel: Isto é algo que muitos de vocês têm me perguntado!"

    # say L1029 bel
    old "This is my first time doing something like this on camera. So I'm a little nervous."
    new "B:bel: Então decidi tratar-te!"

    # say L1030 bel
    old "But I bet that if you show me your support by tipping, I'll feel a lot better."
    new "B:bel: Esta é a minha primeira vez a fazer algo assim em frente à câmara. Estou um pouco nervosa."

    # say L1031 bel
    old "Now, do you want to see the surprise I have in store for you?"
    new "B:bel: Mas aposto que se me mostrares o teu apoio com uma gorjeta, eu vou sentir-me muito melhor."

    # say L1033 bel
    old "This person is a very good friend of mine. And he's very excited to be joining me here in the stream today!"
    new "B:bel: Agora, tu queres ver a surpresa que tenho para ti?"

    # say L1034 bel
    old "Say hi to him!"
    new "B:bel: Esta pessoa é uma muito boa amiga minha. E está muito entusiasmado por se juntar a mim aqui no stream hoje!"

    # say L1039 bel
    old "Everyone, my friend is here because I promised you that you would see me having some fun with a real dick!"
    new "T(bel|tu|dizer): A todos, o meu amigo está aqui porque prometi que vocês veriam eu me divertindo com um pau de verdade!"

    # say L1040 bel
    old "And he came to help me with it."
    new "B:bel: Todos, o meu amigo está aqui porque prometi que veriam a diversão que eu vou ter com um pau de verdade!"

    # say L1041 bel
    old "Why don't we see what he's hiding under these shorts then?"
    new "B:bel: E ele veio ajudar-me com isso."

    # say L1049 bel
    old "Oh my god! Look at how big it is!"
    new "B:bel: Porque não vemos o que ele está a esconder debaixo destes calções?"

    # say L1050 bel
    old "I bet you want to see me play with this big dick, right?"
    new "B:bel: Meu Deus! Olha que grande é!"

    # say L1051 bel
    old "You want me to care for it, and play with it, don't you?"
    new "B: bel: Aposto que queres ver-me a brincar com esta pila grande, certo?"

    # say L1052 bel
    old "Let's not wait anymore for it then!"
    new "B:bel: Queres que eu cuide dele e brinque com ele, não é?"

    # say L1059 bel
    old "Oh! You have been waiting to see me play with your dick, haven't you?"
    new "B:bel: Então, vamos deixar de esperar!"

    # say L1060 bel
    old "I bet you love the way I stroke your big, thick, dick!"
    new "B:bel: Oh! Tu estavas à espera de me ver brincar com o teu pénis, não é?"

    # say L1072 bel
    old "I knew you were going to love what I had in store for you!"
    new "B:bel: Aposto que adoras a forma como te acaricio o teu pénis grande e grosso!"

    # say L1073 bel
    old "Thanks a lot for accomplishing the goals!"
    new "B:bel: Sabia que ias adorar o que tinha preparado para ti!"

    # say L1074 bel
    old "You guys have made me very happy!"
    new "B:bel: Muito obrigado por alcançarem os objetivos!"

    # say L1075 bel
    old "Now, sadly is time for me to disconnect, but be sure I'll come back soon."
    new "B:bel: Vocês fizeram-me muito feliz!"

    # say L1076 bel
    old "And, of course, my friend will be here, accompanying us once again."
    new "B:bel: Agora, infelizmente é hora de me desconectar, mas tenha a certeza que voltarei em breve."

    # say L1077 bel
    old "Don't forget to subscribe to the stream!"
    new "B:bel: E, claro, o meu amigo vai estar aqui, acompanhando-nos mais uma vez."

    # say L1078 bel
    old "So you will get a notification the next time I'm online guys!"
    new "B:bel: Não te esqueças de subscrever o stream!"

    # say L1079 bel
    old "And of course, don't forget to check all my socials!"
    new "B:bel: Então vocês vão receber uma notificação da próxima vez que eu estiver online!"

    # say L1080 bel
    old "Thanks a lot guys!"
    new "B:bel: E claro, não se esqueçam de seguir todas as minhas redes sociais!"

    # say L1081 bel
    old "See you soon..."
    new "B:bel: Muito obrigado, pessoal!"

    # say L1091 bel
    old "It's amazing how many tips we got!"
    new "B:bel: Até já..."

    # say L1092 bel
    old "I already thought that we were going to do well because my fans had never seen me doing something like this."
    new "B:bel: É incrível quantas gorjetas recebemos!"

    # say L1094 bel
    old "But this is far more than I expected!"
    new "B:bel: Eu já pensava que íamos correr bem porque os meus fãs nunca me tinham visto fazer algo assim."

    # say L1095 bel
    old "They really came through with the tipping!"
    new "B:bel: Mas isto é muito mais do que eu esperava!"

    # say L1096 bel
    old "We reached the goal in no time!"
    new "B:bel: Eles realmente se saíram bem com as gorjetas!"

    # say L1098 pla
    old "I'm very happy that it all came out better than you expected Belle."
    new "B:bel: Conseguimos o objetivo em pouco tempo!"

    # say L1100 pla
    old "That's very good."
    new "A:pla: Tu achas que com isto vais ultrapassar a Lana na votação?"

    # say L1101 pla
    old "Do you think that with this you'll surpass Lana in the voting?"
    new "B:pla: Isso está muito bom."

    # say L1102 bel
    old "It's hard to tell, I think I will."
    new "B:pla: Achas que com isto vais ultrapassar a Lana na votação?"

    # say L1103 bel
    old "But only temporarily, with this type of thing you never know for certain who's going to win until the end."
    new "B:bel: É difícil dizer, acho que vou."

    # say L1105 pla
    old "Does that mean you're going to need my help on another occasion?"
    new "B:bel: Mas só temporariamente, com este tipo de coisa nunca se sabe ao certo quem vai ganhar até ao fim."

    # say L1107 bel
    old "Oh, don't doubt it! This is only the first time you're appearing on camera with me."
    new "B:pla: Isso significa que vais precisar da minha ajuda noutra ocasião?"

    # say L1125 bel
    old "{i}I don't know!{/i}"
    new "B:pla: {i}W- o que é que ela está a fazer aqui?! Não ia estar de folga hoje?!{/i}"

    # say L1126 bel
    old "{i}Maybe she had some problems at work or something like that.{/i}"
    new "B:bel: {i}Não sei!{/i}"

    # say L1133 bel
    old "{i}Yeah, you're right.{i}"
    new "B:pla: {i}Melhor responderes-lhe, senão ela vai cá vir ver se tudo está bem.{i}"

    # say L1135 ash
    old "I see honey, ok!"
    new "A:bel: Acho que melhor nos vestirmos e sairmos daqui antes que ela venha ver como estou e nos veja assim."

    # say L1137 bel
    old "I think we better get dressed up and get out of here before she comes to check on me and sees us like this."
    new "T(bel|tu|diz): Acho que melhor vestirmo-nos e sairmos daqui antes que ela venha ver como estou e nos veja assim."

    # say L1138 pla
    old "Yeah, yeah, you're right."
    new "B:bel: Acho que melhor vestirmo-nos e sairmos daqui antes que ela venha ver como estou e nos veja assim."

    # say L1154 ash
    old "It's good seeing you again dear."
    new "A:ash: Vocês estão a trabalhar nesse trabalho da escola de que me falaram?"

    # say L1155 ash
    old "Are you guys working on that school work you told me about?"
    new "B:ash: É bom ver-te de novo, querida."

    # say L1157 pla
    old "Uh... y- yeah, t- that's right."
    new "A:bel: O que estás a fazer em casa, mãe? Não tinhas uma reunião importante de que tinhas falado?"

    # say L1160 bel
    old "What are you doing home mom? I thought you had that important meeting you had talked about."
    new "A:ash: Oh querido, não vais acreditar no que acabou de acontecer!"

    # say L1163 ash
    old "Oh honey, you won't believe what just happened!"
    new "A:ash: Hoje era para ser a minha primeira reunião de planeamento com a equipa."

    # say L1166 ash
    old "Today was supposed to be my first planning meeting with my team."
    new "B:ash: Oh querida, não vais acreditar no que acabou de acontecer!"

    # say L1167 ash
    old "You know, so we could make a marketing plan to show our clients."
    new "A:ash: Mas o programador web que tinha contratado repentinamente desistiu do acordo!"

    # say L1170 ash
    old "But the web developer I had hired suddenly backed out of the deal!"
    new "T(ash|tu|dizes): Mas o programador web que tinha contratado repentinamente desistiu do acordo!"

    # say L1173 ash
    old "Apparently he got a better job offer, and decided to take it."
    new "A:ash: Mas ele nem me deu um aviso ou algo assim, simplesmente desistiu sem dar sinal!"

    # say L1174 ash
    old "But he didn't even give me a heads up or anything, he just bailed without notice!"
    new "B:ash: Parece que ele recebeu uma proposta de trabalho melhor e decidiu aceitá-la."

    # say L1176 ash
    old "What am I going to do now?"
    new "B:ash: Mas ele nem me deu um aviso, simplesmente desistiu sem dizer nada!"

    # say L1177 bel
    old "Can't you just replace him, mom? I'm sure there must be someone out there that you can hire."
    new "B:ash: O que vou fazer agora?"

    # say L1179 ash
    old "If it was that easy I wouldn't have a problem."
    new "B:bel: Não podes simplesmente substituí-lo, mãe? Tenho a certeza de que deve haver alguém que tu possas contratar."

    # say L1180 ash
    old "Getting that web developer wasn't easy."
    new "B:ash: Se fosse assim tão fácil, eu não teria problema."

    # say L1182 ash
    old "You know my firm is only setting up here in town, so we can't actually offer anybody long-term contracts."
    new "B:ash: Arranjar esse desenvolvedor web não foi fácil."

    # say L1184 ash
    old "Finding somebody qualified that's willing to freelance for a while is very hard."
    new "A:ash: Mas já aceitámos o contrato, e os meus chefes esperam que lhes apresente um plano de marketing em breve!"

    # say L1185 ash
    old "But we already took the commission, and my bosses are expecting me to show them a marketing plan soon!"
    new "B:ash: Encontrar alguém qualificado que esteja disposto a trabalhar como freelancer por um tempo é muito difícil."

    # say L1187 ash
    old "Tell me dear, do you know of anybody that could help me?"
    new "B:ash: Mas já aceitámos a comissão, e os meus chefes esperam que eu lhes apresente um plano de marketing em breve!"

    # say L1188 bel
    old "Me? Why would I happen to know someone who is a web developer?"
    new "B:ash: Diz-me, querida, conheces alguém que possa ajudar-me?"

    # say L1190 ash
    old "I don't know, maybe someone from your school?"
    new "B:bel: Eu? Por que eu iria conhecer alguém que é desenvolvedor web?"

    # say L1192 bel
    old "Well, I'm sorry to disappoint you, mom, but I don't know any web developers..."
    new "B:ash: Não sei, talvez alguém da tua escola?"

    # say L1194 ash
    old "I see... that's disappointing."
    new "B:bel: Bem, sinto desiludir-te, mãe, mas não conheço nenhum desenvolvedor web..."

    # say L1207 bel
    old "MOM! What are you talking about? Don't rope him into this!"
    new "B:ash: Eu vejo... isso é desapontante."

    # say L1209 ash
    old "Well honey, I'm sorry if you don't like me asking your friend for help."
    new "B:bel: MÃE! Do que estás a falar? Não o envolvas nisto!"

    # say L1212 ash
    old "But I'm in a very thought spot right now, I need whatever help I can get."
    new "B:ash: Bem querida, sinto muito se não gostas de eu pedir ajuda à tua amiga."

    # say L1219 ash
    old "Really? Are you a web developer?"
    new "B:pla: Bem... Na verdade, eu- eu acho que... Talvez eu possa ajudar."

    # say L1222 pla
    old "Well, I'm not a professional, but I have a little bit of experience."
    new "B:ash: Mesmo? Tu és desenvolvedor web?"

    # say L1227 pla
    old "And... I have been doing the maintenance ever since."
    new "E... tenho feito a manutenção desde então."

    # say L1230 ash
    old "And you think you could help me with this?"
    new "B:pla: E... tenho estado a fazer a manutenção desde então."

    # say L1232 pla
    old "W- well, I think so, I would have to see first what it is that you need me to do, though."
    new "B:ash: E tu achas que podes ajudar-me com isto?"

    # say L1234 ash
    old "That's wonderful [pla]! Oh my God! I would love it if you could help me."
    new "T: Isso é maravilhoso [pla]! Oh meu Deus! Adorava que tu pudesses ajudar-me."

    # say L1238 ash
    old "But I think you could help me with the planning of it, while I find a web developer to hire."
    new "B:ash: Talvez pedir-te para fazer todo o site agora seja pedir demasiado."

    # say L1240 ash
    old "It would only be a few times that I would need your help with the planning."
    new "B:ash: Mas acho que tu podes ajudar-me com o planeamento, enquanto procuro um desenvolvedor web para contratar."

    # say L1242 pla
    old "Hmm... Sure, I think I could do that."
    new "Hmm... Claro, acho que consigo fazer isso."

    # say L1244 ash
    old "That's great!"
    new "E não te preocupes, vou garantir que sejas devidamente compensado por isso. Posso adicionar o custo ao orçamento."

    # say L1245 ash
    old "And don't worry, I'll make sure you get properly compensated for it. I can add the cost to the budget."
    new "E não te preocupes, vou garantir que sejas devidamente compensado por isso. Posso adicionar o custo ao orçamento. Assim, não deverá haver qualquer problema com o teu pagamento."

    # say L1246 ash
    old "So, there shouldn't be any problem with your pay."
    new "A:pla: E-Eu vejo... E, e-eu devo ir ao teu escritório mais tarde?"

    # say L1248 pla
    old "I- I see... So, s- should I come to your office later?"
    new "T(pla|tu|say): E-Eu vejo... Então, de-devo ir ao teu escritório mais tarde?"

    # say L1250 ash
    old "Actually, I'm not sure if that would be a good idea because I wouldn't want the firm's directors to know about this."
    new "B:pla: I- I vejo... Então, de- devo ir ao teu escritório mais tarde?"

    # say L1252 ash
    old "I think it's better if we just work here at home."
    new "T(ash|tu|dizes): Acho melhor se trabalharmos aqui em casa."

    # say L1259 ash
    old "But don't worry, we won't be starting right away, you can come back on another occasion and I'll let you know what the job is about."
    new "B:ash: Agora, deixei alguns documentos que precisas no escritório, vou buscar."

    # say L1261 pla
    old "Alright, I'll be sure to do it."
    new "B:ash: Mas não te preocupes, não vamos começar já, podes voltar noutra ocasião e eu explico-te do que se trata o trabalho."

    # say L1270 bel
    old "I can't believe you're actually going to help her with that."
    new "A:bel: Não achas que isso vai atrapalhar a nossa transmissão?"

    # say L1272 bel
    old "Don't you think that's going to get in the way of us doing the stream?"
    new "B:bel: Não acredito que tu vais realmente ajudá-la com isso."

    # say L1274 pla
    old "In fact, I think it's convenient for us because since she needs me to work here, we'll know more accurately when she will be here and when she won't."
    new "B:bel: Não achas que isso vai atrapalhar a nossa transmissão?"

    # say L1277 bel
    old "But still, I'm sorry my mom is putting you up to this."
    new "B:pla: Na verdade, acho conveniente para nós, porque como ela precisa de mim para trabalhar aqui, saberemos com mais precisão quando ela estará aqui e quando não estará."

    # say L1279 pla
    old "Don't worry about it, I'm happy to help."
    new "Não te preocupes, estou feliz por ajudar."

    # say L1280 bel
    old "Yeah, I know."
    new "B:pla: Não te preocupes, estou feliz em ajudar."

    # say L1281 bel
    old "You're being very nice helping both my mom and me like this."
    new "T(bel|tu|dizer): Estás a ser muito simpático a ajudar tanto a minha mãe como a mim assim."

    # say L1282 bel
    old "That's very good of you [pla]."
    new "T(bel|tu|diz): É muito bom de ti [pla]."

    # say L1284 pla
    old "Thanks for saying that."
    new "A:pla: Olá, acho que devo ir embora, afinal, acabamos de terminar a transmissão, aposto que queres tomar um duche ou algo assim."

    # say L1291 pla
    old "Hey, so I think I should get going, after all, we just finished streaming, I bet you want to take a shower or something."
    new "T(pla|tu|say): Olá, acho que devo ir embora, afinal, acabamos de terminar a transmissão, aposto que queres tomar um duche ou algo assim."

    # say L1325 bel
    old "Hi [pla]! I have great news!"
    new "T(bel|tu|say): Olá [pla]! Tenho grandes notícias!"

    # say L1332 bel
    old "I'm number one now!"
    new "B:bel: Os resultados da sondagem de ontem saíram esta manhã!"

    # say L1334 pla
    old "That's great belle!"
    new "B:bel: Sou a número um agora!"

    # say L1335 pla
    old "I'm very happy for you."
    new "B: pla: Is ótimo, bela!"

    # say L1337 bel
    old "Thanks, this is wonderful!"
    new "B:pla: Estou muito feliz por ti."

    # say L1339 bel
    old "She's been appearing with a guy on stream for longer, so I didn't know if I would be able to catch her with just one stream."
    new "B:bel: Obrigado, isto é maravilhoso!"

    # say L1341 bel
    old "But my fans really liked it!"
    new "B:bel: Ela tem aparecido com um rapaz na transmissão durante mais tempo, por isso não sabia se conseguiria apanhá-la com apenas uma transmissão."

    # say L1343 bel
    old "If we keep going like this, she won't have any chance of catching me!"
    new "B:bel: Mas os meus fãs gostaram muito!"

    # say L1345 pla
    old "That sounds great."
    new "B:bel: Se continuarmos assim, ela não terá hipótese nenhuma de me apanhar!"

    # say L1348 pla
    old "So, when it's the next stream?"
    new "B:pla: Isso soa ótimo."

    # say L1349 bel
    old "Well, that's where we have a little bit of a problem."
    new "B:pla: Então, quando é o próximo stream?"

    # say L1350 pla
    old "Why? What happened?"
    new "A:bel: Tu vês, eu já tinha pensado no que vamos fazer a seguir."

    # say L1352 bel
    old "You see, I had already thought about what we're going to do next."
    new "B:pla: Porquê? O que aconteceu?"

    # say L1353 bel
    old "My fans have been asking for me to do cosplay for a while, so I thought now it would be a good occasion."
    new "Cosplay?"

    # say L1354 pla
    old "Cosplay?"
    new "B:bel: Os meus fãs têm-me pedido para fazer cosplay há algum tempo, por isso achei que agora seria uma boa ocasião."

    # say L1356 bel
    old "Yes, we can't just repeat the same as last time."
    new "B:pla: Cosplay?"

    # say L1357 bel
    old "If we just do the same thing over and over the audience will get bored."
    new "T(bel|tu|say): Se fizermos sempre a mesma coisa, o público vai ficar entediado."

    # say L1358 bel
    old "We have to give them some variety."
    new "T(bel|tu|say): Temos de lhes dar alguma variedade."

    # say L1362 bel
    old "But you see, I don't know when the next stream will be."
    new "B:bel: Temos de lhes dar alguma variedade."

    # say L1363 bel
    old "I already know what character I want to do."
    new "B:bel: Mas tu vês, eu não sei quando será o próximo stream."

    # say L1364 bel
    old "It's somewhat of an interesting character, and my fans seem to have a fixation for that type of girl."
    new "B:bel: Já sei qual personagem quero fazer."

    # say L1365 bel
    old "So I wanted to please them, I even ordered for the cosplay to be delivered by express shipping."
    new "B:bel: É um personagem algo interessante, e os meus fãs parecem ter uma fixação por esse tipo de rapariga."

    # say L1367 bel
    old "But it turns out there was a mixup when I placed my order, when I bought it they had alredy sold it!"
    new "T(bel|tu|say): Mas resulta que houve um engano quando fiz o pedido, quando comprei já tinham vendido!"

    # say L1368 bel
    old "And they don't seem to have any more!"
    new "B:bel: Mas afinal houve um engano quando fiz o pedido, quando comprei já tinham vendido!"

    # say L1370 bel
    old "I have been looking for that same cosplay in other websites, but I can't find it!"
    new "B:bel: E não parecem ter mais!"

    # say L1371 bel
    old "And I already promised the audience that's the character I was going to do."
    new "B:bel: Tenho estado à procura desse mesmo cosplay noutros sites, mas não consigo encontrar!"

    # say L1372 bel
    old "I guess we'll have to postpone it for another time."
    new "T(bel|tu|say): Acho que vamos ter de adiar para outra vez."

    # say L1374 bel
    old "Besides, you also have to go help my mom with that website thing..."
    new "B:bel: Acho que vamos ter que adiar para outra vez."

    # say L1376 bel
    old "Ugh, this annoys me so much, Lana's going to overtake me again!"
    new "B:bel: Além disso, também tens de ir ajudar a minha mãe com aquela coisa do site..."

    # say L1385 bel
    old "If you could, that would be wonderful."
    new "B:pla: Bem, não é certo, vou ter de perguntar, mas acho que é possível."

    # say L1386 pla
    old "I'll ask with my [sisRel] this afternoon, after classes."
    new "T: Vou perguntar com o meu [sisRel] esta tarde, depois das aulas."

    # say L1388 bel
    old "Sure, thanks a lot [pla]."
    new "T(bel|tu|diz): Claro, obrigado [pla]."

    # say L1413 sis
    old "I'm doing pretty well, working on a new collection."
    new "Estou um bocado ocupado, a trabalhar numa nova coleção."

    # say L1414 pla
    old "Uhh, so are you busy?"
    new "B:sis: Estou bem, a trabalhar numa nova coleção."

    # say L1415 sis
    old "Uhh a little bit, Why? What do you need?"
    new "B:pla: Uhh, então estás ocupado?"

    # say L1417 pla
    old "Well, I was wondering if you could help me with getting a cosplay."
    new "B:sis: Uhh um pouco, porquê? O que precisas?"

    # say L1418 sis
    old "A cosplay? I didn't know you were into that kind of stuff..."
    new "B:pla: Bem, estava a pensar se tu poderias ajudar-me a arranjar um cosplay."

    # say L1421 sis
    old "Anyway, what kind of cosplay is it? Like a superhero or something?"
    new "T(sis|tu|diz): Então, de que tipo de cosplay é? De um super-herói ou algo assim?"

    # say L1423 pla
    old "Uhh, it's actually a female cosplay, it's a famous character from a videogame."
    new "T(pla|tu|say): É na verdade um cosplay de mulher, é uma personagem famosa de um videogame."

    # say L1424 sis
    old "A female cosplay? Why do you need that?"
    new "B:pla: Uhh, na verdade é um cosplay de mulher, é uma personagem famosa de um vídeojogo."

    # say L1426 sis
    old "Don't tell me you're thinking of becoming a drag queen."
    new "B:sis: Um cosplay feminino? Por que precisas disso?"

    # say L1428 pla
    old "W- what? Of course not!"
    new "B:sis: Não me digas que estás a pensar tornar-te uma drag queen."

    # say L1430 pla
    old "It's for a friend of mine that needs it."
    new "B:pla: O- o quê? Claro que não!"

    # say L1432 sis
    old "Oh! Is that so? And why are you getting it for her? Are you two doing something naughty?"
    new "B:pla: É para uma amiga que precisa."

    # say L1434 pla
    old "N- no, we're not, I'm just doing her a favor because she needs it. That's all."
    new "B:sis: Oh! É mesmo? E por que estás a fazê-lo para ela? Vocês estão a fazer algo travesso?"

    # say L1436 sis
    old "Haha! Relax, I'm just messing with you."
    new "B: N- não, não estamos, estou só a fazer-lhe um favor porque ela precisa. É só isso."

    # say L1438 sis
    old "I don't mind what you're doing with your friend."
    new "B: Irmã: Haha! Relaxa, estou só a brincar contigo."

    # say L1439 sis
    old "As long as you keep helping me with my business, you can do whatever you want."
    new "B: Irmã: Não me importo com o que estás a fazer com a tua amiga."

    # say L1441 sis
    old "I'll get you the cosplay, it should be easy to get it here soon."
    new "B:sis: Desde que continues a ajudar-me com o meu negócio, podes fazer o que quiseres."

    # say L1445 sis
    old "I'll let you know when it's ready."
    new "B: Irmã: Estou feliz em ajudar."

    # say L1472 ash
    old "Just Ashley dear, remember what I told you, no need for the Mrs."
    new "B:pla: Olá Sra. Ash-"

    # say L1473 pla
    old "Uhh... Right."
    new "A:pla: Olá A- Ashley."

    # say L1474 pla
    old "Hi A- Ashley."
    new "B:pla: Uhh... Certo."

    # say L1476 ash
    old "That's better."
    new "A:ash: Como tens estado, meu amor?"

    # say L1477 ash
    old "How have you been honey?"
    new "B:ash: Assim está melhor."

    # say L1479 ash
    old "Is school going well?"
    new "B:ash: Como tens estado, querida?"

    # say L1481 pla
    old "Uhh? Y- yeah. I- I have been studying a lot..."
    new "B:ash: A escola está a correr bem?"

    # say L1482 ash
    old "That's great dear."
    new "B:pla: Huh? Y- yeah. T- tenho estado a estudar muito..."

    # say L1484 pla
    old "Uh... Listen, A- Ashley, about the w- website."
    new "T(pla|tu|say): Uh... Escuta, A- Ashley, sobre o s- site."

    # say L1486 ash
    old "Right! We should focus on that."
    new "A:pla: Claro, mas não tenho a certeza do que vou fazer exatamente."

    # say L1488 pla
    old "Sure ma'am. But I'm not entirely sure what it is that I will be doing."
    new "T(pla|tu|say): Claro, senhora. Mas não tenho a certeza do que vou fazer exatamente."

    # say L1493 pla
    old "Uh... Sure, no problem."
    new "T: Uh... Claro, sem problemas."

    # say L1505 pla
    old "Then, it will take you to the payment portal. And there you can finalize the purchase."
    new "B:pla: E se clicares aqui podes fazer um pedido."

    # say L1509 ash
    old "Actually, this is more than what I need you to do."
    new "B:ash: Isto é de uma qualidade muito alta, até melhor do que o trabalho de alguns dos desenvolvedores com quem já trabalhei."

    # say L1512 ash
    old "After seeing this, I'm thinking that you could just take the full job of developing the website for the client."
    new "B:ash: Na verdade, isto é mais do que preciso de ti."

    # say L1516 ash
    old "Come on, why are you surprised? You did a very good job with this website."
    new "T(ash|tu|dizes): Vamos, por que estás surpreendido? Fizeste um excelente trabalho com este site."

    # say L1518 ash
    old "And as I told you, this is even more than what I need to be done for the marketing campaign."
    new "B:ash: Vamos, por que estás surpreendido? Fizeste um excelente trabalho com este site."

    # say L1519 ash
    old "You could just do the job by yourself."
    new "E realmente ajudaria muito, porque não teria de procurar alguém para terminar o projeto."

    # say L1521 ash
    old "And It would really help me, because I wouldn't have to look for someone to finish the project."
    new "A:pla: Quero dizer, é uma oferta muito generosa, hã... Ashley, m-mas não tenho a certeza se tenho a experiência necessária para o fazer."

    # say L1522 pla
    old "I mean, that's a very nice offer, uh... Ashley, b- but I'm not sure if I have the experience to do it."
    new "Quer dizer, é uma oferta muito generosa, uh... Ashley, mas não tenho a certeza se tenho a experiência necessária para o fazer. Seria muita responsabilidade."

    # say L1523 pla
    old "It would be a lot of responsability."
    new "B:pla: Quero dizer, é uma oferta muito generosa, hã... Ashley, mas não tenho a certeza se tenho a experiência necessária para o fazer."

    # say L1525 ash
    old "Don't worry about it, dear. I'll accompany you every time you work on it, so I'll tell you exactly what I need from you."
    new "B:pla: Seria muita responsabilidade."

    # say L1529 pla
    old "Alright, if you think it's ok for me to do it, I guess I can take the job."
    new "B:ash: Não te preocupes com isso, querida. Vou acompanhar-te todas as vezes que trabalhares nisso, então vou-te dizer exatamente o que preciso de ti."

    # say L1531 ash
    old "Great! That's just what I wanted to hear."
    new "Ótimo! É exactamente o que queria ouvir."

    # say L1533 pla
    old "Ok, but what exactly is the type of website that I'm going to be working on? Is it an e-commerce?"
    new "T(pla|tu|say): Ok, mas que tipo de site é que vou estar a trabalhar? É um de e-commerce?"

    # say L1534 ash
    old "Not really, what I need you to make is one where we can show a lot of information about a business."
    new "T(ash|tu|say): Não, o que preciso que faças é um site onde possamos mostrar muita informação sobre um negócio. O negócio em questão é uma loja de café orgânico que ficou muito popular aqui na cidade."

    # say L1535 ash
    old "The business in question is an organic coffee shop that's gotten very popular here in the city."
    new "B:ash: Não realmente, o que preciso que faças é um onde possamos mostrar muita informação sobre um negócio."

    # say L1536 ash
    old "And they're looking to expand their business by franchising outside of town."
    new "Eles estão a pensar expandir o negócio através de franchising para fora da cidade. Entendo. Então eles contrataram-te para fazer a campanha de marketing?"

    # say L1537 pla
    old "I see. So they hired you to do their marketing campaign?"
    new "T(pla|tu|say): Entendo. Então eles contrataram a tua empresa de marketing para fazer a campanha?"

    # say L1539 ash
    old "Not me, my marketing firm. I'm just leading my team."
    new "B:pla: Entendo. Então eles contrataram a tua empresa de marketing para a campanha?"

    # say L1541 ash
    old "But, I still have the responsibility for the entire marketing plan."
    new "B:ash: Não eu, a minha empresa de marketing. Eu estou apenas a liderar a equipa."

    # say L1543 ash
    old "Because the clients already paid for the service, and I already received the budget."
    new "B:ash: Mas, ainda tenho a responsabilidade por todo o plano de marketing."

    # say L1545 ash
    old "That's why it's so bad that the web developer quit all of a sudden. Because he put me in a very difficult position."
    new "B:ash: Porque os clientes já pagaram pelo serviço, e eu já recebi o orçamento."

    # say L1547 pla
    old "I understand, I'm sorry that happened."
    new "B:ash: É por isso que é tão mau que o programador web tenha saído de repente. Porque me colocou numa posição muito difícil."

    # say L1549 ash
    old "That's very nice of you dear, thank you."
    new "B:pla: Entendo, sinto muito que isso tenha acontecido."

    # say L1550 ash
    old "Now, why don't we get started and I'll tell you what to do along the way?"
    new "B:ash: Isso é muito gentil de tua parte, querida, obrigada."

    # say L1562 ash
    old "Ok, now please put the title in higher case."
    new "B:ash: Agora, porque não começamos e eu vou-te dizer o que fazer pelo caminho?"

    # say L1564 ash
    old "That's it, perfect. Could you also make those pictures a little bigger?"
    new "B:ash: Ok, agora coloca o título em maiúsculas."

    # say L1565 ash
    old "I want the raw coffee shots to be front and center."
    new "A:pla: Ok, é porque são da tua marca?"

    # say L1567 pla
    old "Ok, is that because of their brand?"
    new "T: Ok, é por causa da marca deles?"

    # say L1569 ash
    old "That's right, they want to show themselves as an organic coffee business, that's a contrast to the bigger coffee chains you see everywhere."
    new "B:pla: Ok, é por causa da marca deles?"

    # say L1570 pla
    old "I see, I think I get it."
    new "B:ash: É isso, eles querem mostrar-se como um negócio de café orgânico, em contraste com as grandes cadeias de cafés que vemos por todo o lado."

    # say L1574 ash
    old "Well, the whole point of marketing is developing and delivering the message the client wants to show."
    new "B:pla: Entendo, acho que percebi."

    # say L1575 ash
    old "So, I really enjoy the process of using optics and messaging to find good ways to attract attention to our clients."
    new "B:ash: Bem, o objetivo principal do marketing é desenvolver e entregar a mensagem que o cliente quer mostrar."

    # say L1576 pla
    old "That's really cool Ashley."
    new "Isso é realmente fixe, Ashley."

    # say L1577 ash
    old "Thanks dear..."
    new "B:pla: Isso é realmente incrível, Ashley."

    # say L1578 ash
    old "Now, let's keep going."
    new "B:ash: Obrigado, querida..."

    # say L1590 ash
    old "Yes! That's exactly what I wanted!"
    new "B:ash: Agora, vamos continuar."

    # say L1594 ash
    old "I'm sure they will, this is turning out better than what I expected."
    new "B:pla: O- Obrigado, Ashley, espero que os teus chefes também gostem."

    # say L1595 ash
    old "Actually, I think you've done enough for today."
    new "T(ash|tu|diz): Na verdade, acho que já fizeste o suficiente para hoje. Por que não paramos e continuamos noutro dia?"

    # say L1596 ash
    old "Why don't we stop and continue another day?"
    new "B:ash: Na verdade, acho que já fizeste o suficiente para hoje."

    # say L1606 pla
    old "Thanks ma'am, I'm sure we will."
    new "T: Obrigado, senhora, tenho a certeza de que sim."

    # say L1608 pla
    old "So, I- I guess I should leave for know."
    new "T(pla|tu|say): Então, a- acho que devo ir agora."

    # say L1610 ash
    old "Wait, before you go, I wanted to ask you about how much time you have available to work on this."
    new "B:pla: Então, acho que devo ir agora."

    # say L1612 ash
    old "You're a student after all. I wouldn't want to use all of your time."
    new "B:ash: Espera, antes de ires, queria perguntar-te quanto tempo tens disponível para trabalhar nisto."

    # say L1613 ash
    old "But if I'm honest, I could use your help as often as possible."
    new "B:ash: Afinal, és estudante. Não quero ocupar todo o teu tempo."

    # say L1615 ash
    old "So, it occurs to me that you could tell me when it works best for you."
    new "B:ash: Mas se for sincero, podia precisar da tua ajuda o mais possível."

    # say L1616 ash
    old "For us to work on the website."
    new "A:pla: Eu- Eu acho que posso vir... Talvez de dois em dois dias e trabalhar contigo?"

    # say L1619 pla
    old "I- I guess I could come... Maybe every other day and work with you?"
    new "B:ash: Para nós trabalharmos no site."

    # say L1621 ash
    old "That's just perfect for me!"
    new "B:pla: Eu... Acho que posso vir... Talvez de dois em dois dias e trabalhar contigo?"

    # say L1622 pla
    old "Great, that's good to hear."
    new "Ótimo, fico contente por tu. A:pla: Já está a ficar um pouco tarde, então acho que vou para casa agora, Ashley."

    # say L1623 pla
    old "Alright, it's getting a bit late, so,I think I'll go home now, Ashley."
    new "B:pla: Ótimo, isso é bom de ouvir."

    # say L1625 ash
    old "Sure dear, thanks again for your great help."
    new "B:pla: Está a ficar um pouco tarde, então, acho que vou para casa, Ashley."

    # say L1626 pla
    old "You're welcome, see you later."
    new "B:ash: Claro, querida, obrigada mais uma vez pela tua grande ajuda. T(pla|tu|say): De nada, até mais. A:ash: Até logo, meu amor."

    # say L1628 ash
    old "See you honey."
    new "B:pla: De nada, até mais."

    # say L1653 pla
    old "Really? It arrived this quickly? That's great!"
    new "B:sis: Ouve, o teu cosplay chegou."

    # say L1654 sis
    old "Well, I have a direct contact, and they always send it via express delivery."
    new "B:pla: Mesmo? Chegou assim tão depressa? Que bom!"

    # say L1655 pla
    old "Oh, that's great."
    new "B:sis: Bem, tenho um contacto direto, e eles sempre enviam por entrega expressa."

    # say L1656 sis
    old "Come with me, the package is in my bedroom."
    new "B:pla: Oh, isso é ótimo."

    # say L1657 pla
    old "Oh, right."
    new "B: Irmã: Vem comigo, o pacote está no meu quarto."

    # say L1672 sis
    old "Wait here."
    new "B:pla: Oh, certo."

    # say L1685 sis
    old "Here it is."
    new "B: Irmã: Espera aqui."

    # say L1687 sis
    old "I ordered it directly from a producer."
    new "B: Irmã: Aqui está."

    # say L1689 sis
    old "I knew that you needed it quickly, right?"
    new "B: I encomendei diretamente ao produtor."

    # say L1693 pla
    old "This is great, thanks a lot."
    new "B:sis: Eu sabia que tu precisavas disto rapidamente, certo?"

    # say L1694 sis
    old "Don't worry about it, I'm happy to help you."
    new "Não te preocupes, estou feliz por te ajudar. Espero que o teu amigo goste."

    # say L1719 bel
    old "She won't be, so we can stream today as well!"
    new "A:pla: Queres transmitir já?"

    # say L1721 pla
    old "You want to stream right away?"
    new "B:bel: Ela não vai, então podemos transmitir hoje também!"

    # say L1722 bel
    old "Of course, we have to."
    new "B:pla: Queres começar a transmitir já?"

    # say L1724 bel
    old "Lana has been putting up a lot of new content, I can't let any more time pass by."
    new "B:bel: Claro, temos que."

    # say L1726 pla
    old "Yeah, you're right, I'll bring the cosplay after classes. Ok?"
    new "B:bel: A Lana tem estado a colocar muito novo conteúdo, não posso deixar passar mais tempo."

    # say L1727 bel
    old "Yeah, perfect."
    new "B:pla: Sim, tens razão, vou levar o cosplay depois das aulas. Ok?"

    # say L1753 bel
    old "Ok, so you'll pick up the cosplay at your house and I'll set up the stream. Ok?"
    new "B:bel: Sim, perfeito."

    # say L1754 pla
    old "Sure, I'll be there right away."
    new "T(pla|tu|say): Claro, estarei aí já de seguida. A:pla: Olá Belle, aqui está."

    # say L1770 pla
    old "Hey Belle, here it is."
    new "B:pla: Claro, estarei aí já."

    # say L1775 bel
    old "Great! Let's go up to my room and I'll try it on."
    new "B:pla: Olá Belle, aqui está."

    # say L1796 bel
    old "Ok, I'll put it on."
    new "T(bel|tu|say): Ok, vou vesti-lo."

    # say L1808 bel
    old "So, what do you think?"
    new "B:bel: Ok, vou pôr."

    # say L1810 pla
    old "You look great Belle!"
    new "T(pla|tu|say): Tu estás ótima, Belle!"

    # say L1811 pla
    old "It really fits you."
    new "B:pla: Tu estás ótima, Belle!"

    # say L1812 bel
    old "I'm happy you like it."
    new "B:pla: Fica-te muito bem."

    # say L1813 bel
    old "Let's get started with the stream then."
    new "B:bel: Fico feliz que tu gostes."

    # say L1828 bel
    old "Ok guys, it's time for another good time!"
    new "T(bel|tu|say): Ok pessoal, é hora de mais um bom momento!"

    # say L1829 bel
    old "What do you think of the cosplay that I prepared for you?"
    new "B:bel: Ok pessoal, é hora de mais uma boa diversão!"

    # say L1830 bel
    old "I know you have been waiting to see me like this, so be sure to enjoy!"
    new "B:bel: Que achas do cosplay que preparei para ti?"

    # say L1831 bel
    old "But that's not all."
    new "B:bel: Eu sei que tu estavas à espera de me ver assim, então aproveita bem!"

    # say L1832 bel
    old "Since you guys liked to see my friend so much last time, I brought him here again!"
    new "B:bel: Mas isso não é tudo."

    # say L1833 bel
    old "So say hi to him again!"
    new "B:bel: Como vocês gostaram tanto de ver o meu amigo da última vez, trouxe-o aqui de novo!"

    # say L1839 bel
    old "Ok, guys, let's not waste any more time."
    new "B:bel: Diz-lhe olá de novo!"

    # say L1840 bel
    old "I know you've been waiting for it, so let's get to it."
    new "B:bel: Ok, pessoal, não vamos perder mais tempo."

    # say L1847 bel
    old "OH! God! This cock!"
    new "B:bel: Eu sei que estavas à espera disto, então vamos lá."

    # say L1848 bel
    old "I love it! It's just the best taste in the world!"
    new "B:bel: OH! Meu Deus! Este pénis!"

    # say L1849 bel
    old "Your dick is so big guys!"
    new "B:bel: Adoro! É o melhor sabor do mundo!"

    # say L1861 bel
    old "I'm happy you enjoyed the stream and my cosplay!"
    new "B:bel: O teu pénis é tão grande, rapazes!"

    # say L1862 bel
    old "After all, I'm doing this for all of you!"
    new "B:bel: Fico feliz que tenhas gostado do stream e da minha cosplay!"

    # say L1863 bel
    old "I'll end the stream here for now."
    new "B:bel: Afinal, estou a fazer isto por todos vocês!"

    # say L1864 bel
    old "But be sure that I'll come back soon."
    new "B:bel: Vou terminar o stream aqui por agora."

    # say L1865 bel
    old "As always, remember to subscribe to the stream."
    new "B:bel: Mas tenha a certeza que vou voltar logo."

    # say L1866 bel
    old "And you’ll be notified every time I’m online!"
    new "T(bel|tu|say): E vais ser notificado sempre que eu estiver online!"

    # say L1867 bel
    old "And of course, remember to check out my social media links!"
    new "B:bel: E serás notificado sempre que eu estiver online!"

    # say L1868 bel
    old "Thans for your support guys!"
    new "B:bel: E claro, não se esqueçam de ver os meus links das redes sociais!"

    # say L1869 bel
    old "See you later, bye!"
    new "B:bel: Obrigado pelo apoio, pessoal!"

    # say L1879 bel
    old "I'm sure that with this, Lana will not have a chance to catch me!"
    new "B:bel: Até mais, adeus!"

    # say L1881 pla
    old "Awesome!"
    new "T:plu: Depois de todo o trabalho que tu deste, é incrível!"

    # say L1883 pla
    old "After all you've worked really hard for this."
    new "B:pla: Fantástico!"

    # say L1887 pla
    old "I think I'll head back home before your mother arrives."
    new "B:pla: Afinal, tu trabalhaste muito para isto."

    # say L1888 bel
    old "Alright, I'll let you know how the voting goes tomorrow."
    new "B:pla: Acho que vou voltar a casa antes da tua mãe chegar."

    # say L1889 pla
    old "Sure, I'm sure it's going to go great."
    new "Olá, Ashley, estou bem, obrigado."

    # say L1906 pla
    old "Hi, Ashley, I'm fine thank you."
    new "B:pla: Claro, tenho a certeza de que vai correr bem."

    # say L1907 ash
    old "That's good, tell me, is there anything I can help you with?"
    new "B:pla: Olá, Ashley, estou bem, obrigado."

    # say L1915 pla
    old "Well, I was thinking that I could keep helping you with developing the website."
    new "B:ash: Isso é bom, conta-me, há algo em que eu possa ajudar-te?"

    # say L1926 pla
    old "Oh, not much, I was just passing by."
    new "B:ash: Ok, espera aqui um minuto que eu vou preparar tudo."

    # say L1929 ash
    old "Please remember to come work on the website project soon. The deadline is coming soon."
    new "B:pla: Oh, não muito, só estava a passar por aqui."

    # say L1933 ash
    old "Thank you [pla], I'll see you later then."
    new "Obrigado [pla], vejo-te mais tarde então."

    # say L1948 pla
    old "Alright, what are we doing?"
    new "B:ash: Ok, então para hoje quero que nos concentremos numa nova parte do projeto."

    # say L1950 ash
    old "Let's get started and I'll explain to you along the way."
    new "T(ash|tu|diz): Vamos começar e eu explico-te ao longo do caminho."

    # say L1967 ash
    old "Ok, Ok, I really like how this turned out."
    new "B:ash: Vamos começar e eu explico-te ao longo do caminho."

    # say L1968 ash
    old "I think we can move on to the next category."
    new "A:pla: Mesmo? Não queres fazer nenhum ajuste?"

    # say L1971 pla
    old "Really? Don't you want to use make any corrections?"
    new "B:ash: Acho que podemos passar para a próxima categoria."

    # say L1973 ash
    old "Not right now, because I haven't  seen how it works with other areas of the website."
    new "B:pla: Mesmo? Não queres fazer quaisquer correções?"

    # say L1975 ash
    old "So, let's shift our focus to those, and then we can make any pertinent corrections."
    new "B:ash: Não agora, porque ainda não vi como isso funciona com outras áreas do site."

    # say L1977 pla
    old "I see, ok, let's do that."
    new "T(pla|tu|say): Entendo, ok, vamos fazer isso."

    # say L1983 ash
    old "Alright [pla], I think that was enough for today. I think we can continue this another time."
    new "T(ash|tu|diz): Tudo bem [pla], acho que foi o suficiente para hoje. Podemos continuar noutra altura."

    # say L1985 pla
    old "You're welcome. My pleasure to help you."
    new "T(pla|tu|say): De nada. É um prazer ajudar-te."

    # say L1986 ash
    old "Now, it's a little late, so why don't you go home and rest?"
    new "B:pla: De nada. Foi um prazer ajudar-te."

    # say L1988 pla
    old "Yeah, you're right. See you later Ashley."
    new "B:ash: Agora, já é um pouco tarde, por que não vais para casa e descansas?"

    # say L1989 ash
    old "See you later hon."
    new "A:pla: Olá Belle, como estás?"

    # say L2019 pla
    old "Hi Belle, how are you?"
    new "T(pla|tu|say): Olá Belle, como estás?"

    # say L2021 pla
    old "What? What's with that expresion?"
    new "B:pla: Olá Belle, como estás?"

    # say L2022 pla
    old "Is there anything wrong?"
    new "B: pla: O quê? Que expressão é essa?"

    # say L2024 bel
    old "I guess you could say there is."
    new "T(bel|tu|say): Acho que se pode dizer que há."

    # say L2025 bel
    old "I saw the latests results of the poll before I came."
    new "B:bel: Acho que se pode dizer que sim."

    # say L2027 bel
    old "And Lana is still on top!"
    new "T(bel|tu|say): E a Lana ainda está em primeiro lugar!"

    # say L2028 pla
    old "She is? But I thought you said that with what we did last time, there was no way she could catch you."
    new "B:bel: E a Lana ainda está em cima!"

    # say L2030 bel
    old "I know, but you just won't believe what that whore is doing now!"
    new "T(bel|tu|say): Eu sei, mas não vais acreditar no que essa puta está a fazer agora!"

    # say L2032 bel
    old "She's doing anal!"
    new "B:bel: Eu sei, mas tu não vais acreditar no que aquela puta está a fazer agora!"

    # say L2033 bel
    old "I mean, can you believe it?!"
    new "B:bel: Ela está a fazer anal!"

    # say L2035 pla
    old "Uhmm, I mean... Is it weird for people to do webcamming?"
    new "B:bel: Quero dizer, tu acreditas?"

    # say L2037 bel
    old "For a new model, of course it is... She just started streaming a few weeks ago!"
    new "B:pla: Humm, quero dizer... É estranho as pessoas fazerem webcamming?"

    # say L2039 bel
    old "She hasn't built a fanbase or anything yet, she is crazy!"
    new "B:bel: Para um novo modelo, claro que sim... Ela começou a transmitir há apenas algumas semanas!"

    # say L2041 bel
    old "Besides, you know what else she did?"
    new "B:bel: Ela ainda não construiu uma base de fãs ou algo assim, ela é louca!"

    # say L2043 bel
    old "She just uploaded it as a video to her stream!"
    new "B:bel: Além disso, sabes o que mais ela fez?"

    # say L2045 bel
    old "Well, she didn't do it live; she just recorded it off-camera and then uploaded it as if it were live..."
    new "B:bel: Ela acabou de o carregar como um vídeo para a sua transmissão!"

    # say L2048 bel
    old "I don't know for certain, but come on, you can tell she did."
    new "T(bel|tu|say): Não tenho a certeza, mas vamos lá, tu consegues ver que ela fez."

    # say L2050 bel
    old "She's not interacting with her chat, answering questions, or anything."
    new "B:bel: Não tenho a certeza, mas vamos lá, tu sabes que ela fez."

    # say L2051 bel
    old "She's just doing it and that's it."
    new "B:bel: Ela não está a interagir com o chat, a responder a perguntas ou nada disso."

    # say L2053 bel
    old "It's clear that it wasn't a live stream, that's for sure!"
    new "B: bel: Ela está só a fazer isso e pronto."

    # say L2054 pla
    old "Ok, I get it, what are you going to do about it then?"
    new "A:bel: Não é óbvio?"

    # say L2056 bel
    old "Isn't it obvious?"
    new "A:bel: Vou combinar com ela!"

    # say L2058 bel
    old "I'm going to match her!"
    new "B:bel: Não é óbvio?"

    # say L2059 bel
    old "I'm not going to just sit down and wait for her to pass me in the rankings!"
    new "B:bel: Vou apanhá-la!"

    # say L2060 pla
    old "So... You're also doing anal too?"
    new "B:bel: Não vou ficar sentado à espera que ela me ultrapasse nas classificações!"

    # say L2062 bel
    old "Yes, why? Are you against doing it or something?"
    new "B:pla: Então... Tu também estás a fazer anal?"

    # say L2063 pla
    old "Uhh, no, no, nothing like that."
    new "B:bel: Sim, porquê? És contra fazer isso ou algo assim?"

    # say L2064 pla
    old "It's just surprising, that's all."
    new "B: pla: Uhh, não, não, nada disso."

    # say L2067 bel
    old "But after I saw Lana's {i}'Stream'{/i}..."
    new "T(bel|tu|say): Mas depois de ver o {i}'Stream'{/i} da Lana..."

    # say L2069 bel
    old "They said they'd totally love to see it."
    new "B:bel: Perguntei aos meus seguidores se gostariam de ver-me a fazer algo parecido."

    # say L2070 bel
    old "So that settles it, we're doing it!"
    new "B:bel: Disseram que adorariam ver isso."

    # say L2071 bel
    old "I told them we had a surprise coming the next time you appeared on the stream with me."
    new "B:bel: Então está decidido, vamos fazer isso!"

    # say L2072 pla
    old "I see, w- well if you're ok with it, I- I guess it's fine."
    new "B:bel: Disse-lhes que tínhamos uma surpresa para a próxima vez que apareces no stream comigo."

    # say L2074 bel
    old "Yeah, I know that the next time you come to my house you have to do that website thing with my mom."
    new "T(bel|tu|say): Sim, sei que da próxima vez que vens a minha casa tens de fazer aquela coisa do site com a minha mãe."

    # say L2075 bel
    old "But perhaps we could do it afterwards."
    new "B:bel: Sim, eu sei que da próxima vez que tu vens à minha casa tens de fazer aquela coisa do site com a minha mãe."

    # say L2077 pla
    old "Actually, it's going to be at least a couple of times that I come to your house and help your mom with the website."
    new "T(pla|tu|say): Na verdade, vou à tua casa pelo menos umas quantas vezes para ajudar a tua mãe com o site."

    # say L2079 bel
    old "Really?!"
    new "B:pla: Na verdade, vou à tua casa pelo menos umas vezes para ajudar a tua mãe com o site."

    # say L2080 bel
    old "But we're really short on time [pla]!"
    new "T(bel|tu|diz): Mas estamos mesmo a ficar sem tempo [pla]!"

    # say L2082 pla
    old "So, I kinda have to help her with it."
    new "B:pla: Eu sei, desculpa, mas aparentemente ela tem que mostrar algum progresso aos chefes na próxima reunião."

    # say L2084 bel
    old "Hmph OK, I guess that's fine."
    new "B:pla: Então, tenho de a ajudar com isso."

    # say L2085 bel
    old "I'll tell my fans to wait for a while before I show them the '{i}surprise{/i}' I'd promise them."
    new "T(bel|tu|say): Vou dizer aos meus fãs para esperarem um pouco antes de lhes mostrar a '{i}surpresa{/i}' que lhes prometi."

    # say L2089 bel
    old "Ok, I guess we better go to classes for now."
    new "B:bel: Mas depois temos que fazer isso, ok?"

    # say L2115 ash
    old "Thank you, dear. I'm very glad I've got to meet you, you know?"
    new "B:bel: Ok, acho que é melhor irmos às aulas por agora."

    # say L2117 ash
    old "After all, Belle never introduces me to any of her friends."
    new "B:ash: Obrigado, querida. Estou muito contente por termos nos conhecido, sabes?"

    # say L2118 ash
    old "That girl's so secretive now."
    new "A:pla: Então... Tu e a Belle não são próximos?"

    # say L2119 pla
    old "So... Aren't you and Belle close?"
    new "T: Então... Vocês não são próximos, tu e a Belle?"

    # say L2120 ash
    old "No, we're not."
    new "B:pla: Então... Vocês não são próximos, tu e a Belle?"

    # say L2121 ash
    old "We used to be very close before, but over the years she and I have distanced a lot."
    new "B:ash: Não, não somos."

    # say L2124 ash
    old "Yes, when Belle was growing up we were inseparable."
    new "B:ash: Antigamente éramos muito próximos, mas ao longo dos anos afastámo-nos bastante."

    # say L2126 ash
    old "I would never go anywhere without her, and you'd be hard-pressed to see one without the other."
    new "A:ash: Mas com o passar do tempo começámos a afastar-nos."

    # say L2129 ash
    old "But as time went by we began to distance."
    new "B:ash: Nunca iria a lado nenhum sem ela, e seria difícil ver um sem o outro."

    # say L2131 ash
    old "Now we barely even talk, and whenever we're together is like she's angry with me all the time."
    new "B:ash: Mas com o tempo começámos a afastar-nos."

    # say L2133 pla
    old "I'm sorry, I didn't know things were like that between the two of you."
    new "T(pla|tu|say): Sinto muito, não sabia que as coisas estavam assim entre vocês."

    # say L2135 ash
    old "Yeah, but I blame myself."
    new "B:pla: Sinto muito, não sabia que as coisas eram assim entre vocês."

    # say L2138 ash
    old "Well, I'm a single mother, and I had Belle when I was very young."
    new "B:ash: Sim, mas culpo-me a mim mesmo."

    # say L2140 ash
    old "I decided that I would do everything I could to raise her properly."
    new "B:ash: Sou uma mãe solteira e tive a Belle quando era muito nova."

    # say L2142 ash
    old "So, as she grew up, my focus was on my work."
    new "B:ash: Decidi que faria tudo o que pudesse para a educar corretamente."

    # say L2144 ash
    old "Since I was always working, I never had any time for her or the things related to school."
    new "B:ash: Então, à medida que ela crescia, o meu foco estava no trabalho."

    # say L2146 ash
    old "Is not that I wasn't interested, is just that I was busy all the time."
    new "B:ash: Como estava sempre a trabalhar, nunca tive tempo para ela ou para as coisas relacionadas com a escola."

    # say L2147 ash
    old "I sort of thought that as long as I was providing for her, things would be fine."
    new "B:ash: Não é que eu não estivesse interessado, é que estava ocupado o tempo todo."

    # say L2149 ash
    old "But I didn't realize she was pulling away from me. Nowadays I never know what she's doing."
    new "A:ash: Os seus interesses, ou as coisas que a interessam..."

    # say L2150 ash
    old "Her interests, or the things she's into..."
    new "T(ash|tu|dizes): Os interesses dela, ou as coisas de que gosta..."

    # say L2152 ash
    old "It's a miracle I even know Hinn, and that's just because I came home one time while she was here."
    new "B:ash: Os interesses dela, ou as coisas de que gosta..."

    # say L2154 ash
    old "Oh, and that other friend... Mike."
    new "B:ash: É um milagre eu sequer conhecer a Hinn, e isso foi só porque cheguei em casa uma vez enquanto ela estava aqui."

    # say L2156 ash
    old "But I'd rather not to talk about him."
    new "B:ash: Oh, e esse outro amigo... Mike."

    # say L2158 pla
    old "I- I'm sorry about that M- Mrs... I- I mean A- Ashley."
    new "B:ash: Mas prefiro não falar sobre ele."

    # say L2159 pla
    old "But I'm sure you and Belle will be fine."
    new "B:pla: I- I'm desculpe por isso S- Senhora... I- I mean A- Ashley."

    # say L2161 ash
    old "You think so?"
    new "T(ash|tu|dizes): Tu pensas isso?"

    # say L2163 pla
    old "For sure, after all, you say you've always been close."
    new "T: Claro, afinal, dizes que sempre foste próximo. A: Tenho a certeza de que a Belle é só..."

    # say L2164 pla
    old "I'm sure Belle's just..."
    new "B:pla: Com certeza, afinal, tu dizes que sempre foram próximos."

    # say L2165 pla
    old "Uhm... Worried about things from school and such."
    new "B:pla: Tenho a certeza de que a Belle está apenas..."

    # say L2167 ash
    old "I guess I'll have to take your word for it. After all, you may be more informed about what she's doing lately than me."
    new "B:pla: Hum... Preocupado com coisas da escola e tal."

    # say L2169 ash
    old "The good thing is that she doesn't seem to be doing anything weird or out of the ordinary."
    new "B:ash: Acho que terei de acreditar em ti. Afinal, tu podes estar mais a par do que ela tem feito ultimamente do que eu."

    # say L2170 ash
    old "She's just focused on school."
    new "B:ash: O bom é que ela não parece estar a fazer nada estranho ou fora do normal."

    # say L2173 ash
    old "Although I think it would be good if she went out a little bit more. She seems to expend most of her time on her computer."
    new "B:ash: Ela está só focada na escola."

    # say L2175 ash
    old "But I guess that's good, at least she's not doing anything bad."
    new "B:ash: Acho que seria bom se ela saísse um pouco mais. Parece que passa a maior parte do tempo no computador."

    # say L2181 pla
    old "Oh! Sure!"
    new "B:ash: Porque não vais para casa por agora? Podemos continuar a trabalhar noutra altura."

    # say L2187 pla
    old "I'll see you later then. Goodbye, Ashley."
    new "T(pla|tu|say): Vejo-te mais tarde então. Adeus, Ashley."

    # say L2189 ash
    old "Goodbye hon, thanks for your help today."
    new "T(ash|tu|diz): Adeus querido, obrigado pela ajuda de hoje."

    # say L2190 ash
    old "And thank you, for listening to me."
    new "B:ash: Adeus querida, obrigado pela tua ajuda hoje."

    # say L2192 pla
    old "Gladly, I'm happy to help you, and to talk to you."
    new "T(pla|tu|say): Com prazer, estou feliz em ajudar-te e em falar contigo."

    # say L2194 ash
    old "That's very sweet."
    new "B:pla: Com prazer, estou feliz em ajudar-te e em falar contigo."

    # say L2199 pla
    old "I think I should get going then."
    new "T: Acho que devo ir-me embora então."

    # say L2228 bel
    old "Well, I know you had to help my mom with that website she's working on."
    new "B:bel: Bem, queria discutir o que vamos fazer no nosso próximo stream juntos."

    # say L2230 bel
    old "But I think today you're supposed to be free, right?"
    new "B:bel: Bem, sei que tiveste de ajudar a minha mãe com o site onde está a trabalhar."

    # say L2231 bel
    old "So, do you think you could come to my house today?"
    new "B:bel: Mas acho que hoje tu estás livre, certo?"

    # say L2233 bel
    old "Great! So let's go after classes."
    new "B:bel: Então, tu achas que podes vir à minha casa hoje?"

    # say L2259 bel
    old "Ok, let's go."
    new "B:bel: Ótimo! Então vamos depois das aulas."

    # say L2260 pla
    old "Right, let's do it."
    new "Bem, vamos lá."

    # say L2273 bel
    old "Alright, let's do this!"
    new "Espera, antes de começarmos."

    # say L2274 pla
    old "Wait, before we start."
    new "T: Espera, antes de começarmos."

    # say L2275 pla
    old "Are you sure you want to do this?"
    new "T(pla|tu|say): Tu estás certo de que queres fazer isto?"

    # say L2276 pla
    old "I know it's not that big a deal to some people, but  you would be doing it for the first time."
    new "B:pla: Tens a certeza de que queres fazer isto?"

    # say L2280 bel
    old "And I'm not backing down because of Lana suddenly coming into the scene."
    new "B:bel: Ganhar este prémio significa muito para mim."

    # say L2282 bel
    old "So yeah, I'm sure!"
    new "B:bel: E não vou recuar só porque a Lana apareceu de repente."

    # say L2283 pla
    old "Ok, if you're this determined, let's do it."
    new "B:bel: Então, tenho a certeza!"

    # say L2285 bel
    old "Yeah! Let's do it!"
    new "B:pla: Ok, se tu és assim determinado, vamos fazer isso."

    # say L2298 bel
    old "Hello again guys!"
    new "B:bel: Sim! Vamos lá!"

    # say L2299 bel
    old "I'm very happy to see you all again!"
    new "B:bel: Olá de novo, pessoal!"

    # say L2300 bel
    old "And I have very good news, everybody!"
    new "B:bel: Estou muito feliz por ver todos vocês de novo!"

    # say L2301 bel
    old "Remember the other surprise I'd talked to you about?!"
    new "B:bel: E tenho excelentes notícias, pessoal!"

    # say L2302 bel
    old "Well, it's happening today!"
    new "B:bel: Lembra-te da outra surpresa de que te falei?!"

    # say L2303 bel
    old "I know this is something you've been dying to see!"
    new "B:bel: Bem, está a acontecer hoje!"

    # say L2304 bel
    old "And I know you will love it!"
    new "B:bel: Eu sei que isto é algo que tu estavas a morrer de vontade de ver!"

    # say L2305 bel
    old "So, say hello again to my friend, and let's get to it!"
    new "B:bel: E sei que vais adorar!"

    # say L2310 bel
    old "Remember guys, just as always! Today's surprise can only come if you guys reach our goal."
    new "B:bel: Então, diga olá de novo ao meu amigo e vamos lá!"

    # say L2311 bel
    old "But I'm sure you'll reach it!"
    new "B:bel: Lembrem-se, como sempre! A surpresa de hoje só vai acontecer se vocês atingirem a meta."

    # say L2318 bel
    old "For today we're going to need it well lubricated, isn't that right, guys?"
    new "B:bel: Mas tenho a certeza de que vais conseguir!"

    # say L2319 bel
    old "So I'll take care of doing a good job with my mouth to get it ready for what comes next."
    new "B:bel: Para hoje vamos precisar que esteja bem lubrificado, não é verdade, rapazes?"

    # say L2320 bel
    old "My God! What a great cock!"
    new "B:bel: Vou cuidar de fazer um bom trabalho com a boca para me preparar para o que vem a seguir."

    # say L2321 bel
    old "Right guys?!"
    new "B:bel: Meu Deus! Que pénis incrível!"

    # say L2322 bel
    old "I bet you can't wait to see me being ravaged by it."
    new "B:bel: Certos, rapazes?"

    # say L2323 bel
    old "Just be sure to get to the goal guys!"
    new "B:bel: Aposto que não vês a hora de me ver ser devassada por ele."

    # say L2336 pla
    old "Uh- I- uh..."
    new "T(pla|tu|say): Uh- I- uh..."

    # say L2337 pla
    old "I came to do something with Belle."
    new "B:pla: Uh- I- uh..."

    # say L2339 pla
    old "Some... Uh- school work..."
    new "B:pla: Vim fazer algo com a Belle."

    # say L2341 ash
    old "Ok, I see, but where is Belle?"
    new "B:pla: Algumas... Uh- trabalhos da escola..."

    # say L2343 pla
    old "She... Uh- she went out for a while."
    new "Ela... Hum, ela saiu por um tempo. Disse algo sobre passar na casa do Hinn para pegar uma coisa."

    # say L2344 pla
    old "She said something about picking up a thing at Hinn's house."
    new "B:pla: Ela... Uh- ela saiu por um tempo."

    # say L2346 ash
    old "I had to pop home to get some documents for work, and I wanted to talk with her."
    new "B:pla: Ela disse algo sobre passar a recolher uma coisa na casa do Hinn."

    # say L2347 ash
    old "Well, it's good to see you anyway."
    new "B:ash: Tive de passar em casa para pegar alguns documentos para o trabalho, e queria falar com ela."

    # say L2348 ash
    old "I'll go back to the office, please tell Belle to give me a call when she gets back."
    new "B:ash: É bom ver-te de qualquer forma."

    # say L2349 ash
    old "See you later [pla]."
    new "T(ash|tu|diz): Até mais [pla]. A:pla: Claro, até mais senhora."

    # say L2363 bel
    old "{i}Holy shit, I know... Anyway, let's just keep going with the stream... Shhh...{/i}"
    new "B:pla: {i}Que raio aconteceu...{/i}"

    # say L2365 bel
    old "Anyways, let's continue with the show!"
    new "B:bel: Desculpa, pessoal! Peço desculpa por essa pequena interrupção... Sabem, isto pode acontecer quando se está a fazer ao vivo..."

    # say L2366 bel
    old "But now we can resume with what we were doing, and you know what that means."
    new "B:bel: De qualquer forma, vamos continuar com o espetáculo!"

    # say L2368 bel
    old "No, she won't be joining us or anything."
    new "B:bel: Mas agora podemos continuar com o que estávamos a fazer, e tu sabes o que isso significa."

    # say L2369 bel
    old "That was just an unplanned thing."
    new "B:bel: Não, ela não vai nos acompanhar."

    # say L2370 bel
    old "But don't worry, we're not stopping here."
    new "B:bel: Foi só uma coisa imprevista."

    # say L2371 bel
    old "Let's keep going!"
    new "B:bel: Mas não te preocupes, não vamos parar aqui."

    # say L2388 bel
    old "Wow, that was close!"
    new "B:bel: Vamos continuar!"

    # say L2389 pla
    old "Really close."
    new "T(pla|tu|say): Foi mesmo perto."

    # say L2390 pla
    old "That really scared me."
    new "B: pla: Muito perto."

    # say L2391 bel
    old "It's good that she didn't see us doing anything."
    new "B:pla: Isso assustou-me muito."

    # say L2393 bel
    old "I can't imagine how we would explain the whole situation to her."
    new "B:bel: É bom que ela não tenha visto o que estávamos a fazer."

    # say L2394 pla
    old "Yeah, tell me about it."
    new "T: Tu tens razão. Vamos voltar para o stream antes que os fãs fiquem impacientes."

    # say L2395 bel
    old "Well, we should get back to the stream before the fans get impatient."
    new "B:pla: Sim, conta-me isso."

    # say L2408 bel
    old "Hngh! Oh yes!"
    new "B:bel: Bem, devemos voltar à transmissão antes que os fãs fiquem impacientes."

    # say L2409 bel
    old "This is what you've all been waiting for isn't it?"
    new "B:bel: Hngh! Oh sim!"

    # say L2410 bel
    old "Well, you earned it!"
    new "B:bel: Isto é o que todos estavam à espera, não é?"

    # say L2411 bel
    old "So, be sure to enjoy it!"
    new "B:bel: Bem, tu mereceste!"

    # say L2424 bel
    old "Guys! I'm so glad you liked it!"
    new "B:bel: Então, aproveitem!"

    # say L2425 bel
    old "You keep making all of this possible."
    new "B: Bel: Rapazes! Estou tão contente que vocês tenham gostado!"

    # say L2426 bel
    old "Witout your support this just wouldn't be possible."
    new "T(bel|tu|diz): Sem o teu apoio, isto simplesmente não seria possível."

    # say L2427 bel
    old "So, it makes me very happy to do this kind of thing for you."
    new "B: bel: Sem o teu apoio isto simplesmente não seria possível."

    # say L2428 bel
    old "Ok guys, I have to leave for now."
    new "B:bel: Então, faz-me muito feliz fazer este tipo de coisa para ti."

    # say L2429 bel
    old "But be sure that I'll be back soon with another stream."
    new "B:bel: Ok, pessoal, tenho que ir agora."

    # say L2430 bel
    old "I wonder what surprise I'll have for you then?"
    new "B:bel: Mas tenha a certeza que vou voltar em breve com outro stream."

    # say L2431 bel
    old "As always remember to subscribe so you will get notified of the next stream!"
    new "B:bel: Que surpresa te esperará, então?"

    # say L2432 bel
    old "And remember to follow me on all my socials."
    new "T(bel|tu|say): E lembra-te de me seguir em todas as minhas redes sociais."

    # say L2433 bel
    old "So you won't miss any updates!"
    new "B:bel: E lembra-te de me seguir em todas as minhas redes sociais."

    # say L2434 bel
    old "Until next time, see you guys! Love you!"
    new "B:bel: Para não perderes nenhuma atualização!"

    # say L2445 bel
    old "I'm sure I'll overtake Lana in no time!"
    new "B:bel: Conseguiram o objetivo tão depressa!"

    # say L2446 bel
    old "And this time I'm certain the first spot in the rankings is mine for sure!"
    new "T(bel|tu|say): E desta vez tenho a certeza que o primeiro lugar no ranking é meu!"

    # say L2448 pla
    old "That's great to hear Belle, I'm sure you'll get it."
    new "B:bel: E desta vez tenho a certeza de que o primeiro lugar no ranking é meu!"

    # say L2450 pla
    old "Although I hope your fans weren't bothered by your mom coming in midstream."
    new "B:pla: Que bom ouvir isso, Belle, tenho a certeza de que vais conseguir."

    # say L2452 pla
    old "That really scared me, I thought she was going to see us."
    new "B:pla: Embora espero que os teus fãs não tenham ficado incomodados com a tua mãe ter entrado no meio."

    # say L2454 bel
    old "Yeah, me too, I'm sorry that happened, by the way."
    new "B:pla: Isso assustou-me bastante, pensei que ela ia ver-nos."

    # say L2455 bel
    old "She just had to come in at the most inopportune time."
    new "B:bel: Sim, eu também, desculpa que isso tenha acontecido, aliás."

    # say L2456 bel
    old "But don't worry, the fans weren't too bothered by her intrusion."
    new "B:bel: Ela teve que entrar no momento mais inoportuno."

    # say L2458 bel
    old "Yeah... they were writing how thrilling it was."
    new "T(bel|tu|say): Sim... estavam a escrever como era empolgante."

    # say L2460 bel
    old "So many of them were even writing how hot it would be to see my mom fuck with us."
    new "B:bel: Sim... eles estavam a escrever o quão empolgante isso era."

    # say L2462 bel
    old "But leaving that aside, everything went better than I expected."
    new "B:bel: Tantos deles estavam até a escrever o quão excitante seria ver a minha mãe a transar connosco."

    # say L2467 pla
    old "I know how much this means to you."
    new "B:pla: Nem sequer menciones, estou feliz por poder ajudar-te."

    # say L2469 bel
    old "But even still, is not as if this is just nothing."
    new "B:pla: Eu sei o quanto isto significa para ti."

    # say L2471 bel
    old "After all, we're... Getting closer."
    new "B:bel: Mas mesmo assim, não é como se isto fosse nada."

    # say L2473 pla
    old "Yeah... We are."
    new "B:bel: Afinal, estamos... A ficar mais próximos."

    # say L2479 pla
    old "Well, I think I should leave for now."
    new "B:pla: Sim... Estamos."

    # say L2481 bel
    old "Right, for sure! I think I better get dressed and call my mom before she goes crazy because I haven't talked to her."
    new "B:pla: Bem, acho que devo ir embora agora."

    # say L2484 pla
    old "Don't worry, I'm just happy I can help you Belle, with anything you need."
    new "B:bel: Estás a fazer tanto por mim, não consigo agradecer-te o suficiente."

    # say L2485 pla
    old "I'll leave for now, see you later."
    new "B:pla: Não te preocupes, estou só feliz por poder ajudar-te, Belle, com o que precisares."

    # say L2507 pla
    old "Hi Ashley, I came to help you with the website."
    new "B:pla: Vou-me embora por agora, vejo-te mais tarde."

    # say L2508 ash
    old "Oh, is good that you're here I need your help with something right now."
    new "B:pla: Olá Ashley, vim ajudar-te com o site."

    # say L2510 ash
    old "Well, I was thinking about the design of the banners that we're making for the coffee shop."
    new "B:ash: Oh, que bom que tu estás aqui, preciso da tua ajuda com uma coisa agora."

    # say L2511 ash
    old "And I remembered some banners that we had made before but never got around to releasing."
    new "B:ash: Estava a pensar no design dos cartazes que estamos a fazer para a loja de café."

    # say L2512 ash
    old "I think we'll be able to reuse some of those ready-made designs to add them to the website."
    new "T(ash|tu|dizer): Acho que conseguiremos reutilizar alguns desses designs pré-fabricados para os adicionar ao site."

    # say L2513 ash
    old "I remembered that I saved those designs on an old flash drive, and I placed it up there on the shelves."
    new "T(ash|tu|dizes): Lembrei-me que guardei esses designs num velho pen drive e coloquei-o ali em cima das prateleiras."

    # say L2514 ash
    old "But it's a bit too high for me to reach by myself without risking falling over."
    new "B:ash: Lembrei-me que guardei esses desenhos num velho pen drive, e coloquei-o ali em cima das prateleiras."

    # say L2515 ash
    old "So, I need you to help me stay stable on the ladder while I look for it."
    new "B:ash: Mas está um bocado alto para eu chegar sem risco de cair."

    # say L2517 pla
    old "Uhh, s- sure, no problem."
    new "B:ash: Então, preciso que me ajudes a ficar estável na escada enquanto procuro."

    # say L2518 ash
    old "Thank you, hun."
    new "A:pla: Estás bem aí? Conseguiste chegar?"

    # say L2523 pla
    old "Are you okay there? Can you reach it?"
    new "B:ash: Obrigado, querida."

    # say L2524 ash
    old "Yeah, I'm close. Just a little more and I'll grab it."
    new "B:pla: Estás bem aí? Conseguiste chegar?"

    # say L2528 pla
    old "{i}(Maybe it is because she's so young, but wow, her body's amazing!){/i}"
    new "B:pla: {i}(... Merda, nem tinha pensado nisso, mas a Ashley é mesmo gira.){/i}"

    # say L2529 pla
    old "{i}(I mean, just look at her ass...){/i}"
    new "B:pla: {i}(Talvez seja porque ela é tão nova, mas uau, o corpo dela é incrível!){/i}"

    # say L2530 pla
    old "{i}(Oh shit! I'm getting horny.){/i}"
    new "B: {i}(Tu sabes, só olha para o rabo dela...){/i}"

    # say L2531 pla
    old "{i}(I have to calm down or I'll get a boner){/i}"
    new "B:pla: {i}(OH NÃO! Estou a ficar excitado.){/i}"

    # say L2534 ash
    old "Well, you moved suddenly, so I was wondering if I made you lose your balance."
    new "B:pla: Uh, yeah, yeah... Porquê?"

    # say L2535 pla
    old "No, no, Uhh, nothing happened, it's ok."
    new "B:ash: Bem, tu moveste-te de repente, então fiquei a pensar se te fiz perder o equilíbrio."

    # say L2536 ash
    old "Uh, ok... sure."
    new "B:pla: Não, não, Uh, nada aconteceu, está tudo bem."

    # say L2539 pla
    old "Oh, alright."
    new "B:ash: Ok, acho que já os tenho, estou a descer."

    # say L2547 pla
    old "Ughh, damn, that was painful."
    new "B:pla: Oh, tudo bem."

    # say L2549 pla
    old "{i}(Oh wow, it's Ashley's ass!){/i}"
    new "B:pla: {i}(Hmm? O que é isto? O que tenho na cara?){/i}"

    # say L2550 pla
    old "{i}(D- Damn! I better get up before she I get a boner!){/i}"
    new "B:pla: {i}(Oh wow, é o rabo da Ashley!){/i}"

    # say L2555 ash
    old "{i}(Oh my gosh! H- He's got a boner!){/i}"
    new "B:pla: {i}(OH NÃO, era exactamente o que eu queria evitar! Fiquei com uma erecção!){/i}"

    # say L2560 pla
    old "Uh... A- Ashley? Can you please move?"
    new "B:pla: Y- yeah, I- I am. I'm sorry, I think I was the one who slipped."

    # say L2561 ash
    old "Uh, I- I..."
    new "A:ash: É que tu tens um..."

    # say L2563 ash
    old "Is just that you have a..."
    new "B:ash: Uh, eu- eu..."

    # say L2574 pla
    old "I- I uh... I'm sorry Ashley, it wasn't my intention..."
    new "A:pla: I- é só que..."

    # say L2575 pla
    old "I- its just that..."
    new "B:pla: I- I uh... Desculpa, Ashley, não foi minha intenção..."

    # say L2576 ash
    old "It's fine, it's fine."
    new "B: pla: É... é só que..."

    # say L2578 ash
    old "You're a young man after all. It's perfectly understandable that this happens."
    new "T(ash|tu|dizes): És um jovem afinal. É perfeitamente compreensível que isto aconteça."

    # say L2579 ash
    old "I fell on you and... M- my butt landed on your face..."
    new "...uma reação natural, não é?"

    # say L2580 ash
    old "So, I think I understand that you would get a..."
    new "B:ash: Caí em cima de ti e... A- a minha bunda caiu na tua cara..."

    # say L2598 pla
    old "Uhh... T- thank you... for understanding."
    new "T: Uhh... O- obrigado... por entender."

    # say L2599 ash
    old "Hmm... Sure, i- it's very normal."
    new "B:pla: Uhh... O- obrigado... por compreender."

    # say L2604 pla
    old "Uhh, s- should we get to working on the website then?"
    new "B:ash: Hmm... Claro, é muito normal."

    # say L2606 ash
    old "I- I don't think that's a good idea right now [pla]."
    new "T(ash|tu|diz): N- não acho que seja uma boa ideia agora [pla]."

    # say L2609 pla
    old "Oh... Alright."
    new "B:ash: B- porque tenho de levar as bandeiras à minha equipa no escritório, para que eles possam usá-las para desenhar as novas."

    # say L2611 pla
    old "I- I think I'll leave for now, see you later."
    new "B:pla: Oh... Tudo bem."

    # say L2612 ash
    old "Y- yeah... S- see you later hon."
    new "B:pla: V- vou-me embora por agora, vejo-te mais tarde."

    # say L2618 ash
    old "Wow, he really has it very big c-... Now I understand why Belle likes him so much..."
    new "B:ash: Y- yeah... A- adeus querida."

    # say L2638 pla
    old "Hey Belle, good morning, how are you?"
    new "B:ash: Wow, ele realmente tem um tamanho impressionante c-... Agora entendo por que a Belle gosta tanto dele..."

    # say L2640 bel
    old "To be honest, I'm quite upset..."
    new "B:pla: Olá Belle, bom dia, como estás?"

    # say L2641 pla
    old "Why? What happened now?"
    new "B:bel: Para ser honesta, estou bastante chateada..."

    # say L2643 bel
    old "Well, it's that bitch Lana."
    new "B:pla: Porquê? O que aconteceu agora?"

    # say L2645 bel
    old "You won't believe what she pulled now!"
    new "B:bel: Bem, é aquela cadela Lana."

    # say L2646 pla
    old "W- what? Why?!"
    new "B:bel: Não vais acreditar no que ela fez agora!"

    # say L2647 pla
    old "I thought that you had surpassed her with what we did last time."
    new "B:pla: O- o quê? Porquê?!"

    # say L2649 bel
    old "And we did!"
    new "T(bel|tu|say): E fizemos!"

    # say L2651 bel
    old "After our last streaming session I went up on the charts by a lot."
    new "B:bel: E conseguimos!"

    # say L2653 bel
    old "So, I guess Lana felt desperate or something."
    new "B:bel: Depois da nossa última sessão de streaming, subi bastante nas classificações."

    # say L2654 bel
    old "Because then she came out and did a threesome!"
    new "T(bel|tu|say): Porque depois ela saiu e fez um trio!"

    # say L2655 pla
    old "A threesome?"
    new "A:bel: Sim, ela simplesmente fez isso do nada."

    # say L2657 bel
    old "Yeah, she just did it out of nowhere."
    new "B:pla: Um trio?"

    # say L2659 bel
    old "You know what really triggers me? She didn't even do it with another cam streamer or anything!"
    new "B:bel: Sim, ela fez isso do nada."

    # say L2661 bel
    old "But of course she didn't, she doesn't know anybody in this business."
    new "B:bel: Sabes o que me enfurece? Ela nem sequer o fez com outro streamer de câmara!"

    # say L2663 bel
    old "I bet she just paid some amateur pornstar to do it with her, that whore!"
    new "B:bel: Mas claro que não, ela não conhece ninguém neste ramo."

    # say L2664 pla
    old "OK, what is your plan then?"
    new "B:bel: Aposto que ela só pagou a alguma amadora para fazer isso com ela, essa put*!"

    # say L2666 bel
    old "What do you mean what is my plan? I'm going to answer her the same way of course?"
    new "B:pla: OK, então qual é o teu plano?"

    # say L2667 pla
    old "Uhh, really? Are you sure?"
    new "B:bel: O que queres dizer com o que é o meu plano? Vou responder-lhe da mesma maneira, claro."

    # say L2669 bel
    old "Of course I'm sure [pla], I've done too much to win this contest."
    new "T(bel|tu|diz): Claro que tenho a certeza [pla], já fiz demasiado para ganhar este concurso."

    # say L2671 bel
    old "I've augmented the number of times I stream weekly. I roped you into this."
    new "B:bel: Tenho trabalhado muito para conseguir cada voto que recebi."

    # say L2673 bel
    old "I even let you fuck me in the ass!"
    new "B:bel: Aumentei o número de vezes que faço stream por semana. Arrastei-te para isto."

    # say L2675 bel
    old "I've worked hard for this, and I'm not going to let some newcomer take it away."
    new "B:bel: Até te deixei foder-me no cu!"

    # say L2676 pla
    old "Well, I don't know what to tell you."
    new "B:bel: Trabalhei muito para isto, e não vou deixar que algum novato me tire isso."

    # say L2677 bel
    old "You don't have to say anything, all I need is for you to be willing to help me when I need it."
    new "B:pla: Bem, não sei o que te dizer."

    # say L2679 pla
    old "Of course! You know I'll help you with anything I can."
    new "B:bel: Não tens de dizer nada, só preciso que estejas disposto a ajudar-me quando precisar."

    # say L2681 bel
    old "Thanks [pla], I'm glad I can count on you."
    new "T(bel|tu|say): Obrigado [pla], fico contente por poder contar contigo."

    # say L2683 bel
    old "I'll have to contact her and see when she would be available to arrange everything for the stream."
    new "B:bel: Além disso, já tenho alguém em mente que pode nos ajudar com o trio."

    # say L2684 bel
    old "Meanwhile, you have to work with my mom the next time you come home, right?"
    new "B:bel: Vou ter de a contactar para ver quando ela está disponível para organizar tudo para o stream."

    # say L2686 pla
    old "Uhh, yeah, we are still working on the website, there are still several things left to finish."
    new "B:bel: Enquanto isso, tu vais ter de trabalhar com a minha mãe da próxima vez que vens a casa, certo?"

    # say L2688 bel
    old "Ok, so while you do that I'll talk with my friend and see if she can help us."
    new "B:pla: Uhh, sim, ainda estamos a trabalhar no site, há ainda várias coisas por acabar."

    # say L2689 bel
    old "I'll let you know as soon as we can do it."
    new "B:bel: Ok, então enquanto tu fazes isso eu vou falar com a minha amiga e ver se ela pode ajudar-nos."

    # say L2691 pla
    old "Uhh, alright."
    new "B:bel: Vou-te avisar assim que pudermos fazer isso."

    # say L2707 pla
    old "Well, I was thinking I could keep helping you develop the website."
    new "B:pla: Até logo, Belle."

    # say L2709 pla
    old "Hmm, what is it?"
    new "Hmm, o que se passa?"

    # say L2711 ash
    old "Well, my laptop isn't working right now."
    new "B:pla: Hmm, o que é?"

    # say L2712 ash
    old "I was... Uh, u- using it the other day, looking for some... References."
    new "B:ash: Bem, o meu portátil não está a funcionar agora."

    # say L2713 ash
    old "But it suddenly stopped working."
    new "B:ash: Estava... Uh, a usá-lo há uns dias, à procura de algumas... Referências."

    # say L2715 ash
    old "I can turn it on now, it will even power up normally."
    new "B:ash: Mas de repente parou de funcionar."

    # say L2716 ash
    old "But after that, it doesn't work."
    new "A:pla: O que queres dizer? O ecrã fica só preto?"

    # say L2717 pla
    old "What do you mean? The screen just stays black?"
    new "T(pla|tu|say): O que queres dizer? O ecrã fica só preto?"

    # say L2718 ash
    old "No, it's not that. Once it's fully turned on, you simply can't do anything with it."
    new "B:pla: O que queres dizer? O ecrã fica só preto?"

    # say L2720 ash
    old "If you click on something, multiple windows open up, and when you attempt to use the web browser, numerous tabs start to open up."
    new "B:ash: Não, não é isso. Quando está completamente ligado, tu simplesmente não consegues fazer nada com ele."

    # say L2721 ash
    old "And you can't close them down or do anything about it."
    new "B:ash: Se clicares em algo, abrem-se várias janelas, e quando tentas usar o navegador, começam a abrir-se inúmeras abas."

    # say L2722 pla
    old "Hmm, that sounds like an adware."
    new "B:ash: E não podes fechar ou fazer nada a respeito."

    # say L2724 pla
    old "But don't worry, I think I can fix it."
    new "B:pla: Hmm, isso soa como um adware."

    # say L2727 pla
    old "Yeah, all I have to do is run an antivirus through it, and it should be completely fine."
    new "B:pla: Mas não te preocupes, acho que consigo arranjá-lo."

    # say L2728 ash
    old "That sounds great! Alright, let's do it."
    new "B:pla: Sim, só tenho de fazer uma varredura com um antivírus, e deve ficar tudo bem."

    # say L2743 ash
    old "There, that's what happens as soon as you try to use it."
    new "B:ash: Isso soa ótimo! Tudo bem, vamos lá."

    # say L2744 pla
    old "Hmm, yeah, I see what you mean."
    new "B:ash: Lá está, é isso que acontece assim que tentas usá-lo."

    # say L2745 pla
    old "Yeah, this appears to be an adware virus. But don't worry, it can be easily fixed."
    new "T(pla|tu|say): Sim, isto parece ser um vírus de adware. Mas não te preocupes, pode ser resolvido facilmente."

    # say L2746 pla
    old "I just have to run the antivirus, and it will take care of cleaning up all those annoying ads."
    new "B:pla: Sim, parece ser um vírus de adware. Mas não te preocupes, é fácil de resolver."

    # say L2747 pla
    old "It should start to work quickly."
    new "B:pla: Só tenho de executar o antivírus, e ele vai tratar de limpar todos esses anúncios irritantes."

    # say L2754 pla
    old "See? It's already starting to work."
    new "B:pla: Vai começar a funcionar rapidamente."

    # say L2760 pla
    old "Ok, now it's searching for viruses and malicious content."
    new "B:pla: Vê? Já está a funcionar."

    # say L2761 pla
    old "As soon as it's done with the scanning, it will start deleting all the damaged files and threats to the system."
    new "B:pla: Ok, agora está a procurar vírus e conteúdo malicioso."

    # say L2769 pla
    old "Ok, it's almost done, it shouldn't take much longer."
    new "B:pla: Bem, não é tão difícil quanto parece, heh."

    # say L2770 ash
    old "Wow, I didn't know it was so fast. I thought I would have to take it for maintenance and it would take days."
    new "B:pla: Ok, está quase feito, não deve demorar muito mais."

    # say L2777 pla
    old "Okay, we're done. The viruses that were affecting your computer should have been eliminated by now."
    new "B:ash: Uau, não sabia que fosse tão rápido. Pensei que teria de o levar para manutenção e que demoraria dias."

    # say L2778 ash
    old "Great, thank you!"
    new "Ótimo, obrigado!"

    # say L2779 pla
    old "Just let me refresh it and we'll see..."
    new "T: Só deixa-me atualizar e veremos..."

    # say L2786 pla
    old "Now, all of those ads and windows that it opened previously should start closing down."
    new "B:pla: Só deixa-me atualizar e veremos..."

    # say L2790 pla
    old "Oh! there's a webpage from your previous session."
    new "B:pla: Agora, todas essas publicidades e janelas que se abriram anteriormente devem começar a fechar."

    # say L2791 pla
    old "Hmm, let's see, what does it say?"
    new "B:pla: Oh! há uma página web da tua sessão anterior."

    # say L2795 pla
    old "Sneaky Stepmom Fucks Step Daugther's Boyfri-..."
    new "Oh! T- isso..."

    # say L2797 ash
    old "Oh! T- that's..."
    new "B:pla: Mãe Astuta Fode Namorado da Entead-..."

    # say L2800 pla
    old "Uhm... Yeah, that's probably what happened."
    new "T(pla|tu|say): Hum... Sim, provavelmente foi isso que aconteceu."

    # say L2801 ash
    old "W- well, let's just close it. And keep checking if the pc is fine."
    new "B:pla: Hum... Sim, provavelmente foi isso que aconteceu."

    # say L2809 pla
    old "Okay, I think the computer is good to go."
    new "B:ash: B-bem, vamos fechar isto. E continuar a verificar se o pc está bem."

    # say L2816 ash
    old "And I'm sorry about that website that you saw."
    new "E desculpa pelo site que viste. Não sei como é que isso lá foi parar."

    # say L2817 ash
    old "I don't know how that got in there."
    new "B:ash: E peço desculpa por esse site que viste."

    # say L2819 pla
    old "Uhh sure... I'm just glad I can be of help."
    new "B:ash: Não faço ideia de como isso foi parar aí."

    # say L2821 ash
    old "That's very nice of you."
    new "B:pla: Uhh, claro... Só estou contente por poder ajudar."

    # say L2827 ash
    old "Uhh, I guess we should continue working, right?"
    new "T(ash|tu|diz): Hum, acho que devíamos continuar a trabalhar, certo?"

    # say L2828 pla
    old "Oh, sure, we should get to that."
    new "A:pla: Olá Belle, como estás?"

    # say L2887 pla
    old "Hey Belle, how are you?"
    new "B:pla: Oh, claro, devíamos fazer isso."

    # say L2888 bel
    old "Actually, I'm doing great, you know? I have very good news!"
    new "B:pla: Ei Belle, como estás?"

    # say L2891 bel
    old "Remember what I told you before? What we needed to do for the next stream?"
    new "B:bel: Na verdade, estou ótimo, sabes? Tenho notícias muito boas!"

    # say L2893 pla
    old "Uhh, yeah, I do."
    new "B:bel: Lembra-te do que te disse antes? O que precisávamos fazer para o próximo stream?"

    # say L2895 bel
    old "Well, I got the girl we needed for the stream!"
    new "B:pla: Uhh, yeah, eu faço."

    # say L2897 pla
    old "T- that's great."
    new "B:bel: Bem, consegui a rapariga de que precisávamos para o stream!"

    # say L2898 bel
    old "Yeah, she's an amazing streamer."
    new "B:pla: T- isso é ótimo."

    # say L2899 bel
    old "So, get ready because today we're going to do the stream!"
    new "B:bel: Sim, ela é uma streamer incrível."

    # say L2901 pla
    old "A- alright, so, are we going to your house after class ends?"
    new "A:bel: Uhh, na verdade, vou faltar às aulas hoje."

    # say L2903 bel
    old "Uhh, actually, I will skip classes today."
    new "B:pla: A- tudo bem, então, vamos à tua casa depois das aulas?"

    # say L2905 bel
    old "I have to go to the girl's house now to pick her up and take her to my house."
    new "B:bel: Uhh, na verdade, vou faltar às aulas hoje."

    # say L2906 bel
    old "And then I'll set up the stream and make sure that everything's ready."
    new "B:bel: Tenho de ir à casa da rapariga agora para a buscar e levá-la à minha casa."

    # say L2909 bel
    old "So, don't worry, you go to class and we'll meet at my house when you're done."
    new "B:bel: E depois eu vou configurar a transmissão e garantir que tudo esteja pronto."

    # say L2914 bel
    old "You'll see, with this, I will definitely surpass Lana in the rankings for good."
    new "B:bel: Então, não te preocupes, vais à aula e encontramo-nos em casa quando acabares."

    # say L2939 pla
    old "That's weird, I'm going to Belle's house to have a... Threesome, and with a girl I don't know..."
    new "B:pla: Ok, acho que vou à casa da Belle agora."

    # say L2940 pla
    old "This definitely escalated quickly..."
    new "B:pla: Isso é estranho, vou à casa da Belle para ter um... Trio, e com uma rapariga que não conheço..."

    # say L2941 pla
    old "Well, anyway, I better go quickly. I don't want to be late for Belle's stream.."
    new "B:pla: Isto certamente escalou depressa..."

    # say L2960 pla
    old "Oh... U- uhm... Hi!"
    new "B:bel: Então, esta é a minha amiga Amorette, ela vai juntar-se a nós para o stream de hoje."

    # say L2962 amo
    old "Hi! Nice meeting you!"
    new "A:amo: Então este é o rapaz com quem tens estado a fazer streamings ultimamente, Belle!"

    # say L2964 amo
    old "So this is the guy you've been streaming with lately, Belle!"
    new "B:amo: Olá! É um prazer conhecer-te!"

    # say L2965 amo
    old "I can't believe I'm actually meeting you! You know, I'm a big fan of yours."
    new "B:amo: Então este é o rapaz com quem tens estado a fazer stream, Belle!"

    # say L2966 pla
    old "My fan? Really?"
    new "T: Claro que sigo a stream da Belle porque ela é uma das melhores streamers."

    # say L2968 amo
    old "Of course I follow Belle's stream because she's one of the best-ranked streamers."
    new "B:pla: O meu fã? A sério?"

    # say L2970 amo
    old "And lately her content has been great, especially the one she's doing with you."
    new "B:amo: Claro que sigo o stream da Belle porque ela é uma das streamers melhor classificadas."

    # say L2971 amo
    old "So, I'm also a fan of yours."
    new "B:amo: E ultimamente o teu conteúdo tem sido ótimo, especialmente o que estás a fazer comigo."

    # say L2974 amo
    old "But how couldn't I be? After all, you have that amazing cannon in between your legs."
    new "B:amo: Então, eu também sou fã teu."

    # say L2976 amo
    old "With how long and thick it is... I know my views would skyrocket if I ever have you in one of my streams."
    new "B:amo: Mas como é que eu não poderia? Afinal, tu tens esse canhão incrível entre as pernas."

    # say L2977 pla
    old "I- Uh- Well... I- I don't know what to say..."
    new "B:amo: Com o tamanho e a espessura que tem... Sei que as visualizações dos meus streams disparariam se te tivesse em um deles."

    # say L2979 amo
    old "Oh! Look at that reaction! It's so cute, hahaha."
    new "B:pla: I- Uh- Well... I- I não sei o que dizer..."

    # say L2985 bel
    old "Ok guys, everything's already set up, so we're ready to go."
    new "B:amo: Oh! Olha essa reação! É tão fofo, hahaha."

    # say L2986 bel
    old "At first I'll be alone on camera, I'll introduce you and then you can come in Amorette."
    new "B:bel: Ok pessoal, tudo já está preparado, estamos prontos para começar."

    # say L3009 bel
    old "Hey guys! It's great to see you all again!"
    new "B:bel: Ótimo, então vamos lá."

    # say L3010 bel
    old "I've been waiting for today's show more than ever!"
    new "B:bel: Olá a todos! É ótimo ver-vos de novo!"

    # say L3011 bel
    old "Because I have yet another great surprise for you guys!"
    new "B:bel: Tenho estado à espera do espetáculo de hoje mais do que nunca!"

    # say L3012 bel
    old "This is something you have been asking me about! And it's finally time for you guys to enjoy it."
    new "B:bel: Porque tenho mais uma grande surpresa para vocês!"

    # say L3013 bel
    old "So, today I have with me a friend that's going to help us."
    new "B:bel: Isto é algo que tu tens estado a pedir-me! E finalmente é a altura de vocês desfrutarem."

    # say L3014 bel
    old "I know you all know her because she's very popular, so please give a warm welcome to my friend Amorette!"
    new "B:bel: Então, hoje tenho comigo uma amiga que vai nos ajudar."

    # say L3019 amo
    old "Hi guys! How are you?!"
    new "B:bel: Eu sei que todos a conhecem porque ela é muito popular, então por favor, dêem as boas-vindas à minha amiga Amorette!"

    # say L3020 amo
    old "It's so nice to be here!"
    new "B:amo: Olá a todos! Como estão?!"

    # say L3021 amo
    old "Oh, some of you know me from my stream?"
    new "B:amo: É tão bom estar aqui!"

    # say L3022 amo
    old "It's great to see you!"
    new "B:amo: Oh, alguns de vocês me conhecem do meu stream?"

    # say L3023 amo
    old "I hope we'll have a very good time together today guys!"
    new "B:amo: É ótimo ver-te!"

    # say L3025 bel
    old "And of course, my friend from before is also here to help us!"
    new "B:amo: Espero que tenhamos uma ótima tarde juntos, pessoal!"

    # say L3030 bel
    old "Well guys, it's time for me to tell you about the surprise I'd planned for you."
    new "B:bel: E claro, o meu amigo de antes também está aqui para nos ajudar!"

    # say L3032 bel
    old "And it's that today we're having a threesome!"
    new "B:bel: Bem, pessoal, é hora de eu vos contar sobre a surpresa que preparei para vocês."

    # say L3034 bel
    old "It's great right?"
    new "B:bel: E hoje vamos ter um ménage à trois!"

    # say L3035 amo
    old "Yey!"
    new "B:bel: É ótimo, certo?"

    # say L3037 bel
    old "Oh! We've all been waiting for this! Let's not delay it anymore!"
    new "B:amo: Yey!"

    # say L3038 bel
    old "So, remember to tip so that we can reach the goal!"
    new "B:bel: Oh! Todos nós estávamos à espera disto! Vamos deixar de adiar!"

    # say L3045 amo
    old "Oh wow, just look at that dick guys!"
    new "B:bel: Então, lembrem-se de dar gorjetas para que possamos atingir o objetivo!"

    # say L3046 amo
    old "I saw it before on screen, but it's so much bigger in person!"
    new "B:amo: Oh wow, olhem para esse pénis!"

    # say L3047 bel
    old "It's great isn't it?"
    new "B:amo: Vi na tela antes, mas é muito maior ao vivo!"

    # say L3064 bel
    old "Thanks guys, you are the best fans in the world!"
    new "B:bel: É ótimo, não é?"

    # say L3065 bel
    old "I'm very happy and proud of you!"
    new "B:bel: Obrigado, vocês são os melhores fãs do mundo!"

    # say L3066 bel
    old "I hope you enjoyed this threesome as much as we did."
    new "B:bel: Estou muito feliz e orgulhosa de ti!"

    # say L3068 amo
    old "Belle is right guys!"
    new "B:bel: Espero que tenham gostado deste trio tanto quanto nós."

    # say L3069 amo
    old "That was so hot!"
    new "B:amo: A Belle tem razão, pessoal!"

    # say L3072 amo
    old "You guys have been so nice!"
    new "B:amo: Estava tão quente!"

    # say L3074 amo
    old "It makes me think of coming back to stream with Belle again..."
    new "B:amo: Vocês têm sido tão simpáticos!"

    # say L3076 bel
    old "I know if Amorette comes back to stream with us, we will all enjoy it!"
    new "B:amo: Faz-me pensar em voltar a transmitir com a Belle..."

    # say L3078 bel
    old "And of course, my friend here will be back as well!"
    new "B:bel: Sei que se a Amorette voltar a transmitir connosco, todos nós vamos desfrutar!"

    # say L3080 bel
    old "Well, guys, that's all for today."
    new "B:bel: E claro, o meu amigo também vai voltar!"

    # say L3081 bel
    old "Remember to subscribe to my profile and follow me on my social networks!"
    new "B:bel: Bem, pessoal, é tudo por hoje."

    # say L3082 bel
    old "And remember to follow Amorette as well."
    new "B:bel: Lembra-te de subscrever o meu perfil e seguir-me nas minhas redes sociais!"

    # say L3083 bel
    old "She does some amazing things in her stream guys!"
    new "B:bel: E lembra-te de seguir a Amorette também."

    # say L3085 amo
    old "Thanks for the warm reception guys!"
    new "B:bel: Ela faz coisas incríveis na sua transmissão, pessoal!"

    # say L3086 amo
    old "And thank you for having me Belle."
    new "B:amo: Obrigado pela receção calorosa, pessoal!"

    # say L3087 amo
    old "See you later guys!"
    new "B:amo: E obrigado por me teres recebido, Belle."

    # say L3088 bel
    old "Bye guys!"
    new "Eles realmente atingiram o objetivo em pouco tempo!"

    # say L3107 bel
    old "They really reached the goal in no time!"
    new "B:bel: Adeus, pessoal!"

    # say L3108 bel
    old "Thanks a lot guys! I'm amazed it all went this well. And it's all thanks to you!"
    new "B:bel: Conseguiram o objetivo num ápice!"

    # say L3109 amo
    old "You're welcome Belle."
    new "B:bel: Muito obrigada, pessoal! Estou surpreendida que tudo tenha corrido tão bem. E é tudo graças a vocês!"

    # say L3110 amo
    old "I'm very happy to help, and this is also good for my own stream."
    new "B:amo: De nada, Belle."

    # say L3111 amo
    old "It's great that you managed to reach the goal."
    new "B:amo: Estou muito feliz por ajudar, e isto é também bom para o meu próprio canal."

    # say L3114 amo
    old "Just you and me, I'm sure you'll enjoy it."
    new "B:amo: Tu tens de vir fazer um dos meus streams comigo um destes dias."

    # say L3115 pla
    old "Uhh... Sure."
    new "B:amo: Só tu e eu, tenho a certeza que vais gostar."

    # say L3116 bel
    old "Ok, that's great."
    new "B:pla: Uhh... Claro."

    # say L3117 bel
    old "Guys, my mom's coming home soon."
    new "B:bel: Ok, isso é ótimo. T(bel|tu|diz): Pessoal, a minha mãe está a chegar a casa em breve. A:bel: Então seria melhor se tu fosses embora."

    # say L3118 bel
    old "So it would be better if you go."
    new "B:bel: Rapazes, a minha mãe está a chegar em casa logo."

    # say L3121 amo
    old "Thanks again for having me Belle."
    new "B:bel: Então é melhor tu ires."

    # say L3122 amo
    old "I'll see you later."
    new "B:amo: Obrigado mais uma vez por me teres recebido, Belle."

    # say L3123 bel
    old "Sure, thanks for helping me."
    new "B:amo: Vejo-te mais tarde."

    # say L3131 pla
    old "I guess I'll see you later then."
    new "T: Acho que nos vemos mais tarde então."

    # say L3132 bel
    old "Of course, thank you, [pla]."
    new "T(bel|tu|say): Claro, obrigado, [pla]."

    # say L3134 bel
    old "And it's all because of you."
    new "B:bel: Tenho a certeza de que com isto posso ultrapassar a Lana na votação."

    # say L3135 pla
    old "Don't mention it, I know you've worked hard for it, so you deserve to win it."
    new "B:bel: E tudo isso é por tua causa."

    # say L3136 pla
    old "And I'm sure you will."
    new "B:pla: Não há de quê, sei que trabalhaste muito por isso, mereces ganhar."

    # say L3154 pla
    old "Ok! I think I managed to finish it all."
    new "B:pla: Vou-me embora então. Até mais."

    # say L3157 ash
    old "Can you show me?"
    new "A:pla: Aqui, esta é a página inicial, onde deixei informações sobre o negócio."

    # say L3161 pla
    old "Here, this is the homepage, in here I just left information about the business."
    new "T: Aqui, esta é a página inicial, aqui deixei apenas informações sobre o negócio. A: A sua história e coisas assim."

    # say L3162 pla
    old "Their history and stuff."
    new "B:pla: Aqui está a página inicial, deixei aqui informações sobre o negócio."

    # say L3164 pla
    old "If you press here it will take you to the menu."
    new "Se quiser fazer um pedido para levantar mais tarde, podes colocá-lo aqui."

    # say L3166 pla
    old "If you wish to make an order to pick up in advance, you can place it here."
    new "B: pla: Se pressionares aqui, serás levado ao menu."

    # say L3167 pla
    old "There's also an option for you to customize your order."
    new "B: pla: Se quiser fazer um pedido para levantar mais tarde, pode fazê-lo aqui."

    # say L3168 ash
    old "Oh! I see!"
    new "B:pla: Existe também a opção de personalizar o teu pedido."

    # say L3170 pla
    old "Yeah, you can even select the coffee by level of roasting."
    new "T: Sim, podes até escolher o café pelo grau de torrefação."

    # say L3171 pla
    old "Or you can even select the region where it comes from."
    new "B:pla: Sim, podes até escolher o café pelo nível de torrefação."

    # say L3176 ash
    old "I know you're not looking for a job right now."
    new "B:ash: Isto é melhor do que o que já vi alguns desenvolvedores web profissionais fazerem."

    # say L3177 ash
    old "Because you have to do things with school and stuff."
    new "B:ash: Eu sei que tu não estás à procura de trabalho agora."

    # say L3179 ash
    old "But if you ever want to get into web developing, just let me know."
    new "B:ash: Porque tens de fazer coisas da escola e tal."

    # say L3180 ash
    old "I'm sure I'll be able to get you something good."
    new "B:ash: Mas se tu quiseres entrar no desenvolvimento web, basta-me dizer."

    # say L3182 ash
    old "Also, if I ever need your help, I'll let you know."
    new "A:ash: Talvez tu possas dar-me uma mão com algo."

    # say L3184 ash
    old "Maybe you can give me a hand with something."
    new "B:ash: E se precisares da minha ajuda, avisa-me."

    # say L3185 pla
    old "For sure! If I can help you with anything, just tell me, I'll do my best to help you any time I can."
    new "B:ash: Talvez possas dar-me uma mão com algo."

    # say L3196 ash
    old "Wait [pla]."
    new "T(ash|tu|diz): Espera [pla]."

    # say L3198 pla
    old "Yes ma'am?"
    new "A:ash: Antes de ires, queria apenas agradecer-te toda a ajuda que me deste nestes dias."

    # say L3199 ash
    old "Before you leave, I just wanted to take a second to thank you for all the help you've given me these days."
    new "B:pla: Sim, senhora?"

    # say L3201 ash
    old "I was in a very difficult situation, and with your help, I was able to solve it even better than I expected."
    new "B:ash: Antes de ires, só queria agradecer-te por toda a ajuda que me deste nestes dias."

    # say L3202 pla
    old "I just wanted to help you, I'm happy I was able to do something."
    new "B:ash: Estava numa situação muito difícil, e com a tua ajuda, consegui resolvê-la ainda melhor do que esperava."

    # say L3203 ash
    old "And you really did, you're welcome here at our home any time you need."
    new "B:pla: Só queria ajudar-te, fico feliz por ter conseguido fazer algo."

    # say L3208 pla
    old "Bye for now then."
    new "T(pla|tu|say): Adeus por agora então."

    # say L3232 bel
    old "Nothing bad, I'm just a little nervous."
    new "B:pla: Porque é que estás tão desanimado?"

    # say L3236 bel
    old "Well, the results of the voting are coming out today."
    new "B:bel: Nada de mal, estou só um pouco nervosa."

    # say L3238 pla
    old "Already? It didn't take any time."
    new "B:bel: Bem, os resultados da votação saem hoje."

    # say L3240 bel
    old "The contest was a bit longer. It's just that when we started streaming, we were already close to the deadline."
    new "B:pla: Já? Não demorou nada."

    # say L3242 pla
    old "Well, I hope that all the streaming we did helped you win."
    new "B:bel: A competição foi um pouco mais longa. É que quando começámos a transmitir, já estávamos perto do prazo final."

    # say L3244 bel
    old "I don't know, I checked the voting before I went out today. Me and Lana were neck and neck."
    new "B:pla: Espero que todas as transmissões que fizemos tenham ajudado-te a ganhar."

    # say L3245 bel
    old "I haven't seen anything else, I'll check it as soon as I get home."
    new "B:bel: Não sei, verifiquei os votos antes de sair hoje. A Lana e eu estávamos empatados."

    # say L3246 bel
    old "So, I wanted to know if you want to accompany me this afternoon to check the results."
    new "B:bel: Não vi nada mais, vou verificar assim que chegar a casa."

    # say L3248 pla
    old "Sure, I'll come with you."
    new "B:bel: Então, querias saber se queres acompanhar-me esta tarde para ver os resultados."

    # say L3250 pla
    old "For sure, let's go to class for now, and I'll come to your house with you when we're done."
    new "T: Claro, vamos à aula por agora, e eu vou contigo a tua casa quando acabarmos."

    # say L3281 bel
    old "I can't wait to see the results, but I'm also so nervous!"
    new "B:pla: Claro, vamos à aula por agora, e eu vou contigo a tua casa quando acabarmos."

    # say L3282 pla
    old "Don't worry, everything will be fine. Let's get going so we can see the results at your place."
    new "B:bel: Mal posso esperar para ver os resultados, mas também estou tão nervosa!"

    # say L3283 bel
    old "Yes, yes, you're right... Let's go. I'll feel calmer there."
    new "B: Não te preocupes, tudo vai correr bem. Vamos andando para podermos ver os resultados em tua casa."

    # say L3296 bel
    old "Ok, let's check how this all turned out."
    new "T(bel|tu|say): Ok, vamos ver como tudo ficou."

    # say L3302 pla
    old "You did?!"
    new "B:bel: Ok, vamos ver como tudo ficou."

    # say L3303 pla
    old "That's great Belle! Congrats!"
    new "B:pla: Tu fizeste?!"

    # say L3308 pla
    old "What?! This is all because of you! You're the one that has been doing all the hard work."
    new "B:bel: Isto tudo é graças a ti!"

    # say L3309 pla
    old "Really Belle, congrats, you deserve this."
    new "B: pla: Que?! Isto tudo é por tua causa! Tu foste quem fez todo o trabalho duro."

    # say L3311 bel
    old "Well, it was impossible without you."
    new "B:pla: Parabéns, Belle, tu mereces isto."

    # say L3329 bel
    old "What do you mean by 'what's going on here?' And why are you barging into my room as if it's yours?"
    new "B:pla: Parabéns, Belle, tu mereces essa vitória. E fico feliz por ter podido ajudar-te. Isso deixa-me muito contente."

    # say L3335 ash
    old "What the hell is happening?!"
    new "T(ash|tu|diz): Que raio se está a passar?!"

    # say L3337 bel
    old "Woah, woah, woah, where did you get that from?!"
    new "B:ash: Que raio se está a passar?!"

    # say L3340 ash
    old "A coworker showed it to me! He caught his son using his credit card to send money to you on this website."
    new "B:bel: Woah, woah, woah, donde é que tu tiraste isso?!"

    # say L3342 ash
    old "He recognized you and decided to ask me if this was you!"
    new "A:ash: Oh meu Deus Belle! O que raio estás a fazer?"

    # say L3344 ash
    old "Oh my gosh Belle! What the hell are you doing?"
    new "B:ash: Ele reconheceu-te e decidiu perguntar-me se eras tu!"

    # say L3346 ash
    old "Why are you asking for money from strangers on the internet?"
    new "B:ash: Ai meu Deus, Belle! O que raio estás a fazer?"

    # say L3348 ash
    old "If you needed money you could've told me!"
    new "B:ash: Porque estás a pedir dinheiro a estranhos na internet?"

    # say L3350 ash
    old "And doing it this way! Oh my god!"
    new "B:ash: Se precisavas de dinheiro podias ter-me dito!"

    # say L3357 bel
    old "I'm doing it because I like it."
    new "B:bel: Em primeiro lugar, vou-te dizer que não estou a fazer isto por dinheiro!"

    # say L3360 bel
    old "But even if I was doing it for money. What's wrong with me doing something like that?"
    new "B:bel: Estou a fazê-lo porque gosto."

    # say L3362 bel
    old "You're the one who's always telling me that I should just live my sexuality any way I can."
    new "E que eu não devo me importar com o que as pessoas dizem sobre mim."

    # say L3364 bel
    old "And that I shouldn't care about what people have to say about me."
    new "A:ash: Isso não é o problema aqui!"

    # say L3367 ash
    old "That isn't the problem here!"
    new "A:ash: Sabes que estou apenas a assumir o meu novo papel na empresa!"

    # say L3369 ash
    old "You know that I'm just taking over my new role in the company!"
    new "T: Imagina como me senti quando o meu colega de trabalho me disse que o filho dele está a roubar dinheiro para dar à minha filha por estar nua na internet!"

    # say L3371 ash
    old "Imagine how I felt when my coworker told me his son is stealing money from him to give to my daughter for being naked online!"
    new "T: Imagina como me senti quando o meu colega de trabalho me disse que o filho dele está a roubar dinheiro para dar à minha filha por estar nua online!"

    # say L3372 ash
    old "This could bring problems to my image as the branch director of the company. The executives could fire me!"
    new "E o que queres que eu faça? Não fazer só porque esses imbecis no teu trabalho possam pensar mal de ti?"

    # say L3374 bel
    old "And what do you want me to do? To not do it just because those assholes at your job might think bad about it?"
    new "B:ash: Isto pode trazer problemas à minha imagem como diretor da filial da empresa. Os executivos podem demitir-me!"

    # say L3377 bel
    old "I'm sorry but I'm not doing that."
    new "B:bel: E o que queres que eu faça? Não fazer só porque uns imbecis no teu trabalho possam pensar mal disso?"

    # say L3379 ash
    old "Oh my gosh could you be any more selfish?!"
    new "B:bel: Desculpa, mas não estou a fazer isso."

    # say L3380 pla
    old "Ok, ok, why don't you two try to talk about this in a calmer way?"
    new "T: Ok, ok, porque não tentam falar disto de uma forma mais calma? Antes que algum de vocês diga algo que possa vir a lamentar."

    # say L3381 pla
    old "Before either of you says anything that you may regret."
    new "B:pla: Ok, ok, porque não tentam falar disto de uma forma mais calma?"

    # say L3385 ash
    old "I was thinking about who's the person in the video with Belle! It's you isn't it?"
    new "B:pla: Antes de qualquer um de vocês dizer algo que possa vir a lamentar."

    # say L3387 ash
    old "I'm so stupid!"
    new "B:ash: Estava a pensar quem é a pessoa no vídeo com a Belle! És tu, não é?"

    # say L3389 ash
    old "Here I was thinking that you were just a good friend of Belle!"
    new "B:ash: Sou tão estúpido!"

    # say L3390 ash
    old "Someone whom I could trust, and here doing this!"
    new "B:ash: Aqui eu estava a pensar que tu eras só uma boa amiga da Belle!"

    # say L3391 ash
    old "And in my house, of all places!"
    new "B:ash: Alguém em quem eu confiava, e aqui a fazer isto!"

    # say L3393 bel
    old "Wait a minute! Don't involve him in this!"
    new "B:ash: E na minha casa, de todos os lugares!"

    # say L3394 bel
    old "He was just helping me, and it's something that I wanted to do and there's nothing wrong with it!"
    new "B:bel: Espera aí! Não o envolvas nisto!"

    # say L3396 ash
    old "Oh yeah? Well, I'm sorry you want to do it so badly because you're about to stop!"
    new "B:bel: Ele estava só a ajudar-me, e é algo que eu queria fazer e não há nada de errado com isso!"

    # say L3397 ash
    old "I already told you, the people at my company are not okay with this!"
    new "B:ash: Oh yeah? Bem, sinto muito que queiras tanto isto, mas vais parar agora!"

    # say L3399 ash
    old "So, unless whatever money you're making with that is enough for you to pay for everything around here!"
    new "B:ash: Já te disse, as pessoas da minha empresa não estão bem com isso!"

    # say L3400 ash
    old "You're about to stop with this weird little hobby of yours!"
    new "B:ash: Então, a menos que o dinheiro que estás a ganhar com isso seja suficiente para pagares tudo aqui!"

    # say L3402 bel
    old "You have to be kidding me!"
    new "B:ash: Vais parar com esse teu passatempo esquisito!"

    # say L3403 bel
    old "Well I'm sorry, but I'm not going to stop doing anything! And if you don't like me doing it in your house then I guess I can leave!"
    new "B:bel: Tu estás a brincar comigo!"

    # say L3405 ash
    old "Then I guess you can!"
    new "B:bel: Pois bem, mas não vou parar de fazer nada! E se não gostas que eu faça isso na tua casa, acho que posso ir-me embora!"

    # say L3407 bel
    old "I'll do it then!"
    new "Espera! Bela!"

    # say L3415 pla
    old "Wait! Belle!"
    new "B:bel: Vou fazer então!"

    # say L3419 pla
    old "I- uh..."
    new "B:pla: Espera! Belle!"

    # say L3420 pla
    old "I- I'm sorry!"
    new "B:pla: I- hã..."

    # say L3445 bel
    old "Hey, I guess I'm doing ok."
    new "T(bel|tu|diz): Olá, acho que estou bem."

    # say L3447 bel
    old "I left my mom's house, so at least she's not annoying me or anything."
    new "B:bel: Hey, acho que estou bem."

    # say L3448 pla
    old "W- what? You actually left your home?"
    new "T(pla|tu|say): W- what? Tu realmente saíste de casa?"

    # say L3450 bel
    old "I did, what else was I supposed to do?"
    new "B:pla: O- o quê? Tu realmente saíste de casa?"

    # say L3451 bel
    old "I'm not going to stop streaming just to give her the pleasure."
    new "B:bel: Fiz, o que mais era suposto fazer?"

    # say L3452 bel
    old "This is too important for me, no matter what she says."
    new "B:bel: Não vou parar de transmitir só para lhe dar prazer."

    # say L3454 pla
    old "I see, I'm sorry Belle; I feel like I caused this."
    new "B:bel: Isto é muito importante para mim, não importa o que ela diga."

    # say L3455 bel
    old "Don't worry, this isn't your fault. It was bound to happen sooner or later."
    new "B:pla: Entendo, sinto muito, Bela; acho que fui eu quem causou isso."

    # say L3456 pla
    old "I guess."
    new "T(pla|tu|say): Acho que sim."

    # say L3457 pla
    old "So, where are you staying now?"
    new "B:pla: Acho que sim."

    # say L3459 bel
    old "I'm staying at Amorette's apartment."
    new "B:pla: Então, onde estás a ficar agora?"

    # say L3460 bel
    old "It's really nice because she has an entire room where we can stream."
    new "B:bel: Estou a ficar no apartamento da Amorette."

    # say L3461 bel
    old "By the way, she says that you're welcome to come to visit anytime you want."
    new "B:bel: É realmente bom porque ela tem um quarto inteiro onde podemos fazer stream."

    # say L3462 pla
    old "I see... Well, thank you I guess."
    new "B:bel: Aliás, ela diz que tu és bem-vindo para visitá-la quando quiseres."

    # say L3463 pla
    old "Leaving aside her offer."
    new "B:pla: Entendo... Bem, obrigado suponho."

    # say L3465 pla
    old "I hope things will be fixed between you and your mom soon."
    new "B:pla: Deixando de lado a sua oferta."

    # say L3467 bel
    old "Thanks... But I wouldn't count on it."
    new "Obrigado... Mas não contaria com isso."

    # say L3468 bel
    old "Listen, I have a couple of things to do now, so I'll see you later, ok?"
    new "B:bel: Obrigado... Mas não contes com isso."

    # say L3469 pla
    old "Yeah, see you."
    new "B:bel: Ouve, tenho umas coisas para fazer agora, então vejo-te mais tarde, ok?"

    # say L3475 pla
    old "Damn, things between them really went out of whack."
    new "T: Merda, as coisas entre eles realmente saíram do sério."

    # say L3476 pla
    old "Maybe I could do something to help them."
    new "Talvez eu pudesse fazer algo para ajudá-los."


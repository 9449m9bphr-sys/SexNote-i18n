# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/rubAnimations.rpy
translate portuguese strings:

    # say L6 gomRub
    old "Mmm, I love how it tastes."
    new "A: gomRub: O teu pénis é tão grande."

    # say L7 gomRub
    old "Your dick is so big."
    new "B: gomRub: Mmm, adoro o sabor."

    # say L8 gomRub
    old "And you’re so hard."
    new "B: gomRub: O teu pénis é tão grande."

    # say L12 gomRub
    old "Sluurp! Are you enjoying it?"
    new "B: gomRub: E estás tão duro."

    # say L13 pla
    old "Mmm...  I guess. it’s a bit weird with Ruby’s body though."
    new "B:gomRub: Sluurp! Estás a gostar?"

    # say L14 gomRub
    old "Your dick, it’s twitching."
    new "B:pla: Mmm... Acho que sim. É um bocado estranho com o corpo da Ruby, no entanto."

    # say L15 gomRub
    old "Mmm! And it’s so tasty, I love it!"
    new "B: gomRub: O teu pénis, está a tremer."

    # say L19 gomRub
    old "Yes, Yes! I love this feeling in my mouth!"
    new "B: gomRub: Mmm! E é tão saboroso, adoro!"

    # say L20 gomRub
    old "I can feel your body tensing up!"
    new "B: gomRub: Sim, sim! Adoro esta sensação na minha boca!"

    # say L21 pla
    old "T- This is, aaah!"
    new "B: gomRub: Sinto o teu corpo a tensar-se!"

    # say L45 gomRub
    old "Yes! Yes! Do it!"
    new "B: pla: T- Isto é, aaah!"

    # say L46 gomRub
    old "Give me that magic power!"
    new "B: gomRub: Sim! Sim! Faz isso!"

    # say L52 gom
    old "Oh wow! You’d given me magic before, but this is way different!"
    new "B: gomRub: Dá-me esse poder mágico!"

    # say L53 gom
    old "Human bodies are amazing. It feels so different."
    new "B:gom: Oh wow! Tu já me tinhas dado magia antes, mas isto é bem diferente!"

    # say L54 gom
    old "It didn’t feel bad before, it’s just so... weird!"
    new "B: gom: Os corpos humanos são incríveis. Sentes-te tão diferente."

    # say L55 pla
    old "Hmm... Yeah, sure."
    new "Hmm... Sim, claro."


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/graAnimations.rpy
translate portuguese strings:

    # say L6 gra
    old "I feel I'm in heaven just by touching it! Oh my Father, I'm so grateful."
    new "Sinto-me no paraíso só de o tocar! Oh meu Pai, estou tão grata. (Meu Deus!...)"

    # say L7 pla
    old "(My God!...)"
    new "B:gra: Sinto-me no paraíso só por tocar! Oh meu Pai, sou tão grata."

    # say L12 gra
    old "The feeling of your big grace on my hands, it's so pure."
    new "B:pla: (Meu Deus!...)"

    # say L17 gra
    old "My heavenly God!... It's so... S- So great and big, divine!"
    new "B:gra: A sensação da tua graça grande nas minhas mãos, é tão pura."

    # say L41 gra
    old "I feel that grace is going to come in my fac- Ahhhhhh!!!"
    new "B:gra: Meu Deus celestial!... É tão... S- Só grande e divino!"

    # say L58 gra
    old "Your divine phallus is precious, just by seeing it I can feel the glory in him."
    new "B:gra: Sinto que a graça vai entrar no meu rosto... Ahhhhhh!!!"

    # say L59 pla
    old "(Wow is s- she... S- sucking it...)"
    new "B:gra: O teu falo divino é precioso, só de o ver sinto a glória nele."

    # say L63 gra
    old "Your divine phallus tastes like heaven... Oh my Father, I'm so grateful."
    new "B:pla: (Que... que ela... está a... a chupar...)"

    # say L67 gra
    old "My soul is silent and my door is open for you, I need your sacred water in my mouth, I have said many wrong things lately and I gotta clean that."
    new "B:gra: O teu falo divino tem sabor a paraíso... Oh meu Pai, estou tão grata."

    # say L68 gra
    old "I wanna feel it in my tongue... My tongue is thirsty of you..."
    new "B:gra: A minha alma está em silêncio e a minha porta está aberta para ti, preciso da tua água sagrada na minha boca, tenho dito muitas coisas erradas recentemente e preciso limpar isso."

    # say L91 gra
    old "I feel that grace is going to come... To come in my lips!!!"
    new "B:gra: Quero senti-lo na minha língua... A minha língua está sedenta de ti..."

    # say L95 gra
    old "Ahhhhhhhh!!"
    new "B:gra: Sinto que a graça vai chegar... Vai chegar nos meus lábios!!!"

    # say L96 gra
    old "(My Godness!... This is heaven, divine!)"
    new "B:gra: Ahhhhhhhh!!"

    # say L108 pla
    old "(Wow is s- she... S- sucking it again...)"
    new "B:gra: (Meu Deus!... Isto é o céu, divino!)"

    # say L116 gra
    old "I need your sacred water in my mouth, I have said many wrong things lately and I gotta clean that."
    new "B:pla: (Que... que ela... está a... a chupar de novo...)"

    # say L147 gra
    old "Oh father, my soul is silent and my door is open for you, I need you inside of me cleaning my impure soul."
    new "B:gra: Preciso da tua água sagrada na minha boca, tenho dito muitas coisas erradas recentemente e preciso limpar isso."

    # say L148 pla
    old "Does she wants me to f- fuck... her?"
    new "B:gra: Oh pai, a minha alma está em silêncio e a minha porta está aberta para ti, preciso de ti dentro de mim a purificar a minha alma impura."

    # say L167 gra
    old "Ohhh father, I can feel your grace inside me!"
    new "B:pla: Ela quer que eu a f-foda...?"

    # say L168 gra
    old "And it feels sooo goood!"
    new "B:gra: Ohhh pai, posso sentir a tua graça dentro de mim!"

    # say L169 pla
    old "(Ohh yeah...)"
    new "B:gra: E sente-se tão bom!"

    # say L173 gra
    old "Yes, father! Please clean all my sins harder!"
    new "B: pla: (Ohh yeah...)"

    # say L174 gra
    old "Ohhh God! Oh God!"
    new "B:gra: Sim, pai! Por favor, limpa todos os meus pecados mais forte!"

    # say L178 gra
    old "Ahhh Ahhh father. Yes, give me more! MORE!"
    new "B:gra: Ohhh Deus! Oh Deus!"

    # say L201 gra
    old "(My heavenly God!... I'm seeing the heaven!)"
    new "B:gra: Ahhh Ahhh pai. Sim, dá-me mais! MAIS!"

    # say L202 gra
    old "I feel that grace is going to come... To come insid- Ahhhhhh!!!"
    new "B:gra: (Meu Deus do céu!... Estou a ver o céu!)"

    # say L219 gra
    old "My heavenly God, it's so big."
    new "B:gra: Sinto que a graça vai chegar... Vai chegar den- Ahhhhhh!!!"

    # say L224 gra
    old "Oh God! It tastes like heaven..."
    new "B:gra: Meu Deus celestial, é tão grande."

    # say L228 gra
    old "I need to purify my soul with your holy milk."
    new "B:gra: Oh Deus! É como o paraíso..."

    # say L251 pla
    old "Sister Grace... I- I-"
    new "B:gra: Preciso purificar a minha alma com o teu leite sagrado."

    # say L252 gra
    old "Oh yeah! I want to feel that grace in my mouth-"
    new "B:pla: Irmã Grace... Eu- Eu-"

    # say L268 gra
    old "Ahhhhhh!!! I can feel the greatness of your body inside me..."
    new "B:gra: Oh yeah! Quero sentir essa graça na minha boca..."

    # say L273 gra
    old "I wanted this so badly... There is no pain I can't bear for God."
    new "B:gra: Ahhhhhh!!! Posso sentir a grandeza do teu corpo dentro de mim..."

    # say L274 gra
    old "Harder! Harder! I want you to make me feel more pain!"
    new "B:gra: Eu queria tanto isto... Não há dor que eu não suporte por Deus."

    # say L279 gra
    old "Ahhhhhh! Ahhhhh! Ahhh!"
    new "B:gra: Mais forte! Mais forte! Quero que me faças sentir mais dor!"

    # say L280 gra
    old "My soul needs as much forgiveness as my body needs punishment."
    new "A minha alma precisa de tanta misericórdia quanto o meu corpo precisa de castigo."


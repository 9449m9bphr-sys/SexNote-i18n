# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Mechanics/Navigation.rpy
translate portuguese strings:

    # say L361 pla
    old "I shouldn't for now."
    new "Não devo por agora."

    # say L372 pla
    old "I shouldn't for now"
    new "Não devo agora."

    # say L417 pla
    old "I shouldn't now"
    new "A:pla: A escola está fechada. Devo ir para casa."

    # say L953 pla
    old "The school is closed. I should just go home."
    new "T: A escola está fechada. Devo ir para casa."

    # say L1248 pla
    old "I shouldn't enter right now. I don't have any appointments..."
    new "Não devo entrar agora. Não tenho nenhum compromisso..."


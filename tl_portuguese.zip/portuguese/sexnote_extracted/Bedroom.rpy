# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Bedroom.rpy
translate portuguese strings:

    # say L10 pla
    old "I should go to the garage to talk with Brixxida first..."
    new "Devo ir à oficina falar com a Brixxida primeiro..."

    # say L22 pla
    old "Ah. I feel rested..."
    new "T(pla|tu|say): Ah. Sinto-me descansado..."

    # say L61 pla
    old "I should probably go talk to Billie..."
    new "B: Ah. Sinto-me descansado..."

    # menu L67 
    old "Sleep"
    new "Dormir"

    # say L82 pla
    old "It's time to sleep..."
    new "B:n: Dormir"

    # say L321 pla
    old "Ready for a new day!"
    new "B:pla: É hora de dormir..."

    # say L383 pla
    old "Oh shit... Not again..."
    new "B:pla: Wow... O que se está a passar..."

    # say L400 pla
    old "What the hell!..."
    new "B:pla: Oh merda... Não de novo..."

    # say L416 pla
    old "Really? You again!?..."
    new "O que raio!... Tu de novo!?..."


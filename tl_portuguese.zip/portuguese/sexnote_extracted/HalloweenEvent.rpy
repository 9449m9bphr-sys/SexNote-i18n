# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/HalloweenEvent.rpy
translate portuguese strings:

    # say L10 pla
    old "Uhh, I didn't sleep well last night... I should drink a cup of water... "
    new "Oh, olá querida, bom dia!"

    # say L25 mo1
    old "Oh, hi honey, good morning!"
    new "B:pla: Uhh, não dormi bem ontem à noite... Devo beber um copo de água..."

    # say L26 pla
    old "Uhh, good morning..."
    new "B:mo1: Oh, olá querida, bom dia!"

    # say L27 mo1
    old "Do you have everything ready for tonight?"
    new "B:pla: Uhh, bom dia..."

    # say L28 pla
    old "T- onight?"
    new "A:mo1: A festa de Halloween é hoje à noite... Tu já tens o teu disfarce?"

    # say L29 mo1
    old "The halloween party is tonight... Don't you have your costume already?"
    new "B:pla: T- esta noite?"

    # say L30 pla
    old "Ohh... Right, I completely forget about that... Ehmm no, actually I don't have a costume yet..."
    new "B:mo1: A festa de Halloween é hoje à noite... Tu já tens o teu disfarce?"

    # say L33 mo1
    old "You are welcome honey."
    new "B:pla: Ótimo, vou falar com ela. Obrigado!"

    # say L52 sis
    old "Ohh, hey [pla]! How do I look with this costume?"
    new "Ohh, olá [pla]! Como fico com este fato?"

    # say L58 sis
    old "Perfect. Do you wanna see the fun thing about this costume?"
    new "B:pla: Hmm, ela está na cozinha... Porquê?"

    # say L59 pla
    old "The fun... Thing? What do you mean?"
    new "B:sis: Perfeito. Queres ver a parte divertida deste fato?"

    # say L60 sis
    old "Hahaha, you are going to love it!"
    new "B:pla: A coisa... Divertida? O que tu queres dizer?"

    # say L61 pla
    old "Hmm a- alright..."
    new "B:sis: Hahaha, vais adorar!"

    # say L62 sis
    old "Well, I chose this costume for just one reason, it has a tail. Do you see it?"
    new "B:pla: Hmm a- alright..."

    # say L63 pla
    old "Hmm... Yes."
    new "B:sis: Bem, escolhi este fato por uma única razão, tem uma cauda. Tu vês?"

    # say L64 sis
    old "Ok, now I'm going to take it out."
    new "Tu vais fazer o quê-"

    # say L65 pla
    old "You are going to wha-"
    new "B:sis: Ok, agora vou tirá-lo."

    # say L72 sis
    old "I wanted something like this from a long time ago... Did you know I have never try anal sex?"
    new "B:pla: Vais fazer o quê..."

    # say L77 sis
    old "Well I wanna change that today... I want you to fuck my ass..."
    new "B: Irmã: Quisera ter algo assim há muito tempo... Sabias que nunca experimentei sexo anal?"

    # say L103 pla
    old "I did it gently..."
    new "B:sis: Uau, foi melhor do que eu pensei, e o teu pénis grande não me doeu nada..."

    # say L104 sis
    old "Definitely we need to repeat it."
    new "B:pla: Fiz com suavidade..."

    # say L105 pla
    old "Uhh... O- ok."
    new "B:sis: Definitivamente precisamos repetir."

    # say L108 sis
    old "Ohh, your costume? Is in your bedroom."
    new "B:pla: Espera... Hmm, vim porque preciso de um fato de Halloween."

    # say L109 pla
    old "Oh really?"
    new "B:sis: Ohh, o teu fato? Está no teu quarto."

    # say L110 sis
    old "Yes, I left it there a few minutes ago."
    new "B:pla: Oh realmente?"

    # say L111 pla
    old "Ohh, thank you so much."
    new "B:sis: Sim, deixei lá há uns minutos."

    # say L112 sis
    old "You're welcome. You will like that costume, it's perfect for you."
    new "B:pla: Ohh, obrigado(a)."

    # say L113 pla
    old "Hmm... Alright."
    new "B:sis: De nada. Vais gostar desse fato, é perfeito para ti."

    # say L126 pla
    old "Uhh, yes."
    new "A:mo1: Hmm, podias vir aqui um minuto?"

    # say L127 mo1
    old "Hmm could you please come for a minute?"
    new "B:pla: Hum, sim."

    # say L137 pla
    old "Ohhh wow!"
    new "B:mo1: Hmm, podias vir cá um minuto?"

    # say L138 mo1
    old "I'm sorry... Is just that this costume is a bit hard to dress up... Could you please help me with that?"
    new "B:pla: Ohhh wow!"

    # say L139 pla
    old "Uhh... S- sure."
    new "B:mo1: Desculpa... É que este fato é um bocado difícil de vestir... Poderias ajudar-me com isso?"

    # say L140 mo1
    old "Thank you. You are a sweetheart!"
    new "Obrigado. Tu és um anjo!"

    # say L141 pla
    old "Ok... Let's see..."
    new "B:mo1: Obrigado. Tu és um amor!"

    # say L146 pla
    old "Well, I think is done..."
    new "B:pla: Ok... Vamos ver..."

    # say L151 mo1
    old "Oh, it's perfect just like in the box picture!"
    new "B:pla: Bem, acho que está feito..."

    # say L152 mo1
    old "Oh, wait... It doesn't cover up my nipples at all..."
    new "B:mo1: Oh, está perfeito tal como na imagem da caixa!"

    # say L165 mo1
    old "Oh, honey don't worry... You got hard for my tits?"
    new "B: Desculpa... Não quis dizer-"

    # say L168 mo1
    old "Ok, what about if I help you with them?"
    new "B:mo1: Oh, querida, não te preocupes... Ficaste com tesão pelos meus peitos?"

    # say L170 mo1
    old "Get naked and let me return you the help."
    new "B:mo1: Ok, e se eu te ajudar com eles?"

    # say L178 mo1
    old "Do you like my boobs honey?"
    new "B:mo1: Despe-te e deixa-me retribuir-te a ajuda."

    # say L179 pla
    old "Uhh.... Y- yes... I love your boobs."
    new "B:mo1: Gostas das minhas tetas, querido?"

    # say L180 mo1
    old "Then fuck them!"
    new "B:pla: Uhh.... S- sim... Adoro os teus peitos."

    # say L196 mo1
    old "Do you feel better now honey?"
    new "B:mo1: Então fode-os!"

    # say L197 pla
    old "Y- yes... Thank you."
    new "B:mo1: Estás melhor agora, querida?"

    # say L199 pla
    old "Uhh... W- with [sis]..."
    new "B:mo1: Não, agradeço a tua ajuda com este fato. Por acaso, falaste com o [sis]?"

    # say L201 pla
    old "Ohhh the costume, right... Yes, I have it in my bedroom, I need to try it"
    new "B:mo1: Sim, sobre o teu fato."

    # say L202 mo1
    old "Oh great, then go, if you need any help just let me know. Now I'm going to clean this mess."
    new "B:pla: Ohhh o fato, certo... Sim, tenho-o no meu quarto, preciso experimentá-lo."

    # say L203 pla
    old "Alright, Thank you."
    new "(Tudo bem, devo experimentar o fato.)"

    # say L208 pla
    old "(Alright, I should try the costume.)"
    new "B:pla: Tudo bem, obrigado."

    # say L230 sis
    old "Oh, you have your costume! You look great!"
    new "Obrigado, mas estava a pensar no que é q-"

    # say L231 pla
    old "Thank you, but I was wondering what is t-"
    new "B:sis: Oh, tu tens o teu fato! Ficas ótimo!"

    # say L232 sis
    old "Hmm your costume is not ready..."
    new "B:pla: Obrigado, mas estava a pensar no que é t-"

    # say L234 sis
    old "You need to get hard to fill the snake."
    new "B:sis: Hmm o teu fato não está pronto..."

    # say L235 pla
    old "F- fill the snake? "
    new "B:sis: Precisas de ficar duro para encher a cobra."

    # say L236 sis
    old "You always have to be that slow?"
    new "B:pla: F- encher a cobra?"

    # say L238 sis
    old "Alright, let me give you a blowjob to make you hard-"
    new "B:sis: Tu tens sempre de ser tão lento?"

    # say L245 mo1
    old "Hi guys, what are you doing?"
    new "B:sis: Tudo bem, vou fazer-te uma felação para te deixar duro-"

    # say L247 pla
    old "(Oh shit...)"
    new "B:mo1: Olá a todos, o que estão a fazer?"

    # say L249 mo1
    old "Oh really, what does he need?"
    new "A:sis: Ele precisa ficar duro para encher o fato."

    # say L250 sis
    old "He needs to get hard to fill his costume."
    new "B:mo1: Oh, realmente, o que ele precisa?"

    # say L253 mo1
    old "Oh, the snake will become to anaconda?"
    new "B:sis: Ele precisa ficar duro para encher o fato."

    # say L255 pla
    old "(What the hell!?)"
    new "B:mo1: Oh, a cobra vai virar anaconda?"

    # say L256 sis
    old "Exactly! I was thinking in a blowjob. What do you think?"
    new "B:pla: (Que raio!?)"

    # say L258 mo1
    old "What about a double blowjob, I think that would make him hard for all night!"
    new "B:sis: Exactamente! Estava a pensar numa fellatio. E tu, o que achas?"

    # say L260 pla
    old "(WHAT THE FUCK IS GOING ON?!)"
    new "B:mo1: E se fizermos um duplo boquete, acho que isso o deixará duro a noite toda!"

    # say L261 sis
    old "Great idea!"
    new "B:pla: (QUE RAIO ESTÁ A ACONTECER?!)"

    # say L293 mo2
    old "I- I REALLY CAN BELIEVE IT..."
    new "B:pla: OHHHH MERDA...."

    # say L294 pla
    old "(OH GOD I'M DEAD.)"
    new "A:mo2: Não posso acreditar que todos vocês começaram a festa sem mim..."

    # say L295 mo2
    old "I can't believe all of you started the party without me..."
    new "B:pla: (OH GOD I'M DEAD.)"

    # say L296 pla
    old "WHAAAAATTT...."
    new "B:mo2: Não posso acreditar que vocês começaram a festa sem mim..."

    # say L297 mo1
    old "There is more for you too..."
    new "B:pla: WHAAAAATTT...."

    # say L299 sis
    old "We will give you the best spot."
    new "B:mo1: Há mais para ti também..."

    # say L301 mo2
    old "And what are we waiting for? Let's enjoy!"
    new "B:sis: Vamos dar-te o melhor lugar."

    # say L314 mo1
    old "This is just a halloween party..."
    new "B:mo2: E por que estamos à espera? Vamos aproveitar!"

    # say L315 sis
    old "Don't you want to join us?"
    new "B:mo1: Isto é só uma festa de Halloween..."

    # say L316 mo2
    old "You can't lose this chance..."
    new "B:sis: Não queres juntar-te a nós?"

    # say L317 pla
    old "... What the hell... Let's do it!"
    new "B:mo2: Não podes perder esta oportunidade..."

    # say L326 pla
    old "Oh God... I can't anymore"
    new "B:pla:... Que raio... Vamos lá!"

    # say L331 pla
    old "Hmm... I- I just can't... I'm really tired..."
    new "Oh não, meu amor, tu não estás a perceber."

    # say L332 mo1
    old "Oh no honey, you don't understand."
    new "B:pla: Hmm... I- I não consigo... Estou mesmo cansado..."

    # say L333 mo2
    old "You fucked us, now is our turn to fuck you."
    new "B:mo1: Oh não querida, tu não percebes."

    # say L339 sis
    old "We want to fuck you..."
    new "B:mo2: Tu fodeste-nos, agora é a nossa vez de te foder."

    # say L340 mo1
    old "Just like you did..."
    new "B: Irmã: Queremos foder-te..."

    # say L341 mo2
    old "We are going to drill you."
    new "B:mo1: Como tu fizeste..."

    # say L350 pla
    old "Wow... It was just a nightmare... Thank God."
    new "B:mo2: Vamos treinar-te."

    # say L351 pla
    old "Hmm... Actually it wasn't a nightmare at all..."
    new "B:pla: Uau... Foi apenas um pesadelo... Graças a Deus."


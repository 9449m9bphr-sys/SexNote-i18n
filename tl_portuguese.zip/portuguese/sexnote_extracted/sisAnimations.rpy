# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/sisAnimations.rpy
translate portuguese strings:

    # say L6 pla
    old "W- What are you doing?"
    new "O que é que parece?"

    # say L7 sis
    old "What does it look like?"
    new "B: pla: O-O que estás a fazer?"

    # say L12 sis
    old "Hmm, your cock is so tasty!"
    new "Hmm, o teu pénis é tão saboroso! Não gostas disto?"

    # say L13 sis
    old "Don't you like it?"
    new "B: Irmã: Hmm, o teu pénis é tão saboroso!"

    # say L18 sis
    old "I can't believe you have such a big cock!"
    new "B:sis: Não gostas disto?"

    # say L43 pla
    old "Please, stop. You are... Gonna make me-"
    new "B: Irmã: Não posso acreditar que tenhas um pénis tão grande!"

    # say L44 sis
    old "Cum? Oh please do it. I'm dying to see this monster cock cum all over..."
    new "B: pla: Por favor, para. Tu vais... Vai fazer-me-"

    # say L50 sis
    old "Shit! That was so intense... Did you like it?"
    new "B: Irmã: Ejacular? Oh, por favor, faz isso. Estou a morrer de vontade de ver este pénis gigante ejacular por todo o lado..."

    # say L51 pla
    old "Ye... I- I have to go..."
    new "B:sis: Merda! Isso foi tão intenso... Tu gostaste?"

    # say L58 pla
    old "What the fuck was that?"
    new "B:pla: Ye... E-E tenho que ir..."

    # say L59 pla
    old "I better go to sleep now..."
    new "B:pla: Que raio foi isso?"

    # say L74 pla
    old "Ready for a new day!..."
    new "B:pla: Melhor ir dormir agora..."

    # say L92 sis
    old "Hmm I love this taste."
    new "B:pla: Pronto para um novo dia!..."

    # say L93 sis
    old "Do you like how it feels inside my mouth?"
    new "Tu: Gostas da sensação dentro da minha boca? É tão grande que quero tudo dentro, achas que sou capaz?"

    # say L97 sis
    old "It's fucking huge, I want to have it all inside, do you think I'm capable?"
    new "B: Irmã: Gostas da sensação dentro da minha boca?"

    # say L99 sis
    old "Oh my god, I can feel it reaching my throat."
    new "B: Irmã: É tão grande, quero ter tudo dentro, achas que sou capaz?"

    # say L103 sis
    old "What about a deepthroat?"
    new "B:sis: Oh meu Deus, sinto-o a chegar à minha garganta."

    # say L105 pla
    old "Oh my God!"
    new "B:sis: E um deepthroat?"

    # say L106 sis
    old "Oh my, I can feel every inch inside my mouth!"
    new "B:pla: Oh meu Deus!"

    # say L129 pla
    old "Ohhh, I- I!"
    new "B:sis: Oh meu, posso sentir cada centímetro dentro da minha boca!"

    # say L134 sis
    old "Wow... That was massive, let me clean this mess... "
    new "B:pla: Ohhh, eu- eu!"

    # say L163 pla
    old "(Oh man in a second I will be hard...)"
    new "B:sis: Uau... Isso foi enorme, deixa-me limpar esta bagunça..."

    # say L166 sis
    old "Ohh, I love it ... My tits are very sensitive, I'm getting horny..."
    new "B:pla: (Oh, homem, daqui a pouco estou duro...)"

    # say L170 sis
    old "Ohh yeah, just like that... Don't stop baby..."
    new "B:sis: Ohh, adoro... Os meus peitos são muito sensíveis, estou a ficar excitada..."

    # say L207 sis
    old "How does it feel in between these amazing boobs?"
    new "B:sis: Ohh yeah, just like that... Não pares, bebé..."

    # say L208 pla
    old "Ohh... It... Feels great."
    new "B:sis: Como é que se sente entre estes peitos incríveis?"

    # say L211 sis
    old "Ohh... It feels really good..."
    new "B:pla: Ohh... É... Maravilhoso."

    # say L212 sis
    old "Do not try to stop, keep moving faster."
    new "B: Irmã: Ohh... Sente-se tão bem..."

    # say L216 sis
    old "Oh yeah, fuck my tits! Harder, fuck them harder!"
    new "B:sis: Não tentes parar, continua mais rápido."

    # say L259 pla
    old "Hey Ky-... (Wow!)"
    new "B:sis: Oh yeah, goza todo em cima de mim!"

    # say L260 pla
    old "Oh shit, she is playing with her dildo..."
    new "B:pla: Ei Ky-... (Uau!)"

    # say L261 pla
    old "I have to keep quiet so she doesn't notice me."
    new "B:pla: Oh merda, ela está a brincar com o seu dildo..."

    # say L265 sis
    old "Mmm, it feels so good!"
    new "B:pla: Tenho de ficar em silêncio para ela não me notar."

    # say L266 sis
    old "My pussy wants a big, hard cock!"
    new "B: Irmã: Mmm, sinto-me tão bem!"

    # say L270 sis
    old "Oh yeah! it feels better than fingering!"
    new "B: Irmã: A minha xoxota quer um pau grande e duro!"

    # say L271 sis
    old "I'm so fucking wet right now."
    new "B:sis: Oh yeah! Sente-se melhor do que com os dedos!"

    # say L302 sis
    old "Ughhh I can't take it anymore, I want to feel my pussy fucked! "
    new "B:sis: Estou tão molhada agora."

    # say L304 pla
    old "(Oh wow!)"
    new "B:sis: Ughhh já não aguento mais, quero sentir a minha xoxota a ser fodida!"

    # say L305 sis
    old "Ohhh yeah!"
    new "B:pla: (Oh wow!)"

    # say L309 sis
    old "Ahhh, yes! Right there."
    new "B:sis: Ohhh sim!"

    # say L310 sis
    old "This is so fucking good!"
    new "B:sis: Ahhh, sim! Ali mesmo."

    # say L314 sis
    old "Mmmm, I want to cum now!"
    new "B: Irmã: Isto é tão bom!"

    # say L343 sis
    old "Oh, yeah! Yeahh!!!"
    new "B: Irmã: Mmmm, quero gozar agora!"

    # say L344 sis
    old "I'm cumming!"
    new "B:sis: Oh, sim! Simmm!!!"

    # say L360 pla
    old "(Oh my god it's like my dream!)"
    new "B: Irmã: Estou a gozar!"

    # say L365 pla
    old "A- alright..."
    new "B: Irmã: Vamos! Quero que me fodas a garganta mais forte!"

    # say L370 sis
    old "I want to have it all inside my mouth."
    new "B:pla: A- tudo bem..."

    # say L397 sis
    old "Don't stop, don't stop! Cum inside my throat!"
    new "Não pares, não pares! Goza dentro da minha garganta! Ohh! É tão grande..."

    # say L414 sis
    old "Ohh! It's so big..."
    new "B: Irmã: Não pares, não pares! Goza dentro da minha garganta!"

    # say L415 sis
    old "Your cock is so much better than my dildo."
    new "B:sis: Ohh! É tão grande..."

    # say L429 sis
    old "You're drilling me"
    new "B: Irmã: Ai meu Deus! É tão grande!"

    # say L452 sis
    old "I'M GONNA... I'M GONNA-"
    new "B: Irmã: Estás a treinar-me"

    # say L453 sis
    old "OOOOOHHHH! YEAHHH..."
    new "B: Irmã: VOU... VOU..."

    # say L457 sis
    old "Fuck... It was really good..."
    new "B:sis: OOOOOHHHH! SIMMMM..."

    # say L466 pla
    old "Ok... Let me try, like this?"
    new "B: Irmã: Merda... Foi mesmo bom..."

    # say L467 sis
    old "Just relax your hands and enjoy what you are doing, don't you like it?"
    new "B:pla: Ok... Vou tentar assim?"

    # say L468 pla
    old "Gulp... Y-yes."
    new "B:sis: Só relaxa as mãos e aproveita o que estás a fazer, não gostas?"

    # say L471 sis
    old "Yeah, you're doing great, very gentle."
    new "B:pla: Engasga... S-sim."

    # say L472 pla
    old "(This is delicious, she is so hot.)"
    new "B:sis: Sim, estás a fazer muito bem, muito suave."

    # say L473 sis
    old "Do you like my ass?"
    new "B: pla: (Isto é delicioso, tu estás tão quente.)"

    # say L478 sis
    old "Be creative, you can touch all you want! I like it."
    new "B: Irmã: Gostas do meu rabo?"

    # say L479 sis
    old "Do it harder baby..."
    new "B: Irmã: Seja criativa, podes tocar onde quiseres! Eu gosto."

    # say L517 sis
    old "Ugghh... It feels great."
    new "B: Irmã: Faz mais forte, baby..."

    # say L518 sis
    old "Oh yeah... Fuck my pussy baby."
    new "B: Irmã: Ugghh... Sente-se tão bem."

    # say L522 sis
    old "Ohh yeah baby, don't stop."
    new "B: Irmã: Oh sim... Foda-me, baby."

    # say L551 sis
    old "OHH GOD, OHH GOD. I'M CUMMING!"
    new "B:sis: Ahhh, ahhh, vou gozar. Mais forte. Foda-me mais forte!"

    # say L553 pla
    old "I- I'm cumming too!"
    new "B:sis: OHH DEUS, OHH DEUS. EU ESTOU A GOZAR!"

    # say L556 sis
    old "Oh yeah... I can feel it all inside me."
    new "B:pla: I- I'm cumming too!"

    # say L570 sis
    old "I love playing with your cock"
    new "Aproveita a vista..."

    # say L571 sis
    old "Enjoy the view..."
    new "B: Irmã: Adoro brincar com o teu pénis"

    # say L574 sis
    old "Do you like my throat?"
    new "B:sis: Aproveita a vista... T(sis|tu|diz): Gostas da minha garganta? A:pla: Oh sim..."

    # say L575 pla
    old "Oh yes..."
    new "B:sis: Gostas da minha garganta?"

    # say L576 sis
    old "Then, what are you waiting to fuck it?"
    new "B:pla: Oh sim..."

    # say L625 sis
    old "Ughh, is so big."
    new "B: Irmã: Goza na minha boca, bebé..."

    # say L626 sis
    old "I love it!!!"
    new "B: Irmã: Ughh, é tão grande."

    # say L633 sis
    old "My pussy is gripping that fucking cock."
    new "B: Irmã: Ohh, quero-te bem dentro de mim..."

    # say L636 sis
    old "HARDER! FUCK ME HARDER BABY!"
    new "B: Irmã: A minha xoxota está a agarrar aquele pénis."

    # say L638 sis
    old "OH GOD, OH GOD! I'M CUMING!"
    new "A:pla: Vou..."

    # say L661 pla
    old "I'm gonna-"
    new "B:sis: OH DEUS, OH DEUS! ESTOU A GOZAR!"

    # say L662 sis
    old "YES BABY CUM INSIDE ME!"
    new "B:pla: Vou..."

    # say L707 sis
    old "Alright, now it's time to wake up."
    new "B: Irmã: SIM BEBÉ EJacula DENTRO DE MIM!"

    # say L709 sis
    old "This is a dream, dummy... "
    new "B:sis: Está na hora de acordares."

    # say L710 sis
    old "Did you really think that I would let you fuck my mouth?"
    new "B: Isto é um sonho, parvo..."

    # say L712 sis
    old "Hahaha! Hahahaha!"
    new "B: pla: I- I-"

    # say L721 linSis
    old "That’s right, just let me do the work."
    new "B:sis: Hahaha! Hahahaha!"

    # say L722 linSis
    old "Mmmm! It’s so big."
    new "B:linSis: Tens razão, deixa-me fazer o trabalho."

    # say L723 pla
    old "Do you feel ok? Has anything changed?"
    new "B:linSis: Mmmm! É tão grande."

    # say L724 linSis
    old "I do, it feels so different, human bodies are more sensitive after all."
    new "B:pla: Tu estás bem? Houve alguma mudança?"

    # say L725 linSis
    old "But nothing has changed, no problem."
    new "B:linSis: Eu faço, sente-se tão diferente, os corpos humanos são mais sensíveis afinal."

    # say L729 linSis
    old "Oh, yes, like that."
    new "B:linSis: Mas nada mudou, sem problemas."

    # say L730 linSis
    old "It feels soo great."
    new "B:linSis: Oh, sim, assim."

    # say L731 pla
    old "Do you feel any magic?"
    new "B:linSis: Sinto-me tão bem."

    # say L732 linSis
    old "Not yet... Ah! keep going."
    new "B:pla: Sentes alguma magia?"

    # say L733 linSis
    old "Maybe in a little. Mmmm."
    new "B:linSis: Ainda não... Ah! continua."

    # say L737 linSis
    old "AH, AH, YES!"
    new "B:linSis: Talvez daqui a pouco. Mmmm."

    # say L738 linSis
    old "N- now I feel it."
    new "B:linSis: AH, AH, SIM!"

    # say L739 linSis
    old "Don’t stop, keep going!"
    new "B:linSis: A- agora eu sinto."

    # say L762 pla
    old "I- I can’t hold it anymore."
    new "B:linSis: Não pares, continua!"

    # say L764 linSis
    old "Oh yes, do it!"
    new "B:pla: I- I já não aguento mais."

    # say L766 linSis
    old "Ohh yeahh!"
    new "B:linSis: Oh sim, faz isso!"

    # say L772 lin
    old "Amazing, it’s incredible how much magic power you’re able to hold and release."
    new "B:linSis: Ohh yeahh!"

    # say L773 lin
    old "And doing it in a human body felt so different and good!"
    new "T(lin|tu|say): E fazê-lo num corpo humano foi tão diferente e bom!"


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/veeAnimations.rpy
translate portuguese strings:

    # say L6 vee
    old "Oh yeah! This is just magical!"
    new "vee: Adoro que estejas a ver-me, Pai!"

    # say L7 vee
    old "I love that you're watching me, Daddy!"
    new "B:vee: Oh sim! Isto é mesmo mágico!"

    # say L8 vee
    old "I miss your dick so much!"
    new "B:vee: Adoro que estejas a ver-me, Pai!"

    # say L12 vee
    old "Do you like to see me touching my pussy?"
    new "B:vee: Sinto tanta falta do teu pénis!"

    # say L13 vih
    old "Oh yeah baby! I love it!"
    new "B:vee: Gostas de me ver a tocar na minha xoxota?"

    # say L14 vih
    old "I can't wait to fuck your pussy myself!"
    new "B:vih: Oh sim, bebé! Adoro isto!"

    # say L18 vee
    old "Oh daddy! It feels as if you were here!"
    new "B:vih: Não posso esperar para foder a tua xoxota!"

    # say L19 vee
    old "I can't get enough of this!"
    new "B:vee: Oh pai! Sinto como se tu estivesses aqui!"

    # say L20 vee
    old "I want more and more!"
    new "B:vee: Não consigo parar!"

    # say L43 vee
    old "I- I'm about to cum honey!"
    new "B:vee: Quero mais e mais!"

    # say L44 vih
    old "Do it! I'm about to cum too!"
    new "B:vee: I- I'm about to cum, querida!"

    # say L45 vee
    old "Oh yeah! Let's do it together!"
    new "B:vih: Faz isso! Estou quase a gozar também!"

    # say L52 vee
    old "Oh that was magical honey."
    new "B:vee: Oh sim! Vamos fazer juntos!"

    # say L53 vee
    old "I can't wait to see you again to feel you inside me."
    new "B:vee: Oh, isso foi mágico, meu amor."

    # say L54 vih
    old "Oh yeah, I can't wait to fuck you too."
    new "B:vee: Não posso esperar para te ver de novo e sentir-te dentro de mim."

    # say L57 vih
    old "Is everything alright? You just got quiet all of a sudden."
    new "O que?! Ah, sim!"

    # say L58 vee
    old "What?! Oh yeah!"
    new "T(vee|tu|dizes): Que?! Oh, sim!"

    # say L59 vee
    old "It's just that I think I heard some steps in the hallway."
    new "B:vee: Que?! Oh sim!"

    # say L60 vee
    old "Maybe we should end the call here honey, in case one of the girls comes in."
    new "B:vee: É que acho que ouvi passos no corredor."

    # say L61 vih
    old "Hmph, yeah you're right."
    new "B:vee: Talvez devamos acabar a chamada aqui, meu amor, para o caso de uma das raparigas entrar."

    # say L62 vih
    old "Talk to you later then."
    new "B:vih: Hmph, sim, tens razão."

    # say L63 vee
    old "Bye honey, I love you."
    new "T(vee|tu|diz): Adeus querido, amo-te."

    # say L64 vee
    old "Hey, you! I already saw you there peeping, come in here and close the door behind you!"
    new "B:vee: Adeus querida, amo-te."


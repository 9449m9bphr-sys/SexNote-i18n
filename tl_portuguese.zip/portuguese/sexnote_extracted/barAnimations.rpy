# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/barAnimations.rpy
translate portuguese strings:

    # say L53 pla
    old "Uhmm... I- I don't think that was in the script Barbie."
    new "Uhmm... A- acho que isso não estava no roteiro, Barbie."

    # say L112 pla
    old "B- barbie! I- I'm about to...!"
    new "B: Uhmm... A- acho que isso não estava no roteiro, Barbie."

    # say L123 pla
    old "Yeah... I'm glad."
    new "B: B- barbie! I- I'm about to...!"

    # say L124 pla
    old "But I wasn't expecting that."
    new "B:pla: Sim... Estou contente."

    # say L125 pla
    old "Maybe you should be careful when you drink..."
    new "T(pla|tu|say): Talvez devesse ter cuidado quando bebes..."

    # say L153 pla
    old "I- I do!"
    new "B: pla: Talvez deves ter cuidado quando bebes..."

    # say L176 pla
    old "B- barbie I- I can't hold it in anymore!"
    new "B: pla: Eu- Eu faço!"

    # say L188 pla
    old "Uhmm, yeah... But we really can't right now."
    new "B: B- barbie I- Não aguento mais!"

    # say L189 pla
    old "So how about you get up? So I can get my pants up."
    new "B:pla: Hummm, sim... Mas não podemos agora."

    # say L239 pla
    old "B- Barbie! I- I'm about to cum!"
    new "B: pla: Então, tu vais-te levantar? Para eu poder subir as calças."

    # say L411 joh
    old "Is Hinn with you?"
    new "B:joh: Estás aqui para ver alguém?"

    # say L413 pla
    old "D- Dr. Johnson! H- hi!"
    new "B:joh: Tu estás com alguém?"

    # say L414 pla
    old "N- no, I'm not here with anybody."
    new "B:pla: D- Dr. Johnson! H- hi!"

    # say L415 pla
    old "I- uh- Ugh-"
    new "B: N- não, não estou aqui com ninguém."

    # say L416 pla
    old "I'm here to deal with some things of my own!"
    new "B: pla: I- uh- Ugh-"

    # say L417 joh
    old "Why are you panting?"
    new "B:pla: Estou aqui para tratar de algumas coisas minhas!"

    # say L419 joh
    old "I see you have your business in something here."
    new "B:joh: Porque estás a ofegar?"

    # say L420 joh
    old "I- I'll let you be."
    new "B:joh: Vejo que tens os teus negócios aqui."

    # say L421 joh
    old "Have fun..."
    new "B:joh: I- I deixarei-te em paz."

    # say L435 pla
    old "B- Barbie! You have to stop!"
    new "B:joh: Diverte-te..."

    # say L436 pla
    old "Someone already saw us!"
    new "B: B- Barbie! Tu tens de parar!"

    # say L472 pla
    old "What are you talking about!"
    new "T: Do que estás a falar!"

    # say L473 pla
    old "I'm sure Dr. Johnson caught us!"
    new "T: Tenho a certeza de que a Dra. Johnson nos viu! E se ela disser algo aos administradores do edifício?!"

    # say L474 pla
    old "What if she says something to the building administrators?!"
    new "B:pla: Tenho a certeza de que a Dra. Johnson nos viu!"

    # say L594 pla
    old "Barbie I-!"
    new "B: pla: E se ela disser algo aos administradores do prédio?!"

    # say L654 pla
    old "B- Barbie - I feel like I'm cumming!"
    new "B: pla: Barbie I-!"

    # say L665 pla
    old "I- I'm glad you enjoyed it."
    new "B: B- Barbie - Sinto que estou a gozar!"

    # say L666 pla
    old "But hey, what do you say we get up and get dressed?"
    new "Mas hey, que tal irmos lá para cima e nos vestirmos?"


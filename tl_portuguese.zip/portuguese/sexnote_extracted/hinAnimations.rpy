# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/hinAnimations.rpy
translate portuguese strings:

    # say L6 joh
    old "Little by little, you start to increase the speed..."
    new "A:joh: Podes sentir o corpo dele a começar a tensar, a aquecer, isso significa que ele está perto..."

    # say L13 joh
    old "You can feel his body start to tense, warm up, that means he's close..."
    new "B:joh: Devagarinho, vais aumentando a velocidade..."

    # say L38 joh
    old "Ready for the shot?"
    new "B:joh: Podes sentir o corpo dele a ficar tenso, a aquecer, isso significa que ele está perto..."

    # say L39 hin
    old "For what?"
    new "A:joh: Uau! (Mmm)"

    # say L44 joh
    old "Wow! (Mmm)"
    new "B:hin: Para quê?"

    # say L62 pla
    old "It was great."
    new "Foi ótimo."

    # say L104 joh
    old "Wow, I wasn't expecting it... That was a lot."
    new "B:pla: Foi incrível."

    # say L110 joh
    old "A lot of cum as always, yummy"
    new "A:joh: Vai devagar, aumentando a velocidade comigo."

    # say L120 joh
    old "Go slowly increasing speed with me."
    new "B:joh: Muito leite como sempre, delicioso."

    # say L125 pla
    old "It... feels, very good..."
    new "A:joh: E se o fizermos gozar Hinn?"

    # say L129 joh
    old "How about if we make him cum Hinn?"
    new "B:pla: Sente-se... muito bem..."

    # say L130 hin
    old "(Oh My... Yes!)"
    new "B:joh: E se o fizermos gozar, Hinn?"

    # say L154 pla
    old "I- I'm going to..."
    new "B:hin: (Oh My... Yes!)"

    # say L164 joh
    old "And it's still hard... Beautiful youth, I think we can continue with the next practice, what do you say Hinn?"
    new "B:joh: Fixe!"

    # say L174 joh
    old "Well, you already saw me do it, in the last session, so it's your turn."
    new "B:joh: E ainda está duro... Bela juventude, acho que podemos continuar com a próxima prática, o que dizes, Hinn?"

    # say L176 joh
    old "Don't worry I will help you."
    new "B:joh: Bem, tu já me viste fazer isso na última sessão, então agora é a tua vez."

    # say L178 joh
    old "Remember to brush your hair very well and be careful with your teeth, ok?"
    new "B:joh: Não te preocupes, vou ajudar-te."

    # say L182 joh
    old "Very well, go ahead you can do a little more..."
    new "B:joh: Lembra-te de pentear bem o cabelo e ter cuidado com os dentes, ok?"

    # say L187 joh
    old "You feel it in your throat right? Well now take it out slowly."
    new "B:joh: Muito bem, continua, podes fazer um pouco mais..."

    # say L196 joh
    old "Great! Now keep doing it."
    new "B:joh: Sentes isso na garganta, certo? Agora tira devagar."

    # say L202 joh
    old "All right honey, you're doing great."
    new "B:joh: Ótimo! Continua assim."

    # say L204 pla
    old "Uh... It feels very... good."
    new "T(pla|tu|say): Uh... Sente-se muito... bem."

    # say L212 pla
    old "I going to..."
    new "E ainda está duro... Tu sabes o que fazer Hinn... É hora de engolir fundo!"

    # say L222 joh
    old "And it's still hard... You know what to do Hinn... It's time to deepthroat!"
    new "B:pla: Vou..."

    # say L243 joh
    old "All right, how about we do it a little faster?"
    new "B:joh: E ainda está duro... Sabes o que fazer, Hinn... É hora de engolir fundo!"

    # say L251 joh
    old "You have to learn to read your partner's expressions."
    new "B:joh: Tudo bem, vamos fazer um pouco mais rápido?"

    # say L252 joh
    old "Look how he starts to tense his legs, that means he is enjoying it, so, we have to do it a little faster."
    new "B:joh: Tens de aprender a ler as expressões do teu parceiro."

    # say L276 joh
    old "All right, are you ready for the shot? Get it in your mouth, so, you don't make a mess here."
    new "B:joh: Vê como ele começa a contrair as pernas, isso significa que ele está a gostar, então, temos de fazer um pouco mais rápido."

    # say L277 hin
    old "What?"
    new "B:joh: Tudo bem, estás pronto para a tarefa? Põe na boca, assim não fazes sujeira aqui."

    # say L282 joh
    old "Great Hinn!"
    new "B:hin: O quê?"

    # say L296 joh
    old "All right, Hinn!"
    new "B:hin: Claro."

    # say L298 pla
    old "She did it awesome!"
    new "B:joh: Tudo bem, Hinn!"

    # say L299 joh
    old "Hahaha, you are improving Hinn."
    new "B:pla: Ela fez incrível!"

    # say L308 joh
    old "Wow, it looks like someone was practicing the lessons at home."
    new "B:joh: Hahaha, estás a melhorar Hinn."

    # say L312 joh
    old "All right, let's go a little faster."
    new "B:joh: Wow, parece que alguém estava a praticar as lições em casa."

    # say L340 pla
    old "Girls, I think I'm going to..."
    new "B:joh: Tudo bem, vamos um pouco mais rápido."

    # say L358 joh
    old "Well, it's time to fuck!"
    new "B:pla: Raparigas, acho que vou..."

    # say L366 joh
    old "Let me lubricate it well before I start."
    new "B:joh: Bem, é hora de foder!"

    # say L413 joh
    old "Well I think that's enough, now you're going to penetrate Hinn..."
    new "B:joh: Deixa-me lubrificar bem antes de começar."

    # say L414 pla
    old "Wow... Ok."
    new "B:joh: Acho que já chega, agora vais penetrar a Hinn..."

    # say L415 joh
    old "Slowly and carefully..."
    new "B:pla: Wow... Ok."

    # say L421 joh
    old "Hinn you're going to enjoy the wonder of being a woman."
    new "B:joh: Devagar e com cuidado..."

    # say L425 joh
    old "Ready for that big cock Hinn?"
    new "B:joh: Vais desfrutar da maravilha de ser mulher, Hinn."

    # say L444 hin
    old "Oh... It feels.... Aghh... Aghhh..."
    new "B:joh: Como estás a sentir-te, Hinn?"

    # say L445 joh
    old "That's what I thought..."
    new "A:joh: Foda-a mais forte, faz com que ela goze contigo!"

    # say L449 joh
    old "Fuck her harder, make her cum with you!"
    new "B:joh: Foi o que pensei..."

    # say L472 joh
    old "Get it out, get it out, come in my mouth!"
    new "B:joh: Foda-a mais forte, faz com que ela goze contigo!"

    # say L478 joh
    old "Ohh yeah, yummy...."
    new "B:joh: Tira, tira, goza na minha boca!"

    # say L502 joh
    old "He is going to cum..."
    new "B:joh: Ohh sim, delicioso...."

    # say L503 hin
    old "Then, let's do it faster..."
    new "B:joh: Ele vai gozar..."

    # say L504 joh
    old "Good girl."
    new "B:hin: Então, vamos mais rápido..."

    # say L536 joh
    old "All right is time to fuck!"
    new "B:joh: Boa rapariga."

    # say L615 joh
    old "Do you like this [pla]? Do you like my tits on your face?"
    new "B:joh: Muito bem [pla], tu já sabes o que fazer..."

    # say L620 joh
    old "Yeah! yeah! Let's fuck Hinn harder!"
    new "B:pla: (Claro!)"

    # say L655 joh
    old "Delicious!"
    new "B:pla: Ohh! Foda-se sim..."

    # say L670 joh
    old "You are doing it great!"
    new "B:joh: Delicioso!"

    # say L671 joh
    old "Speed it up a little."
    new "B:joh: Estás a fazer um ótimo trabalho!"

    # say L680 hin
    old "Oh please, don't stop, do it faster! I'm going to cum!"
    new "B:joh: Estás a gozar?"

    # say L707 hin
    old "Wow... That was awesome..."
    new "B:hin: Oh, por favor, não pares, faz mais rápido! Vou gozar!"

    # say L714 joh
    old "Ohh, I think it's the perfect opportunity, for the last lesson."
    new "B:hin: Uau... Isso foi incrível..."

    # say L715 joh
    old "Get a good facial..."
    new "B:joh: Ohh, acho que é a oportunidade perfeita para a última lição."

    # say L718 joh
    old "Now let's ger a good facial Hinn."
    new "B:joh: Vai ser uma boa ejaculação facial..."

    # say L740 joh
    old "Get ready for the shot honey, he is ready."
    new "B:joh: Sentes-te bem? Queres gozar nesse rosto bonito?"

    # say L763 joh
    old "Give it to her! Cum on Hinn face!"
    new "B:joh: Prepara-te para a cena, querida, ele está pronto."

    # say L771 joh
    old "Ohh yes... Delicious..."
    new "B:joh: Dá-lhe! Ejacula na cara da Hinn!"

    # say L817 pla
    old "Wow Hinn, I'm going to..."
    new "B:joh: Ohh sim... Delicioso..."

    # say L822 pla
    old "Wow, that was awesome..."
    new "B:pla: Vou..."

    # say L823 hin
    old "I didn't say it's over. You just enjoy..."
    new "B:pla: Uau, isso foi incrível..."

    # say L826 pla
    old "... WOW!"
    new "B: Não disse que acabou. Tu só gostas..."

    # say L864 pla
    old "Hinn, again I'm going to..."
    new "B:pla:... UAU!"

    # say L865 pla
    old "Aghhh..."
    new "B:pla: Hinn, outra vez vou..."

    # say L872 hin
    old "That was fun..."
    new "B:pla: Aghhh..."

    # say L873 pla
    old "That... Was... Surprising."
    new "B:hin: Foi divertido..."

    # say L880 pla
    old "That was great."
    new "T(pla|tu|say): Foi incrível."

    # say L896 hin
    old "Slurrp, Yes, I see you like that."
    new "A:hin: Adoro o sabor do teu pénis! Adoro como ele se sente na minha boca!"

    # say L897 hin
    old "I love the taste of you dick! I love how it feels in my mouth!"
    new "B:hin: Slurrp, Sim, vejo que gostas disto."

    # say L898 hin
    old "I'll do it a little bit faster."
    new "B:hin: Adoro o sabor do teu pénis! Adoro como ele se sente na minha boca!"

    # say L903 bel
    old "(Hmm, they look like they're having fun. I better leave, I don't want them to know I saw them.)"
    new "B:hin: Vou fazer um pouco mais rápido."

    # say L905 bel
    old "For now..."
    new "T(bel|tu|say): Por agora..."

    # say L913 hin
    old "Uhhh, I can feel how your body tense up!"
    new "B:bel: Por agora..."

    # say L914 pla
    old "H- Hinn. Mmm!"
    new "B:hin: Uhhh, sinto como o teu corpo se contrai!"

    # say L915 hin
    old "Mmmm! Yes, Yes!"
    new "B:pla: H- Hinn. Mmm!"

    # say L938 pla
    old "H-Hinn, I c- can't hold back anymore."
    new "B:hin: Mmmm! Sim, sim!"

    # say L939 hin
    old "F- Finish, cum in my mouth!"
    new "B:pla: H-Hinn, já n-não aguento mais."

    # say L940 hin
    old "I want you to!"
    new "B:hin: F- Acaba, goza na minha boca!"

    # say L941 pla
    old "Ughh, Y- YES!"
    new "B:hin: Quero que tu!"

    # say L948 hin
    old "Well, I'm glad you enjoyed it."
    new "B: pla: Y- yeah, I did, thank you Hinn."

    # say L949 hin
    old "Although now I'm covered with cum."
    new "B:hin: Bem, fico contente que tenhas gostado."

    # say L950 pla
    old "Sorry about that."
    new "B:hin: Embora agora esteja coberta de sêmen."

    # say L951 hin
    old "It's ok, I wanted to do that with you. Besides, we're in the bathroom."
    new "T(hin|tu|diz): Tudo bem, eu queria fazer isso contigo. Além disso, estamos no banheiro."

    # say L952 hin
    old "Help me clean up."
    new "B:hin: Tudo bem, eu queria fazer isso contigo. Além disso, estamos no banheiro."

    # say L1070 hin
    old "Mmm! It's been a while..."
    new "B:hin: Ajuda-me a arrumar."

    # say L1071 hin
    old "Ah! Oh yes! I've missed this..."
    new "B:hin: Mmm! Já faz tempo..."

    # say L1072 pla
    old "Ohh God!"
    new "B:hin: Ah! Oh sim! Senti falta disto..."

    # say L1073 hin
    old "Ahh! It's so big! and It feels so good!"
    new "B:pla: Ohh Deus!"

    # say L1077 hin
    old "Ah! Ah! I love to feel you inside [pla]!"
    new "Ah! Ah! Adoro sentir-te dentro de [pla]!"

    # say L1080 hin
    old "I- I just love to have sex with you!"
    new "B:hin: O- o teu pénis é simplesmente o melhor!"

    # say L1084 hin
    old "AHH! AHH! YES! YES!"
    new "B:hin: Eu... eu adoro fazer sexo contigo!"

    # say L1085 hin
    old "I love the way you always make me feel!"
    new "B:hin: AHH! AHH! SIM! SIM!"

    # say L1086 hin
    old "I LOVE IT!"
    new "B:hin: Adoro a forma como tu sempre me fazes sentir!"

    # say L1087 hin
    old "I want to keep doing it with you!"
    new "B:hin: ADORO ISTO!"

    # say L1110 pla
    old "H- Hinn! I- I think I'm about to...!"
    new "B:hin: Quero continuar a fazer isto contigo!"

    # say L1111 hin
    old "Ohh, yes yes!"
    new "B:pla: H- Hinn! A- Acho que vou...!"

    # say L1112 hin
    old "I want you to cum inside me!"
    new "B:hin: Ohh, sim sim!"

    # say L1119 hin
    old "Wow... That felt great."
    new "B:hin: Quero que gozes dentro de mim!"

    # say L1120 hin
    old "Did you enjoy it too [pla]?"
    new "T(hin|tu|say): Gostaste também, [pla]?"

    # say L1121 pla
    old "O- of course, it was really good."
    new "O- obviamente, foi realmente bom."

    # say L1130 jad
    old "What the hell is this?!!!"
    new "B:pla: O- obviamente, foi realmente bom."

    # say L1142 hin
    old "It really is great. I can't get over it."
    new "B:hin: Mmm! Adoro o sabor do teu pénis."

    # say L1149 hin
    old "M- me too! I love your cock!"
    new "B:pla: Ugh! S- sim!"

    # say L1150 hin
    old "I- it's so hot!"
    new "A:jad: Honestemente, juro que não entendo o que se passa na cabeça dessa rapariga às vezes."

    # say L1158 jad
    old "Honestly, I swear I don't understand what's going on in that girl's head sometimes."
    new "T(jad|tu|say): Honestamente, juro que não entendo o que se passa na cabeça dessa rapariga às vezes."

    # say L1159 jad
    old "Where did she take off too? They're not in her room."
    new "B:jad: Honestemente, juro que não entendo o que se passa na cabeça dessa rapariga às vezes."

    # say L1160 jad
    old "And would you look at that? She left the bathroom light on!"
    new "B:jad: Onde é que ela foi parar? Não estão no quarto dela."

    # say L1161 jad
    old "I swear to God..."
    new "B:jad: E vê lá! Ela deixou a luz da casa de banho ligada!"

    # say L1167 jad
    old "(Oh my God! What are they doing?! Again?!)"
    new "B:jad: Juro por Deus..."

    # say L1168 jad
    old "(And in the bathroom of all places! These kids don't understand what shame is!)"
    new "B:jad: (Oh my Deus! O que estão a fazer?! De novo?!)"

    # say L1173 jad
    old "(I can't believe that young man is like that.... Amazing.)"
    new "A:jad: (I- Hinn está mesmo a pôr tudo aquilo na boca?)"

    # say L1174 jad
    old "(I- is Hinn really putting all that in her mouth?)"
    new "B:jad: (Não posso acreditar que aquele jovem seja assim.... Incrível.)"

    # say L1175 jad
    old "(I- I can't believe it.)"
    new "A:hin: Slrrrrp! Mmmm! Y- Yeah! I- I adoro o teu pénis!"

    # say L1182 hin
    old "Slrrrrp! Mmmm! Y- Yeah! I- I love your cock!"
    new "B:jad: (Não acredito.)"

    # say L1183 hin
    old "I- it barely fits in my mouth!"
    new "B:hin: Slrrrrp! Mmmm! Y- Yeah! I- I love your cock!"

    # say L1184 hin
    old "It's so amazing!"
    new "B:hin: N-não cabe na minha boca!"

    # say L1185 jad
    old "(S- she's actually putting all of it in her mouth!)"
    new "B:hin: É tão incrível!"

    # say L1186 jad
    old "(I can't believe what I'm seeing!)"
    new "T: (Não acredito no que estou a ver!)"

    # say L1187 jad
    old "(H- he's not going to cum in her mouth, right?)"
    new "B:jad: (Não acredito no que estou a ver!)"

    # say L1210 pla
    old "H- Hinn... I- I think I'm about to!"
    new "B:jad: (H- ele não vai gozar na boca dela, certo?)"

    # say L1211 hin
    old "YES! CUM IN MY MOUTH!"
    new "B:pla: H- Hinn... A- Acho que vou!"

    # say L1212 jad
    old "(I can't believe Hinn is saying that kind of stuff!)"
    new "B:hin: SIM! EJacula NA MINHA BOCA!"

    # say L1213 jad
    old "(I- is he going to do it?)"
    new "B:jad: (Não posso acreditar que o Hinn está a dizer esse tipo de coisas!)"

    # say L1219 jad
    old "(My God, kids these days, honestly...)"
    new "T:jad: (Meu Deus, os jovens de hoje, honestamente...)"

    # say L1220 jad
    old "(And they even say they're not a couple.)"
    new "B:jad: (Meu Deus, os jovens de hoje, honestamente...)"

    # say L1221 jad
    old "(I guess this is alright. I won't say anything for now, but Hinn really needs to learn to do it in her bedroom.)"
    new "B:jad: (E dizem que não são um casal.)"

    # say L1233 hin
    old "Hngh!! Oh yes!"
    new "B:jad: (Acho que isto está bem. Não direi nada por agora, mas a Hinn realmente precisa aprender a fazer isto no quarto dela.)"

    # say L1234 hin
    old "That's what I've been waiting for!"
    new "B:hin: Hngh!! Oh sim!"

    # say L1235 hin
    old "I just love how you fill me up!"
    new "B:hin: É isso que eu estava à espera!"

    # say L1241 pla
    old "Mmm, y- yes!"
    new "B:hin: Estás a gostar?"

    # say L1242 hin
    old "I- I'm loving it!"
    new "B:pla: Mmm, s- sim!"

    # say L1247 jad
    old "Uhh... What is that noise?"
    new "B:hin: I- Estou a adorar!"

    # say L1250 jad
    old "(I can't believe they're doing it again!)"
    new "B:jad: Uhh... Que barulho é esse?"

    # say L1252 jad
    old "(But well, at least they're doing it privately.)"
    new "B:jad: (Não posso acreditar que eles estão a fazer de novo!)"

    # say L1253 jad
    old "Oh, my God! I- I can't help myself..."
    new "B:jad: (Mas bem, pelo menos estão a fazê-lo em privado.)"

    # say L1265 hin
    old "AH! AH! AH! YES! YES!"
    new "B:jad: (Ele é tão grande! Eu... devo estar a imaginar como deve ser ser penetrada por ele...)"

    # say L1266 hin
    old "I've been missing this so much!"
    new "B:hin: AH! AH! AH! SIM! SIM!"

    # say L1267 jad
    old "(Mmmm, and she's taking all of it!)"
    new "B:hin: Tenho andado a sentir tanta falta disto!"

    # say L1268 hin
    old "I love how you fuck me!"
    new "B:jad: (Mmmm, e ela está a aceitar tudo!)"

    # say L1301 jad
    old "(H- he won't cum inside of her... Will he?)"
    new "B:hin: Adoro como tu me fodes!"

    # say L1302 hin
    old "I- I want you to cum inside!"
    new "A:hin: Deixa-me apanhar tudo!"

    # say L1303 hin
    old "Let me get it all!"
    new "B:hin: I- Quero que gozes dentro de mim!"

    # say L1304 pla
    old "Y- yes! I- I'm about to...!"
    new "A:jad: (Meu Deus! Não posso acreditar que acabei de os ver a fazer sexo!)"

    # say L1310 jad
    old "(God! I can't believe I just watched them have sex!)"
    new "B:pla: S- sim! V- vou...!"

    # say L1311 jad
    old "(But this time they did it in Hinn's bedroom, I'm the one who shouldn't be here spying on them.)"
    new "B:jad: (Meu Deus! Não posso acreditar que acabei de os ver a fazer sexo!)"

    # say L1318 pla
    old "Yeah..."
    new "B:hin: Pareceu uma eternidade desde a última vez que fizemos isso."

    # say L1319 hin
    old "By the way, it's getting kinda late, I guess my mom will be here any minute."
    new "T(hin|tu|diz): Aliás, já está a ficar um bocado tarde, acho que a minha mãe vai chegar a qualquer momento."

    # say L1320 pla
    old "You're right! I guess we better get dressed soon!"
    new "B:hin: Aliás, já está a ficar um bocado tarde, acho que a minha mãe deve chegar a qualquer momento."

    # say L1321 jad
    old "(I should leave before they find out I'm here.)"
    new "B:pla: Tens razão! Acho que melhor vestirmo-nos já!"

    # say L1326 jad
    old "Oh God, what is happening to me?"
    new "Oh Deus, o que está a acontecer comigo?"


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/miaAnimations.rpy
translate portuguese strings:

    # say L6 devMia
    old "Mmm! Oh wow."
    new "T(devMia|tu|say): Mmm! Oh wow."

    # say L7 devMia
    old "This is very different."
    new "Não pares."

    # say L8 devMia
    old "Don’t stop."
    new "B:devMia: Isto é muito diferente."

    # say L12 devMia
    old "I- I wasn’t expecting this. This sensation."
    new "B:devMia: Não pares."

    # say L14 devMia
    old "Oh, I’m more than ok."
    new "B:devMia: I- I não estava à espera disto. Esta sensação."

    # say L15 devMia
    old "Do it faster."
    new "B:devMia: Oh, estou mais do que bem."

    # say L19 devMia
    old "AH, yes, like that, keep going!"
    new "A: pla: Eu... sinto..."

    # say L20 pla
    old "I- feel..."
    new "B:devMia: AH, sim, assim, continua!"

    # say L21 devMia
    old "Don’t stop! KEEP GOING!"
    new "B:pla: Eu... sinto..."

    # say L45 pla
    old "I think I can’t hold it back anymore!"
    new "B:devMia: Não pares! CONTINUA!"

    # say L46 devMia
    old "Let it go, cum inside me!"
    new "T: Deixa ir, goza dentro de mim!"

    # say L47 devMia
    old "I want you to give that magic power!"
    new "Deixa ir, goza dentro de mim!"

    # say L48 devMia
    old "Oh yes!"
    new "B:devMia: Quero que me dês esse poder mágico!"

    # say L54 dev
    old "Oh my! That was fantastic!"
    new "Oh meu! Isso foi fantástico! Linnet tinha-me falado sobre isso, mas isto é um nível completamente diferente!"

    # say L55 dev
    old "Linnet had told me about it, but this is just another level!"
    new "B:dev: Oh meu! Isso foi fantástico!"

    # say L56 dev
    old "We have to try this again!"
    new "A:pla: Tu estás louco?"

    # say L57 pla
    old "Are you insane?"
    new "T(pla|tu|say): Tu estás louco?"

    # say L58 pla
    old "We were already at risk doing it here, in the classroom."
    new "T: Já estávamos em risco a fazer isto aqui, na sala de aula."

    # say L59 pla
    old "We need to leave before someone comes... But help me clean her first."
    new "T(tu|say): Precisamos de sair antes que alguém venha... Mas ajuda-me a limpar isto primeiro."

    # say L71 mia
    old "You say you don’t know what’s happening, yet you still have this boner."
    new "B:pla: Precisamos de sair antes que alguém venha... Mas ajuda-me a limpar isto primeiro."

    # say L72 pla
    old "W- well, t- that’s just because..."
    new "B:mia: Dizes que não sabes o que está a acontecer, mas ainda tens esta ereção."

    # say L73 mia
    old "Spare me, will you?"
    new "B: B- bem, i- isso é só porque..."

    # say L74 mia
    old "I just need you to finish, I’ll go faster."
    new "B:mia: Poupem-me, sim?"

    # say L78 mia
    old "You’re fucking disgusting for doing this, you know? To force me this way."
    new "B:mia: Só preciso que acabes, vou mais rápido."

    # say L79 pla
    old "I- I already said I don’t know what are you talking abut."
    new "B:mia: Tu és nojento por fazer isto, sabes? Forçar-me desta maneira."

    # say L80 mia
    old "Sure... I guess this boner is just because I’m pretty, right? You are sick!"
    new "B: pla: J-Já disse que não sei do que estás a falar."

    # say L81 mia
    old "Will you just finish already?"
    new "B:mia: Claro... Acho que esta excitação é só porque sou bonita, certo? Tu és doente!"

    # say L85 mia
    old "I just can’t believe you’d stood up this low."
    new "B:mia: Vais acabar já?"

    # say L86 mia
    old "I will never forgive this, and I’ll make sure you pay for this."
    new "B:mia: Não consigo acreditar que tenhas feito isto."

    # say L87 mia
    old "Don’t you think for a single second that you’ll pull this shit again."
    new "B:mia: Nunca te perdoarei por isto, e vou garantir que pagas por isso."

    # say L110 pla
    old "M-Miss Mia, if you keep going, I-I’ll...!"
    new "M-miúda Mia, se continuares assim, eu...!"

    # say L111 mia
    old "Fucking finally!"
    new "B:pla: M-Miss Mia, se continuares, eu...!"

    # say L112 mia
    old "Finish quickly will you? I don’t want to keep touching your dick."
    new "B:mia: Finalmente!"

    # say L117 mia
    old "Ughhh... This is so gross..."
    new "B:mia: Acaba depressa, ok? Não quero continuar a tocar na tua pila."

    # say L118 mia
    old "Anyway, let's finish this shit."
    new "B:mia: Ughhh... Isto é tão nojento..."

    # say L119 pla
    old "W- What? Now what?"
    new "B:mia: Então, vamos acabar com isso."

    # say L124 pla
    old "What the hell was that?"
    new "O que raio foi isso?"

    # say L125 pla
    old "Why did you suddenly do that?"
    new "B:pla: Que raio foi isso?"

    # say L126 mia
    old "I see you’re planning on keeping this up, huh?"
    new "T(mia|formal|say): Vejo que pretendes continuar com isto, hã?"

    # say L140 den
    old "Yeah that’s right, get his dick in your mouth."
    new "B:mia: Mas nunca pensei que fosses o tipo de barata nojenta capaz de fazer uma coisa destas."

    # say L141 den
    old "Like the whore you are."
    new "B:den: Sim, é isso aí, mete o pau dele na tua boca."

    # say L142 mia
    old "S- shut up!"
    new "B:den: Como a puta que és."

    # say L146 den
    old "You must be enjoying this, aren’t you?"
    new "B:mia: C- cala-te!"

    # say L147 mia
    old "Pfff..."
    new "B:den: Deves estar a adorar isto, não estás?"

    # say L148 den
    old "You little whore, look at how you do that."
    new "B:mia: Pfff..."

    # say L149 den
    old "It must be your experience from all the cocks you’ve sucked."
    new "B:den: Tu pequena puta, olha como faz isso."

    # say L153 den
    old "Tell me Mia, how much are you enjoying this?"
    new "B:den: Deve ser a tua experiência com todos os pénis que já chupaste."

    # say L154 mia
    old "Glurpp... F- fuck you!"
    new "B:den: Diz-me, Mia, quanto estás a gostar disto?"

    # say L155 den
    old "Ha, you’re gagging on cock and you’re telling me to shut up?"
    new "B:mia: Glurpp... F- foda-se!"

    # say L180 den
    old "Don't worry, she'll swallow it all, that's what she used to do."
    new "B:den: Porque não vais em frente e gozas na boca dela?"

    # say L181 den
    old "You better drink every drop Mia, that’s an order."
    new "B:den: Não te preocupes, ela vai engolir tudo, é o que costumava fazer."

    # say L187 pla
    old "Are you ok Miss Mia?"
    new "B:den: Tu melhor beberes cada gota, Mia, é uma ordem."

    # say L189 mia
    old "Ohh, yes, I’m fine, just let me gather my bearings for a second."
    new "B:pla: Estás bem, Miss Mia?"

    # say L190 pla
    old "I’m sorry, for finishing in your mout-... I mean for everything."
    new "B:mia: Ohh, sim, estou bem, só me dá um segundo para me recompor."

    # say L193 mia
    old "That asshole is the one who made us do this."
    new "B:pla: Desculpa, por acabar na tua boca... Quero dizer, por tudo."

    # say L211 mia
    old "Oh! Nghn!"
    new "B:mia: Esse idiota é quem nos fez fazer isso."

    # say L212 den
    old "Ha, what’s the matter Ms? Is it too big for you?"
    new "B:mia: Oh! Nghn!"

    # say L213 den
    old "But you’re so experienced! Come on! I know you can take it all!"
    new "B:den: Ha, qual é o problema, tu? É muito grande para ti?"

    # say L219 den
    old "I know you wanted to do this bro! She’s been messing with you after all."
    new "B:den: Aposto que deve ser muito bom, hã?"

    # say L220 den
    old "That’s it, fuck her like the whore she is!"
    new "A:den: Como te sentes, Sr.ª Mia?"

    # say L224 den
    old "How do you feel Ms. Mia?"
    new "B:den: É isso, fode-a como a puta que ela é!"

    # say L225 den
    old "I bet you like having his big cock inside!"
    new "B:den: Como te sentes, Sr.ª Mia?"

    # say L226 den
    old "Just like the old days, huh?"
    new "B:den: Aposto que gostas de ter o seu pau grande dentro!"

    # say L227 mia
    old "S- Mmm! Shut up!"
    new "B:den: Como nos velhos tempos, hã?"

    # say L250 pla
    old "M-Miss Mia, I think - I think I’m..."
    new "B:mia: S- Mmm! Cala-te!"

    # say L252 den
    old "Fill that pussy up with cum!"
    new "A:pla: A-estás bem, Miss Mia?"

    # say L257 pla
    old "A-are you ok Miss Mia?"
    new "B:den: Enche essa buceta de esperma!"

    # say L258 pla
    old "I’m sorry."
    new "B:pla: A-estás bem, Mia?"

    # say L260 mia
    old "It’s ok, you shouldn’t have to apologize."
    new "B:pla: Desculpa."

    # say L261 mia
    old "You’re also a victim here."
    new "B:mia: Tudo bem, não precisas de pedir desculpa."

    # say L262 mia
    old "You’re actually a big help."
    new "B:mia: Tu também és uma vítima aqui."

    # say L282 den
    old "Yeah, you probably missed that dick, didn’t you Mia?"
    new "B:mia: Tu és realmente uma grande ajuda."

    # say L284 den
    old "Answer me Mia!"
    new "B:den: Claro que sentiste a falta dessa pila, não foi, Mia?"

    # say L285 mia
    old "Y- Nghn! Mmm! Y-Yeah I do!"
    new "B:den: Responde-me, Mia!"

    # say L289 den
    old "I bet you like fucking in the bathroom!"
    new "B:mia: Y- Nghn! Mmm! Y-Sim, eu gosto!"

    # say L290 den
    old "You like that you almost got caught, don’t you Mia?"
    new "B:den: Aposto que gostas de transar na casa de banho!"

    # say L291 den
    old "Is exciting isn’t it?"
    new "T(den|tu|say): É excitante, não é?"

    # say L292 den
    old "I can’t hear you!"
    new "B:den: É empolgante, não é?"

    # say L293 mia
    old "Y-yes! Ah! Is... Ah! Very exciting!"
    new "B:den: Não te consigo ouvir!"

    # say L317 den
    old "It’s ok dude, let it out!"
    new "A:den: Quero que tu a encontres completamente!"

    # say L318 den
    old "I want you to fill her pussy up!"
    new "B:den: Tudo bem, deixa sair!"

    # say L319 pla
    old "M-Miss Mia, I- I’m about to...!"
    new "B:den: Quero que a enchas!"

    # say L320 mia
    old "J-just do it!"
    new "B:pla: M-Miss Mia, eu...!"

    # say L325 den
    old "Well guys, I would say that was perfect! Don’t you agree?"
    new "B:mia: J-já o fiz!"

    # say L326 den
    old "Hahahaha, you can really tell Mia has some experience in front of the camera."
    new "B:den: Bem, pessoal, diria que foi perfeito! Não concordam?"

    # say L329 den
    old "But remember, all of this has been recorded, I don’t have to remind you what that means... Anyway, bye."
    new "B:den: Bem, acho que devo deixar vocês, dois pombinhos, para se consolarem."

    # say L345 dir
    old "Oh yeah! That’s it!"
    new "B:den: Mas lembra-te, tudo isto foi gravado, não preciso de te lembrar do que isso significa... Enfim, adeus."

    # say L346 dir
    old "Yes! Yes! It’s so good!"
    new "A:dir: É ainda melhor do que um pau de verdade!"

    # say L347 dir
    old "It’s even better than a real dick!"
    new "B:dir: Sim! Sim! É tão bom!"

    # say L352 dir
    old "Ah! Ah! Yeah!"
    new "B:dir: É ainda melhor que um pau de verdade!"

    # say L353 dir
    old "That’s just what I wanted!"
    new "Ah! Ah! Sim! Isso mesmo! Sim!"

    # say L354 dir
    old "YES!"
    new "Mmm, é tão difícil."

    # say L387 mia
    old "Mmm, it’s so hard"
    new "B:dir: SIM!"

    # say L388 mia
    old "Oh! Mmm!"
    new "B:mia: Mmm, está tão difícil"

    # say L389 pla
    old "M-Mia, lower your voice."
    new "B:mia: Oh! Mmm!"

    # say L393 dir
    old "Oh, oh fuck yeah!"
    new "B: M-Mia, baixa a voz."

    # say L394 dir
    old "AH! AH! AH!"
    new "B:dir: Oh, oh merda sim!"

    # say L395 dir
    old "MMMM! FUCK YEAH!"
    new "B:dir: AH! AH! AH!"

    # say L399 dir
    old "Well, that just cheered me up!"
    new "B:dir: MMMM! ÓTIMO!"

    # say L400 dir
    old "What a great way to start the day!"
    new "Ah, merda, Ah!"

    # say L412 miavid
    old "Oh fuck, Ah!"
    new "B:dir: Que ótima maneira de começar o dia!"

    # say L413 black1
    old "Yes, oh you look so fucking good."
    new "B:miavid: Ah, merda!"

    # say L414 miavid
    old "Mmmm! Ahhh! It's so big..."
    new "B:black1: Sim, oh tu pareces tão bem."

    # say L415 black1
    old "That’s what I wanna hear."
    new "B:miavid: Mmmm! Ahhh! É tão grande..."

    # say L416 black2
    old "Keep sucking bitch."
    new "B:black1: É isso que eu quero ouvir."

    # say L418 pla
    old "You had to memorize these dialogues or..."
    new "B:black2: Continua a chupar, puta."

    # say L419 mia
    old "Uhh... Something like that... That’s how it usually is in that industry."
    new "B:pla: Tiveste de memorizar estes diálogos ou..."

    # say L420 mia
    old "Also my moans and everything, you have to pretend it all."
    new "B:mia: Uhh... Algo assim... É assim que costuma ser nessa indústria."

    # say L424 miavid
    old "Mmm! Slurp! Slurp!"
    new "B:mia: E também os meus gemidos e tudo, tens de fingir tudo."

    # say L425 black1
    old "Mmm yeah babe, it feels really nice..."
    new "B:miavid: Mmm! Chup-chup!"

    # say L426 miavid
    old "Oh, yeah!"
    new "B:black1: Hmm, sim querida, está a sentir-se mesmo bem..."

    # say L428 pla
    old "Did you guys ever improvised the lines or anything?"
    new "B:miavid: Oh, yeah!"

    # say L429 mia
    old "Yeah, the only script we had was for the set ups, but most of the time we were improvising."
    new "B:pla: Vocês alguma vez improvisaram as falas ou algo assim?"

    # say L430 pla
    old "Yeah, I could kinda tell."
    new "T(pla|tu|say): Sim, eu já tinha reparado."

    # say L434 black2
    old "Oh my gosh, I can feel it reaching your throat."
    new "B:pla: Sim, eu já tinha reparado."

    # say L435 miavid
    old "Mmmm... Yeah baby..."
    new "B:black2: Oh meu Deus, posso sentir isso chegando à tua garganta."

    # say L436 black1
    old "That’s what you wanted bitch!"
    new "B:miavid: Mmmm... Sim, bebé..."

    # say L437 miavid
    old "Yeah! Yeah!"
    new "B:black1: É isso que tu querias, putinha!"

    # say L438 miavid
    old "I love your big black cocks!"
    new "Sabes... Tu foste muito bom nisto."

    # say L440 pla
    old "You know... You were very good at this."
    new "T: Sabes... Tu foste muito bom nisto."

    # say L443 pla
    old "Sorry, sorry, you’re right, that was out of line, I was just saying."
    new "B:mia: É isso que tens a dizer sobre isso?"

    # say L444 mia
    old "Yeah, yeah, I know what you mean..."
    new "B:pla: Desculpa, desculpa, tens razão, fui longe demais, estava só a dizer."

    # menu L465 
    old "Skip"
    new "Saltar"

    # say L466 mia
    old "Ok, that’s enough, there aren’t any more videos or anything else in the folder."
    new "T(mia|formal|say): Ok, chega, não há mais vídeos nem nada mais na pasta."

    # say L467 mia
    old "So we don’t need to keep checking this out."
    new "B:mia: Ok, chega, não há mais vídeos nem nada mais na pasta."

    # say L468 pla
    old "Yeah, you’re right."
    new "T(pla|tu|say): Sim, tens razão."

    # say L478 miavid
    old "I-It’s so fucking big!"
    new "T(tu): É... é tão grande!"

    # say L479 miavid
    old "I can’t handle it! AH!"
    new "B:miavid: I-It’s tão grande!"

    # say L480 black1
    old "That’s right baby, take that big black cock!"
    new "B:miavid: Não aguento! AH!"

    # say L481 miavid
    old "AH! AH! AAAAH!"
    new "B:black1: Tens razão, bebé, toma esse grande pénis negro!"

    # say L483 pla
    old "Well, they are very big."
    new "B:miavid: AH! AH! AAAAH!"

    # say L484 mia
    old "Mmm, not the biggest ever."
    new "B:pla: Bem, eles são muito grandes."

    # say L503 mia
    old "Just don’t take too much time."
    new "B:mia: Mmm, não é o maior de todos."

    # say L504 mia
    old "We’re supposed to already be going to the principal's office."
    new "B:mia: Não demores muito."

    # say L505 pla
    old "O-ok!"
    new "O-ok! Vou já!"

    # say L508 mia
    old "Hurry up!"
    new "B:pla: O-ok!"

    # say L509 pla
    old "I-I’m trying, but I can’t do it if you keep rushing me!"
    new "B:mia: Anda depressa!"

    # say L510 mia
    old "Just let go and enjoy it."
    new "B:pla: Estou a tentar, mas não consigo se tu continuares a apressar-me!"

    # say L511 mia
    old "That way you’ll cum quickly."
    new "B:mia: Deixa-te ir e aproveita."

    # say L512 mia
    old "I’ll go faster!"
    new "B:mia: Assim vais gozar depressa."

    # say L517 mia
    old "That’s it, I can feel you getting harder."
    new "B:mia: Vou mais rápido!"

    # say L518 mia
    old "There you go, just enjoy my mouth!"
    new "B:mia: É isso, sinto-te a ficar mais duro."

    # say L519 pla
    old "I-I think it’s working."
    new "B:mia: Aí está, só aproveita a minha boca!"

    # say L520 pla
    old "J-just don’t stop."
    new "B:pla: A-Acho que está a funcionar."

    # say L543 pla
    old "M-Mia I think I’m cuming!"
    new "B: pla: J-já não pares."

    # say L544 mia
    old "Do it, quickly!"
    new "B:pla: M-Mia, acho que vou gozar!"

    # say L545 mia
    old "Finish!"
    new "B:mia: Faz isso, depressa!"

    # say L551 mia
    old "I mean, did you have to finish all over me?"
    new "B:mia: Acabaste!"

    # say L552 mia
    old "You covered me in cum!"
    new "B:mia: Quero dizer, tiveste de acabar todo em cima de mim?"

    # say L553 pla
    old "S-sorry, I couldn’t really control it."
    new "B:mia: Cobriste-me de sêmen!"

    # say L554 mia
    old "Whatever, listen, I’ll get clean quickly and we’ll go to the principal’s office."
    new "B:pla: Desculpa, não consegui mesmo controlar."


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Lydia.rpy
translate portuguese strings:

    # say L60 lyd
    old "No Anna, you can't live your life like this."
    new "T(lyd|tu|diz): Não, Anna, não podes viver a tua vida assim."

    # say L62 ann
    old "I'm already big enough to decide what I do with my life."
    new "B:lyd: Não, Ana, tu não podes viver a tua vida assim."

    # say L64 lyd
    old "Yes, but in recent weeks you have been drinking excessively and even using drugs!"
    new "B:ann: Já sou o suficiente crescida para decidir o que faço com a minha vida."

    # say L66 lyd
    old "I'm very worried about you, about your health, I know your father's loss was not easy, it hurts me a lot too-"
    new "B:lyd: Sim, mas nas últimas semanas tu tens bebido em excesso e até usado drogas!"

    # say L68 ann
    old "it has nothing to do with it... I just want to enjoy my life, I don't want to live locked up and self-conscious like... You."
    new "B:lyd: Estou muito preocupado contigo, com a tua saúde, sei que a perda do teu pai não foi fácil, também me dói muito..."

    # say L76 ann
    old "Anyway... Don't wait for me tonight..."
    new "B:ann: não tem nada a ver com isso... Eu só quero aproveitar a minha vida, não quero viver trancada e insegura como... Tu."

    # say L80 lyd
    old "I'm sorry you heard that... Things have not been very easy for either of us."
    new "B:ann: De qualquer forma... Não me esperes esta noite..."

    # say L82 pla
    old "I'm very sorry, I just came to accompany you a little..."
    new "B:lyd: Sinto muito que tenhas ouvido isso... As coisas não têm sido fáceis para nenhum de nós."

    # say L85 lyd
    old "Aww thank you very much pumpkin."
    new "B:pla: Sinto muito, vim apenas para te acompanhar um pouco..."

    # say L87 lyd
    old "But you don't have to worry, I know you have your things to do, and at the moment I don't feel very well."
    new "B:lyd: Aww, muito obrigado meu querido."

    # say L89 pla
    old "Hmm, is it because of the discussion with Anna?"
    new "B:lyd: Mas não tens de te preocupar, sei que tens as tuas coisas para fazer, e neste momento não me sinto muito bem."

    # say L91 lyd
    old "Yes honey, she was greatly affected by her father's death and has been... Quite bad lately."
    new "B:pla: Hmm, é por causa da discussão com a Anna?"

    # say L93 pla
    old "I understand, I can come another day if you want."
    new "B:lyd: Sim querida, ela foi muito afetada pela morte do pai e tem estado... Bastante mal."

    # say L95 lyd
    old "You know what? Yes, come over the weekend and come with me to church, are you okay with that?"
    new "T: Sabes o que? Sim, vem no fim de semana e vai comigo à igreja, estás bem com isso?"

    # say L97 pla
    old "Perfect! I will come in the weekend."
    new "B:lyd: Sabes o quê? Sim, vem passar o fim de semana comigo e vamos à igreja, estás bem com isso?"

    # say L99 lyd
    old "Great, thank you for your visit and support honey, I really appreciate it."
    new "T(lyd|tu|say): Ótimo, obrigada pela tua visita e apoio, meu amor, eu realmente aprecio."

    # say L101 pla
    old "Don't worry, I'm glad for helping you..."
    new "Não te preocupes, fico contente por te ajudar..."

    # say L120 lyd
    old "Oh hi pumpkin, did you come to help me with the dating app?"
    new "B:pla: Não te preocupes, fico contente por te ajudar..."

    # say L121 pla
    old "Uhh yeah, how's it going?"
    new "B:lyd: Oh olá querida, vieste ajudar-me com a app de encontros?"

    # say L122 lyd
    old "Well, remember we have to do it in the afternoons, because Anna is here in the mornings..."
    new "B:pla: Uhh yeah, como é que estás?"

    # say L123 pla
    old "Ohh, you're right! I'm sorry, I totally forgot."
    new "B:lyd: Bem, lembra-te que temos de o fazer à tarde, porque a Anna está aqui de manhã..."

    # say L124 lyd
    old "Don't worry pumpkin, just come back in a few hours."
    new "B:pla: Ohh, tens razão! Desculpa, esqueci-me completamente."

    # say L125 pla
    old "Alright, see you later then."
    new "B:lyd: Não te preocupes, meu amor, volta daqui a algumas horas."

    # say L126 lyd
    old "See you later."
    new "B:pla: Tchau, então."

    # say L135 lyd
    old "Hey pumpkin, did you come to accompany me to church?"
    new "B:lyd: Até mais tarde."

    # say L137 pla
    old "Of course, are you ready?"
    new "B:lyd: Olá querida, vieste para me acompanhar à igreja?"

    # say L139 lyd
    old "Sure, let's go!"
    new "A:lyd: Muito obrigada por me acompanhares a esta missa em memória do meu marido."

    # say L146 lyd
    old "Thank you so much for joining me to this mass in commemoration of my husband."
    new "B:lyd: Claro, vamos lá!"

    # say L148 pla
    old "Don't worry, it's a pleasure to share with you."
    new "B:lyd: Muito obrigada por me acompanhares nesta missa em memória do meu marido."

    # say L150 lyd
    old "Oh honey, you don't know how important is the support like yours right now."
    new "B:pla: Não te preocupes, é um prazer partilhar contigo."

    # say L153 jon
    old "Hi Lydia, I'm so sorry for your husband, how have you been these past few week?"
    new "B:lyd: Oh querida, tu não sabes o quanto é importante o apoio como o teu neste momento."

    # say L155 lyd
    old "Coping with patience, Mrs. Jones."
    new "B:jon: Olá Lydia, sinto muito pelo teu marido, como tens estado nas últimas semanas?"

    # say L157 jon
    old "Yes, I understand you perfectly, I also lost my husband 5 years ago."
    new "B:lyd: Lidar com paciência, Sra. Jones."

    # say L159 jon
    old "Do you know what helped me? Praying and approach to God."
    new "B:jon: Sim, compreendo-te perfeitamente, também perdi o meu marido há 5 anos."

    # say L161 lyd
    old "Yes Mrs. Jones, that's the best."
    new "B:jon: Sabes o que me ajudou? Oração e aproximação a Deus."

    # say L164 jon
    old "I will continue coming to church everyday, giving my life to the lord."
    new "B:lyd: Sim, Sra. Jones, é o melhor."

    # say L166 lyd
    old "Yes... He comforts us..."
    new "B:jon: Vou continuar a ir à igreja todos os dias, entregando a minha vida ao Senhor."

    # say L168 jon
    old "There's nothing like being faithful to the Lord all your life, right Lydia?"
    new "B:lyd: Sim... Ele conforta-nos..."

    # say L170 lyd
    old "Sure... Excuse me Mrs. Jones, I have to go, I hope to see you soon."
    new "B:jon: Não há nada como ser fiel ao Senhor durante toda a vida, certo Lydia?"

    # say L172 jon
    old "Okay Lydia, remember that this is the house of God and here you will always be welcome."
    new "B:lyd:Certo... Desculpe, Sra. Jones, tenho que ir, espero vê-la em breve."

    # say L182 pla
    old "Are you feeling alright? You seem a little disturbed."
    new "A:lyd: Ouviu o que a Sra. Jones disse?"

    # say L184 lyd
    old "Did you hear what Mrs. Jones said?"
    new "B:pla: Estás bem? Pareces um pouco perturbado."

    # say L186 pla
    old "Yes, she is a very religious woman, will you accompany her to church?."
    new "B:lyd: Ouviste o que a Sra. Jones disse?"

    # say L188 lyd
    old "No, no, you don't understand..."
    new "B:pla: Sim, ela é uma mulher muito religiosa, vais acompanhá-la à igreja?"

    # say L190 lyd
    old "I've been thinking... After so many years, I have never lived my life..."
    new "B:lyd: Não, não, tu não entendes..."

    # say L198 lyd
    old "And after so many years I had conformed to what it should be like."
    new "B:lyd: Sabes, quando atinges uma certa idade, começas a olhar para trás e a ver o que viveste..."

    # say L200 lyd
    old "But after listening to Mrs. Jones... That's not what I want for my life."
    new "B:lyd: E depois de tantos anos, eu já me conformara com o que deveria ser."

    # say L204 lyd
    old "I already gave my whole life to a man, now he isn't here anymore, I don't want to stay locked up in a church now either."
    new "B:lyd: Mas depois de ouvir a Sra. Jones... Isso não é o que eu quero para a minha vida."

    # say L208 lyd
    old "I don't want to be like Mrs Jones in 5 years, it's not what I want for my life..."
    new "B:lyd: Já dei a minha vida toda a um homem, agora que ele já não está aqui, não quero ficar presa numa igreja."

    # say L210 pla
    old "Then, what will you do?"
    new "B:lyd: Não quero ser como a Sra. Jones daqui a 5 anos, não é o que quero para a minha vida..."

    # say L212 lyd
    old "I think Anna is right... I have to start living my life, live new experiences."
    new "B:pla: Então, o que vais fazer?"

    # say L214 lyd
    old "You know? I never had sex with any other man... I really don't know if I enjoyed sex at least!"
    new "T(lyd|tu|say): Sabes? Nunca tive sexo com nenhum outro homem... Não tenho a certeza se alguma vez gostei de sexo!"

    # say L218 lyd
    old "Today was a revelation for me... and I don't want to bother you anymore."
    new "B:lyd: Sabes? Nunca tive sexo com nenhum outro homem... Realmente não sei se alguma vez gostei de sexo!"

    # say L220 lyd
    old "Thank you very much for your company, these days I will be thinking about what I should do with my life."
    new "B:lyd: Hoje foi uma revelação para mim... e não quero incomodar-te mais."

    # say L222 pla
    old "I understand, if you need anything just let me know..."
    new "B:lyd: Muito obrigado pela tua companhia, nos próximos dias vou pensar no que devo fazer com a minha vida."

    # say L224 lyd
    old "In fact I think if I'm going to need several things from you..."
    new "B:pla: Entendo, se precisares de algo, basta dizer..."

    # say L228 lyd
    old "Never mind, see you later pumpkin."
    new "B:lyd: Na verdade, acho que vou precisar de várias coisas tuas..."

    # say L243 lyd
    old "Hi Honey, remember that I need you to accompany me to the church the weekend."
    new "B:lyd: Não importa, vejo-te mais tarde, querida."

    # say L245 pla
    old "Ohhh, of course, no problem, I'll be here on the weekend."
    new "B:lyd: Olá querida, lembra-te que preciso que me acompanhes à igreja no fim de semana."

    # say L247 lyd
    old "Thank you very much pumpkin!"
    new "Obrigada, meu bem! Olá querido, precisas de mim?"

    # say L254 lyd
    old "Hi Honey, do you need me?"
    new "B:lyd: Muito obrigado, querida!"

    # say L256 pla
    old "Oh no, sorry, I was just walking around."
    new "B:lyd: Olá querida, precisas de mim?"

    # say L258 lyd
    old "Ok, pumpkin"
    new "A:pla: Desculpa, estava só a passear."

    # say L286 pla
    old "Sorry, I was just walking around."
    new "Desculpa, estava só a passear."


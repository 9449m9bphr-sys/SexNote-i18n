# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/linAnimations.rpy
translate portuguese strings:

    # say L6 lin
    old "You're definitely very good at this, I can start to feel much more energy inside of me..."
    new "Tu és definitivamente muito bom nisto, já começo a sentir muito mais energia dentro de mim..."

    # say L7 pla
    old "Hmm... T- Thanks."
    new "A:lin: Sentes-te bem, hã?"

    # say L11 lin
    old "Does it feels good, Huhh?"
    new "T(lin|tu|say): Sentes-te bem, hã?"

    # say L12 pla
    old "Y- yes... It feels great..."
    new "B:lin: Sentes-te bem, hã?"

    # say L16 lin
    old "Come one, I want to suck every drop that comes out of you."
    new "B:pla: S-sim... É incrível..."

    # say L17 pla
    old "Oh God..."
    new "B:lin: Vem, quero sugar cada gota que sai de ti."

    # say L41 lin
    old "Yes, yes! Give it to me!"
    new "B: Oh Deus..."

    # say L50 lin
    old "Alright, it's my time to ride you..."
    new "B:lin: Sim, sim! Dá-me isso!"

    # say L51 lin
    old "I want you to drill me, like you did with that girl."
    new "B:lin: Está na hora de eu te montar..."

    # say L67 lin
    old "Wow... You're so good at this."
    new "B:lin: Quero que me fodes, como fizeste com aquela rapariga."

    # say L69 lin
    old "I love it! Don't stop... Don't Stop..."
    new "B:lin: Wow... Tu és tão boa nisto."

    # say L73 lin
    old "Ahhh.... Ahhh...."
    new "B:lin: Adoro isto! Não pares... Não pares..."

    # say L74 lin
    old "I can feel all your energy entering my body..."
    new "B:lin: Ahhh.... Ahhh...."

    # say L79 lin
    old "Ahhhhh... I want more."
    new "B:lin: Posso sentir toda a tua energia a entrar no meu corpo..."

    # say L80 lin
    old "More give me more! Harder! HARDER!"
    new "B:lin: Ahhhhh... Quero mais."

    # say L104 lin
    old "Oh yeahh cum inside me! Give me all your load!"
    new "B:lin: Mais, dá-me mais! Mais forte! MAIS FORTE!"

    # say L122 pla
    old "Wow... What are you doing? Why are you tying me up?"
    new "B:lin: Oh simmm, goza dentro de mim! Dá-me toda a tua carga!"

    # say L123 lin
    old "I like to play a little while I share my energy with you."
    new "B:pla: Wow... O que estás a fazer? Porque é que me estás a amarrar?"

    # say L128 lin
    old "Ohhh, It's great to feel so much energy when I'm with you."
    new "B:lin: Gosto de brincar um pouco enquanto partilho a minha energia contigo."

    # say L133 lin
    old "Yes! Yes! I can feel all your energy inside me!"
    new "B:lin: Ohhh, é ótimo sentir tanta energia quando estou contigo."

    # say L134 lin
    old "Don't stop, don't stop!"
    new "B:lin: Sim! Sim! Posso sentir toda a tua energia dentro de mim!"

    # say L162 lin
    old "Oh, that was fun, isn't?"
    new "Oh, isso foi divertido, não é?"


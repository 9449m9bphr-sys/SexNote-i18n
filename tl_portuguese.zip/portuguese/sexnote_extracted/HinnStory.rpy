# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/HinnStory.rpy
translate portuguese strings:

    # say L17 pla
    old "Are we a couple?"
    new "S... SOMOS... SOMOS UM CASAL?"

    # say L19 hin
    old "W... WHAT?... WE... WHAT?"
    new "B:pla: Somos um casal?"

    # say L21 pla
    old "Well, we are partners for the class project, right?"
    new "B:hin: W... WHAT?... WE... WHAT?"

    # say L23 hin
    old "Ohh... Riiight. Haha. The class project. Yeah, we are. Sorry, I just forgot..."
    new "B:pla: Bem, somos parceiros para o projeto da aula, certo?"

    # say L25 pla
    old "Don't worry. We can meet to work on it. If you prefer, I could go to your house."
    new "Não te preocupes. Podemos encontrar-nos para trabalhar nisso. Se preferires, posso ir à tua casa."

    # say L27 hin
    old "W...What? My house? Why? Haha. I mean, why not your place?"
    new "B:pla: Não te preocupes. Podemos encontrar-nos para trabalhar nisso. Se preferires, posso ir à tua casa."

    # say L29 pla
    old "Well, I just thought it would be more comfortable for you. But if you don't wanna-"
    new "B:hin: O...O quê? A minha casa? Porquê? Haha. Quero dizer, por que não na tua?"

    # say L31 hin
    old "No! I don't have a problem with that. Hehe. We can meet at my house then. I will wait for you tomorrow after class so we can meet up, ok?"
    new "B:pla: Bem, pensei que seria mais confortável para ti. Mas se tu não quiseres..."

    # say L35 hin
    old "Ok then... I... I have to go, see you tomorrow, [pla]."
    new "T(hin|tu|diz): Ok então... Eu... Eu tenho que ir, até amanhã, [pla]."

    # say L52 pla
    old "Hey Hinn, how are you?"
    new "B:pla: Até amanhã, Hinn!"

    # say L56 pla
    old "I'm good too. So, are you ready to start?"
    new "Bem, sim! A- Acho que sim..."

    # say L58 hin
    old "Well yes! I- I think so..."
    new "B:pla: Estou bem também. Então, estás pronta para começar?"

    # say L60 pla
    old "Ok, then, let's do it!"
    new "B:hin: Bem sim! A- Acho que sim..."

    # say L69 rub
    old "Woah! Look who we have here, it's the girl who dresses as a man."
    new "B:pla: Ok, então, vamos lá!"

    # say L71 oli
    old "Yes! Perhaps you have nothing but that horrible gigantic sweatshirt."
    new "B:rub: Uau! Olha quem está aqui, é a rapariga que se veste como um homem."

    # say L76 rub
    old "You know what the problem is? the problem is that she is kind of fat and that's why she wears those sweatshirts hahaha."
    new "B:oli: Sim! Talvez não tenhas nada além dessa horrível sweatshirt gigante."

    # say L78 hin
    old "No, I'm not-"
    new "B:rub: Sabes qual é o problema? O problema é que ela é um pouco gorda e por isso é que usa essas sweatshirts hahaha."

    # say L80 oli
    old "Hahaha you're a fat woman. Don't you have any sense of style?"
    new "B:hin: Não, eu não-"

    # say L82 rub
    old "Style? Hahaha look at her such horrible clothes obviously she doesn't know what that is."
    new "B:oli: Hahaha, tu és uma mulher gorda. Não tens qualquer noção de estilo?"

    # say L86 pla
    old "Hey, you shouldn't be so bitchy to Hinn..."
    new "B:rub: Estilo? Hahaha olha para ela com aquelas roupas horríveis, obviamente não sabe do que se trata."

    # say L88 rub
    old "Hahaha check it out Olivia, the loser defends the fatty woman."
    new "B:pla: Ei, não deves ser tão malvada com a Hinn..."

    # say L90 oli
    old "Why don't you go away with your fat girlfriend, loser?"
    new "B:rub: Hahaha olha só, Olivia, o perdedor defende a gorda."

    # say L92 pla
    old "... Assholes."
    new "B:oli: Por que não vais embora com a tua namorada gorda, perdedor?"

    # say L94 rub
    old "Bye Loser!"
    new "B:pla:... Merdas."

    # say L113 pla
    old "Wait Hinn..."
    new "B:rub: Adeus perdedor!"

    # say L120 pla
    old "Hmm... some stupid girls were bothering Hinn."
    new "B:pla: Espera, Hinn..."

    # say L124 pla
    old "Has this happened before?"
    new "B:pla: Hmm... algumas raparigas estúpidas estavam a incomodar a Hinn."

    # say L126 jad
    old "Yes, but she won't let me go talk to the principal, she says that I would only embarrass her even more..."
    new "T(jad|tu|say): Sim, mas ela não me deixa ir falar com o diretor, diz que eu só iria embaraçá-la ainda mais..."

    # say L130 jad
    old "By the way, I'm Jade Hinn's mom, are you her friend?"
    new "B:jad: Sim, mas ela não me deixa ir falar com o diretor, diz que eu só iria embaraçá-la ainda mais..."

    # say L134 jad
    old "Hahaha, Nice to meet you. [pla] please excuse me for a moment. I'm going to talk to Hinn."
    new "B:pla: Sim, é um prazer conhecer-te, o meu nome é [pla]."

    # say L138 jad
    old "Oh no, don't go wait for me here, get comfortable and I'll be back in a minute."
    new "T(jad|tu|say): Oh não, não vais embora, espera-me aqui, arranja-te à vontade e eu volto num instante."

    # say L153 jad
    old "All right, I talked to her, everything is fine, she's just a little embarrassed."
    new "B:jad: Oh não, não vais embora, espera-me aqui, arranja-te à vontade e eu volto num instante."

    # say L155 jad
    old "I can tell she really appreciates you that's why I want to take the opportunity to ask you a favor."
    new "T(jad|tu|diz): Posso ver que ela realmente te valoriza, por isso quero aproveitar para te pedir um favor."

    # say L159 jad
    old "I have encouraged her to seek therapy many times as she has had problems at times."
    new "T(jad|tu|dizer): Já a incentivei várias vezes a procurar terapia, pois ela já teve problemas algumas vezes."

    # say L161 pla
    old "To the psychologist?"
    new "T(pla|tu|dizer): À psicóloga?"

    # say L163 jad
    old "Yes, That would be the best option for her to improve her self-esteem, I know it could help her a lot, but she won't listen to me."
    new "B:pla: À psicóloga?"

    # say L165 pla
    old "Hmm, I understand."
    new "A:jad: Então, pensei que tu podes ajudar-me a convencê-la."

    # say L167 jad
    old "So, I thought you could help me convince her."
    new "B:pla: Hmm, percebo."

    # say L171 jad
    old "Yes, I'm sure with your help we can convince her that that's the right thing to do."
    new "B:jad: Então, pensei que tu podes ajudar-me a convencê-la."

    # say L173 pla
    old "Alright. But what should I do?"
    new "T(pla|tu|say): Tudo bem. Mas o que devo fazer?"

    # say L175 jad
    old "First of all, help me find a psychologist, the truth is that I have been looking for one, but I haven't been able to find anyone."
    new "B:pla: Tudo bem. Mas o que devo fazer?"

    # say L177 pla
    old "Hmm, ok, I can handle it."
    new "T: Hmm, ok, eu trato disso."

    # say L179 jad
    old "All right, as soon as you find a therapist let me know. You can meet me here in the morning."
    new "B:pla: Hmm, ok, eu consigo lidar com isso."

    # say L196 pla
    old "Don't worry Hinn, do you feel better?"
    new "B:jad: Bem, vou deixar-vos, assim podem continuar com o vosso trabalho."

    # say L198 hin
    old "Yes a little, I'm very sorry that-"
    new "B:pla: Não te preocupes Hinn, estás a sentir-te melhor?"

    # say L200 pla
    old "No, you don't have to apologize for anything, they're just bitches."
    new "B:hin: Sim, um pouco, sinto muito que-"

    # say L202 hin
    old "Hehehe, if you say so."
    new "B:pla: Não, não tens de pedir desculpa por nada, são só putos."

    # say L204 pla
    old "Do you want to work today? We could do it tomorrow if you think thats better."
    new "B:hin: Hehehe, se tu dizes."

    # say L206 hin
    old "No, no, I'm fine, we can start today."
    new "B:pla: Queres trabalhar hoje? Podemos fazer amanhã se achas que é melhor."

    # say L208 pla
    old "Ok, let's do it."
    new "A:pla: Uau, Hinn! Não sabia que fosses tão bom nisto!"

    # say L222 pla
    old "Wow, Hinn! I didn't know you were so good at this!"
    new "B:pla: Ok, vamos fazer isto."

    # say L224 hin
    old "Well... It's not as difficult as it seems. Hehe. I just study a little here and there."
    new "B:pla: Wow, Hinn! Não sabia que fosses tão bom nisto!"

    # say L226 pla
    old "Well, thanks to you, we made a lot of progress. I think we can stop for now."
    new "B:hin: Bem... Não é tão difícil como parece. Hehe. Eu só estudo um pouco aqui e ali."

    # say L228 hin
    old "Yes, it's getting late. We can continue tomorrow!"
    new "B:pla: Bem, graças a ti, fizemos muito progresso. Acho que podemos parar por agora."

    # say L230 pla
    old "Ok. I really enjoyed working with you. I think we make a very good team."
    new "Sim... Tu achas mesmo isso?"

    # say L232 hin
    old "Do... D- do you think that?"
    new "B:pla: Ok. Aproveitei muito trabalhar contigo. Acho que formamos uma equipa muito boa."

    # say L234 pla
    old "Of course! I think we are going to kick some ass together."
    new "B:hin: Tu... T- tu achas isso?"

    # say L238 pla
    old "Well, see you tomorrow, Hinn. Have a good night."
    new "B:pla: Claro! Acho que vamos dar uma boa lição juntos."

    # say L240 hin
    old "You too. By the way, remember to show Mrs. Mia our progress, let her know how far we've come. See you tomorrow."
    new "B:pla: Então, até amanhã, Hinn. Boa noite."

    # say L242 pla
    old "Ok... See you."
    new "Tu vieste! Não sabia se realmente virias..."

    # say L262 jad
    old "You came! I didn't know if you would actually come..."
    new "B:pla: Ok... Até logo."

    # say L264 pla
    old "Well, I like Hinn and I want to help her anyway I can, I finally found a therapist."
    new "B:jad: Tu vieste! Não sabia se realmente virias..."

    # say L266 jad
    old "That's excellent! What's their name?"
    new "B:pla: Bem, gosto da Hinn e quero ajudá-la no que for preciso, finalmente encontrei uma terapeuta."

    # say L268 pla
    old "She is Dr. Johnson, she has her office in the town Business Building."
    new "B:jad: Isso é excelente! Qual é o nome dela?"

    # say L270 jad
    old "Great, it's not far from here."
    new "B:pla: Ela é a Dra. Johnson, tem o consultório no Edifício Empresarial da cidade."

    # say L272 pla
    old "No is not, if you want I can make an appointment to see her."
    new "B:jad: Ótimo, não está longe daqui."

    # say L274 jad
    old "Oh, don't worry I'll take care of it."
    new "B:pla: Não é, se quiser posso marcar uma consulta para a ver."

    # say L278 jad
    old "However, now comes the toughest part, convincing Hinn to go to therapy."
    new "B:jad: Oh, não te preocupes, eu trato disso."

    # say L280 jad
    old "So, I'll talk to her today but you should convince her to agree to do it."
    new "B:jad: No entanto, agora vem a parte mais difícil, convencer a Hinn a ir à terapia."

    # say L282 pla
    old "Understood!"
    new "T(pla|tu|say): Entendido! Vou a correr para a escola. Não quero chegar atrasado por tua causa."

    # say L284 jad
    old "Perfect! Now hurry too school. I don't want you to be late because of me."
    new "T(jad|tu|say): Perfeito! Agora vai depressa para a escola. Não quero que fiques atrasado por minha causa."

    # say L286 pla
    old "Alright! Bye."
    new "B:jad: Perfeito! Agora vai para a escola depressa. Não quero que fiques atrasado por minha causa."

    # say L302 jad
    old "I only care about you and your well-being, sweetheart..."
    new "T(jad|tu|say): Só me importo contigo e com o teu bem-estar, querida..."

    # say L313 pla
    old "Good morning Mr. Jade... Hello there, Hinn."
    new "B:hin: (Oh não...)"

    # say L318 jad
    old "I don't think you're crazy honey, I just want you to go to therapy to strengthen your self-esteem."
    new "T(jad|tu|say): Não acho que tu sejas louca, querida, só quero que tu vais à terapia para fortalecer a tua autoestima."

    # say L320 hin
    old "I have nothing that I need to be strengthened!"
    new "B:jad: Não acho que tu estás louca, meu amor, só quero que tu vais à terapia para fortalecer a tua autoestima."

    # say L322 jad
    old "Honey, I know the reason why you don't want to go, it is because you think they are going to make fun of you even more at school."
    new "B:hin: Não tenho nada que precise ser fortalecido!"

    # say L324 jad
    old "But I promise it won't happen, we can do everything without anyone knowing."
    new "B:jad: Meu amor, eu sei o motivo pelo qual tu não queres ir, é porque pensas que vão zombar de ti ainda mais na escola."

    # say L346 jad
    old "See honey, don't worry any more, go to a single session and then decide whether to continue or not."
    new "B:pla: Claro, adorava."

    # say L348 hin
    old "Would you really be willing to go with me?"
    new "B:jad: Vê querida, não te preocupes mais, vai a uma única sessão e depois decide se queres continuar ou não."

    # say L350 pla
    old "Of course, it should be fun."
    new "T(pla|tu|say): Claro, deve ser divertido."

    # say L352 hin
    old "Okay, but don't think I don't realize how you are manipulating me."
    new "B:pla: Claro, deve ser divertido."

    # say L354 jad
    old "Excellent honey, I'm going to make the appointment. So, you can start studying now."
    new "Ótimo, meu amor, vou marcar a consulta. Então, tu podes começar a estudar agora."

    # say L361 hin
    old "She's unbelievable..."
    new "B:jad: Ótimo, querida, vou marcar a consulta. Então, podes começar a estudar agora."

    # say L364 pla
    old "Well, the truth is, I think she's doing the best she can to help you."
    new "B:hin: Ela é incrível..."

    # say L366 hin
    old "If you say so... Anyway, let's start to work."
    new "B:pla: Bem, a verdade é que acho que ela está a fazer o melhor que pode para te ajudar."

    # say L392 pla
    old "Ok, see you tomorrow, Hinn."
    new "B:pla: Não é nada..."

    # say L396 pla
    old "Ok. Have a good night."
    new "B:pla: Ok, até amanhã, Hinn."

    # say L420 hin
    old "Fine, thanks for asking. Today is the so-called “therapy session”, are you coming?"
    new "É hoje?"

    # say L422 pla
    old "Is it today?"
    new "B:hin: Tudo bem, obrigado por perguntar. Hoje é a tal sessão de terapia, vais vir?"

    # say L424 hin
    old "Yes... My mother finally managed to schedule an appointment as we agreed."
    new "B:pla: É hoje?"

    # say L426 pla
    old "Sure, I promised that I'll join you."
    new "Ótimo, estás pronto?"

    # say L428 hin
    old "Awesome, are you ready?"
    new "B:pla: Claro, prometi que iria contigo."

    # say L430 pla
    old "Yes, let's get going."
    new "B:hin: Ótimo, estás pronta?"

    # say L432 hin
    old "Very well."
    new "B:pla: Sim, vamos lá."

    # say L440 joh
    old "Good afternoon, nice to meet you, you must be Hinn, right?"
    new "B:hin: Muito bem."

    # say L442 hin
    old "Yes, Dr. Johnson, nice to meet you too."
    new "B:joh: Boa tarde, prazer em conhecê-lo, deve ser o Hinn, certo?"

    # say L444 joh
    old "Your mother has already told me a little about you and you are..."
    new "B:hin: Sim, Dr. Johnson, também é um prazer conhecer-te."

    # say L446 pla
    old "My name is [pla], nice to meet you."
    new "T(pla|tu|diz): Chamo-me [pla], prazer em conhecer-te."

    # say L453 hin
    old "He's a friend..."
    new "A:joh: Oh ok, percebo, um amigo..."

    # say L455 joh
    old "Oh ok, I understand a friend..."
    new "B:hin: É um amigo..."

    # say L478 joh
    old "And we have reached to the conclusion that it is best for her to try on other outfits so that she feels more comfortable with her body."
    new "B:joh: Muito bem, deixa-me explicar. Com Hinn discutimos o problema de bullying na escola."

    # say L480 pla
    old "I understand, I think it's a good idea."
    new "T(pla|tu|say): Entendo, acho que é uma boa ideia."

    # say L482 joh
    old "Yes, but to help her to have a better progress with the therapy, we require your help."
    new "B:pla: Entendo, acho que é uma boa ideia."

    # say L484 pla
    old "My help? How so?"
    new "T(pla|tu|say): A minha ajuda? Como assim?"

    # say L486 joh
    old "We need a male friend opinion for each outfit so Hinn can feel that someone cares for her."
    new "B:pla: A minha ajuda? Como assim?"

    # say L488 pla
    old "Oh, I understand, no problem."
    new "B:joh: Precisamos da opinião de um amigo homem para cada outfit para que a Hinn se sinta valorizada."

    # say L492 pla
    old "Yes, it will be fun."
    new "B:pla: Oh, percebo, sem problemas."

    # say L494 joh
    old "All right, in that case sit on the couch while Hinn takes off that sweatshirt."
    new "B:pla: Sim, vai ser divertido."

    # say L509 joh
    old "Are you ready Hinn?"
    new "B:joh: Tudo bem, nesse caso senta no sofá enquanto a Hinn tira esse casaco."

    # say L511 hin
    old "Hmm, I think so."
    new "B:joh: Estás pronta, Hinn?"

    # say L513 joh
    old "Very well take off that sweatshirt and let us see your body better."
    new "B:hin: Hmm, acho que sim."

    # say L517 joh
    old "Don't worry, you're in a safe place, nobody's going to judge you here."
    new "B:joh: Muito bem, tira esse casaco e deixa-nos ver melhor o teu corpo."

    # say L519 hin
    old "Hmm alright."
    new "A:joh: Mas rapariga, tu tens um corpo incrível!"

    # say L523 joh
    old "But girl you have a great body!"
    new "B:hin: Hmm, está bem."

    # say L528 pla
    old "Yes, she certainly looks better."
    new "T(pla|tu|say): Sim, ela certamente parece melhor."

    # say L532 joh
    old "Do you think you could survive without your Sweatshirt?"
    new "B:pla: Sim, ela certamente está melhor."

    # say L534 hin
    old "They are going to criticize me at school, because of my... b- breasts."
    new "B:joh: Tu achas que consegues sobreviver sem a tua sweatshirt?"

    # say L536 joh
    old "Hahaha, but how are you going to be embarrassed by those beautiful breasts?"
    new "B:hin: Vão criticar-me na escola por causa das minhas... b- mamas."

    # say L542 joh
    old "You have a blessing, you have a slim waist and a couple of really nice boobs, with those you might make all the boys crazy over you. "
    new "B:pla:... Hmm não, realmente os teus seios parecem ótimos."

    # say L546 joh
    old "All right, all right, no problem, I think that's it for today."
    new "B:joh: Tu tens uma bênção, tens uma cintura fina e um par de peitos realmente bonitos, com isso podes deixar todos os rapazes loucos por ti."

    # say L554 joh
    old "However, we will have to get some more outfits to continue with your treatment."
    new "B:joh: Tudo bem, tudo bem, sem problemas, acho que é isso por hoje."

    # say L556 joh
    old "Hmm, I'd rather it wasn't your own clothes, since from what I've see your clothes cover a lot."
    new "B:joh: No entanto, teremos de arranjar mais roupa para continuar o teu tratamento."

    # say L558 pla
    old "I think I could help, I could get some clothes for Hinn."
    new "B:joh: Hmm, preferia que não fossem as tuas próprias roupas, pois, pelo que vejo, as tuas roupas cobrem bastante."

    # say L560 joh
    old "Fantastic! Make sure it's a bit of a daring and revealing outfit."
    new "B:pla: Acho que posso ajudar, posso arranjar algumas roupas para a Hinn."

    # say L562 joh
    old "We need to gradually make Hinn feel more secure in her body."
    new "B:joh: Fantástico! Certifica-te de que é um outfit ousado e revelador."

    # say L566 joh
    old "Ok, see you in the next session guys!"
    new "B:joh: Precisamos fazer Hinn sentir-se gradualmente mais segura no seu corpo."

    # say L568 hin
    old "Thanks Dr. Johnson, goodbye."
    new "B:joh: Ok, vejo-vos na próxima sessão!"

    # say L570 pla
    old "Goodbye."
    new "A:pla: Como te sentiste, Hinn?"

    # say L577 pla
    old "How did you feel Hinn?"
    new "B:pla: Adeus."

    # say L579 hin
    old "Actually, it was quite interesting, I felt comfortable in therapy, confronting it a little I think it can help."
    new "B:pla: Como te sentiste, Hinn?"

    # say L581 pla
    old "Excellent, I think it's great that you feel that way."
    new "B:hin: Na verdade, foi bastante interessante, senti-me confortável na terapia, acho que confrontar um pouco pode ajudar."

    # say L583 pla
    old "So, will you continue attending therapy?"
    new "B:pla: Excelente, acho ótimo que te sintas assim."

    # say L585 hin
    old "Hmm... Would you still accompany me?"
    new "B:pla: Então, vais continuar a frequentar a terapia?"

    # say L587 pla
    old "Of course I will."
    new "T(pla|tu|say): Claro que sim."

    # say L590 hin
    old "Okay, let's just don't make a fuss in front of my mother, I don't want her to think she was right."
    new "B:pla: Claro que sim."

    # say L592 pla
    old "Hahaha, alright."
    new "T(pla|tu|say): Hahaha, tudo bem."

    # say L594 hin
    old "Thanks again for your support."
    new "B:pla: Hahaha, tudo bem."

    # say L596 pla
    old "It's a pleasure, Hinn."
    new "T: É um prazer, Hinn. Claro que posso ir contigo à tua casa hoje. Não quero que a tua mãe me faça muitas perguntas."

    # say L598 hin
    old "Could you come with me to my house today? I don't want my mother to ask me many questions."
    new "B:pla: É um prazer, Hinn."

    # say L610 jad
    old "How did it go guys?"
    new "B:hin: Podes vir comigo para minha casa hoje? Não quero que a minha mãe me faça muitas perguntas. T(jad|tu|say): Como correu, pessoal? A:hin: Hmm... afinal não foi má ideia..."

    # say L612 hin
    old "Hmm... it wasn't a bad idea after all..."
    new "B:jad: Como correu, pessoal?"

    # say L614 jad
    old "You should tell by now that therapy is a very positive thing to do."
    new "B:hin: Hmm... afinal não foi má ideia..."

    # say L616 jad
    old "Then I will immediately schedule the next appointment!"
    new "B:jad: Deves perceber por agora que a terapia é uma coisa muito positiva."

    # say L618 hin
    old "No, I'm not going to go to therapy every day mom..."
    new "A:jad: Mas... Eu pensei que tu gostasses."

    # say L620 jad
    old "But... I thought you liked it."
    new "B:hin: Não, não vou a terapia todos os dias, mãe..."

    # say L626 hin
    old "No, I will make the appointments myself when I think it is appropriate."
    new "B:jad: Hmm, percebo, então quando devo marcar a próxima consulta?"

    # say L632 jad
    old "I'll leave you alone, so, you can say goodbye to each other, heh."
    new "B:jad: Tudo bem, tens razão, deixo isso contigo, se precisares de algo não hesites em pedir."

    # say L647 pla
    old "I'm glad that everything went well with therapy."
    new "B:jad: Vou deixar-vos a sós, então, podem dizer adeus um ao outro, hehe."

    # say L649 hin
    old "Yes, me too, at least my mom will stop bothering me every day, or I hope so."
    new "B:pla: Fico contente que tudo tenha corrido bem com a terapia."

    # say L651 pla
    old "Hahaha I don't think that's going to happen."
    new "B:hin: Sim, eu também, pelo menos a minha mãe vai parar de me chatear todos os dias, ou espero que sim."

    # say L653 hin
    old "Hehehe neither do I."
    new "B:pla: Hahaha acho que isso não vai acontecer."

    # say L659 pla
    old "Well, well, it's getting late, so I'm going home, see you tomorrow."
    new "B:hin: Hehehe, eu também não."

    # say L661 hin
    old "Yes, thank you so much for what you are doing."
    new "B:pla: Bem, bem, já está tarde, vou para casa, até amanhã."

    # say L663 pla
    old "You are welcome, I enjoyed it as much as you did and I love spending time with you."
    new "B:hin: Sim, muito obrigado pelo que estás a fazer."

    # say L667 pla
    old "Well... see you tomorrow."
    new "B:pla: De nada, eu também gostei muito e adoro passar tempo contigo."

    # say L687 pla
    old "Hey Hinn! How are you today?"
    new "B:pla: Well... see you tomorrow."

    # say L693 hin
    old "Ok, ok."
    new "A:joh: Olá, como estão?"

    # say L701 joh
    old "Hi guys, how are you?"
    new "Olá a todos, como estão? Tudo bem, obrigado."

    # say L703 pla
    old "Fine, thanks."
    new "Prontos para continuar com o tratamento?"

    # say L705 joh
    old "Ready to go on with the treatment?"
    new "B:pla: Bem, obrigado."

    # say L713 joh
    old "Hmm, we'll see let's go Hinn, to the changing room."
    new "B:pla: Bem, sim, embora não tenha a certeza se isto vai funcionar, as roupas são... um pouco mais reveladoras do que o necessário."

    # say L715 hin
    old "Hmm... ok."
    new "A:joh: Bem, demorou um pouco a convencê-la, mas finalmente consegui que ela experimentasse este fato..."

    # say L728 joh
    old "Well, it took me a while to convince her, but finally got her to try on this outfit..."
    new "B:hum: Hmm... ok."

    # say L742 hin
    old "Do you really think so?"
    new "B:pla: (Oh my God!) Bem, acho que tu estás mesmo bem, Hinn..."

    # say L743 pla
    old "Yes, you look great."
    new "B:hin: Tu realmente pensas isso?"

    # say L745 joh
    old "What did I tell you? You should wear these kinds of clothes every day."
    new "B:pla: Sim, tu estás ótima."

    # say L747 hin
    old "No way. I'm not going to wear this in public..."
    new "B:joh: O que te disse? Deves usar este tipo de roupa todos os dias."

    # say L754 joh
    old "Yeah, honey remember we are going to do it privately and in a safe place, so we can improve."
    new "B:hin: Mais revelador?!"

    # say L764 joh
    old "Well, that's it. See you in the next session."
    new "B:joh: Sim, querida, lembra-te que vamos fazer isto em privado e num local seguro, para podermos melhorar."

    # say L766 hin
    old "Thanks Dr. Johnson."
    new "B:joh: Bem, é isso. Até à próxima sessão."

    # say L775 hin
    old "Thank you so much for joining me again... I really appreciate it."
    new "B:hin: Obrigado, Dr. Johnson."

    # say L777 pla
    old "Oh, don't worry, I think it's fun."
    new "B:hin: Muito obrigado por te juntares a mim de novo... Aprecio muito."

    # say L779 hin
    old "You're right, it's a bit fun..."
    new "A:pla: Queres que te acompanhe a casa?"

    # say L781 pla
    old "Would you like me to walk you home?"
    new "B:hin: Tens razão, é um bocado divertido..."

    # say L783 hin
    old "Oh no, don't worry my mom will come to pick me up."
    new "B:pla: Queres que te acompanhe a casa?"

    # say L785 pla
    old "Alright, then see you tomorrow?"
    new "Tudo bem, então até amanhã?"

    # say L787 hin
    old "Yes!... I mean, sure."
    new "B:pla: Então, até amanhã?"

    # say L789 pla
    old "Great, see you tomorrow Hinn."
    new "B:hin: Sim!... Quero dizer, claro."

    # say L791 hin
    old "See you tomorrow [pla]."
    new "T(hin|tu|diz): Até amanhã [pla]."

    # say L830 joh
    old "Excellent, let's go Hinn."
    new "B:joh: Pronto para começar o tratamento?"

    # say L844 joh
    old "I love this outfit, I find it fancy and it looks great on you Hinn..."
    new "B:joh: Ótimo, vamos Hinn."

    # say L856 joh
    old "Look at you, wow, you look fantastic."
    new "B:joh: Adoro este outfit, acho-o elegante e fica-te muito bem, Hinn..."

    # say L858 hin
    old "I think this skirt is too short..."
    new "B:joh: Olha para ti, uau, estás fantástica."

    # say L865 joh
    old "Sure, you are... Do you think Hinn has pretty legs?"
    new "B:pla: Mmm Sim... Quero dizer, não... Estou só a ver. Nada mais."

    # say L866 pla
    old "Uhhh... Well, actually yes, I do..."
    new "B:joh: Claro, tu és... Achas que as pernas da Hinn são bonitas?"

    # say L869 pla
    old "Yes, you really look nice."
    new "B:pla: Uhhh... Bem, na verdade sim, eu..."

    # say L871 joh
    old "And how about that cleavage, aye?"
    new "B:pla: Sim, tu realmente ficas bem."

    # say L875 pla
    old "Uhh... It looks great, too. Hinn has a really good... Body."
    new "B:joh: E quanto àquele decote, hã?"

    # say L877 joh
    old "She has great boobs, too, doesn't she?"
    new "B:pla: Uhh... Parece ótimo, também. A Hinn tem um corpo realmente bom."

    # say L881 hin
    old "I'm going to change my clothes..."
    new "A:joh: Hehe. Estava só a brincar..."

    # say L883 joh
    old "Hehe. I was just kidding..."
    new "B:hin: Vou trocar de roupa..."

    # say L895 joh
    old "Great! All right guys, see you in the next session."
    new "B:pla: Vou tentar."

    # say L897 hin
    old "Thank you Dr. Johnson."
    new "B:joh: Ótimo! Até à próxima sessão, pessoal."

    # say L910 hin
    old "You are right, it's a bit fun..."
    new "A:pla: Queres que te acompanhe a casa?"

    # say L912 pla
    old "Do you want me to walk you home?"
    new "T(pla|tu|say): Queres que te acompanhe a casa?"

    # say L939 pla
    old "I talked to Mrs. Mia... Ugh, I think she hates me or something."
    new "T(pla|tu|say): Falei com a Sra. Mia... Ah, acho que ela me odeia ou algo assim."

    # say L941 hin
    old "Why do you say that?"
    new "B:pla: Falei com a Sra. Mia... Ugh, acho que ela me odeia ou algo assim."

    # say L943 pla
    old "She doesn't think I did anything on our project... And she wants you to talk to her alone."
    new "B:hin: Porque dizes isso?"

    # say L965 hin
    old "Everything is fine. I explained everything to her."
    new "T(tu|dizer): Tudo bem. Expliquei tudo a ela."

    # say L967 pla
    old "Really? Just like that, huh?"
    new "B:hin: Tudo está bem. Expliquei tudo a ela."

    # say L969 hin
    old "Well, I can be very persuasive if I set my mind to it."
    new "B:pla: Sério? Assim, sem mais nem menos?"

    # say L971 pla
    old "Wow, Hinn! You sure have changed. You're way more open and secure..."
    new "B:hin: Bem, posso ser muito persuasiva se me proponho a isso."

    # say L975 pla
    old "Yes, I really do."
    new "B:pla: Wow, Hinn! Tu mudaste mesmo. Estás muito mais aberta e segura..."

    # say L981 hin
    old "Well, speaking of that, today is the new therapy session."
    new "B:pla: Sim. Definitivamente acho que sim..."

    # say L1011 joh
    old "Great, let's go Hinn."
    new "B:hin: Bem, a propósito, hoje é a nova sessão de terapia."

    # say L1034 joh
    old "I honestly didn't think that Hinn was going to wear this... But we really are coming a long way..."
    new "B:joh: Ótimo, vamos lá, Hinn."

    # say L1037 hin
    old "I don't really feel comfortable..."
    new "B:joh: Honestamente, não pensei que a Hinn fosse usar isto... Mas estamos mesmo a avançar muito..."

    # say L1039 joh
    old "You look fantastic, girl! With this outfit, you will drive them all crazy!"
    new "B:hin: Não me sinto muito confortável..."

    # say L1041 hin
    old "What! Who's supposed to wear this in public?"
    new "B:joh: Tu estás fantástica, rapariga! Com este outfit, vais enlouquecer todos!"

    # say L1053 joh
    old "Haha! Well, you've already made him get horny."
    new "B:pla:...(Oh shit! Estou a ficar excitado.)"

    # say L1057 joh
    old "Can't you see his pants?"
    new "B:joh: Haha! Bem, tu já o deixaste excitado."

    # say L1061 joh
    old "That right there, Hinn, is the most honest show of appreciation you can receive from a man..."
    new "B:joh: Não vês as calças dele?"

    # say L1064 hin
    old "Oh my..."
    new "B:joh: Aquilo mesmo, Hinn, é a forma mais sincera de apreciação que podes receber de um homem..."

    # say L1065 pla
    old "Sorry... It wasn't... My intention..."
    new "B:hin: Oh my..."

    # say L1067 joh
    old "Oh, no. Don't worry, honey. In fact, Hinn, you should feel flattered."
    new "B:pla: Desculpa... Não foi... Minha intenção..."

    # say L1073 joh
    old "Well, since you are both quite young, I think I could take this chance to give you a little sex education lesson..."
    new "B:pla: (Oh shit!)"

    # say L1083 joh
    old "I have to admit, [pla], I didn't imagine it would be this big... His size is pretty impressive, huh, Hinn?"
    new "B:joh: Hahaha, [pla], deixaste a Hinn sem palavras... Vem cá, não sejas tímido..."

    # say L1085 joh
    old "Haha. This surely is the first time she's seen a real one and seeing one of this size even surprises me."
    new "B:hin: (É tão grande.)"

    # say L1088 joh
    old "Let me get all this out of here..."
    new "Haha. Isto com certeza é a primeira vez que ela vê um de verdade e ver um deste tamanho até me surpreende."

    # say L1093 joh
    old "Certainly... This is awesome, kid... What a big cock you have down here!"
    new "B:joh: Deixa-me tirar tudo daqui..."

    # say L1100 joh
    old "Well, Hinn, pay close attention... I'm going to teach you how to please a man with your hands, this will be very useful knowledge..."
    new "B:joh: Claro... Isto é incrível, miúdo... Que pénis grande tens aqui!"

    # say L1102 joh
    old "You have to take it in your hands and start to massage, from top to bottom very carefully..."
    new "B:joh: Bem, Hinn, presta muita atenção... Vou ensinar-te como agradar a um homem com as tuas mãos, este será um conhecimento muito útil..."

    # say L1115 joh
    old "Well... I hope you learned a little more about your sexuality, kids... If you want me to give you another small lesson, just let me know."
    new "B:joh: Tens de o pegar nas mãos e começar a massagear, do topo até à base, com muito cuidado..."

    # say L1117 joh
    old "See you in the next session."
    new "B:joh: Bem... Espero que tenham aprendido um pouco mais sobre a vossa sexualidade, miúdos... Se quiserem que vos dê outra pequena lição, basta dizer."

    # say L1132 hin
    old "Well..."
    new "B:joh: Até à próxima sessão."

    # say L1134 pla
    old "Your mom is coming to pick you up?"
    new "B:hin: Bem..."

    # say L1136 hin
    old "Yes, yes, she is coming to get me."
    new "B:pla: A tua mãe vai buscar-te?"

    # say L1138 pla
    old "Oh, ok, then see you tomorrow?"
    new "B:hin: Sim, sim, ela está a vir buscar-me."

    # say L1174 pla
    old "Yes, I love to help. Also, I think your mom did everything to help you."
    new "B:pla: Oh, ok, então até amanhã?"

    # say L1178 pla
    old "I really think you look good with any clothes you decide to wear, the most important thing is how you feel about yourself."
    new "B:pla: Sim, adoro ajudar. Além disso, acho que a tua mãe fez tudo para te ajudar."

    # say L1184 hin
    old "For sure, see you in the afternoon."
    new "B:pla: Com prazer... Então, nos vemos esta tarde?"

    # say L1186 pla
    old "Great. Bye."
    new "A:joh: Olá pessoal! Prontos para a última sessão?"

    # say L1217 joh
    old "Hi guys! Ready for the last session?"
    new "É esta a última sessão?"

    # say L1219 hin
    old "Is this the last session?"
    new "A:joh: Sim, tu tens avançado muito bem com a terapia."

    # say L1221 joh
    old "Yes, you have advanced very well with the therapy."
    new "B:hin: É esta a última sessão?"

    # say L1222 joh
    old "And have managed to gain more security in yourself and in your body and that was the objective."
    new "B:joh: Sim, tu tens avançado muito bem com a terapia."

    # say L1224 hin
    old "But... I- I don't feel... Ready."
    new "B:joh: E conseguiste ganhar mais confiança em ti e no teu corpo, e esse era o objetivo."

    # say L1226 joh
    old "Well... We still have this session, right?"
    new "B:hin: Mas... Eu não me sinto... Pronta."

    # say L1228 hin
    old "Hmm... ok..."
    new "B:joh: Bem... Ainda temos esta sessão, certo?"

    # say L1235 joh
    old "Right, little by little you started to wear clothes that exposed more of your body, this time there will be nothing covering your body..."
    new "B:joh: E isso porque na última sessão vamos fazer um exercício de aceitação do teu próprio corpo."

    # say L1237 hin
    old "So?"
    new "A:joh: Certo, desta vez vais estar nua."

    # say L1239 joh
    old "Right, this time you'll be naked."
    new "A:joh: Vamos, menina, isso não é muito diferente do que tu já fizeste antes."

    # say L1245 joh
    old "Come on girl, that's not much different from what you've already done before."
    new "B:joh: Vamos, desta vez vais estar nua."

    # say L1250 joh
    old "Just let's go girl, Your body is natural, your body is perfect."
    new "B:joh: Vamos, menina, isso não é muito diferente do que já fizeste antes."

    # say L1265 joh
    old "Well, I think we're ready!"
    new "B:joh: Vamos, minha querida, o teu corpo é natural, o teu corpo é perfeito."

    # say L1268 joh
    old "How are you feeling my dear?"
    new "B:joh: Bem, acho que estamos prontos!"

    # say L1270 hin
    old "I don't feel very good..."
    new "B:joh: Como estás a sentir-te, minha querida?"

    # say L1277 joh
    old "I guess you guys will have played around a bit since the last lesson I gave you, right?"
    new "B:joh: Hahaha outra vez em silêncio?"

    # say L1279 hin
    old "... No, we haven't..."
    new "A:joh: Oh realmente? Que pena."

    # say L1281 joh
    old "Oh really? That's a shame."
    new "A:joh: Sabes o que vou fazer? Vou dar-te outra aula de borla, gostavas?"

    # say L1283 joh
    old "You know what I'll give you another free lesson, would you like to?"
    new "B:joh: Oh realmente? Que pena."

    # say L1292 joh
    old "Come here Hinn, I'll teach you how to take the next step in male pleasure."
    new "B:joh: Tudo bem, mas só porque é a nossa última sessão juntos."

    # say L1301 joh
    old "Very well, you take it in your hand and this time you use your mouth."
    new "B:joh: Vem cá, Hinn, vou ensinar-te a dar o próximo passo no prazer masculino."

    # say L1302 joh
    old "You must pay close attention to the head, it is the most pleasant area"
    new "B:joh: Muito bem, tu pegas na mão e desta vez usas a boca."

    # say L1303 joh
    old "So, you should use your tongue and lips to stimulate that whole area."
    new "B:joh: Tens de prestar muita atenção à cabeça, é a zona mais agradável."

    # say L1315 joh
    old "Well, you've been naked for over 10 min, in front of us and you look pretty comfortable with that."
    new "B:joh: Então, deves usar a língua e os lábios para estimular toda essa área."

    # say L1317 joh
    old "That is proof that my work is already done."
    new "B:joh: Bem, tu estás nu há mais de 10 minutos, na nossa frente e pareces bastante à vontade com isso."

    # say L1319 hin
    old "Thank you very much Dr. Johnson."
    new "B:joh: Isso é prova de que o meu trabalho já está feito."

    # say L1321 joh
    old "But girl you can get dressed now, you don't have to be naked all the time..."
    new "B:hin: Muito obrigado, Dr. Johnson."

    # say L1323 hin
    old "... Sorry."
    new "B:joh: Mas tu podes vestir-te agora, não precisas de estar sempre nua..."

    # say L1325 joh
    old "Hahaha."
    new "A:joh: Bem, é isto, espero que as sessões e as pequenas lições tenham ajudado, aproveitem a vossa sexualidade e a vossa juventude!"

    # say L1332 joh
    old "Well this is it, I hope the sessions and the little lessons have helped you, enjoy your sexuality and your youth guys!"
    new "B:joh: Hahaha."

    # say L1336 joh
    old "I hope you do very well."
    new "B:joh: Bem, é isto, espero que as sessões e as pequenas lições tenham ajudado, desfrutem da vossa sexualidade e juventude!"

    # say L1345 pla
    old "How did you feel in today's session?"
    new "B:joh: Espero que tenhas feito muito bem."

    # say L1347 hin
    old "I think it was exciting..."
    new "B:pla: Como te sentiste na sessão de hoje?"

    # say L1349 pla
    old "Ehmm, yes, it was exciting, right?"
    new "A:hin: Gostaste?"

    # say L1351 hin
    old "Did you like it?"
    new "B:pla: Hmm, sim, foi empolgante, certo?"

    # say L1353 pla
    old "Well... Yes."
    new "B:hin: Gostaste?"

    # say L1355 hin
    old "I liked too."
    new "B:pla: Bem... Sim."

    # say L1359 pla
    old "Ok, then see you tomorrow?"
    new "B:hin: Também gostei."

    # say L1398 pla
    old "See you, Hinn."
    new "B:pla: Ok, então até amanhã?"

    # say L1412 pla
    old "Yes! We finally did it! We finished the project, even Mrs. Mia was happy with it!"
    new "B:pla: Até logo, Hinn."

    # say L1414 hin
    old "Great, now that we're done, I want to ask you if... Will you continue to accompany me to therapy sessions?"
    new "Ótimo, agora que já acabámos, quero perguntar-te se... Vais continuar a acompanhar-me às sessões de terapia?"

    # say L1418 hin
    old "FOR REAL?"
    new "B:hin: Ótimo, agora que já acabámos, quero perguntar-te se... Vais continuar a acompanhar-me às sessões de terapia?"

    # say L1420 hin
    old "I mean... Seriously?"
    new "B:hin: A SÉRIO?"

    # say L1422 pla
    old "Sure! Well, only if you want too."
    new "T(pla|tu|say): Claro! Bem, só se tu quiseres."

    # say L1424 hin
    old "Yes, I would like it! You have helped me a lot and I would like to continue hanging out with you."
    new "B:pla: Claro! Só se tu quiseres."

    # say L1426 pla
    old "You can always count on me, Hinn."
    new "B:hin: Sim, eu queria! Tu ajudaste-me muito e gostava de continuar a passar tempo contigo."

    # say L1432 pla
    old "Hmm... Let me talk to her and see what I can do."
    new "B:hin: Mas como vais manter as sessões, o Dr. Johnson disse que tínhamos acabado."

    # say L1434 hin
    old "Great! I hope you can convince her..."
    new "B:pla: Hmm... Deixa-me falar com ela e ver o que posso fazer."

    # say L1436 pla
    old "Yes me too."
    new "A:ang: Muito obrigado, Dr. Johnson, a sessão de hoje foi ótima."

    # say L1459 ang
    old "Thank you very much Dr. Johnson, today's session was great."
    new "T: Muito obrigado, Dr. Johnson, a sessão de hoje foi ótima."

    # say L1463 joh
    old "I hope these tips help you, in the next session and we will analyze the progress."
    new "B:ang: Muito obrigado, Dr. Johnson, a sessão de hoje foi ótima."

    # say L1465 ang
    old "Very well, goodbye doctor."
    new "B:joh: Espero que estas dicas te ajudem, na próxima sessão analisaremos o progresso."

    # say L1475 joh
    old "How can I help you?"
    new "B:pla: Estou bem, Dr. Johnson."

    # say L1477 pla
    old "Well... I've been thinking with Hinn... And we wonder if we can continue with the..."
    new "B:joh: Como posso ajudar-te?"

    # say L1479 joh
    old "With the?"
    new "B:pla: Bem... Tenho estado a pensar com Hinn... E perguntamo-nos se podemos continuar com a..."

    # say L1481 pla
    old "If we can continue with the therapy?"
    new "T: Se podemos continuar com a terapia?"

    # say L1483 joh
    old "Oh, Hmm... I made an exception with you guys since that kind of session is for couple therapy..."
    new "B:pla: Se podemos continuar com a terapia?"

    # say L1485 pla
    old "Hmm, could we get some more of those?"
    new "B:joh: Oh, Hmm... Fiz uma exceção para vocês, pois esse tipo de sessão é para terapia de casal..."

    # say L1495 joh
    old "I'll give those therapy sessions if you help me with another patients exercise, I think you could help me with them..."
    new "B:joh: Hmm, tu sabes, vamos fazer um acordo..."

    # say L1497 pla
    old "Help with another patients?"
    new "B:joh: Vou dar-te essas sessões de terapia se me ajudares com o exercício de outro paciente, acho que poderias ser muito útil..."

    # say L1499 joh
    old "Yes, I actually have a case where I think you would be a great help..."
    new "B:pla: Podes ajudar com mais pacientes?"

    # say L1501 pla
    old "Hmm okay, and will the therapy continue in return?"
    new "B:joh: Sim, na verdade tenho um caso em que acho que tu serias uma grande ajuda..."

    # say L1503 joh
    old "Yes, I think it is an excellent deal."
    new "B:pla: Hmm, okay, e a terapia continuará em troca?"

    # say L1505 pla
    old "Very well then, Hinn will schedule the appointment for the next lesson."
    new "B:joh: Sim, acho que é um excelente negócio."

    # say L1507 joh
    old "Perfect, I'll let you know when I need you to work with my patient."
    new "B:pla: Muito bem, então Hinn marcará o próximo encontro."

    # say L1509 pla
    old "Understood."
    new "B:joh: Perfeito, aviso-te quando precisar que trabalhes com o meu paciente."

    # say L1516 hin
    old "Well? What happened?"
    new "Tudo está resolvido, só tens de a chamar para marcar o próximo encontro."

    # say L1518 pla
    old "Everything is settled, you just have to call her to make the next appointment."
    new "T(pla|tu|diz): Tudo resolvido, só tens de a chamar para marcar o próximo encontro."

    # say L1547 joh
    old "Wow Hinn, you decided to not wear the jacket, I see that the sessions served you well."
    new "B:pla: Sem problemas. Então, até amanhã?"

    # say L1552 joh
    old "Well, you're looking forward to continuing my therapy, uh?"
    new "B:joh: Wow Hinn, decidiste não usar o casaco, vejo que as sessões te fizeram bem."

    # say L1556 pla
    old "Well... "
    new "B:joh: Bem, estás ansioso para continuar a minha terapia, hã?"

    # say L1558 joh
    old "Hahaha I like to give therapy, so, don't worry guys."
    new "B:pla: Bem..."

    # say L1560 joh
    old "I think I've already given you a good introduction, what do you say if we go to Hinn's practice?"
    new "B:joh: Hahaha gosto de dar terapia, então, não se preocupem."

    # say L1564 joh
    old "Come on girl, don't be shy, after all you guys asked me for more lessons, right?"
    new "B:joh: Acho que já te dei uma boa introdução, o que achas se formos para a consulta da Hinn?"

    # say L1566 hin
    old "Yes, yes, I'm sorry..."
    new "B:joh: Vamos, menina, não sejas tímida, afinal vocês pediram-me mais aulas, certo?"

    # say L1568 joh
    old "All right, let's go step by step, ok?"
    new "B:hin: Sim, sim, desculpa..."

    # say L1582 joh
    old "How does it feel Hinn..."
    new "B:joh: Oh yeah, toma-o assim, enche completamente a mão, certo?"

    # say L1583 hin
    old "Warm and... Hard..."
    new "B:joh: Como é que isso se sente Hinn..."

    # say L1585 joh
    old "Hahaha the advantages of youth."
    new "B:hin: Quente e... Duro..."

    # say L1598 joh
    old "All right guys I think that's it for this lesson."
    new "B:joh: Hahaha as vantagens da juventude."

    # say L1600 joh
    old "I think you both enjoyed it a lot, and you already have some things to practice at home..."
    new "B:joh: Bem, rapazes, acho que é isso para esta aula."

    # say L1604 joh
    old "It was really a pleasure guys, I'll wait for you for the next lesson..."
    new "B:joh: Acho que vocês dois gostaram muito, e já têm algumas coisas para praticar em casa..."

    # say L1611 hin
    old "That was... Fun."
    new "B:joh: Foi realmente um prazer, pessoal, vou esperar por vocês na próxima aula..."

    # say L1613 pla
    old "Yes, I think it was... Very educational."
    new "Sim, acho que foi... Muito educativo."

    # say L1615 hin
    old "Hehehe yes it was..."
    new "B:pla: Sim, acho que foi... Muito educativo."

    # say L1621 pla
    old "Well, see you tomorrow Hinn."
    new "B:hin: Hehehe sim, foi..."

    # say L1640 pla
    old "Hi Hinn, how are you?"
    new "B:pla: Então, até amanhã, Hinn."

    # say L1642 hin
    old "I'm great-"
    new "B:pla: Olá Hinn, como estás? T(hin|tu|say): Estou ótima- A:rub: Uau, perdeste a tua feia sweatshirt, rapariga?"

    # say L1650 rub
    old "Wow, did you lose your ugly sweatshirt girl?"
    new "B:hin: Estou ótimo-"

    # say L1654 rub
    old "Yes, don't you feel sorry to show that fatness?"
    new "B:rub: Uau, perdeste a tua feia camisola de malha, rapariga?"

    # say L1656 pla
    old "Really, you aga-"
    new "Tu estás a falar dos meus peitos grandes? Tu és uma invejosa, Ruby!"

    # say L1658 hin
    old "Are you talking about my big boobs? You envious Ruby jerk?"
    new "B:pla: Olha, tu de novo..."

    # say L1660 rub
    old "What ?! I envy? I don't know what-"
    new "B:hin: Estás a falar dos meus peitos grandes? Tu invejosa Ruby?"

    # say L1662 hin
    old "Ohh sorry, I'm a woman with a really good body and some brain..."
    new "B:rub: Que?! Ciúmes? Não faço ideia do que-"

    # say L1664 oli
    old "Ouchh..."
    new "B:hin: Ohh desculpa, sou uma mulher com um corpo incrível e algum cérebro..."

    # say L1668 hin
    old "Ohh I'm sorry, was it too much for your little head? Maybe tomorrow you will understand it..."
    new "B:oli: Ai..."

    # say L1670 hin
    old "Right now I don't have time to waste with a couple of stupid brainless girls like you. See ya..."
    new "B:hin: Ohh desculpa, foi demais para a tua cabecinha? Talvez amanhã compreendas..."

    # say L1679 pla
    old "Hehehe see ya..."
    new "B:hin: Agora não tenho tempo a perder com umas miúdas estúpidas e sem cérebro como vocês. Até sempre..."

    # say L1681 rub
    old "Oh you shut up, loser!"
    new "B:pla: Hehehe até logo..."

    # say L1683 pla
    old "Ugh, sorry..."
    new "A:pla: Uau, Hinn, isso foi incrível!"

    # say L1693 pla
    old "Wow Hinn that was great!"
    new "B:pla: Ugh, desculpa..."

    # say L1695 hin
    old "It doesn't matter, come sit on the couch."
    new "B:pla: Uau, Hinn, isso foi incrível!"

    # say L1697 pla
    old "What? What for?"
    new "B:hin: Não importa, vem sentar no sofá."

    # say L1699 hin
    old "I'm going to suck it you, sit down..."
    new "B:pla: O quê? Para quê?"

    # say L1701 pla
    old "(What the...) All right."
    new "B:hin: Vou chupá-lo, senta-te..."

    # say L1712 pla
    old "Are you sure-"
    new "B:pla: (Que raio...) Tudo bem."

    # say L1715 hin
    old "You just watch and enjoy."
    new "T(hin|tu|diz): Tu só vês e desfrutas."

    # say L1729 hin
    old "Sorry, sorry. I was so impulsive... I just felt adrenaline after what happened and I wanted to try-"
    new "B:hin: Tu só observas e desfrutas."

    # say L1731 pla
    old "No, don't worry, I'm amazed at your progress, you're more confident."
    new "B:hin: Desculpa, desculpa. Fui tão impulsivo... Senti adrenalina depois do que aconteceu e quis tentar-"

    # say L1733 pla
    old "And I like that."
    new "B: Não, não te preocupes, estou impressionado com o teu progresso, estás mais confiante."

    # say L1737 pla
    old "Yes, it was exciting."
    new "Sim, foi empolgante. Acho que o Dr. Johnson ajudou muito."

    # say L1739 hin
    old "I think Dr. Johnson has helped a lot."
    new "B:pla: Sim, foi empolgante."

    # say L1741 pla
    old "You bet she has..."
    new "Aposta que sim... Bem, acho que a minha mãe vai chegar em breve, podemos continuar amanhã, o que tu achas?"

    # say L1745 hin
    old "Well, I think my mom will be here soon, we can continue tomorrow, what do you think?"
    new "B:pla: Podes crer que tem..."

    # say L1747 pla
    old "Sure, see you tomorrow Hinn."
    new "B:hin: Bem, acho que a minha mãe vai chegar logo, podemos continuar amanhã, o que tu achas?"

    # say L1767 pla
    old "I love it."
    new "B:pla: Claro, vejo-te amanhã Hinn."

    # say L1769 hin
    old "I'm glad you liked."
    new "T(hin|tu|diz): Fico contente que tenhas gostado."

    # say L1771 hin
    old "Whenever you want another one we could practice again."
    new "B:hin: Fico contente que tenhas gostado."

    # say L1775 hin
    old "Great. See you tomorrow."
    new "B:hin: Sempre que quiseres outra vez podemos praticar de novo."

    # say L1777 pla
    old "Good night Hinn."
    new "B:hin: Ótimo. Até amanhã."

    # say L1819 joh
    old "Great, let's not waste any more time..."
    new "B:pla:... Bem-"

    # say L1821 joh
    old "Let's heat the situation up a bit, since you want something more advanced Hinn, let's try a double blowjob."
    new "B:joh: Ótimo, não vamos perder mais tempo..."

    # say L1823 joh
    old "I hope it's not too much for you..."
    new "B:joh: Vamos aquecer um pouco a situação, já que queres algo mais avançado, Hinn, vamos tentar uma dupla felação."

    # say L1825 hin
    old "Okay, let's try it."
    new "B:joh: Espero que não seja demasiado para ti..."

    # say L1827 joh
    old "Hahaha who are you and what did you do with Hinn?"
    new "B:hin: Okay, vamos experimentar."

    # say L1836 joh
    old "With your tongue, stimulate the tip of the penis."
    new "Com a língua, estimula a ponta do pénis. Isso enlouquece qualquer homem..."

    # say L1837 joh
    old "This drives any man crazy..."
    new "B:joh: Com a tua língua, estimula a ponta do pénis."

    # say L1849 joh
    old "Hmm, I think you guys are ready to do it right?"
    new "B:joh: Isto enlouquece qualquer homem..."

    # say L1851 pla
    old "Do... What?"
    new "A:joh: Merda, vamos foder, pessoal..."

    # say L1853 joh
    old "Fuck, let's fuck guys..."
    new "B:pla: Do... O quê?"

    # say L1857 joh
    old "Come with me."
    new "B:joh: Merda, vamos transar, pessoal..."

    # say L1866 joh
    old "This is a practice room that I use with some patients."
    new "B:joh: Vem comigo."

    # say L1868 joh
    old "Come on guys take off your clothes, today you are going to have sex!"
    new "B:joh: Esta é uma sala de prática que uso com alguns pacientes."

    # say L1876 joh
    old "What's up [pla]? Now are you the shy one?"
    new "B:joh: Vamos, rapazes, tirem a roupa, hoje vão ter sexo! T(joh|formal|say): O que se passa, [pla]? Agora és tu o tímido? A:joh: Talvez precisem de um exemplo..."

    # say L1884 joh
    old "Well? What are you waiting for, you're the only one with clothes, don't you want to fuck this cute Hinn?"
    new "B:joh: Talvez precisas de um exemplo..."

    # say L1894 joh
    old "All right, as I know this is probably your first time, let's go smooth and slow..."
    new "B:joh: Bem? O que estás à espera, és o único com roupa, não queres foder esta adorável Hinn?"

    # say L1895 joh
    old "Let me lubricate it well before we start."
    new "B:joh: Tudo bem, como sei que é provavelmente a tua primeira vez, vamos com calma..."

    # say L1907 joh
    old "Well guys, I hope to see you for a lesson soon... You can continue your practices in the meantime."
    new "B:joh: Deixa-me lubrificar bem antes de começarmos."

    # say L1909 hin
    old "Yes, it was a lot of fun."
    new "B:joh: Bem, pessoal, espero ver-vos em breve para uma aula... Podem continuar a praticar entretanto."

    # say L1911 joh
    old "Great, I think that's it for today let's get dressed and go to the office."
    new "B:hin: Sim, foi muito divertido."

    # say L1919 joh
    old "Well guys, I hope to see you for a next lesson soon... You can continue your practices in the meantime."
    new "B:joh: Ótimo, acho que é isso por hoje. Vamos vestir-nos e ir para o escritório."

    # say L1980 joh
    old "Haha that's great..."
    new "A:hin: Então, vamos para o sofá?"

    # say L1982 hin
    old "So, are we going to the couch?"
    new "B:joh: Haha, isso é ótimo..."

    # say L1984 joh
    old "Ohh no, let's not waste time, let's go directly to a more comfortable place..."
    new "B:hin: Então, vamos para o sofá?"

    # say L2018 joh
    old "Hahaha, come on I've already sucked your penis, there's no reason to be ashamed."
    new "B:pla:... Não, não, eu só-"

    # say L2020 joh
    old "Actually, today while you fuck Hinn you are going to enjoy my soft and big boobs..."
    new "B:joh: Hahaha, vamos, já te chupaste o pénis, não há razão para ter vergonha."

    # say L2036 joh
    old "Another successful session guys... Let's get dressed."
    new "B:joh: Na verdade, hoje enquanto tu fodes a Hinn vais aproveitar os meus peitos macios e grandes..."

    # say L2044 joh
    old "All right that's it for today, I hope to see you soon for a next lesson guys."
    new "B:joh: Outra sessão bem-sucedida, pessoal... Vamos nos vestir."

    # say L2046 hin
    old "Of course we will Dr. Johnson."
    new "B:joh: Muito bem, é tudo por hoje, espero ver-vos em breve para a próxima aula."

    # say L2097 joh
    old "Oh, but here are my favorite patients... Hehehe."
    new "B:hin: Claro que sim, Dr. Johnson."

    # say L2099 hin
    old "Good afternoon Dr. Johnson."
    new "B:joh: Oh, mas aqui estão os meus pacientes favoritos... Hehehe."

    # say L2101 joh
    old "How are you guys? Ready for our last lesson?"
    new "B:hin: Boa tarde, Dr. Johnson."

    # say L2103 pla
    old "Last lesson?"
    new "B:joh: Como estão vocês? Prontos para a nossa última aula?"

    # say L2105 joh
    old "Yes, I think you already have the basics, it is important that you now experience for yourselves to discover your own sexuality."
    new "B:pla: Última lição?"

    # say L2107 hin
    old "But... Can't we go on?"
    new "B:joh: Sim, acho que já tens os fundamentos, é importante que agora experimentes por ti mesmo para descobrires a tua própria sexualidade."

    # say L2109 joh
    old "Well, we could repeat some of the lessons we've already done..."
    new "B:hin: Mas... Não podemos continuar?"

    # say L2111 hin
    old "Oh great, sounds good..."
    new "B:joh: Bem, poderíamos repetir algumas das lições que já fizemos..."

    # say L2113 pla
    old "So, what will we do today?"
    new "B:hin: Ótimo, parece bem..."

    # say L2115 joh
    old "Let's go to the room and I'll explain."
    new "B:pla: Então, o que vamos fazer hoje?"

    # say L2123 joh
    old "All right, let's heat things up a bit by lubricating it well, you know what to do."
    new "B:joh: Vamos para o quarto e eu explico."

    # say L2141 joh
    old "Yes, I will just be watching, the idea is that you can continue to do it yourself so that you can enjoy your sexuality alone."
    new "B:pla: Sozinho?"

    # say L2143 pla
    old "Hmm ok."
    new "B:joh: Sim, vou apenas observar, a ideia é que tu continues a fazê-lo para que possas desfrutar da tua sexualidade sozinho."

    # say L2162 joh
    old "Well guys, that was it for today, get dressed."
    new "B:pla: Hmm ok."

    # say L2170 joh
    old "I think it's time for you to practice what you learned. Enjoy it guys!"
    new "B:joh: Bem, pessoal, foi isso para hoje, vistam-se."

    # say L2172 joh
    old "If you want to repeat one of the lessons, don't hesitate to come back."
    new "B:joh: Acho que é hora de tu praticares o que aprendeste. Divirtam-se!"

    # say L2212 hin
    old "I'm great, What about you?"
    new "B:joh: Se quiser repetir uma das lições, não hesite em voltar."

    # say L2216 hin
    old "So? Would you like to repeat some session with Dr. Johnson?"
    new "B: Estou ótimo, e tu?"

    # say L2221 pla
    old "Of course! Let's do it."
    new "B:hin: Então? Gostavas de repetir alguma sessão com o Dr. Johnson?"

    # say L2230 pla
    old "I really would like to... But I can't right now."
    new "T(pla|tu|say): Eu realmente gostava de... Mas não posso agora."

    # say L2232 hin
    old "Oh don't worry you can look for me if you change your mind."
    new "B:pla: Eu realmente gostava de... Mas não posso agora."

    # say L2234 pla
    old "I will do it."
    new "B:hin: Não te preocupes, podes procurar-me se mudares de ideias."

    # say L2255 joh
    old "I knew it would not take long for you to return from the last session."
    new "B:pla: Vou fazê-lo."

    # say L2257 joh
    old "So? What do you want to do today guys?"
    new "B:joh: Eu sabia que não demorarias muito a voltar da última sessão."

    # say L2269 joh
    old "Oh, you guys want to go from the beginning, right?"
    new "B:joh: Então? O que querem fazer hoje, pessoal?"

    # say L2273 joh
    old "I like it! Let's do it."
    new "B:joh: Oh, vocês querem começar do início, certo?"

    # say L2283 joh
    old "It always surprises me!"
    new "B:joh: Gosto disto! Vamos fazer."

    # say L2290 joh
    old "Well, let's do it..."
    new "B:joh: Surpreende-me sempre!"

    # say L2308 joh
    old "Anyway... I like it! Let's do it."
    new "B:joh: Precisas de outra lição de sexo oral? Uh? Ou só queres que eu te faça um bom sexo oral?"

    # say L2355 joh
    old "Double blowjob and Doggystyle? How great does it sounds?"
    new "B:joh: O teu pénis é um dos maiores que já vi."

    # say L2367 joh
    old "And you are becoming some kind of expert Hinn!"
    new "B:joh: Duplo felatio e estilo cachorro? Que maravilha soa!"

    # menu L2372 
    old "Lesson 5"
    new "B:joh: E tu estás a tornar-te num verdadeiro especialista, Hinn!"

    # say L2380 joh
    old "Do you want to have my boobs on your face while you fuck Hinn, uh?"
    new "B:n: Lição 5"

    # menu L2403 
    old "Lesson 6"
    new "B:joh: Queres ter os meus peitos na tua cara enquanto fodes a Hinn, hã?"

    # say L2411 joh
    old "Oh god, I'm dying to see that pretty face covered with a good facial."
    new "B:n: Lição 6"

    # say L2444 hin
    old "Will come back soon..."
    new "B:joh: Bem, foi divertido, mas é tudo por hoje."

    # say L2446 joh
    old "I will be waiting."
    new "B:hin: Vou voltar já..."

    # say L2448 pla
    old "See you soon Dr Johnson."
    new "T(pla|tu|say): Até já, Dr. Johnson."

    # say L2457 hin
    old "That was hot, right?"
    new "B:pla: Até breve, Dr. Johnson."

    # say L2459 pla
    old "Yes, it was great."
    new "B:hin: Estava quente, certo?"

    # say L2461 hin
    old "Hehehe do want to repeat it tomorrow?"
    new "B:pla: Sim, foi ótimo."

    # say L2467 pla
    old "Ok, see you tomorrow Hinn."
    new "Ok, vejo-te amanhã Hinn."


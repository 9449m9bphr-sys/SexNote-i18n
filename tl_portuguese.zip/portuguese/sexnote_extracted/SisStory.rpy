# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/SisStory.rpy
translate portuguese strings:

    # say L9 sis
    old "Hey [pla], I heard [mo1] and [mo2] arguing about you last night."
    new "T(sis|tu|say): Ei [pla], ouvi dizer que [mo1] e [mo2] discutiram sobre ti ontem à noite."

    # say L10 sis
    old "Do you know what happened?"
    new "Sobre mim? Oh, merda..."

    # say L11 pla
    old "About me? Oh, fuck... "
    new "B:sis: Sabes o que aconteceu?"

    # say L12 sis
    old "What? Do you know what it was about?"
    new "B:pla: Sobre mim? Ah, merda..."

    # say L13 pla
    old "No, no I don't know. I, uh... I have to go."
    new "B:sis: O quê? Sabes do que se tratava?"

    # say L18 sis
    old "Wait, don't leave yet! I kinda need your help... "
    new "B:pla: Não, não sei. Eu... eu tenho que ir."

    # say L22 sis
    old "Well, you know all the nerdy shit, right?"
    new "B:sis: Espera, não vais embora ainda! Preciso de ajuda..."

    # say L23 pla
    old "... What are you trying to say?"
    new "B:sis: Bem, tu sabes toda a merda nerd, certo?"

    # say L24 sis
    old "What I mean is, do you know how to make a website?"
    new "B:pla:... O que estás a tentar dizer?"

    # say L25 pla
    old "Well, yes, I know how to do it."
    new "B:sis: O que eu quero dizer é, sabes fazer um site?"

    # say L26 sis
    old "See, that's nerdy shit... "
    new "B:pla: Bem, sim, eu sei como fazer."

    # say L27 pla
    old "Come out with it. What do you need?"
    new "B:sis: Vê, isso é coisa de nerd..."

    # say L28 sis
    old "Haha. Ok, just come to my room in the afternoon and I will explain everything..."
    new "B:pla: Vai lá, diz. O que precisas?"

    # say L60 pla
    old "Oh, shit..."
    new "B:sis: Haha. Ok, vem ao meu quarto à tarde e explico tudo..."

    # say L64 sis
    old "(GOD that's his... It's huge...)"
    new "B:pla: Oh, merda..."

    # say L70 pla
    old "No... It's... Not... What... It seems..."
    new "B:sis: (MEU DEUS, isso é dele... É enorme...)"

    # say L87 pla
    old "Oh shit, did she see you?"
    new "B:pla: Não... Não é... O que... Parece..."

    # say L89 bri
    old "Of course not. No one but you can see me..."
    new "B:pla: Oh merda, ela viu-te?"

    # say L91 pla
    old "Yeah... But she saw me... Like this... Fuck..."
    new "B:bri: Claro que não. Só tu me podes ver..."

    # say L93 pla
    old "Now what? It doesn't go down..."
    new "B:pla: Sim... Mas ela viu-me... Assim... Merda..."

    # say L95 bri
    old "Well, I think that interrupting the process of transferring magic power so abruptly was not a good thing..."
    new "B:pla: Agora o que? Não desce..."

    # say L97 pla
    old "So, now what do I do to get this thing down?"
    new "B:bri: Bem, acho que interromper o processo de transferência de poder mágico de forma tão abrupta não foi uma boa ideia..."

    # say L99 bri
    old "Well... It would be best to wait for your body to process all the magical power it received for the first time."
    new "B:pla: Então, e agora, o que faço para fazer isto desaparecer?"

    # say L101 pla
    old "Okay. It's probably best to go to my room before someone else comes in and sees me with this..."
    new "B:bri: Bem... Seria melhor esperar que o teu corpo processe todo o poder mágico que recebeste pela primeira vez."

    # say L103 bri
    old "Ok, I'll rest and try to recover some magical energy."
    new "B:pla: Ok. É melhor ir para o meu quarto antes que alguém mais entre e me veja com isto..."

    # say L132 pla
    old "... Sure, I guess."
    new "B:sis: Estive à espera de ti. Vamos direto ao assunto, sim?"

    # say L134 sis
    old "Now, pay attention... As you know, I have been selling clothes to friends and acquaintances."
    new "B:pla:... Claro, acho que sim."

    # say L135 sis
    old "But now I want to sell them on the internet! That's why I need you to help me make a website."
    new "B:sis: Agora, presta atenção... Como sabes, tenho estado a vender roupa a amigos e conhecidos."

    # say L136 pla
    old "Well, I've never done a storefront site before... But it should be easy enough."
    new "B:sis: Mas agora quero vendê-los na internet! É por isso que preciso da tua ajuda para fazer um site."

    # say L137 sis
    old "Perfect! Good nerd! Because I will need it ready for next week. I have a lot of items to post."
    new "B:pla: Bem, nunca fiz um site de loja antes... Mas deve ser fácil o suficiente."

    # say L138 pla
    old "What? That's gonna be pretty hard to make it that fast, [sis]."
    new "T(pla|tu|say): Que? Vai ser bem difícil fazer isso tão rápido, [sis]."

    # say L142 sis
    old "Alright, but how long will this take? And I'm not trying to just get this for free. I'm willing to pay a small fee for your help."
    new "B:pla: Não é tão simples como tu penses. Na verdade, vou precisar que trabalhes de perto comigo para me dizeres como queres que fique desenhado."

    # say L143 pla
    old "Really? Hmmm... Maybe we can work in the afternoons and see how far we can go with it."
    new "T: Bem? Hmm... Talvez possamos trabalhar à tarde e ver até onde conseguimos chegar com isso."

    # say L144 sis
    old "That's the spirit, little dude. And hey, if it all works out well, I could share some of the profits."
    new "B:pla: Mesmo? Hmm... Talvez possamos trabalhar à tarde e ver até onde conseguimos chegar."

    # say L145 pla
    old "Nice. Sounds good to me."
    new "B:sis: É isso aí, pequeno. E olha, se tudo correr bem, posso partilhar alguns dos lucros contigo."

    # say L146 sis
    old "Perfect! Then I will wait for you in the afternoon in my room so we can start working. And don't have me waiting like you did yesterday."
    new "B:pla: Ótimo. Soa bem para mim."

    # say L147 pla
    old "Ok, I will see you in the afternoon to help you."
    new "Obrigado(a)! Ah, a propósito, o que tens feito na garagem?"

    # say L148 sis
    old "Thank you so much! By the way, what have you been doing in the garage?"
    new "B:pla: Ok, vejo-te à tarde para te ajudar."

    # say L149 pla
    old "Well... Uhh... A school project... "
    new "B:sis: Muito obrigado! Por acaso, o que tens feito na garagem?"

    # say L150 sis
    old "And what's so exciting in the project that's making your dick so hard?"
    new "B:pla: Bem... Hum... Um projeto escolar..."

    # say L151 pla
    old "What? Uhh... I don't know... What are you're talking about... "
    new "B:sis: E o que é tão empolgante no projeto que está deixando o teu pénis tão duro?"

    # say L152 sis
    old "Haha. Yeah, right. You know I saw it?"
    new "B:pla: O quê? Hã... Não sei... Do que estás a falar..."

    # say L154 sis
    old "Ok, ok, don't answer me. I was just being curious... If you need to go ahead with your project, do your thing."
    new "B: Irmã: Haha. Claro. Tu sabes que eu vi?"

    # say L155 sis
    old "Just don't forget me in the afternoons."
    new "B:sis: Ok, ok, não me respondas. Eu estava só a ser curioso... Se precisas de avançar com o teu projeto, faz o que tens a fazer."

    # say L185 sis
    old "Damn, it's late. I didn't realize how much time has passed."
    new "Merda, está tarde. Não tinha reparado quanto tempo já passou."

    # say L189 pla
    old "Yup, we did a lot of work today."
    new "B:sis: Merda, já é tarde. Não tinha reparado quanto tempo passou."

    # say L190 sis
    old "That's right, you deserve a break today. Thanks for your hard work."
    new "B:pla: Sim, trabalhámos muito hoje."

    # say L191 pla
    old "Ok, you are very welcome... See you later, good night."
    new "B:sis: É verdade, tu mereces um descanso hoje. Obrigada pelo teu trabalho árduo."

    # say L200 pla
    old "Yeah, but we are making so much progress."
    new "B:pla: Ok, tu és muito bem-vindo... Até mais, boa noite."

    # say L201 sis
    old "Right! I like this kind of work. You typing all of those codes and me saying what to do... "
    new "B:pla: Sim, mas estamos a fazer tanto progresso."

    # say L202 pla
    old "Yeah... That was really fun... "
    new "B:sis: Certo! Gosto deste tipo de trabalho. Tu a escrever todos esses códigos e eu a dizer o que fazer..."

    # say L203 sis
    old "Oh, come on, it wasn't that bad and I will pay you... "
    new "B:pla: Sim... Foi mesmo divertido..."

    # say L204 pla
    old "You are right about that. We are a good team."
    new "B:sis: Oh, vamos, não foi assim tão mau e eu vou pagar-te..."

    # say L205 sis
    old "That's better! Ok, let's link back up tomorrow to keep working!"
    new "T(sis|tu|diz): Isso mesmo! Ok, vamos nos encontrar amanhã para continuar a trabalhar!"

    # say L227 sis
    old "NOTHING... NOTHING! (Shit!) I THINK WE'RE DONE FOR TODAY!"
    new "B:pla: Que raio! O que é isto?"

    # say L228 pla
    old "But... There is still so much to do."
    new "B:sis: NADA... NADA! (Merda!) ACHO QUE ACABÁMOS POR HOJE!"

    # say L229 sis
    old "A Virus! My laptop has a virus and I need to fix it... Come tomorrow. Leave now."
    new "B:pla: Mas... Ainda há tanto por fazer."

    # say L230 pla
    old "... (Hmm, that was weird.)"
    new "B: Irmã: Um vírus! O meu portátil tem um vírus e preciso de o arranjar... Vem amanhã. Vai-te embora agora."

    # say L247 pla
    old "I should check if [sis] needs help with the website."
    new "T(pla|tu|say): Devo verificar se [sis] precisa de ajuda com o site."

    # say L259 pla
    old "I- I'm sorry, I didn't k- know..."
    new "B:pla: Oh wow!"

    # say L260 sis
    old "Oh, come on... This isn't what you wanted to see?"
    new "B:pla: I- I'm sorry, I didn't k- know..."

    # say L267 sis
    old "You have worked very, very hard for me, maybe you deserve a small reward."
    new "B: Irmã: Ohh... Olha o que temos aqui... Tu definitivamente tens um pénis enorme..."

    # say L269 sis
    old "Well I think you have something for me down there, maybe I should take care of it."
    new "B: Irmã: Tu trabalhaste muito, muito por mim, talvez mereças uma pequena recompensa."

    # say L271 sis
    old "I know you want to fuck me... I think I could let you fuck my mouth, would you like that?"
    new "B: Irmã: Acho que tens algo para mim aí embaixo, talvez devesse cuidar disso."

    # say L273 sis
    old "Yes, I'll let you fuck my mouth, with that huge cock..."
    new "B: Irmã: Eu sei que tu queres foder-me... Acho que poderia deixar-te foder a minha boca, gostavas disso?"

    # say L274 sis
    old "Now, take out that cock and come here!"
    new "B:sis: Sim, vou deixar-te foder a minha boca, com esse pau enorme..."

    # say L292 pla
    old "Wow! That was just a dream..."
    new "B:sis: Agora, tira esse pénis e vem aqui!"

    # say L293 pla
    old "I should definitely stop playing visual novels..."
    new "B:pla: Uau! Isso foi apenas um sonho..."

    # say L294 pla
    old "Working with her so much is affecting me in some way."
    new "B:pla: Deveria definitivamente parar de jogar novelas visuais..."

    # say L325 pla
    old "Ufff finally... I think that's it, we are done."
    new "B:pla: Trabalhar tanto com ela está a afetar-me de alguma forma."

    # say L326 sis
    old "Really? Finally? Excellent!!! So, how do we start selling products?"
    new "B:pla: Ufff finalmente... Acho que é isso, estamos terminados."

    # say L327 pla
    old "Hmm... I'm a bit tired because of all I have done, we can check tomorrow."
    new "B:sis: Mesmo? Finalmente? Excelente!!! Então, como começamos a vender os produtos?"

    # say L328 sis
    old "What?! I've been waiting for weeks! I need to sell my products as fast as I can, it will take just a moment and you're not going die for that... "
    new "B:pla: Hmm... Estou um pouco cansado por tudo o que fiz, podemos ver isso amanhã."

    # say L329 pla
    old "Ok, I will explain, pay attention to this."
    new "T: Oh, esta é uma parte muito interessante do design web, usei JavaScript para tornar a tua página responsiva, apliquei os layouts e-"

    # say L336 pla
    old "Oh, this is a very interesting part on web designing, I used javascript in order to make your webpage responsive, I apply the layouts and-"
    new "B:pla: Ok, vou explicar, presta atenção a isto."

    # say L337 sis
    old "Come On! straight to the point nerd! How do I upload the content?"
    new "B:pla: Oh, esta é uma parte muito interessante do design web, usei JavaScript para tornar a tua página responsiva, apliquei os layouts e-"

    # say L338 pla
    old "Ok, well, to upload the pics and info, you need to access with the admin account, open the products window and there you can upload, item by item... "
    new "B:sis: Vamos lá! Vai direto ao assunto, nerd! Como faço para carregar o conteúdo?"

    # say L339 pla
    old "The description needs a title, detailed info of the product, the pics and finally the price, and there you go!"
    new "B:pla: Ok, bem, para carregar as fotos e a informação, precisas de aceder com a conta de administrador, abrir a janela de produtos e lá podes carregar, item por item..."

    # say L340 sis
    old "Woow, amazing, let me try myself... "
    new "B:pla: A descrição precisa de um título, informações detalhadas do produto, as fotos e finalmente o preço, e está feito!"

    # say L344 pla
    old "Ok... "
    new "B:sis: Uau, incrível, deixa-me experimentar..."

    # say L345 sis
    old "It's not as hard as you said, actually it's pretty simple... "
    new "B:pla: Ok..."

    # say L346 pla
    old "Well, it's because the hardest part was done already with the coding... "
    new "B:sis: Não é tão difícil como disseste, na verdade é bastante simples..."

    # say L347 sis
    old "Suuuuure. Now, how can an user make a purchase?"
    new "B:pla: Bem, é porque a parte mais difícil já estava feita com o código..."

    # say L348 pla
    old "Well, everything is done thru the security framework-"
    new "Bem, tudo é feito através do sistema de segurança -"

    # say L349 sis
    old "BORING! just tell me how I can see the money. "
    new "B:pla: Bem, tudo é feito através do sistema de segurança..."

    # say L350 pla
    old "Hmm ok. You need to go to the sales window, here you will see the customer info, products and money."
    new "B: Irmã: ABORRECIMENTO! Só me diz como posso ver o dinheiro."

    # say L351 sis
    old "Wujuu! If you behave I think, there is an option to make you my partner."
    new "B:pla: Hmm ok. Tu precisas de ir à janela de vendas, aqui vais ver a informação do cliente, os produtos e o dinheiro."

    # say L352 pla
    old "Yeah right. Well I think that's all for today, need anything else?"
    new "B:sis: Wujuu! Se fores bem-comportado, acho que há a opção de te tornares o meu parceiro."

    # say L353 sis
    old "No, if I need something I'll reach out to you... You better not doing something weird... "
    new "B:pla: Claro. Acho que é tudo por hoje, precisas de algo mais?"

    # say L355 sis
    old "Nevermind... I will be busy, doing my work, see you later... "
    new "B:sis: Não, se precisar de algo eu te chamo... Melhor não estares a fazer nada estranho..."

    # say L356 pla
    old "Hmm, Ok... (You are welcome, by the way... )"
    new "B: Irmã: Não importa... Vou estar ocupada, a trabalhar, até logo..."

    # say L387 pla
    old "(I should leave... I don't want to make her think I'm perverted.)"
    new "T: (Devo ir-me embora... Não quero que ela pense que sou um pervertido.)"

    # say L398 sis
    old "COME IN... AND CLOSE THE DOOR."
    new "B:pla: Desculpa, eu estava-."

    # say L399 pla
    old "(Shit!)"
    new "B:sis: ENTRA... E FECHA A PORTA."

    # say L405 pla
    old "Look I... "
    new "B: Merda!"

    # say L406 sis
    old "Shut up... You just saw me... Now it's my turn."
    new "T(sis|tu|say): Cala-te... Tu acabaste de me ver... Agora é a minha vez."

    # say L407 pla
    old "(Gulp) What? What do you mean?"
    new "B:sis: Cala-te... Tu acabaste de me ver... Agora é a minha vez."

    # say L408 sis
    old "I mean, show me what you got in those shorts."
    new "B:pla: (Gulp) O quê? O que queres dizer?"

    # say L409 pla
    old "Whaat?... "
    new "B:sis: Quero dizer, mostra-me o que tens nessas calças."

    # say L411 pla
    old "B- but... Why do you want to see me naked?"
    new "B- mas... Porque queres ver-me nu? É justiça para um pervertido... E eu estou apenas curiosa com o que vi na garagem da última vez... Então mostra-me... Agora!"

    # say L412 sis
    old "Is justice for a pervert... And I'm just curious about what I saw in the garage last time... So show me... Now!"
    new "B: B- mas... Porque queres ver-me nua?"

    # say L413 pla
    old "Alright, alright... "
    new "B:sis: A justiça para um pervertido... E estou apenas curiosa sobre o que vi na garagem da última vez... Então mostra-me... Agora!"

    # say L421 sis
    old "(Mmm... It's bigger than some pornstars I use to see.)"
    new "B:pla: Tudo bem, tudo bem..."

    # say L422 sis
    old "And... Why were you so excited at the garage?"
    new "B:sis: (Mmm... É maior do que alguns actores pornográficos que costumava ver.)"

    # say L423 pla
    old "Hmm... I- I don't know what you're talking about."
    new "B:sis: E... Porque é que estavas tão animado na oficina?"

    # say L424 sis
    old "Ugh. Ok, nevermind... I should go... "
    new "B:pla: Hmm... I- I não sei do que estás a falar."

    # say L428 pla
    old "Wait... That's my? "
    new "B:sis: Ugh. Ok, deixa estar... Devo ir..."

    # say L429 sis
    old "Bye... "
    new "B:pla: Espera... Isso é meu?"

    # say L436 pla
    old "What the hell! She took my clothes!"
    new "B:sis: Adeus..."

    # say L437 pla
    old "Oh shit! What do I do now?"
    new "B:pla: Que raio! Ela levou a minha roupa!"

    # say L438 pla
    old "I gotta get to my room really fast!"
    new "B:pla: Oh shit! O que faço agora?"

    # say L443 pla
    old "Ok I don't see anyone nearby, now is my chance... "
    new "B:pla: Tenho de chegar ao meu quarto muito depressa!"

    # say L453 mo2
    old "WHAT THE FUCK?!"
    new "B:pla: Ok, não vejo ninguém por perto, agora é a minha oportunidade..."

    # say L454 pla
    old "(... Oh god..) Sorry... "
    new "B:mo2: QUE PORRA É ESSA?!"

    # say L465 mo2
    old "YOU ARE A FUCKING PERVERT AND AN EXHIBITIONIST!!!"
    new "B:pla: (... Oh god..) Desculpa..."

    # say L466 pla
    old "(Oh shit, oh shit. I almost died! Fuck!)"
    new "B:mo2: TU ÉS UM PERVERTIDO E UM EXHIBICIONISTA!!!"

    # say L467 pla
    old "It's probably best to stay here until tomorrow... "
    new "B:pla: (Oh shit, oh shit. Quase morri! Merda!)"

    # say L490 sis
    old "Well, I am kind of ok."
    new "B:pla: É melhor ficarmos aqui até amanhã..."

    # say L491 pla
    old "Hmm... Is everything alright?"
    new "B:sis: Bem, estou mais ou menos."

    # say L492 sis
    old "Not really, the website is not working and I don't know what's wrong."
    new "B:pla: Hmm... Tudo bem?"

    # say L493 pla
    old "Is not working? You wanna check it together to see what the problem could be?"
    new "Não está a funcionar? Queres ver isso juntos para perceber o que pode estar a acontecer?"

    # say L494 sis
    old "Oh please, because I feel a bit down, you know."
    new "B:pla: Não está a funcionar? Queres ver juntos o que pode ser?"

    # say L495 pla
    old "Don't worry, we can find a solution."
    new "Não te preocupes, podemos encontrar uma solução."

    # say L502 pla
    old "I can see that your webpage has been visited several times, so there are actually people looking at it."
    new "B:pla: Não te preocupes, podemos encontrar uma solução."

    # say L503 sis
    old "I think the clothes are nice, but do you think they're maybe too expensive?"
    new "B:pla: Posso ver que a tua página web foi visitada várias vezes, por isso há realmente pessoas a ver."

    # say L504 pla
    old "Hmmm, I think you have a good variety of prices, so I don't think that is the problem."
    new "T: Hmmm, acho que tens uma boa variedade de preços, por isso não penso que seja esse o problema."

    # say L505 sis
    old "Could it be that the products aren't that nice?"
    new "B:pla: Hmmm, acho que tens uma boa variedade de preços, por isso não deve ser esse o problema."

    # say L506 pla
    old "I actually like them, I've seen you wearing some of the clothes, they look cool."
    new "A:sis: O site está a funcionar corretamente?"

    # say L507 sis
    old "Is the website running correctly?"
    new "T(sis|tu|diz): O site está a funcionar corretamente?"

    # say L508 pla
    old "What do you mean? Sure! it works, I made it myself."
    new "T: O que queres dizer? Claro! Funciona, fiz eu próprio."

    # say L509 sis
    old "Let's try to make a purchase to see if the website is ok."
    new "T(sis|tu|diz): Vamos fazer uma compra para ver se o site está ok."

    # say L510 pla
    old "I did everything carefully... Hmm, but we can double check."
    new "B:sis: Vamos tentar fazer uma compra para ver se o site está ok."

    # say L511 sis
    old "Perfect, select that shirt, then those pants, add them to the shopping cart."
    new "B:pla: Fiz tudo com cuidado... Hmm, mas podemos fazer uma verificação dupla."

    # say L512 sis
    old "What's next?"
    new "B: Irmã: Perfeito, seleciona essa camisa, depois essas calças, adiciona-os ao carrinho de compras."

    # say L513 pla
    old "The delivery info"
    new "B:sis: O que vem a seguir? T(pla|tu|diz): As informações de entrega. A:sis: Ok, vamos usar as nossas."

    # say L514 sis
    old "Ok, let's use ours."
    new "B:pla: A informação da entrega"

    # say L515 pla
    old "Oh, payment options, let's put the card in."
    new "B:sis: Ok, vamos usar os nossos."

    # say L517 pla
    old "Finally, summary cart."
    new "B:pla: Oh, opções de pagamento, vamos colocar o cartão."

    # say L518 pla
    old "Order went through successfully, the website works perfectly. That's not the problem."
    new "B:pla: Finalmente, carrinho de compras."

    # say L519 sis
    old "Cancel the order."
    new "T(sis|tu|diz): Cancela a encomenda."

    # say L520 sis
    old "I don't get it... What am I doing wrong?"
    new "B:sis: Cancela o pedido."

    # say L521 sis
    old "What do other people do to sell?"
    new "B:sis: Não percebo... O que estou a fazer de mal?"

    # say L522 pla
    old "Huh! that's brilliant."
    new "B:sis: O que é que as outras pessoas fazem para vender?"

    # say L523 sis
    old "Really? Wait... What's brilliant?"
    new "B:pla: Huh! isso é genial."

    # say L524 pla
    old "A very good idea could be to check how other people do it."
    new "B:sis: Mesmo? Espera... O que é brilhante?"

    # say L525 pla
    old "Let's compare ours with other websites, that way we can take some ideas too."
    new "T(pla|tu|say): Vamos comparar o nosso com outros sites, assim podemos pegar algumas ideias também."

    # say L526 pla
    old "Let's check a big one like... Hmm I don't know, Calvin Klown."
    new "B:pla: Vamos comparar o nosso com outros sites, assim podemos pegar algumas ideias também."

    # say L527 sis
    old "Yeah, that could work."
    new "B:pla: Vamos ver um grande como... Hmm, não sei, Calvin Klown."

    # say L528 pla
    old "They are really good, this looks amazing."
    new "Sim, é muito deprimente."

    # say L529 sis
    old "Yeah, it's very depressing."
    new "B:pla: São mesmo bons, isto parece incrível."

    # say L531 sis
    old "Just look! They are just so gorgeous, mine doesn't look even close."
    new "B:sis: Sim, é muito deprimente."

    # say L532 pla
    old "Well, it's not fair if you compare yourself with them, this is a worldwide fashion business!"
    new "B:sis: Olha só! São tão lindas, a minha nem se compara."

    # say L533 pla
    old "Consider, that they invest millions on advertisement, Internet, TV characters, even music videos and artists."
    new "B:pla: Bem, não é justo se tu te comparas com eles, este é um negócio de moda mundial!"

    # say L534 sis
    old "Yeah, that's very impressive."
    new "B:pla: Considera que eles investem milhões em publicidade, Internet, personagens de TV, até em vídeos e artistas musicais."

    # say L535 pla
    old "Alright, that was enough Calvin Klown for one day."
    new "Bem, isso foi suficiente de Calvin Klown para um dia."

    # say L541 pla
    old "Hmm... I have something in mind."
    new "B:pla: Bem, já deu Calvin Klown para hoje."

    # say L542 pla
    old "Well, we could, and I am not sure... But try some options to show the clothes like they do."
    new "B:pla: Hmm... Tenho uma ideia."

    # say L543 sis
    old "You mean the way they use models and take the pics?"
    new "B:pla: Bem, podíamos, e não tenho a certeza... Mas tenta algumas opções para mostrar as roupas como eles fazem."

    # say L544 pla
    old "Yes, it could look more... Interesting? I guess so?"
    new "B:sis: Tu queres dizer a maneira como usam modelos e tiram as fotos?"

    # say L545 pla
    old "We can give it a try, doing the pics instead of using the ones you're using."
    new "B:pla: Sim, poderia ficar mais... Interessante? Acho que sim?"

    # say L546 sis
    old "Hmm but we'll need a model and we can't afford that... "
    new "B:pla: Podemos experimentar, fazendo as fotos em vez de usar as que estás a usar."

    # say L547 sis
    old "Wait a minute... I could be the model, can't I?"
    new "B:sis: Hmm mas vamos precisar de um modelo e não podemos pagar isso..."

    # say L548 pla
    old "I considered that an option at first, but I saw there are some clothes where you would be almost naked."
    new "B:sis: Espera um momento... Eu poderia ser a modelo, não é?"

    # say L549 pla
    old "I mean some clothes are 'sexy' and a lot of people would watch them... Are you sure you are ok with that?"
    new "B:pla: Eu considerei essa opção no início, mas vi que há algumas roupas onde tu ficarias quase nua."

    # say L550 sis
    old "Actually, I like the idea... I think it's kind of exciting!"
    new "B:pla: Quero dizer, algumas roupas são 'sexy' e muita gente gostaria de ver... Tens a certeza de que estás bem com isso?"

    # say L551 pla
    old "Well, if you'd like we would have covered an important part of the problem and if you are the model that would be very useful to have a defined market image."
    new "B:sis: Na verdade, gosto da ideia... Acho que é até excitante!"

    # say L552 sis
    old "Ok, so, what do we need?"
    new "B:pla: Bem, se quisermos teremos abordado uma parte importante do problema e se fores tu o modelo isso será muito útil para termos uma imagem de mercado definida."

    # say L553 pla
    old "We will for sure need a photographer."
    new "T(pla|tu|say): Vamos precisar com certeza de um fotógrafo."

    # say L554 sis
    old "Wait a minute! A photographer could be really expensive."
    new "B:pla: Vamos precisar de um fotógrafo, com certeza."

    # say L555 sis
    old "Why don't you take the pics instead?"
    new "B:sis: Espera aí! Um fotógrafo pode ser muito caro."

    # say L556 pla
    old "Technically, I could but I have no camera."
    new "A:sis: Acho que consigo fazer isso. Mas tu consegues usar uma câmara profissional?"

    # say L557 sis
    old "I think I can handle that. But can you use a professional camera?"
    new "B:pla: Tecnicamente, podia, mas não tenho câmara."

    # say L558 sis
    old "What I'm asking for of course a nerd knows."
    new "B: Isto eu consigo fazer. Mas podes usar uma câmara profissional?"

    # say L560 sis
    old "That's great, so if you take the pictures, we can save a little without asking for the help of a photographer."
    new "B: Irmã: O que estou a pedir é claro que um nerd sabe."

    # say L561 sis
    old "So, I will use all my money to buy a lot of clothes, so we can take tons of pics."
    new "B:sis: Ótimo, então se tu tirares as fotos, podemos poupar um pouco sem pedir ajuda a um fotógrafo."

    # say L562 pla
    old "Wait what? No, no, no, calm down! It isn't convenient to use all the money you have."
    new "B:sis: Então, vou usar todo o meu dinheiro para comprar muita roupa, assim podemos tirar toneladas de fotos."

    # say L563 sis
    old "But we will need the clothes for the pics... "
    new "B:pla: Espera aí! Não, não, não, calma! Não é conveniente usares todo o dinheiro que tens."

    # say L564 pla
    old "Yes, we do, however, we have to do some baby steps to check if it works."
    new "B:sis: Mas vamos precisar das roupas para as fotos..."

    # say L565 pla
    old "If we can see some progress then you can invest more to see an improvement."
    new "B:pla: Sim, mas temos de dar alguns passos pequenos para ver se funciona."

    # say L566 sis
    old "Hmm... Yeah, I think you're right."
    new "B:pla: Se conseguirmos ver algum progresso, tu podes investir mais para ver uma melhoria."

    # say L567 sis
    old "Ok, I need time now, to get all of this ready. thanks for your help, I really appreciate it."
    new "Ok, preciso de tempo agora para preparar tudo. obrigado pela tua ajuda, eu realmente aprecio. Vou avisar-te assim que tiver tudo pronto."

    # say L568 sis
    old "I will let you know as soon as I have everything ready."
    new "B:sis: Ok, preciso de tempo agora, para preparar tudo. obrigada pela tua ajuda, aprecio muito."

    # say L569 pla
    old "Cool, I'll see you then."
    new "Bem, estive ocupado. O que aconteceu?"

    # say L591 sis
    old "You can't imagine how excited I am, I almost jumped from the window when I saw the driver."
    new "B:sis: Vamos, a entrega acabou de chegar."

    # say L592 pla
    old "I can see that, you're all anxious to start."
    new "B:sis: Não imaginas como estou excitada, quase saltei da janela quando vi o condutor."

    # say L593 sis
    old "Yes, we can't waste time, I have been waiting for this, the website needs this."
    new "B:pla: Eu vejo isso, estás ansioso para começar."

    # say L594 sis
    old "Let's go to my bedroom."
    new "B:sis: Sim, não podemos perder tempo, eu tenho esperado por isto, o site precisa disto."

    # say L602 sis
    old "Give me a moment, I don't know where to start. "
    new "B:sis: Vamos para o meu quarto."

    # say L603 pla
    old "Ok, just calm down a bit."
    new "T: Tudo bem, só acalma-te um bocadinho."

    # say L613 sis
    old "I'm pretty impatient we can start right away."
    new "I: Estou bastante impaciente, podemos começar já."

    # say L614 sis
    old "This is for you."
    new "B:sis: Estou bastante impaciente, podemos começar já."

    # say L619 pla
    old "Wow, this is huge, looks like a very good camera."
    new "B:sis: Isto é para ti."

    # say L620 sis
    old "I am sure you will figure out how it works."
    new "B:pla: Uau, isto é enorme, parece uma câmara muito boa."

    # say L621 sis
    old "Bear with me a moment while I get ready. You should try the cam in the meantime."
    new "B:sis: Tenho a certeza de que vais perceber como funciona."

    # say L622 pla
    old "Ok, Sure, I will start checking (It doesn't look so hard.)"
    new "B:sis: Espera um momento enquanto me preparo. Deves experimentar a câmara entretanto."

    # say L628 pla
    old "(I think auto mode should work just fine to start, I'll give a further review later.)"
    new "B:pla: Ok, claro, vou começar a verificar (não parece ser tão difícil.)"

    # say L629 pla
    old "(Let's check... She bought really nice clothes.)"
    new "B:pla: (Acho que o modo automático deve funcionar bem para começar, vou dar uma revisão mais tarde.)"

    # say L636 pla
    old "(This is very short and tiny. How does she fit in?)"
    new "B:pla: (Vamos ver... Ela comprou roupa muito bonita.)"

    # say L642 pla
    old "(This is a great color for a pic, I think I have a couple of ideas.)"
    new "T: (Esta é uma ótima cor para uma foto, acho que tenho umas ideias.)"

    # say L648 pla
    old "(What is this?)"
    new "B:pla: (Esta é uma ótima cor para uma foto, acho que tenho umas ideias.)"

    # say L651 pla
    old "(Ohh... This is a...)"
    new "B: pla: (O que é isto?)"

    # say L654 sis
    old "Wow,wow, wow. GET AWAY FROM MY STUFF... You little snoopy."
    new "B:pla: (Ohh... Isto é...)"

    # say L660 sis
    old "Where did you get it?"
    new "B:sis: Wow, wow, wow. Afasta-te das minhas coisas... Tu és mesmo curioso."

    # say L661 sis
    old "I mean why are you looking through my stuff?"
    new "B:sis: Onde é que tu foste buscar isso?"

    # say L662 pla
    old " I... I- I just... "
    new "T(pla|tu|say): Eu... Eu- Eu só..."

    # say L663 sis
    old " I... I... I... What?"
    new "B:pla: Eu... Eu... Eu apenas..."

    # say L664 pla
    old "I was checking the clothes you bought, and it was just there."
    new "B:sis: Eu... Eu... Eu... O quê?"

    # say L665 pla
    old "I was not snooping, just checking the clothes and that appeared out nowhere."
    new "B:pla: Estava a ver as roupas que compraste, e estava lá."

    # say L666 sis
    old "THERE'S NO TIME TO WASTE, WE CAME TO WORK, LET'S GET STARTED."
    new "B:pla: Não estava a bisbilhotar, só estava a verificar as roupas e aquilo apareceu do nada."

    # say L667 pla
    old "You're right, I'm sorry."
    new "B:sis: NÃO HÁ TEMPO A PERDER, VIEMOS TRABALHAR, VAMOS COMEÇAR."

    # say L668 sis
    old "Alright, just get everything ready while I change."
    new "Bem... Como é que eu fico?"

    # say L676 sis
    old "Well... How do I look?"
    new "B:sis: Tudo bem, prepara tudo enquanto eu me troco."

    # say L677 pla
    old "Gulp... Y-you look ho- nice, you look pretty nice."
    new "B:sis: Bem... Como é que eu fico?"

    # say L678 sis
    old "Let's start, we have already wasted enough."
    new "B:pla: Engasga... T-tu p-pareces tão bonita, pareces muito bem."

    # say L693 pla
    old "Ok, let me try... I will stay here to catch you better, stay right there."
    new "B:sis: Vamos começar, já perdemos tempo demais."

    # say L700 pla
    old "(Oh shit.. It's not as easy as I thought...)"
    new "B:pla: Ok, deixa-me tentar... Vou ficar aqui para te apanhar melhor, fica aí quieto."

    # say L702 pla
    old "Ehh... Just give me a second... I- I'm finding your best... Angle."
    new "B:pla: (Merda... Não é tão fácil quanto eu pensei...)"

    # say L703 pla
    old "(Shit! I must take the picture when it's fully focused...)"
    new "B: Ehh... Dá-me só um segundo... T-tenho de encontrar o teu melhor... Ângulo."

    # say L741 pla
    old "Ehmm... Fine, we could check it at the end of the session..."
    new "B:pla: (Merda! Tenho de tirar a foto quando estiver completamente focada...)"

    # say L742 sis
    old "You're right, sorry I'm just a bit anxious."
    new "B:pla: Hmm... Tudo bem, podemos verificar no final da sessão..."

    # say L743 pla
    old "Don't worry, relax a bit to look more natural."
    new "Não te preocupes, relaxa um bocadinho para pareceres mais natural."

    # say L744 sis
    old "Okay, so for the next photo what should I do?"
    new "B:pla: Não te preocupes, relaxa um bocadinho para pareceres mais natural."

    # say L745 pla
    old "Hmm, I think we should take a picture from behind to show the back of the dress..."
    new "Hmm, acho que devias ficar de costas para mostrar o fundo do vestido..."

    # say L746 sis
    old "Oh right! So what position should I take?"
    new "B:pla: Hmm, acho que devemos tirar uma foto de costas para mostrar o fundo do vestido..."

    # say L747 pla
    old "Hmm, I think we could use the bed, what about if you lean on the edge of the bed with you back pointing to me in a... Sexy way."
    new "Bem, acho que podemos usar a cama, e se tu te apoiares na beira da cama com as costas viradas para mim... De uma maneira... Sexy."

    # say L748 sis
    old "Alright ..."
    new "B:pla: Hmm, acho que podíamos usar a cama, e se tu te apoias na beira da cama com as costas voltadas para mim de uma maneira... Sexy."

    # say L758 sis
    old "So, do I look good like this?"
    new "B:sis: Tudo bem... T(sis|tu|diz): Então, estou bem assim? A:pla: (Uau) Sim... Ficas ótima, deixa-me focar a câmara..."

    # say L759 pla
    old "(Wow) Yeah... You look, great, let me focus on the camera ..."
    new "B:sis: Então, estou bem assim?"

    # say L760 pla
    old "(Oh shit, I'm getting hard. She looks really hot.)"
    new "B:pla: (Wow) Sim... Tu pareces ótima, deixa-me focar a câmara..."

    # say L792 pla
    old "(I hope she doesn't notice my hardon...)"
    new "B: (Oh merda, estou a ficar excitado. Ela parece mesmo quente.)"

    # say L795 pla
    old "Ok... I- I think that's enough, for now."
    new "B: pla: (Espero que ela não note a minha ereção...)"

    # say L796 sis
    old "What? Just two pics? No, I actually have an idea for a next photo..."
    new "B:pla: Ok... A- Acho que chega por agora."

    # say L797 pla
    old "R- really? With a front and backside photo of the dress is not... Enough?"
    new "B:sis: O quê? Apenas duas fotos? Não, na verdade tenho uma ideia para a próxima foto..."

    # say L798 sis
    old "(Why is he acting so strange.) No, let's take one last photo, ok?"
    new "B: R- realmente? Com uma foto da frente e de trás do vestido não é... suficiente?"

    # say L800 sis
    old "Let me try something I saw."
    new "B: (Porque é que ele está a agir tão estranho.) Não, vamos tirar uma última foto, ok?"

    # say L813 sis
    old "(Is he ok?, he's walking different) Do you think this looks good?"
    new "B:sis: Deixa-me experimentar algo que vi."

    # say L814 pla
    old "(Shit... I'm so hard right now...)"
    new "B:sis: (Ele está bem?, ele está a andar diferente) Achas que isto fica bem?"

    # say L815 pla
    old "Y- yes, you look great..."
    new "B:pla: (Merda... Estou tão excitado agora...)"

    # say L816 sis
    old "(What he gots there? Ohh! He has a boner. How could I not realize it before?)"
    new "B: pla: T- tu... olhas bem..."

    # say L817 sis
    old "(Well, I need to let him work, he is very focused, and don't want to make him feel uncomfortable.)"
    new "B:sis: (O que ele tem aí? Ahh! Ele tem uma ereção. Como é que eu não reparei antes?)"

    # say L851 sis
    old "Alright, I think that's enough for now..."
    new "Bem, acho que chega por agora..."

    # say L852 pla
    old "Oh, great, so it's done then see you later..."
    new "B:sis: Tudo bem, acho que chega por agora..."

    # say L856 sis
    old "Wait a minute..."
    new "B:pla: Oh, ótimo, então está feito, até mais..."

    # say L858 sis
    old "You said we could check the photos at the end of the session..."
    new "B:sis: Espera um momento..."

    # say L860 pla
    old "You're right..."
    new "B:sis: Tu disseste que podíamos ver as fotos no final da sessão..."

    # say L863 pla
    old "Ok... L- let's see the photos..."
    new "T(pla|tu|diz): Ok... L- vamos ver as fotos..."

    # menu L883 
    old "Watch again"
    new "B:pla: Ok... L- vamos ver as fotos..."

    # menu L887 
    old "Not Again"
    new "Estas fotos estão desfocadas! Elas parecem realmente más..."

    # say L900 sis
    old "These photos are out of focus! They look really bad..."
    new "T(sis|tu|say): Estas fotos estão desfocadas! Parecem mesmo más..."

    # say L901 pla
    old "I am sorry, I think I need to practice more."
    new "B:sis: Estas fotos estão desfocadas! Parecem mesmo más..."

    # say L902 sis
    old "Oh no, this is not good, I wanted to have this material for the website really soon."
    new "B:pla: Desculpa, acho que preciso praticar mais."

    # say L903 pla
    old "I can make it better, just need some time."
    new "B:sis: Oh não, isto não é bom, queria ter este material para o site muito em breve."

    # say L904 sis
    old "So you need time but a moment ago you were snooping through my personal stuff."
    new "B:pla: Posso torná-lo melhor, só preciso de algum tempo."

    # say L905 sis
    old "I can't believe it."
    new "Não posso acreditar."

    # say L906 pla
    old "I'm sorry, I will practice more."
    new "B: Irmã: Não acredito."

    # say L907 sis
    old "All right, take the cam with you, and next time you better do it right."
    new "B:pla: Desculpa, vou praticar mais."

    # say L931 sis
    old "Well, I am not surprised."
    new "B:sis: Toma a câmara contigo, e da próxima vez faz melhor."

    # say L932 pla
    old "Why, don't you like them?"
    new "B:sis: Bem, não estou surpreendido."

    # say L933 sis
    old "Yep, I look gorgeous, I mean what could I expect from the 'nerd'."
    new "B:pla: Porquê, não gostas deles?"

    # say L934 pla
    old "I just wanted to help you."
    new "B:sis: Claro, estou linda, quer dizer, o que mais esperar da 'nerd'?"

    # say L935 sis
    old "You did well nerd."
    new "T(sis|tu|diz): Tu foste bem, nerd."

    # say L936 sis
    old "I didn't mean they are not good, don't take me the wrong way, I meant I knew it."
    new "B:sis: Tu foste bem, nerd."

    # say L937 sis
    old "I appreciated it."
    new "B: I não quis dizer que não são bons, não me interpretes mal, eu só quis dizer que eu sabia."

    # say L938 sis
    old "Time is money, let me upload this material, I need to sell."
    new "B: I apreciei."

    # say L939 pla
    old "Ok, I guess I'm leaving then."
    new "Pronta para repetir o último photoshoot?"

    # say L971 sis
    old "Ready to repeat the last photoshoot?"
    new "B:pla: Ok, acho que vou embora então."

    # say L972 pla
    old "Yes, I practiced and I know I'll do better now..."
    new "B:sis: Pronto para repetir a última sessão fotográfica?"

    # say L973 sis
    old "You better do it right this time... Don't waste more time. Get ready while I get changed."
    new "B:pla: Sim, treinei e sei que vou fazer melhor agora..."

    # say L978 sis
    old "Oh, by the way, do you need some help before we start?"
    new "B:sis: Tu melhor fazeres isto direito desta vez... Não desperdices mais tempo. Prepara-te enquanto eu me troco."

    # say L984 pla
    old "Well... Ok."
    new "B:sis: Oh, a propósito, precisas de alguma ajuda antes de começarmos?"

    # say L985 sis
    old "Hahaha, I'm going to make you cum fast..."
    new "B:pla: Bem... Ok."

    # say L995 sis
    old "I'm gonna get changed. You get the camera and stay ready."
    new "B:sis: Hahaha, vou fazer-te gozar depressa..."

    # say L1000 pla
    old "It's ok, I think I will be fine."
    new "B:sis: Vou trocar de roupa. Tu pegas a câmara e fica preparado."

    # say L1002 pla
    old "Yes, don't worry. I appreciate your help."
    new "B:pla: Está bem, acho que vou ficar bem."

    # say L1003 sis
    old "Perfect! then let's go, we have so much to do!"
    new "B:pla: Sim, não te preocupes. Aprecio a tua ajuda."

    # say L1004 sis
    old "I am excited, I just want to upload the new pics to get more sales!"
    new "B: Irmã: Perfeito! Então vamos, temos tanto para fazer!"

    # say L1033 sis
    old "Alright, let's start! "
    new "B: Irmã: Estou animada, só quero fazer o upload das novas fotos para ter mais vendas!"

    # say L1059 sis
    old "I already know all the positions. You just focus on taking good pictures this time..."
    new "B:sis: Tudo bem, vamos começar!"

    # say L1112 pla
    old "Ehmm... Done..."
    new "B:sis: Já conheço todas as posições. Tu só te preocupas em tirar boas fotos desta vez..."

    # say L1113 sis
    old "Alright, next one. You know what to do."
    new "B:pla: Hmm... Feito..."

    # say L1169 sis
    old "Very well, last one. I hope all the photos are perfect, right?"
    new "Sim, não te preocupes..."

    # say L1170 pla
    old "Yes, don't worry..."
    new "Bem, último. Espero que todas as fotos estejam perfeitas, certo? / Sim, não te preocupes... / Ok, vamos ver as novas fotos!"

    # say L1223 sis
    old "Ok, let's see the new photos!"
    new "B:pla: Sim, não te preocupes..."

    # say L1283 sis
    old "Well, it wasn't enough... And you are making me lose money!"
    new "B: pla: N-não foi minha culpa, eu realmente tentei melhorar..."

    # say L1284 sis
    old "Get out... Come back when you learn to use that damn camera..."
    new "B: Irmã: Bem, não foi o suficiente... E estás a fazer-me perder dinheiro!"

    # say L1317 sis
    old "Well, finally! These photos are great."
    new "B: Irmã: Sai... Volta quando aprenderes a usar essa maldita câmara..."

    # say L1318 sis
    old "I hope next time we don't have to do the photoshoot twice again..."
    new "B:sis: Bem, finalmente! Estas fotos estão ótimas."

    # say L1319 pla
    old "Don't worry..."
    new "B:sis: Espero que da próxima vez não tenhamos de fazer a sessão fotográfica duas vezes..."

    # say L1320 sis
    old "Hmm... Time is money, let me upload this material, I need to sell."
    new "B:pla: Não te preocupes..."

    # say L1321 pla
    old "Ok, leaving now."
    new "B:sis: Hmm... O tempo é dinheiro, deixa-me carregar este material, preciso de o vender."

    # say L1395 pla
    old "(Holy shit! If I get caught she'll kill me!)"
    new "B:pla: Ok, a sair agora."

    # say L1398 sis
    old "Hey, big boy. Do you need some help?"
    new "B:pla: (Puta merda! Se ela me apanhar, mata-me!)"

    # say L1407 pla
    old "Oh, god. Thanks. If she would have caught me, I'd be a goner."
    new "B:sis: Ei, grande miúdo. Precisas de ajuda?"

    # say L1408 sis
    old "It's ok! you are saved now, just relax."
    new "B:pla: Oh, meu Deus. Obrigado. Se ela me apanhasse, eu estava perdido."

    # say L1409 pla
    old "Yes, I appreciate it, you saved my ass."
    new "B:sis: Está tudo bem! Estás a salvo agora, só relaxa."

    # say L1410 sis
    old "I feel thankful too, last time you were great with the pics."
    new "B:pla: Sim, agradeço, salvaste-me as fuças."

    # say L1411 sis
    old "Haven't given you a proper reward."
    new "B:sis: Sinto-me grata também, da última vez foste ótima com as fotos."

    # say L1412 pla
    old "Wh- What... Do you mean?"
    new "A:sis: O que eu quero dizer é... Tira essas calças e mostra-me esse pénis."

    # say L1413 sis
    old "What I mean is... Take off those pants and show me that dick."
    new "B:pla: Wh- What... Do you mean?"

    # say L1423 sis
    old "I knew it! It's fucking huge..."
    new "B:pla: Mesmo?… Ugh... Ok."

    # say L1425 sis
    old "Just let me turn on the lights to get a better look at it."
    new "B: Ia: Eu sabia! É enorme..."

    # say L1444 sis
    old "Hey buddy, guess what?"
    new "B: Irmã: Só deixa-me ligar a luz para ver melhor."

    # say L1446 sis
    old "Your idea was a big noise, it pulled off selling!"
    new "B: Irmã: Ei, adivinha o quê?"

    # say L1448 sis
    old "Yep, come to my bedroom I need your help with something..."
    new "B:sis: A tua ideia fez muito barulho, conseguiu vender!"

    # say L1455 sis
    old "Well, besides the messages I have now. We actually got a new customer, she was pretty interested in the last pics we did, remember?"
    new "B:sis: Sim, vem ao meu quarto, preciso da tua ajuda com uma coisa..."

    # say L1456 pla
    old "Yeah! I know which ones."
    new "B:sis: Bem, para além das mensagens que tenho agora. Conseguimos um cliente novo, ela mostrou-se bastante interessada nas últimas fotos que fizemos, lembras-te?"

    # say L1457 sis
    old "Anyway, I need your help now, we have several customers' messages."
    new "B:pla: Claro! Eu sei quais são."

    # say L1458 sis
    old "I'll need to answer them as some of them are very potential purchases."
    new "B: Irmã: De qualquer forma, preciso da tua ajuda agora, temos várias mensagens de clientes."

    # say L1459 sis
    old "Need you to take one package to a customer."
    new "T(sis|tu|diz): Preciso que leves um pacote a um cliente."

    # say L1460 pla
    old "You mean today?"
    new "B:sis: Preciso que leves um pacote a um cliente. T(pla|tu|say): Queres dizer hoje? A:sis: Oh não, quero dizer já agora."

    # say L1461 sis
    old "Oh no, I mean right now."
    new "B:pla: Quer dizer hoje?"

    # say L1462 pla
    old "I am kind of busy now."
    new "T(pla|tu|say): Estou um pouco ocupado agora."

    # say L1463 sis
    old "That's not a business wise decision."
    new "T: Isso não é uma decisão muito inteligente do ponto de vista empresarial."

    # say L1465 sis
    old "You know this is not actually a favor, it's included in the money you are expecting."
    new "B:sis: Isso não é uma decisão empresarial."

    # say L1466 pla
    old "Hmm... I know, but I can't do it right away... We never discussed these kind of things."
    new "B:sis: Sabes que isto não é realmente um favor, está incluído no dinheiro que esperas receber."

    # say L1467 sis
    old "Yes, I know but we have to be committed to make this business grow."
    new "T(sis|tu|diz): Sim, eu sei, mas temos de nos comprometer para fazer este negócio crescer."

    # say L1468 pla
    old "Come on, almost everybody knows about me here in town, it's not comfortable."
    new "B:sis: Sim, eu sei, mas temos de nos empenhar para fazer este negócio crescer."

    # say L1469 pla
    old "I don't want to be embarrassed delivering sexy panties to a classmate's mother."
    new "B:pla: Vamos, quase toda a gente aqui na cidade sabe de mim, não é confortável."

    # say L1470 sis
    old "Why would you be embarrassed, it isn't like you're the one wearing it."
    new "B:pla: Não quero ficar embaraçado a entregar calcinhas sexy à mãe de uma colega de turma."

    # say L1471 sis
    old "Here is the thing, do you still wanna be helped like the other night?"
    new "B: Irmã: Porque é que te embaraças, não é como se fosses tu a usá-lo."

    # say L1472 sis
    old "So, think about the 'business', if you help me I'll help you. I think my help is amazing, don't you like it?"
    new "B:sis: Aqui está a coisa, tu ainda queres ser ajudada como na outra noite?"

    # say L1473 pla
    old "Hmm... Fine, but don't take me wrong, It's for business!"
    new "B:sis: Então, pensa no 'negócio', se me ajudares eu ajudo-te. Acho que a minha ajuda é incrível, não gostas dela?"

    # say L1474 sis
    old "Hehehe, yeah sure! The business..."
    new "B:pla: Hmm... Tudo bem, mas não me interpretes mal, é para negócios!"

    # say L1475 sis
    old "You will find all the info you need on the package."
    new "B:sis: Hehehe, claro! O negócio..."

    # say L1477 pla
    old "Hmm alright..."
    new "B:sis: Vais encontrar toda a informação de que precisas no pacote."

    # say L1482 pla
    old "I think it's here... I hope it's not someone I know."
    new "A:jon: Sim, senhor, como posso ajudá-lo?"

    # say L1485 jon
    old "Yes, sir, how can I help you?"
    new "A:pla: (A sério? Ela está a usar isto?)"

    # say L1486 pla
    old "(For real? Is she wearing this?)"
    new "B:jon: Sim, senhor, como posso ajudá-lo?"

    # say L1487 pla
    old "Hmmm, I think this package is for you."
    new "B:pla: (A sério? Ela está a usar isto?)"

    # say L1488 jon
    old "(Wow! I know this young man, I met him in church.) "
    new "B: pla: Hmmm, acho que este pacote é para ti."

    # say L1489 jon
    old "For me?"
    new "B:jon: (Uau! Conheço este jovem, encontrei-o na igreja.)"

    # say L1490 pla
    old "Yes, we had your order record, let me confirm, it is the Ultra short skirt, marvelous night surprise dress."
    new "B:jon: Para mim?"

    # say L1491 jon
    old "... What? This must be a mistake."
    new "B:pla: Sim, tínhamos o registo do teu pedido, deixa-me confirmar, é a saia ultra curta, vestido surpresa maravilhosa para a noite."

    # say L1492 pla
    old "(Of course is yours, who else could be, has your name on it.)"
    new "B:jon:... O quê? Isto deve ser um engano."

    # say L1493 pla
    old "It could be, however, you're Mrs. Jones, right?"
    new "B: pla: (Claro que é teu, de quem mais poderia ser, tem o teu nome.)"

    # say L1494 jon
    old "Yes, that's me..."
    new "B:pla: Poderia ser, no entanto, tu és a Sra. Jones, certo?"

    # say L1495 pla
    old "Well, we have all your information here, and the payment was done online... So..."
    new "B:jon: Sim, sou eu..."

    # say L1496 jon
    old "(Hmm... I need to make up something, he knows me...)"
    new "B:pla: Bem, temos todas as suas informações aqui, e o pagamento foi feito online... Então..."

    # say L1497 jon
    old "Oh! I remembered now, this is for my daughter, I forgot completely, hehehe."
    new "B:jon: (Hmm... Preciso de inventar algo, ele conhece-me...)"

    # say L1498 pla
    old "Hmm... It's ok, I understand, hope you daughter likes it."
    new "B:jon: Oh! Lembrei-me agora, isto é para a minha filha, esqueci-me completamente, hehehe."

    # say L1503 jon
    old "Ok... Thank you! Bye bye."
    new "B:pla: Hmm... Tudo bem, eu entendo, espero que a tua filha goste."

    # say L1511 pla
    old "It's done!"
    new "Ótimo, o que aconteceu? Quero saber tudo."

    # say L1512 sis
    old "Awesome, What happened? I wanna know everything."
    new "B:pla: Está feito!"

    # say L1513 pla
    old "It was ok, gave her the package, that was it."
    new "T(pla|tu|say): Foi tudo bem, dei-lhe o pacote, foi só isso."

    # say L1514 sis
    old "Was she excited about the purchase?"
    new "T(sis|tu|diz): Estava ela entusiasmada com a compra?"

    # say L1515 pla
    old "Couldn't tell you, she was kind of reserved."
    new "Não sei, ela estava um bocado reservada."

    # say L1516 sis
    old "Did you see if she liked it?"
    new "B:pla: Não podia dizer-te, ela era um bocado reservada."

    # say L1517 pla
    old "No, I just gave her the package and she said thank you."
    new "B:sis: Viste se ela gostou?"

    # say L1518 sis
    old "I need you to pay careful attention to those details in future deliveries. "
    new "B:pla: Não, apenas lhe dei o pacote e ela disse obrigada."

    # say L1519 pla
    old "What do you mean by future deliveries?"
    new "B:sis: Preciso que prestes muita atenção a esses detalhes nas entregas futuras."

    # say L1520 sis
    old "I have more merchandise coming so get prepare for another photoshoot session. "
    new "T: Tenho mais mercadoria a caminho, então prepara-te para outra sessão de fotografia."

    # say L1521 pla
    old "Hmm... All right."
    new "B:sis: Tenho mais mercadoria a caminho, então prepara-te para outra sessão de fotografia."

    # say L1522 sis
    old "Now leave me alone. It's late and I have a lot to do... "
    new "B:pla: Hmm... Tudo bem."

    # say L1544 sis
    old "Hey!, You won't believe the great news I have, I am so excited, this is working really well."
    new "B: Irmã: Agora deixa-me em paz. É tarde e tenho muito que fazer..."

    # say L1545 sis
    old "We have a new customer, she ordered almost the entire website catalogue."
    new "B:sis: Ei!, Não vais acreditar na novidade que tenho, estou tão entusiasmada, isto está a correr mesmo bem."

    # say L1546 pla
    old "Wow, that's great!"
    new "B:sis: Temos uma nova cliente, ela encomendou quase todo o catálogo do site. T(pla|tu|say): Uau, isso é ótimo! A:sis: O pedido já foi processado, então... preciso da tua ajuda!"

    # say L1547 sis
    old "The order already went through, soooo... I need your help!"
    new "B:pla: Uau, isso é ótimo!"

    # say L1548 pla
    old "Let me guess, you want me to make the delivery?"
    new "B:sis: A encomenda já foi processada, então... Preciso da tua ajuda!"

    # say L1549 sis
    old "Yes, but if you go right now, you won't have to do it later, huh?"
    new "B:pla: Deixa-me adivinhar, queres que eu faça a entrega?"

    # say L1550 pla
    old "Well, it's still me doing the delivery!"
    new "B:sis: Sim, mas se fores agora, não terás de o fazer mais tarde, hã?"

    # say L1551 sis
    old "I love how engaged you are, this is why we are growing and growing!"
    new "B:pla: Bem, ainda sou eu a fazer a entrega!"

    # say L1552 pla
    old "Hmm, alright, I'll do the damn delivery... "
    new "B:sis: Adoro como estás envolvido, é por isso que estamos a crescer e a crescer!"

    # say L1553 sis
    old "Hahaha remember is for the ‘business'."
    new "B:pla: Hmm, bem, vou fazer a maldita entrega..."

    # say L1555 sis
    old "Alright, let me know when it's done, see you later."
    new "B:sis: Hahaha lembra-te que é para o ‘negócio’."

    # say L1558 pla
    old "(Hmmm I hope it isn't anyone I know like last time.)"
    new "B:sis: Tudo bem, avisa-me quando estiver pronto, até mais tarde."

    # say L1562 pla
    old "(Alright, is here...)"
    new "B:pla: (Hmm, espero que não seja ninguém que eu conheça como da última vez.)"

    # say L1564 ana
    old "Good morning, how can I help you?"
    new "B:pla: (Está bem, está aqui...)"

    # say L1567 pla
    old "G-good morning, Mrs. Anastasia? Here is your package!"
    new "B:ana: Bom dia, como posso ajudar-te?"

    # say L1568 ana
    old "Oh, Thank you so much! So? Are you the business guy behind this?"
    new "B:pla: B-bom dia, Sra. Anastasia? Aqui está o seu pacote!"

    # say L1571 pla
    old "Thanks... We are trying to get some extra income."
    new "B:ana: É tão fofo, ela tem muita sorte de ter um rapaz bonito e jovem como tu a ajudar."

    # say L1574 ana
    old "I like your products, surely I will look forward to knowing more about you guys."
    new "B:pla: Obrigado... Estamos a tentar arranjar algum rendimento extra."

    # say L1575 ana
    old "Specially you, sweety."
    new "B:ana: Gosto dos vossos produtos, com certeza vou querer saber mais sobre vocês."

    # say L1576 pla
    old "Hmmm... T-thanks."
    new "B:ana: Especialmente tu, querida."

    # say L1577 ana
    old "My pleasure, see you later sweetheart..."
    new "B:pla: Hmmm... O-obrigado."

    # say L1579 pla
    old "(What a nice lady.)"
    new "Bem, estou de volta."

    # say L1585 pla
    old "Well, I am back."
    new "B: Que senhora simpática."

    # say L1586 sis
    old "How was it? I'm kind of busy, but let me know everything."
    new "B:pla: Estou de volta."

    # say L1587 pla
    old "She was very interested in the clothes."
    new "Ótimo, disse-lhe que eram da melhor qualidade e muito elegantes."

    # say L1588 sis
    old "Great, what did you tell her?"
    new "B:pla: Ela estava muito interessada nas roupas."

    # say L1589 pla
    old "The common stuff, you know, I said hello, the information of the delivery."
    new "B:sis: Ótimo, o que é que lhe disseste?"

    # say L1590 pla
    old "She mentioned she will order more."
    new "B:pla: As coisas normais, sabes, disse olá, dei as informações da entrega."

    # say L1591 sis
    old "Fantastic, I will need your help next time, so she feels engaged with the purchase."
    new "B:pla: Ela mencionou que vai encomendar mais."

    # say L1592 sis
    old "Let me continue... I have more and more customers messaging."
    new "B:sis: Fantástico, vou precisar da tua ajuda da próxima vez, para que ela se sinta envolvida na compra."

    # say L1595 pla
    old "Sure, you are very welcome!"
    new "B:sis: Deixa-me continuar... Tenho cada vez mais clientes a mandar mensagens."

    # say L1615 sis
    old "You ready for the pics? I've been waiting for you."
    new "B:pla: Claro, és muito bem-vindo!"

    # say L1616 pla
    old "Oh right, I'm going for the camera, I'll see you in your bedroom."
    new "B:sis: Estás pronta para as fotos? Tenho estado à espera de ti."

    # say L1624 pla
    old "(Holy shit!)"
    new "B:pla: Oh, certo, vou buscar a câmara, vejo-te no quarto."

    # say L1625 sis
    old "Finally, I have good ideas for today's session."
    new "B:pla: (Puta merda!)"

    # say L1626 sis
    old "What do you think? Do I look beautiful?"
    new "B:sis: Finalmente, tenho boas ideias para a sessão de hoje."

    # say L1627 pla
    old "Gulp... (Wow, she is really hot) I think you look very... N-nice."
    new "B:sis: O que achas? Estou bonita?"

    # say L1628 sis
    old "Great... But, before we start do you think, you need any... Help?"
    new "B:pla: Engasga... (Uau, ela é mesmo muito atraente) Acho que tu estás muito... N-nice."

    # say L1629 pla
    old "What do you mean? I have the camera and everything..."
    new "B:sis: Ótimo... Mas, antes de começarmos, tu achas que precisas de alguma... Ajuda?"

    # say L1630 sis
    old "I mean if you need to 'relax' before we start..."
    new "T(sis|tu|say): Quero dizer se precisas de 'relaxar' antes de começarmos..."

    # say L1631 pla
    old "I-I don't understand..."
    new "B:sis: Quero dizer, se precisas de 'relaxar' antes de começarmos..."

    # say L1632 sis
    old "I mean, don't be flushed I know you got hard last time and is totally normal..."
    new "B:pla: N-Não percebo..."

    # say L1634 sis
    old "It's because of the clothes I'm wearing, I think it's fair, you know, you help me, I can help you too and I already did, didn't I?"
    new "B:sis: Quero dizer, não fiques embaraçado, sei que ficaste duro da última vez e é totalmente normal..."

    # say L1635 pla
    old "I'm not sure if it's okay..."
    new "B:sis: É por causa da roupa que estou a usar, acho que é justo, sabes, tu ajudas-me, eu posso ajudar-te também e já o fiz, não foi?"

    # say L1636 sis
    old "Oh come on, you're not going to take good pictures if you're hard the whole session..."
    new "B:pla: Não tenho a certeza se está bem..."

    # say L1637 sis
    old "It's because of business, remember?"
    new "B: Irmã: Vamos, não vais tirar boas fotos se estiveres excitado durante toda a sessão..."

    # say L1639 sis
    old "Great, take off your pants I'm going to suck you off..."
    new "B:sis: É por causa do trabalho, lembras-te? T(sis|tu|diz): Ótimo, tira as calças, vou chupar-te... A:pla: Q-QUE?! Vais chupar-..."

    # say L1640 pla
    old "W-WHAT?! Are you going to suck-..."
    new "B:sis: Ótimo, tira as calças, vou chupar-te..."

    # say L1641 sis
    old "Well... You did a great job with the deliveries, I think you deserve a reward, don't you think?"
    new "B:pla: Q-QUE?! Vais... vais chupar-..."

    # say L1643 sis
    old "By the way, I'll have to take off my clothes, just to be sure I don't stain the clothes for the photos..."
    new "B:sis: Bem... Fizeste um ótimo trabalho com as entregas, acho que mereces uma recompensa, não achas?"

    # say L1644 sis
    old "Does it bother you?"
    new "B: Isto é, vou ter de tirar a roupa, só para ter a certeza que não mancho as roupas para as fotos..."

    # say L1646 sis
    old "Hahaha you will love it..."
    new "B: Irmã: Isso incomoda-te?"

    # say L1663 sis
    old "I hope you are relaxed now, so let's do it!"
    new "B:sis: Hahaha vais adorar..."

    # say L1678 sis
    old "You think this way it looks good?"
    new "B: Irmã, espero que estejas relaxada agora, então vamos fazer isso!"

    # say L1679 pla
    old "Absolutely."
    new "T(tu|diz): Absolutamente."

    # say L1680 pla
    old "Let me be sure the skirt stands out. I will take a pic of entire clothes."
    new "B:pla: Absolutamente."

    # say L1715 pla
    old "Yes, let's do the next one from another position."
    new "B:pla: Vou-me certificar que a saia se destaque. Vou tirar uma foto de toda a roupa."

    # say L1716 sis
    old "Great! I saw one I want to try."
    new "B:pla: Sim, vamos fazer o próximo de outra posição."

    # say L1717 pla
    old "Sure, what do you have on mind?"
    new "A:sis: Quero tirar algumas fotos na cama."

    # say L1718 sis
    old "I want to take some pics on the bed."
    new "B:pla: Claro, o que tens em mente?"

    # say L1719 pla
    old "Well, we haven't done anything like that before. Let's do it!"
    new "B: I want to take some pics on the bed."

    # say L1720 pla
    old "Lay down on the bed but leave the legs out of the bed so we can see your butt."
    new "B:pla: Bem, nunca fizemos nada assim antes. Vamos fazer!"

    # say L1721 sis
    old "Nicee."
    new "B: Deita-te na cama mas deixa as pernas para fora para podermos ver o teu rabo."

    # say L1731 sis
    old "I hope it looks sexy."
    new "B:sis: Nicee."

    # say L1732 pla
    old "(Holy shit...) I-I am sure you're gonna love these."
    new "B:sis: Espero que fique sexy."

    # say L1733 pla
    old "But let me try to catch a bit more, your legs must look huge."
    new "B: (Puta merda...) T-Tenho a certeza de que vais adorar isto."

    # say L1759 pla
    old "I think I have it."
    new "B:pla: Mas deixa-me tentar apanhar um bocadinho mais, as tuas pernas devem parecer enormes."

    # say L1768 pla
    old "Ok, for the next picture I need you to turn around please, I want to try an option like the last time but slightly different."
    new "T(pla|tu|say): Ok, para a próxima foto preciso que te vire, por favor. Quero tentar uma opção parecida com a da última vez, mas ligeiramente diferente. A:pla: Não olhes para a câmara e tenta levantar um pouco mais o rabo, segura o cabelo com uma mão."

    # say L1769 pla
    old "Do not look at the camera and try to lift a bit more your butt, hold your hair with one hand."
    new "B: pla: Ok, para a próxima foto preciso que te vire, por favor. Quero tentar uma opção como da última vez, mas ligeiramente diferente."

    # say L1770 sis
    old "Ohh, I like it!"
    new "B:pla: Não olhes para a câmara e tenta levantar um pouco mais o rabo, segura o cabelo com uma mão."

    # say L1781 pla
    old "It's perfect."
    new "B:sis: Ohh, gosto disto!"

    # say L1806 pla
    old "Ok, I think we are done."
    new "Ótimo!!! Deixa-me vê-los!"

    # say L1814 sis
    old "Awesome!!! Let me see them!"
    new "B:pla: Ok, acho que já acabámos."

    # say L1819 pla
    old "Ok... Gallery... Done"
    new "B:sis: Ótimo!!! Deixa-me ver!"

    # say L1854 pla
    old "I do not know what's happening today, these photos are not sharp enough."
    new "B:pla: Ok... Galeria... Feito."

    # say L1855 sis
    old "We will need to try again, this material is important. "
    new "B:pla: Não sei o que está a acontecer hoje, estas fotos não estão nítidas o suficiente."

    # say L1856 pla
    old "Yes, I am sure we can make it a lot better."
    new "B:sis: Vamos ter de tentar de novo, este material é importante."

    # say L1857 pla
    old "I just need to practice more."
    new "B:pla: Sim, tenho a certeza de que podemos torná-lo muito melhor."

    # say L1858 sis
    old "I need you to put more effort, we can't keep wasting time like this."
    new "T: Precisas de te esforçar mais, não podemos continuar a perder tempo assim."

    # say L1859 pla
    old "It won't happen again!"
    new "B:sis: Preciso que ponhas mais empenho, não podemos continuar a perder tempo assim."

    # say L1884 sis
    old "Wow, we're on fire!"
    new "B:pla: Não vai acontecer de novo!"

    # say L1885 sis
    old "Look at me, so hot. I like your job and I'm not talking about the pics only."
    new "B:sis: Uau, estamos em chamas!"

    # say L1886 pla
    old "We are doing a great job."
    new "B:sis: Olha para mim, tão quente. Gosto do teu trabalho e não estou a falar só das fotos."

    # say L1887 sis
    old "Yes, everyday I have more customers, you're a big help."
    new "B:pla: Estamos a fazer um ótimo trabalho."

    # say L1888 sis
    old "I will go ahead to upload this content on the website."
    new "B:sis: Sim, todos os dias tenho mais clientes, tu és uma grande ajuda."

    # say L1889 pla
    old "Ok, bye."
    new "Bem, agora que estás aqui, te lembras da Sra. Anastasia? Ela fez outro pedido, eram principalmente os últimos que tirámos fotos!"

    # say L1910 sis
    old "Hey, now that you are here, do you remember Mrs Anastasia? Well, she placed another order, it was mostly the last ones we took pics of!"
    new "T: Ei, agora que estás aqui, lembras-te da Sra. Anastasia? Bem, ela fez outro pedido, eram principalmente os últimos que tirámos fotos!"

    # say L1911 sis
    old "Need you to be really nice with her, I'm sure, she will buy anything we post later!"
    new "B:sis: Ei, agora que estás aqui, lembras-te da Sra. Anastasia? Bem, ela fez outro pedido, eram principalmente os últimos que tirámos fotos!"

    # say L1912 sis
    old "So you better give her amazing customer service, don't want you to mess things up with her."
    new "B:sis: Preciso que sejas mesmo simpático com ela, tenho a certeza de que ela comprará tudo o que publicarmos mais tarde!"

    # say L1913 pla
    old "Ok... I'll go right away."
    new "B:sis: Então é melhor dares-lhe um atendimento excelente, não queres estragar as coisas com ela."

    # say L1914 sis
    old "Don't forget to be really kind, she is a very important client."
    new "B:pla: Ok... Vou já."

    # say L1916 pla
    old "Yes, yes, I know!"
    new "Bom dia, Sra., tenho outro pacote para si!"

    # say L1922 pla
    old "Good morning Mrs, I have another package for you!"
    new "B:pla: Sim, sim, eu sei!"

    # say L1923 ana
    old "Oh, it's you again, you came really fast, Thank you very much!"
    new "B:pla: Bom dia, tenho outro pacote para si!"

    # say L1924 pla
    old "We really appreciate your purchase."
    new "B:ana: Oh, és tu de novo, chegaste mesmo rápido, muito obrigada!"

    # say L1925 ana
    old "I do appreciate how much of a gentleman you are."
    new "B:pla: Agradecemos muito a sua compra."

    # say L1926 pla
    old "Hmmm, thank you... Uhh this is your package."
    new "B:ana: Aprecio muito como és um cavalheiro."

    # say L1927 ana
    old "Thank you sweety!"
    new "B:pla: Hmmm, obrigado... Uhh, isto é o teu pacote."

    # say L1932 ana
    old "You know what? you deserve a tip."
    new "B:ana: Obrigada, querido!"

    # say L1933 pla
    old "Oh please don't worry..."
    new "B:ana: Sabes o quê? Tu mereces uma gorjeta."

    # say L1934 ana
    old "Give me just a second, your kindness deserves compensation."
    new "T(ana|tu|diz): Dá-me só um segundo, a tua bondade merece ser recompensada."

    # say L1935 pla
    old "It's not necessary, I am very glad to bring your package."
    new "A:ana: Não te atrevas a sair!"

    # say L1936 ana
    old "Do not dare to leave!"
    new "B:pla: Não é necessário, estou muito contente por trazer o teu pacote."

    # say L1948 ana
    old "I beg your pardon... Can't find my purse."
    new "B:ana: Nem ousar sair!"

    # say L1949 pla
    old "Do not worry, it's not a problem."
    new "B:ana: Peço desculpa... Não consigo encontrar a minha carteira."

    # say L1950 ana
    old "Oh no, you deserve it."
    new "B:pla: Não te preocupes, não é problema."

    # say L1951 ana
    old "Let me see if I could have something here... Hope you like it."
    new "B:ana: Oh não, tu mereces."

    # say L1953 pla
    old "(Wow) ..."
    new "B:ana: Vamos ver se tenho algo aqui... Espero que gostes."

    # say L1954 ana
    old "(He's so shy... Hehehe, can't even speak.)"
    new "B:pla: (Wow)..."

    # say L1955 pla
    old "Gulp, tha-... Thank you."
    new "B:ana: (Ele é tão tímido... Hehehe, nem consegue falar.)"

    # say L1957 ana
    old "Hehehe, You are kind of tender."
    new "B:pla: Engasga, a-... Agradeço."

    # say L1958 ana
    old "I hope I can see you next time, I'll have cash handy. Bye handsome!"
    new "B:ana: Hehehe, Tu és um pouco sensível."

    # say L1966 sis
    old "Was everything alright?"
    new "B:ana: Espero que possa ver-te da próxima vez, vou ter dinheiro à mão. Adeus, lindo!"

    # say L1967 pla
    old "Definitely, she is amazing!"
    new "B:sis: Tudo bem?"

    # say L1968 sis
    old "(Amazing?) Hmm ok, thank you!"
    new "B:pla: Definitivamente, ela é incrível!"

    # say L1969 sis
    old "Does she like the products."
    new "Ela parecia muito interessada nos novos produtos."

    # say L1970 pla
    old "She seemed to be very interested about the new products."
    new "Ela parecia estar muito interessada nos novos produtos."

    # say L1971 sis
    old "That's fascinating."
    new "T(sis|tu|diz): Isso é fascinante."

    # say L1972 sis
    old "Hope you are doing your part, so she definitely keeps her business with us."
    new "T(sis|tu|diz): Espero que estejas a fazer a tua parte, para que ela continue definitivamente a fazer negócios connosco. A:sis: Além disso, preciso que te prepares, temos mais produtos a caminho."

    # say L1974 sis
    old "Besides, I need you to get prepared, we have more products coming."
    new "B: Irmã: Espero que estejas a fazer a tua parte, para que ela continue a fazer negócios connosco."

    # say L1976 sis
    old "Yes, we need to work hard."
    new "B:sis: Além disso, preciso que te prepares, temos mais produtos a chegar."

    # say L1977 pla
    old "Uhh, let's see what happens."
    new "B:sis: Sim, precisamos trabalhar duro."

    # say L1978 sis
    old "You can be sure it's worth."
    new "B:pla: Uhh, vamos ver o que acontece."

    # say L2004 sis
    old "Yep, the pool. Summer is coming, bikinis are amazing so I need all your effort today."
    new "B:pla: Para a p-piscina?"

    # say L2005 sis
    old "We are selling new things and people are crazy with the new summer alternatives."
    new "B:sis: Sim, a piscina. A primavera está a chegar, os biquínis são incríveis, por isso preciso de todo o teu esforço hoje."

    # say L2007 sis
    old "Do you need some help before we start?"
    new "B: Irmã: Estamos a vender coisas novas e as pessoas estão loucas com as novas alternativas de verão."

    # say L2009 sis
    old "I mean do you want me to suck your dick, because at the pool it's not that easy. "
    new "B: Irmã: Precisas de ajuda antes de começarmos?"

    # say L2010 sis
    old "And don't beat around the bush!"
    new "E não te escondas atrás de rodeios!"

    # say L2016 pla
    old "I-I am not sure."
    new "B:sis: E não te escondas!"

    # say L2017 sis
    old "Do you want it or not?"
    new "B:pla: N-Não tenho a certeza."

    # say L2019 sis
    old "We don't have time to lose I will take it as a yes..."
    new "B: Irmã: Queres ou não?"

    # say L2020 sis
    old "I'm going to make you cum fast..."
    new "B: Irmã: Não temos tempo a perder, vou considerar isso como um sim..."

    # say L2044 sis
    old "I hope you're better now, let's do it!"
    new "B: Irmã: Vou fazer-te gozar depressa..."

    # say L2052 sis
    old "Oh, I will love the pics today, look at the sun, the pool, everything in its right place."
    new "B:sis: Espero que estejas melhor agora, vamos lá!"

    # say L2053 pla
    old "Yeah I couldn't ask for a better light and place."
    new "B:sis: Oh, vou adorar as fotos hoje, olha o sol, a piscina, tudo no seu lugar."

    # say L2054 sis
    old "Don't lose more time, let's start."
    new "B:pla: Sim, não podia pedir melhor luz e lugar."

    # say L2055 pla
    old "You're right. Stay right there, let me start with a full body!"
    new "B:sis: Não percas mais tempo, vamos começar."

    # say L2056 sis
    old "Ok, I will stay like this."
    new "B:pla: Tens razão. Fica aí, vou começar com o corpo inteiro!"

    # say L2057 pla
    old "I think you should look to the right, to get a better perspective..."
    new "Bem, tu és o nerd..."

    # say L2058 sis
    old "Alright, you are the nerd..."
    new "B:pla: Acho que deves olhar para a direita, para teres uma melhor perspetiva..."

    # say L2073 pla
    old "Wonderful, the light is perfect, your hair looks very bright."
    new "Ótimo, a luz está perfeita, o teu cabelo está muito brilhante."

    # say L2074 sis
    old "Perfect, make sure I look sexy."
    new "B:pla: Ótimo, a luz está perfeita, o teu cabelo está muito brilhante."

    # say L2102 pla
    old "Got it!"
    new "T(tu|diz): Entendido!"

    # say L2111 pla
    old "It would be more interesting if we take advantage of some elements of the place."
    new "B:pla: Entendido!"

    # say L2112 sis
    old "Hmmm, what do you think about the pool?"
    new "B:pla: Seria mais interessante se aproveitássemos alguns elementos do lugar."

    # say L2113 pla
    old "I don't think so, we need the clothes dry."
    new "B:sis: Hmm, o que achas da piscina?"

    # say L2114 pla
    old "You now what? Go to the chair, something casual, let's use those glasses you have."
    new "B:pla: Não acho, precisamos que a roupa seque."

    # say L2115 sis
    old "Yes, just like that, that's perfect."
    new "B:pla: Sabes o quê? Vai para a cadeira, algo casual, vamos usar aqueles óculos que tens."

    # say L2126 pla
    old "Perfect, try to hold the glasses with your hands."
    new "B:sis: Sim, assim mesmo, perfeito."

    # say L2127 sis
    old "Try to show my boobs a bit more, I want them to stand out."
    new "B:pla: Perfeito, tenta segurar os óculos com as mãos."

    # say L2128 pla
    old "I think this is the pic you're looking for."
    new "B: Irmã: Tenta mostrar um pouco mais as minhas mamas, quero que se destaquem."

    # say L2153 pla
    old "Ok, next photo..."
    new "B:pla: Acho que esta é a foto que estás à procura."

    # say L2161 pla
    old "I have a great idea, let's show a different emotion."
    new "T: Tenho uma grande ideia, vamos mostrar uma emoção diferente."

    # say L2162 sis
    old "I am listening..."
    new "B:pla: Tenho uma ideia genial, vamos mostrar uma emoção diferente."

    # say L2163 pla
    old "Let's take advantage of the pool but I don't want the same poses we already tried before, I want to do something unexpected."
    new "B:sis: Estou a ouvir..."

    # say L2164 pla
    old "Hmm, turn around and try to look at me, but close your eyes..."
    new "B:pla: Vamos aproveitar a piscina, mas não quero as mesmas posições que já tentámos antes, quero fazer algo inesperado."

    # say L2165 sis
    old "With my eyes closed? Alright, let me try it."
    new "B:pla: Hmm, vira-te e tenta olhar para mim, mas fecha os olhos..."

    # say L2176 pla
    old "keep that smile, do not change your face."
    new "T(pla|tu|say): mantém esse sorriso, não mude a tua expressão."

    # say L2177 pla
    old "That's a plot twist."
    new "B: pla: mantém esse sorriso, não mude a tua expressão."

    # say L2178 pla
    old "I like it."
    new "T: Gosto disso."

    # say L2202 pla
    old "Ok, I think that's it."
    new "B:pla: Gosto disto."

    # say L2214 pla
    old "Ok... Here they are."
    new "A:pla: Não sei o que se passa hoje, não estão suficientemente nítidos."

    # say L2247 pla
    old "I don't know what's happening today, they are not sharp enough."
    new "B:pla: Ok... Aqui estão."

    # say L2251 sis
    old "I need you to put more effort, we can't waste time like today."
    new "B:pla: Não sei o que está a acontecer hoje, não estão afiados o suficiente."

    # say L2253 sis
    old "Hmm, look for me to repeat the sesion again..."
    new "B: Irmã: Preciso que ponhas mais empenho, não podemos desperdiçar tempo como hoje."

    # say L2276 sis
    old "I like them, but there's something not working."
    new "B:sis: Hmm, vê se eu repito a sessão outra vez..."

    # say L2277 pla
    old "What's not working? I can check, so you like them more."
    new "B:sis: Gosto deles, mas há algo que não está a funcionar."

    # say L2278 sis
    old "Oh no, it's not you, I need some sunbathing."
    new "B:pla: O que é que não está a funcionar? Posso verificar, para tu gostares mais."

    # say L2279 sis
    old "Don't you think so?"
    new "B:sis: Oh não, não és tu, preciso de tomar um banho de sol."

    # say L2280 pla
    old "I think you look great."
    new "B:sis: Não achas?"

    # say L2281 sis
    old "Hehehe of course... "
    new "B:pla: Acho que tu estás ótima."

    # say L2282 sis
    old "Anyway, I'm going work on the website, have a good one."
    new "B:ris: Hehehe claro..."

    # say L2310 sis
    old "Glad that you came, quite on time to apply my sunscreen, can you help me?"
    new "B: Irmã: De qualquer forma, vou trabalhar no site, boa sorte."

    # say L2312 sis
    old "I can show you how to do it... Let's start with my boobs."
    new "B:sis: Fico contente que tenhas vindo, bem a tempo de aplicar o meu protetor solar, podes ajudar-me?"

    # say L2313 pla
    old "Your... Wh- What?"
    new "B:sis: Posso mostrar-te como fazer... Vamos começar com os meus peitos."

    # say L2314 sis
    old "My boobs, I need to show the bikinis, so my boobs are important. And you see them all the time in the photoshoots."
    new "B:pla: Tu... O quê?"

    # say L2315 pla
    old "Hmmm... Alright..."
    new "B: Irmã: Os meus peitos, preciso mostrar os biquínis, por isso os meus peitos são importantes. E tu vês-os sempre nas sessões fotográficas."

    # say L2319 pla
    old "Wow! What are you doing?"
    new "B:pla: Hmmm... Tudo bem..."

    # say L2320 sis
    old "Taking off my bra, you weren't pretending to tan my breasts with it on, did you?"
    new "T(sis|tu|diz): A tirar o sutiã, não estavas a fingir que me estavas a bronzear os seios com ele posto, pois não?"

    # say L2321 pla
    old "So you want me to apply the sunscreen like thi-"
    new "B: Irmã: A tirar o sutiã, não estavas a fingir que me estavas a bronzear os seios com ele posto, pois não?"

    # say L2322 sis
    old "Oh, shut up... You and I both know you're dying to touch them..."
    new "B:pla: Então queres que eu aplique o protector solar assim-"

    # say L2323 sis
    old "And I just want a good massage and sunbathe to get a tan."
    new "B:sis: Oh, cala-te... Tu e eu sabemos que estás a morrer de vontade de os tocar..."

    # say L2325 sis
    old "So stop acting like an idiot and play with my babies..."
    new "E eu só quero uma boa massagem e tomar sol para ficar morena."

    # say L2339 pla
    old "I-I don't know what you mea-"
    new "B:sis: Não tentes esconder de mim... Eu sei que já estás excitado."

    # say L2340 sis
    old "Let me give you a clue... I've heard cum is a great treatment for the skin, so I wanted to test it on my boobs."
    new "B:pla: N-Não sei do que estás a falar..."

    # say L2341 pla
    old "W-What!?... "
    new "B:sis: Deixa-me dar-te uma pista... Ouvi dizer que o sêmen é um ótimo tratamento para a pele, por isso quis testá-lo nas minhas mamas."

    # say L2342 sis
    old "Shut up and come here..."
    new "B:pla: Q-Que!?..."

    # say L2358 sis
    old "Did you enjoy it?"
    new "Cala-te e vem aqui..."

    # say L2359 pla
    old "Yeah!"
    new "A:sis: Adorava ter este tratamento de pele com mais frequência."

    # say L2360 sis
    old "I would love to have this skin care therapy more often."
    new "B:pla: Sim!"

    # say L2361 sis
    old "I'll enjoy the sun, thank you."
    new "B:sis: Adorava ter este tratamento de cuidados de pele mais vezes."

    # say L2362 pla
    old "You're welcome, see you later!"
    new "B:sis: Vou aproveitar o sol, obrigada."

    # say L2385 sis
    old "Oh, you came at the right time."
    new "B:pla: De nada, até mais!"

    # say L2387 sis
    old "Fortunately there is good news, I want to tell you something to cheer you up a bit."
    new "B: Irmã: Oh, tu chegaste na altura certa."

    # say L2389 sis
    old "The bikini session was great, Anastasia ordered again."
    new "B: Irmã: Afortunadamente há boas notícias, quero contar-te algo para te animar um pouco."

    # say L2391 sis
    old "I need you to be nice with her again, so she feels comfortable."
    new "B:sis: A sessão de biquíni foi ótima, a Anastasia pediu de novo."

    # say L2392 pla
    old "Ok, I will."
    new "B:sis: Preciso que sejas simpático com ela de novo, para que ela se sinta confortável."

    # say L2393 sis
    old "You already know her place, remember, that everything you do is really important."
    new "B:pla: Ok, eu farei."

    # say L2401 pla
    old "Good morning Mrs."
    new "B:sis: Tu já sabes onde ela mora, lembra-te que tudo o que fazes é muito importante."

    # say L2402 ana
    old "Oh what a nice surprise, It's my favorite delivery boy!"
    new "B:pla: Bom dia, Sra."

    # say L2403 pla
    old "Hehehe, Thank you, I am glad to see you too."
    new "B:ana: Oh que surpresa agradável, é o meu carteiro favorito!"

    # say L2404 pla
    old "Here you are!"
    new "B:pla: Hehehe, Obrigado, também fico contente por te ver."

    # say L2409 ana
    old "Thank you, you're so kind."
    new "B:pla: Aqui está!"

    # say L2410 pla
    old "I hope you enjoy your purchase, have a nice day!"
    new "B:ana: Obrigada, és tão simpático."

    # say L2411 ana
    old "Oh, are you planning on leaving already? Actually I was considering to ask you for a big favor and I have nobody else to help me."
    new "B:pla: Espero que gostes da tua compra, tenha um bom dia!"

    # say L2412 ana
    old "I think since you're a man you could help me."
    new "B:ana: Oh, estás a pensar ir-te embora já? Na verdade, estava a considerar pedir-te um grande favor e não tenho mais ninguém que me possa ajudar."

    # say L2413 pla
    old "(I have to make her feel comfortable, she's our best client.)"
    new "B:ana: Acho que como és homem podes ajudar-me."

    # say L2414 ana
    old "It won't take you too long, I promise."
    new "T: Não vai demorar muito, prometo."

    # say L2415 pla
    old "Oh, sure, how can I help you?"
    new "B:ana: Não vai demorar muito, prometo."

    # say L2416 ana
    old "Please come in."
    new "B:pla: Oh, claro, como posso ajudar-te?"

    # say L2424 ana
    old "Just wait a second, I will be right back."
    new "B:ana: Por favor, entra."

    # say L2438 pla
    old "(Wow, Wow!)"
    new "B:ana: Espera um segundo, já volto."

    # say L2439 ana
    old "I needed a second opinion, and I just thought you could help."
    new "B: pla: (Uau, Uau!)"

    # say L2440 ana
    old "Please be honest, do you like it?"
    new "T(ana|tu|say): Por favor, sê sincero, gostas?"

    # say L2441 pla
    old "Gulp, You look..."
    new "B:ana: Sê sincera, gostas disto?"

    # say L2443 pla
    old "No, no, no, of course not, You look... A-amazing."
    new "B:pla: Engasga, Tu pareces..."

    # say L2445 pla
    old "Y-Yes... I- I am being really honest."
    new "B: Não, não, não, claro que não, Tu pareces... A-Amazing."

    # say L2448 pla
    old "(Oh shit... I'm getting hard.)"
    new "B: pla: S-Sim... E-Estou a ser realmente honesto."

    # say L2449 ana
    old "Wow dear, what you got in there?"
    new "B:pla: (Oh shit... Estou a ficar excitado.)"

    # say L2450 pla
    old "I'm sorry, I didn't mean to-"
    new "B:ana: Que querido, o que tens aí?"

    # say L2451 ana
    old "Ohh, You are very sweet, I apologize for this, I didn't mean to make you feel uncomfortable."
    new "T(ana|tu|diz): Ohh, tu és muito doce, peço desculpa por isso, não quis fazer-te sentir desconfortável."

    # say L2453 pla
    old "I-I am sorry, I-I... Just should leave."
    new "B:ana: Ohh, Tu és muito querido, peço desculpa por isso, não quis fazer-te sentir desconfortável."

    # say L2454 ana
    old "Oh no, please let me apologize correctly, you can't leave like that."
    new "B:pla: I-I desculpe, I-I... Devo ir."

    # say L2456 ana
    old "I think you deserve a bigger tip this time due to this big inconvenience."
    new "B:ana: Oh não, por favor, deixa-me pedir desculpa corretamente, tu não podes ir-te embora assim."

    # say L2459 ana
    old "How about if you just relax a little bit on the couch and let me fix this with my own hands. "
    new "B:ana: Acho que mereces uma gorjeta maior desta vez devido a este grande inconveniente."

    # say L2466 ana
    old "Please, relax and let me compensate for the situation, just close your eyes and enjoy."
    new "A:ana: Espero que tenhas gostado..."

    # say L2478 ana
    old "I hope you liked it..."
    new "B:ana: Por favor, relaxa e deixa-me compensar a situação, só fecha os olhos e desfruta."

    # say L2479 pla
    old "Uhh... Y-yes, thank you"
    new "B:ana: Espero que tenhas gostado..."

    # say L2480 ana
    old "Alright sweetie, thanks for your help, it was very clear to me that this bikini suits me very well... I hope to see you in my next delivery."
    new "B:pla: Uhh... S-sim, obrigado"

    # say L2481 pla
    old "(Wow, I'm starting to love this job)"
    new "B:ana: Obrigada, querida, a tua ajuda foi muito clara, percebi que este biquíni me fica mesmo bem... Espero ver-te na minha próxima entrega."

    # say L2482 pla
    old "Of course, I'll bring your next purchase."
    new "B: pla: (Que fixe, estou a começar a gostar deste trabalho)"

    # say L2483 ana
    old "That sounds great..."
    new "Olá, tu já voltaste."

    # say L2492 sis
    old "Hey, you are back."
    new "B:ana: Isso soa ótimo... T(sis|tu|diz): Ei, tu já voltaste. A:pla: Pois é."

    # say L2493 pla
    old "Yep."
    new "Sim, tudo correu bem."

    # say L2494 sis
    old "So? Everything went alright?"
    new "Foi... Maravilhoso."

    # say L2495 pla
    old "It was... Wonderful."
    new "B:sis: Então? Tudo correu bem?"

    # say L2496 sis
    old "(Wonderful?) Hmm, ok thanks for your help."
    new "B:pla: Foi... Maravilhoso."

    # say L2497 sis
    old "Did she like it?"
    new "Sim, ela adorou."

    # say L2498 pla
    old "Yeah, she loved it."
    new "T: Sim, ela adorou."

    # say L2499 sis
    old "How are you so sure about it?"
    new "B:pla: Sim, ela adorou."

    # say L2500 pla
    old "Well... Is the second time she purchases, so she liked the first one."
    new "B:sis: Como é que estás tão certo disso?"

    # say L2501 sis
    old "Ok... I'll let you know once we are ready for the next photography session."
    new "B:pla: Bem... É a segunda vez que ela compra, então gostou do primeiro."

    # say L2502 pla
    old "I'll look forward to it."
    new "T(pla|tu|say): Vou esperar por isso."

    # say L2529 sis
    old "Uhh... I am so horny, I'll need more."
    new "B:pla: Estou ansioso por isso."

    # say L2531 pla
    old "(Oh shit... She saw me!)"
    new "B:sis: Uhh... Estou tão excitada, vou precisar de mais."

    # say L2539 sis
    old "I know you have been there for a while."
    new "Desculpa... Eu-Eu estava apenas-"

    # say L2540 pla
    old "Sorry... I-I was just-"
    new "B:sis: Eu sei que já estás aqui há algum tempo."

    # say L2541 sis
    old "It's ok dummy! I think it is time to get paid back."
    new "B:pla: Desculpa... Eu-Eu estava só-"

    # say L2543 sis
    old "I mean, I need you to pay me back, I know that you have more than enough to give."
    new "B: Irmã: Não te preocupes, parvalhão! Acho que é altura de me pagares."

    # say L2545 sis
    old "Come here, let me suck that big dick."
    new "B: Isto é, preciso que me pagues, sei que tens mais do que o suficiente para dar."

    # say L2550 sis
    old "Grab my head and fuck my mouth!"
    new "B: Irmã: Vem aqui, deixa-me chupar esse pau grande."

    # say L2560 sis
    old "Oh, shit. I can't handle it anymore... Want you to fuck me, I need you inside of me now."
    new "B: Irmã: Segura a minha cabeça e fode a minha boca!"

    # say L2580 sis
    old "Ugh, I got really tired, that was pretty intense."
    new "B:sis: Wow, tu foste incrível!"

    # say L2582 sis
    old "Anyway, I'm gonna need some of your skills tomorrow too."
    new "B: Irmã: Ugh, fiquei mesmo cansada, isso foi bem intenso."

    # say L2584 sis
    old "Hahaha, I'm talking about the photshoot, dummy. I'm preparing a new one, so, I count on you."
    new "B:sis: De qualquer forma, vou precisar das tuas habilidades amanhã também."

    # say L2585 pla
    old "Sure, I'll be ready."
    new "B:sis: Hahaha, estou a falar da sessão fotográfica, parvalhão. Estou a preparar uma nova, por isso, conto contigo."

    # say L2586 sis
    old "Now leave me alone. I just want to rest..."
    new "B:pla: Claro, estou pronta."

    # say L2587 pla
    old "Hmm, alright... See you later."
    new "B:sis: Agora deixa-me em paz. Só quero descansar..."

    # say L2609 sis
    old "Hey, did you sleep well?"
    new "B:pla: Hmm, bem... Até logo. T(sis|tu|say): Ei, dormiste bem? A:pla: Sim, bastante bem!"

    # say L2610 pla
    old "Yeah, pretty well!"
    new "B:sis: Ei, dormiste bem?"

    # say L2611 sis
    old "Good, that means we're gonna rock today!"
    new "B:pla: Sim, bastante bem!"

    # say L2644 sis
    old "I will be at the pool, don't be late."
    new "B:sis: Ótimo, isso significa que vamos arrasar hoje!"

    # say L2645 pla
    old "I'm going to pick up the camera and see you there."
    new "B:sis: Vou estar na piscina, não cheguem tarde."

    # say L2652 sis
    old "This is the newest collection, what do you think?"
    new "B:pla: Vou buscar a câmara e lá estarei."

    # say L2653 pla
    old "Really? It's pretty nice!"
    new "B:sis: Esta é a nova coleção, o que achas?"

    # say L2654 pla
    old "I have some ideas for today."
    new "B:pla: Mesmo? É bastante agradável!"

    # say L2655 sis
    old "Awesome, what are we waiting for?"
    new "B:pla: Tenho algumas ideias para hoje."

    # say L2656 pla
    old "Ok, let's start with you standing up in front of the pool for a full body one."
    new "Ok, vamos começar com tu a ficar de pé à frente da piscina para uma foto do corpo inteiro."

    # say L2669 sis
    old "Ok, do I look good like this?"
    new "B:pla: Ok, vamos começar com tu a ficar de pé à frente da piscina para uma foto de corpo inteiro."

    # say L2670 pla
    old "Yeah, keep your hand there, do not move... It looks more fancy."
    new "A:pla: Agora quero experimentar algo especial."

    # say L2706 pla
    old "Now I want try something special."
    new "B:pla: Sim, mantém a mão aí, não te mexas... Fica mais sofisticado."

    # say L2707 sis
    old "Tell me what to do."
    new "B:pla: Agora quero experimentar algo especial."

    # say L2708 pla
    old "Please get on your knees, looking at me very very enticingly and to move your shoulders a bit ahead of your body..."
    new "Gostas disto assim?"

    # say L2719 sis
    old "Do you like it this way?"
    new "B:pla: Por favor, ajoelha-te e olha para mim de uma forma muito muito sedutora, movendo um pouco os ombros à frente do corpo..."

    # say L2745 pla
    old "Oh boy, this is by far one of the best ones."
    new "B:sis: Gostas assim?"

    # say L2753 pla
    old "Hmm I think would be great another one on the floor, but you turning around."
    new "B:pla: Oh my, este é sem dúvida um dos melhores."

    # say L2754 sis
    old "Alright, but what kind of position should I do?"
    new "B:pla: Hmm acho que seria ótimo outro no chão, mas tu virando-te."

    # say L2755 pla
    old "Let's see if we can make it a bit hotter..."
    new "B:sis: Tudo bem, mas que tipo de posição devo fazer?"

    # say L2756 pla
    old "Try to spread a bit your legs... And look at the camera. Also lift up your butt a bit more but try to keep your breast lower."
    new "B:pla: Vamos ver se conseguimos tornar isto um pouco mais quente..."

    # say L2757 sis
    old "Hmm, let me try."
    new "B:pla: Tenta afastar um pouco as pernas... E olha para a câmara. Também levanta um pouco o rabo, mas tenta manter os seios mais baixos."

    # say L2768 pla
    old "Oh perfect! let me take the picture."
    new "B:sis: Hmm, deixa-me tentar."

    # say L2792 pla
    old "This looks amazing."
    new "B:pla: Oh perfeito! Deixa-me tirar a foto."

    # say L2799 pla
    old "Ok, I really think we are done..."
    new "B: pla: Isto parece incrível."

    # say L2801 sis
    old "Really? Yayyy! let me see them."
    new "B:pla: Ok, acho que já estamos feitos..."

    # say L2802 pla
    old "Of course..."
    new "B:sis: Mesmo? Yayyy! Deixa-me ver."

    # say L2839 pla
    old "I do not know what's happening today, they are not sharp enough."
    new "B:pla: Claro..."

    # say L2857 pla
    old "Hmm, again with that..."
    new "B: pla: Não sei o que está a acontecer hoje, não estão afiados o suficiente."

    # say L2858 sis
    old "Hahaha, You did it well nerd."
    new "B:pla: Hmm, outra vez com isso..."

    # say L2867 sis
    old "Anyway, I'm going to upload more material, I need to sell."
    new "B: Irmã: Hahaha, tu fizeste bem, nerd."

    # say L2869 sis
    old "Oh by the way... I'm considering bringing some sexy friends so we can make pics with new models."
    new "B:sis: De qualquer forma, vou carregar mais material, preciso vender."

    # say L2870 sis
    old "It would help us get everybody's attention and it means more sales, more money."
    new "B: Irmã: Ah, a propósito... Estou a pensar em trazer algumas amigas sexy para fazermos fotos com novos modelos."

    # say L2872 sis
    old "Sure, you are gonna like it!"
    new "B: Irmã: Isso ajudaria a chamar a atenção de todos e significa mais vendas, mais dinheiro."

    # say L2873 sis
    old "Well time is money, see you around..."
    new "B:sis: Claro, vais gostar!"

    # say L2875 pla
    old "New models, uh?"
    new "B:sis: O tempo é dinheiro, até à vista..."

    # say L2898 sis
    old "Well you're on time, wanna have fun? I need help with my sunscreen again."
    new "B:pla: Novos modelos, hã?"

    # say L2900 sis
    old "Let's start with my butt."
    new "B: Irmã: Bem, tu estás a horas, queres divertir-te? Preciso de ajuda com o meu protetor solar outra vez."

    # say L2904 sis
    old "I love the sun, it feels great and makes me look better, don't you think."
    new "B: Irmã: Vamos começar com o meu rabo."

    # say L2906 sis
    old "Please pay attention, I need you to spread it aaaaall over my butt while giving a slow massage."
    new "B: Irmã: Adoro o sol, faz-me sentir ótima e fico com melhor aspeto, não achas?"

    # say L2924 sis
    old "You know what? Let's fuck right now!"
    new "B: Irmã: Presta atenção, preciso que espalhes tudinho no meu rabo enquanto me dás uma massagem devagar."

    # say L2925 pla
    old "Wha-? But... Someone could see us."
    new "B:sis: Sabes o quê? Vamos fazer sexo agora!"

    # say L2926 sis
    old "People are busy, nobody is gonna come, I already checked."
    new "T(sis|tu|diz): As pessoas estão ocupadas, ninguém vai aparecer, já verifiquei."

    # say L2927 sis
    old "Last time you weren't so worried about that!"
    new "B: Irmã: As pessoas estão ocupadas, ninguém vai vir, já verifiquei."

    # say L2929 sis
    old "Don't worry about the people, think just about my ass"
    new "B: Irmã: Da última vez não te preocupavas tanto com isso!"

    # say L2941 sis
    old "I really liked it, you are by far much better than my toy."
    new "B: Irmã: Não te preocupes com as pessoas, pensa só no meu rabo."

    # say L2942 sis
    old "It's like a super toy, delicious!"
    new "B: Isto foi incrível, és muito melhor do que o meu brinquedo."

    # say L2943 sis
    old "Hope you liked it too, gonna take a shower."
    new "B: Irmã: É como um brinquedo super, delicioso!"

    # say L2944 sis
    old "Bye now."
    new "B:sis: Espero que tenhas gostado, vou tomar um duche. T(sis|tu|diz): Adeus. A:pla: Pois, e tu?"

    # say L2968 pla
    old "Yep, how bout you?"
    new "B:sis: Adeus. T(pla|tu|say): Yep, e tu? A:sis: Incrível, o sol faz-me sentir bem."

    # say L2969 sis
    old "Amazing, sun makes me feel good."
    new "B:pla: Claro, e tu?"

    # say L2970 sis
    old "I want to share some news to you."
    new "B: Irmã: Incrível, o sol faz-me sentir bem."

    # say L2972 sis
    old "Sure, meet me in my bedroom."
    new "B:sis: Quero partilhar contigo algumas novidades."

    # say L2973 pla
    old "Coming."
    new "Bem, sendo honesta, o negócio está a correr bastante bem."

    # say L2980 sis
    old "Well, being honest, the business is running pretty good."
    new "B:pla: A chegar."

    # say L2981 sis
    old "Part of this success has been your help with the website, the pics, and your effort."
    new "B:sis: Bem, sendo honesta, o negócio está a correr bastante bem."

    # say L2982 sis
    old "I know you have been more than the 'nerd' with the website, but also the one who delivers, photographer, market couch, you name it."
    new "B:sis: Parte deste sucesso tem sido a tua ajuda com o site, as fotos e o teu esforço."

    # say L2983 pla
    old "Well, that is not true, but thanks."
    new "B:sis: Eu sei que tu foste mais do que o 'nerd' do site, mas também o entregador, fotógrafo, conselheiro de mercado, enfim."

    # say L2984 sis
    old "I think it would be fair if we split the incomes instead of just giving you part of it, because you are more like my partner."
    new "B:pla: Bem, isso não é verdade, mas obrigado."

    # say L2985 pla
    old "Wow... I am glad to hear that."
    new "B:sis: Acho que seria justo dividirmos as receitas em vez de te dar apenas uma parte, porque tu és mais como minha parceira."

    # say L2986 sis
    old "To be honest, there is more you should know."
    new "B:pla: Uau... Fico contente em ouvir isso."

    # say L2987 sis
    old "This is just part of the incomes, there is something you should be more excited about."
    new "B:sis: A ser sincera, há mais que deves saber."

    # say L2989 sis
    old "Lay on the bed, I will show you."
    new "B: Isto é apenas uma parte dos rendimentos, há algo de que deves ficar mais entusiasmada."

    # say L2992 sis
    old "Let me give you something money can't buy."
    new "B: Irmã: Deita-te na cama, vou mostrar-te."

    # say L3001 sis
    old "Ohh, I love this taste..."
    new "B: Irmã: Deixa-me dar-te algo que o dinheiro não pode comprar."

    # say L3002 sis
    old "Now, let's fuck! I'm going to ride you..."
    new "B:sis: Ohh, adoro este sabor..."

    # say L3015 sis
    old "That was intense... What a mess we've made."
    new "B:sis: Agora, vamos foder! Vou cavalgar-te..."

    # say L3022 pla
    old "Hell yeah."
    new "B:sis: Isso foi intenso... Que confusão fizemos."

    # say L3023 sis
    old "I think this is how a very successful partnership starts!"
    new "B:pla: Claro que sim."

    # say L3024 sis
    old "I appreciate your hard work especially in this extra activity."
    new "B: Isto é como uma parceria muito bem-sucedida começa!"

    # say L3025 sis
    old "From now you can ask anything from me. I mean we are partners."
    new "B: Irmã: Aprecio o teu trabalho duro, especialmente nesta atividade extra."

    # say L3061 sis
    old "I asked you to come to my bedroom in the afternoons, dummy..."
    new "B:sis: Adoro o teu pénis, Nerd!"

    # say L3063 pla
    old "Oh, my bad. I will be in the garage studying then."
    new "B:sis: Pedi-te para vires ao meu quarto à tarde, parvalhão..."

    # say L3068 sis
    old "Studying in the garage?... (Hmm, I wonder what he's really doing in there.)"
    new "B:pla: Oh, desculpa. Vou estar a estudar na garagem."

    # say L3098 pla
    old "Oh... sorry. I was just thinking of something..."
    new "Oh... desculpa. Estava só a pensar em algo..."


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/janAnimations.rpy
translate portuguese strings:

    # say L37 pla
    old "(Oh shit, I'm dead.)"
    new "Oh merda, estou morto."

    # say L47 pla
    old "Wow! Are they... Having sex?"
    new "B:pla: (Oh shit, estou morto.)"

    # say L95 pla
    old "I should leave... I don't want to get caught peeping."
    new "B:pla: Uau! Eles estão... a fazer sexo?"

    # say L144 pla
    old "(Damn, she's so tight! Oh shit! I feel like... I am going to...)"
    new "B:pla: Devo ir... Não quero ser apanhado a espreitar."

    # say L148 mo2
    old "Fuck, baby. This new strap-on has a good lubrication system. It feels like a real cumshot... And it's so warm."
    new "B:pla: (Merda, ela é tão apertada! Oh, carago! Sinto-me... Vou...)"

    # say L149 mo2
    old "Mmm. Let me rest a little..."
    new "B:mo2: Merda, bebé. Esta nova cinta peniana tem um bom sistema de lubrificação. Sente-se como um ejacular real... E está tão quente."

    # say L150 pla
    old "(Alright. I should get out of here.)"
    new "B:mo2: Mmm. Deixa-me descansar um pouco..."

    # say L165 pla
    old "(She's so tight! Oh shit, I feel like... I am going to...)"
    new "B:pla: (Tudo bem. Devo sair daqui.)"

    # say L169 mo2
    old "Mmm, still so good... Let me rest up, baby..."
    new "B: (Ela é tão apertada! Ah, merda, sinto que... vou...)"

    # say L170 pla
    old "(Ok, I should get out...)"
    new "B:mo2: Mmm, ainda tão bom... Deixa-me descansar, querido..."

    # say L188 mo2
    old "So nice to see like a little rat on the floor..."
    new "A:mo2: Estás a ficar excitado de novo?"

    # say L190 mo2
    old "Are getting horny again?"
    new "B:mo2: Que bom ver uma ratinha no chão..."

    # say L191 mo2
    old "You're so gross... Getting horny just by sucking my foot."
    new "B:mo2: Estás a ficar excitado de novo?"

    # say L195 mo2
    old "Yeah! This is what you like..."
    new "B:mo2: Tu és tão nojento... A ficar excitado só de chupar o meu pé."

    # say L197 mo2
    old "I see you want more and more... You are a disgusting needy bastard."
    new "B:mo2: Sim! É isto que tu gostas..."

    # say L202 mo2
    old "That's what you deserve for being a fucking pervert!"
    new "B:mo2: Vejo que queres mais e mais... Tu és um bastardo nojento e necessitado."

    # say L204 mo2
    old "I'm going to make you suck my foot! Every day you little rat!"
    new "B:mo2: É o que tu mereces por seres um pervertido da merda!"

    # say L228 mo2
    old "That's it. Enough!"
    new "B:mo2: Vou fazer-te lamber o meu pé! Todos os dias, tu rato imundo!"

    # say L230 mo2
    old "Fuck! This is gross... Now I have my foot full of your disgusting slime."
    new "B:mo2: Chega. Basta!"

    # say L231 mo2
    old "I hope you've learned your lesson and don't go back to being perverted with your disgusting hardon."
    new "B:mo2: Merda! Isto é nojento... Agora tenho o pé cheio do teu nojento muco."

    # say L232 mo2
    old "I need to clean myself from all this bullcrap..."
    new "B:mo2: Espero que tenhas aprendido a lição e não voltes a ser pervertido com a tua ereção nojenta."

    # say L245 mo2
    old "Is this what you like, you little pervert? Do you like that your boss treats you like a cockroach?"
    new "B:mo2: Preciso de me limpar de toda esta merda..."

    # say L246 mo2
    old "Does that turn you on, you fucking bastard?"
    new "B:mo2: É isto que tu gostas, tu pequeno pervertido? Gostas que o teu chefe te trate como uma barata?"

    # say L253 mo2
    old "I ASKED YOU. ANSWER YOUR BOSS!"
    new "B:mo2: Isso te excita, seu merda?"

    # say L254 pla
    old "Y- yes."
    new "B:mo2: EU PERGUNTEI A TI. RESPONDE AO TEU CHEFE!"

    # say L255 mo2
    old "Ohh poor baby, he thinks I'm doing this to please him..."
    new "B: pla: Y- sim."

    # say L259 mo2
    old "I'm doing this to torture you ..."
    new "B:mo2: Ohh pobre bebé, ele pensa que estou a fazer isto para lhe agradar..."

    # say L260 mo2
    old "Because a pervert like you only thinks with the cock!"
    new "B:mo2: Estou a fazer isto para te torturar..."

    # say L261 mo2
    old "So, I won't make you cum until you get humillied, and accept you are a cockroach and I am your master."
    new "B:mo2: Porque um pervertido como tu só pensa com o pénis!"

    # say L289 mo2
    old "Well, I'm not gonna let you cum."
    new "B:mo2: Ohh, estás perto?"

    # say L293 mo2
    old "If you want to cum, you have to beg for it."
    new "B:mo2: Bem, não vou deixar-te gozar."

    # say L294 pla
    old "W- What?"
    new "B:mo2: Se quiser gozar, tens de implorar por isso."

    # say L295 mo2
    old "Yes! Beg for it!"
    new "B: pla: E-Está a brincar..."

    # say L296 pla
    old "P- please... L- let me cum..."
    new "B:mo2: Sim! Implora por isso!"

    # say L297 mo2
    old "Do you realize how pathetic that sounds?"
    new "B: pla: P- por favor... L- deixa-me gozar..."

    # say L298 mo2
    old "You are a cockroach, a disgusting and perverted cockroach ... What are you?"
    new "B:mo2: Tu percebes como isso soa patético?"

    # say L299 pla
    old "I- I am a... D- disgusting and p- perverted... Cockroach."
    new "E quem sou eu?"

    # say L303 mo2
    old "And who am I?"
    new "B:pla: I- I sou um... D- nojento e p- pervertido... Barata."

    # say L304 pla
    old "Uhh... Y- you are m- my boss..."
    new "B:mo2: E quem sou eu?"

    # say L305 mo2
    old "I AM YOUR MASTER!"
    new "B:pla: Uhh... T-tu és o meu chefe..."

    # say L306 pla
    old "Uhh... My master, y- you are m- my master."
    new "B:mo2: EU SOU O TEU MESTRE!"

    # say L307 mo2
    old "That sounds much better."
    new "B:pla: Uhh... O meu mestre, v-você é o meu mestre."

    # say L311 mo2
    old "I guess you are finally learning."
    new "Acho que finalmente estás a aprender."

    # say L312 pla
    old "Ahh..."
    new "A:mo2: Oh, estás perto de novo?"

    # say L313 mo2
    old "Oh, are you close again?"
    new "B:pla: Ahh..."

    # say L314 mo2
    old "It would be a shame if I stop again, isn't it?"
    new "B:mo2: Oh, estás perto de novo?"

    # say L315 pla
    old "No, please... Don't stop... It hurts."
    new "B:mo2: Seria uma pena se eu parasse de novo, não é?"

    # say L316 mo2
    old "Then beg your master!"
    new "B:pla: Não, por favor... Não pare... Faz mal."

    # say L317 pla
    old "Please, master... Please let me cum... I- I'm your... Slave!"
    new "B:mo2: Então, implora ao teu mestre!"

    # say L318 mo2
    old "Yes, you are..."
    new "B:pla: Por favor, mestre... Deixa-me gozar... S-Sou a tua... Escrava!"

    # say L324 mo2
    old "Ughh gross..."
    new "B:pla: Ahhhh!"

    # say L325 mo2
    old "I guess you are learning some respect here, aren't you?"
    new "B:mo2: Ughh nojento..."

    # say L327 mo2
    old "Now, clean this, it's disgusting."
    new "B:mo2: Acho que estás a aprender algum respeito aqui, não é?"

    # say L340 mo2
    old "Ohh yeah, just like that little bitch."
    new "B:mo2: Agora, limpa isto, está nojento."

    # say L342 mo2
    old "Keep licking it."
    new "B:mo2: Ohh sim, assim mesmo, pequena cadela."

    # say L346 mo2
    old "Wow, you are not completely useless after all."
    new "B:mo2: Continua a lamber."

    # say L347 mo2
    old "Ahh, finally you are doing a good job."
    new "B:mo2: Wow, tu não és completamente inútil afinal."

    # say L348 mo2
    old "I see you love licking and kissing my pussy..."
    new "B:mo2: Ahh, finalmente estás a fazer um bom trabalho."

    # say L353 mo2
    old "Ahh! Wow!"
    new "B:mo2: Vejo que adoras lamber e beijar a minha xoxota..."

    # say L354 mo2
    old "Oh yeah, keep going little bitch!"
    new "B:mo2: Ahh! Uau!"

    # say L356 mo2
    old "I'm your master and you gotta lick me until I tell you to stop."
    new "B:mo2: Oh sim, continua, putinha!"

    # say L379 mo2
    old "Don't stop, don't stop, you fucking bastard..."
    new "B:mo2: Sou o teu mestre e tu tens de me lamber até eu te dizer para parar."

    # say L381 mo2
    old "Oh gosh! Ahhhhh! Fuck!"
    new "B:mo2: Não pares, não pares, seu merda..."

    # say L390 mo2
    old "Ahh, that wasn't bad, you are finally good at something."
    new "B:mo2: Ahhhh! Merda!"

    # say L391 pla
    old "T- Thank-"
    new "B:mo2: Ahh, isso não foi mau, finalmente és bom nisso."

    # say L392 mo2
    old "Anyway, get out, I have to work."
    new "B: pla: T- Obrigado..."

    # say L397 mo2
    old "Uhhh, I think you are improving."
    new "B:mo2: De qualquer forma, sai, tenho que trabalhar."

    # say L398 mo2
    old "Maybe I could reward you for doing a good job, maybe that way you will stop being a stupid useless at everything else."
    new "B:mo2: Uhhh, acho que estás a melhorar."

    # say L399 pla
    old "W- what do you mean?"
    new "B:mo2: Talvez eu possa recompensar-te por teres feito um bom trabalho, assim talvez deixes de ser estúpido e inútil em tudo o resto."

    # say L400 mo2
    old "I'm tough but fair, and you have pleased me these last two times."
    new "B: pla: O- o que queres dizer com isso?"

    # say L401 mo2
    old "Now it's time for a reward for this little pervert. Now take out your pants."
    new "B:mo2: Sou exigente mas justo, e tu agradaste-me nestas últimas duas vezes."

    # say L402 pla
    old "Y- yes master."
    new "B:mo2: Agora é hora de uma recompensa para este pequeno pervertido. Agora tira as calças."

    # say L409 mo2
    old "What are you waiting for? I'm not going to do it for you, if you want to cum you will have to do it yourself, idiot."
    new "B:pla: S- sim, mestre."

    # say L410 pla
    old "Uhh... R- right, sorry."
    new "B:mo2: O que estás à espera? Não vou fazer isso por ti, se quiseres gozar vais ter de o fazer tu próprio, idiota."

    # say L422 mo2
    old "Hahaha, you look like a poor animal begging to cum with my foot."
    new "B:pla: Uhh... C-como quiseres."

    # say L427 mo2
    old "Oh, you're getting more excited, just like a bitch in heat."
    new "B:mo2: Hahaha, pareces um animal pobre a implorar para gozar com o meu pé."

    # say L429 mo2
    old "You are disgusting."
    new "A:mo2: Vejo que estás a acelerar, estás perto?"

    # say L433 mo2
    old "I see you're speeding up, Are you getting close?"
    new "Tu estás a acelerar, estás perto?"

    # say L434 pla
    old "Y- yes..."
    new "B:mo2: Vejo que estás a acelerar, estás perto?"

    # say L435 mo2
    old "Don't you dare come on my foot, because I kill you."
    new "B: pla: Y- sim..."

    # say L459 mo2
    old "Ohh, your cock is about to explode but you cannot cum because I haven't said you can do so..."
    new "B:mo2: Nem ouse vir a meu pé, ou eu mato-te."

    # say L460 mo2
    old "Poor boy can't cum because I won't let you do it. Unless you beg for it."
    new "... P- por favor, mestre... D- deixa-me gozar."

    # say L461 pla
    old "... P- please master... L- let me cum."
    new "B:mo2: Pobre rapaz não consegue gozar porque eu não deixo. A menos que implores."

    # say L462 mo2
    old "Hmm, I'm not sure... you should give it a better try."
    new "B:pla:... M- mestre... D- deixa-me gozar."

    # say L463 pla
    old "I- I- I am your bitch... Just a cockroach, and you are my master, p- please let this cockroach c- cum..."
    new "B:mo2: Hmm, não tenho a certeza... devias tentar melhor."

    # say L464 mo2
    old "Hmm, why do I have to be so merciful? Alright, stop moving, I'm gonna help you out."
    new "B:pla: S- S- Sou a tua cadela... Apenas uma barata, e tu és o meu mestre, p- por favor, deixa esta barata gozar..."

    # say L474 mo2
    old "One more time you see who is the Master..."
    new "B:mo2: Hmm, por que tenho de ser tão misericordioso? Tudo bem, para de te mexer, vou ajudar-te."

    # say L475 pla
    old "Y- Yes-"
    new "B:mo2: Mais uma vez vais ver quem é o Mestre..."

    # say L476 mo2
    old "You're shit... Don't talk if I don't tell you so..."
    new "B: pla: S- Sim-"

    # say L477 pla
    old "S- sorr-"
    new "B:mo2: Tu és lixo... Não fale se eu não te disser para falar..."

    # say L478 mo2
    old "Shut up!"
    new "B: pla: S- sorr-"

    # say L482 mo2
    old "Yeahh! I like when you don't talk and only listen to your master."
    new "B:mo2: Cala-te!"

    # say L484 mo2
    old "Fucking pervert!"
    new "B:mo2: Sim! Gosto quando não falas e só ouves o teu mestre."

    # say L486 mo2
    old "Shut up and follow my words... You won't talk if your master wants silence..."
    new "B:mo2: Pervertido nojento!"

    # say L490 mo2
    old "Oh look at you so vulnerable and needy."
    new "B:mo2: Cala-te e segue as minhas palavras... Não vais falar se o teu mestre quiser silêncio..."

    # say L491 mo2
    old "Are you getting close? Because you look awful."
    new "B:mo2: Olha para ti, tão vulnerável e necessitado."

    # say L492 pla
    old "Y- yes, master."
    new "B:mo2: Estás perto? Porque pareces horrível."

    # say L493 mo2
    old "Alright, don't cum until I tell you."
    new "B:pla: S- sim, mestre."

    # say L494 pla
    old "Uhh, Y- yes, m- master."
    new "B:mo2: Tudo bem, não gozes até eu mandar."

    # say L517 mo2
    old "Ask for permission if you want to cum."
    new "B:pla: Uhh, s-sim, m-mestre."

    # say L519 mo2
    old "Yes! Ask your Master for permission."
    new "Preciso de gozar... A-agora, por favor."

    # say L520 pla
    old "I need to cum... N- now, please."
    new "B:mo2: Sim! Pede permissão ao teu Mestre."

    # say L521 pla
    old "M- Maste-"
    new "B: pla: Preciso de gozar... A- agora, por favor."

    # say L522 mo2
    old "You'll come whenever I want, not when you need to..."
    new "B: pla: M- Mestre-"

    # say L523 mo2
    old "Say that you're my little bitch... Say it and I'll make you cum, maybe... Who knows if I'll change my mind."
    new "B:mo2: Vais vir sempre que eu quiser, não quando tu precisares..."

    # say L525 pla
    old "I- I'm your L- little B- bitch."
    new "B:mo2: Diz que és a minha putinha... Diz e faço-te gozar, talvez... Quem sabe se mudo de ideias."

    # say L526 pla
    old "Let me cum, please..."
    new "B:pla: S- Sou a tua p- putinha."

    # say L532 mo2
    old "Uhh... Gross."
    new "B:pla: Deixa-me gozar, por favor..."

    # say L544 mo2
    old "At least you're getting better on this."
    new "B:mo2: Uhh... Nojento."

    # say L545 mo2
    old "Oh yeah, keep licking it."
    new "B:mo2: Pelo menos estás a melhorar nisto."

    # say L547 mo2
    old "Uhh this position is pretty good!"
    new "B:mo2: Oh yeah, continua a lamber."

    # say L551 mo2
    old "Do you like it? Having your master pussy on your face?"
    new "B:mo2: Uhh esta posição está bastante boa!"

    # say L553 mo2
    old "Good boy, keep doing it, and I might reward you."
    new "B:mo2: Gostas disto? Com o meu cu na tua cara?"

    # say L557 mo2
    old "Ahh! Yess!"
    new "B:mo2: Bom rapaz, continua assim e eu posso recompensar-te."

    # say L558 mo2
    old "Oh yeah, keep going, keep going!"
    new "B:mo2: Ahh! Sim!"

    # say L584 mo2
    old "You're my bitch... Keep doing it."
    new "B:mo2: Oh sim, continua, continua!"

    # say L586 mo2
    old "Oh gosh! Ahhhh! Fuck!"
    new "B:mo2: Tu és a minha cadela... Continua assim."

    # say L593 mo2
    old "You're a bad employee but since you've done well today, I'm gonna give you something."
    new "B:mo2: Ahhhh! Merda!"

    # say L598 mo2
    old "However, you will keep licking and you will make me cum again."
    new "B:mo2: És um mau empregado, mas como te saíste bem hoje, vou dar-te algo."

    # say L611 mo2
    old "Wow, you are definitely enjoying your master's pussy, right?"
    new "B:mo2: No entanto, vais continuar a lamber e vais fazer-me gozar de novo."

    # say L612 pla
    old "Uhh I-"
    new "B:mo2: Uau, tu estás definitivamente a adorar a xoxota da tua mestra, não é?"

    # say L613 mo2
    old "Don't ever stop licking, or I'll rip your cock off!"
    new "B:pla: Uhh eu..."

    # say L618 mo2
    old "Look how much you enjoy it... Uhh? your little bastard."
    new "B:mo2: Não pares de lamber, ou arranco o teu pénis!"

    # say L619 mo2
    old "You are really a pervert, is this what you wanted? Uh?"
    new "B:mo2: Olha como tu gostas... Uhh? o teu pequeno bastardo."

    # say L621 mo2
    old "Just keep going."
    new "B:mo2: Tu és mesmo um pervertido, é isto que querias? hã?"

    # say L625 mo2
    old "Oh yeah, keep going, make me cum again!"
    new "B:mo2: Continua assim."

    # say L626 mo2
    old "Don't stop, don't stop, you little bastard."
    new "B:mo2: Oh sim, continua, faz-me gozar de novo!"

    # say L650 pla
    old "Ohhhh... F- Fuckk!"
    new "B:mo2: Não pares, não pares, tu pequeno bastardo."

    # say L656 mo2
    old "Okay, I'm done here, I hope you don't screw it up again at work. Otherwise, next time it will be worse."
    new "B:pla: Ohhhh... F- Foda-se!"

    # say L657 mo2
    old "Get dressed and leave, I can't waste any more time with you."
    new "B:mo2: Está bem, já acabei aqui, espero que não estragues de novo no trabalho. Senão, da próxima vez será pior."

    # say L665 mo2
    old "Uhh that was good..."
    new "B:mo2: Veste-te e vai, não posso perder mais tempo contigo."

    # say L666 pla
    old "Alright, I'm gonna get dressed."
    new "Oh, que bom, mas eu quero um pouco mais."

    # say L667 mo2
    old "Oh gosh, I want a little more."
    new "B:pla: Vou vestir-me."

    # say L669 mo2
    old "Shut up and keep licking. I'm going to try something different."
    new "B:mo2: Oh, que raio, eu quero um pouco mais."

    # say L677 pla
    old "Oh wow! What the fuck!"
    new "B:mo2: Cala-te e continua a lamber. Vou tentar algo diferente."

    # say L678 mo2
    old "Don't even think about saying or doing something, keep quiet, and don't stop licking."
    new "B:pla: Oh wow! Que merda!"

    # say L687 mo2
    old "This is what you always wanted, isn't it?"
    new "B:mo2: Nem sequer penses em dizer ou fazer algo, mantém-te calado e não pares de lamber."

    # say L689 mo2
    old "Getting your naughty and disgusting cock sucked."
    new "B:mo2: Isto é o que sempre quis, não é?"

    # say L693 mo2
    old "Do you like it? Uh? Do you like your master sucking your cock?"
    new "B:mo2: A deixar o teu pénis sujo e nojento ser chupado."

    # say L695 mo2
    old "Of course you do, look how excited and horny you are."
    new "B:mo2: Gostas disto? hã? Gostas do teu mestre a chupar-te o pénis?"

    # say L699 mo2
    old "Ohh, yeah, keep going, keep licking my pussy, you little pervert."
    new "B:mo2: Claro que sim, olha como estás excitada e com tesão."

    # say L700 mo2
    old "Are you going to remain useless, good for nothing? Are you going to keep doing it so that I continue to punish you?"
    new "B:mo2: Ohh, sim, continua, continua a lamber a minha xoxota, tu pequeno pervertido."

    # say L725 pla
    old "I- I'm cumming!"
    new "B:mo2: Ohh, sim, não pares, não pares!"

    # say L726 mo2
    old "Ahhh I- I'm cumming to!"
    new "B:pla: I- I'm cumming!"

    # say L733 mo2
    old "Ughhh, gross..."
    new "B:mo2: Ahhh, eu- eu estou a gozar!"

    # say L734 mo2
    old "I better go clean this up, it's disgusting... "
    new "A:mo2: Sou o teu chefe e o teu Mestre."

    # say L745 mo2
    old "I'm your boss and your Master."
    new "B:mo2: Melhor ir limpar isto, está nojento..."

    # say L746 mo2
    old "And you're shit... And you do what I say."
    new "B:mo2: Sou o teu chefe e o teu Mestre."

    # say L747 mo2
    old "Got it?"
    new "B:mo2: E tu és uma merda... E fazes o que eu digo."

    # say L749 mo2
    old "You belong to me and I do whatever I fucking want with you."
    new "B:mo2: Entendido?"

    # say L753 mo2
    old "Yeahh! This is what you like..."
    new "B:mo2: Tu pertences a mim e eu faço contigo o que quiser."

    # say L755 mo2
    old "Fucking pervert! Fucking slave... Useless bitch."
    new "B:mo2: Sim! É isto que tu gostas..."

    # say L757 mo2
    old "Your cock is really hard but I won't make you cum yet... Not if you are so eagered. You don't deserve to cum now."
    new "B:mo2: Pervertido nojento! Escravo imprestável..."

    # say L761 mo2
    old "You are about to explode! isn't it? Fuck you!"
    new "B:mo2: O teu pénis está mesmo duro, mas não vou deixar-te gozar ainda... Não se fores tão ansioso. Não mereces gozar agora."

    # say L763 mo2
    old "Say who is your Master?"
    new "B:mo2: Vais explodir! Não é verdade? Foda-se!"

    # say L765 mo2
    old "Say it out loud NOW!"
    new "B:mo2: Diz quem é o teu Mestre?"

    # say L766 mo2
    old "If you wanna cum, you'll need to say it!"
    new "B:mo2: Diz em voz alta AGORA!"

    # say L767 pla
    old "Y- You... You're my Master."
    new "B:mo2: Se quiser gozar, vais ter de o dizer!"

    # say L768 mo2
    old "You want to cum... Poor boy can't come because I won't let him do it."
    new "B: Y- Tu... Tu és o meu Mestre."

    # say L791 mo2
    old "If you want to come, you have to beg for it again."
    new "B:mo2: Queres gozar... Pobre rapaz não consegue porque eu não deixo."

    # say L792 pla
    old "A- again..."
    new "B:mo2: Se queres vir, tens de implorar de novo."

    # say L793 mo2
    old "Yes! Beg for it! You have to learn little bitch."
    new "B: A- de novo..."

    # say L794 pla
    old "P- please, I- I need to cum... I really need it... N- now."
    new "B:mo2: Sim! Implora por isso! Tens de aprender, putinha."

    # say L795 mo2
    old "You'll cum whenever I want not when you need to..."
    new "B: pla: P- por favor, eu- eu preciso de gozar... Preciso mesmo... A- agora."

    # say L796 mo2
    old "Say that you're my bitch... Say it and I'll let you cum."
    new "B:mo2: Vais gozar quando eu quiser, não quando tu precisares..."

    # say L798 pla
    old "I'm your b- bitch, master..."
    new "B:mo2: Diz que és a minha cadela... Diz e deixo-te gozar."

    # say L805 mo2
    old "I didn't expect this to happen but I'll do it..."
    new "B:pla: Sou a tua b- putinha, mestre..."

    # say L806 mo2
    old "I've tried to show you who is the Master here but you still refuse to believe..."
    new "B:mo2: Não esperava que isto acontecesse, mas vou fazê-lo..."

    # say L807 mo2
    old "We cannot keep going in the same way... Now you'll know who is the master and who is the slave."
    new "B:mo2: Tentei mostrar-te quem é o Mestre aqui, mas tu continuas a recusar-te a acreditar..."

    # say L809 mo2
    old "I'm your fucking Master and you're my slave, you listen and do as I say..."
    new "B:mo2: Não podemos continuar assim... Agora vais saber quem é o mestre e quem é o escravo."

    # say L810 mo2
    old "This is not a game! I'm gonna fuck you if I want, you do as I tell you..."
    new "B:mo2: Sou o teu maldito Mestre e tu és a minha escrava, vais ouvir e fazer o que eu digo..."

    # say L811 pla
    old "W- what-"
    new "B:mo2: Isto não é um jogo! Vou foder-te se eu quiser, faz o que te mando..."

    # say L827 mo2
    old "Little bastard, useless and needy..."
    new "B: pla: O- o que-"

    # say L829 mo2
    old "I'm your Master and I want you to say it more often."
    new "B:mo2: Pequeno bastardo, inútil e necessitado..."

    # say L830 pla
    old "M- Mas-"
    new "B:mo2: Sou o teu Mestre e quero que digas mais vezes."

    # say L831 mo2
    old "I don't hear you!"
    new "A:mo2: Diz! Quem é o teu Mestre?"

    # say L832 mo2
    old "Say it! Who is your Master?"
    new "B:mo2: Não te ouço!"

    # say L833 pla
    old "Y- You..."
    new "B:mo2: Diz! Quem é o teu Mestre?"

    # say L838 mo2
    old "Seems that the slave is doing okay..."
    new "B: pla: T-Tu..."

    # say L840 mo2
    old "Are you enjoying this? Who told you to enjoy this... You're just a fucking slave..."
    new "B:mo2: Parece que a escrava está a ir bem..."

    # say L842 mo2
    old "You're almost nonexistent... Without me, you're nothing. Without your Master, you're nothing."
    new "B:mo2: Estás a gostar disto? Quem te disse para gostar... Tu és apenas uma putinha..."

    # say L843 mo2
    old "I'll make you suffer, motherfucker!"
    new "B:mo2: Tu quase não existes... Sem mim, tu és nada. Sem o teu Mestre, tu és nada."

    # say L848 mo2
    old "You are about to explode! isn't it? Fucking idiot!"
    new "B:mo2: Vou fazer-te sofrer, merda!"

    # say L850 mo2
    old "I'm fucking you, little bastard."
    new "B:mo2: Vais explodir! Não vais? Idiota!"

    # say L851 mo2
    old "Now you are my bitch, I'm fucking my little bitch."
    new "B:mo2: Estou a foder-te, pequeno bastardo."

    # menu L872 
    old "Change perspective"
    new "Ohh yeahh, tu sentes como estou a foder-te forte?"

    # say L882 mo2
    old "Ohh yeahh, can you feel how hard I'm fucking you?"
    new "B:n: Mudar perspetiva"

    # say L883 pla
    old "Ahhh... I- I-"
    new "B:mo2: Ohh yeahh, sentes como estou a foder-te?"

    # say L884 mo2
    old "Yes, I'm cuming on you fucking bastard"
    new "B:pla: Ahhh... I- I-"

    # say L893 mo2
    old "All right, I already made you my bitch!"
    new "B:mo2: Sim, estou a gozar em ti, maldito."

    # say L894 mo2
    old "Never ever, try to rebel against me, I am your master."
    new "B:mo2: Tudo bem, já te fiz a minha cadela!"

    # say L911 mo1
    old "This feels so nice... Oh my God!"
    new "B:mo2: Uhh... Tu és tão sexy..."

    # say L915 mo2
    old "Ahhh, don't stop baby, don't stop!"
    new "B:mo1: Isto sente-se tão bem... Oh meu Deus!"

    # say L916 mo1
    old "Oh yes! I have been waiting a lot for this!"
    new "B:mo2: Ahhh, não pares, meu amor, não pares!"

    # say L924 mo1
    old "Ahhh, Ahhh! I love you."
    new "B:mo2: Oh yeah, continua assim, amor, continua assim!"

    # say L925 mo2
    old "Keep going, keep going!"
    new "A:mo1: Oh meu Deus, estou tão excitada!"

    # say L926 mo1
    old "Oh my God, I'm so fucking horny!"
    new "B:mo2: Continua, continua!"

    # say L950 mo2
    old "Yes, Yes, cum for me baby!"
    new "B:mo1: Oh meu Deus, estou tão excitada!"


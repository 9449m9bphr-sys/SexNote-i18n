# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/LadStory.rpy
translate portuguese strings:

    # say L14 pla
    old "Yeah, I did. And you?"
    new "B:mo1: Dormiste bem?"

    # say L20 pla
    old "Oh that's right! It's today! I'd totally forgotten about it."
    new "B:mo1: Bem, não realmente. Só queria ver se tu estás a fazer algo com os amigos para o Halloween."

    # say L21 pla
    old "That reminds me, I need to pick up my costume."
    new "B:pla: Ah, é verdade! É hoje! Tinha-me completamente esquecido."

    # say L23 mo1
    old "Are you going to school in a costume?"
    new "B:pla: Isso lembra, preciso ir buscar o meu fato."

    # say L24 pla
    old "Yeah, me and my friends are dressing up for Halloween."
    new "T(pla|tu|say): Sim, eu e os meus amigos vamos vestidos para o Halloween."

    # say L25 mo1
    old "Really? Why? Are you having a party?"
    new "B:pla: Sim, eu e os meus amigos estamos a vestir-nos para o Halloween."

    # say L26 pla
    old "No, no, nothing special like that. It's just that the school principal said all students get to wear costumes today."
    new "B:mo1: Mesmo? Porquê? Vais fazer uma festa?"

    # say L27 mo1
    old "Seriously? That's cool."
    new "B:pla: Não, nada de especial. É que o diretor da escola disse que todos os alunos podem usar trajes hoje."

    # say L28 pla
    old "Yeah, it's nice we get to do this once in a while. Everyone's excited about it."
    new "B:mo1: A sério? Isso é fixe."

    # say L31 pla
    old "Yeah, I'll do. We're competing about who has the worst costume."
    new "B:mo1: Afinal, este é o teu último Halloween na escola, onde ainda podes vestir-te à fantasia, por isso aproveita bem."

    # say L32 mo1
    old "And do you have one already?"
    new "B:pla: Sim, eu faço. Estamos a competir sobre quem tem o pior disfarce."

    # say L53 sis
    old "Hi [pla], good morning. How are you?"
    new "Estou bem. Olá, [pla], bom dia. Como estás?"

    # say L55 sis
    old "Yeah, it did. It came in with the last shipment of clothing for the store."
    new "T(sis|tu|say): Sim, chegou. Veio com o último carregamento de roupa para a loja."

    # say L57 pla
    old "Great! Where is it?"
    new "B:sis: Sim, chegou. Veio com o último carregamento de roupa para a loja."

    # say L59 sis
    old "Hmm... I haven't unpacked anything yet, so it must be in one of the boxes."
    new "B:pla: Ótimo! Onde é que está?"

    # say L60 sis
    old "Just wait here a minute. I'll go get it for you."
    new "B: Irmã: Hmm... Ainda não desembrulhei nada, então deve estar em uma das caixas."

    # say L72 sis
    old "Here you go."
    new "B:sis: Espera aqui um minuto. Vou buscar isso para ti."

    # say L77 pla
    old "Of course, by the way, how much do I owe you?"
    new "B:sis: Bem, vais experimentá-lo e dizes-me se te fica bem e se gostas."

    # say L78 sis
    old "Oh, don't worry about it..."
    new "B:pla: Claro, a propósito, quanto te devo?"

    # say L79 sis
    old "It's on the house."
    new "B:sis: Oh, não te preocupes com isso..."

    # say L104 pla
    old "Now I'm ready for Halloween!"
    new "B:pla: Vou definitivamente impressionar todos com isto."

    # say L127 pla
    old "Hey guys, what 's up?"
    new "B:pla: Agora estou pronto para o Halloween!"

    # say L131 bel
    old "It looks very good."
    new "B:pla: Fixe, não é?"

    # say L132 mik
    old "Yeah dude, really cool."
    new "B:bel: Parece muito bom."

    # say L134 mik
    old "But to be honest, not as cool as mine."
    new "T(mik|tu|say): Mas a ser sincero, nem tão fixe como o meu."

    # say L135 bel
    old "Really? And why is that?"
    new "B:mik: Mas a ser sincero, não é tão fixe como o meu."

    # say L136 mik
    old "Because I'm Iron Man, I mean... Come on!"
    new "T(mik|tu|say): Porque sou o Homem de Ferro, quer dizer... Vamos lá!"

    # say L137 mik
    old "I'm the super rich, genius, chick magnet! No way Spiderman beats that."
    new "T(mik|tu|say): Sou o super rico, gênio, imã de garotas! Impossível o Homem-Aranha competir com isso."

    # say L139 pla
    old "It actually is a cool Iron Man costume... Even the goatee."
    new "B:mik: Sou o super rico, gênio, imã de gatas! Impossível o Homem-Aranha competir com isso."

    # say L141 bel
    old "Hmph, I guess."
    new "A: mik: E tu, Belle? És como um tipo de coelho?"

    # say L143 mik
    old "And you Belle? Are you like a type of rabbit?"
    new "B:bel: Hmph, acho que sim."

    # say L144 bel
    old "Not a type of rabbit. I'm a bunny, the coolest one, Lola Bunny!"
    new "B:mik: E tu, Belle? És como um tipo de coelho?"

    # say L145 pla
    old "Ohh right. I get it now."
    new "B:bel: Não é um tipo de coelho. Sou uma coelhinha, a mais cool, a Lola Bunny!"

    # say L146 pla
    old "Cool costume, it looks really good on you."
    new "B:pla: Ahh, percebi agora."

    # say L160 rub
    old "Oh my, Olivia, would you look at that? The loser club in their dumb costumes. Aren't they childish?"
    new "B:pla: Fato fixe, fica-te mesmo bem."

    # say L161 oli
    old "Yeah, always acting like little kids. Dumb, poor kids."
    new "B:rub: Oh my, Olivia, olha só isso! O clube dos perdedores com os seus ridículos trajes. Não são eles infantis?"

    # say L162 bel
    old "Don't you two airheads have anything better to do this early in the morning?"
    new "B:oli: Sim, sempre a agirem como crianças. Crianças estúpidas e pobres."

    # say L163 rub
    old "Better than showing you just how much of a dumbass you are? Don't think so."
    new "B:bel: Vocês dois não têm nada melhor para fazer tão cedo de manhã?"

    # say L164 rub
    old "By the way, are you supposed to be Lola Bunny?"
    new "B:rub: Melhor do que mostrar-te o quão estúpido és? Não acho."

    # say L165 bel
    old "Y-yeah, I am. Why?"
    new "B:rub: Por acaso, tu és suposta ser a Lola Bunny?"

    # say L166 rub
    old "Dear, you should realize that with those ears, and that pig nose of yours, you're much more of a Piglet."
    new "B:bel: A-ah, sou. Porquê?"

    # say L167 pla
    old "Hey! Don't you think that's too much?"
    new "B:rub: Querida, deves perceber que com essas orelhas e esse nariz de porco, és muito mais uma Porquinha."

    # say L168 mik
    old "That's right. Shut up!"
    new "B:pla: Ei! Não achas que isso é demais?"

    # say L169 rub
    old "Wow Olivia, look who's defending Piglet! Spiderman the scrawny loser, and Iron fat."
    new "B:mik: É isso aí. Cala a boca!"

    # say L170 oli
    old "What's funny is that they're opposites. One is too slim to fill his Spiderman pajamas, and the other's too fat to fit into the costume."
    new "B:rub: Wow Olivia, olha quem está a defender o Porquinho! O Homem-Aranha, o perdedor magricela, e o Homem de Ferro, o gordo."

    # say L171 rub
    old "Hey Iron Man, don't you think it's ridiculous that your belly's rounder than your chest?"
    new "B:oli: O que é engraçado é que eles são opostos. Um é tão magro que nem preenche o pijama do Homem-Aranha, e o outro é tão gordo que não consegue entrar no traje."

    # say L172 oli
    old "Maybe we should call him barrel man."
    new "B:rub: Ei Homem de Ferro, não achas ridículo que a tua barriga seja mais redonda do que o peito?"

    # say L179 hin
    old "Hey guys! What's up? It's everything ok?"
    new "B:oli: Talvez devêssemos chamá-lo de homem barril."

    # say L183 oli
    old "Ohh wow. What a costume..."
    new "B:hin: Ei pessoal! Tudo bem? Tudo ok?"

    # say L184 rub
    old "My god! And what the hell are you wearing? You look like a WHORE."
    new "B:oli: Ohh wow. Que fato..."

    # say L185 oli
    old "The stupid cow came dressed up like a bat-whore."
    new "B:rub: Meu Deus! E que raio é que estás a usar? Pareces uma PUTA."

    # say L187 hin
    old "Hey! It's not a whore costume. I'm Morrigan from Darkstalkers. And for your information this took a lot of time to make..."
    new "B:oli: A vaca estúpida veio vestida como uma puta-morcega."

    # say L188 rub
    old "Ughh nerd... I don't care..."
    new "B:hin: Ei! Não é um disfarce de prostituta. Sou a Morrigan dos Darkstalkers. E para tua informação, isto demorou muito tempo a fazer..."

    # say L189 rub
    old "I am only surprised that the shy moron I see here every day would bring such a revealing costume."
    new "B:rub: Ughh nerd... Não me importo..."

    # say L190 oli
    old "Which by the way, it's disgusting."
    new "B:rub: Estou só surpreendido que a tonta tímida que vejo todos os dias trouxesse um fato tão revelador."

    # say L191 rub
    old "I mean, you couldn't wear ANYTHING more revealing! My god! You should be ashamed!"
    new "B:oli: Aliás, é nojento."

    # say L192 hin
    old "W- what are you talking about? Your costume has also a cleavage..."
    new "B:rub: Quero dizer, tu não podias usar NADA mais revelador! Meu Deus! Deverias ter vergonha!"

    # say L193 rub
    old "WHAT? YOU'VE GOTTA BE KIDDING ME!"
    new "B:hin: O- o que estás a dizer? O teu fato também tem decote..."

    # say L194 rub
    old "We have decent classy costumes, there's nothing wrong with ours."
    new "B:rub: QUE? TU DEVES ESTAR A BRINCAR COMIGO!"

    # say L195 rub
    old "In case you haven't noticed, Olivia and I are Disney princesses..."
    new "B:rub: Temos trajes decentes e elegantes, não há nada de errado com os nossos."

    # say L196 rub
    old "While you just came in a stupid costume from some nerd stuff."
    new "B:rub: Se não reparaste, Olivia e eu somos princesas da Disney..."

    # say L197 hin
    old "Well, I don't care, because I really have something to show and I feel comfortable with my body, unlike you two stupid bitches..."
    new "B:rub: Enquanto tu entras com um fato ridículo de alguma coisa nerd."

    # say L198 rub
    old "W- what did you just say to me?! Olivia! Did you hear that?!!"
    new "B:hin: Bem, eu não me importo, porque tenho mesmo algo para mostrar e me sinto confortável com o meu corpo, ao contrário de vocês duas estúpidas putinhas..."

    # say L199 oli
    old "I did Ruby! How dare you talk to us like that? You bat-whore!"
    new "B:rub: O- o que acabaste de me dizer?! Olivia! Ouviu isso?!!"

    # say L200 hin
    old "Shut up you two! You envious bitches!"
    new "B:oli: Fiz a Ruby! Como ousas falar connosco assim? Tu, putinha de morcego!"

    # say L201 bel
    old "Ohhhh! What's the matter, girls? You can dish it, but you can't take it?"
    new "B:hin: Cala-te, vocês duas! Vocês são umas invejosas!"

    # say L202 pla
    old "H-Hey, Hinn, maybe it's best if we just leave, look, classes are about to start..."
    new "B:bel: Ohhhh! Que se passa, meninas? Vocês sabem dar, mas não sabem receber?"

    # say L203 hin
    old "And why do we have to be the ones to leave?! These idiots are the ones who started."
    new "B:pla: H-Hey, Hinn, talvez seja melhor se formos embora, olha, as aulas estão prestes a começar..."

    # say L204 hin
    old "You two better get out here! I've had enough of your bullshit!"
    new "B:hin: E por que temos de ser nós a ir embora?! Estes idiotas são os que começaram."

    # say L205 rub
    old "Ughh. We're leaving! But it's not because you tell us to, you little whore! I just don't want to keep wasting my time with you, dumbasses."
    new "B:hin: Vocês dois melhor saírem daqui! Já cheguei ao limite da vossa merda!"

    # say L206 rub
    old "Let 's go Olivia."
    new "B:rub: Ughh. Vamos embora! Mas não é porque tu nos mandas, tua putinha! Eu só não quero continuar a perder o meu tempo contigo, imbecis."

    # say L220 bel
    old "Wow! Hinn, what's happened to you? That was sooo awesome!"
    new "B:rub: Vamos, Olivia."

    # say L221 hin
    old "Hehe, you think so?"
    new "B:bel: Uau! Hinn, o que aconteceu contigo? Isso foi tão incrível!"

    # say L225 hin
    old "Well, it's a relief to hear you guys say that... For a moment there I thought you may have thought ill of me."
    new "B:pla: Concordo com a Belle, foste totalmente incrível, Hinn!"

    # say L227 pla
    old "Aww, we wouldn't. And hey, for what it's worth, I think your costume is great."
    new "B:hin: Bem, é um alívio ouvir vocês dizerem isso... Por um momento pensei que poderiam ter uma má opinião de mim."

    # say L228 bel
    old "Yeah Hinn, you look gorgeous, and I'm happy you're finally showing some skin, it was about time!"
    new "T(bel|tu|say): Sim, Hinn, tu estás linda, e fico feliz que finalmente estejas a mostrar um pouco de pele, estava na hora!"

    # say L229 hin
    old "Sigh, stop it with that."
    new "B:bel: Sim Hinn, estás linda, e fico contente que finalmente estejas a mostrar um pouco de pele, estava na hora!"

    # say L230 mik
    old "Yeah Hinn, it really, really suits you."
    new "B:hin: Suspiro, pára com isso."

    # say L231 mik
    old "And hey, I support you sharing your natural gifts with us. It's a really nice view."
    new "B:mik: Sim, Hinn, fica-te mesmo bem."

    # say L233 bel
    old "Oh my gosh Mike, couldn't you be a little decent at least once?"
    new "B:mik: E olha, eu apoio-te a partilhar os teus dons naturais connosco. É uma vista realmente bonita."

    # say L234 mik
    old "What? What did I say? I was giving Hinn a compliment!"
    new "B:bel: Ai, Mike, não podias ser um pouco decente pelo menos uma vez?"

    # say L235 bel
    old "Yeah right, sure you were..."
    new "B:mik: Que? O que eu disse? Estava a dar um elogio à Hinn!"

    # say L236 bel
    old "Anyway, we better get going. It's almost time for class."
    new "B:bel: Claro, como não..."

    # say L237 mik
    old "Huh? But we still have some time."
    new "B:bel: Então, melhor irmos. É quase hora de aula."

    # say L239 bel
    old "I know, but you know Ms. Mia has her eyes on you because you keep skipping. So, let's go, come on!"
    new "B:mik: Huh? Mas ainda temos algum tempo."

    # say L254 pla
    old "Of course! I like it a lot."
    new "B:hin: O que disseste sobre o meu fato, gostas mesmo dele?"

    # say L255 pla
    old "And to be honest... I think you're the only student who could pull it off."
    new "E a ser sincero... Acho que tu és o único aluno que consegue fazer isto."

    # say L256 hin
    old "Huh? You mean it?"
    new "B:pla: E a ser sincero... Acho que tu és o único aluno que consegue fazer isso."

    # say L257 pla
    old "Yeah! Nobody else could wear that costume that well."
    new "B:hin: Huh? Tu queres dizer isso a sério?"

    # say L263 hin
    old "Just come."
    new "B:pla: Uhh, onde é que estamos a ir?"

    # say L285 pla
    old "Hmm, Hinn, this is the girl's bathroom, I don't think it's ok for me to go in."
    new "B:hin: Vem já."

    # say L286 pla
    old "Maybe it's better if I wait outside."
    new "T(pla|tu|say): Talvez seja melhor eu esperar fora."

    # say L288 pla
    old "For you to use the bathroom..."
    new "B:pla: Talvez seja melhor eu esperar lá fora."

    # say L289 hin
    old "Hahahaha. Don't be silly, I didn't bring you here for that."
    new "B:pla: Para tu usares a casa de banho..."

    # say L290 pla
    old "Uhh, you didn't? Then why?"
    new "B:hin: Hahahaha. Não sejas parvo, não te trouxe aqui para isso."

    # say L292 hin
    old "You see, working with you and Dr. Johnson has really helped me get over my shyness, that's how I was able to stand up to those bullies."
    new "B:pla: Uhh, não? Então porquê?"

    # say L293 hin
    old "So, I thought maybe we could have a little session now. Besides, I want to thank you."
    new "B: Tu vês, trabalhar contigo e com o Dr. Johnson ajudou-me realmente a superar a minha timidez, foi assim que consegui enfrentar aqueles bully."

    # say L294 pla
    old "B- but here? What if someone sees us?"
    new "B:hin: Então, pensei que podíamos ter uma sessãozinha agora. Além disso, quero agradecer-te."

    # say L295 hin
    old "Ohh, don't worry, I'm sure it's gonna be fine, classes are about to start, so there's nobody around."
    new "B: B- mas aqui? E se alguém nos vir?"

    # say L296 pla
    old "Well, if you say so... I guess it's ok then."
    new "B:hin: Ohh, não te preocupes, tenho a certeza de que vai correr tudo bem, as aulas estão prestes a começar, por isso não há ninguém por perto."

    # say L297 hin
    old "Yes, I'm sure nobody will see us."
    new "B:pla: Bem, se tu dizes... Acho que está bem então."

    # say L298 hin
    old "Come here, pull down your pants."
    new "B:hin: Claro, tenho a certeza que ninguém nos vai ver."

    # say L308 hin
    old "I'm happy you're this hard because of me."
    new "B:pla: Não acredito que estamos a fazer isto na casa de banho."

    # say L317 hin
    old "Look, it's almost time for class."
    new "B:hin: Estou feliz por estares assim tão excitado por minha causa."

    # say L318 hin
    old "I'll go ahead. Don't be late."
    new "B:hin: Olha, já é quase hora de ir para a aula."

    # say L327 pla
    old "Wow! I don't know what that was, but I sure like this new Hinn."
    new "B:hin: Vou indo. Não te atrases."

    # say L340 pla
    old "Ohh! Wow, Billie! What are you doing here?"
    new "B:pla: Uau! Não sei o que foi isso, mas gosto muito desta nova Hinn."

    # say L342 bil
    old "Hey! What's up? I just transferred here. Today's my first day."
    new "B:pla: Ohh! Uau, Billie! O que estás a fazer aqui?"

    # say L343 pla
    old "Ahh, I see. That's cool, what school did you transfer from?"
    new "B:bil: Ei! O que há? Acabei de me transferir para cá. Hoje é o meu primeiro dia."

    # say L344 bil
    old "From nowhere actually. All my life I've been home schooled, and that's fine, I guess. But you see, this is my last year..."
    new "B:pla: Ahh, percebo. Isso é fixe, de onde foste transferido?"

    # say L345 bil
    old "So, I wanted to have the school experience at least for senior year."
    new "B:bil: De repente, na verdade. Toda a minha vida fui ensinado em casa, e isso está bem, acho eu. Mas sabes, este é o meu último ano..."

    # say L346 pla
    old "Well, I think that's a great idea! I'm glad you get to live that at least once. And hey, welcome."
    new "B:bil: Então, eu queria ter a experiência escolar pelo menos no último ano."

    # say L348 bil
    old "It was a coincidence that my first day was Halloween. So, I had to come in costume. What do you think?"
    new "B:pla: Bem, acho que é uma ótima ideia! Fico contente que tenhas a oportunidade de viver isso pelo menos uma vez. E olá."

    # say L349 pla
    old "I think it's great, it's really good. You look just like the real Harley Quinn."
    new "T: Acho que é ótimo, está mesmo bom. Pareces mesmo a Harley Quinn verdadeira."

    # say L350 bil
    old "Thanks, and hey, I think you also make for a very good Spiderman."
    new "B:pla: Acho ótimo, é realmente bom. Tu pareces mesmo a Harley Quinn verdadeira."

    # say L352 pla
    old "Thanks!"
    new "A:bil: Por acaso. Porque é que estavas a sair da casa de banho das raparigas?"

    # say L353 bil
    old "By the way. Why were you leaving the girls bathroom?"
    new "B:pla: Obrigado!"

    # say L354 pla
    old "Ohh! Hmm, no reason."
    new "B:bil: Por acaso. Porque é que estavas a sair da casa de banho das raparigas?"

    # say L355 pla
    old "I guess, I- I just got confused."
    new "B:pla: Ohh! Hmm, sem razão."

    # say L357 bil
    old "Uhh... Sure..."
    new "T(bil|tu|say): Hmm... Claro..."

    # say L358 pla
    old "We better get going, the class has already started."
    new "B:bil: Uhh... Claro..."

    # say L364 mia
    old "Ok guys, let's start today's lesson. Now who can tell me where we left it last time?"
    new "B:pla: Melhor irmos, a aula já começou."

    # say L382 mia
    old "Yeah right! Always excuses with you. Anyway, go sit down!"
    new "B:pla: I- Desculpe, Sra. Mia, não vai acontecer de novo, é que encontrei um amigo no corredor."

    # say L389 mia
    old "Ok guys, before we begin, I have to introduce you to a new student."
    new "B:mia: Claro! Sempre desculpas contigo. De qualquer forma, vai sentar-te!"

    # say L393 mia
    old "This is Billie, she's going to be accompanying us during this last year. Be sure to be nice to her."
    new "B:mia: Ok, pessoal, antes de começarmos, tenho que vos apresentar uma nova aluna."

    # say L394 bil
    old "Hi."
    new "B:mia: Esta é a Billie, ela vai acompanhar-nos durante este último ano. Certifiquem-se de ser simpáticos com ela."

    # say L396 mia
    old "Take seat Billie, there's a spot for you there."
    new "B:bil: Olá."

    # say L423 bel
    old "Ok everybody, classes are over, and we have time. Why don't we go ask for some candy?"
    new "B:mia: Ok, isso é tudo por hoje, não se esqueçam de ler o livro antes da próxima aula. É melhor se prepararem com antecedência."

    # say L424 bil
    old "Ugh, candy? Are you serious? Don't you think we're a little too old for that?"
    new "B:bel: Ok, pessoal, as aulas acabaram e temos tempo. Por que não vamos pedir algumas balas?"

    # say L425 bel
    old "Ohh, come on! This is our last year, so we won't be able to do it anymore."
    new "B:bil: Ugh, doces? Estás a brincar? Não achas que já somos um bocado velhos para isso?"

    # say L426 mik
    old "Yeah! Billie, trick or treating is super cool, we'll have a great time."
    new "B:bel: Ohh, vamos! É o nosso último ano, então não vamos poder fazer isso de novo."

    # say L427 bil
    old "I don't think walking around, knocking on front doors is a ‘great time.'"
    new "B:mik: Claro! Billie, ir pedir doces é super fixe, vamos divertir-nos imenso."

    # say L428 bil
    old "But whatever, if you all want to."
    new "B: Não acho que andar por aí, a bater à porta das pessoas, seja uma grande maneira de passar o tempo."

    # say L430 pla
    old "I actually want too, it's a good way to spend the afternoon."
    new "B:bil: Mas enfim, se vocês querem."

    # say L431 pla
    old "Besides, we get to use the costumes some more."
    new "E o que tu achas, Hinn?"

    # say L432 pla
    old "And what do you think Hinn?"
    new "B:pla: Além disso, podemos usar os trajes mais vezes."

    # say L433 hin
    old "I think it's a nice idea. I wanna hang out some more."
    new "B:pla: E o que tu achas, Hinn?"

    # say L434 hin
    old "And to be honest I also don't want to get out of my costume just yet."
    new "B:hin: Acho que é uma boa ideia. Quero passar mais tempo contigo."

    # say L435 bil
    old "Oh my god, you guys are so lame."
    new "B:hin: E a ser sincero, também não quero tirar o meu fato ainda."

    # say L436 bil
    old "But fine, fine, if you want to do it, I'll do it too. This better be good."
    new "B:bil: Ai, meu Deus, vocês são tão parvos."

    # say L453 mik
    old "That was so awesome! I can't believe they gave us this much candy at our age."
    new "B:bil: Mas bem, bem, se tu queres fazê-lo, eu também o farei. Isto melhor ser bom."

    # say L454 pla
    old "Definitely, a real success I'd say."
    new "B:mik: Foi tão incrível! Não acredito que nos deram tanto doces à nossa idade."

    # say L455 bel
    old "You see? It was totally worth it. I knew it was gonna be this much fun. Right Billie?"
    new "B:pla: Definitivamente, um verdadeiro sucesso, diria eu."

    # say L456 bil
    old "Yeah... I guess. It wasn't so bad after all."
    new "B:bel: Vês? Foi totalmente a pena. Sabia que ia ser assim tão divertido. Não é, Billie?"

    # say L457 hin
    old "It's still early, we could keep going if you want to."
    new "B:bil: Sim... Acho que sim. Não foi tão mau afinal."

    # say L458 mik
    old "Nah, I don't think so. This is nice and all, but my feet hurt, I'm a little tired of carrying this heavy custume."
    new "B:hin: Ainda é cedo, podíamos continuar se tu quiseres."

    # say L459 pla
    old "Come on man, don't ruin the mood, you're the one who wanted to ask for candy in the first place."
    new "B:mik: Não, não acho. Isto é agradável e tudo, mas os meus pés doem, estou um pouco cansado de carregar este fato pesado."

    # say L462 pla
    old "Hmm, and what do you think, Hinn? Do you want to keep going?"
    new "B:bil: Bem, se é o caso, devemos ir à praia, está muito perto e podemos sentar-nos e descansar lá."

    # say L463 hin
    old "Ohh, I'm fine. I only said it because I thought everyone else wanted to do it too, but if everyone it's ok with stopping here I'd agree."
    new "B:pla: Hmm, e o que tu achas, Hinn? Queres continuar?"

    # say L464 bel
    old "That settles it then, let's go to the beach."
    new "B:hin: Ohh, estou bem. Só disse porque pensei que todos queriam fazer isso, mas se está tudo bem parar aqui, eu concordo."

    # say L478 pla
    old "Well, this is nice. I thought there were going to be people here."
    new "B:bel: Então está decidido, vamos à praia."

    # say L479 hin
    old "Yeah, it's good that it is so quiet, this is a good place to rest."
    new "B:pla: Bem, isto é agradável. Pensei que houvesse pessoas aqui."

    # say L480 bel
    old "We should find a place to sit down."
    new "A:hin: Não podemos simplesmente sentar-nos aqui?"

    # say L481 hin
    old "Can't we just sit here?"
    new "B:bel: Devíamos encontrar um sítio para nos sentarmos."

    # say L482 bel
    old "I think we could sit a little bit closer to the sea."
    new "B:hin: Não podemos ficar aqui sentados?"

    # say L483 bil
    old "Let's just go to that spot over there"
    new "B:bel: Acho que podíamos sentar-nos um pouco mais perto do mar."

    # say L484 pla
    old "Yeah, that seems fine."
    new "T: Sim, parece bom."

    # say L498 bil
    old "Ok, since we're here. Why don't we make it a little bit more interesting than just sitting down doing nothing? Let's play truth or dare!"
    new "Uhh, desculpa. Truth ou quê?"

    # say L499 hin
    old "Uhh, I'm sorry. Truth or what?"
    new "A:bil: O quê? Tu não sabes o que é verdade ou desafio?"

    # say L500 bil
    old "What? You don't know what truth or dare is?"
    new "T(bil|tu|say): O quê? Tu não sabes o que é verdade ou desafio?"

    # say L501 mik
    old "Hey! I know what it is."
    new "B:bil: O quê? Tu não sabes o que é verdade ou desafio?"

    # say L502 pla
    old "Uhh, I think I know it, but I haven't played it."
    new "T: Hum, acho que sei, mas nunca joguei."

    # say L503 pla
    old "Just so we're all on the same page, could you explain?"
    new "A:bil: É muito simples: em cada rodada, um de nós escolhe alguém e pergunta 'verdade ou desafio'"

    # say L505 bil
    old "It's very simple: Each round, one of us chooses someone and asks them 'truth or dare'"
    new "T(bil|tu|say): É muito simples: Cada rodada, um de nós escolhe alguém e pergunta 'verdade ou desafio'."

    # say L506 bil
    old "If the person chooses ‘truth' they have to answer whatever the other one asks. If they choose ‘dare', they have to do what the person tells them to."
    new "T(bil|tu|say): Se a pessoa escolher ‘verdade’, tem de responder a qualquer coisa que o outro pergunte. Se escolher ‘desafio’, tem de fazer o que a outra pessoa lhe disser."

    # say L507 pla
    old "All right..."
    new "B:bil: Se a pessoa escolher ‘verdade', tem de responder a tudo o que a outra pedir. Se escolher ‘desafio', tem de fazer o que a outra disser."

    # say L508 bel
    old "You have to be really honest in answering or accomplishing the dare, otherwise, you must go and can't continue playing."
    new "B:pla: Tudo bem..."

    # say L509 bil
    old "Yeah, just like that, it's really fun. Come on, let's play!"
    new "B:bel: Tens de ser realmente honesta ao responder ou cumprir o desafio, caso contrário, tens de sair e não podes continuar a jogar."

    # say L511 pla
    old "Hmm, I don't know Billie..."
    new "B:bil: Sim, é mesmo assim, é muito divertido. Vamos, vamos brincar!"

    # say L514 pla
    old "Ok, ok. If you guys really want to, let's do it."
    new "B:bel: Yeah guys, let's do it. You never know, you may end up liking it."

    # say L516 mik
    old "Alright! Let's do it!"
    new "A:bil: Conseguiste, Hinn?"

    # say L517 bil
    old "Did you get it Hinn?"
    new "B:mik: Tudo bem! Vamos lá!"

    # say L519 hin
    old "Yeah, it's not that hard."
    new "B:bil: Conseguiste perceber, Hinn?"

    # say L520 bel
    old "Ok, since you say you understood it Hinn. Let's start with you, truth or dare?"
    new "B:hin: Sim, não é assim tão difícil."

    # say L521 hin
    old "Uhmm, truth."
    new "B:bel: Ok, já que disseste que percebeste, Hinn. Vamos começar contigo, verdade ou desafio?"

    # say L523 bel
    old "Hmm, are you in love with anybody here?"
    new "B:hin: Hmm, verdade."

    # say L524 hin
    old "W- what? What kind of question is that?!"
    new "B:bel: Hmm, estás apaixonado por alguém aqui?"

    # say L525 bel
    old "Uhh, it's a valid question, and you have to answer it, those are the rules..."
    new "B:hin: Q- que? Que tipo de pergunta é essa?!"

    # say L526 bil
    old "That's right, that's the game."
    new "B:bel: Uhh, é uma pergunta válida, e tu tens de responder, são as regras..."

    # say L528 hin
    old "*Sigh* O- ok. Y- yes, I- I'm in love with someone who's here."
    new "B:bil: É isso mesmo, é esse o jogo."

    # say L531 mik
    old "WHAT?! Who is it? Who is it?"
    new "B:hin: *Suspiro* O- ok. Y- yes, eu estou apaixonado por alguém que está aqui."

    # say L532 pla
    old "Hey, hey! Not fair, dude, she already answered a question. You can't ask her anything else. Right Billie?"
    new "B:mik: QUE?! Quem é? Quem é?"

    # say L534 bil
    old "Yeah, if you really wanna know that kind of stuff, you're gonna have to ask better questions."
    new "B:pla: Ei, ei! Não é justo, cara, ela já respondeu uma pergunta. Não podes perguntar-lhe mais nada. Certo, Billie?"

    # say L535 bil
    old "But come on, I think we should go for dares... It makes the game exciting!"
    new "B:bil: Sim, se realmente queres saber esse tipo de coisas, vais ter de fazer perguntas melhores."

    # say L538 bel
    old "Truth."
    new "B:pla: Hmm, ok. Então, Belle, verdade ou desafio?"

    # say L539 bil
    old "Oh come on! Don't be pussies! Dares are way more fun!"
    new "B:bel: Verdade."

    # say L540 pla
    old "Hmm... H- have you ever kissed a man before?"
    new "B:bil: Vamos lá! Não sejam medrosos! As coragens são muito mais divertidas!"

    # say L542 bil
    old "What kind of question is that? Are you serious? Oh my god, you're a bunch of wusses."
    new "B:pla: Hmm... H- já beijaste um homem antes?"

    # say L547 bil
    old "I'll ask the question. Belle, have you ever taken naked pics?"
    new "B:bil: Que tipo de pergunta é essa? Estás a brincar? Meu Deus, vocês são uns medrosos."

    # say L548 bel
    old "W- whoa. Don't you think that's a little too far?"
    new "B:bil: Vou fazer a pergunta. Belle, já tiraste fotos nuas alguma vez?"

    # say L550 bil
    old "No it's not and answer the question."
    new "B:bel: W- whoa. Tu não achas que isso é um pouco exagerado?"

    # say L551 mik
    old "Yeah Belle, those are the rules. You answer the question or leave!"
    new "B:bil: Não e responde à pergunta."

    # say L555 bel
    old "Ugh! Yeah fine, I've taken naked photos before."
    new "B:mik: Sim Belle, essas são as regras. Tu respondes à pergunta ou vais-te embora!"

    # say L558 mik
    old "Whoa! Really?!"
    new "B:bel: Ugh! Sim, está bem, já tirei fotos nuas antes."

    # say L561 bil
    old "Hehe, ok. Who 's next?"
    new "B:mik: Uau! A sério?!"

    # say L562 mik
    old "Me, me, me! I'm next."
    new "B:bil: Hehe, ok. Quem é o próximo?"

    # say L563 mik
    old "Ok, Billie. Truth or dare?"
    new "B:mik: Eu, eu, eu! Sou eu a seguir."

    # say L564 bil
    old "Dare! Unlike you guys, I actually have some guts."
    new "T(bil|tu|say): Desafio! Ao contrário de vocês, eu tenho coragem."

    # say L568 mik
    old "Ok... Hmm... I dare you to... kiss Belle!"
    new "B:bil: Coragem! Ao contrário de vocês, eu tenho coragem."

    # say L570 bel
    old "What? But I'm not the one with the dare! It's Billie."
    new "B:mik: Ok... Hmm... Desafio-te a... beijar a Belle!"

    # say L571 bil
    old "Well, yeah. But this kind of dares are valid too. After all, I'm the one that has to do it."
    new "B:bel: O quê? Mas eu não sou o da desafio! É a Billie."

    # say L572 mik
    old "Yeah! Remember, you have to do it or you're out!"
    new "B:bil: Bem, sim. Mas este tipo de desafios também conta. Afinal, sou eu que tenho de o fazer."

    # say L573 bil
    old "Yeah whatever, I'll do it, it's no big deal."
    new "T(bil|tu|say): Tudo bem, eu faço, não é nada de mais."

    # say L575 bil
    old "Come on, just help me with this... Otherwise I won't be able to continue playing..."
    new "T(bil|tu|say): Vamos, só me ajuda com isto... Senão não vou conseguir continuar a jogar..."

    # say L577 bil
    old "Just come here, close your eyes and think of someone you like."
    new "B:bil: Vamos, só me ajuda com isto... Senão não vou conseguir continuar a jogar..."

    # say L578 bil
    old "I'm sure we both are gonna enjoy it."
    new "B:bil: Vem aqui, fecha os olhos e pensa em alguém que gostes."

    # say L590 hin
    old "Ok. Now it's my turn to have a go!"
    new "B:bil: Tenho a certeza que ambos vamos aproveitar."

    # say L592 hin
    old "Mike, truth or dare?"
    new "B:hin: Ok. Agora é a minha vez de jogar!"

    # say L593 mik
    old "Of course dare."
    new "B:hin: Mike, verdade ou desafio?"

    # say L594 hin
    old "Well, I dare you to leave and go home."
    new "B:mik: Claro, ousadia."

    # say L595 mik
    old "Uhh?..."
    new "B:hin: Pois, desafio-te a ires embora e voltares para casa."

    # say L596 bel
    old "Yeah! That's right, we all had to do our dares. You have to do the same."
    new "B:mik: Huh?..."

    # say L597 hin
    old "What is it Mike? You can't do it, uhh?"
    new "B:bel: Sim! É verdade, todos tivemos de fazer as nossas coragens. Tu também tens de fazer o mesmo."

    # say L598 mik
    old "Of course I can do it! I'll show you!"
    new "B:hin: O que é, Mike? Tu não consegues, hã?"

    # say L615 bil
    old "Yeah, I didn't think he would do it."
    new "B:mik: Claro que consigo fazer! Vou mostrar-te!"

    # say L617 pla
    old "Hahaha, very good trick Hinn, well done."
    new "B:bil: Sim, eu também não pensei que ele fosse fazer isso."

    # say L627 pla
    old "You know what? I- I choose dare."
    new "B:pla: Hmm, verdade."

    # say L628 bel
    old "What? No, you've got to answer the question."
    new "B:pla: Sabes o quê? Eu... eu escolho a coragem."

    # say L629 bil
    old "No, it's fine. In fact, from now on let's play only with 'dares', no more truths."
    new "B:bel: O quê? Não, tens de responder à pergunta."

    # say L630 bel
    old "Hmm, ok, if that's how it is. Then I dare you to take your penis out."
    new "B:bil: Não, tudo bem. Na verdade, daqui para a frente vamos jogar só com \"desafios\", sem mais verdades."

    # say L631 pla
    old "W- what? Why do I have to do that?"
    new "B:bel: Hmm, ok, se é assim. Então desafio-te a tirar o pénis de fora."

    # say L632 bel
    old "Well, you can either do that, or answer my question!"
    new "B:pla: O- o quê? Porque é que tenho de fazer isso?"

    # say L634 pla
    old "Hmm, fine..."
    new "B:bel: Bem, tu podes fazer isso ou responder à minha pergunta!"

    # say L643 bel
    old "(What a fucking big cock!)"
    new "B:pla: Hmm, está bem..."

    # say L654 pla
    old "Hey, I already did it. You have to fulfill the dare."
    new "B:bil: Porque não mostras também algo teu? E se tirares as mamas?"

    # say L655 bel
    old "Fine. I'll do it."
    new "B:pla: Olá, já fiz. Agora tu tens de cumprir a aposta."

    # say L686 bel
    old "Ok, since I've done it... It's my turn, Billie! Show us your breasts too."
    new "B:bel: Tudo bem. Vou fazer."

    # say L687 bil
    old "Ughh, so original..."
    new "B:bel: Ok, já que eu fiz... É a tua vez, Billie! Mostra-nos também os teus seios."

    # say L715 bil
    old "Then, since there's only one person here that hasn't shown anything. Hinn, I dare you to take your breast out too."
    new "B:bil: Ughh, tão original..."

    # say L718 hin
    old "I- I... Uhh... I'm sorry guys, I- I can't do it."
    new "B:bil: Então, já que só resta uma pessoa que ainda não mostrou nada. Hinn, eu desafio-te a tirar também os teus seios."

    # say L730 pla
    old "Hinn wait!"
    new "B:hin: Eu... Uh... Desculpa, pessoal, eu... Eu não consigo."

    # say L733 bel
    old "Not right now, if you go after her you're just going to make her feel worse."
    new "B:pla: Mas... Acho que ela precisa de companhia."

    # say L736 bel
    old "Trust me, it's better if you just let it be. You can talk to her later. Right Billie?"
    new "B:bel: Não agora, se tu fores atrás dela só vais fazer com que ela se sinta pior."

    # say L737 bil
    old "Yeah, what she said."
    new "B:bel: Confia em mim, é melhor deixar estar. Podes falar com ela mais tarde. Certo, Billie?"

    # say L740 pla
    old "Hmm, all right."
    new "B:bil: Sim, o que ela disse."

    # say L741 bil
    old "Well, I guess we can continue playing then."
    new "B:pla: Hmm, tudo bem."

    # say L742 bel
    old "I agree, since we already started playing. I think it's the best we can do."
    new "B:bil: Bem, acho que podemos continuar a jogar então."

    # say L743 pla
    old "Yeah fine. Let's do it."
    new "B:bel: Concordo, já que já começámos a jogar. Acho que é o melhor que podemos fazer."

    # say L746 pla
    old "Whoa! Really?"
    new "B:bel: Porque não chupas as tetas da Billie?"

    # say L747 bil
    old "Well, a dare is a dare, so..."
    new "B:pla: Uau! A sério?"

    # say L748 pla
    old "A- all right."
    new "A: bil: Hmm, isto não vai ficar assim."

    # say L767 bil
    old "Hmm, this isn't going to stay like this."
    new "B:pla: A - tudo bem."

    # say L773 bil
    old "That's right."
    new "B:bel: W- what? For real?!"

    # say L774 bel
    old "Ughh, fine, let's do it."
    new "T(bel|tu|say): Ughh, está bem, vamos lá."

    # say L783 bel
    old "Yeah, well, here I come."
    new "B:bil: Vamos, para de enrolar e faz."

    # say L796 bel
    old "Ok, I did what you dared me too."
    new "B:bel: Pois bem, aqui vou eu."

    # say L799 bel
    old "What? After you made me do all of that, you can't do it?"
    new "B:bil: O que é isto, a copiar-me outra vez?"

    # say L800 bil
    old "Tsk, of course I can, come on [pla] let's do it!"
    new "T(bil|tu|say): Tsk, claro que posso, vamos lá [pla], vamos fazer isso!"

    # say L811 bel
    old "Are you nervous?"
    new "B:bil: Não consigo acreditar que leves tanto."

    # say L812 bil
    old "Of course not. I was just saying."
    new "T(bil|tu|say): Claro que não. Eu estava só a dizer."

    # say L828 bil
    old "Ok, this has been fun. But what do you say about taking this to the next level?"
    new "B:bil: Claro que não. Eu estava só a dizer."

    # say L830 bel
    old "The next level? Hasn't this been enough?"
    new "B:bil: Ok, isto tem sido divertido. Mas e se subirmos o nível?"

    # say L831 bil
    old "No, I'm talking about something extreme, How about we go to the haunted house here in town?"
    new "A:pla: Casa assombrada?"

    # say L832 pla
    old "Haunted house?"
    new "B:bil: Não, estou a falar de algo extremo. Que tal irmos à casa assombrada aqui na cidade?"

    # say L833 bil
    old "Yeah that's right. There's a house in town with vampires. Why don't we go?"
    new "B:pla: Casa assombrada?"

    # say L834 bel
    old "Ohh, you're talking about the old mansion."
    new "B:bil: Sim, é verdade. Há uma casa na cidade com vampiros. Porque não vamos?"

    # say L836 pla
    old "B- but you said vampires. Which vampires?"
    new "B:bel: Ohh, estás a falar da velha mansão."

    # say L838 bil
    old "There's a legend about that house, that says there are vampires in there."
    new "B: B- mas tu disseste vampiros. Que vampiros?"

    # say L839 bil
    old "All its inhabitants are women, people say that they have been seen kidnapping men, to then suck all of their blood out."
    new "B:bil: Há uma lenda sobre aquela casa, que diz que há vampiros lá dentro."

    # say L840 bil
    old "And leave them completely dry."
    new "B:bil: Todas as suas habitantes são mulheres, dizem que já foram vistas a sequestrar homens para depois lhes sugar todo o sangue."

    # say L842 bil
    old "Besides, it is said that they are all very pale, and apparently they only go out at night. Never in the sunlight. Surely to pick up another victim."
    new "B:bil: E deixa-os completamente secos."

    # say L843 bel
    old "Yeah, yeah, yeah. It's super creepy and spooky, let's go!"
    new "B:bil: Além disso, diz-se que todos são muito pálidos e que só saem à noite. Nunca ao sol. Com certeza para apanhar outra vítima."

    # say L844 pla
    old "Uhh... I- I'm not sure I want to go there."
    new "B:bel: Sim, sim, sim. É super assustador, vamos lá!"

    # say L845 bil
    old "Aww, are you that much of a wuss? Come on, have some guts."
    new "B:pla: Uhh... N-Não tenho a certeza se quero ir lá."

    # say L846 pla
    old "I'm not a wuss... Ok, let's do it then."
    new "B:bil: Aww, és assim tão medricas? Vamos, mostra alguma coragem."

    # say L855 bel
    old "Wow guys, this really feels sinister. It's quite terrifying."
    new "B:pla: Não sou um medricas... Ok, vamos lá então."

    # say L856 pla
    old "Y-y-yeah, this is very scary. Maybe we should head back."
    new "B:bel: Uau, pessoal, isto está mesmo sinistro. É bastante assustador."

    # say L859 pla
    old "W-what? B-but..."
    new "B:bil: E como tu és o Homem-Aranha... Desafio-te a subir ao telhado."

    # say L860 bil
    old "It's a dare, isn't it? We accomplished ours very well."
    new "T(bil|tu|say): É uma coragem, não é? Nós cumprimos a nossa muito bem."

    # say L861 bil
    old "And you seemed to enjoy those a lot. Didn't you? it would be unfair if you chicken out now. Do it!"
    new "B:bil: É uma aposta, não é? Nós cumprimos a nossa muito bem."

    # say L862 pla
    old "Hmph, fine. I'll do it."
    new "B:bil: E parecias ter gostado muito disso. Não foi? Seria injusto se agora te arrepiasses. Faz isso!"

    # say L863 bil
    old "But use all the suit, even with the mask, just like spiderman."
    new "B:pla: Hmph, bem. Vou fazê-lo."

    # say L864 pla
    old "Really? Hmm, Alright."
    new "B:bil: Mas usa todo o fato, até com a máscara, como o Homem-Aranha."

    # say L870 bel
    old "That's it! Yes, you're doing well!"
    new "B:pla: Mesmo? Hmm, Tudo bem."

    # say L873 bil
    old "Keep going! You can't just stop halfway up! You have to make it to the roof!"
    new "B:bel: É isso! Sim, estás a fazer bem!"

    # say L876 pla
    old "I know, ugh! I know!"
    new "B:bil: Continua! Não podes parar a meio! Tens de chegar ao telhado!"

    # say L882 pla
    old "Ok! I made it all the way up! Just wait there, I'm gonna go down again!"
    new "B:pla: Eu sei, ugh! Eu sei!"

    # say L883 bil
    old "Yeah sure! You made it, come down!"
    new "AAAAAAH!!"

    # say L891 pla
    old "AAAAAAH!!"
    new "B:bil: Claro! Conseguiste, desce!"

    # say L896 bel
    old "We're going to get some help! Just hang in there!"
    new "A:pla: W- o que é isto? Onde e- eu estou?"

    # say L909 pla
    old "W- what is this? W- where I-?"
    new "B:bel: Vamos buscar ajuda! Só aguenta mais um pouco!"

    # say L940 pla
    old "Ugh!! My god, what happened? Why does my head hurt so much?"
    new "B: pla: O- o que é isto? O- onde eu-?"

    # say L946 lad
    old "Oh, Hello! You're finally awake, I'm glad you woke up. I was thinking that if you didn't, I might have to call an ambulance."
    new "B:pla: Ugh!! Meu Deus, o que aconteceu? Porque é que a minha cabeça dói tanto?"

    # say L947 pla
    old "Whoa! Ah... W- where am I?"
    new "T(pla|tu|say): Quem! Ah... Onde é que eu estou?"

    # say L948 lad
    old "Calm down, this is my house. You fell in here yesterday while you were playing on our roof."
    new "T(lad|formal|say): Calma, isto é a minha casa. Tu caíste aqui ontem enquanto estavas a brincar no nosso telhado."

    # say L949 pla
    old "Y- your house?"
    new "B:lad: Calma, esta é a minha casa. Tu caíste aqui ontem enquanto estavas a brincar no nosso telhado."

    # say L950 lad
    old "Yes, that's right. Maybe you thought you actually were spiderman?"
    new "B:pla: Y- a tua casa?"

    # say L952 pla
    old "Oh my God! It's morning already?!"
    new "T: Oh meu Deus! Já é de manhã?!"

    # say L953 pla
    old "I- I have to go, [mo1rel] must be worried sick about me."
    new "T(pla|tu|say): I- I tenho que ir, [mo1rel] deve estar muito preocupado comigo."

    # say L955 pla
    old "Y- yes, but don't worry, I promise I'll come back to fix your roof."
    new "B:lad: Tu já estás a ir-te embora?"

    # say L956 lad
    old "Ok, if you say so. Be careful though. You got a big hit there."
    new "B: pla: Y- sim, mas não te preocupes, prometo que vou voltar para consertar o telhado."

    # say L972 mo1
    old "Dear, you're home! Oh my god! You had me so worried. Where were you?!"
    new "B:lad: Ok, se tu dizes. Mas toma cuidado, tu levaste um grande golpe."

    # say L975 mo1
    old "That's not a problem. But why didn't you call to let us know where you were?!"
    new "B:pla: E depois de termos acabado, o Mike convidou-me para ficar na casa dele."

    # say L978 pla
    old "You're right, my bad."
    new "B:mo1: Pois fizeste! Tu és adulto, podes fazer o que quiseres, mas pelo menos telefona para me avisar destas coisas."

    # say L979 mo1
    old "It's ok honey, I'm just happy to see you're safe."
    new "B:pla: Tens razão, foi erro meu."

    # say L986 pla
    old "I would like to rest a little bit more. But I guess I better get to school. I don't want to give Ms. Mia any more reasons to suspend me."
    new "B:pla: Ohh, que dia louco foi ontem. Não posso acreditar que fizemos tudo isso."

    # say L1113 pla
    old "Hey girls, how are you?"
    new "B:pla: Eu queria descansar mais um pouco. Mas acho melhor ir para a escola. Não quero dar à Sr.ª Mia mais motivos para me suspender."

    # say L1117 bil
    old "Are you really ok? We went asking for assistance but when we came back you weren't there."
    new "B:pla: Olá raparigas, como estão?"

    # say L1118 bil
    old "We were very worried because we didn't know where you went."
    new "B:bil: Estás realmente bem? Fomos pedir ajuda mas quando voltámos tu já não estavas lá."

    # say L1119 pla
    old "Yeah, sorry about that. But to be honest I don't know what happened either."
    new "B:bil: Estavamos muito preocupados porque não sabíamos onde tu tinhas ido."

    # say L1120 pla
    old "All I remember was hitting the ground really hard, and you calling out for me. But then I passed out."
    new "T(pla|tu|say): Só me lembro de cair no chão com muita força, e tu a chamar por mim. Depois desmaiei."

    # say L1121 pla
    old "I imagined it was the lady who moved me."
    new "B:pla: A única coisa que me lembro foi de cair no chão com muita força, e tu a chamar por mim. Mas depois desmaiei."

    # say L1123 bil
    old "Lady? You're talking about the vampire?!"
    new "B:pla: Imaginei que fosse a senhora que me moveu."

    # say L1124 pla
    old "Uhhh, I- I don't know, I just met her this morning when I woke up, apparently she took care of me."
    new "T(pla|tu|say): Uhhh, n-não sei, só a conheci esta manhã quando acordei, parece que ela cuidou de mim."

    # say L1125 bel
    old "Whoa! And how was it? Weren't you scared?"
    new "B:pla: Uhhh, eu- eu não sei, só a conheci esta manhã quando acordei, aparentemente ela cuidou de mim."

    # say L1126 pla
    old "Me? Not really? I was only surprised, because she wasn't angry. In fact, she was really nice to me."
    new "T(pla|tu|say): Eu? Nem tanto. Apenas fiquei surpreendido, porque ela não ficou zangada. Na verdade, ela foi muito simpática comigo."

    # say L1127 pla
    old "I promised to come back later and fix the damage I did to her roof."
    new "B: pla: Eu? Nem tanto. Apenas fiquei surpreendido porque ela não ficou zangada. Na verdade, ela foi muito simpática comigo."

    # say L1128 bil
    old "Whoa! Well I guess it's better that way."
    new "B:pla: Prometi voltar mais tarde e reparar os danos que fiz ao telhado dela."

    # say L1130 bel
    old "Yeah, after all, you did ruin her roof. So, it's better if you fix it."
    new "B:bil: Uau! Bem, acho que é melhor assim."

    # say L1132 bil
    old "Yeah, I think I went a little overboard with that last dare."
    new "T(bil|tu|say): Sim, acho que exagerei na última aposta."

    # say L1133 bil
    old "I promise I'll make it up to you next time we play. Right Belle?"
    new "B:bil: Sim, acho que exagerei um bocado nesse último desafio."

    # say L1134 bel
    old "Yeah, for sure."
    new "B:bil: Prometo que compensarei da próxima vez que jogarmos. Certo, Belle?"

    # say L1135 pla
    old "Well, I didn't think I would want to play that again."
    new "B:bel: Claro, com certeza."

    # say L1136 pla
    old "But if it's going to be like you say, then count me in for next time."
    new "B:pla: Bem, não pensei que quisesse jogar isso de novo."

    # say L1138 bel
    old "Well, we have classes now. See you later."
    new "B:pla: Mas se for como tu dizes, então conta comigo para a próxima."

    # say L1139 pla
    old "Alright, see you girls."
    new "B:bel: Bem, temos aulas agora. Até mais."

    # say L1159 pla
    old "Hey, listen, I've been thinking, and I'm sorry about the way things ended up yesterday, me and the girls took it a little too far."
    new "B:pla: Olá Hinn. Estou bem, graças a Deus que hoje consigo ver-te."

    # say L1161 hin
    old "It's ok, actually I wanted to say sorry to you."
    new "B:pla: Oi, escuta, tenho andado a pensar e sinto muito pelo que aconteceu ontem, eu e as raparigas exagerámos um bocado."

    # say L1162 hin
    old "To be honest, I'm still not used to being that open. It's ok when I'm with you and Dr. Johnson."
    new "T: Para ser honesto, ainda não me habituei a ser tão aberto. Fica bem quando estou contigo e com o Dr. Johnson."

    # say L1163 hin
    old "But if things turn sexual when there's other people around, and watching me, I just freeze."
    new "B:hin: Para ser honesto, ainda não me habituei a ser tão aberto. Está bem quando estou contigo e com o Dr. Johnson."

    # say L1164 hin
    old "And yesterday things got a little too dense for my liking, so I couldn't handle it, and took off."
    new "B:hin: Mas se as coisas ficam sexuais quando há outras pessoas por perto, e a observar-me, eu simplesmente fico paralisado."

    # say L1165 hin
    old "S- sorry for leaving like that, I hope I didn't ruin your night."
    new "B:hin: E ontem as coisas ficaram um pouco densas demais para o meu gosto, então não consegui lidar e fui embora."

    # say L1166 pla
    old "No, not at all! You didn't ruin anything."
    new "B:hin: S- sorry for leaving like that, I hope I didn't ruin the tua noite."

    # say L1168 pla
    old "Yes, really. I'm just happy to see you're doing fine."
    new "B: pla: Não, nada disso! Tu não estragaste nada."

    # say L1172 hin
    old "Well, I- I've been thinking... maybe I could talk with Dr. Johnson again, take a couple more lessons from her."
    new "B: Mas... honestamente, não me sinto bem..."

    # say L1173 pla
    old "Really? Do you feel you need it?"
    new "B:hin: Bem, eu... eu tenho pensado... talvez eu possa falar com a Dra. Johnson de novo, tirar mais algumas lições com ela."

    # say L1174 hin
    old "I do. I know she's already helped me a lot. But it can't hurt to keep working on things. There's always room for improvement"
    new "B:pla: Mesmo? Tu sentes que precisas disso?"

    # say L1176 pla
    old "Hmm, well, if you think it's the best thing for you, I support you completely."
    new "B:hin: Eu sei. Sei que ela já me ajudou muito. Mas não faz mal continuar a trabalhar nisso. Há sempre espaço para melhorar."

    # say L1177 hin
    old "Thank you, your support does mean a lot to me. Also, would you come with me? To the sessions? I think it's easier with you there."
    new "B:pla: Hmm, bem, se tu achas que é o melhor para ti, apoio-te completamente."

    # say L1178 pla
    old "Of course I will, if you need me, I'm more than happy to help you."
    new "B:hin: Obrigado, o teu apoio significa muito para mim. E, tu vias comigo? Às sessões? Acho que é mais fácil com tu lá."

    # say L1182 hin
    old "Yeah, if not Ms. Mia will be angry."
    new "B:pla: Oh! Olha a hora, acho melhor irmos para a aula."

    # say L1183 pla
    old "You are right. let's go."
    new "B:hin: Sim, se não a senhora Mia vai ficar zangada."

    # say L1198 pla
    old "Good morning ma'am, how are you?"
    new "B:pla: Tens razão. Vamos."

    # say L1199 lad
    old "Ohh! This is a surprise... I didn't think you were gonna come back."
    new "B:pla: Bom dia, como está?"

    # say L1200 pla
    old "No, I couldn't do that. I said I was gonna fix it, and that's what I'll do."
    new "B:lad: Ohh! Que surpresa... Não pensei que fosses voltar."

    # say L1201 lad
    old "Well, isn't that nice?"
    new "B: Não, não posso fazer isso. Disse que ia arranjá-lo, e é isso que vou fazer."

    # say L1202 lad
    old "Truth be told, I had already prepared some tools to fix it myself. But if you're gonna do it I'll lend them to you."
    new "B:lad: Bem, não é nada mal?"

    # say L1203 pla
    old "Thank you ma'am. I promised it's going to be as good as new when I'm done."
    new "B:lad: A verdade é que já tinha preparado algumas ferramentas para consertar eu mesmo. Mas se vais fazer tu, empresto-as-te."

    # say L1204 lad
    old "That's really nice of you, thank you."
    new "B:pla: Obrigado, senhora. Prometo que vai ficar como novo quando acabar."

    # say L1205 pla
    old "So, where are the tools and materials?"
    new "B:lad: É muito simpático da tua parte, obrigado."

    # say L1206 lad
    old "Oh, they're in the next room, in the garage."
    new "B:pla: Então, onde estão as ferramentas e os materiais?"

    # say L1207 lad
    old "The damage isn't that small, so it's going to take you a while to finish completely, you may have to come a couple more times."
    new "B:lad: Oh, eles estão no quarto ao lado, na garagem."

    # say L1209 pla
    old "That's fine, it was my fault, so it doesn't matter to me how much time it takes. I'll fix it completely."
    new "B:lad: O dano não é assim tão pequeno, por isso vai demorar um bocado a terminar completamente, pode ser que tenhas de vir mais umas vezes."

    # say L1210 pla
    old "And once again ma'am. I'm sorry for doing that."
    new "T(pla|tu|say): E mais uma vez, peço desculpa por isso, senhora."

    # say L1211 lad
    old "It's ok, what's important it's that you came back, and by the way, I'm Alcina Dimitrescu."
    new "B:pla: E mais uma vez, peço desculpa, senhora. Sinto muito por ter feito isso."

    # say L1214 lad
    old "Oh don't worry, nice to meet you too [pla]..."
    new "B:pla: Ohh desculpa... Não te disse o meu nome. Sou [pla], é um prazer conhecer-te."

    # say L1216 pla
    old "All right, thank you."
    new "B:lad: Vou estar no quarto ao lado se precisares de mim. Não vou tomar mais do teu tempo e deixo-te começar o teu trabalho..."

    # say L1227 lad
    old "Congratulations! You made a lot of progress today."
    new "B:pla: Muito bem, obrigado."

    # say L1228 lad
    old "You're very fast, and it's all very well done."
    new "B:lad: Parabéns! Fizeste muitos progressos hoje."

    # say L1229 pla
    old "Thank you ma'am. I'm glad you like my progress."
    new "B:lad: Tu és muito rápido e tudo está muito bem feito."

    # say L1230 pla
    old "I'm sure if I keep going at this pace it'll be ready very soon."
    new "B:pla: Obrigado, senhora. Fico contente por gostares do meu progresso."

    # say L1231 lad
    old "Sure, I have no doubt about it. Very nice."
    new "B:pla: Tenho a certeza de que, se continuar a este ritmo, ficará pronto muito em breve."

    # say L1232 pla
    old "Thank you ma'am."
    new "B:lad: Claro, não tenho dúvidas. Muito bonito."

    # say L1233 pla
    old "It's a little late, so I think I should be going home. But I'll come back soon."
    new "T(tu|dizer): É um pouco tarde, então acho que devo ir para casa. Mas volto logo."

    # say L1234 lad
    old "Oh yeah, don't worry, go home, I'll see you later then."
    new "B:pla: É um pouco tarde, por isso acho que devo ir para casa. Mas voltarei em breve."

    # say L1247 pla
    old "Hmm, this is harder than I expected."
    new "B:lad: Oh yeah, não te preocupes, vai para casa, vejo-te mais tarde então."

    # say L1248 pla
    old "Sorry for doing so little. But I'm sure next time I'll progress a lot more."
    new "B:pla: Hmm, isto é mais difícil do que eu esperava."

    # say L1249 lad
    old "Well, you didn't do much today, but I understand, it's a big job after all. "
    new "B:pla: Desculpa por ter feito tão pouco. Mas tenho a certeza de que da próxima vez vou avançar muito mais."

    # say L1250 lad
    old "Don't worry about the progress, I know you'll make it."
    new "B:lad: Bem, não fizeste muito hoje, mas compreendo, é um trabalho grande afinal."

    # say L1251 pla
    old "Yeah, thank you. I'll come back later and keep working on it."
    new "B:lad: Não te preocupes com o progresso, sei que vais conseguir."

    # say L1252 lad
    old "Yes, it's a little late, so you should go home and come another time."
    new "B:pla: Sim, obrigado. Vou voltar mais tarde e continuar a trabalhar nisso."

    # say L1253 pla
    old "You are right. Thank you."
    new "T(pla|tu|say): Tens razão. Obrigado."

    # say L1263 pla
    old "Hmm, listen, ma'am before I leave, may I ask you something?"
    new "B:pla: Tens razão. Obrigado."

    # say L1264 lad
    old "And what may that be?"
    new "B:pla: Hmm, escuta, senhora, antes de eu ir, posso perguntar-te uma coisa?"

    # say L1265 pla
    old "Well, I'm a little ashamed to admit this."
    new "B:lad: E o que pode ser isso?"

    # say L1266 pla
    old "But the reason I crashed into your living room the other day was because a couple of my friends dared me to climb your roof."
    new "B:pla: Bem, sinto-me um pouco embaraçado em admitir isto."

    # say L1268 lad
    old "And why did they do that?"
    new "B:pla: Mas a razão pela qual eu caí no teu quarto de estar na outra dia foi porque uns amigos me desafiaram a subir ao teu telhado."

    # say L1269 pla
    old "Well... it's because there are some rumors about this house being haunted."
    new "B:lad: E porquê que fizeram isso?"

    # say L1271 lad
    old "Haunted you say?"
    new "B:pla: Bem... é porque há alguns rumores sobre esta casa estar assombrada."

    # say L1272 pla
    old "Yeah... I mean, I don't believe them now, but that's what they say."
    new "T(pla|tu|say): Sim... Quero dizer, não acredito agora, mas é o que dizem."

    # say L1273 pla
    old "And, that's not all of it..."
    new "B:pla: Sim... Quero dizer, não acredito neles agora, mas é o que eles dizem."

    # say L1274 lad
    old "It isn't?"
    new "B:pla: E, isso não é tudo..."

    # say L1276 pla
    old "Well, apparently there's a story about a group of vampires living here..."
    new "B:lad: Não é?"

    # say L1277 lad
    old "Is that so? And what do you think? Do I look like a vampire to you?"
    new "B:pla: Bem, parece que há uma história sobre um grupo de vampiros que vive aqui..."

    # say L1278 pla
    old "O- of course not. I just wanted to apologize for the reason I climbed your roof. Because the rumor isn't true, right?"
    new "B:lad: É mesmo? E o que tu achas? Pareço um vampiro para ti?"

    # say L1279 lad
    old "Hehe, of course not. Seriously, kids these days have some imagination."
    new "B:pla: O- obviamente não. Só queria pedir desculpa pela razão pela qual subi ao teu telhado. Porque o boato não é verdade, certo?"

    # say L1280 lad
    old "But now it's not the time for that, it's very late and I think you need to go home."
    new "B:lad: Hehe, claro que não. A sério, os miúdos de hoje em dia têm imaginação."

    # say L1282 pla
    old "You're right, sorry for bothering you with all of this."
    new "T(pla|tu|say): Tens razão, desculpa por te ter incomodado com tudo isto."

    # say L1283 pla
    old "And don't worry, I'll come soon to keep working on the roof."
    new "B:pla: Tens razão, desculpa por te ter incomodado com tudo isto."

    # say L1284 lad
    old "I really appreciate your help. Have a good night."
    new "B:pla: E não te preocupes, vou voltar logo para continuar a trabalhar no telhado."

    # say L1304 lad
    old "Oh perfect. Well, I'll leave you to it. If you need me, I'm in the room next door."
    new "B:pla: Sim, senhora. Vou começar já. Assim posso terminar o mais rápido possível."

    # say L1310 pla
    old "Excuse ma'am, but before I go home, there's something else I'd like to ask you about."
    new "T(pla|tu|say): Desculpe, senhora, mas antes de ir para casa, há algo mais que gostaria de lhe perguntar."

    # say L1312 lad
    old "Perhaps another rumor?"
    new "B:pla: Desculpe, senhora, mas antes de eu ir para casa, há mais uma coisa que gostaria de lhe perguntar."

    # say L1313 pla
    old "No, no. Nothing like that. It's just... After I fell and passed out. I remember waking up for a brief moment. "
    new "B:lad: Talvez outro boato?"

    # say L1314 pla
    old "And I could swear I saw you with someone else, watching me."
    new "T(pla|tu|say): E juro que vi tu com outra pessoa, a observar-me."

    # say L1316 lad
    old "S- someone else, heh... What do you mean?"
    new "B:pla: E eu podia jurar que te vi com outra pessoa, a observar-me."

    # say L1317 pla
    old "Well, I saw two young ladies, they kinda looked like you. But I'm not sure..."
    new "B:lad: S- someone else, heh... O que queres dizer?"

    # say L1320 pla
    old "Are you sure? It felt so real..."
    new "B:lad: Acho que deves ter visto algum tipo de alucinação ou algo assim."

    # say L1321 lad
    old "Yes I'm sure. Now, It's getting very late, so you should go home now."
    new "B:pla: Tens a certeza? Pareceu tão real..."

    # say L1322 pla
    old "Hmm, ok. I think you're right. Bye ma'am."
    new "B:lad: Sim, tenho a certeza. Agora, já está muito tarde, por isso deves ir para casa."

    # say L1323 lad
    old "Have a good night, [pla]."
    new "Boa noite, [pla]."

    # say L1339 lad
    old "Wow! Look at how much you have done already! I think you only need to come back one more time and you will have finished."
    new "B:pla: Ok! Isso é tudo para hoje. Está quase feito."

    # say L1340 pla
    old "Thank you ma'am, I'm happy you like how the repairs are going, I also think I only need to come once more, and it'll be ready."
    new "Obrigado, senhora, fico contente que goste do progresso das reparações. Também penso que só preciso de vir mais uma vez e ficará pronto."

    # say L1341 lad
    old "I'm astounded at how fast you are, you're a very good worker."
    new "B:pla: Muito obrigado, senhora, fico contente que goste do progresso das reparações. Acho que só preciso vir mais uma vez e ficará pronto."

    # say L1342 pla
    old "Thank you very much!"
    new "B:lad: Estou impressionado com a tua rapidez, és um trabalhador excelente."

    # say L1343 pla
    old "Well, I think I'll head home. I'll be sure to come back and finish."
    new "B:pla: Muito obrigado!"

    # say L1352 lad
    old "A problem? No, no, nothing like that, I just wanted to thank you once again for how well the repairs are going."
    new "B:pla: Sim? Há algum problema?"

    # say L1353 lad
    old "Being completely honest, I didn't think you were actually going to do it. But I'm glad I was wrong."
    new "B:lad: Um problema? Não, não, nada disso, só queria agradecer-te mais uma vez pelo bom andamento das reparações."

    # say L1354 pla
    old "Well, it's not a problem at all. It was my fault that the roof broke in the first place, I feel like it's only fair that I handle the repairs."
    new "B:lad: A ser completamente honesto, não pensei que tu fosses realmente fazer isso. Mas fico contente por estar enganado."

    # say L1356 lad
    old "Well, I'm happy that you're such an upstanding young man."
    new "B:pla: Bem, não é problema nenhum. Foi culpa minha que o telhado se partiu, sinto que é justo que eu me ocupe das reparações."

    # say L1357 lad
    old "And another thing..."
    new "B:lad: Bem, fico contente por seres um jovem tão correto."

    # say L1358 pla
    old "Yes?"
    new "A:lad: É sobre aqueles rumores de que falaste. A verdade é que também já ouvi falar deles."

    # say L1359 lad
    old "It's about those rumors that you mentioned. The truth is I have actually heard of them as well."
    new "Tu sabias disso?"

    # say L1360 pla
    old "You knew about them?"
    new "T(pla|tu|say): Tu sabias disso?"

    # say L1361 lad
    old "Of course I did. it's difficult not to notice when people look at me and murmur wherever I go."
    new "B:pla: Tu sabias deles?"

    # say L1362 lad
    old "But some people are even worse, they come to my house and try to sneak in, or to get pics of the 'vampire lady'."
    new "B:lad: Claro que sim. É difícil não reparar quando as pessoas me olham e sussurram por onde passo."

    # say L1363 lad
    old "It's really stressful, so I was a bit cautious of your intentions at first."
    new "B:lad: Mas algumas pessoas são ainda piores, vêm à minha casa e tentam entrar às escondidas ou tirar fotos da 'senhora vampira'."

    # say L1364 pla
    old "Ohh, I- I see, I'm sorry things are like that. It must be so awkward to have to deal with that all the time."
    new "B:lad: É realmente stressante, por isso fiquei um pouco cautelosa com as tuas intenções no início."

    # say L1366 lad
    old "Oh yeah, it's tremendously stressful... Actually, there is a reason why those rumours exist."
    new "B:pla: Ohh, eu- eu percebo, desculpa se as coisas são assim. Deve ser tão embaraçante ter de lidar com isso o tempo todo."

    # say L1367 pla
    old "Uhh? What do you mean?"
    new "B:lad: Oh yeah, é extremamente stressante... Na verdade, há uma razão para esses rumores existirem."

    # say L1368 lad
    old "Well, as I said, I was a bit cautious of you, but I think you've managed to keep your word."
    new "B:pla: Huh? O que queres dizer?"

    # say L1369 lad
    old "And I realize I haven't been completely honest with you..."
    new "B:lad: Bem, como eu disse, estava um pouco cauteloso contigo, mas acho que conseguiste cumprir a tua palavra."

    # say L1370 lad
    old "So, let me tell you the truth; it would be good if at least one person in town knows things as they really are."
    new "A:lad: Eu sofro de uma condição rara na qual o meu corpo é incapaz de produzir um certo tipo de aminoácido."

    # say L1373 lad
    old "I suffer from a rare condition in which my body is unable to produce a certain type of amino acid."
    new "B:lad: Então, deixa-me dizer-te a verdade; seria bom que pelo menos uma pessoa na cidade soubesse as coisas como realmente são."

    # say L1376 lad
    old "Haha, it means that I'm unable to produce and store a type of protein that the body needs to function properly."
    new "T(lad|formal|say): Haha, significa que não consigo produzir e armazenar um tipo de proteína que o corpo precisa para funcionar corretamente."

    # say L1378 pla
    old "Ohh..."
    new "B:lad: Haha, isso significa que não consigo produzir e armazenar um tipo de proteína que o corpo precisa para funcionar corretamente."

    # say L1379 lad
    old "As I said, it's not all of them, I'd be dead if it was like that. But this one is crucial nonetheless."
    new "B:pla: Ohh..."

    # say L1380 lad
    old "Nor am I able to absorb it from the usual sources, like meat and vegetables."
    new "B:lad: Como eu disse, não são todos, eu estaria morto se fosse assim. Mas este é crucial mesmo assim."

    # say L1381 pla
    old "So, does that mean your health is in danger?"
    new "B:lad: Nem eu sou capaz de absorvê-lo das fontes habituais, como carne e legumes."

    # say L1382 lad
    old "Hmm kind of. My body it's very delicate to certain things. For example, I'm unable to go directly into the sunlight."
    new "B:pla: Então, isso significa que a tua saúde está em perigo?"

    # say L1383 lad
    old "If I did, I would start suffering from strong allergic reactions. So, every time I go outside it has to be during the nighttime."
    new "B:lad: Hmm, mais ou menos. O meu corpo é muito sensível a certas coisas. Por exemplo, não posso expor-me diretamente ao sol."

    # say L1384 pla
    old "Ohh, so, is that why people think you're a vampire?"
    new "B:lad: Se eu fizesse, começaria a sofrer de fortes reações alérgicas. Por isso, sempre que saio, tem que ser durante a noite."

    # say L1385 lad
    old "Well, that and my appearance, that's also the result of my disease."
    new "B:pla: Ohh, então, é por isso que as pessoas pensam que és um vampiro?"

    # say L1386 lad
    old "This amino acid helps with the creation of melanin, which is what gives colour to the skin."
    new "B:lad: Bem, isso e a minha aparência, também são resultado da minha doença."

    # say L1387 lad
    old "So I'm very white, and my eyes are pale."
    new "B:lad: Este aminoácido ajuda na criação de melanina, que é o que dá cor à pele."

    # say L1388 pla
    old "Oh, I get it now."
    new "B:lad: Sou muito pálido, e os meus olhos são claros."

    # say L1389 lad
    old "Yeah, and I understand them, if somebody who looks like me it's only seen outside at night. And well... people talk..."
    new "B:pla: Ah, percebi agora."

    # say L1391 pla
    old "But, it's not fair, I mean, you can't judge people just because of their appearance."
    new "B:lad: Sim, e eu entendo, se alguém como eu só é visto à noite. E bem... as pessoas falam..."

    # say L1392 lad
    old "Well, is not just that. The thing is, since I'm unable to produce this substance, I have to obtain it from a different source."
    new "B:pla: Mas, não é justo, quero dizer, não podes julgar as pessoas só pela aparência."

    # say L1393 pla
    old "But you said you couldn't get it from food either..."
    new "B:lad: Bem, não é só isso. O problema é que, como não consigo produzir esta substância, tenho de a obter de uma fonte diferente."

    # say L1394 lad
    old "That's right, I can't get it from food. But there's something else that can help me."
    new "B:pla: Mas tu disseste que não conseguias obtê-lo dos alimentos..."

    # say L1395 lad
    old "You see, for whatever reason I can actually receive the proteins that I need from semen."
    new "B:lad: É verdade, não consigo obtê-las dos alimentos. Mas há algo mais que pode ajudar-me."

    # say L1397 lad
    old "So, I made a deal with some men from town that were willing to help me. That sustained me for a while..."
    new "B:lad: Vês, por alguma razão consigo realmente absorver as proteínas de que preciso do sêmen."

    # say L1398 pla
    old "Ohh, I see..."
    new "B:lad: Então, fiz um acordo com alguns homens da cidade que estavam dispostos a ajudar-me. Isso me sustentou por um tempo..."

    # say L1399 lad
    old "But the problem is that for whatever reason, when I touch a man, it has a very strong effect on them."
    new "A:pla: Eles também pegaram a doença?"

    # say L1400 pla
    old "They caught the disease too?"
    new "B:lad: Mas o problema é que, por alguma razão, quando toco num homem, isso tem um efeito muito forte nele."

    # say L1401 lad
    old "What? No, no, it's not that."
    new "O que tenho não é contagioso, mas causa certos efeitos nos homens."

    # say L1402 lad
    old "What I have is not contagious, but it does cause certain effects on men."
    new "B:lad: O quê? Não, não, não é isso."

    # say L1404 lad
    old "So anytime one of them helped me. They would be very drained afterwards."
    new "B:lad: O que tenho não é contagioso, mas causa certos efeitos nos homens."

    # say L1405 lad
    old "They ended up looking pale and famished. That's probably where the vampire myth mostly comes from."
    new "B:lad: Então, sempre que um deles me ajudava, ficavam muito esgotados depois."

    # say L1406 pla
    old "Oh, I understand..."
    new "B:lad: Acabaram por parecer pálidos e famintos. É provavelmente daí que vem grande parte do mito dos vampiros."

    # say L1408 lad
    old "And as you know, there is a very large religious community in this town."
    new "B:pla: Oh, percebo..."

    # say L1409 lad
    old "Many women got worried that I would hurt their husbands, and even worse, that I would steal them."
    new "B:lad: E como sabes, há uma comunidade religiosa muito grande nesta cidade."

    # say L1410 lad
    old "And seeing how tired the men were after helping me, the rumors began to circulate."
    new "B:lad: Muitas mulheres ficaram preocupadas que eu pudesse magoar os seus maridos, e pior ainda, que eu os roubasse."

    # say L1411 pla
    old "I see, I think I now understand better where the legend comes from."
    new "B:lad: E vendo como os homens estavam cansados depois de me ajudar, os rumores começaram a circular."

    # say L1412 pla
    old "But still, your disease is no reason for them to be talking that way about you."
    new "B:pla: Entendo, acho que agora compreendo melhor de onde vem a lenda."

    # say L1413 pla
    old "I'm sorry ma'am, because not only do you have to take care of your condition. You also have to deal with the town's scorn."
    new "B:pla: Mas ainda assim, a tua doença não é razão para falarem de ti dessa maneira."

    # say L1415 lad
    old "It's really nice of you to say that, thank you. But I'm used to it already."
    new "B:pla: Sinto muito, senhora, porque não só tem de cuidar da sua condição. Também tem de lidar com o desprezo da cidade."

    # say L1416 lad
    old "The only thing that really affects me is that I haven't been able to get the protein I need as of late."
    new "B:lad: É muito simpático da tua parte dizer isso, obrigado. Mas já me habituei."

    # say L1417 pla
    old "Wait, so does that mean nobody is helping you right now? So, how do you meet your protein needs then?"
    new "B:lad: A única coisa que realmente me afeta é não ter conseguido obter a proteína de que preciso ultimamente."

    # say L1418 lad
    old "Hmm, not really, it is true that nobody comes here anymore. "
    new "B:pla: Espera, então isso significa que ninguém está a ajudar-te agora? E como é que cumpres as tuas necessidades proteicas, então?"

    # say L1419 lad
    old "But I have a deal with the hospital, having a certificate for my condition allows me to receive some semen supplies from them."
    new "B:lad: Hmm, não realmente, é verdade que ninguém vem aqui anymore."

    # say L1420 lad
    old "It all comes from donation to the sperm bank of the hospital. They give them to me because it's for the treatment of a medical condition."
    new "B:lad: Mas tenho um acordo com o hospital, ter um certificado para a minha condição permite-me receber algumas fornecimentos de sêmen deles."

    # say L1422 pla
    old "Uhh, I see."
    new "B:lad: Tudo vem da doação ao banco de esperma do hospital. Eles dão-me porque é para o tratamento de uma condição médica."

    # say L1423 lad
    old "It's not perfect, but it kind of works."
    new "A:lad: Então, percebes agora? Porque é que as pessoas acreditam nessa lenda? E onde é que esses rumores começaram?"

    # say L1424 lad
    old "So, you see now? Why do people believe in that legend? And where did those rumours start?"
    new "B:lad: Não é perfeito, mas funciona mais ou menos."

    # say L1425 pla
    old "Yeah, I can see it now, but I don't think it's fair!"
    new "B:lad: Então, vês agora? Porque é que as pessoas acreditam nessa lenda? E onde é que esses rumores começaram?"

    # say L1426 lad
    old "You're right, it isn't, but that's how things are."
    new "B:pla: Sim, consigo ver isso agora, mas não acho justo!"

    # say L1427 lad
    old "And at least now you know the truth and are willing to talk to me."
    new "B:lad: Tens razão, não é, mas é assim que as coisas são."

    # say L1428 pla
    old "Hmm, actually... I don't know if you're ok with me saying this."
    new "B:lad: E pelo menos agora tu sabes a verdade e estás disposto a falar comigo."

    # say L1429 pla
    old "But I think I could do more than just listen to you."
    new "B:pla: Hmm, na verdade... não sei se estás bem comigo a dizer isto."

    # say L1430 pla
    old "If you're ok with me doing it, I would like to help you."
    new "B:pla: Mas acho que posso fazer mais do que apenas ouvir-te."

    # say L1432 pla
    old "I mean, you said that what you get from the hospital helps, but is not enough, right?"
    new "B:pla: Se estiveres bem com isso, eu gostava de te ajudar."

    # say L1433 pla
    old "So, I want to help you."
    new "T(pla|tu|say): Então, quero ajudar-te."

    # say L1435 lad
    old "That's really nice of you to say, but I don't think you understand."
    new "T(lad|formal|say): É muito gentil da tua parte, mas acho que não percebes."

    # say L1437 lad
    old "I told you that the men who helped me were very drained after doing it."
    new "B:lad: É muito simpático da tua parte dizer isso, mas não acho que percebas."

    # say L1438 pla
    old "Uhh... I mean, I could just do it in a cup or something and give it to you, right?"
    new "T(pla|tu|say): Hmm... Quero dizer, eu podia fazer num copo ou algo assim e dar-te, certo?"

    # say L1439 lad
    old "Not really, you see, that's the problem with the sperm I get from the hospital."
    new "B:pla: Hum... Quero dizer, eu podia fazer num copo ou algo assim e dar-te, certo?"

    # say L1440 lad
    old "I don't only get what I need from the semen, but also from the contact with the penis."
    new "B:lad: Não, vês, esse é o problema com o sêmen que recebo do hospital."

    # say L1441 lad
    old "So if I only receive your semen, I won't be able to extract the necessary amount."
    new "B:lad: Não só obtenho o que preciso do sêmen, mas também do contacto com o pénis."

    # say L1443 pla
    old "Well, I still think we can maybe do a small test and see how we do."
    new "B:lad: Então, se eu só receber o teu sêmen, não vou conseguir extrair a quantidade necessária."

    # say L1444 lad
    old "I don't know. Are you sure?"
    new "B:pla: Bem, ainda penso que podemos fazer um pequeno teste e ver como nos sai."

    # say L1445 pla
    old "Yeah, I think so. I really want to help you in any way I can."
    new "B:lad: Não sei. Tens a certeza?"

    # say L1446 lad
    old "Good, then I guess we can try testing how it goes."
    new "B:pla: Sim, acho que sim. Quero mesmo ajudar-te em tudo o que puder."

    # say L1447 pla
    old "Great, so let's do it."
    new "B:lad: Ótimo, então acho que podemos testar como isso vai."

    # say L1448 lad
    old "All right, then take out your pants."
    new "B:pla: Ótimo, então vamos lá."

    # say L1457 lad
    old "I must say I'm impressed young man."
    new "A:lad: Tu tens um dos maiores pénis que já vi."

    # say L1458 lad
    old "You got one of the biggest penises I have ever seen."
    new "B:lad: Tenho de dizer que estou impressionado, rapaz."

    # say L1459 lad
    old "It's impressive."
    new "A:pla: Uhh... O- obrigado, senhora... Acho que sim."

    # say L1460 pla
    old "Uhh... T- thank you ma'am... I guess."
    new "B:lad: É impressionante."

    # say L1472 pla
    old "It's good that you can feel better ma'am. I'll do it again if you need me to."
    new "B:pla: Uhh... Obrigado... Acho eu."

    # say L1473 lad
    old "Hmm, you seem to be very fine. Normally when I do this with a man, they look very tired afterwards. I wonder if it's because of your age."
    new "B:pla: É bom que tu te sintas melhor, senhora. Farei de novo se precisares."

    # say L1475 pla
    old "I don't know what it may be. But I am a little tired. Maybe I should go home for today. But I'll come back to finish the roof."
    new "B:lad: Hmm, pareces estar muito bem. Normalmente quando faço isto com um homem, eles ficam muito cansados depois. Deve ser por causa da tua idade."

    # say L1476 lad
    old "Ok, just remember to drink a lot of water, and eat as much as you can."
    new "B: pla: Não sei o que possa ser. Mas estou um pouco cansado. Talvez devesse ir para casa hoje. Mas voltarei para terminar o telhado."

    # say L1477 lad
    old "You may not look tired, but I'm sure it must've had some effect on you. Be sure to rest."
    new "B:lad: Ok, lembra-te de beber muita água e de comer o máximo que conseguires."

    # say L1478 pla
    old "I'll do, don't worry. See you later Lady Dimitrescu."
    new "B:lad: Podes não parecer cansado, mas tenho a certeza de que isso te deve ter afetado. Certifica-te de descansar."

    # say L1496 pla
    old "Good morning Lady Dimitrescu! I've come to continue repairing the roof."
    new "B:pla: Vou fazer, não te preocupes. Até mais tarde, Lady Dimitrescu."

    # say L1497 lad
    old "Good morning."
    new "B:pla: Bom dia, Lady Dimitrescu! Vim continuar a reparar o telhado."

    # say L1498 lad
    old "You know, I must say, you don't look very tired at all. Even though I'm certain I took a lot from you."
    new "B:lad: Bom dia."

    # say L1500 pla
    old "(Hmm, I wonder if it's because of the magic power. Maybe it protected me from the effects.)"
    new "B:lad: Sabes, devo dizer que não pareces nada cansada. Mesmo sabendo que tirei muito de ti."

    # say L1501 pla
    old "I don't really know what to tell you, I actually don't feel bad at all."
    new "B: pla: (Hmm, será por causa do poder mágico. Talvez me tenha protegido dos efeitos.)"

    # say L1502 lad
    old "This is a surprise. Are you sure you're ok to work on the roof today?"
    new "B:pla: Não sei bem o que te dizer, na verdade não me sinto nada mal."

    # say L1504 pla
    old "Yes, don't worry, I feel great, I'm going to get to it right away. So, I can finish it as soon as I can."
    new "B:lad: Isto é uma surpresa. Tens a certeza de que estás bem para trabalhar no telhado hoje?"

    # say L1517 lad
    old "This is great! You really did it! Thank you so much, it's fantastic that you put in all this effort. "
    new "B:pla: Sim, não te preocupes, estou a sentir-me ótimo, vou começar já. Assim, posso terminá-lo o mais rápido possível."

    # say L1518 lad
    old "It looks even better than it was before."
    new "B:lad: Isto é fantástico! Tu realmente o fizeste! Muito obrigado, é incrível que tenhas posto todo este esforço."

    # say L1519 pla
    old "I'm happy you like it ma'am. It makes all of that effort worth it."
    new "T: Fico feliz que gostes, senhora. Torna todo o esforço compensador."

    # say L1520 lad
    old "I don't know how to repay you."
    new "B:pla: Fico feliz que tenhas gostado, senhora. Torna todo o esforço compensador."

    # say L1521 pla
    old "Oh no, you don't need to pay me or anything. After all, I did the initial damage."
    new "B:lad: Não sei como te agradecer."

    # say L1525 lad
    old "Ohh, I wouldn't get angry."
    new "B:pla: Mais uma vez, peço desculpa por ter danificado o telhado e agradeço a tua paciência. Isto demorou um bocado, mas tu nunca te zangaste comigo."

    # say L1526 lad
    old "As I told you, at this point I'm used to people just trying to take a peek into my house, so I was just annoyed when it happened"
    new "B:lad: Ohh, não te zangues."

    # say L1527 lad
    old "But you've proven to me that you're a stand up young man. I'm happy I got to meet you."
    new "B:lad: Como te disse, a esta altura já estou habituado a pessoas que tentam espreitar para dentro da minha casa, por isso fiquei apenas irritado quando aconteceu."

    # say L1528 pla
    old "Thank you ma'am, if there's anything else I can do for you, please tell me. I'm more than happy to do it."
    new "B:lad: Mas tu provaste-me que és um rapaz de confiança. Estou feliz por ter-te conhecido."

    # say L1529 lad
    old "Well... Now that you mention it, there might be..."
    new "B:pla: Muito obrigado, senhora. Se houver mais alguma coisa que eu possa fazer por si, por favor, diga-me. Estou mais do que disposto a fazê-lo."

    # say L1530 pla
    old "Really? If that's the case, please tell me. I'll do my best to help you."
    new "B:lad: Bem... Agora que mencionas, pode ser que haja..."

    # say L1531 lad
    old "You see, since you don't seem to be at all affected about the help you already gave me. I was wondering if I can ask for your help again."
    new "B:pla: Mesmo? Se for esse o caso, por favor, diz-me. Vou fazer o meu melhor para te ajudar."

    # say L1532 lad
    old "But this time it might be a little different."
    new "B:lad: Vês, como não pareces nada afetado pela ajuda que já me deste. Estava a pensar se posso pedir a tua ajuda de novo."

    # say L1534 pla
    old "Different? How?"
    new "B:lad: Mas desta vez pode ser um pouco diferente."

    # say L1535 lad
    old "Let me explain, I can assimilate a lot through my digestive system, but the most efficient way of taking in the protein content is through my uterus."
    new "T(lad|formal|say): Deixa-me explicar, posso assimilar muito através do meu sistema digestivo, mas a forma mais eficiente de absorver o conteúdo proteico é através do meu útero."

    # say L1536 lad
    old "Because that way my body can absorb it better."
    new "B:lad: Deixa-me explicar, posso assimilar muito através do meu sistema digestivo, mas a forma mais eficiente de absorver o conteúdo proteico é através do meu útero."

    # say L1537 pla
    old "Wow, does that mean you have to have sex with me?"
    new "B:lad: Porque assim o meu corpo absorve melhor."

    # say L1538 lad
    old "Well, only if you are okay with that, of course."
    new "B:pla: Wow, isso significa que tens de ter sexo comigo?"

    # say L1540 pla
    old "Hmm... Well, if that actually helps you, and it's better for you, sure."
    new "B:lad: Bem, claro, só se tu estiveres bem com isso."

    # say L1541 pla
    old "After all, I did promise I would help you. didn't I?"
    new "B:pla: Hmm... Bem, se isso realmente te ajuda, e é melhor para ti, claro."

    # say L1542 lad
    old "Perfect! Thank you so much!"
    new "B:pla: Afinal, prometi que te ajudaria, não é verdade?"

    # say L1543 lad
    old "Hmm, come with me to the stairs..."
    new "B:lad: Perfeito! Muito obrigado!"

    # say L1559 lad
    old "That was fantastic, thank you! You have no idea how much you help me."
    new "B:lad: Hmm, vem comigo para as escadas..."

    # say L1560 pla
    old "I'm happy to help... and to be honest I enjoyed it too."
    new "T(pla|tu|say): Fico feliz em ajudar... e a ser sincero, também gostei."

    # say L1561 lad
    old "It's very interesting that you don't get tired at all doing this with me."
    new "B:pla: Estou feliz por ajudar... e a ser sincero, também gostei."

    # say L1562 lad
    old "Maybe that could be of help..."
    new "T(lad|formal|say): Talvez isso possa ser útil..."

    # say L1563 pla
    old "Uhh, what do you mean?"
    new "A:lad: Bem, há algo que tenho de te dizer."

    # say L1564 lad
    old "Well, there's something I must let you know."
    new "A:lad: Tu te lembras do que me contaste sobre a noite em que caíste aqui? Que viste eu com duas outras raparigas?"

    # say L1567 lad
    old "Do you remember what you told me about the night you fell in here? That you saw me with two other girls?"
    new "B:lad: Bem, há algo que tenho de te dizer."

    # say L1568 pla
    old "Yeah, the girls from my dream."
    new "B:lad: Tu te lembras do que me disseste sobre a noite em que caíste aqui? Que me viste com duas outras raparigas?"

    # say L1570 lad
    old "Well, actually they're my daughters. Or at least that's what I call them."
    new "B:pla: Sim, as raparigas do meu sonho."

    # say L1571 lad
    old "You see, years ago I found out I'm not the only person with my condition."
    new "B:lad: Na verdade, são minhas filhas. Ou pelo menos é o que eu chamo a elas."

    # say L1572 lad
    old "There are some other people, and I decided to help them. That's why I have this mansion, to receive people like me, and give them a hand."
    new "B:lad: Vês, há anos descobri que não sou a única pessoa com a minha condição."

    # say L1573 pla
    old "Really? So, you live with several people here? I haven't seen them."
    new "B:lad: Existem outras pessoas, e decidi ajudá-las. É por isso que tenho esta mansão, para receber pessoas como eu e dar-lhes uma mão."

    # say L1574 lad
    old "Right now it's only me and my two daughters. With the years some have come and go."
    new "B:pla: Mesmo? Então, tu vives aqui com várias pessoas? Não as tenho visto."

    # say L1575 lad
    old "We communicate with each other every time anyone finds anything that can help us."
    new "B:lad: Agora sou só eu e as minhas duas filhas. Ao longo dos anos, algumas pessoas vieram e foram."

    # say L1576 pla
    old "Oh, it's a very nice gesture of you that you take people in and help them. You really are a good person."
    new "B:lad: Nós nos comunicamos sempre que alguém encontra algo que possa nos ajudar."

    # say L1578 lad
    old "Thank you, I'm glad you think that about me."
    new "B:pla: Oh, é um gesto muito simpático da tua parte receber pessoas e ajudá-las. Tu és realmente uma boa pessoa."

    # say L1579 lad
    old "And yeah, we help each other cope with the condition. And since it's such a rare thing, it's really useful that we are all close to each other."
    new "E tu vês, já me ajudaste duas vezes e não pareces ser afetado..."

    # say L1580 lad
    old "And you see, since you've now been able to help me twice, and don't seem to be affected..."
    new "B:lad: E sim, nos ajudamos uns aos outros a lidar com a condição. E como é algo tão raro, é realmente útil que estejamos todos próximos uns dos outros."

    # say L1581 lad
    old "I was wondering if you could also help my two daughters."
    new "B:lad: E vês, como já me conseguiste ajudar duas vezes e não pareces afectada..."

    # say L1583 pla
    old "Oh! I see."
    new "B:lad: Estava a pensar se tu também poderias ajudar as minhas duas filhas."

    # say L1584 lad
    old "I would love it if you could. They could really use your help to improve their health."
    new "B:pla: Oh! Entendo."

    # say L1585 pla
    old "Well, I think that if I really did help you treat your condition. I don't see why it couldn't do it for you daughters."
    new "B:lad: Adorava se pudesses. Elas podiam realmente beneficiar da tua ajuda para melhorar a saúde."

    # say L1586 lad
    old "You're an angel. Then I'll talk to them, so that you can help them as soon as possible."
    new "B:pla: Bem, acho que se eu realmente te ajudei a tratar a tua condição, não vejo porque não poderia fazer o mesmo pelas tuas filhas."

    # say L1587 lad
    old "Is that ok with you?"
    new "B:lad: Tu és um anjo. Vou falar com eles, para que tu possas ajudá-los o mais rápido possível."

    # say L1589 lad
    old "All right, have a good night [pla]."
    new "T(lad|formal|say): Tudo bem, boa noite [pla]."

    # say L1613 pla
    old "Good morning ma'am, I'm here to help you as we talked before."
    new "B:pla: Boa noite para ti também, Lady Dimitrescu."

    # say L1614 lad
    old "Good morning. I'm happy to see that you actually came."
    new "B:pla: Bom dia, senhora, vim ajudá-la como combinamos."

    # say L1615 lad
    old "Allow me to introduce you to my daughters. These are Bela and Daniela."
    new "B:lad: Bom dia. Fico contente por ver que realmente vieste."

    # say L1620 dan
    old "Hello, I'm Daniela, mother has told us about you, and what you're able to do for us. Thank you very much for coming."
    new "B:bela: O- olá. Sou a Bela, prazer em conhecer-te."

    # say L1623 pla
    old "Uhh... Right now? And just like that?"
    new "B:lad: Bem, agora que as apresentações já foram feitas, acho melhor começarmos."

    # say L1624 lad
    old "Well, have in mind my daughters really needs it, and we use to do it in the past with other guys..."
    new "B:pla: Uhh... Agora? E assim, sem mais nem menos?"

    # say L1625 lad
    old "So, don't worry, just relax, and let us do all for you."
    new "B:lad: Bem, tenha em mente que as minhas filhas realmente precisam disto, e costumávamos fazê-lo no passado com outros rapazes..."

    # say L1633 lad
    old "Mmmm, look at that, you're already in the mood for it..."
    new "B:lad: Então, não te preocupes, só relaxa e deixa-nos fazer tudo por ti."

    # say L1634 dan
    old "Oh wow! Look at what you're packing there."
    new "B:lad: Mmmm, olha isso, tu já estás com vontade..."

    # say L1636 lad
    old "Daniela darling, please, you don't have to be this forward."
    new "B:dan: Oh wow! Olha o que tu tens aí."

    # say L1637 bela
    old "But mother, it is true that's an impressive size."
    new "B:lad: Daniela querida, por favor, não tens de ser tão direta."

    # say L1638 lad
    old "Hehe, we can't deny that..."
    new "B:bela: Mas mãe, é verdade que é um tamanho impressionante."

    # say L1639 lad
    old "But remember, we're doing this for a reason, so control yourselves."
    new "B:lad: Hehe, não podemos negar isso..."

    # say L1640 dan
    old "Yes, mother."
    new "A:lad: Agora, acho que já falámos o suficiente."

    # say L1642 lad
    old "Now, I think we've talked enough."
    new "B:dan: Sim, mãe."

    # say L1662 lad
    old "By the way, how are you feeling [pla]?"
    new "B:lad: Estás pronto [pla]?"

    # say L1664 lad
    old "I must admit your endurance is astounding."
    new "B:pla: Bem, para ser honesto estou um pouco cansado. Mas nada que uma sesta e um pouco de comida não resolvam. Vou ficar bem."

    # say L1665 lad
    old "But I'm happy you're fine."
    new "B:lad: Devo admitir que a tua resistência é impressionante."

    # say L1666 pla
    old "And I'm happy I can be of help to you all."
    new "B:lad: Mas fico feliz que estejas bem."

    # say L1670 dan
    old "Honestly, our health had been going down due to not being able to get enough semen for all three of us."
    new "B:pla: E fico feliz por poder ajudar-vos."

    # say L1671 dan
    old "And even if the hospital donated more, it's not the same thing as receiving it directly from a person."
    new "B:dan: Honestamente, a nossa saúde tem estado a piorar por não conseguirmos obter sêmen suficiente para os três."

    # say L1672 pla
    old "Hmm, does that mean that if no one else helps you, you'll be in trouble again?"
    new "B:dan: E mesmo que o hospital doe mais, não é a mesma coisa que receber diretamente de uma pessoa."

    # say L1673 lad
    old "Sadly it does."
    new "B:pla: Hmm, isso significa que se ninguém mais te ajudar, vais ter problemas de novo?"

    # say L1674 pla
    old "Then I'll be sure to come back again and help you. I'll do it as many times as you need me to."
    new "B:lad: Infelizmente sim."

    # say L1676 lad
    old "Hmm are you sure? I understand that one time is something. But if you do too many times it might affect you."
    new "B:pla: Então vou ter a certeza de voltar e ajudar-te. Vou fazê-lo tantas vezes quanto precisares."

    # say L1677 pla
    old "I think I could keep helping you some more, given that so far I haven't had any negative reaction."
    new "B:lad: Hmm, tens a certeza? Entendo que uma vez é algo. Mas se fizeres muitas vezes pode afetar-te."

    # say L1678 pla
    old "So you can count on me."
    new "B:pla: Acho que posso continuar a ajudar-te, dado que até agora não tive nenhuma reação negativa."

    # say L1679 lad
    old "Aww, you're an angel. Well then, when we need it, we'll be sure to call you on."
    new "A:pla: Olá, Senhora Dimitrescu."

    # say L1697 pla
    old "Hi Lady Dimitrescu."
    new "B:lad: Aww, tu és um anjo. Bem, então, quando precisarmos, certamente te chamaremos."

    # menu L1703 
    old "Help them again"
    new "B:lad: Como posso ajudar-te hoje?"

    # say L1705 pla
    old "Well, I have been thinking about helping you again."
    new "B:n: Ajuda-los de novo"

    # say L1706 lad
    old "Oh, have you come help us with our protein needs?"
    new "B:pla: Bem, tenho estado a pensar em ajudar-te de novo."

    # say L1707 pla
    old "That's right, I thought you might need it."
    new "B:lad: Oh, vieste ajudar-nos com as nossas necessidades de proteína?"

    # say L1708 lad
    old "That's perfect, you came at just the right moment."
    new "B:pla: É verdade, pensei que poderias precisar."

    # say L1709 lad
    old "Let me call the girls."
    new "B:lad: Is perfeito, tu chegaste no momento certo."

    # say L1728 bela
    old "Hi [pla]! How are you?"
    new "T(bela|tu|diz): Olá [pla]! Como estás?"

    # say L1729 pla
    old "I'm fine, thank you, I came to see if you needed my help today."
    new "Sim, a mãe disse-nos."

    # say L1730 dan
    old "Yeah, mother told us."
    new "B:pla: Estou bem, obrigado, vim ver se precisavas da minha ajuda hoje."

    # say L1764 pla
    old "What?! Oh no, sorry, I was just a little distracted."
    new "B:dan: Sim, a mãe já nos disse."

    # say L1766 lad
    old "Hmm, I see, well, be careful on the way back."
    new "B:pla: Que?! Oh, desculpa, estava só um pouco distraído."

    # say L1767 pla
    old "Yes ma'am, bye."
    new "B:lad: Hmm, percebo, bem, cuidado no caminho de volta."

    # say L1770 pla
    old "Oh, sorry, I was just passing by."
    new "B:pla: Sim, senhora, adeus."

    # say L1771 lad
    old "Hmm, I see, well, make sure you come when you have some free time."
    new "B:pla: Oh, desculpe, eu estava só a passar."

    # say L1772 pla
    old "Yes ma'am, of course. See you later."
    new "Adeus, cuidado."

    # say L1773 lad
    old "Bye, take care."
    new "Adeus, cuida-te."


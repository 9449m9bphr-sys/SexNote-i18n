# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/johAnimations.rpy
translate portuguese strings:

    # say L6 joh
    old "Perfect, you are doing it so good, don't stop..."
    new "T(joh|formal|say): Perfeito, estás a fazer tão bem, não pares..."

    # say L8 joh
    old "Please keep in mind the places where it's better to touch, where you can make your patient feel even more..."
    new "B:joh: Perfeito, estás a fazer tão bem, não pares..."

    # say L15 joh
    old "You are doing perfect, don't stop, it feels so good."
    new "B:joh: Por favor, lembra-te dos lugares onde é melhor tocar, onde podes fazer a tua paciente sentir-se ainda melhor..."

    # say L16 pla
    old "Slurp... Slurp..."
    new "B:joh: Estás a fazer perfeitamente, não pares, sente-se tão bem."

    # say L39 joh
    old "Ahh, I want you to do it faster!... Go as fast as you c- can."
    new "B:pla: Slurp... Slurp..."

    # say L40 joh
    old "Yeah, Yeah, YEAH! keep moving... I- I am cuming! AHH!"
    new "B:joh: Ahh, quero que faças mais rápido!... Vai o mais rápido que c- consegues."

    # say L59 joh
    old "Please, just let me to enjoy your dick..."
    new "B:joh: Sim, sim, SIM! Continua... V-Vou gozar! AHH!"

    # say L61 joh
    old "It's so hard... I just wanted to have it since I saw you fucking Angelina."
    new "B:joh: Por favor, deixa-me apenas desfrutar do teu pénis..."

    # say L64 joh
    old "I want you to feel the tip of my tongue playing with the head of your dick..."
    new "B:joh: É tão difícil... Só queria tê-lo desde que te vi a foder a Angelina."

    # say L65 pla
    old "(Oh God...)"
    new "B:joh: Quero que sintas a ponta da minha língua a brincar com a cabeça do teu pénis..."

    # say L70 joh
    old "I'm really really wet right now... Do you like my mouth?"
    new "B:pla: (Oh Deus...)"

    # say L71 pla
    old "Oh God, yes, it feels really good..."
    new "B:joh: Estou mesmo muito molhada agora... Gostas da minha boca?"

    # say L74 joh
    old "I need you to feel my mouth, to internalize the pleasure you are feeling, it's something you should handle. "
    new "B:pla: Ah, Deus, sim, está a sentir-se tão bem..."

    # say L80 joh
    old "Who do you prefer to suck your cock?  Me... Slurp... Or... Slurp... Angelina?"
    new "B:joh: Preciso que sinta a minha boca, que interiorize o prazer que está a sentir, é algo que deve gerir."

    # say L82 joh
    old "Are you really considering it?"
    new "B:joh: Quem preferes para chupar o teu pau? Eu... Slurp... Ou... Slurp... Angelina?"

    # say L85 joh
    old "Can you feel my tongue? Do you feel how wet it is now, feel the tip playing with your dick's head..."
    new "B:joh: Estás realmente a considerá-lo?"

    # say L86 pla
    old "Yes, I- I can."
    new "B:joh: Sentes a minha língua? Sentes o quão molhada está agora, a ponta a brincar com a cabeça do teu pénis..."

    # say L106 joh
    old "I'm gonna show you WHO is the MASTER..."
    new "B:pla: Sim, eu... eu consigo."

    # say L110 joh
    old "I'm going to do it with all I have, so be ready."
    new "B:joh: Vou-te mostrar QUEM é o MESTRE..."

    # say L129 joh
    old "This is how a master do it..."
    new "B:joh: Vou fazer isto com todas as minhas forças, prepara-te."

    # say L130 pla
    old "Uhhh..."
    new "A:joh: Concentra-te, não podes gozar."

    # say L133 joh
    old "Stay focused, you can't cum."
    new "B:pla: Uhhh..."

    # say L134 pla
    old "I won't."
    new "B:joh: Concentra-te, não podes gozar."

    # say L135 joh
    old "I hope so!"
    new "A:joh: E então? O que achas agora? Quem é melhor?"

    # say L139 joh
    old "So? What do you think now? Who is better?"
    new "B:joh: Espero que sim!"

    # say L140 pla
    old "Ahh... Y- you... You are better..."
    new "B:joh: E então? O que achas agora? Quem é melhor?"

    # say L141 joh
    old "That's what I wanted to ear..."
    new "B:pla: Ahh... T-tu... Tu és melhor..."

    # say L144 joh
    old "I will speed up a bit, I know you will enjoy it."
    new "B:joh: É isso que eu queria ouvir..."

    # say L152 joh
    old "I'm going to make you cum NOW!"
    new "B:joh: Vou acelerar um pouco, sei que vais gostar."

    # say L154 joh
    old "You are doing it better than I expected... But you can't against my full speed."
    new "B:joh: Vou fazer-te gozar AGORA!"

    # say L157 pla
    old "AHH!"
    new "A:pla: A- Acho que vou-"

    # say L186 pla
    old "I- I think I'm going to-"
    new "A: joh: Oh, por favor, deixa ir, derrama sobre a minha boca..."

    # say L187 joh
    old "Oh, please let it go, spill it over my mouth..."
    new "B:pla: Eu... Acho que vou..."

    # say L188 pla
    old "A- are you sure?"
    new "B:joh: Oh, por favor, deixa ir, derrama sobre a minha boca..."

    # say L189 joh
    old "Yess, I want to feel all you cum in my mouth, give it all to me!"
    new "B:pla: A- estás certa?"

    # say L200 joh
    old "Definetly, I need to ride this cock, I want it all inside me, lie on the bed I need you to fuck me!"
    new "B:joh: Sim, quero sentir todo o teu esperma na minha boca, dá-me tudo!"

    # say L202 joh
    old "I don't want any kids game, fuck me really HARD!"
    new "B:joh: Com certeza, preciso cavalgar este pau, quero tudo dentro de mim, deita-te na cama, preciso que me fodes!"

    # say L203 pla
    old "A- alright."
    new "A: joh: Escuta com atenção, quero que mantenhas um ritmo regular e também uma força uniforme..."

    # say L219 joh
    old "Listen carefully, I want you to keep a regular rythm, and also an uniform strength..."
    new "B:pla: A- tudo bem."

    # say L220 joh
    old "You need to plan your movements, your energy, I will tell when you can do it faster."
    new "B:joh: Escuta com atenção, quero que mantenha um ritmo regular e também uma força uniforme..."

    # say L225 joh
    old "Ahh... I like it, keep it like that..."
    new "B:joh: Precisas de planear os teus movimentos, a tua energia, direi quando podes fazer mais rápido."

    # say L228 joh
    old "Oh, now faster, I'm very wet, do it harder."
    new "B:joh: Ahh... Gosto disto, continua assim..."

    # say L229 pla
    old "O- ok."
    new "A:joh: BATE MAIS FORTE!"

    # say L249 joh
    old "POUND ME HARDER!"
    new "B:pla: O- ok."

    # say L250 pla
    old "Huh..."
    new "A:joh: Ahh, faz com toda a força que precisas, quero que me fodas até ao fundo."

    # say L271 joh
    old "Ahh, do it as hard as you have to, I want you to smash my pussy"
    new "B:pla: Huh..."

    # say L273 joh
    old "Oh yeah, don't stop, don't stop!"
    new "B:joh: Ahh, faz com toda a força que tiveres, quero que me fodas!"

    # say L276 joh
    old "Show me how powerful your dick is, I want you to make cum!"
    new "B:joh: Oh yeah, não pares, não pares!"

    # say L278 pla
    old "Ughh... "
    new "B:joh: Mostra-me o quão poderoso é o teu pénis, quero que me faças gozar!"

    # say L307 joh
    old "Oh God! I'm cumming!! Ahhh! Ahhhh!"
    new "B:pla: Ughh..."

    # say L325 joh
    old "Yes, just like this baby..."
    new "B:joh: Ah Deus! Estou a gozar!! Ahhh! Ahhhh!"

    # say L326 pla
    old "Gulp..."
    new "A:joh: Ahh! O teu pénis é tão bom..."

    # say L330 joh
    old "Ahh! Your dick is so good..."
    new "B:pla: Engolir..."

    # say L331 pla
    old "Ah!"
    new "Ahh! O teu pénis é tão bom... Ah! TÃO BOM!!!"

    # say L332 joh
    old "SO GOOD!!!"
    new "B:pla: Ah!"

    # say L335 joh
    old "Ohh yeahh, it's so big!"
    new "B:joh: TÃO BOM!!!"

    # say L336 pla
    old "AH!"
    new "MAIS FORTE, MAIS FORTE!"

    # say L337 joh
    old "HARDER, HARDER!"
    new "B:pla: AH!"

    # say L362 joh
    old "I'm gonna cum!!!"
    new "B:joh: MAIS FORTE, MAIS FORTE!"

    # say L364 joh
    old "Let's cum together, DON'T STOP, DON'T STOP... AHHH!"
    new "B:joh: Vou gozar!!!"

    # say L365 pla
    old "Mmmm!! I- I'm coming..."
    new "B:joh: Vamos gozar juntos, NÃO PARES, NÃO PARES... AHHH!"

    # say L371 joh
    old "Wow..."
    new "B:pla: Mmmm!! E-Estou a gozar..."

    # say L383 joh
    old "Oh yeah, I'm going to show you how an expert fucks!"
    new "B:joh: Wow..."

    # say L384 pla
    old "Ughh, It feels amazing..."
    new "B:joh: Oh yeah, vou-te mostrar como um especialista faz sexo!"

    # say L387 joh
    old "Mmmm... Riding you drives me crazy!"
    new "B:pla: Ughh, É incrível..."

    # say L388 pla
    old "Oh yess... Please don't stop it... Ahh!"
    new "B:joh: Mmmm... Montar-te deixa-me louco!"

    # say L389 joh
    old "Yeah, you like it? Then I'm gonna fuck you harder!"
    new "B:pla: Oh yess... Por favor, não pares... Ahh!"

    # say L393 joh
    old "Uhhh... You have really huge cock! I can't fit it all in my pussy."
    new "B:joh: Sim, tu gostas? Então vou-te foder mais forte!"

    # say L394 joh
    old "Fuck me! Fuck me! I want you to fill my cunt of cum."
    new "B:joh: Uhhh... Tu tens mesmo um pénis enorme! Não consigo cabê-lo todo dentro de mim."

    # say L419 joh
    old "Yeeeeesss... Yesss... I- I'm cumming!!"
    new "B:joh: Foda-me! Foda-me! Quero que enchas a minha xoxota de esperma."

    # say L420 pla
    old "Ahhhhh... Ughhh..."
    new "B:joh: Yeeeeesss... Yesss... V-Vou gozar!!"

    # say L426 joh
    old "Ohh, yes, I feel it inside, that's delicious."
    new "B:pla: Ahhhhh... Ughhh..."

    # say L427 joh
    old "Don't even think about stopping... I need more of your cock NOW!"
    new "B:joh: Ohh, sim, sinto-o dentro, é delicioso."

    # say L442 joh
    old "Now softly... I wanna feel all your big cook..."
    new "B:joh: Nem penses em parar... Preciso de mais do teu pau AGORA!"

    # say L443 joh
    old "Ohh yeahh... Just like that baby..."
    new "B:joh: Agora devagar... Quero sentir todo o teu grande pénis..."

    # say L447 joh
    old "Do you like my big boobs? How do they bounce when you fuck me?"
    new "B:joh: Ohh sim... Assim mesmo, querida..."

    # say L448 pla
    old "Yes, I love your tits!"
    new "B:joh: Gostas das minhas grandes tetas? Como é que elas saltam quando me comes?"

    # say L449 joh
    old "Then, fuck me faster, with that huge cock!"
    new "B:pla: Sim, adoro os teus peitos!"

    # say L453 joh
    old "Harder! Fuck me harder! I want you to make me cum as you did with Angelina!"
    new "B:joh: Então, foda-me mais rápido, com esse pau enorme!"

    # say L455 joh
    old "OH GOD... I'M GONNA FUCK YOU EVERYDAY..."
    new "B:joh: Mais forte! Foda-me mais forte! Quero que me faças gozar como fizeste com Angelina!"

    # say L479 pla
    old "I- I going to..."
    new "B:joh: OH DEUS... VOU FODER-TE TODOS OS DIAS..."

    # say L480 joh
    old "Yes! Cum inside me!"
    new "Sim! Entra em mim!"


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/ChristmasEvent2.rpy
translate portuguese strings:

    # say L7 pla
    old "Hmm, what is this?"
    new "Que sensação é esta?"

    # say L8 pla
    old "What's this feeling?"
    new "B:pla: Hmm, o que é isto?"

    # say L9 pla
    old "I- I have a hard-on?!"
    new "B:pla: Que sensação é esta?"

    # say L22 pla
    old "Lydia?! W- what are you doing?"
    new "B:pla: I- Tenho uma ereção?!"

    # say L28 lyd
    old "Good morning hon! Great, you finally wake up!"
    new "B:pla: Lydia?! Q- que estás a fazer?"

    # say L29 pla
    old "W- what's happenning? What's this?!"
    new "B:lyd: Bom dia querida! Ótimo, finalmente acordaste!"

    # say L30 pla
    old "And what is that you're wearing?!"
    new "B:pla: O- o que está a acontecer? O que é isto?!"

    # say L34 lyd
    old "Do you like it? It's my Mrs. Claus outfit for the day!"
    new "B:pla: E o que é que estás a usar?!"

    # say L35 lyd
    old "You know, to get in the spirit of Christmas."
    new "B:lyd: Gostas? É o meu fato de Senhora Claus para o dia!"

    # say L36 pla
    old "Whatever! What are you doing in my room, and giving me a blowjob?!"
    new "B:lyd: Sabes, para entrar no espírito do Natal."

    # say L37 lyd
    old "Well, I came to spend Christmas with you guys."
    new "B:pla: Pfft! O que estás a fazer no meu quarto e a dar-me uma fellatio?!"

    # say L38 lyd
    old "But when I arrived I saw that you were still sleeping."
    new "B:lyd: Bem, vim passar o Natal convosco."

    # say L42 lyd
    old "Then I decided to wake you up in a special way!"
    new "B:lyd: Mas quando cheguei vi que tu ainda estavas a dormir."

    # say L43 lyd
    old "I guess you can say it is my early Christmas present to you!"
    new "B:lyd: Então decidi acordar-te de uma forma especial!"

    # say L44 pla
    old "What are you talking about?!"
    new "B:lyd: Podes dizer que é o meu presente de Natal antecipado para ti!"

    # say L45 pla
    old "Do you know what my [mo1rel]'s going to do if she sees what you're doing?!"
    new "T: Sabes o que a minha [mo1rel] vai fazer se vir o que estás a fazer?!"

    # say L50 lyd
    old "Oh, don't say that."
    new "B:pla: O que te deu de repente?"

    # say L51 lyd
    old "Nothing got into me."
    new "B:lyd: Oh, não digas isso."

    # say L55 lyd
    old "I just wanted to start Christmas the right way."
    new "B:lyd: Não me entrou nada."

    # say L59 lyd
    old "I bet you can help me with that."
    new "B:lyd: Só queria começar o Natal da maneira certa."

    # say L63 lyd
    old "After all, you have something I want in me..."
    new "B:lyd: Aposto que podes ajudar-me com isso."

    # say L64 pla
    old "W- what? You must be kidding me!"
    new "B:lyd: Afinal, tu tens algo que eu quero em ti..."

    # say L68 lyd
    old "Don't be so shy baby"
    new "T(lyd|tu|say): Não fiques tão tímido, querido"

    # say L69 lyd
    old "After all, it's not like you haven't done it before."
    new "B:lyd: Não sejas tão tímido, querido."

    # say L73 lyd
    old "Besides, I can see very clearly that you want it."
    new "B:lyd: Afinal, não é como se tu nunca tivesses feito antes."

    # say L74 pla
    old "T- that's just because you woke me up that way!"
    new "B:lyd: Além disso, posso ver muito claramente que tu queres."

    # say L75 pla
    old "It- it will go down in a minute."
    new "B:pla: T- isso é só porque tu me acordaste assim!"

    # say L79 lyd
    old "Oh, but I can't let that happen!"
    new "B:pla: Vai... vai baixar num minuto."

    # say L80 lyd
    old "I haven't had any breakfast yet, and I think I want some of your eggnog!"
    new "B:lyd: Oh, mas não posso deixar isso acontecer!"

    # say L87 lyd
    old "My god, I love the taste and smell of your dick!"
    new "B:lyd: Ainda não tomei o pequeno-almoço e acho que quero um pouco do teu ponche de ovos!"

    # say L88 lyd
    old "I'm already so wet!"
    new "B:lyd: Meu Deus, adoro o sabor e o cheiro do teu pénis!"

    # say L89 lyd
    old "What a shame we don't have much time."
    new "T(lyd|tu|say): Que pena não termos muito tempo."

    # say L90 lyd
    old "Otherwise I'd like to do something else..."
    new "B:lyd: Que pena não termos muito tempo."

    # say L102 lyd
    old "So, you can get dressed in peace."
    new "B:lyd: Vou dizer bom dia ao resto da família."

    # say L103 pla
    old "Uhh... sure."
    new "B:lyd: Então, podes vestir-te em paz."

    # say L113 pla
    old "W- what? What was that? What's happening?"
    new "B:pla: Huh... claro."

    # say L114 sis
    old "I was asking you if you had a minute, I have something to show you..."
    new "T(sis|tu|diz): Estava a perguntar-te se tinhas um minuto, tenho algo para te mostrar..."

    # say L116 sis
    old "Excuse me?"
    new "B:sis: Estava a perguntar-te se tinhas um minuto, tenho algo para te mostrar..."

    # say L117 pla
    old "Uhh, nevermind... Uhh, what do you want to show me?"
    new "B:sis: Desculpa?"

    # say L119 sis
    old "Hmm, come to my bedroom with me."
    new "B:pla: Uhh, deixa estar... Uhh, o que queres mostrar-me?"

    # say L120 pla
    old "Uh, sure."
    new "B:sis: Hmm, vem ao meu quarto comigo."

    # say L137 sis
    old "So, I wanted to show you the new Christmas clothes that just arrived."
    new "T(sis|tu|diz): Então, queria mostrar-te as novas roupas de Natal que acabaram de chegar. A:sis: São para a loja."

    # say L138 sis
    old "They're for the shop."
    new "B:sis: Então, queria mostrar-te as novas roupas de Natal que acabaram de chegar."

    # say L145 sis
    old "Great! Just wait here."
    new "B: Irmã: Queres ver as fotos?"

    # say L157 sis
    old "Ok, this is the first one, what do you think?"
    new "Acho que é ótimo, muito festivo, fica-te bem."

    # say L158 pla
    old "I think it's great, very festive, it suits you."
    new "B:sis: Ok, este é o primeiro, o que tu achas?"

    # say L159 pla
    old "I'm sure it's going to sell great."
    new "B:pla: Acho ótimo, muito festivo, combina contigo."

    # say L160 sis
    old "That's just what I thought."
    new "B:pla: Tenho a certeza que vai vender muito bem."

    # say L161 sis
    old "Let me show you the other one."
    new "B:iris: Foi exactamente o que pensei. T(iris|tu|diz): Deixa-me mostrar-te o outro. A:iris: E então, que tal este?"

    # say L177 sis
    old "So, what about this one?"
    new "Este é o meu favorito."

    # say L178 sis
    old "This one is my favorite."
    new "B:sis: Então, e este?"

    # say L180 pla
    old "I- I mean, it looks great on you."
    new "T: I- Isto fica-te muito bem."

    # say L181 pla
    old "I'm not sure this counts as an outfit per se."
    new "B:pla: I- Quero dizer, fica-te muito bem."

    # say L185 pla
    old "But maybe it will sell well as lingerie."
    new "B:pla: Não tenho a certeza de que isto conte como um outfit propriamente dito."

    # say L186 pla
    old "This one could also be good for the ladies that want to surprise their husbands and boyfriends."
    new "B:pla: Mas talvez venda bem como lingerie."

    # say L187 sis
    old "Yeah, and it's very comfortable too."
    new "B:pla: Este também pode ser bom para as senhoras que querem surpreender os maridos e namorados."

    # say L203 sis
    old "What do you think? Isn't it soft?"
    new "B:sis: Oh bem, só quero que sintas o tecido."

    # say L204 pla
    old "I- I guess it is, yeah..."
    new "B:sis: O que achas? Não é macio?"

    # say L206 sis
    old "But how much do you like it?"
    new "B:pla: I- Acho que é, sim..."

    # say L207 sis
    old "Let me see how you feel down here..."
    new "B:sis: Mas quanto é que tu gostas?"

    # say L220 sis
    old "And oh my god! Look at that!"
    new "B: Irmã: Só queria ver o quanto tu gostas do meu outfit..."

    # say L221 sis
    old "You clearly really like it!"
    new "E... eu quero dizer."

    # say L222 pla
    old "Uh... I- I mean."
    new "B:sis: Tu claramente gostas muito disto!"

    # say L223 sis
    old "It's ok [pla] I know you love it."
    new "T(sis|tu|diz): Tudo bem [pla], sei que tu adoras."

    # say L225 sis
    old "What I could with it..."
    new "B: Irmã: Olha só aquele pénis grande!"

    # say L239 sis
    old "I'm sure the clients will love this new line!"
    new "B:sis: O que eu poderia fazer com isso..."

    # say L240 pla
    old "Umm, yeah, I guess they will."
    new "B:sis: Tenho a certeza de que os clientes vão adorar esta nova linha!"

    # say L246 sis
    old "Why do you ask?"
    new "B:sis: Eu? Estou ótima!"

    # say L247 pla
    old "No reason, it's just a strange feeling..."
    new "T: Não há razão, é só uma sensação estranha..."

    # say L248 pla
    old "You know what? Forget it, it must be my imagination."
    new "B: pla: Sem razão, é só uma sensação estranha..."

    # say L250 sis
    old "Well, I have to work on some things for the website, you can leave now."
    new "B:pla: Sabes o que? Esquece, deve ser a minha imaginação."

    # say L252 pla
    old "Uhh, right..."
    new "B:sis: Bem, tenho que trabalhar em algumas coisas para o site, podes ir embora agora."

    # say L262 pla
    old "Uhh... That was weird..."
    new "Uhh... Ainda tenho essa sensação estranha... O que foi isso?"

    # say L263 pla
    old "I still has that strange feeling... What was that?"
    new "T(pla|tu|say): Ainda tenho essa sensação estranha... O que foi isso?"

    # say L264 pla
    old "Anyway, I better go downstairs and see what happened with Lydia..."
    new "B:pla: Ainda tenho essa sensação estranha... O que foi aquilo?"

    # say L288 mo1
    old "We're opening our Christmas gifts, you're just in time."
    new "B:mo1: Chegaste, maravilha!"

    # say L299 mo1
    old "I can't wait to see what it is!"
    new "B:mo1: Oh! Querida! Obrigada!"

    # say L313 mo1
    old "Of course I do! This is my favorite brand!"
    new "B:pla: (É um frasco de lubrificante?)"

    # say L314 mo2
    old "You know, this lube is very good because it enhance all sensations."
    new "B:mo1: Claro que sim! Esta é a minha marca favorita!"

    # say L315 pla
    old "(Holy shit, yes it is...)"
    new "B:mo2: Sabes, este lubrificante é muito bom porque potencia todas as sensações."

    # say L319 mo2
    old "So, when we use it you can feel even harder when you're getting railed."
    new "B:pla: (Santo Deus, é verdade...)"

    # say L320 pla
    old "(What the... Why are they talking like that in front of Lydia...)"
    new "B:mo2: Então, quando usarmos vais sentir ainda mais quando estás a ser penetrada."

    # say L324 mo1
    old "Oh honey! That sounds fantastic! We have to use it as soon as we can!"
    new "B:pla: (Que... Porque é que estão a falar assim na frente da Lydia...)"

    # say L325 mo2
    old "Off course! I really enjoy this one, is really warm..."
    new "B:mo1: Oh querida! Isso soa fantástico! Temos que usar o mais rápido possível!"

    # say L326 mo2
    old "We have to put it to the test to see if you like it."
    new "B:mo2: Claro! Realmente gosto disto, está mesmo quente..."

    # say L331 lyd
    old "Oh please, stop..."
    new "B:mo2: Temos que por isso à prova para ver se tu gostas."

    # say L344 mo1
    old "There's no reason why it couldn't be for the both of us!"
    new "B:pla: (Que raio...)"

    # say L345 mo1
    old "As long as we both enjoy it, who cares who it is for!"
    new "B:mo1: Não há razão para não ser para os dois!"

    # say L350 mo2
    old "That's right Lydia, relax."
    new "B:mo1: Desde que ambos gostemos, quem se importa para quem é!"

    # say L359 lyd
    old "I think everybody should get to have a good time with these gifts."
    new "B:lyd: Todos os presentes devem ser apreciados igualmente."

    # say L360 mo1
    old "Oh, I agree with that."
    new "A:pla: Uhh... Q- que se passa?"

    # say L371 pla
    old "I'll open my gifts later."
    new "B:pla: Acho que estou bem por agora."

    # say L372 lyd
    old "Don't be foolish sweetie! You have to open them right now!"
    new "T(lyd|tu|say): Não sejas tolo, querido! Tens de os abrir já!"

    # say L373 mo2
    old "Otherwise it is no fun."
    new "B:lyd: Não sejas tola, querida! Tens de os abrir já!"

    # say L387 mo2
    old "Don't be a brag and do it!"
    new "B:pla: N- Não tenho a certeza se devo."

    # say L401 pla
    old "W- WHAT THA FUCK? THIS WEIRD THING AGAIN???"
    new "B:mo2: Não te vanglories e faz isso!"

    # say L402 mo1
    old "Oh, don't worry honey, this is just one of your Christmas gifts."
    new "B: pla: Q- QUE RAIO? ESTA COISA ESTRANHA DE NOVO???"

    # say L403 mo1
    old "After all you have been such a good boy this year."
    new "B:mo1: Oh, não te preocupes querida, isto é apenas um dos teus presentes de Natal."

    # say L404 mo2
    old "And we have been such naughty girls."
    new "B:mo1: Afinal, foste um menino tão bom este ano."

    # say L405 lyd
    old "So, just relax and let us take care of you for a chance."
    new "B:mo2: E temos sido tão más."

    # say L407 pla
    old "{i}(Lydia had already been acting weird since this morning.){/i}"
    new "B:pla: {i}(O que raio se está a passar com eles?){/i}"

    # say L411 pla
    old "{i}(So, if this is a dream...){/i}"
    new "B:pla: {i}(Esuponho que isto seja mais um desses sonhos? Não há outra explicação para isto.){/i}"

    # say L412 pla
    old "{i}(I guess I can just enjoy it, right?){/i}"
    new "B:pla: {i}(Então, se isto é um sonho...){/i}"

    # say L435 lyd
    old "And your tongue is so good baby!"
    new "E a tua língua é tão boa, bebé!"

    # say L438 pla
    old "{i}(When am I going to have another dream like this?){/i}"
    new "B:pla: {i}(Bem, acho que devo apenas continuar a aproveitar.){/i}"

    # say L450 pla
    old "Did you come to join in on the fun?"
    new "B: L- Linett, que surpresa! Tu também estás no meu sonho?"

    # say L451 pla
    old "I mean, I haven't done it with shinigamis and humans simultaneously."
    new "B:pla: Vim juntar-me à diversão?"

    # say L452 pla
    old "But it could be interesting! Hop in!"
    new "B: pla: Quero dizer, nunca o fiz com shinigamis e humanos ao mesmo tempo."

    # say L453 lin
    old "What? What are you talking about?"
    new "B:pla: Mas podia ser interessante! Entra!"

    # say L454 pla
    old "Oh come on, you don't have to act like you don't want it."
    new "B:lin: O quê? Do que estás a falar?"

    # say L455 pla
    old "This is a dream after all."
    new "B:pla: Vamos, não precisas de agir como se não quisesse."

    # say L456 lin
    old "This isn't a dream you dumbass!"
    new "T(lin|tu|say): Isto não é um sonho, seu idiota!"

    # say L457 pla
    old "W- What? What do you mean?"
    new "T: W- What? O que queres dizer com isso?"

    # say L458 lin
    old "As you heard, this isn't a dream!"
    new "T(lin|tu|say): Como ouviste, isto não é um sonho!"

    # say L459 lin
    old "This is all real [pla]!"
    new "T(lin|tu|say): Isto tudo é real [pla]!"

    # say L464 lin
    old "Seems to have affected reality in a way we couldn't predict."
    new "B:lin: Parece que o feitiço de concentração de magia que fizemos na igreja..."

    # say L465 lin
    old "The ritual was successful but it's now starting to gather magic from all around."
    new "B:lin: Parece ter afetado a realidade de uma forma que não conseguíamos prever."

    # say L466 lin
    old "And given that most magic in this world is stored in human bodies, it's trying to force it out!"
    new "B:lin: O ritual foi bem-sucedido, mas agora está a começar a recolher magia de todo o lado."

    # say L470 lin
    old "When that happens to human bodies they start to feel their life energy deplete."
    new "B:lin: E dado que a maior parte da magia neste mundo está armazenada nos corpos humanos, está a tentar forçá-la a sair!"

    # say L474 lin
    old "So, all the weird human behavior is caused because of the magic power..."
    new "B:lin: Quando isso acontece aos corpos humanos, eles começam a sentir a sua energia vital a diminuir."

    # say L475 lin
    old "They're not really themselves, they're in a sort of magically unconscious state..."
    new "B:lin: Então, todo o comportamento estranho dos humanos é causado pelo poder mágico..."

    # say L476 lin
    old "And if it isn't stopped now it will wreak havoc in this world."
    new "B:lin: Eles não estão realmente a si mesmos, estão num estado de inconsciência mágica..."

    # say L477 lin
    old "Although it already started. So, we have very little time."
    new "B:lin: E se não for parado agora, causará estragos neste mundo."

    # say L481 lin
    old "Truth be told, when we did the last ritual I noticed something was odd."
    new "B:lin: Embora já tenha começado. Portanto, temos muito pouco tempo."

    # say L482 lin
    old "I probably should've done something about it then."
    new "B:lin: A dizer a verdade, quando fizemos o último ritual, notei que algo estava estranho."

    # say L483 lin
    old "But I didn't expect anything like this to happen."
    new "B:lin: Deveria ter feito algo a respeito na altura."

    # say L484 pla
    old "I- I- I'm not getting it at all..."
    new "A:lin: O que estou a dizer é que a realidade está a começar a fragmentar-se!"

    # say L488 lin
    old "What I'm telling you is that reality is starting to fragment!"
    new "B: pla: N-N-Não estou a perceber nada..."

    # say L489 lin
    old "So, we have to hurry and do something about it!"
    new "B:lin: O que estou a dizer é que a realidade está a começar a fragmentar-se!"

    # say L493 lin
    old "The ritual we did was successful."
    new "B:lin: Então, temos de nos apressar e fazer algo a respeito!"

    # say L494 lin
    old "The problem  is that there's not enough magic density in this world to just create a portal."
    new "B:lin: O ritual que fizemos foi bem-sucedido."

    # say L499 pla
    old "What can we do about it?"
    new "B:lin: O problema é que não há densidade mágica suficiente neste mundo para criar um portal."

    # say L503 lin
    old "I have a couple ideas."
    new "T(lin|tu|say): Tenho algumas ideias."

    # say L504 lin
    old "Honestly I don't know if what I'm thinking off will work."
    new "B:lin: Tenho algumas ideias."

    # say L505 lin
    old "So, we'll have to try a couple of things to see what sticks."
    new "Mas seja o que for que façamos."

    # say L506 lin
    old "But whatever it is we do."
    new "B:lin: Então, vamos ter de experimentar algumas coisas para ver o que resulta."

    # say L510 lin
    old "I'm sure we'll need the other three shinigami for it, so, let's go."
    new "B:lin: Mas seja o que for que façamos."

    # say L528 lin
    old "W- What? Who are you?!"
    new "B:lin: Tenho a certeza de que vamos precisar dos outros três shinigami para isso, então, vamos."

    # say L529 bri
    old "What the fuck is going on here?!"
    new "T(bri|tu|say): Que raio se está a passar aqui?!"

    # say L530 lin
    old "Uh- Listen, I don't know who you are."
    new "T(lin|tu|say): Hã... Ouve, não sei quem tu és."

    # say L535 lin
    old "I didn't even know there was another shinigami around."
    new "B:lin: Uh- Escuta, não sei quem tu és."

    # say L536 lin
    old "But nice to meet you... I guess. I'm Linnet."
    new "T(lin|tu|say): Mas é bom conhecer-te... Acho eu. Sou a Linnet."

    # say L540 lin
    old "Listen, right now there's no time for us to talk."
    new "B:lin: Mas é agradável conhecer-te... Acho eu. Sou a Linnet."

    # say L541 lin
    old "In case you haven't noticed, reality is tearing itself apart!"
    new "A:lin: Vais ajudar-nos ou não?!"

    # say L542 lin
    old "Are you going to help us or not?!"
    new "B:lin: Se não reparaste, a realidade está a rasgar-se!"

    # say L543 bri
    old "Oh, I know full well who you are!"
    new "B:lin: Vais ajudar-nos ou não?!"

    # say L547 bri
    old "You're that idiot that keeps messing with the magic of this world!"
    new "B:bri: Oh, eu sei muito bem quem tu és!"

    # say L553 bri
    old "Look at the mess you've made!"
    new "T(bri|tu|say): Olha para a confusão que fizeste!"

    # say L563 bri
    old "I'M NOT GOING TO LET YOU CONTINUE RUINING EVERYTHING!"
    new "B:bri: Não vês que estás a destruir a nossa única hipótese de consertar o mundo mágico?"

    # say L583 pla
    old "B- Brixxida! W- What are you doing? She's an ally!"
    new "B:bri: NÃO VOU DEIXAR QUE CONTINUES A ESTRAGAR TUDO!"

    # say L587 bri
    old "Oh! You shut up! Enough with the stupidities!"
    new "B: B- Brixxida! Q- Que estás a fazer? Ela é uma aliada!"

    # say L588 bri
    old "You've already ruined too many things."
    new "B:bri: Oh! Cala-te! Chega de estupideces!"

    # say L589 bri
    old "And I won't keep risking my life, this world, and the magic world."
    new "E não vou continuar a arriscar a minha vida, este mundo e o mundo mágico por causa das ações de um grupo de shinigamis estúpidos e inexperientes."

    # say L590 bri
    old "Because of the actions of a group of stupid inexperienced shinigamis."
    new "E não vou continuar a arriscar a minha vida, este mundo e o mundo mágico. Por causa das ações de um grupo de shinigamis estúpidos e inexperientes. Lá, tu tratas disso."

    # say L599 bri
    old "There, you take care of that."
    new "B:bri: Devido às ações de um grupo de shinigamis estúpidos e inexperientes."

    # say L600 bri
    old "Put her some place where she won't be a bother."
    new "B:bri: Lá, tu tratas disso."

    # say L635 pla
    old "I don't see anything wrong..."
    new "T: Não vejo nada de errado..."

    # say L636 bri
    old "Oh really? Use your Eye of Agamotto..."
    new "B:pla: Não vejo nada de errado..."

    # say L637 pla
    old "Uhh... Alright..."
    new "B:bri: Oh really? Usa o teu Olho de Agamotto..."

    # say L647 pla
    old "Woah! What's this? What's happening?"
    new "B:pla: Uhh... Tudo bem..."

    # say L648 bri
    old "This is what you and that idiot did!"
    new "B:pla: Uau! O que é isto? O que está a acontecer?"

    # say L652 bri
    old "What you're seeing is the result of a difficult spell being casted by an inexpert hand."
    new "B:bri: Isto é o que tu e esse idiota fizeram!"

    # say L658 pla
    old "Ok, but what's your plan to fix all this?"
    new "Tudo bem, mas qual é o teu plano para resolver tudo isto?"

    # say L659 bri
    old "Just watch."
    new "T(bri|tu|say): Só vê."

    # say L665 bri
    old "Now! Quick! We have to go to your house to stabilize it!"
    new "B:bri: Apenas vê."

    # say L667 pla
    old "Woah, Woah! What do you mean?!"
    new "B:bri: Agora! depressa! Temos de ir para tua casa estabilizá-lo!"

    # say L668 pla
    old "Are you planning on putting that in my house?"
    new "B:pla: Woah, Woah! O que queres dizer com isso?!"

    # say L669 bri
    old "Don't worry nothing will happen."
    new "B:pla: Tu vais pôr isso na minha casa?"

    # say L670 bri
    old "Unlike your little friend, I know how to do things properly."
    new "B:bri: Não te preocupes, nada vai acontecer."

    # say L672 bri
    old "So, let's hurry and go to your house!"
    new "B:bri: Ao contrário da tua pequena amiga, eu sei fazer as coisas direito."

    # say L674 pla
    old "R- Right!"
    new "B:bri: Então, vamos depressa para tua casa!"

    # say L680 pla
    old "So, what now?"
    new "A:bri: Vou invocar o portal aqui."

    # say L681 bri
    old "I'm going to invoke the portal here."
    new "T(bri|tu|say): Vou invocar o portal aqui."

    # say L682 pla
    old "Oh wow..."
    new "B:bri: Vou invocar o portal aqui."

    # say L707 pla
    old "Uhh... So, does that mean that we can go to the magical world now?"
    new "T(pla|tu|say): Hmm... Então, isso significa que podemos ir para o mundo mágico agora?"

    # say L709 bri
    old "Of course not. Going from one world to another is not that easy!"
    new "T(bri|tu|say): Claro que não. Passar de um mundo para outro não é assim tão fácil!"

    # say L710 bri
    old "To work, this portal needs a massive amount of magic to finish its development."
    new "T(bri|tu|say): Para funcionar, este portal precisa de uma quantidade massiva de magia para completar o seu desenvolvimento."

    # say L711 bri
    old "What it was doing before was sucking all of the magic power around, without any control or direction."
    new "B:bri: Para funcionar, este portal precisa de uma quantidade massiva de magia para completar o seu desenvolvimento."

    # say L715 bri
    old "That could've ended the world."
    new "B:bri: O que estava a fazer antes era sugar todo o poder mágico à volta, sem qualquer controlo ou direção."

    # say L719 bri
    old "I just stabilized it so that it wouldn't continue extracting magic from all around and destroy the world."
    new "T(bri|tu|say): Apenas estabilizei para que não continuasse a extrair magia de tudo à volta e destruísse o mundo."

    # say L724 bri
    old "What we must do now is feed it magic power in a more controlled way."
    new "B:bri: Estabilizei-o para que não continue a extrair magia de tudo à volta e destrua o mundo."

    # say L728 pla
    old "Uh... ok."
    new "T:pla: Hum... ok."

    # say L732 pla
    old "So, how do we feed it magic power now?"
    new "B:pla: Uh... ok."

    # say L736 bri
    old "Well, normally it would be just a simple issue of using the eye of Agamoto to stock up in magic power."
    new "B:pla: Então, como alimentamos com poder mágico agora?"

    # say L737 bri
    old "And then just release it in the portal."
    new "E agora, devido a ti e ao teu pequeno amigo terem estragado tudo."

    # say L741 bri
    old "But now, due to you and your little friend messing up."
    new "T(bri|tu|say): Mas agora, devido a ti e ao teu pequeno amigo a estragarem tudo."

    # say L742 bri
    old "It extracted a lot of free-flowing energy from the world."
    new "B:bri: Mas agora, devido a ti e ao teu pequeno amigo a estragarem tudo."

    # say L744 bri
    old "We can get it back, but it's going to take a longer time. And it will be a lot more dangerous."
    new "T(bri|tu|dizer): Vamos recuperá-lo, mas vai demorar mais tempo. E será muito mais perigoso."

    # say L748 bri
    old "All thanks to you and that stupid little shinigami with which you have been playing."
    new "T(bri|tu|say): Tudo graças a ti e àquela estúpida shinigami com a qual andas a brincar."

    # say L749 pla
    old "I'm sorry Brixxida, all I wanted was to help, you know?"
    new "B:bri: Tudo graças a ti e àquela estúpida pequena shinigami com a qual tens andado a brincar."

    # say L753 bri
    old "Hmph."
    new "T(bri|tu|say): Hmph."

    # say L754 pla
    old "So, what can we do to make the portal work?"
    new "Bem, a única maneira é alimentar o poder mágico..."

    # say L755 bri
    old "Well, the only way is to seed the magic power..."
    new "B:pla: Então, o que podemos fazer para fazer o portal funcionar?"

    # say L757 pla
    old "Seed the magic power? What's that?"
    new "A:bri: É um ritual mágico que usamos para concentrar poder mágico."

    # say L758 bri
    old "It's a magic ritual we use to concentrate magic power."
    new "T(bri|tu|say): É um ritual mágico que usamos para concentrar poder mágico. A:bri: Incubando-o dentro dos corpos humanos."

    # say L759 bri
    old "By incubating it inside the bodies of humans."
    new "B:bri: É um ritual mágico que usamos para concentrar poder mágico."

    # say L760 bri
    old "The power grows and concentrates over time. Until it finally flows out and into the portal."
    new "T(bri|tu|say): O poder cresce e se concentra ao longo do tempo. Até que finalmente flui para fora e entra no portal."

    # say L762 pla
    old "Ok, I think I get it. So, how do we do it?"
    new "B:bri: O poder cresce e se concentra ao longo do tempo. Até que finalmente flui e entra no portal."

    # say L763 bri
    old "There's only one real way to do it. You have to plan the seed inside the body."
    new "B:pla: Ok, acho que percebi. E então, como fazemos isso?"

    # say L764 bri
    old "Once inside it gestates and grows, until it's time to come out."
    new "B:bri: Só há uma maneira verdadeira de o fazer. Tens de planear a semente no interior do corpo."

    # say L766 pla
    old "Ok, but how do I do it?"
    new "B:bri: Uma vez dentro, ele se desenvolve e cresce, até ser hora de sair."

    # say L768 bri
    old "Well, you have to seed them the same way you gather and give magic power out."
    new "B:pla: Ok, mas como é que faço isso?"

    # say L769 pla
    old "Woah! Woah! Woah! You mean I have to impregnate them?!"
    new "B:bri: Bem, tens de os fertilizar da mesma forma que recolhes e dás poder mágico."

    # say L771 bri
    old "In human terms, that's what it's called, yeah."
    new "T(bri|tu|say): Em termos humanos, é isso mesmo, sim."

    # say L773 pla
    old "What the fuck? Are you for real?"
    new "T: Que raio? Estás a falar a sério?"

    # say L774 pla
    old "I'm way too young to have children!"
    new "B:pla: Que raio? Estás a falar a sério?"

    # say L782 bri
    old "But don't worry, it's not the way you think."
    new "B:pla: Sou demasiado nova para ter filhos!"

    # say L784 bri
    old "During the growing period, the magic power will concentrate without a particular form."
    new "B:bri: Mas não te preocupes, não é como tu pensas."

    # say L787 bri
    old "And it will only change if, you decide it to be anything in particular."
    new "B:bri: Durante o período de crescimento, o poder mágico se concentrará sem uma forma específica."

    # say L789 bri
    old "It means that if you just take out all of the magic power from these women it will just be energy."
    new "T(bri|tu|say): Significa que se tirares toda a energia mágica destas mulheres, será apenas energia."

    # say L790 bri
    old "Pure magic energy, without any form in particular."
    new "T(bri|tu|say): Energia mágica pura, sem qualquer forma específica."

    # say L791 bri
    old "And it will only take the shape of a human infant if you decide that you will leave energy remains behind."
    new "B:bri: Energia mágica pura, sem qualquer forma em particular."

    # say L793 bri
    old "Otherwise there won't be any reproduction between you and the humans we use for this ritual."
    new "B:bri: E só assumirá a forma de um bebé humano se decidires deixar restos de energia."

    # say L795 pla
    old "I- I see, I guess that's..."
    new "B:bri: Caso contrário, não haverá reprodução entre ti e os humanos que usamos para este ritual."

    # say L796 pla
    old "Fine, I guess?"
    new "B: pla: Eu... Acho que é isso, acho eu."

    # say L798 bri
    old "However, until the magic power is ready to be taken out of their bodies and we do it."
    new "No entanto, até que a força mágica esteja pronta para ser retirada dos seus corpos e nós o façamos."

    # say L799 bri
    old "They will look like they are pregnant."
    new "B:bri: No entanto, até que a energia mágica esteja pronta para ser retirada dos seus corpos e nós o façamos."

    # say L801 bri
    old "The entire process it's going to be very similar to the way you humans gestate your infants."
    new "B:bri: Vão parecer grávidas."

    # say L802 bri
    old "Is just that at the end of it, there won't necessary be another human."
    new "B:bri: O processo inteiro vai ser muito semelhante à forma como vocês, humanos, gestam os vossos bebés."

    # say L803 bri
    old "So, their bodies will just go back to how they were before the ritual started."
    new "B:bri: É só que no final, não necessariamente haverá outro ser humano."

    # say L805 pla
    old "I get it now."
    new "A:bri: Ouve, sei que não gostas disso."

    # say L806 bri
    old "Listen, I know you don't like it."
    new "T(bri|tu|say): Ouve, sei que não gostas disto."

    # say L807 bri
    old "But for now, that's the only way we have to power up the portal and return the magic world to what it was before."
    new "B:bri: Ouve, sei que tu não gostas disto."

    # say L808 bri
    old "Not to mention avoiding the destruction of yours."
    new "B:bri: Mas por agora, é a única forma que temos de ativar o portal e devolver o mundo mágico ao que era antes."

    # say L809 pla
    old "I get it."
    new "T: Entendo."

    # say L810 pla
    old "If I have to do it, I guess there's no choice."
    new "T(pla|tu|say): Se tenho de o fazer, acho que não tenho alternativa."

    # say L811 bri
    old "By the way; from now on, I will be in charge of everything, you get that?"
    new "B:pla: Se tenho de o fazer, acho que não tenho escolha."

    # say L815 bri
    old "No more running around like an idiot with you dumbass shinigami friends messing everything up!!"
    new "B:bri: Aliás; a partir de agora, eu estarei no comando, percebeste?"

    # say L816 pla
    old "Uh. I- sure..."
    new "B:bri: Chega de correr como um idiota com os teus amigos shinigami a estragarem tudo!"

    # say L817 bri
    old "Good, I'm glad you understand that."
    new "A:bri: Agora, prepara-te, porque há muitas coisas que vais precisar de aprender sobre tudo isto."

    # say L819 bri
    old "Now, get ready, because there are a lot of things you will need to learn about all of this."
    new "B:bri: Ótimo, fico contente que percebas isso."

    # say L820 pla
    old "Oh, man... Alright..."
    new "B:bri: Agora, prepara-te, porque há muitas coisas que vais precisar de aprender sobre tudo isto."

    # say L828 pla
    old "I guess I'll leave you here for now..."
    new "T(pla|tu|say): Acho que te deixo aqui por agora..."

    # say L829 pla
    old "I'm so sorry, about this Linnet."
    new "B:pla: Acho que vou deixar-te aqui por agora..."

    # say L830 pla
    old "I promise that I will help you to get free from this."
    new "T(pla|tu|diz): Prometo-te que vou ajudar-te a libertares-te disto."


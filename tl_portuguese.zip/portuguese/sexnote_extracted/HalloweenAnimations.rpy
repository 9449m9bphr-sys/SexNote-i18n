# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/HalloweenAnimations.rpy
translate portuguese strings:

    # say L5 sis
    old "I'm ready... Do your thing and put it in..."
    new "T(sis|tu|diz): Estou pronta... Faz o que tens a fazer e mete-o dentro..."

    # say L6 pla
    old "Alright."
    new "B:sis: Estou pronta... Faz o que tens a fazer e mete-o..."

    # say L12 sis
    old "Oh God... It feels really nice... Your cock feels really nice in my ass..."
    new "B:pla: Tudo bem."

    # say L13 pla
    old "Uhh it feels.... Tight..."
    new "B:sis: Oh Deus... É tão bom... O teu pénis sente-se tão bem no meu cu..."

    # say L43 sis
    old "Ohh God! I'm coming... I'm coming!!!"
    new "Ohh Deus! Estou a gozar... Estou a gozar!!!"

    # say L44 pla
    old "Ahhh...."
    new "A:mo1: Sentes-te bem, querida?"

    # say L59 mo1
    old "Does it feel nice baby?"
    new "B:pla: Ahhh...."

    # say L60 pla
    old "It feels amazing, please don't stop!"
    new "B:mo1: Sentes-te bem, querida?"

    # say L65 mo1
    old "Oh yes! Oh yes! Fuck my tits baby!"
    new "B:pla: É incrível, por favor não pares!"

    # say L66 pla
    old "Ahh... Ahhh"
    new "B:mo1: Oh sim! Oh sim! Fode os meus peitos, bebé!"

    # say L95 pla
    old "I- I am going to... Ahhh"
    new "Goza nas minhas tetas, querido!"

    # say L96 mo1
    old "Cum on my tits honey!"
    new "B: pla: Vou... Ahhh"

    # say L120 sis
    old "It's probably his darkest fantasy..."
    new "B:pla: (OH MEU DEUS NÃO ACREDITO!)"

    # say L125 mo1
    old "And what about if you cum for us?"
    new "B:sis: Provavelmente é a sua fantasia mais sombria..."

    # say L127 sis
    old "Yes! Let's make him cum!"
    new "B:mo1: E se tu gozares para nós?"

    # say L151 pla
    old "Oh my... I- I am going to... "
    new "B:sis: Sim! Vamos fazer com que ele goze!"

    # say L170 mo2
    old "Oh yeah..."
    new "A:mo2: Oh deus, nem consigo pensar em ser fodida por este pénis..."

    # say L174 mo2
    old "Oh god I can't ever think about being fucked by this cock..."
    new "B:mo2: Oh yeah..."

    # say L175 sis
    old "Is fucking amazing... You should try it."
    new "B:mo2: Oh deus, não consigo pensar em ser fodida por este pénis..."

    # say L176 mo2
    old "Definetely I will..."
    new "B:sis: É incrível... Deves experimentar."

    # say L182 mo2
    old "Enought waste of time, I want to fuck! Let's make him cum."
    new "B:mo2: Com certeza que vou..."

    # say L184 sis
    old "Yes! Let's make him cum again!"
    new "B:mo2: Chega de perder tempo, quero foder! Vamos fazer com que ele goze."

    # say L209 mo2
    old "Yeesss..."
    new "Bem... O que raio se está a passar aqui?"

    # say L213 pla
    old "Alright... What the fuck is happening here?"
    new "Oh Deus! É tão grande..."

    # say L224 mo2
    old "Oh God! It's fucking huge..."
    new "B:pla: Tudo bem... O que raio se está a passar aqui?"

    # say L231 mo2
    old "Oh my fucking God, he is drilling me!"
    new "B:mo2: Um pouco, mas está tão bom..."

    # say L261 mo2
    old "Ahhhhh Ahhh, I'm cumming!"
    new "B:mo2: Oh yessss! Mais forte, foda-me mais forte, baby!"

    # say L265 mo1
    old "Well, it's my turn now..."
    new "B: Ahhhhh Ahhh, estou a gozar!"

    # say L267 mo2
    old "I will bring one of our toys..."
    new "B:mo1: Bem, agora é a minha vez..."

    # say L283 mo2
    old "We haven't tried anal sex in a long time... How does it feel to be completely filled?"
    new "B:mo2: Vou trazer um dos nossos brinquedos..."

    # say L284 mo1
    old "Ohhhhh God, this is like a double penetration! It's to much..."
    new "B:mo2: Não experimentamos sexo anal há muito tempo... Como é estar completamente preenchida?"

    # say L289 mo1
    old "OHHH WOW! I can't handle this!"
    new "B:mo1: Ohhhhh Deus, isto é como uma dupla penetração! É demasiado..."

    # say L290 mo1
    old "Ahhh Ahhhh!"
    new "B:mo1: OHHH WOW! Não consigo aguentar isto!"

    # say L321 mo1
    old "I- I... Ahhhhh I- am... Cumming!"
    new "B:mo1: Oh oh simmmm! Nunca senti nada assim!"

    # say L326 pla
    old "Holy shit... I'm fucking dry."
    new "B:mo1: Eu... Ahhhhh Estou... A gozar!"

    # say L327 sis
    old "Oh no... I have been waiting my turn."
    new "B:pla: Merda... Estou seco."

    # say L345 mo1
    old "Honey, let him rest a bit, I'm going to help him get ready to fuck you too."
    new "B:sis: Oh não... Estive à espera da minha vez."

    # say L346 sis
    old "Hmmm Alright."
    new "B:mo1: Meu amor, deixa-o descansar um pouco, vou ajudá-lo a preparar-se para te foder também."

    # say L350 sis
    old "Now! I want it now!"
    new "Agora! Quero agora!"

    # say L351 mo1
    old "Oh, honey just let me enjoy it a little bit more..."
    new "B: Irmã: Agora! Quero agora!"

    # say L352 sis
    old "Hmmm..."
    new "B:mo1: Oh, querida, deixa-me só aproveitar um pouco mais..."

    # say L392 mo1
    old "Does it feel good honey?"
    new "B:sis: Ohhhh sim, é isto que eu quero..."

    # say L393 sis
    old "It feels great, I never get tired of this..."
    new "B:mo1: Sentes-te bem, querida?"

    # say L406 sis
    old "Yes! He is making me cum!"
    new "B:mo1: Ah, mas está tão bom."

    # say L430 sis
    old "Yesss Yesss... I'm cumming!!!"
    new "B:sis: Sim! Ele está a fazer-me gozar!"

    # say L431 sis
    old "Ahhhhhh..."
    new "B:sis: Yesss Yesss... Estou a gozar!!!"

    # say L432 mo1
    old "I want it on my mouth."
    new "Quero na minha boca."


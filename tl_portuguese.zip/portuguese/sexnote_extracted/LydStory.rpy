# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/LydStory.rpy
translate portuguese strings:

    # say L11 ann
    old "I mean mom, online dating?!! What the fuck?!!!"
    new "A:ann: Tu não pensavas noutra coisa?"

    # say L12 ann
    old "You couldn't think about anything else?"
    new "B:ann: Quero dizer, mãe, dating online?!!! Que raio?!!!"

    # say L13 ann
    old "Why don't you just join a knitting group? Or play bingo like any other widow?"
    new "B:ann: Não conseguiste pensar em mais nada?"

    # say L14 lyd
    old "What's so bad about what I said?"
    new "A:lyd: Não acho que haja nada de errado com uma mulher solteira a pensar em conhecer novas pessoas."

    # say L15 lyd
    old "I don't think there's anything wrong with a single woman thinking about meeting new people."
    new "Agora que o teu pai já não está aqui, gostava de fazer alguns novos amigos, e..."

    # say L16 lyd
    old "Now that your father's not here I'd like to make some new friends, and..."
    new "B:lyd: Não acho que haja nada de errado com uma mulher solteira a pensar em conhecer novas pessoas."

    # say L17 ann
    old "Do you think you're at the age where you should be meeting people through a dating app?"
    new "A:ann: Além disso, quem raio é que vai falar contigo? A uma avó viúva?"

    # say L18 ann
    old "Besides, who the hell is going to talk to you? To a widowed grandmother?"
    new "B:ann: Tu achas que já tens idade para conhecer pessoas através de uma aplicação de encontros?"

    # say L19 ann
    old "If you want to meet new people why don't you just go to an elderly home?"
    new "B:ann: Além disso, quem diabo é que vai falar contigo? Com uma avó viúva?"

    # say L20 ann
    old "Maybe there you'll find some people your age."
    new "B:ann: Se queres conhecer novas pessoas, por que não vais a uma casa de repouso?"

    # say L21 lyd
    old "It's that way to talk to your mother?"
    new "B:ann: Talvez lá encontres pessoas da tua idade."

    # say L22 lyd
    old "Are you listening to yourself?"
    new "B:lyd: É assim que falas com a tua mãe?"

    # say L23 ann
    old "I don't care!"
    new "T(ann|tu|dizes): Não me importo!"

    # say L24 ann
    old "You should be the one thinking about what you're saying! Dad's not even been dead for a year!"
    new "T(ann|tu|dizes): Deverias pensar bem no que estás a dizer! O pai nem sequer está morto há um ano!"

    # say L25 ann
    old "And here you are thinking about picking guys up like you're some... Ugh!"
    new "B:ann: Deverias ser tu a pensar no que estás a dizer! O pai nem sequer está morto há um ano!"

    # say L26 ann
    old "I don't want my mother to go around giving herself up to some randoms on the internet."
    new "B:ann: E aqui estás tu a pensar em arranjar rapazes como se fosses... Ugh!"

    # say L27 ann
    old "Listen, you can do what you want, but don't expect me to help you with anything..."
    new "B:ann: Não quero que a minha mãe ande a dar-se a desconhecidos na internet."

    # say L28 ann
    old "Ugh! I don't even want to keep talking to you!"
    new "B:ann: Ouve, podes fazer o que quiseres, mas não contes com a minha ajuda para nada..."

    # say L46 pla
    old "Uhhh... Just the last bit of it, I think..."
    new "T(pla|tu|say): Uhhh... Apenas a última parte, acho..."

    # say L47 pla
    old "All I heard was Anna being as annoying as always."
    new "B:pla: Uhhh... Apenas a última parte, acho..."

    # say L48 pla
    old "What's the matter? Why is she acting up now?"
    new "A:lyd: Bem... Como posso dizer?"

    # say L50 lyd
    old "Well... How can I put it?"
    new "B:pla: O que se passa? Porque é que ela está a agir assim agora?"

    # say L51 lyd
    old "Do you remember the other day when you went with me to church?"
    new "B:lyd: Bem... Como posso dizer?"

    # say L52 pla
    old "Hmmm, yeah."
    new "B:lyd: Tu te lembras do outro dia quando foste comigo à igreja?"

    # say L53 lyd
    old "The thing is, ever since we ran into Mrs. Jones, I've been thinking and..."
    new "B:pla: Hmmm, sim."

    # say L54 lyd
    old "I don't want to be like that [pla]. Her husband died five years ago, and she's been unable to move on from that."
    new "T(lyd|tu|say): Não quero ser como a [pla]. O marido dela morreu há cinco anos, e ela não conseguiu superar isso."

    # say L56 lyd
    old "You know, all she ever does is talk about God and faith. Frankly, it's pitying."
    new "B:pla: Ela não avançou? O que queres dizer?"

    # say L57 lyd
    old "I decided I don't want that to happen to me too."
    new "B:lyd: Sabes, tudo o que ela faz é falar de Deus e da fé. Francamente, é uma pena."

    # say L60 lyd
    old "So, I've been trying to get myself out there, I've gone to a couple of bars, and clubs."
    new "B:lyd: Decidi que não quero que isso aconteça comigo também."

    # say L61 lyd
    old "Trying to meet new people, you know?"
    new "B:lyd: Então, tenho tentado sair mais, fui a alguns bares e discotecas."

    # say L62 lyd
    old "But, it's been to no avail. It turns out people don't really go to bars or clubs to meet new people anymore."
    new "B:lyd: A tentar conhecer novas pessoas, sabes?"

    # say L64 lyd
    old "It's not as common to go out to meet new people. Nowadays, if someone goes out it's because they already have plans with someone else."
    new "T(lyd|tu|say): Não é tão comum sair para conhecer novas pessoas. Hoje em dia, se alguém sai, é porque já tem planos com outra pessoa."

    # say L65 lyd
    old "So, I thought maybe I should do what I heard young people are doing these days, and try online dating."
    new "B:lyd: Não é tão comum sair para conhecer novas pessoas. Hoje em dia, se alguém sai, é porque já tem planos com outra pessoa."

    # say L66 pla
    old "Well, that sounds like a good idea."
    new "B:lyd: Então, pensei que talvez devesse fazer o que ouvi que os jovens estão a fazer hoje em dia e experimentar o dating online."

    # say L68 lyd
    old "I guess so, but the whole internet thing just flies over my head. It's so complicated."
    new "B:pla: Bem, isso parece uma boa ideia."

    # say L69 lyd
    old "Given that I can't really do it myself I asked Anna to help me out."
    new "B:lyd: Acho que sim, mas toda essa coisa da internet passa direto por cima da minha cabeça. É tão complicado."

    # say L70 lyd
    old "But, you already saw how that turned out."
    new "B:lyd: Dado que eu não consigo fazer isso, pedi à Anna para me ajudar."

    # say L71 pla
    old "Hmph, I did..."
    new "B:lyd: Mas, tu já viste como isso acabou."

    # say L72 lyd
    old "Although maybe she's right. Maybe I'm just too old to be thinking about doing things like online dating and such."
    new "B:pla: Hmph, eu fiz..."

    # say L73 lyd
    old "I'm just an old, lonely widow after all... So I'll just give up."
    new "B:lyd: Embora talvez ela tenha razão. Talvez eu seja apenas velha demais para pensar em coisas como encontros online e afins."

    # say L74 pla
    old "Woah, woah, wait a minute."
    new "B:lyd: Sou apenas uma velha viúva solitária afinal... Vou desistir."

    # say L75 pla
    old "Listen, you don't have to say all those bad things about you, and you also shouldn't say that you're going to give up."
    new "B:pla: Calma, calma, espera aí."

    # say L76 pla
    old "I actually agree with you, you have every right to live your life any way you want to."
    new "B:pla: Ouve, não tens de dizer todas essas coisas más sobre ti, e também não deves dizer que vais desistir."

    # say L77 pla
    old "Anna's just jealous because you're her mother. And she's always very possessive."
    new "B:pla: Na verdade, concordo contigo, tu tens todo o direito de viver a tua vida como quiseres."

    # say L78 pla
    old "But you're free to do whatever you want. And I'm totally sure you can be with anyone you want to."
    new "B: Anna está apenas com ciúmes porque tu és a mãe dela. E ela é sempre muito possessiva."

    # say L82 pla
    old "Of course I do! Anyone would be lucky to meet you. I'm sure of it."
    new "B:pla: Mas tu és livre para fazer o que quiseres. E estou totalmente certo de que podes estar com quem tu quiseres."

    # say L83 pla
    old "In fact, if Anna won't do it. Let me help you, I'll set up your profile for you."
    new "B:pla: Claro que sim! Qualquer pessoa teria sorte em te conhecer. Tenho a certeza disso."

    # say L89 pla
    old "Oh no, there's no need. These days the best and easiest ways to meet people online are dating apps."
    new "B:lyd: Vamos para o meu quarto, o meu computador está lá."

    # say L90 pla
    old "You know, on the phone. Have you ever heard of Tinder?"
    new "B:pla: Oh não, não há necessidade. Hoje em dia, as melhores e mais fáceis maneiras de conhecer pessoas online são os aplicativos de dating."

    # say L91 lyd
    old "Tinder? No, no idea what it is."
    new "B:pla: Sabes, no telemóvel. Já ouviste falar do Tinder?"

    # say L92 pla
    old "Well, it's this new dating app, in which you create a profile with your information on it."
    new "B:lyd: Tinder? Não, não faço ideia do que é."

    # say L93 pla
    old "The profile is public, so anyone can see it, and decide if they would like to talk to you or not."
    new "B:pla: Bem, é este novo aplicativo de dating, no qual crias um perfil com as tuas informações."

    # say L94 lyd
    old "I see, what kind of information should go in there?"
    new "B:pla: O perfil é público, por isso qualquer pessoa pode vê-lo e decidir se quer falar contigo ou não."

    # say L95 pla
    old "Nothing private, just the type of person you are, what you like and dislike."
    new "T: Nada de privado, só o tipo de pessoa que és, o que gostas e o que não gostas."

    # say L96 pla
    old "And a couple of pictures of you, so they know how you look."
    new "B:pla: Nada de privado, só o tipo de pessoa que és, o que gostas e o que não gostas."

    # say L97 pla
    old "You can also write what you want to find in a partner, so they know if you'll like them."
    new "B:pla: E algumas fotos tuas, para que eles saibam como és."

    # say L98 lyd
    old "That sounds interesting. How does it work?"
    new "B:pla: Podes escrever também o que procuras num parceiro, para que eles saibam se vais gostar deles."

    # say L99 pla
    old "It's very simple, once your profile is on the app it will be visible to people in it."
    new "T(pla|tu|say): É muito simples, uma vez que o teu perfil está na app, ele será visível para as pessoas nela."

    # say L100 pla
    old "And they get to decide if they would like to meet you."
    new "B:pla: É muito simples, uma vez que o teu perfil está na app, ele será visível para as pessoas nela."

    # say L101 pla
    old "If they do, all they have to do is swipe your profile to the right, if they don't they swipe left."
    new "B:pla: E eles decidem se querem conhecer-te."

    # say L102 pla
    old "And it's the same with you, if you see a profile you swipe either right or left, depending on if you like them or not."
    new "B:pla: Se eles gostarem, só têm de deslizar o perfil para a direita, se não gostarem, deslizam para a esquerda."

    # say L103 pla
    old "If both of you swipe right, that means it's a match, and you can both start talking."
    new "B:pla: E é a mesma coisa contigo, se vês um perfil swipas para a direita ou para a esquerda, dependendo de gostares ou não."

    # say L104 lyd
    old "Hmm, that sounds very simple and practical."
    new "B:pla: Se ambos swiparem para a direita, isso significa que é uma correspondência, e vocês dois podem começar a conversar."

    # say L105 pla
    old "It is, come on, I'll help you set your profile."
    new "T: É, vem, eu ajudo-te a configurar o teu perfil. Primeiro, é definir a tua bio, é só uma pequena descrição de ti e das coisas que gostas e dos teus interesses."

    # say L112 pla
    old "Ok, so, first of all, is setting up your bio, it's just a small description of you and the things you like and your interests."
    new "B:pla: É, vamos lá, vou ajudar-te a configurar o teu perfil."

    # say L113 lyd
    old "Ok, so let me see, hmm... I got it!"
    new "B:pla: Ok, então, em primeiro lugar, é definir a tua bio, é apenas uma pequena descrição de ti e das coisas que gostas e dos teus interesses."

    # say L114 lyd
    old "I'm a single woman who enjoys the simple things in life. I love long walks, enjoying nature and talking."
    new "B:lyd: Ok, então deixa-me ver, hmm... Já sei!"

    # say L115 lyd
    old "My perfect evening is a summer afternoon enjoying a glass of merlot and reading a good book."
    new "B:lyd: Sou uma mulher solteira que aprecia as coisas simples da vida. Adoro longas caminhadas, desfrutar da natureza e conversar."

    # say L124 pla
    old "Ok, so that's your profile all set."
    new "B:lyd: A minha tarde perfeita é uma tarde de verão a saborear um copo de merlot e a ler um bom livro."

    # say L125 lyd
    old "Oh wow, that took no time, and it looks great!"
    new "B:pla: Ok, então o teu perfil está tudo pronto."

    # say L127 lyd
    old "So? What do I do now?"
    new "B:lyd: Oh wow, isso não demorou nada e ficou ótimo!"

    # say L128 pla
    old "Well, now that you have your own profile, what you have to do is look at other people's profiles."
    new "B:lyd: E então? O que faço agora?"

    # say L129 pla
    old "And see if you like any of them. You do this by swiping right or left..."
    new "B:pla: Agora que tens o teu próprio perfil, o que tens de fazer é ver os perfis dos outros."

    # say L130 lyd
    old "Woah, woah, that's a little too fast for me, and it sounds a bit complicated."
    new "B:pla: E vê se gostas de algum deles. Fazes isso deslizando para a direita ou para a esquerda..."

    # say L131 lyd
    old "Hmm, why don't you do it for me?"
    new "B:lyd: Uau, uau, isso é um pouco rápido para mim e parece um bocado complicado."

    # say L133 pla
    old "Hmm... ok sure, no problem, it's not hard, once you get it, it will be really easy."
    new "B:lyd: Hmm, por que não fazes isso por mim?"

    # say L134 pla
    old "Alright, let's start, but, if I'm the one doing it, I won't know what kind of guy you're into."
    new "B:pla: Hmm... ok, claro, não há problema, uma vez que pegues o jeito, será mesmo fácil."

    # say L135 pla
    old "Why don't you tell me what you're looking for in a man?"
    new "B:pla: Tudo bem, vamos começar, mas, se sou eu a fazer, não vou saber que tipo de homem te agrada."

    # say L136 pla
    old "That way I'll know who to select."
    new "A:lyd: O que procuro? Hum, vamos ver..."

    # say L137 lyd
    old "What I'm looking for? Hmm, let's see..."
    new "B:pla: Assim saberei quem selecionar."

    # say L138 lyd
    old "Well, I tend to like guys with beards, I think they look very manly, but it's not a requirement."
    new "B:lyd: O que estou à procura? Hmm, vamos ver..."

    # say L139 pla
    old "Hmm, ok, I'll keep that in mind."
    new "B:lyd: Bem, eu gosto de rapazes com barba, acho que eles ficam muito viris, mas não é um requisito."

    # say L140 lyd
    old "But, be sure that it's a beard, not a mustache, I hate mustaches."
    new "Mas, certifica-te de que é uma barba, não um bigode, eu detesto bigodes. O meu marido costumava ter um e nunca consegui convencê-lo a raspá-lo."

    # say L141 lyd
    old "My husband used to have one and I was never able to get him to shave it."
    new "B:lyd: Mas, certifica-te de que é uma barba, não um bigode, detesto bigodes."

    # say L142 pla
    old "Sure, that's an important detail."
    new "T:pla|tu|say: Claro, é um detalhe importante. A:pla: Mais alguma coisa?"

    # say L143 pla
    old "Anything else?"
    new "B:pla: Claro, é um pormenor importante."

    # say L145 lyd
    old "I don't like bald men, I prefer a nice head of hair, but no white hair, not even at the sides."
    new "B:pla: Algo mais?"

    # say L146 pla
    old "Alright, no bald men or white hair."
    new "B:lyd: Não gosto de homens carecas, prefiro um belo cabelo, mas sem cabelos brancos, nem nas têmporas."

    # say L147 lyd
    old "Well, to be honest, I'm looking for a young guy, so I'd rather he didn't look old, like wrinkles and stuff..."
    new "B:pla: Tudo bem, sem homens carecas ou de cabelo branco."

    # say L148 pla
    old "Got it. Something else?"
    new "T(pla|tu|say): Entendido. Mais alguma coisa?"

    # say L149 lyd
    old "Oh right, I don't know why but I have never been into gingers... So, no red hair, nothing personal..."
    new "B:pla: Entendido. Algo mais?"

    # say L150 pla
    old "Hmm, Ok, I think I got everything. I'll try my best to find you someone like that."
    new "B:lyd: Ah, é verdade, não sei porquê mas nunca fui fã de ruivas... Então, sem cabelo vermelho, nada pessoal..."

    # say L152 lyd
    old "Woah, thank you pumpkin, this is exciting!"
    new "B:pla: Hmm, Ok, acho que tenho tudo. Vou tentar encontrar-te alguém assim."

    # say L167 pla
    old "Ok Lydia, here you go, I think I got just what you wanted."
    new "B:lyd: Uau, obrigada querida, isto é emocionante!"

    # say L168 pla
    old "And look at that, you already matched with a couple of them!"
    new "B:pla: Ok Lydia, aqui tens, acho que consegui o que querias."

    # say L169 pla
    old "If you want to you can start talking with them."
    new "B:pla: E vê lá isso, já combinaste com alguns deles!"

    # say L170 lyd
    old "That's wonderful pumpkin!"
    new "B:pla: Se quiseres, podes começar a falar com eles."

    # say L171 lyd
    old "Oh, they all look very interesting indeed!"
    new "B:lyd: Is maravilhoso, querida!"

    # say L172 lyd
    old "This is great, I'll start talking to them."
    new "B:lyd: Oh, parecem todos muito interessantes mesmo!"

    # say L173 pla
    old "I'm glad you think they're good picks."
    new "T: Fico contente que aches que são boas escolhas."

    # say L177 lyd
    old "I think it would be better if you leave before she comes back."
    new "B:lyd: Mas, a Anna pode voltar logo, e tenho medo do que ela vai dizer se nos vir a fazer isto."

    # say L181 pla
    old "Oh, sure, you're right! I'd forgotten about Anna."
    new "B:lyd: Acho que é melhor tu ires embora antes dela voltar."

    # say L182 pla
    old "I'll come back later to see how it went with the guys, ok?"
    new "B:pla: Oh, claro, tens razão! Eu tinha esquecido da Anna."

    # say L184 lyd
    old "Sure, but please come in the afternoon, when Anna is usually out."
    new "B:pla: Vou voltar mais tarde para ver como correu com os rapazes, ok?"

    # say L185 pla
    old "Alright, I will come in the afternoon."
    new "B:lyd: Claro, mas vem à tarde, quando a Anna costuma estar fora."

    # say L186 lyd
    old "Thank you so much pumpkin, I really appreciate your help."
    new "B:pla: Tudo bem, vou passar à tarde."

    # say L187 pla
    old "No biggie, I'm happy to help, bye!"
    new "Não te preocupes, estou feliz por ajudar, adeus!"

    # say L203 pla
    old "Damn, I think I didn't do a good job with this Lydia, sorry."
    new "B:pla: Não há problema, estou feliz em ajudar, adeus!"

    # say L204 lyd
    old "Really? Did the phone fail?"
    new "B:pla: Merda, acho que não fiz um bom trabalho com isso, Lydia, desculpa."

    # say L205 pla
    old "No, no, it's just that I think I selected some profiles wrong. So you may not like them too much."
    new "B:lyd: Mesmo? O telemóvel falhou?"

    # say L206 lyd
    old "Aw, that's ok, you don't need to stress too much about it."
    new "B:pla: Não, não, é só que acho que selecionei alguns perfis errados. Então talvez tu não gostes muito deles."

    # say L207 lyd
    old "We're both learning about this kind of thing. It's ok, really."
    new "B:lyd: Ah, não te preocupes, não precisas de stressar muito com isso."

    # say L208 pla
    old "Thanks... Well, I think there's still a couple of matches, so you may talk to a couple of them, if you want to of course."
    new "Obrigado... Bem, acho que ainda há um par de partidas, então podes falar com umas duas, se quiseres, claro."

    # say L209 lyd
    old "I'll do it, maybe they're not that bad. But for now, I think it would be better if you left."
    new "B:pla: Obrigado... Bem, acho que ainda há um par de partidas, então podes falar com umas duas, se quiseres, claro."

    # say L210 lyd
    old "Anna has been out for a little while now, so she could come back at any moment."
    new "B:lyd: Vou fazer, talvez não sejam assim tão más. Mas por agora, acho melhor que tu fosses embora."

    # say L211 lyd
    old "I don't even know what she would say if she finds out about this."
    new "B:lyd: A Anna já saiu há um bocado, por isso pode voltar a qualquer momento."

    # say L212 lyd
    old "I don't want any more trouble with her. So it's best if you leave."
    new "B:lyd: Nem sei o que ela diria se descobrisse isso."

    # say L214 pla
    old "Yeah, you're right. I'll come back later to help again, bye Lydia."
    new "B:lyd: Não quero mais problemas com ela. É melhor tu ires embora."

    # say L235 lyd
    old "Hi pumpkin! How are you?"
    new "Olá, querida! Como estás?"

    # say L237 pla
    old "Hey, it's Anna around?"
    new "B:lyd: Olá querida! Como estás?"

    # say L238 lyd
    old "She isn't, why?"
    new "B:pla: Olá, a Anna está por perto?"

    # say L243 pla
    old "Well, I thought I could help you again with the app."
    new "B:lyd: Ela não está, porquê?"

    # say L244 pla
    old "How has it been going since the last time? Have you talked to anybody?"
    new "B:pla: Bem, pensei que pudesse ajudar-te de novo com a app."

    # say L245 lyd
    old "Oh, not really, I've had a couple of conversations with some people, but nothing interesting."
    new "B:pla: Como tem sido desde a última vez? Falaste com alguém?"

    # say L248 pla
    old "Well, that's why I'm here, to help you out. So let's see the app."
    new "B:lyd: Oh, não realmente, tive algumas conversas com algumas pessoas, mas nada de interessante."

    # say L262 pla
    old "Ok, here you go, I think I got just what you wanted."
    new "B:pla: Bem, é por isso que estou aqui, para te ajudar. Vamos ver o app."

    # say L270 pla
    old "With that done, I think it's better if I leave."
    new "T(pla|tu|say): Com isso feito, acho melhor eu ir embora."

    # say L272 pla
    old "We wouldn't want Anna to get here and catch us."
    new "B:pla: Com isso feito, acho melhor ir embora."

    # say L321 pla
    old "Thanks... Well, I think there's still a couple of them you could talk to if you want to of course."
    new "Oi Lydia, como estás?"

    # say L347 pla
    old "Hi Lydia, how are you?"
    new "B:pla: Obrigado... Bem, acho que ainda há umas duas pessoas com quem podes falar se quiseres, claro."

    # say L350 lyd
    old "Well... the thing is..."
    new "B:pla: O quê? Aconteceu alguma coisa? Porque é que estás tão triste?"

    # say L351 lyd
    old "Ugh, I've been talking with a couple of men on tinder, and..."
    new "B:lyd: Bem... a questão é..."

    # say L352 pla
    old "Oh, did I make a mistake choosing their profiles? Is there something wrong with them?"
    new "B:lyd: Ugh, tenho estado a falar com uns quantos homens no tinder, e..."

    # say L354 lyd
    old "Hmm, their perfectly nice gentlemen, very smart and all."
    new "B:pla: Oh, fiz um erro ao escolher os seus perfis? Há algo de errado com eles?"

    # say L355 lyd
    old "But, they're very old! As old as my ex husband was! And I don't want that!"
    new "B:lyd: Hmm, são homens perfeitamente agradáveis, muito inteligentes e tudo mais."

    # say L356 lyd
    old "I mean, I just widowed a man that age."
    new "B:lyd: Mas, eles são muito velhos! Tão velhos quanto o meu ex-marido! E eu não quero isso!"

    # say L357 lyd
    old "When I talked about dating again I was thinking more along the lines of young, energetic men, full of vitality... You know?"
    new "B:lyd: Quero dizer, acabei de viúvar um homem daquela idade."

    # say L359 pla
    old "I- I guess I do."
    new "B:lyd: Quando falei em voltar a namorar, estava a pensar mais em homens jovens, cheios de energia, plenos de vitalidade... Sabes?"

    # say L360 lyd
    old "Why is the app only pairing me with these old guys?"
    new "T(lyd|tu|diz): Porque é que a app só me está a emparelhar com estes velhos?"

    # say L361 pla
    old "Uhh, I don't really know why."
    new "T: Uhh, não sei bem porquê."

    # say L362 pla
    old "Maybe it's the algorithm putting you with people your age."
    new "B:pla: Uhh, não sei bem porquê."

    # say L363 pla
    old "But, I think there might be something we can do about that."
    new "T(pla|tu|say): Mas, acho que podemos fazer algo em relação a isso."

    # say L364 lyd
    old "Yeah? What is it?"
    new "B:pla: Mas, acho que podemos fazer algo a respeito."

    # say L365 pla
    old "Well, we could 'fix' your profile. Improve it a little."
    new "B:lyd: Sim? O que é?"

    # say L366 lyd
    old "What do you mean by 'fix'?"
    new "B:pla: Bem, poderíamos 'melhorar' o teu perfil. Aperfeiçoá-lo um pouco."

    # say L367 pla
    old "We could, for example, put a better picture of you. Or maybe another description of you in the bio."
    new "T(pla|tu|say): Podíamos, por exemplo, colocar uma foto melhor tua. Ou talvez outra descrição tua na bio."

    # say L368 pla
    old "Something that will be more attractive to younger men."
    new "B:pla: Podíamos, por exemplo, colocar uma foto melhor tua. Ou talvez outra descrição tua na bio."

    # say L370 lyd
    old "That sounds like a great idea!"
    new "T(lyd|tu|say): Isso soa como uma ótima ideia!"

    # say L371 pla
    old "Yeah, keeping in mind that those are the things that people will see when they go to your profile."
    new "T: Sim, tendo em mente que essas são as coisas que as pessoas vão ver quando forem ao teu perfil. Podemos trabalhar nelas para conseguir que mais jovens deslizem para a direita em vez de para a esquerda no teu perfil."

    # say L372 pla
    old "We could work on them to get more young people to swipe right instead of left on your profile."
    new "B:pla: Sim, lembrando que essas são as coisas que as pessoas vão ver quando forem ao teu perfil."

    # say L373 lyd
    old "That'd be perfect, let's do it."
    new "A:pla: A primeira coisa é a foto, tens alguma foto em que pareças um pouco mais descontraído?"

    # say L382 pla
    old "The first thing is the picture, do you have any picture in which you look a little more casual?"
    new "B:lyd: Isso seria perfeito, vamos fazer."

    # say L383 lyd
    old "I think I do, yeah, there must be a couple of some trips and excursions there in the phone."
    new "B:pla: A primeira coisa é a foto, tens alguma foto em que pareças um pouco mais casual?"

    # say L388 pla
    old "Ok, that's perfect, now for the bio."
    new "T: Ok, isso é perfeito, agora para a bio."

    # say L389 pla
    old "I think we could maybe change it for either something more casual or a little bit more... Uhh, seductive."
    new "B:pla: Ok, isso está perfeito, agora para a bio."

    # say L390 pla
    old "What do you think?"
    new "B: pla: Acho que podíamos talvez mudar para algo mais casual ou um pouco mais... Hum, sedutor."

    # say L392 lyd
    old "Well, if that helps, I think we should give it a try."
    new "B:pla: O que achas?"

    # say L393 pla
    old "Alright, let me think in something."
    new "Bem, se isso ajuda, acho que devemos tentar. Tudo bem, deixa-me pensar em algo. Ok, já está pronto, o que tu achas?"

    # say L398 pla
    old "Ok, it's ready, what do you think?"
    new "B:pla: Tudo bem, deixa-me pensar em algo."

    # say L399 lyd
    old "It looks great! And I think I get what you were saying, this one definitely sounds and looks a lot more attractive."
    new "B:pla: Ok, está pronto, o que achas?"

    # say L402 pla
    old "I'm glad you like it. I'm sure this time we'll attract some younger men."
    new "T: Fico contente que tenhas gostado. Tenho a certeza de que desta vez vamos atrair alguns homens mais novos."

    # say L404 pla
    old "Do you want to try now? I could get on the app and see if you can make a match with some new people."
    new "B:pla: Fico contente que gostes. Tenho a certeza de que desta vez vamos atrair alguns homens mais novos."

    # say L405 lyd
    old "Sure, just one little thing pumpkin. What does that GILF thing mean? Is it some kind of world play?"
    new "T: Claro, só uma coisinha, querida. O que é aquela coisa de GILF? É algum tipo de trocadilho?"

    # say L406 pla
    old "Uhh, t-that... yeah."
    new "É na verdade um acrónimo."

    # say L407 pla
    old "It's actually an acronym."
    new "T(pla|tu|say): Na verdade, é uma sigla."

    # say L409 lyd
    old "It is? What does it stand for?"
    new "B:pla: Na verdade, é um acrónimo."

    # say L410 pla
    old "Hmm, it stands for... Great... I- Intelligent, L- Loving... Friend."
    new "B:lyd: É? O que isso significa?"

    # say L411 pla
    old "It's something that people my age understand, don't worry."
    new "B:pla: Hmm, significa... Grande... I- Inteligente, L- Amoroso... Amigo."

    # say L413 lyd
    old "Ohh, I see! That's great! Thank you."
    new "B:pla: É algo que as pessoas da minha idade entendem, não se preocupe."

    # say L414 lyd
    old "Well, I guess we can start looking for some profiles now."
    new "Olá querida!"

    # say L433 lyd
    old "Hi pumpkin!"
    new "B:lyd: Bem, acho que podemos começar a procurar alguns perfis agora."

    # say L434 lyd
    old "I'm very fine, thank you."
    new "B:lyd: Olá querida!"

    # say L435 pla
    old "Oh yeah? Has anything good happened on tinder?"
    new "B:lyd: Estou muito bem, obrigada."

    # say L436 lyd
    old "Well, you could say that. Ever since we changed my profile the number of young men talking to me has increased. It's been very exciting."
    new "B:pla: Oh yeah? Aconteceu algo de bom no Tinder?"

    # say L437 pla
    old "That's good to hear. So, it worked! it's what you expected, right?"
    new "B:lyd: Podes dizer isso. Desde que alterámos o meu perfil, o número de rapazes a falar comigo aumentou. Tem sido muito empolgante."

    # say L438 lyd
    old "Hmm, it kinda is but..."
    new "B:pla: Que bom ouvir isso. Então, funcionou! É o que esperavas, certo?"

    # say L439 pla
    old "What? Anything wrong with anyone?"
    new "B:lyd: Hmm, é mais ou menos, mas..."

    # say L440 lyd
    old "No, nothing wrong per se with the people I'm speaking to or the app."
    new "T(lyd|tu|say): Não, nada de errado por si com as pessoas com quem estou a falar ou com o app."

    # say L442 pla
    old "Then what is it?"
    new "Então, o que é? É mais por causa da linguagem deles."

    # say L444 lyd
    old "Well, it's more to do with their language."
    new "B:pla: Então, o que é?"

    # say L445 lyd
    old "To be honest I don't understand a lot of what they say. There is this one guy I was talking to."
    new "E ele de repente começou a escrever coisas como, lmao, brb, tbh."

    # say L446 lyd
    old "And he suddenly began writing things like, lmao, brb, tbh."
    new "T(lyd|tu|dizes): E quando lhe perguntei o que queria dizer."

    # say L448 lyd
    old "And when asked him what he meant."
    new "B:lyd: E ele começou a escrever coisas como, lmao, brb, tbh."

    # say L449 lyd
    old "And he answered saying: 'lol, Idk wdym?"
    new "E ele respondeu dizendo: 'lol, não sei o que queres dizer?'"

    # say L450 lyd
    old "What?! What does that even mean?!"
    new "B:lyd: E ele respondeu dizendo: 'lol, Idk wdym?'"

    # say L453 lyd
    old "Yeah, how am I even supposed to talk to these people?"
    new "B:lyd: Que?! O que é que isso quer dizer?!"

    # say L455 lyd
    old "Don't laugh, this isn't funny."
    new "B:lyd: Sim, como é que eu sou suposto falar com estas pessoas?"

    # say L456 pla
    old "Y-you're right, sorry."
    new "B:lyd: Não te rias, isto não é engraçado."

    # say L457 pla
    old "It's just that I wasn't expecting that. But, I get what you mean, I guess young people talk in a confusing way."
    new "T(pla|tu|say): É que não estava à espera disso. Mas percebo o que queres dizer, acho que os jovens falam de uma forma confusa."

    # say L458 pla
    old "Don't worry, they're not saying anything weird, they're just abbreviations, so you don't have to write the whole thing."
    new "Não te preocupes, não estão a dizer nada de esquisito, são só abreviações, por isso não precisas de escrever tudo. Vou ensinar-te a usá-las."

    # say L459 pla
    old "I'll teach you how to use them."
    new "B:pla: Não te preocupes, eles não estão a dizer nada de esquisito, são apenas abreviações, por isso não tens de escrever tudo."

    # say L460 lyd
    old "Well, I thank you, but I don't think that's going to do much for me. Because I've got another problem with the app."
    new "B:pla: Vou-te ensinar a usá-los."

    # say L461 lyd
    old "And is that damned keyboard, it's so small! I have no idea how you can write so fast on those little keyboards; you can't even see them!"
    new "B:lyd: Bem, agradeço, mas não acho que isso vá ajudar muito. Porque tenho outro problema com o aplicativo."

    # say L462 pla
    old "Come on, come on, don't stress too much about it."
    new "B:lyd: E essa tecla maldita, é tão pequena! Não faço ideia como consegues escrever tão depressa nesses teclados minúsculos; nem sequer se conseguem ver!"

    # say L463 pla
    old "Let's just work on it and in no time you'll master them. You'll see."
    new "B:pla: Vamos, vamos, não te preocupes tanto com isso."

    # say L464 lyd
    old "If you say so. I guess I can try to learn..."
    new "B:pla: Vamos trabalhar nisso e em pouco tempo vais dominá-los. Verás."

    # say L470 lyd
    old "What a coincidence, this is the guy I was talking with yesterday night."
    new "B:lyd: Se tu dizes. Acho que posso tentar aprender..."

    # say L471 lyd
    old "I know! Why don't we try speaking to him now? You could write for me!"
    new "B:lyd: Que coincidência, este é o rapaz com quem falei ontem à noite."

    # say L472 pla
    old "Hmm, I don't know, I mean, it's your conversation."
    new "T(pla|tu|say): Hmm, não sei, quer dizer, é a tua conversa."

    # say L473 lyd
    old "Oh please, since you'll actually understand if he uses those abbreviations, and you can use the keyboard."
    new "B:pla: Hmm, não sei, quer dizer, é a tua conversa."

    # say L474 lyd
    old "Why don't you just tell me what he's saying and I'll tell you what to answer?"
    new "B:lyd: Oh, por favor, como tu vais entender se ele usar essas abreviações e podes usar o teclado."

    # say L475 pla
    old "Hahaha, that sounds odd."
    new "Hahaha, isso soa estranho. Mas acho que podemos tentar."

    # say L476 pla
    old "But I guess we can try."
    new "B: pla: Hahaha, isso soa estranho."

    # say L477 pla
    old "So, you see that it's not that difficult."
    new "B:pla: Mas acho que podemos tentar."

    # say L491 lyd
    old "What did he say?"
    new "A:pla: Ele está só a dizer olá e a perguntar como estás hoje."

    # say L492 pla
    old "He's just saying hello, and asking how you are today."
    new "B:lyd: O que ele disse?"

    # say L493 lyd
    old "Well, don't keep him waiting! Say hello back!"
    new "B:pla: Ele está só a dizer olá e a perguntar como estás hoje."

    # say L497 lyd
    old "What did he say now?"
    new "A:pla: Ele disse..."

    # say L498 pla
    old "He said..."
    new "Ele disse..."

    # say L499 lyd
    old "Here, let me see!"
    new "B:pla: Ele disse..."

    # say L500 lyd
    old "Hmm, 'hbu'? What is that supposed to mean?"
    new "T(lyd|tu|say): Hmm, 'hbu'? O que é suposto significar?"

    # say L501 pla
    old "It means 'How about you?'"
    new "T(pla|tu|say): Significa 'E tu?'"

    # say L502 lyd
    old "Jesus, and he couldn't write that? How lazy are young people these days?"
    new "B:pla: Significa 'E tu?'"

    # say L503 pla
    old "It's not about being lazy, just answering fast."
    new "B:lyd: Jesus, e ele não conseguia escrever isso? Que preguiçosos são os jovens hoje em dia."

    # say L504 pla
    old "Which by the way, he's waiting for us to answer him."
    new "B:pla: Não é por ser preguiçoso, é só responder rápido."

    # say L505 lyd
    old "Oh shoot, right!"
    new "B:pla: Aliás, ele está à espera que lhe respondamos."

    # say L506 lyd
    old "Tell him: 'Oh, it's so good that you exercise, that's very good for the joints and muscles."
    new "B:lyd: Oh, droga, certo!"

    # say L507 lyd
    old "Be sure to hydrate and rest properly."
    new "B:lyd: Diz-lhe: 'Oh, é tão bom que tu fazes exercício, isso é muito bom para as articulações e músculos."

    # say L508 pla
    old "Wait, what?!"
    new "B:lyd: Certifica-te de te hidratar e descansar adequadamente."

    # say L509 pla
    old "Hahahahaha."
    new "T(pla|tu|say): Hahahahaha."

    # say L510 lyd
    old "Now what's so funny?"
    new "T(lyd|tu|say): Agora, o que é tão engraçado?"

    # say L511 pla
    old "Hahaha, well, we can't tell him that. You'd sound like a P.E. teacher. You have to be a little more playful."
    new "T(pla|tu|say): Hahaha, bem, não podemos dizer isso a ele. Ias parecer um professor de Educação Física. Tens de ser um pouco mais brincalhão."

    # say L513 lyd
    old "Playful?"
    new "B:pla: Hahaha, bem, não podemos dizer isso a ele. Ias parecer um professor de educação física. Tens de ser um pouco mais brincalhão."

    # say L514 pla
    old "Yeah you know, something about how attractive that is to you and stuff."
    new "B:lyd: Brincalhão? T(pla|tu|say): Sim, sabes, algo sobre como isso é atraente para ti e tal. A:lyd: Entendo, bem..."

    # say L515 lyd
    old "I see, well..."
    new "B:pla: Sabes, há algo nisso que me atrai e tal. T(lyd|tu|say): Entendo, bem... A:lyd: E se fosse assim?"

    # say L516 lyd
    old "How about this?"
    new "A:lyd: Adoro que tu faças exercício, deves estar em ótima forma então."

    # say L517 lyd
    old "I love that you exercise, you must be in great shape then."
    new "B:lyd: Que tal isto?"

    # say L518 pla
    old "Hmm, not really playful, but it could work."
    new "B:lyd: Adoro que tu faças exercício, deves estar em ótima forma então."

    # say L519 pla
    old "Let's see how it goes."
    new "T: Vamos ver como corre."

    # say L523 pla
    old "He said 'Oh yeah, maybe if you're lucky I'll let you take a peek later.'"
    new "T(tu|say): Ele disse 'Oh yeah, talvez se tiveres sorte eu deixe-te dar uma espreitadela mais tarde.' A:lyd: Oh, hahaha, isso é tão fofo. Então diz-lhe que..."

    # say L524 lyd
    old "Oh, hahaha, that's so cute. Then tell him that..."
    new "B:pla: Ele disse 'Oh yeah, talvez se tiveres sorte eu deixe-te dar uma espreitadela mais tarde.'"

    # say L525 pla
    old "Wait, there's more."
    new "B:lyd: Oh, hahaha, isso é tão fofo. Então diz-lhe que..."

    # say L527 pla
    old "Hmm, he says 'Judging from your pictures you must be super hot too.'"
    new "B:pla: Espera, há mais."

    # say L528 lyd
    old "Oh, really? That's so nice!"
    new "B:pla: Hmm, ele diz 'Pelas tuas fotos deves ser super gira também.'"

    # say L529 lyd
    old "Hmm... Tell him 'You're joking, right? I'm just an old woman.'"
    new "B:lyd: Oh, realmente? Isso é tão simpático!"

    # say L530 pla
    old "Really? Hmm alright..."
    new "B:lyd: Hmm... Diz-lhe 'Estás a brincar, certo? Sou só uma velhinha.'"

    # say L534 pla
    old "He says 'Come on! Don't say that, I'm sure you're beautiful.'"
    new "B:pla: Mesmo? Hmm, está bem..."

    # say L535 pla
    old "And then he says 'Also, I wouldn't call you 'old'. On the contrary, I think you're very experienced, and experience is sexy.'"
    new "B:pla: Ele diz 'Vamos! Não digas isso, tenho a certeza de que és bonita.'"

    # say L536 lyd
    old "Hahaha, what a cute guy."
    new "B:pla: E depois ele diz 'Aliás, eu não te chamaria de \"velha\". Pelo contrário, acho que és muito experiente, e experiência é sexy.'"

    # say L537 lyd
    old "Tell him 'Well it seems you know how to compliment a lady.'"
    new "B:lyd: Hahaha, que rapazinho fofo."

    # say L542 pla
    old "He says 'That's not the only thing I know how to do with a lady.'"
    new "B:lyd: Diz-lhe 'Parece que sabes como elogiar uma senhora.'"

    # say L545 pla
    old "And now he adds 'Why don't we go out for dinner and you let me show you?'"
    new "B:pla: Ele diz 'Isso não é a única coisa que sei fazer com uma senhora.'"

    # say L546 lyd
    old "Well isn't he brave? He just invited me to date out of the blue!"
    new "B:pla: E agora ele adiciona 'Porque não saímos para jantar e tu deixas-me mostrar-te?'"

    # say L547 lyd
    old "But I don't think I should accept just like that, I don't want him to think that I'm desperate."
    new "Mas não acho que deva aceitar assim, não quero que ele pense que sou desesperada."

    # say L548 pla
    old "Then what should I tell him?"
    new "B:lyd: Mas não acho que devo aceitar assim, não quero que ele pense que sou desesperada."

    # say L549 lyd
    old "Hmm, let me think..."
    new "Hmm, deixa-me pensar... Já sei."

    # say L550 lyd
    old "I got it."
    new "B:lyd: Hmm, deixa-me pensar..."

    # say L551 lyd
    old "Tell him 'Ohh, I don't know, I think you'll be bored if you go out with an old woman like me.'"
    new "B:lyd: Entendi."

    # say L553 lyd
    old "Why did you write 'idk' what does that mean?"
    new "B:lyd: Diz-lhe 'Ohh, não sei, acho que vais ficar aborrecido se saíres com uma velha como eu.'"

    # say L554 pla
    old "I mean 'I don't know' it's just so that he doesn't think you're super formal."
    new "T(pla|tu|say): Quero dizer 'não sei', é só para ele não achar que és muito formal."

    # say L555 lyd
    old "Ohh, I see."
    new "B:pla: Quero dizer, 'não sei', só para ele não achar que és muito formal."

    # say L557 lyd
    old "Hmm, isn't he something?"
    new "Oh realmente? Tens a certeza de que não estás só a dizer isso para tentar meter-te nas minhas calças?"

    # say L558 lyd
    old "Write 'Oh really? Are you sure you're not just saying that to try and get in my pants?'"
    new "B:lyd: Hmm, não é ele algo?"

    # say L563 pla
    old "He's saying 'Of course not, I honestly think you're super interesting.'"
    new "B:lyd: Escreve 'Oh realmente? Tens a certeza de que não estás só a dizer isso para tentar meter-te nas minhas calças?'"

    # say L564 pla
    old "And also 'But hey, for what it's worth, I do like my women a little older ;)'"
    new "B:pla: Ele está a dizer 'Claro que não, eu honestamente acho que tu és super interessante.'"

    # say L567 lyd
    old "Hahahaha, tell him 'Well, aren't you something?'"
    new "B:pla: E também 'Mas hey, para o que vale, eu gosto das minhas mulheres um pouco mais velhas;)'"

    # say L571 pla
    old "Uhh... Now he's saying 'Baby I'm a little more than just something'"
    new "T(pla|tu|say): Uhh... Agora ele está a dizer 'Baby, eu sou um pouco mais do que apenas algo'"

    # say L572 pla
    old "And he is asking if you want to... Uhh, see."
    new "B:pla: Uhh... Agora ele está a dizer 'Baby, eu sou um pouco mais do que apenas algo'"

    # say L573 lyd
    old "See? See what?"
    new "B:pla: E ele está a perguntar se tu queres... Hum, ver."

    # say L574 pla
    old "Well... you know."
    new "B:lyd: Vês? Vês o quê?"

    # say L575 lyd
    old "Know what? Ask him, 'see what?'"
    new "B:pla: Bem... tu sabes."

    # say L580 pla
    old "He replied 'lol, you bad girl, you know what I mean...'"
    new "B:lyd: Sabes o quê? Pergunta-lhe 'vê o quê?'"

    # say L581 lyd
    old "Lol? What's that?"
    new "B:pla: Ele respondeu 'lol, tu rapariga má, sabes o que quero dizer...'"

    # say L582 pla
    old "It means: 'Laughing out loud'."
    new "T(tu|pla|say): Significa: 'A rir alto'."

    # say L584 lyd
    old "So, something that I said was funny?"
    new "B:pla: Significa: 'A rir à gargalhada'."

    # say L586 lyd
    old "But what? And what's he talking about me knowing what he means?"
    new "B:lyd: Então, alguma coisa que eu disse foi engraçada?"

    # say L589 lyd
    old "Oh wow! I wasn't expecting that!"
    new "B:lyd: Mas o quê? E do que ele está a falar sobre eu saber o que ele quer dizer?"

    # say L590 pla
    old "Hmm, me neither..."
    new "Hmm, eu também não..."

    # say L591 lyd
    old "What do I answer now?"
    new "B:pla: Hmm, eu também não..."

    # say L593 pla
    old "Hmm, I- I guess you can tell him how surprised you are."
    new "Claro, diz-lhe que não estava à espera dessa imagem."

    # say L594 lyd
    old "Sure, tell him that I wasn't expecting that picture."
    new "B:pla: Hmm, eu- eu acho que podes dizer-lhe o quanto estás surpreendido."

    # say L598 pla
    old "He replied: 'Hahaha, well, you know... yolo, right?'"
    new "Yolo?"

    # say L600 lyd
    old "Yolo?"
    new "B:pla: Ele respondeu: 'Hahaha, bem, tu sabes... yolo, certo?'"

    # say L602 pla
    old "You only live once."
    new "B:lyd: Yolo?"

    # say L603 lyd
    old "You young people, honestly..."
    new "B:pla: Só se vive uma vez."

    # say L605 pla
    old "He wants to know what you thought about the picture."
    new "T: Ele quer saber o que tu achaste da foto."

    # say L606 lyd
    old "Really? W- what should I tell him?"
    new "B:pla: Ele quer saber o que tu achaste da imagem."

    # say L608 pla
    old "Just tell him what you think."
    new "B:lyd: Mesmo? E- e o que devo dizer-lhe?"

    # say L609 lyd
    old "Well, let me see it again..."
    new "B:pla: Diz-lhe o que pensas."

    # say L616 lyd
    old "Well, I wasn't expecting him to just send it. That was very unexpected."
    new "B:lyd: Bem, deixa-me ver de novo..."

    # say L617 lyd
    old "But if I'm honest, it's very... impressive. Also, he's rock hard, do you think that's for me?"
    new "B:lyd: Bem, não estava à espera que ele o enviasse assim. Foi muito inesperado."

    # say L619 pla
    old "Do I tell him that?"
    new "B:lyd: Mas se for sincera, é muito... impressionante. Além disso, ele está super duro, achas que é para mim?"

    # say L620 lyd
    old "Well, that's what I think about that pic."
    new "B:pla: Digo-lhe isso?"

    # say L621 pla
    old "Alright, I'll tell him that."
    new "A:pla: Claro que é, para ser honesto, tu és super giro, tão giro que me pões duro só de pensar em estar contigo."

    # say L628 pla
    old "Of course it is, to be honest, you're super hot, so hot that you make me hard just thinking about being with you."
    new "B:pla: Claro, vou dizer-lhe isso."

    # say L630 lyd
    old "That that's very sweet, thank you."
    new "B:pla: Claro que é, para ser sincero, tu és super giro, tão giro que me deixas duro só de pensar em estar contigo."

    # say L633 lyd
    old "And to be honest, seeing your hard dick also turns on a little."
    new "E a ser sincera, ver o teu pénis duro também me excita um pouco. Oh yeah? Diz-me quanto."

    # say L636 pla
    old "Oh yeah? Tell me how much."
    new "B:lyd: E a ser sincera, ver o teu pénis erecto também me excita um pouco."

    # say L637 lyd
    old "Mmm, just seeing your hard dick is making me horny."
    new "B:pla: Oh yeah? Diz-me quanto."

    # say L640 pla
    old "That's it baby and thinking about your wet pussy makes me even harder."
    new "B:lyd: Mmm, só de ver o teu pénis duro estou a ficar excitada."

    # say L648 lyd
    old "Yes, my pussy is dripping just thinking about your cock."
    new "B:pla: É isso, meu amor, e pensar na tua xoxota molhada me deixa ainda mais duro."

    # say L652 pla
    old "Oh baby, I want to fuck you with this big cock."
    new "B:lyd: Sim, a minha xoxota está a pingar só de pensar no teu pénis."

    # say L653 lyd
    old "Oh yes, I want you to come over and put that hard cock in me."
    new "B:pla: Oh baby, quero foder-te com este pénis grande."

    # say L656 pla
    old "Do you really want that baby?"
    new "B:lyd: Oh sim, quero que venhas e me ponhas esse pau duro dentro de mim."

    # say L657 lyd
    old "Oh yes! I want it so bad!"
    new "B:pla: Tu realmente queres esse bebé?"

    # say L662 pla
    old "Tell me, what else do you want me to do to you?"
    new "B:lyd: Oh sim! Eu quero tanto!"

    # say L663 lyd
    old "I want you to come over and pull my hair while you fuck me!"
    new "B:pla: Diz-me, o que mais queres que eu faça contigo?"

    # say L666 pla
    old "Yes! I'll pull your hair while I fuck you from behind!"
    new "B:lyd: Quero que venhas e me puxes o cabelo enquanto me fodes!"

    # say L669 lyd
    old "Yes! Yes! I want you to pull my hair and slap my ass!"
    new "B:pla: Sim! Vou puxar o teu cabelo enquanto te fodo por trás!"

    # say L672 pla
    old "I'll pull your hair and call you my little slut!"
    new "B:lyd: Sim! Sim! Quero que puxes o meu cabelo e bates no meu rabo!"

    # say L673 lyd
    old "Oh yeah! I'm your little slut!"
    new "B:pla: Vou puxar o teu cabelo e chamar-te a minha pequena putinha!"

    # say L681 lyd
    old "Mmmm... Phew..."
    new "B:lyd: Oh yeah! Sou a tua pequena putinha!"

    # say L682 lyd
    old "Wow, that was fun."
    new "B:lyd: Mmmm... Phew..."

    # say L688 pla
    old "He says he has to go now, he is late for his work."
    new "B:lyd: Uau, isso foi divertido."

    # say L689 lyd
    old "Ohh... hmm, sure."
    new "B:pla: Ele diz que tem que ir agora, está atrasado para o trabalho."

    # say L693 pla
    old "He says 'It was awesome, you really are cool. I can't wait to meet you in person.'"
    new "B:lyd: Ohh... hmm, claro."

    # say L695 lyd
    old "Uhh t- thanks... see you later."
    new "B:pla: Ele diz 'Foi incrível, tu és mesmo fixe. Mal posso esperar para te conhecer pessoalmente.'"

    # say L697 pla
    old "Ok, I think it's done, so I'm going home."
    new "B:lyd: Uhh t- obrigado... até mais."

    # say L709 lyd
    old "It's just that it's been so long since any kind of you know... Release."
    new "B:lyd: Desculpa, não sei o que aconteceu."

    # say L710 lyd
    old "I wasn't expecting the conversation to take a turn that way."
    new "B:lyd: É que já passou tanto tempo desde qualquer tipo de... alívio."

    # say L711 lyd
    old "But please believe me that I didn't plan any of this, I just couldn't help it."
    new "T(lyd|tu|say): Mas acredita, por favor, que não planeei nada disto, simplesmente não consegui evitar."

    # say L712 pla
    old "Hey, hey, it's ok. Don't worry."
    new "B:lyd: Mas acredita que eu não planeei nada disto, simplesmente não consegui evitar."

    # say L713 pla
    old "I understand, and I'm not angry."
    new "B:pla: Ei, ei, está tudo bem. Não te preocupes."

    # say L714 pla
    old "I won't lie, I'm a little surprised."
    new "T(pla|tu|say): Não vou mentir, estou um pouco surpreendido."

    # say L715 pla
    old "But, I understand. After all, the whole point of doing this was for you to let loose and meet new people."
    new "B:pla: Não vou mentir, estou um pouco surpreendido."

    # say L717 pla
    old "No biggie, but maybe I should go now."
    new "Não é nada, mas talvez eu deva ir agora."

    # say L718 lyd
    old "Yeah, you're right. Anna might come back any minute."
    new "B:pla: Não é problema, mas talvez eu deva ir agora."

    # say L719 pla
    old "Yeah, however, I'm glad to see that you're making progress with your online app."
    new "B:lyd: Sim, tens razão. A Anna pode voltar a qualquer momento."

    # say L721 lyd
    old "But being honest it's all thanks to your help."
    new "B:pla: Sim, no entanto, fico contente por veres que estás a fazer progressos com a tua app online."

    # say L722 pla
    old "It's nothing, I'm glad I can be of help to you."
    new "B:lyd: Mas sendo sincero, tudo isso se deve à tua ajuda."

    # say L723 pla
    old "Keep chatting and I'll be back soon to keep helping you."
    new "B:pla: Não é nada, fico contente por poder ajudar-te."

    # say L724 lyd
    old "All right, Thank you!"
    new "B:pla: Continua a conversar e eu volto já para continuar a ajudar-te."

    # say L746 pla
    old "Hi, how a..."
    new "Tudo bem, obrigado! Oi, como estás... Tudo bem? Aconteceu algo?"

    # say L748 pla
    old "Is everything alright? Did anything happen?"
    new "B:pla: Olá, como estás..."

    # say L751 lyd
    old "I guess everything's right. I'm just not feeling well right now."
    new "Hmm, bem, não é muito."

    # say L753 lyd
    old "Hmm, well, it's not much."
    new "B:lyd: Acho que tudo está bem. É só que não me estou a sentir bem neste momento."

    # say L754 lyd
    old "It's just that I went out with that guy you were helping me chat with."
    new "B:lyd: Hmm, bem, não foi grande coisa."

    # say L756 lyd
    old "And it didn't go well, it was actually kinda bad."
    new "T(lyd|tu|say): E não correu bem, na verdade foi meio mau."

    # say L759 pla
    old "Did he say anything bad to you?"
    new "T(pla|tu|say): Disse algo de mal para ti?"

    # say L761 lyd
    old "No, no. The problem is that it didn't feel good."
    new "B:pla: Ele disse algo de mal para ti?"

    # say L763 lyd
    old "We only talked about everyday stuff and the conversation didn't go anywhere from there. Is just as if he had lost all interest."
    new "B:lyd: Não, não. O problema é que não senti nada de bom."

    # say L764 lyd
    old "I swear to god he wasn't even looking at me!"
    new "T(lyd|tu|say): Juro por deus que ele nem sequer me olhava!"

    # say L765 lyd
    old "And after saying all that stuff on our chat."
    new "B:lyd: Juro por deus que ele nem sequer me olhou!"

    # say L766 lyd
    old "It's extremely disappointing."
    new "B:lyd: E depois de dizer tudo aquilo no nosso chat."

    # say L767 pla
    old "I see, I'm sorry that happened."
    new "T: Entendo, sinto muito que isso tenha acontecido."

    # say L770 lyd
    old "And I don't think this whole thing of looking for younger men is for me."
    new "E não acho que esta coisa de procurar homens mais novos seja para mim. Pensa bem, nem sequer percebo o que dizem quando escrevem com aquelas palavras estranhas que inventam."

    # say L772 lyd
    old "Think about it, I don't even understand what they're saying when they write with those strange words they make up."
    new "E quando tive um encontro com um rapaz que parecia querer algo comigo."

    # say L773 lyd
    old "And when I got a date with a guy that seemingly wanted to have something with me."
    new "T(lyd|tu|say): E quando tive um encontro com um tipo que parecia querer algo comigo."

    # say L774 lyd
    old "He just lost all interest and began treating me all cordial and distant."
    new "T(lyd|tu|say): Ele perdeu todo o interesse e começou a tratar-me de forma cordial e distante."

    # say L777 lyd
    old "I didn't like that at all. I'm not doing this to be looked at as if I was their grandma."
    new "B:lyd: Ele perdeu todo o interesse e começou a tratar-me de forma cordial e distante."

    # say L778 lyd
    old "So it's better if we just look for older men that are my age, I think I can date then."
    new "B:lyd: Não gostei nada disto. Não estou a fazer isto para ser olhada como se fosse a avó deles."

    # say L780 pla
    old "Well, I get what you mean."
    new "B:lyd: Então é melhor procurarmos homens mais velhos da minha idade, acho que consigo namorar com eles."

    # say L781 pla
    old "But I don't actually think that's what you want Lydia."
    new "B:pla: Bem, percebo o que queres dizer."

    # say L782 pla
    old "Listen, that guy was an idiot. You shouldn't let his attitude bring you down."
    new "Hmm, tu dizes isso mas..."

    # say L783 lyd
    old "Hmm, you say that but..."
    new "B:pla: Ouve, aquele tipo era um idiota. Não deixes que a atitude dele te afecte."

    # say L784 pla
    old "Listen, you went on a date, and it didn't go great because the guy turned out to be an asshole."
    new "B:lyd: Hmm, dizes isso mas..."

    # say L785 pla
    old "I get it sucks, but that stuff happens."
    new "B:pla: Ouve, foste a um encontro e não correu bem porque o tipo acabou por ser um sacana."

    # say L786 pla
    old "Believe me, if it didn't go well it's because of him. You didn't have anything to do with that."
    new "B:pla: Eu percebo que é chato, mas essas coisas acontecem."

    # say L790 pla
    old "Of course! I mean, look at you. You are beautiful, and you're great to hang around. Any guy would be lucky to be with you."
    new "B:pla: Acredita em mim, se não correu bem foi por causa dele. Tu não tiveste nada a ver com isso."

    # say L791 lyd
    old "Hmph, you're sweet, but I know you're only saying that to cheer me up. I know you don't mean it."
    new "B:pla: Claro! Quero dizer, olha para ti. Tu és linda e ótima companhia. Qualquer rapaz teria sorte de estar contigo."

    # say L792 pla
    old "Swear to god that I do."
    new "B:lyd: Hmph, és doce, mas sei que estás a dizer isso só para me animar. Sei que não é a sério."

    # say L793 lyd
    old "Well then you're the only one!"
    new "B:pla: Juro por Deus que faço."

    # say L796 lyd
    old "I'm old, any sex appeal that I had I lost a long time ago."
    new "B:lyd: Além disso, não posso competir com as raparigas com quem os jovens saem. Com os seus corpos perfeitos e tonificados."

    # say L797 pla
    old "W- What?! What are you saying? You can't be serious."
    new "B:lyd: Sou velho, qualquer apelo sexual que tivesse perdi há muito tempo."

    # say L798 lyd
    old "Well, I am!"
    new "B:pla: O-O quê?! O que estás a dizer? Não estás a ser sério."

    # say L799 lyd
    old "It's just true, I'm no longer pretty."
    new "B:lyd: Bem, eu sou!"

    # say L800 pla
    old "What are you talking about, you're so beautiful."
    new "B:lyd: É verdade, já não sou bonita."

    # say L801 pla
    old "You're still a very sexy woman, your face, your body, everything about you is perfect."
    new "B: pla: Do que estás a falar, és tão bonita."

    # say L802 lyd
    old "Yeah right..."
    new "B:pla: Tu ainda és uma mulher muito sexy, o teu rosto, o teu corpo, tudo em ti é perfeito."

    # say L803 pla
    old "I mean it, any man would find you to be incredibly sexy."
    new "T(pla|tu|say): Quero dizer, qualquer homem acharia que tu és incrivelmente sexy."

    # say L808 lyd
    old "Any man?"
    new "T(lyd|tu|say): Todos eles?"

    # say L809 pla
    old "All of them?"
    new "T: Todos eles?"

    # say L811 lyd
    old "... Even you?"
    new "B:pla: Todos eles?"

    # say L814 lyd
    old "Yeah, you, you said any man would think I'm sexy."
    new "B:lyd:... Até tu?"

    # say L815 lyd
    old "How about you? Do you really think I'm sexy?"
    new "T(lyd|tu|say): E tu? Tu realmente achas que sou sexy?"

    # say L817 pla
    old "Uhh, w- well, yeah, I mean..."
    new "T(pla|tu|say): Hum, b- bem, sim, quero dizer..."

    # say L818 lyd
    old "You mean what?"
    new "B:pla: Uhh, w- well, yeah, I mean..."

    # say L819 lyd
    old "I knew it! You also just think I'm old!"
    new "B:lyd: Tu queres dizer o quê?"

    # say L820 pla
    old "No, no, not at all."
    new "Não, não, de todo. É só que não estava à espera de tu me perguntares isso."

    # say L821 pla
    old "It's just that I wasn't expecting you to ask me that."
    new "B:pla: Não, não, de todo."

    # say L822 pla
    old "But I mean, of course, I also think you're sexy."
    new "Mas claro, também acho que tu és sexy."

    # say L824 lyd
    old "Really? And you actually mean it? You're not just saying that to please me?"
    new "B:pla: Mas quero dizer, claro, também acho que tu és sexy."

    # say L826 pla
    old "For real, I mean it 100."
    new "T(pla|tu|say): A sério, estou a falar a verdade 100."

    # say L828 lyd
    old "Well, I don't know if you're lying, but just you saying I'm sexy is not enough."
    new "B:pla: A sério, estou a falar a sério 100."

    # say L829 lyd
    old "But there's one way to know for certain... Your cock."
    new "B:lyd: Bem, não sei se estás a mentir, mas só tu dizeres que sou sexy não chega."

    # say L830 pla
    old "My cock? W- what do you mean?"
    new "B:lyd: Mas há uma maneira de saber com certeza... O teu pénis."

    # say L831 lyd
    old "To know if you're lying, you may say I'm sexy, but if you don't have an erection I won't believe you."
    new "B:pla: O meu pénis? Q- quer dizer?"

    # say L832 lyd
    old "It's the same with all men, the penis never lies."
    new "B:lyd: Para saber se estás a mentir, podes dizer que és sexy, mas se não tiveres uma ereção, não te vou acreditar."

    # say L833 lyd
    old "So..."
    new "B:lyd: É a mesma coisa com todos os homens, o pénis nunca mente."

    # say L837 pla
    old "W- whoa! What are you doing?"
    new "B:lyd: Então..."

    # say L841 lyd
    old "Well, I wanted to know what you think about my breasts."
    new "B:pla: W- whoa! Quem diria! O que estás a fazer?"

    # say L842 lyd
    old "How about now? Do you still think I'm sexy?"
    new "B:lyd: Bem, queria saber o que tu achas dos meus seios."

    # say L843 pla
    old "Y- yeah, of course."
    new "B:lyd: E agora? Ainda achas que sou sexy?"

    # say L844 lyd
    old "So, look at them, and let's see if your cock thinks the same."
    new "B:pla: Y- yeah, of course."

    # say L845 pla
    old "I don't think that's a good idea. After all..."
    new "B:lyd: Então, olha para elas e vê se o teu pénis pensa o mesmo."

    # say L846 lyd
    old "Stop putting up excuses and see my tit!"
    new "B:pla: Não acho que seja uma boa ideia. Afinal..."

    # say L847 lyd
    old "Or I'll know you're lying to me."
    new "B:lyd: Pára de inventar desculpas e vê o meu peito!"

    # say L854 lyd
    old "Oh wow, this is impressive."
    new "B:lyd:!!!!"

    # say L855 lyd
    old "Ok, I believe you, if you're this hard you must be telling the truth."
    new "B:lyd: Oh wow, isto é impressionante."

    # say L856 pla
    old "Yeah, well, I do believe you're very beautiful."
    new "B:lyd: Ok, acredito em ti, se estás assim tão duro deves estar a dizer a verdade."

    # say L857 lyd
    old "Well, I have no doubt about that now."
    new "B:pla: Yeah, well, eu acredito que tu és muito bonita."

    # say L858 lyd
    old "I must say [pla] your cock is something else."
    new "T(lyd|tu|say): Tenho de dizer [pla] que o teu pénis é qualquer coisa. É tão... grande."

    # say L860 lyd
    old "I- I can believe that it is because of me."
    new "B:lyd: É tão... grande."

    # say L862 lyd
    old "It's really flattering that such a young man like you can feel that way about a woman my age."
    new "T(lyd|tu|say): É realmente lisonjeiro que um jovem como tu possa sentir isso por uma mulher da minha idade."

    # say L868 lyd
    old "I- I just want to see it closer..."
    new "B:lyd: É muito lisonjeiro que um jovem como tu possa sentir isso por uma mulher da minha idade."

    # say L869 lyd
    old "It's been a long time since I've seen one so close."
    new "B:lyd: I- Eu só quero ver mais de perto..."

    # say L873 lyd
    old "And, it wasn't that big... Not at all..."
    new "B:lyd: Já fazia muito tempo que não via um tão de perto."

    # say L874 lyd
    old "Knowing this is caused by me really makes me tingle."
    new "B:lyd: E, não era assim tão grande... Nem por isso..."

    # say L875 lyd
    old "I'm sorry to ask but, may I see it... I mean, out of your pants?"
    new "B:lyd: Saber que isto é causado por mim deixa-me com arrepios."

    # say L876 lyd
    old "To be honest, is the first time I have seen one that big, and really makes me curious..."
    new "B:lyd: Peço desculpa por perguntar, mas... posso ver? Quero dizer, fora das calças?"

    # say L877 pla
    old "... Hmm o- ok."
    new "B:lyd: Para ser honesta, é a primeira vez que vejo um assim tão grande, e realmente me deixa curiosa..."

    # say L881 lyd
    old "Oh wow! It's even bigger than I thought it was..."
    new "B:pla:... Hmm o- ok."

    # say L882 lyd
    old "I have never thought you were this... gifted."
    new "B:lyd: Oh wow! É mesmo maior do que eu pensava..."

    # say L884 lyd
    old "And it's so hard... really seen just this old boob make you so hard?"
    new "B:lyd: Nunca pensei que fosses... assim tão... dotado."

    # say L885 pla
    old "It was something instinctive, you know a natural reaction..."
    new "B:lyd: E é tão difícil... realmente ver só esse peito velho te deixa assim tão excitado?"

    # say L886 lyd
    old "That is the most honest answer a woman can get from a man..."
    new "B:pla: Foi algo instintivo, sabes, uma reação natural..."

    # say L889 lyd
    old "Yeah, now I can see it..."
    new "B:pla: Tu tens de saber que és realmente bonita e sexy, qualquer homem pode ver isso, realmente."

    # say L891 lyd
    old "Uhh... C- can I touch it?"
    new "B:lyd: Sim, agora consigo ver..."

    # say L893 lyd
    old "I mean, I just want to see how hard you are, if you're really excited or if it's just barely."
    new "E tu não consegues perceber só de olhar?"

    # say L894 pla
    old "And you can't tell just from seeing it?"
    new "T(pla|tu|say): E não consegues perceber só de olhar?"

    # say L895 lyd
    old "You can't always know that from just looking."
    new "T: Não podes sempre saber isso só de olhar."

    # say L896 lyd
    old "It's always better to check with my own hands."
    new "T: É sempre melhor verificar com as minhas próprias mãos."

    # say L904 lyd
    old "Woah, you're really hard!"
    new "B:lyd: É sempre melhor verificar com as minhas próprias mãos."

    # say L905 lyd
    old "And you're so big! This is impressive!"
    new "B:lyd: Uau, estás mesmo duro!"

    # say L917 lyd
    old "And seeing how hard you got because of me."
    new "E ver como tu ficaste tão excitado por minha causa. Mas, juro por Deus que não foi minha intenção..."

    # say L918 lyd
    old "But, I swear to God I didn't mean to..."
    new "B:lyd: E vendo como ficaste duro por minha causa."

    # say L919 pla
    old "Hey, hey, it's ok."
    new "B:lyd: Mas, juro por Deus que não foi minha intenção..."

    # say L920 pla
    old "No need for you to stress over this."
    new "B:pla: Ei, ei, está tudo bem."

    # say L921 pla
    old "I'm not angry with you. I understand."
    new "T: Não estou zangado contigo. Entendo."

    # say L923 pla
    old "Yeah, I do, it's ok."
    new "B:pla: Não estou zangado contigo. Entendo."

    # say L925 lyd
    old "Hmm, but maybe we should clean this up before we keep talking."
    new "B:pla: Sim, faço isso, está bem."

    # say L933 lyd
    old "Thanks for helping me feel better."
    new "B:lyd: A verdade é que o que aconteceu com aquele tipo realmente me afetou. Estava a sentir-me muito mal."

    # say L934 pla
    old "No problem, I understand, that kind of thing can make you feel really bad."
    new "Não há problema, entendo, esse tipo de coisa pode deixar-te realmente mal. Estou contente que estejas bem agora."

    # say L935 pla
    old "I'm glad you're ok now."
    new "B:pla: Sem problemas, eu entendo, esse tipo de coisa pode deixar-te realmente mal."

    # say L936 pla
    old "Now that I see you feel better, I think I should go home."
    new "B:pla: Fico contente que estejas bem agora."

    # say L937 lyd
    old "Sure, no problem. Bye."
    new "A:pla: Olá Lydia. Como estás hoje?"

    # say L955 pla
    old "Hey Lydia. How are you today?"
    new "T(pla|tu|say): Oi Lydia. Como estás hoje?"

    # say L956 lyd
    old "Hi [pla]! Nice seeing you. You arrive just at the perfect time."
    new "T(lyd|tu|say): Olá [pla]! É bom ver-te. Chegas na altura perfeita."

    # say L957 pla
    old "The perfect time? For what?"
    new "A:lyd: Tu vês, tenho estado a falar com um novo rapaz no Tinder, e as conversas têm corrido bastante bem."

    # say L958 lyd
    old "You see, I've been talking to this new guy on Tinder, and the conversations have been going pretty well."
    new "Tu vês, tenho estado a falar com este novo gajo no Tinder e as conversas têm corrido bastante bem."

    # say L960 lyd
    old "Yeah, it is."
    new "B:lyd: Vês, tenho estado a falar com um novo gajo no Tinder, e as conversas têm corrido bastante bem."

    # say L961 lyd
    old "The thing is that he has been asking to see some pictures of me for a while..."
    new "B:lyd: Sim, é."

    # say L962 lyd
    old "And he has sent me a lot of pics, and the conversation is going really well, so, I want to send them to him a few ones."
    new "B:lyd: A questão é que ele tem estado a pedir para ver algumas fotos minhas há algum tempo..."

    # say L963 lyd
    old "But, to be honest, I don't really know what to send him."
    new "B:lyd: E ele enviou-me muitas fotos e a conversa está a correr muito bem, por isso, quero enviar-lhe algumas."

    # say L964 lyd
    old "So, I think you could take some pictures of me so I can send him some good ones."
    new "B:lyd: Mas, a ser sincera, não sei bem o que lhe enviar."

    # say L966 lyd
    old "So, what do you say? Do you think you can do it?"
    new "B:lyd: Então, acho que tu podes tirar algumas fotos minhas para eu lhe enviar algumas boas."

    # say L967 pla
    old "Hmm, sure, I guess I can."
    new "Hmm, claro, acho que consigo."

    # say L975 lyd
    old "Ok, I think something casual, like this, what do you think?"
    new "B:pla: Hmm, claro, acho que posso."

    # say L976 pla
    old "It looks great!"
    new "T(pla|tu|say): Fica ótimo!"

    # say L987 lyd
    old "But it's ok, take it, if you like it I think he will too."
    new "B:pla: Fica ótimo!"

    # say L997 lyd
    old "Is it ok? Do you like it?"
    new "B:lyd: Mas está bem, leva, se tu gostas acho que ele também vai gostar."

    # say L998 pla
    old "Yeah, I think it looks very good."
    new "B:lyd: Está bem? Gostas?"

    # say L999 lyd
    old "Great! So, next one."
    new "Ótimo! Então, o próximo."

    # say L1006 lyd
    old "Ok, for this one I want to try something a little hotter."
    new "B:lyd: Ótimo! Então, o próximo."

    # say L1007 lyd
    old "Does my ass look good enough?"
    new "B:lyd: Ok, para este quero tentar algo um pouco mais quente."

    # say L1008 pla
    old "Sure, I think it looks great."
    new "T: Claro, acho que tu tens um ótimo rabo. Não me parece que estejas gorda. Gosto muito desse."

    # say L1026 lyd
    old "Do I look fat? What do you think? Do you like that one?"
    new "B:pla: Claro, acho que fica-te muito bem."

    # say L1027 pla
    old "Don't worry, I think you look just perfect."
    new "B:lyd: Estou gorda? O que tu achas? Gostas deste?"

    # say L1028 lyd
    old "Great, I've got an idea for the next one."
    new "B:pla: Não te preocupes, acho que tu estás perfeita."

    # say L1036 lyd
    old "Ha! I knew it, you men and breasts, I don't know why you're so crazy about them."
    new "T(lyd|tu|say): Ha! Eu sabia, vocês homens e seios, não sei por que ficam tão loucos por eles."

    # say L1039 lyd
    old "The truth is, he's already sent me a couple of pictures of himself."
    new "B:lyd: Ha! Eu sabia, vocês homens e seios, não sei por que vocês ficam tão loucos por eles."

    # say L1040 lyd
    old "And some of those are actually very spicy."
    new "B:lyd: A verdade é que ele já me enviou algumas fotos dele."

    # say L1041 lyd
    old "So, I thought that maybe I could send him some like that too."
    new "B:lyd: E alguns deles são realmente picantes."

    # say L1043 pla
    old "I- I think it's great."
    new "B:lyd: Então, pensei que talvez pudesse enviar-lhe algumas assim também."

    # say L1044 lyd
    old "Yeah, I can see that. Fufu."
    new "B:pla: I- Acho ótimo."

    # say L1046 lyd
    old "Anyway, take the picture."
    new "Então, como é que a foto ficou?"

    # say L1052 lyd
    old "So how does the picture look?"
    new "B:lyd: De qualquer forma, tira a foto."

    # say L1053 pla
    old "Very well I think."
    new "T(pla|tu|say): Muito bem, acho eu."

    # say L1054 lyd
    old "And my breasts? They don't look soggy or wrinkled?"
    new "B:pla: Muito bem, acho eu."

    # say L1055 pla
    old "No, no, they look great as well."
    new "B:lyd: E os meus seios? Não parecem enrugados ou amolecidos?"

    # say L1056 lyd
    old "That's great, I'm glad that's how it is."
    new "B:pla: Não, não, eles também ficam ótimos."

    # say L1063 lyd
    old "That was very good [pla], thank you."
    new "T(lyd|tu|say): Isso foi muito bom [pla], obrigado."

    # say L1064 pla
    old "It's ok, happy to help."
    new "T: Tudo bem, feliz por ajudar."

    # say L1065 lyd
    old "I hope he likes the pictures."
    new "T(lyd|tu|say): Espero que ele goste das fotos."

    # say L1066 pla
    old "I'm sure he will, you look great, don't worry."
    new "T: Tenho a certeza que vai gostar, tu estás ótima, não te preocupes."

    # say L1067 lyd
    old "Well thank you, that's very sweet of you."
    new "B:pla: Tenho a certeza que sim, tu estás ótima, não te preocupes."

    # say L1068 lyd
    old "I believe you this time."
    new "T(lyd|tu|dizer): Afinal, eu consigo ver desta vez."

    # say L1069 lyd
    old "After all, I can see it this time."
    new "T(lyd|tu|say): Afinal, eu consigo ver desta vez."

    # say L1071 pla
    old "Sorry, it's just that you took your shirt off all of a sudden."
    new "T(pla|tu|say): Desculpa, é que tiraste a camisa de repente."

    # say L1073 lyd
    old "It's ok, don't worry, I actually like to see that reaction."
    new "T: Não te preocupes, gosto mesmo de ver essa reação. Acho muito lisonjeiro."

    # say L1074 lyd
    old "I think it's very flattering."
    new "B:lyd: Não te preocupes, gosto mesmo de ver essa reação."

    # say L1075 lyd
    old "To see such a young man get so hard because of me, I can never get tired of it."
    new "B:lyd: Acho muito lisonjeiro."

    # say L1076 lyd
    old "In fact, how about I help you with that? I know it can take a while for your dick to calm down."
    new "B:lyd: Ver um jovem ficar tão duro por minha causa, nunca me canso disso."

    # say L1077 pla
    old "You don't really have to do it."
    new "B:lyd: Na verdade, porque não te ajudo com isso? Sei que pode demorar um bocado para o teu pénis acalmar."

    # say L1078 lyd
    old "Well, you helped me with the pictures, it's fine if I help you back. Don't you think?"
    new "B:pla: Não tens mesmo de o fazer."

    # say L1079 lyd
    old "And to be honest, doing these photos made me a bit horny..."
    new "B:lyd: Bem, tu ajudaste-me com as fotos, não é justo que eu te ajude de volta? Não achas?"

    # say L1081 lyd
    old "Now come, let me help you."
    new "B:lyd: E a ser sincera, tirar estas fotos deixou-me um bocado excitada..."

    # say L1088 lyd
    old "I didn't notice last time, but your dick has a great smell."
    new "B:lyd: Agora vem, deixa-me ajudar-te."

    # say L1089 lyd
    old "And I can't believe how hard you get."
    new "B:lyd: Não tinha reparado da última vez, mas o teu pénis tem um cheiro incrível."

    # say L1090 lyd
    old "Young men are amazing."
    new "B:lyd: E não consigo acreditar no quanto tu ficas duro."

    # say L1091 lyd
    old "It's sooo big too."
    new "B:lyd: Os jovens são incríveis."

    # say L1092 lyd
    old "Honestly I'm not sure it will fill all in my mouth."
    new "B:lyd: É tão grande também."

    # say L1093 lyd
    old "But don't worry, I'll make sure you finish in a moment."
    new "B:lyd: Honestamente, não tenho a certeza se caberá tudo na minha boca."

    # say L1104 pla
    old "Well, I think I should go home."
    new "B:lyd: Mas não te preocupes, vou garantir que acabas num momento."

    # say L1105 lyd
    old "Sure thing, thanks again for the pictures. I'll let you know if he likes them."
    new "B:pla: Bem, acho que devo ir para casa."

    # say L1126 ann
    old "I mean, what the fuck mom?! What the actual fuck?!"
    new "Agora tu chegas a casa tarde? JESUS!"

    # say L1127 ann
    old "Now you're coming home late? JESUS!"
    new "A:ann: Depois de todas as vezes que me repreendeste por fazer o mesmo quando era adolescente. E não só isso, mas tenho a certeza de que estavas num encontro com alguém."

    # say L1128 ann
    old "After all those times you scolded me for doing it when I was a teenager. And not only that, but I'm sure you were on a date with someone."
    new "B:ann: Agora tu chegas a casa tarde? JESUS!"

    # say L1129 ann
    old "I imagine it was some guy you must've met there. What's wrong with you?"
    new "A:ann: Não te apercebes que já és demasiado velha para saíres com rapazes desses?"

    # say L1130 ann
    old "Don't you realize you're too old to be going out with guys like those?"
    new "T(ann|tu|diz): Não te apercebes que já és demasiado velha para saíres com rapazes daqueles?"

    # say L1131 ann
    old "Honestly..."
    new "A:lyd: Porque estás tão zangada?"

    # say L1132 lyd
    old "Why are you so angry?"
    new "A:lyd: Entendo que esqueci de te dizer que saí ontem à noite, mas isso não é motivo para agires assim."

    # say L1133 lyd
    old "I get that I forgot to tell you I was going out last night, but that's no reason to be acting like this."
    new "T(lyd|tu|dizes): Entendo que esqueci de te dizer que saí ontem à noite, mas isso não é motivo para agires assim."

    # say L1134 lyd
    old "Listen, your mother is a mature woman, and I have every right to go out and date anyone I want to."
    new "B:lyd: Entendo que esqueci de te dizer que saí ontem à noite, mas isso não é motivo para agires assim."

    # say L1136 ann
    old "I DON'T GIVE A FUCK!"
    new "T(ann|tu|say): NÃO ME IMPORTO NEM UM POUCO!"

    # say L1137 ann
    old "I just don't want to go around picking up random dudes that you find on the street!"
    new "B:ann: NÃO ME IMPORTO NEM UM POUCO!"

    # say L1138 ann
    old "I mean, what's everyone going to think? That you're just some whore looking for dick!"
    new "B:ann: Não quero andar a apanhar tipos aleatórios que encontres na rua!"

    # say L1139 ann
    old "They would be right by the way! Because that's what you're acting like!!!"
    new "B:ann: Quero dizer, o que é que toda a gente vai pensar? Que tu és uma puta à procura de pénis!"

    # say L1142 ann
    old "Ugh! I'm so mad mom! I swear to god!"
    new "B:ann: Estariam certos, afinal! É assim que estás a agir!"

    # say L1143 ann
    old "You know what? I won't keep talking about this!"
    new "B:ann: Ugh! Estou tão zangada com a mãe! Juro por deus!"

    # say L1160 lyd
    old "Well, remember the guy that we took the pictures for?"
    new "B:pla: Não te preocupes comigo, e tu? O que é que a Anna tinha desta vez?"

    # say L1163 lyd
    old "Well, we went out on a date, and we ended up staying out until very late, and Anna noticed it."
    new "B:lyd: Então, lembras-te do rapaz para quem tirámos as fotografias?"

    # say L1164 lyd
    old "As you can see, she's not too thrilled about it."
    new "B:lyd: Bem, saímos para um encontro e acabamos por ficar fora até muito tarde, e a Anna reparou."

    # say L1165 pla
    old "Yeah, I caught that she's not too happy about the situation."
    new "B:lyd: Como podes ver, ela não está nada contente com isso."

    # say L1166 pla
    old "But so what? You're a grown woman, and she can't be telling you what to do or not."
    new "Mas e daí? Tu és uma mulher adulta, e ela não pode estar a dizer-te o que fazer ou não."

    # say L1167 lyd
    old "I don't know, lately I've been thinking that she may be right and that I'm actually acting like a whore."
    new "B:pla: Mas e daí? Tu és uma mulher adulta, e ela não pode estar a dizer-te o que fazer ou não."

    # say L1168 pla
    old "Whoah, whoah, whoah."
    new "B:lyd: Não sei, ultimamente tenho pensado que ela pode estar certa e que estou a agir como uma puta."

    # say L1169 pla
    old "No, no, let's not go there."
    new "B:pla: Quem, quem, quem."

    # say L1170 pla
    old "Listen, Anna's just angry, and since she's such a hothead she doesn't know how to deal with it."
    new "B:pla: Não, não, vamos deixar isso para lá."

    # say L1171 pla
    old "All she knows is how to get angry, scream and be cruel. Don't pay any attention to what she says, ok?"
    new "B:pla: Ouve, a Anna está só zangada, e como é tão impulsiva não sabe como lidar com isso."

    # say L1173 lyd
    old "Ok, I guess you have a point."
    new "B:pla: Tudo o que ela sabe é como ficar zangada, gritar e ser cruel. Não ligues ao que ela diz, ok?"

    # say L1175 pla
    old "Now, tell me how your night went."
    new "T: Agora, conta-me como correu a tua noite."

    # say L1176 pla
    old "It sounds like it was a very good time."
    new "B:pla: Agora, conta-me como foi a tua noite."

    # say L1177 lyd
    old "Hmm, yeah, I guess so..."
    new "B:pla: Parece que foi uma boa noite."

    # say L1178 pla
    old "Yeah? Because you don't look very excited about it."
    new "B:lyd: Hmm, yeah, acho que sim..."

    # say L1179 lyd
    old "Well... you see."
    new "B:pla: Sim? Porque não pareces muito entusiasmada com isso."

    # say L1180 lyd
    old "The date went well, he was a perfect gentleman, and I think we had a lot of chemistry. He actually said he wanted to see me again soon."
    new "B:lyd: Bem... tu vês."

    # say L1181 lyd
    old "But that got me thinking, with the way things are going, that we could end up having sex next time."
    new "B:lyd: A saída correu bem, ele foi um verdadeiro cavalheiro, e acho que tivemos muita química. Ele disse mesmo que queria ver-me outra vez em breve."

    # say L1182 pla
    old "Well, yeah, that's usually how those things go."
    new "B:lyd: Mas isso me fez pensar, com o rumo que as coisas estão tomando, que poderíamos acabar fazendo sexo da próxima vez."

    # say L1183 pla
    old "You don't want to?"
    new "B:pla: Bem, sim, é assim que essas coisas costumam ser."

    # say L1184 lyd
    old "It's not that, I obviously want to."
    new "T: Não é isso, eu obviamente quero. O problema é que já faz um tempo desde a última vez que tive sexo."

    # say L1185 lyd
    old "The problem is that it's been a while since I had sex for the last time."
    new "B:lyd: Não é isso, eu obviamente quero."

    # say L1186 lyd
    old "Even with my deceased husband, the last few years of our relationship we barely had any contact."
    new "B:lyd: O problema é que já passou algum tempo desde a última vez que tive sexo."

    # say L1187 lyd
    old "I'm afraid that I'm not gonna be good enough or that I'll end up disappointing him."
    new "B:lyd: Mesmo com o meu marido falecido, nos últimos anos da nossa relação mal tínhamos contacto."

    # say L1188 lyd
    old "After all this time it's a lot of pressure you know?"
    new "A:lyd: Especialmente porque não tenho a certeza se ele vai gostar do meu corpo."

    # say L1189 lyd
    old "Especially since I'm not sure he'll like my body."
    new "T(lyd|tu|say): Especialmente porque não tenho a certeza se ele vai gostar do meu corpo."

    # say L1190 lyd
    old "What if he thinks that I'm too old? or that I'm not hot enough?"
    new "B:lyd: Especialmente porque não tenho a certeza de que ele goste do meu corpo."

    # say L1191 pla
    old "What? Not at all!"
    new "B:lyd: E se ele achar que sou velha demais? ou que não sou suficientemente atraente?"

    # say L1192 pla
    old "Don't even think about it. That guy has already seen pictures of you, and if he says that you're hot, you should believe him."
    new "B:pla: O quê? Nem pensar!"

    # say L1193 pla
    old "Everything is gonna be fine, believe me."
    new "B:pla: Nem penses nisso. Esse tipo já viu fotos tuas, e se ele diz que tu és gira, deves acreditar nele."

    # say L1194 lyd
    old "Ok, I'll stop worrying about it. Thanks again [pla], I don't know what I would do without all your help."
    new "T(lyd|tu|say): Ok, vou parar de me preocupar com isso. Obrigada mais uma vez [pla], não sei o que faria sem toda a tua ajuda."

    # say L1196 pla
    old "Don't even mention it."
    new "Não menciones isso."

    # say L1197 pla
    old "Hmmm."
    new "B:pla: Nem sequer menciones isso."

    # say L1198 pla
    old "So, since I'm already here, do you want us to browse through some tinder profiles?"
    new "B:pla: Hmmm."

    # say L1200 lyd
    old "I don't really feel like doing that right now, besides, since Anna is in her room she could come down any second."
    new "B:pla: Então, já que estou aqui, tu queres que a gente veja alguns perfis do Tinder?"

    # say L1201 lyd
    old "I don't want to have to deal with her temper again today."
    new "B:lyd: Não me apetece muito fazer isso agora, além disso, como a Anna está no quarto dela, ela pode descer a qualquer momento."

    # say L1202 pla
    old "I understand, then I guess it's better if I leave."
    new "B:lyd: Não quero ter de lidar com o temperamento dela de novo hoje."

    # say L1203 pla
    old "But before I go, remember what I told you."
    new "B:pla: Entendo, então acho melhor ir embora."

    # say L1204 pla
    old "You're a beautiful woman, and you're in your right to be or date anyone."
    new "B:pla: Mas antes de eu ir, lembra-te do que te disse."

    # say L1205 pla
    old "No matter what Anna thinks about that. She can keep her opinions to herself."
    new "B:pla: Tu és uma mulher bonita e tens todo o direito de estar com quem quiseres."

    # say L1226 lyd
    old "Hi [pla], I guess I'm fine, thank you."
    new "T(lyd|tu|say): Olá [pla], acho que estou bem, obrigado."

    # say L1228 lyd
    old "Oh [pla], it's just so bad..."
    new "T(lyd|tu|say): Oh [pla], é só tão mau..."

    # say L1231 lyd
    old "Well, the thing is that I did go on that date with the guy I told you about."
    new "B:pla: O que é que está mal? Estás a preocupar-me, conta-me."

    # say L1232 lyd
    old "I suppose it went well, just like last time he was a gentleman, the conversation was good and we had a good time."
    new "B:lyd: Bem, a verdade é que fui mesmo ao encontro com o rapaz do qual te falei."

    # say L1233 lyd
    old "The problem came later... when we were about to have sex."
    new "B:lyd: Suponho que correu bem, como da última vez ele foi um cavalheiro, a conversa foi boa e divertimo-nos."

    # say L1234 pla
    old "Ohh... Why?"
    new "B:lyd: O problema surgiu depois... quando íamos ter relações."

    # say L1235 lyd
    old "Well, after dinner he asked me if I wanted to continue the evening at his house, I said yes and we went there."
    new "B:pla: Ohh... Porquê?"

    # say L1236 lyd
    old "I really wanted to do it, and things were going so well..."
    new "B:lyd: Bem, depois do jantar ele perguntou se eu queria continuar a noite na casa dele, eu disse que sim e fomos lá."

    # say L1237 lyd
    old "But, I just couldn't do it... I got nervous and uncomfortable."
    new "Mas, simplesmente não consegui... Fiquei nervosa e desconfortável."

    # say L1239 pla
    old "Was it something he did?"
    new "T(pla|tu|say): Foi algo que ele fez?"

    # say L1241 lyd
    old "Oh no, nothing like that, he was actually very nice, as I said, a perfect gentleman."
    new "B:pla: Foi algo que ele fez?"

    # say L1242 lyd
    old "I was the one with the problem, no matter what we tried all I could think was about my husband, and Anna's words."
    new "B:lyd: Oh não, nada disso, ele foi na verdade muito simpático, como eu disse, um cavalheiro perfeito."

    # say L1243 lyd
    old "Telling me that I was ugly and undesirable, that what I was doing was wrong."
    new "B:lyd: Fui eu quem teve o problema, não importa o que tentássemos, só conseguia pensar no meu marido e nas palavras da Anna."

    # say L1244 lyd
    old "After a while, I just backed out and asked him to drive me home."
    new "B:lyd: Dizer-me que era feia e indesejável, que o que estava a fazer estava errado."

    # say L1245 lyd
    old "After all I think Mrs. Jones was right, at my age it's just impossible for me to form a connection with another person."
    new "B:lyd: Depois de um tempo, apenas desisti e pedi que me levasse para casa."

    # say L1246 lyd
    old "I think I should just give up and become a church lady like her."
    new "B:lyd: Afinal, acho que a senhora Jones tinha razão, à minha idade é impossível para mim criar uma ligação com outra pessoa."

    # say L1247 pla
    old "Wait, wait, don't say that."
    new "B:lyd: Acho que devo desistir e me tornar uma senhora da igreja como ela."

    # say L1248 pla
    old "Listen, what you went through is perfectly normal, you don't need to beat yourself over it."
    new "B: Espera, espera, não digas isso."

    # say L1249 pla
    old "Sure it would be good if you could have sex with the guy."
    new "B:pla: Ouve, o que passaste é perfeitamente normal, não precisas de te castigar por isso."

    # say L1250 pla
    old "But think about it, you were out of the dating game for a long time, it's ok to feel insecure."
    new "B:pla: Seria bom se tu pudesses ter sexo com o rapaz."

    # say L1251 pla
    old "There's no need for you to feel that you're going to become someone like Mrs. Jones."
    new "B:pla: Mas pensa nisso, tu estiveste fora do jogo amoroso durante muito tempo, é normal sentires-te inseguro."

    # say L1252 lyd
    old "That's very cute of you, but [pla] I don't know, it's just too difficult."
    new "T(lyd|tu|say): É muito fofo da tua parte, mas [pla] não sei, é só demasiado difícil."

    # say L1254 pla
    old "It is, but that doesn't mean you should give up, or pay any attention to what Anna says."
    new "T: É, mas isso não significa que deves desistir ou dar ouvidos ao que a Anna diz."

    # say L1255 pla
    old "Listen, you're doing this for yourself, not for Anna, or your husband or anyone else, just for you."
    new "B:pla: É, mas isso não significa que deves desistir ou dar qualquer atenção ao que a Anna diz."

    # say L1256 pla
    old "You have every right to be happy and to search for that happiness."
    new "B:pla: Ouve, estás a fazer isto por ti, não pela Anna, nem pelo teu marido ou por ninguém mais, mas sim por ti."

    # say L1257 pla
    old "So, there's no need for you to feel guilty about living your life."
    new "B:pla: Tu tens todo o direito de ser feliz e procurar essa felicidade."

    # say L1258 lyd
    old "I understand what you're saying, but I don't know how to do it."
    new "T(lyd|tu|say): Entendo o que estás a dizer, mas não sei como fazer."

    # say L1259 lyd
    old "How do I manage to do it when I feel so uncomfortable?"
    new "B:lyd: Entendo o que estás a dizer, mas não sei como fazer."

    # say L1260 lyd
    old "I wasn't able to even get naked!"
    new "B:lyd: Como é que eu consigo fazer quando me sinto tão desconfortável?"

    # say L1261 lyd
    old "I can't imagine even trying to be even more intimate in a physical way."
    new "B:lyd: Nem consegui tirar a roupa!"

    # say L1263 pla
    old "Hmm... It's just you haven't done it in a long time, you're a bit... Rusty..."
    new "B:lyd: Não consigo imaginar sequer tentar ser mais íntimo de uma forma física."

    # say L1264 lyd
    old "But how do I fix it? How can I ever be able to have some sexual contact again?"
    new "B:pla: Hmm... É só que tu não fazias isto há muito tempo, estás um bocado... Ferrugento..."

    # say L1266 pla
    old "Wait... What about me?"
    new "B:lyd: Mas como é que eu resolvo isso? Como é que vou conseguir ter algum contacto sexual de novo?"

    # say L1269 pla
    old "Well, you say that, but you've been able to do a few sexual things with... me."
    new "B:pla: Espera... E eu?"

    # say L1270 lyd
    old "Oh... Yeah well, that's different."
    new "B:pla: Bem, tu dizes isso, mas conseguiste fazer algumas coisas sexuais com... mim."

    # say L1273 lyd
    old "I don't know... with you it doesn't feel like I'm doing some weird thing with a stranger, you just feel... safer."
    new "B:lyd: Oh... Pois bem, isso é diferente."

    # say L1274 lyd
    old "With this other guy I felt very awkward like we didn't have a bond, or anything connecting us."
    new "B:lyd: Não sei... contigo não sinto que estou a fazer algo estranho com um desconhecido, tu dás-me... mais segurança."

    # say L1275 pla
    old "Hmph, I think I get what you're saying."
    new "B:lyd: Com aquele outro rapaz senti-me muito desconfortável, como se não tivéssemos uma ligação, ou algo que nos unisse."

    # say L1277 lyd
    old "Oh, I have an idea."
    new "B:pla: Hmph, acho que percebi o que queres dizer."

    # say L1280 lyd
    old "I think that my problem might be taking that first step to physical intimacy. That's what's holding me back."
    new "B:lyd: Oh, tenho uma ideia."

    # say L1281 lyd
    old "It's just as you said, I'm rusty, so, maybe I just need a bit of practice?"
    new "T: É como tu disseste, estou enferrujado, por isso, talvez só precise de um pouco de prática?"

    # say L1282 pla
    old "Practice?"
    new "B:lyd: É como tu disseste, estou enferrujado, então, talvez só precise de um pouco de prática?"

    # say L1283 lyd
    old "I think that if I do it with someone at least once, from there on it should be a lot easier with other guys."
    new "B:pla: Prática?"

    # say L1285 pla
    old "Ohh, I get it... Well, that makes a lot of sense. I think you're right."
    new "Mas com quem vais fazer isso pela primeira vez?"

    # say L1286 pla
    old "But who are you gonna do it with first?"
    new "B:pla: Ohh, percebo... Bem, isso faz todo o sentido. Acho que tens razão."

    # say L1287 lyd
    old "Well... so far there's only one man I think I feel comfortable enough to do it with."
    new "B:pla: Mas com quem vais fazer isso primeiro?"

    # say L1288 pla
    old "And who is it?"
    new "B:lyd: Bem... até agora só há um homem com quem me sinto confortável o suficiente para fazer isso."

    # say L1289 pla
    old "Oh wait, you don't mean... me?!"
    new "B:pla: E quem é?"

    # say L1290 lyd
    old "What can I tell you? As you've seen you're the only one with which I've been able to do anything without feeling weird."
    new "B:pla: Oh espera, tu não estás a falar de... mim?!"

    # say L1291 pla
    old "B- but you know."
    new "B:lyd: O que posso dizer? Como viste, tu és o único com quem consegui fazer algo sem me sentir estranho."

    # say L1293 lyd
    old "I know, it sounds crazy, and maybe I'm just saying this impulsively, but this wouldn't be the first time we do something of the sort."
    new "E eu acho que não teria qualquer problema se fosses tu, estou claramente confortável contigo..."

    # say L1294 lyd
    old "And I think that I wouldn't have any problem if it were you, I'm clearly comfortable with you...."
    new "B:lyd: Eu sei, soa louco, e talvez eu esteja a dizer isto impulsivamente, mas não seria a primeira vez que fazemos algo assim."

    # say L1295 pla
    old "B- but, that would be way too far over the line!"
    new "B:lyd: E acho que não teria problema se fosses tu, estou claramente à vontade contigo...."

    # say L1296 lyd
    old "You are right... I better stop this and settle down."
    new "Não, não, não é por isso."

    # say L1297 pla
    old "No, no, it's not about that."
    new "Não, não, não é por isso. É só que a solução parece muito drástica."

    # say L1298 pla
    old "It's just that the solution sounds way too drastic."
    new "B:pla: Não, não, não é nada disso."

    # say L1299 pla
    old "Why don't you try other solutions first? Going to therapy, or maybe trying with some other dude..."
    new "B:pla: É que a solução parece demasiado drástica."

    # say L1300 lyd
    old "Oh please, you know that's not going to help me!"
    new "B: pla: Porque não tentas outras soluções primeiro? Ir à terapia, ou talvez experimentar com outro gajo..."

    # say L1301 lyd
    old "Besides, this isn't easy for me either."
    new "A:lyd: Imagina só o quão embaraçante seria continuar a tentar com uma e outra pessoa sem conseguir fazer nada."

    # say L1302 lyd
    old "Just imagine how embarrassing it would be to keep trying with one and another person without managing to do anything."
    new "B:lyd: Além disso, isto não é fácil para mim também."

    # say L1304 lyd
    old "It's not like I want my life to be in shambles like this, you know [pla]?"
    new "T(lyd|tu|say): Não é como se eu quisesse que a minha vida fosse uma desgraça assim, sabes [pla]?"

    # say L1306 lyd
    old "Won't you help me with that?"
    new "B:lyd: Tudo o que te estou a dizer é que estou a tentar reconstruir a minha vida para não acabar como a Sra. Jones."

    # say L1307 lyd
    old "After all, it would just be this one time, just so that I get used to it again."
    new "B:lyd: Não me ajudas com isso?"

    # say L1308 pla
    old "Hmm, I suppose what you're saying makes sense."
    new "B:lyd: Afinal, seria só desta vez, só para eu me habituar de novo."

    # say L1309 pla
    old "I'm not sure I like this, but ok, I suppose we can do it."
    new "B:pla: Hmm, suponho que o que dizes faz sentido."

    # say L1327 pla
    old "I think the best thing is that I go for today."
    new "B:lyd: Não te preocupes, deita-te no sofá e deixa tudo por minha conta!"

    # say L1328 pla
    old "Are you going to keep talking with the guy?"
    new "B:pla: Acho que o melhor é eu ir hoje."

    # say L1329 lyd
    old "I will, I really like him, so, I hope we can have another date."
    new "B:pla: Vais continuar a falar com o rapaz?"

    # say L1330 lyd
    old "And this time I'm sure everything will go well."
    new "B:lyd: Vou, gosto muito dele, então, espero que possamos ter outro encontro."

    # say L1331 pla
    old "I'm sure it will, good luck."
    new "T(pla|tu|say): Tenho a certeza que vai correr bem, boa sorte."

    # say L1353 pla
    old "Great, so tell me, everything went well on your date, right?"
    new "Ótimo, então conta-me, tudo correu bem no teu encontro, certo?"

    # say L1354 lyd
    old "Oh, that? Not at all!"
    new "B:pla: Ótimo, então conta-me, tudo correu bem no teu encontro, certo?"

    # say L1355 pla
    old "What's with that face?"
    new "A:pla: Não me digas que as coisas correram mal de novo no teu encontro."

    # say L1356 pla
    old "Don't tell me things went wrong again on your date."
    new "T(pla|tu|say): Não me digas que as coisas correram mal de novo no teu encontro."

    # say L1357 lyd
    old "Ugh. Then I don't know what else to tell you."
    new "A:lyd: Não aconteceu nada, esse é o problema."

    # say L1360 lyd
    old "Nothing happened, that's the problem."
    new "Nada. Nada de nada."

    # say L1361 pla
    old "Nothing? Nothing at all?"
    new "B:lyd: Não aconteceu nada, esse é o problema."

    # say L1362 lyd
    old "Well, yes..."
    new "B:pla: Nada? Nada mesmo?"

    # say L1366 lyd
    old "I don't know, the date went well, he was as well behaved as always, but when the moment came I just felt that I couldn't do it."
    new "T(lyd|tu|say): Não sei, o encontro correu bem, ele estava tão comportado como sempre, mas quando o momento chegou, senti que não conseguia fazer."

    # say L1368 pla
    old "But, I thought you had gotten over your intimacy problem, that's why we did what we did, right?"
    new "B:lyd: Não sei, o encontro correu bem, ele estava tão bem-comportado como sempre, mas quando o momento chegou, simplesmente senti que não conseguia fazer."

    # say L1369 lyd
    old "Yeah, yeah, and I think it did help. After all, this time I wasn't scared or feeling bad or anything."
    new "B:pla: Mas, eu pensei que já tinhas superado o teu problema de intimidade, por isso fizemos o que fizemos, certo?"

    # say L1370 lyd
    old "I just didn't want him to put his hands on me, I don't know, I guess we just didn't have any sexual attraction."
    new "B:lyd: Sim, sim, e acho que ajudou. Afinal, desta vez não tive medo nem me senti mal ou algo assim."

    # say L1371 lyd
    old "You have no idea how annoyed I am because of that."
    new "B:lyd: Eu simplesmente não queria que ele me tocasse, não sei, acho que não tínhamos atração sexual."

    # say L1372 pla
    old "Hmm, well, if you say that you didn't feel bad or scared, I guess that's a good thing."
    new "B:lyd: Não sabes como estou irritada por causa disso."

    # say L1373 pla
    old "Those things happen."
    new "B:pla: Hmm, bem, se tu dizes que não te sentiste mal ou assustado, acho que isso é bom."

    # say L1374 lyd
    old "I'm still very frustrated though."
    new "B:pla: Essas coisas acontecem."

    # say L1375 lyd
    old "But I understand that the problem wasn't me, I think the problem was that I didn't like him enough."
    new "B:lyd: Ainda estou muito frustrada, tu sabes."

    # say L1377 pla
    old "Hmph, if you say so."
    new "T: Hmph, se tu dizes."

    # say L1378 lyd
    old "Oh, don't be mad, at least I'm not feeling bad about it."
    new "B:pla: Hmph, se tu dizes."

    # say L1379 lyd
    old "Just a little bit annoyed."
    new "B:lyd: Oh, não fiques zangado, pelo menos eu não estou a sentir-me mal com isso."

    # say L1380 pla
    old "I guess we can call that a silver lining..."
    new "B:lyd: Um pouco irritada."

    # say L1381 pla
    old "But if that's not the thing that has you in a good mood, what is it?"
    new "Mas se isso não é o que te deixa de bom humor, o que é?"

    # say L1382 lyd
    old "Right, that!"
    new "B:pla: Mas se não é isso que te deixa de bom humor, o que é?"

    # say L1383 lyd
    old "I've been talking to another guy, and actually, things seem to be going well."
    new "T(lyd|tu|dizes): Tenho estado a falar com outro rapaz, e na verdade, as coisas parecem estar a correr bem."

    # say L1384 lyd
    old "We haven't met, but I really like his personality."
    new "B:lyd: Tenho estado a falar com outro rapaz, e na verdade, as coisas parecem estar a correr bem."

    # say L1385 pla
    old "That's cool."
    new "Isso é fixe."

    # say L1387 lyd
    old "Hmm, in fact, I think you could help me out with that."
    new "Ajuda-te?"

    # say L1388 pla
    old "Help you?"
    new "T(pla|tu|say): Ajudar-te?"

    # say L1389 lyd
    old "Yeah, to talk to him, just before you arrived we were in the middle of a conversation."
    new "B:pla: Queres ajuda?"

    # say L1390 lyd
    old "I think you could help me chat with him."
    new "B:lyd: Sim, estávamos a falar, acabámos de interromper a conversa quando tu chegaste."

    # say L1391 pla
    old "Hmm, I don't know... I mean, if you've been talking with these guys I think you can keep up the conversation without my help."
    new "T: Hmm, não sei... Quero dizer, se já tens falado com esses caras, acho que consegues continuar a conversa sem a minha ajuda."

    # say L1392 lyd
    old "Oh, don't say that, you are really a great help to me."
    new "T(lyd|tu|say): Oh, não digas isso, tu és realmente uma grande ajuda para mim."

    # say L1393 lyd
    old "But you know I have some problems with the keyboard and his expressions."
    new "B:lyd: Oh, não digas isso, tu és realmente uma grande ajuda para mim."

    # say L1394 pla
    old "I guess you're right. I suppose it would do no harm to give you a hand."
    new "T: Acho que tens razão. Suponho que não fará mal ajudar-te."

    # say L1396 lyd
    old "Great, then, let's go to the sofa to chat more comfortably."
    new "T(lyd|tu|say): Ótimo, então, vamos para o sofá conversar com mais conforto."

    # say L1411 lyd
    old "This is where we were in the conversation a little before you arrived."
    new "B:lyd: Ótimo, então, vamos para o sofá conversar com mais conforto."

    # say L1412 pla
    old "I see, things seem to be going well."
    new "T(pla|tu|say): Vejo, as coisas parecem estar a correr bem."

    # say L1413 lyd
    old "I guess they are... so what do I tell him now?"
    new "B:pla: Entendo, as coisas parecem estar a correr bem."

    # say L1414 pla
    old "Well, as I told you last time, you have to be playful, but a little suggestive."
    new "B:lyd: Acho que são... então, o que lhe digo agora?"

    # say L1415 lyd
    old "I was​​ thinking of telling him something about my clothes, about how sexy they would be."
    new "B:pla: Bem, como te disse da última vez, tens de ser divertida, mas um pouco sugestiva."

    # say L1416 pla
    old "That sounds good, how do you want me to say it?"
    new "B:lyd: Estava a pensar em dizer-lhe algo sobre a minha roupa, sobre como seria sexy."

    # say L1417 lyd
    old "Like this 'To start, I would get there wearing a trench coat'."
    new "B:pla: Isso soa bem, como queres que eu o diga?"

    # say L1419 pla
    old "What? That's not sexy at all!"
    new "B:lyd: Assim, 'Para começar, eu chegaria lá usando um casaco de chuva'."

    # say L1420 lyd
    old "Of course it isn't, it's something I read in a magazine a long time ago, just write it."
    new "B:pla: O quê? Isso não é sexy de todo!"

    # say L1424 pla
    old "He answered 'a trench coat?' See? That's not sexy."
    new "B:lyd: Claro que não, é algo que li numa revista há muito tempo, só escreve."

    # say L1426 lyd
    old "Fufu, what's sexy is what I would bring underneath."
    new "B:pla: Ele respondeu 'um casaco de cabedal?' Vês? Isso não é sexy."

    # say L1427 lyd
    old "Write 'Then I would take it off, to let you see the black lingerie that I'm wearing underneath.'"
    new "B:lyd: Fufu, o que é sexy é o que eu traria por baixo."

    # say L1429 pla
    old "Oh! I see what you mean."
    new "B:lyd: Escreve 'Depois tirava, para te mostrar a lingerie preta que estou a usar por baixo.'"

    # say L1432 pla
    old "He really seemed to like that, now he's asking 'Then what else?'"
    new "B:pla: Oh! Agora percebo o que queres dizer."

    # say L1434 lyd
    old "I would take you by the hand and bring you to the couch, where I would want you to lay down."
    new "T(lyd|tu|say): Pegaria na tua mão e levar-te-ia para o sofá, onde quereria que te deitasses."

    # say L1438 pla
    old "He says 'Oh yeah? And what would you do once I'm laying down on the couch baby?'"
    new "B:lyd: Eu pegaria na tua mão e te levaria ao sofá, onde eu queria que tu deitasses."

    # say L1439 lyd
    old "I would lay down on top of you, and I would take those lips of yours on a hot, rough kiss."
    new "T(lyd|tu|say): Eu deitava-me em cima de ti e beijava-te com paixão, num beijo quente e intenso."

    # say L1442 pla
    old "He wrote 'I like that! But that's all you'd want?'"
    new "B:lyd: Iria deitar-me em cima de ti e beijar-te-ia com um beijo quente e áspero."

    # say L1444 lyd
    old "Haha, so cute, tell him 'Well, aren't we a little impatient tonight?'"
    new "T: Haha, tão fofo, diz-lhe 'Então, não estamos um pouco impacientes esta noite?'"

    # say L1447 pla
    old "Hmm, he says 'I'm sorry baby, it's just that I can't resist you.'"
    new "B:lyd: Haha, tão fofo, diz-lhe 'Então, não estamos um pouco impacientes esta noite?'"

    # say L1448 lyd
    old "That's very cute of him."
    new "Está bem, também não consigo resistir-te."

    # say L1449 lyd
    old "Write 'It's ok, I can't resist you either.'"
    new "B:lyd: É muito fofo dele."

    # say L1451 lyd
    old "So while we're kissing, I slowly bring my hand down your chest, pass your abs... and over that big bulging dick under your pants."
    new "B:lyd: Tudo bem, também não consigo resistir a ti."

    # say L1462 pla
    old "That's it baby! Yeah, you know just what I want."
    new "B:lyd: Então, enquanto nos beijamos, eu vou lentamente descendo a mão pelo teu peito, passo pelos teus abdominais... e sobre aquele grande volume nas tuas calças."

    # say L1463 lyd
    old "Fufu, and you haven't seen anything yet..."
    new "B:pla: É isso aí, bebé! Sim, tu sabes exactamente o que eu quero."

    # say L1466 pla
    old "Tell me more!"
    new "B:lyd: Fufu, e ainda não viste nada..."

    # say L1467 lyd
    old "I'll feel your big hard cock with my hand, and that is gonna make me horny..."
    new "T(tu): Vou sentir o teu pau grande e duro com a minha mão, e isso vai deixar-me excitada..."

    # say L1478 lyd
    old "And I'm going to rub it over your pants, feeling how big it is..."
    new "B:lyd: Vou sentir o teu pau grande e duro com a minha mão, e isso vai deixar-me excitada..."

    # say L1481 pla
    old "Ohh, you'll love to feel every inch of me..."
    new "B:lyd: E vou esfregar na tua calça, sentindo o quão grande é..."

    # say L1482 lyd
    old "I already love it... But you'll love what I'm going to do next..."
    new "B:pla: Ohh, vais adorar sentir cada centímetro de mim..."

    # say L1485 pla
    old "Ohh yes babe, what are you gonna do next?"
    new "B:lyd: Eu já adoro... Mas vais adorar o que vou fazer a seguir..."

    # say L1486 lyd
    old "Well, I'm going to kneel in front of you and I'm going to take out that huge cock."
    new "B:pla: Ohh sim querida, o que vais fazer a seguir?"

    # say L1495 lyd
    old "Then, I'll bring my head down and kiss and lick the tip of your cock."
    new "B:lyd: Vou ajoelhar-me à tua frente e vou tirar esse pau enorme."

    # say L1504 pla
    old "Mmm, I love that, I love how you kiss it."
    new "B:lyd: Então, vou baixar a cabeça e beijar e lamber a ponta do teu pénis."

    # say L1514 lyd
    old "That was a great conversation! Wasn't it?"
    new "B:pla: Mmm, adoro isso, adoro como tu beijas."

    # say L1516 pla
    old "Uhm, sure... I was very good."
    new "B:lyd: Foi uma ótima conversa! Não foi?"

    # say L1517 lyd
    old "I think this might be the right guy for me, he's hot, he's into me. He's just great, right?"
    new "T(lyd|tu|say): Acho que este pode ser o homem certo para mim, ele é giro, está interessado em mim. Ele é simplesmente ótimo, não é?"

    # say L1518 pla
    old "Yeah, yeah... He sounds like a great guy."
    new "B:lyd: Acho que este pode ser o homem certo para mim, ele é giro, está interessado em mim. Ele é simplesmente ótimo, não é?"

    # say L1519 pla
    old "Anyway, I think I should probably go now."
    new "T(pla|tu|say): De qualquer forma, acho que devo ir agora."

    # say L1520 pla
    old "You know, before Anna arrives and stuff."
    new "B:pla: De qualquer forma, acho que devo ir agora."

    # say L1522 lyd
    old "Yeah, that's probably better. Thank you so much."
    new "A:pla: Quemaa?! O que estás a fazer aqui?!"

    # say L1538 pla
    old "Whoaa?! What are you doing here?!"
    new "B:lyd: Sim, provavelmente é melhor. Muito obrigado."

    # say L1542 lyd
    old "Did I s- surprize you?!"
    new "B:lyd: Tu ficaste surpreendido?"

    # say L1543 pla
    old "Oh! Yes, you did! Why are you in my room?"
    new "B:lyd: Surpreendi-te?!"

    # say L1544 pla
    old "How did you get in?"
    new "B:pla: Oh! Sim, fizeste! O que estás a fazer no meu quarto?"

    # say L1545 lyd
    old "Sue gave 'e a key."
    new "B:pla: Como é que entraste?"

    # say L1547 pla
    old "I see, well, that makes sense."
    new "B:lyd: Sue deu-lhe uma chave."

    # say L1548 pla
    old "But you still haven't answered, what are you doing in my room? And this smell... It's alcohol."
    new "B:pla: Entendo, bem, isso faz sentido."

    # say L1549 pla
    old "Are you drunk? I thought tonight was the night of your date."
    new "B: Mas ainda não respondeste, o que estás a fazer no meu quarto? E este cheiro... É álcool."

    # say L1550 pla
    old "Shouldn't you be with the guy?"
    new "B: pla: Estás bêbado? Pensei que esta noite fosse a noite do teu encontro."

    # say L1551 lyd
    old "I 'uess I zhould be. But it didn't go well, like a' all."
    new "T(lyd|tu|say): Acho que devia estar. Mas não correu bem, como sempre."

    # say L1552 pla
    old "It didn't? What happened this time?"
    new "T(pla|tu|say): Não? O que aconteceu desta vez?"

    # say L1553 lyd
    old "I don't know!"
    new "B:pla: Não? O que aconteceu desta vez?"

    # say L1554 lyd
    old "I just wasn't able to, when 'e moment came I just felt... nothing."
    new "B:lyd: Não sei!"

    # say L1555 pla
    old "What do you mean nothing? I thought you liked the guy."
    new "T(pla|tu|say): O que queres dizer com nada? Pensei que gostasses dele."

    # say L1556 lyd
    old "I did, I really did, and I think he's cute, and sexy, and funny... but I just wasn't able to focus on him."
    new "T(lyd|tu|say): Eu gostava, gostava mesmo, e acho que ele é fofo, sexy e engraçado... mas simplesmente não conseguia me concentrar nele. A:lyd: Só não queria fazer isso com ele... mas ainda quero ter sexo."

    # say L1557 lyd
    old "I just didn't want to do it with him... but I still want to have sex."
    new "B:lyd: Eu fiz, eu realmente fiz, e acho que ele é fofo, sexy e engraçado... mas simplesmente não consegui me concentrar nele."

    # say L1559 pla
    old "I don't get it, if you want sex all you had to do was sleep with that guy."
    new "T: Não percebo, se queres sexo bastava teres dormido com esse tipo."

    # say L1560 lyd
    old "I don't really think that would have worked."
    new "T: Não acho que isso teria funcionado."

    # say L1561 lyd
    old "I think I was wrong about some'ing, I'm not the type of woman who... hips!"
    new "B:lyd: Não acho que isso teria funcionado."

    # say L1562 lyd
    old "Sorry... who sleeps around. I'm a one-man woman!"
    new "B:lyd: Acho que me enganei em algo, não sou o tipo de mulher que... hips!"

    # say L1563 pla
    old "I get that, but you told me you believed this guy was that one man, why did you suddenly backed out of it? "
    new "B:lyd: Desculpa... quem é que anda a dormir com todo o mundo. Eu sou uma mulher de um só homem!"

    # say L1564 lyd
    old "D- don't you get it? I already have a man in my life."
    new "T(lyd|tu|say): D- não percebes? Já tenho um homem na minha vida."

    # say L1565 pla
    old "What? Don't tell me you're still thinking about grandpa."
    new "B:lyd: D- não percebes? Já tenho um homem na minha vida."

    # say L1566 pla
    old "I think you need to move on from that, that's the whole point, that you wouldn't be caught up in the past."
    new "B: pla: Que? Não me digas que ainda estás a pensar no avô."

    # say L1567 lyd
    old "No, not, no, think about it, there's only one man that I let, and want to touch me."
    new "B:pla: Acho que precisas de avançar, é o ponto, não ficares preso no passado."

    # say L1569 pla
    old "You don't mean... me?!"
    new "B:lyd: Não, não, pensa bem, só há um homem que eu deixo e quero que me toque."

    # say L1570 lyd
    old "Who else dummy?"
    new "B:pla: Tu não estás a falar... de mim?!"

    # say L1572 pla
    old "W- w- what?"
    new "B:lyd: Quem mais, bobo?"

    # say L1574 lyd
    old "As I said you're the only one I'll allow to touch me."
    new "B:pla: W- w- what?"

    # say L1575 lyd
    old "Not only that, you're the only man I was able to think about when I tried to do it with those other guys."
    new "B:lyd: Como eu disse, tu és o único que eu permito tocar em mim."

    # say L1578 lyd
    old "Besides, all of those guys, they're so childish, going all out on a phone."
    new "B:lyd: Depois de ver todas essas fotos de pénis que me enviavam, agora só penso que eles não valem nada. Nada comparado contigo."

    # say L1579 lyd
    old "Ugh!"
    new "B:lyd: Além disso, todos esses caras, são tão infantis, a dar tudo num telemóvel."

    # say L1580 lyd
    old "There's only one man I want to be intimate with..."
    new "B:lyd: Ugh!"

    # say L1581 pla
    old "Are you for real? Do you really mean this?"
    new "B:lyd: Só há um homem com quem quero ser íntima..."

    # say L1582 lyd
    old "I do, I really do."
    new "B:pla: Estás a ser a sério? É verdade que queres isto?"

    # say L1583 lyd
    old "And I also know you want it too, come on, I know you liked it, the other times. So come on, let's just do it."
    new "B:lyd: Eu faço, eu realmente faço."

    # say L1585 lyd
    old "Why do you think I came all the way here?"
    new "B:lyd: E eu também sei que tu queres, vamos lá, sei que gostaste nas outras vezes. Então, vamos lá, vamos fazê-lo."

    # say L1586 lyd
    old "It wasn't only to tell you that I couldn't get it on with some other guys."
    new "T(lyd|tu|say): Não foi só para te dizer que não consegui ficar com outros caras."

    # say L1587 pla
    old "But- but... w- we're in my room, I don't think we should."
    new "B:lyd: Não foi só para te dizer que não consegui ficar com outros caras."

    # say L1589 lyd
    old "Shhh, don't worry, nobody will listen to us. It's ok..."
    new "B: Mas... mas... estamos no meu quarto, não acho que devemos."

    # say L1596 lyd
    old "What do you think, I'm finally cutting loose and doing what I want."
    new "B:lyd: Shhh, não te preocupes, ninguém nos vai ouvir. Tudo bem..."

    # say L1605 lyd
    old "Ever since last time I've been wanting you to fuck me again."
    new "T(lyd|tu|say): Desde a última vez que tenho vontade de tu me foderes de novo."

    # say L1606 lyd
    old "It's because of this dick of yours that I haven't been able to be with other guys."
    new "B:lyd: Desde a última vez que tenho vontade de tu me foderes de novo."

    # say L1607 lyd
    old "I still remember how good it felt that one time."
    new "B:lyd: É por causa deste pénis teu que não tenho conseguido estar com outros rapazes."

    # say L1608 lyd
    old "Now, let's not delay it anymore, I want it in me right now!"
    new "B:lyd: Ainda me lembro de como foi bom daquela vez."

    # say L1617 lyd
    old "Oh! Oh my god! What am I doing in your room?!"
    new "B:lyd: Agora, não vamos adiar mais, quero que me faças isso já!"

    # say L1619 pla
    old "Uhh... Well... yesterday you came here."
    new "B:lyd: Oh! Oh meu Deus! O que estou a fazer no teu quarto?!"

    # say L1620 pla
    old "You were drunk and..."
    new "B:pla: Uhh... Bem... ontem tu vieste aqui."

    # say L1621 lyd
    old "Oh God! That's right! I came in here when I was drunk!"
    new "B:pla: Tu estavas bêbado e..."

    # say L1624 pla
    old "Hey..."
    new "B:lyd: E eu não devia estar aqui, ontem à noite foi só efeito do álcool e mais nada."

    # say L1625 lyd
    old "Don't say anything, it's getting very early and somebody could see us."
    new "B:pla: Olá..."

    # say L1626 lyd
    old "I should just leave, bye."
    new "B:lyd: Não digas nada, está a ficar muito cedo e alguém poderia ver-nos."

    # say L1645 lyd
    old "[pla]! H- hi."
    new "Ouvem [pla]! H- olá."

    # say L1647 lyd
    old "Listen [pla] what happened last night made me think a lot about some stuff."
    new "B:lyd: [pla]! H- olá."

    # say L1649 lyd
    old "So, I decided we shouldn't see each other or talk again for a while."
    new "O:pla: Escuta, sei que estás abalado e confuso."

    # say L1651 pla
    old "Listen, I know you're shook and confused."
    new "B:lyd: Então, decidi que não devemos nos ver ou falar por um tempo."

    # say L1652 pla
    old "But I don't think you should be alone right now."
    new "B:pla: Ouve, sei que estás abalado e confuso."

    # say L1653 lyd
    old "This isn't just a rash decision."
    new "B:pla: Mas não acho que deves ficar sozinha agora."

    # say L1654 lyd
    old "I think I made a mistake with this whole online dating thing."
    new "T(lyd|tu|say): Acho que cometi um erro com toda esta coisa de dating online."

    # say L1655 lyd
    old "I did want to meet and date somebody."
    new "B:lyd: Acho que cometi um erro com toda esta coisa de dating online."

    # say L1656 lyd
    old "But it got out of my hands at one point. You saw how much it was affecting me."
    new "B:lyd: Queria mesmo conhecer e namorar alguém."

    # say L1657 lyd
    old "My sudden mood swings, and odd behavior."
    new "B:lyd: Mas escapou-me das mãos em determinado momento. Viste como me afetava."

    # say L1658 lyd
    old "I don't want to deal with that anymore."
    new "T: Não quero lidar com isso mais."

    # say L1659 lyd
    old "No, what I need is time to think and get my bearings together."
    new "Não, o que preciso é de tempo para pensar e me reorganizar."

    # say L1660 pla
    old "So, I shouldn't have helped you?"
    new "B:lyd: Não, o que preciso é de tempo para pensar e me reorganizar."

    # say L1661 lyd
    old "That's not what I said. I actually think that your help was good for me, and I'm grateful for it."
    new "T(lyd|tu|say): Não foi isso que eu disse. Na verdade, acho que a tua ajuda foi boa para mim e estou grato por isso. A:lyd: É só que sinto que as coisas têm fugido um pouco ao controlo ultimamente, por isso devíamos apenas relaxar um pouco. Sabes?"

    # say L1662 lyd
    old "It's just that I feel that things have gotten out of hand lately, so we should just relax for a little while. You know?"
    new "B:lyd: Isso não é o que eu disse. Na verdade, acho que a tua ajuda foi boa para mim, e estou grato por isso."

    # say L1663 pla
    old "I guess that if that is what you want..."
    new "B:lyd: É só que sinto que as coisas têm fugido um pouco ao controlo ultimamente, por isso devíamos apenas relaxar um pouco. Sabes?"

    # say L1664 lyd
    old "It is, it really is."
    new "B:pla: Acho que se é isso que queres..."

    # say L1666 pla
    old "I see... I understand. If you're ok, then I guess I better leave."
    new "T: Vejo... Entendo. Se estás bem, acho que é melhor eu ir-me embora."

    # say L1667 pla
    old "But if you ever feel like you need to talk, don't hesitate to call me. Ok?"
    new "B:pla: Eu percebo... Entendo. Se estás bem, acho melhor ir-me embora."

    # say L1668 lyd
    old "I will, thank you."
    new "Claro, obrigado."


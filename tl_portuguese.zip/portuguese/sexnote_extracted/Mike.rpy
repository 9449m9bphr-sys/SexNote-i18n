# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Mike.rpy
translate portuguese strings:

    # say L32 whi
    old "Mmm, hi, [pla]. Long time, no see! My, how you've grown!"
    new "T(whi|formal|say): Mmm, olá, [pla]. Há muito tempo que não nos vemos! Meu, como tu cresceste!"

    # say L37 whi
    old "I guess you came over to see Mike? What are you two planning on doing?"
    new "B:pla: (Gulp) Olá, Sra. White. Obrigado."

    # say L39 pla
    old "Uhh... We... Nothing... Hehe."
    new "B:whi: Acho que vieste ver o Mike? O que vocês dois planejam fazer?"

    # say L44 mik
    old "Finally! You decided to come! Don't bother us, Mom. We gotta work on that dumb school project."
    new "B:pla: Uhh... Nós... Nada... Hehe."

    # say L46 whi
    old "Ok. If you guys need anything, I'll be here."
    new "B:mik: Finalmente! Decidiste vir! Não nos incomodes, Mãe. Temos que trabalhar nesse estúpido projeto escolar."

    # say L52 pla
    old "Alright, man. What's this great thing you just had to show me? "
    new "B:whi: Ok. Se precisarem de algo, estou aqui."

    # say L54 mik
    old "Well, you came just in time. Every day... at this minute... it begins."
    new "B:pla: Então, mano. Qual é essa grande coisa que tinhas de me mostrar?"

    # say L56 pla
    old "What begins?"
    new "B:mik: Bem, tu chegaste a tempo. Todos os dias... a esta hora... começa."

    # say L58 mik
    old "You'll see... Just wait."
    new "B:pla: O que começa?"

    # say L61 pla
    old "The hell you doing, Mike?"
    new "B:mik: Vais ver... Só espera."

    # say L62 mik
    old "Let me enjoy for a sec. It'll be your turn in a bit."
    new "B:pla: Que raio estás a fazer, Mike?"

    # say L67 mik
    old "Ok, here. Take this and peep what's out the front window? "
    new "B:mik: Deixa-me aproveitar um bocadinho. Vai ser a tua vez daqui a pouco."

    # say L74 pla
    old "Oh shit!"
    new "B:mik: Ok, aqui. Olha o que está na frente da janela?"

    # say L75 mik
    old "She's hot, isn't she?"
    new "B:pla: Oh merda!"

    # say L77 pla
    old "Damn. I think... I think, I've seen her before"
    new "B:mik: Ela é gira, não é?"

    # say L78 mik
    old "Wait... Do you really know  that lady?"
    new "B:pla: Merda. Acho... Acho que já a vi antes."

    # say L84 pla
    old " I think so but I'm not sure... I'd have to get a closer look."
    new "B:mik: Espera... Tu realmente conheces aquela senhora?"

    # say L87 mik
    old "Well ... I know something for sure... she is sexy as fuck! "
    new "B:pla: Acho que sim, mas não tenho a certeza... Teria de olhar mais de perto."

    # say L89 pla
    old "(she really is...)"
    new "B:mik: Bem... Eu sei uma coisa com certeza... ela é sexy como a puta!"

    # say L93 mik
    old "Haha. I knew you would like it."
    new "T: Haha. Eu sabia que ias gostar."

    # say L101 mik
    old "What? Is she getting naked? Give me those binoculars!"
    new "B:mik: Haha. Eu sabia que tu ias gostar."

    # say L107 pla
    old "(Hmm... What am I going to do now? Can't let Mike see me like this.)"
    new "B:mik: Que? Ela está a despir-se? Dá-me esses binóculos!"

    # say L109 pla
    old "(The only solution is to go to the bathroom and try to masturbate.)"
    new "B:pla: (Hmm... O que vou fazer agora? Não posso deixar o Mike me ver assim.)"

    # say L111 pla
    old "Hmm... I need to use your bathroom, man. You keep watching her..."
    new "B:pla: (A única solução é ir à casa de banho e tentar me masturbar.)"

    # say L112 mik
    old "Ok. Suit yourself."
    new "B:pla: Hmm... Preciso de usar a tua casa de banho, mano. Tu continua a ver..."

    # say L117 pla
    old " Whoops. I'm sorry, ma'am. I thought there was no one-"
    new "B:mik: Ok. Tudo bem."

    # say L121 whi
    old "Haha! I am just kidding. Do what you need to do, kid. I'll continue taking a shower, deal?"
    new "B:pla: Não. Claro que não, Sra. White..."

    # say L122 pla
    old "Ok... (Hmm I have no option) "
    new "B:whi: Haha! Estou só a brincar. Faz o que precisas, miúdo. Vou continuar a tomar banho, combinado?"

    # say L129 whi
    old "(What is that noise? ...What is he doing?)"
    new "B:pla: Ok... (Hmm, não tenho opção...)"

    # say L133 whi
    old "(My word... He is hung!)"
    new "B:whi: (Que barulho é esse?...O que ele está a fazer?)"

    # say L139 whi
    old "(Mmm... I should just take my shower. I don't want him to see me peeping.)"
    new "B:whi: (Pelas minhas contas... Ele está bem dotado!)"

    # say L143 pla
    old "Well, I managed to solve it, but I don't know for how long..."
    new "B:whi: (Mmm... Devia ir tomar o meu duche. Não quero que ele me veja a espreitar.)"

    # say L145 pla
    old "I better say goodbye to Mike and go home."
    new "B:pla: Consegui resolver, mas não sei por quanto tempo..."

    # say L156 pla
    old " Hey, Mike. I have to jet."
    new "T(pla|tu|say): Hey, Mike. Tenho que ir."

    # say L157 mik
    old "Oh, ok.  If you want to check her out again, come tomorrow."
    new "B:pla: Hey, Mike. Tenho que ir."

    # say L159 pla
    old "W-What?!"
    new "B:mik: Oh, ok. Se quiseres ver a minha vizinha de novo, vem amanhã."

    # say L160 mik
    old "Yeah. If you want to see my neighbor again, come tomorrow..."
    new "B:pla: Q-Que?!"

    # say L162 pla
    old " Ohh, right. (Whew.) The neighbor... Ok. See you later, dude."
    new "A:mik: Ei, tu queres ver a vizinha de novo?"

    # say L182 mik
    old "Hey dude, you wanna see her again?"
    new "B:pla: Ohh, certo. (Ufa.) O vizinho... Ok. Até mais, mano."

    # say L185 pla
    old "Yeah, man. I want to check if I really know her."
    new "B:mik: Ei, gajo, queres ver a miúda de novo?"

    # say L187 mik
    old "Really? Ok, yeah, sure... Ok, it's your turn then..."
    new "B:pla: Yeah, man. I want to check if I really know her."

    # say L194 mik
    old "Remember, if she starts to undress you have to tell me..."
    new "B:mik: Mesmo? Ok, sim, claro... Ok, então é a tua vez..."

    # say L195 pla
    old "Alright..."
    new "T:pla: (Hmm, realmente? Outra ereção?) Mike, preciso ir à casa de banho. Queres continuar a ver?"

    # say L197 pla
    old "(Hmm, really? Another hardon?) Mike, I need to use the bathroom. You wanna keep watching?"
    new "B:pla: Tudo bem..."

    # say L198 mik
    old "Of course!... She's so hot."
    new "B:pla: (Hmm, realmente? Outra ereção?) Mike, preciso ir à casa de banho. Queres continuar a ver?"

    # say L212 mik
    old "You back, dude?... Check out this other position she's practicing..."
    new "B:mik: Claro!... Ela é tão gira."

    # say L215 pla
    old "Really? Let me see. (Maybe now I can see her face and know if I can if i can recognize her.)"
    new "B:mik: Estás de volta, cara?... Olha esta outra posição que ela está a praticar..."

    # say L217 mik
    old "Yeah, sure... Here you go."
    new "B:pla: Mesmo? Deixa-me ver. (Talvez agora eu possa ver o rosto dela e saber se a reconheço.)"

    # say L227 pla
    old "(Hmm, really? An erection again?) Mike, I need to use your bathroom. You can have the binoculars back, bud."
    new "B:mik: Claro... Aqui tens."

    # say L228 mik
    old "Sweet!"
    new "B:pla: (Hmm, realmente? Outra ereção?) Mike, preciso usar a tua casa de banho. Podes ter de volta os binóculos, meu."

    # say L251 mik
    old "She makes me so fuckin' hard. I really wanna fuck her..."
    new "B:pla: Que merda..."

    # say L253 pla
    old "(Aaaand, of course, another erection...) Yeah, Mike... this is awesome... You can keep watching..."
    new "B:mik: Ela deixa-me tão duro. Quero mesmo foder com ela..."

    # say L258 mik
    old "Perfect! Ohh man. Tonight, I'm going to jerk off just thinking about her... "
    new "B:pla: (E claro, mais uma ereção...) Sim, Mike... isto é incrível... Podes continuar a ver..."

    # say L259 pla
    old "...(This guy...)"
    new "Mike, preciso de usar a tua casa de banho, mano..."

    # say L261 pla
    old "Mike, I need to use your bathroom, man..."
    new "B:pla:...(Este tipo...)"

    # say L262 mik
    old "Nice... take your time. My turn to enjoy the view."
    new "B: Mike, preciso usar a tua casa de banho, mano..."

    # say L280 mik
    old "Ok, it's your turn then..."
    new "B:pla: Bem... Sim..."

    # menu L290 
    old "Position 1"
    new "B:mik: Ok, agora é a tua vez..."

    # menu L295 
    old "Position 2"
    new "B: n: Posição 1"

    # menu L300 
    old "Position 3"
    new "B: n: Posição 2"

    # menu L305 
    old "Continue"
    new "Continuar"

    # say L312 pla
    old "(Aaaand, here it is, another erection...) Mike... I need to use your bathroom.... You can keep watching..."
    new "B:n: Continuar"

    # say L313 mik
    old "Ok, man. It's my turn again..."
    new "B:pla: (Eis aqui, mais uma ereção...) Mike... Preciso usar a tua casa de banho.... Podes continuar a ver..."

    # menu L324 
    old "Handjob"
    new "Ok, tu. É a minha vez de novo..."

    # say L344 pla
    old "Ok, thank you, Mrs. White."
    new "T(pla|tu|say): Ok, obrigado, Sra. White."

    # say L353 whi
    old "Hey big boy... Don't you want to go to the bathroom again?"
    new "B:pla: Ok, obrigado, Sra. White."

    # say L355 pla
    old "...I...Umm... What... do you mean?"
    new "B:whi: Ei, grande rapaz... Não queres ir à casa de banho outra vez?"

    # say L357 whi
    old "I mean don't leave me waiting. I will be in there if you want to go at it again..."
    new "B:pla:...Eu... Hum... O que... queres dizer?"

    # say L367 whi
    old "Hey, handsome... Are you looking for some help?"
    new "B:whi: Quero dizer, não me deixes à espera. Vou estar lá se quiseres continuar..."

    # say L369 pla
    old "Wh... Huh?... Nah, I was... Looking for Mike..."
    new "B:whi: Ei, gato... Estás à procura de alguma ajuda?"

    # say L371 whi
    old "Ok, honey. Mmm, I will be in the bathroom waiting for you..."
    new "B:pla: Wh... Huh?... Não, eu estava... À procura do Mike..."

    # say L403 pla
    old "...Yeah, I'm looking for Mike, I... I will go to his bedroom, excuse me."
    new "B:whi: Ok, meu amor. Mmm, vou estar no banheiro à tua espera..."

    # say L437 pla
    old "(Daaaamn!).... I'm sorry, ma'am. I'm leaving right now."
    new "B:pla:...Sim, estou à procura do Mike, eu... Vou ao quarto dele, desculpe."

    # say L439 whi
    old "Ohh. I'm sorry. Silly me, I forgot to close the curtains... Haha! But don't you worry. I know what you're going to do and maybe I can give you some... inspiration..."
    new "B:pla: (Puta merda!).... Desculpa, senhora. Estou a sair já."

    # say L441 pla
    old "I... don't know... what you're talking about. (Gulp)"
    new "B:whi: Ohh. Desculpa. Que parva, esqueci-me de fechar as cortinas... Haha! Mas não te preocupes. Eu sei o que vais fazer e talvez eu possa dar-te um pouco de... inspiração..."

    # say L443 whi
    old "Ohh, come on... you're about to burst in those shorts of yours... Just let it out. Mmm, I wanna see it..."
    new "B:pla: Eu... não sei... do que estás a falar. (Engolir em seco)"

    # say L446 pla
    old "...O-Ok."
    new "B:whi: Ohh, vamos... estás prestes a explodir nessas calças... Deixa sair. Mmm, quero ver..."

    # say L449 whi
    old "That's right... Stroke that big cock for mommy..."
    new "B:pla:...O-Ok."

    # say L457 whi
    old "Thank you, honey... I hope we have a bathroom rondevu again."
    new "B:pla:...Isso foi intenso..."

    # say L459 pla
    old "I... I... have to go, Mrs. White."
    new "B:whi: Obrigada, querido... Espero que tenhamos outro encontro no banheiro."

    # say L463 pla
    old "Whoa... That was crazy..."
    new "B:pla: Eu... Eu... tenho que ir, Sra. White."

    # say L465 pla
    old "I better go home."
    new "B:pla: Uau... Isso foi louco..."

    # say L478 pla
    old "(Oh shit... Again).... I'm sorry, I'm leaving right now."
    new "B:pla: Melhor ir para casa."

    # say L498 whi
    old "Thank you, honey... I hope we have a bathroom rendezvous again."
    new "B:whi: Ohh, vamos... Deixa sair. Quero ver de novo..."

    # say L519 whi
    old "Hey handsome, I was waiting for you."
    new "B:whi: Obrigado, querida... Espero que tenhamos outro encontro no banheiro."

    # say L523 whi
    old "Come on, don't be shy. Take that monster out and get to jerking..."
    new "B:whi: Olá gato, estava à espera de ti."

    # say L531 whi
    old "Would you mind if I give you a hand?"
    new "B:whi: Vamos, não sejas tímido. Tira essa besta e começa a te masturbar..."

    # say L532 pla
    old "(Is this really happening?) W- What?"
    new "B:whi: Tu não te importas se te der uma mão, certo?"

    # say L544 whi
    old "You can come whenever you want and, I'll give you a hand, my pleasure, okay?"
    new "B: pla: (Isto está realmente a acontecer?) W- What?"

    # say L546 pla
    old "Yes, ma'am."
    new "B:whi: Podes vir quando quiseres e eu dou-te uma mão, com todo o prazer, ok?"

    # say L547 whi
    old "Get out before Mike suspects anything..."
    new "B:pla: Sim, senhora."

    # say L549 pla
    old "Ok, Mrs. White... "
    new "Bem, que carga pesada..."

    # say L552 whi
    old "Hmm, what a big load..."
    new "B:pla: Ok, Mrs. White..."

    # say L555 pla
    old "Wow... She jerked me off..."
    new "B:whi: Hmm, que carga pesada..."

    # say L556 pla
    old "I should take my ass home."
    new "B:pla: Uau... Ela me fez uma mastubação..."

    # say L581 whi
    old "Come on, Take off your pants. I have a little surprise for you..."
    new "B:pla: Devo levar o meu rabo para casa."

    # say L599 whi
    old "I will be waiting for you handsome..."
    new "B:whi: Vamos, tira as calças. Tenho uma surpresa para ti..."

    # say L607 whi
    old "Hmm, that tasted so good!"
    new "B:whi: Estarei à tua espera, bonito..."

    # say L610 pla
    old "Wow... W- what just happened?"
    new "Uau... O-O que acabou de acontecer?"


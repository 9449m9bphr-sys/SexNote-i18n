# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Akita.rpy
translate portuguese strings:

    # menu L36 
    old "Talk to her"
    new "Olá, bem-vindo à Jamliz Corporation! Como posso ajudar-te?"

    # say L39 aki
    old "Hello, welcome to Jamliz Corporation! How can I help you?"
    new "B:n: Fala com ela"

    # say L46 pla
    old "Delivery boy? Ok, well... I think that's it... right?"
    new "B:aki: Ohh, certo. Ela disse-me que ia enviar um rapaz para entregar esses documentos. Perfeito... Muito obrigado!"

    # say L48 aki
    old "Yes, and by the way, my name is Akita nice to meet you..."
    new "B:pla: Rapaz das entregas? Ok, bem... Acho que é isso... certo?"

    # say L54 pla
    old "Oh... right, of course, my bad... Well, it was nice to meet you, see you later..."
    new "B:aki: Sim, sim, tu já me tinhas dito... Hahaha."

    # say L75 pla
    old "Well... You're welcome, see you later..."
    new "B:aki: Hahaha, estou só a brincar contigo, perfeito... Muito obrigado."

    # say L77 aki
    old "Goodbye, handsome."
    new "B:pla: Bem... De nada, até mais tarde..."

    # say L88 pla
    old "I shouldn't bother her. She's working."
    new "Não devo incomodá-la. Ela está a trabalhar."

    # menu L100 
    old "Use Agamoto Eye 1"
    new "Não devo incomodá-la. Ela está a trabalhar."

    # menu L104 
    old "Use Agamoto Eye 2"
    new "B:n: Usa o Agamoto Eye 1"

    # menu L108 
    old "Use Agamoto Eye 3"
    new "Não, não. Desculpa. Estava só a passear."

    # say L115 pla
    old "No, no. Sorry. I was just walking around."
    new "B:n: Usa Agamoto Eye 3"

    # menu L117 
    old "Back"
    new "Voltar"


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Bathroom.rpy
translate portuguese strings:

    # menu L11 
    old "Look at her better"
    new "Devo ir embora... Não quero que ela pense que sou pervertido."

    # say L19 pla
    old "I should leave... I don't want to make her think I'm perverted."
    new "Devo ir embora... Não quero que ela pense que sou pervertido."


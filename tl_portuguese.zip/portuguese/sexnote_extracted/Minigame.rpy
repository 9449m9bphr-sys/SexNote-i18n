# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Mechanics/Minigame.rpy
translate portuguese strings:

    # narrator L270 
    old "Drag the documents that must be sent to the right destination, do it quickly to reach all the deliveries of the day."
    new "Arrasta os documentos que devem ser enviados para o destino correto, faz isso rapidamente para cumprir todas as entregas do dia."

    # say L311 drag_name
    old "Town Hall"
    new "B:n: Arrasta os documentos que devem ser enviados para o destino correto, faz isso rapidamente para cumprir todas as entregas do dia."

    # narrator L396 
    old "To fix the roof you have to drag the tiles one by one to cover the damage."
    new "T: Para reparar o telhado, tens de arrastar as telhas uma a uma para cobrir o dano."

    # narrator L633 
    old "Open up the boxes two by two, and pair them up with the one equal to them."
    new "B:n: Para reparar o telhado, tens de arrastar as telhas uma a uma para cobrir o dano."

    # narrator L744 
    old "Try to select the profiles that are more akin to what Lydia wants. Swipe the correct ones right and the wrong ones left."
    new "B:n: Abre as caixas de duas em duas e junta-as com a que lhe é igual."

    # narrator L746 
    old "Remember that these are some of the characteristics that Lydia doesn't like: white hair, red hair, old look and mustache."
    new "B:n: Tenta selecionar os perfis que são mais próximos do que a Lydia quer. Desliza os corretos para a direita e os errados para a esquerda."


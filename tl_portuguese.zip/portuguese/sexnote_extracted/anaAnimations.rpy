# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/anaAnimations.rpy
translate portuguese strings:

    # say L12 ana
    old "What a nice cock do you have..."
    new "A:ana: Gostas disto, hã? Queres que seja mais rápido, bebé?"

    # say L16 ana
    old "Do you like it, Uh? Do you want it faster baby?"
    new "B:ana: Que pénis tão bonito tens..."

    # say L20 ana
    old "Oh yeah baby, I wanna see that huge cock cumming..."
    new "B:ana: Gostas disto, hã? Queres que seja mais rápido, meu bem?"

    # say L45 pla
    old "Mrs Anastasia... I- going to-"
    new "B:ana: Oh yeah baby, quero ver esse pau enorme a gozar..."

    # say L46 ana
    old "Oh yes, cum for mommy, give it to me..."
    new "B:pla: Mrs Anastasia... V-vou..."

    # say L51 ana
    old "Wow that was a lot of cum..."
    new "B:ana: Oh sim, goza para a mamã, dá-me isso..."

    # say L60 ana
    old "Mmm, I love your huge cock!"
    new "B:ana: Uau, isso foi muito esperma..."

    # say L64 ana
    old "Do you like my mounth, baby?"
    new "B:ana: Mmm, adoro o teu pénis enorme!"

    # say L68 ana
    old "Come on fuck my throat with your big cock!"
    new "B:ana: Gostas da minha boca, bebé?"

    # say L92 pla
    old "Anastasia I'm going to..."
    new "B:ana: Vamos, enfia o teu pau grande na minha garganta!"

    # say L93 ana
    old "Ohh yeah, cum all over my face!"
    new "B: pla: Anastasia vou..."

    # say L98 ana
    old "Uhhh warm and sweet..."
    new "B:ana: Ohh sim, goza na minha cara!"

    # say L115 ana
    old "Ahhh, yeah baby fuck me, FUCK ME!"
    new "B:ana: Uhhh quente e doce..."

    # say L119 ana
    old "Oh god, Oh god, It feels great!"
    new "B:ana: Ahhh, sim bebé foda-me, FODA-ME!"

    # say L123 ana
    old "H- Harder... Fuck me harder!"
    new "B:ana: Ah deus, Ah deus, É tão bom!"

    # say L147 ana
    old "Ahhh I'm cumming!"
    new "B:ana: H- Mais forte... Foda-me mais forte!"

    # say L148 pla
    old "I- I'm cumming too..."
    new "B:ana: Ahhh estou a gozar!"

    # say L169 ana
    old "Oh my God! This is amazing! Fuck me, Fuck me!"
    new "B:pla: I- I'm cumming too..."

    # say L173 ana
    old "AHHHH AHHHH, YEAH YEAH, HARDER BABY, HARDEER!"
    new "B:ana: Oh meu Deus! Isto é incrível! Foda-me, foda-me!"

    # say L177 ana
    old "OH MY GOD I LOVE YOUR COCK! GIMME MOREE!"
    new "B:ana: AHHHH AHHHH, SIM SIM, MAIS FORTE BEBÉ, MAIS FORTE!"

    # say L212 ana
    old "Oh my god! I loved it..."
    new "B:ana: OH MY GOD I AMO O TEU PÉNIS! DÁ-ME MAIS!"

    # say L213 pla
    old "I- I like it... too."
    new "A:ana: Oh meu Deus! Tu és incrível, adorei..."

    # say L216 ana
    old "Oh my god! You are amazing, I loved it..."
    new "B:pla: I- I gosto... demasiado."

    # say L220 ana
    old "I loved it..."
    new "A:ana: Ohhh, o teu pénis sente-se tão bem!"

    # say L229 ana
    old "Ohhh, your cock feels so nice!"
    new "B:ana: Adorei..."

    # say L233 ana
    old "YEAH, BABY, FASTER, FASTER!"
    new "B:ana: Ohhh, o teu pénis sente-se tão bem!"

    # say L237 ana
    old "OH MY FUCKING GOD! HARDER, FUCK ME HARDER!"
    new "B:ana: SIM, BEBÉ, MAIS RÁPIDO, MAIS RÁPIDO!"

    # say L275 lis
    old "Alright, take a few moments to settle into your position."
    new "B:ana: OH MY FUCKING GOD! MAIS FORTE, TRANSA COMIGO MAIS FORTE!"

    # say L276 lis
    old "Bring your attention to your breath."
    new "B:lis: Tudo bem, toma um momento para te acomodares."

    # say L277 lis
    old "Focus on the air coming in and out."
    new "B:lis: Presta atenção à tua respiração."

    # say L281 lis
    old "Notice the cool air entering your nostrils and the warm air leaving them."
    new "B:lis: Concentra-te no ar que entra e sai."

    # say L282 lis
    old "Without trying to change your breath, simply observe it."
    new "B:lis: Nota o ar frio a entrar nas tuas narinas e o ar quente a sair delas."

    # say L283 lis
    old "Let your body and mind relax."
    new "B:lis: Sem tentar alterar a tua respiração, simplesmente observa-a."

    # say L289 lis
    old "If your mind begins to wander, that's okay."
    new "B:lis: Deixa o teu corpo e mente relaxarem."

    # say L290 lis
    old "Let your body feel everything it needs to feel."
    new "B:lis: Se a tua mente começar a vaguear, isso está bem."

    # say L297 lis
    old "Allow yourself to be fully present with each breath."
    new "B:lis: Guia suavemente o teu foco de volta à sensação de respirar."

    # say L298 lis
    old "Finding calm and clarity in this simple act."
    new "B:lis: Deixa-te estar totalmente presente com cada respiração."

    # say L303 ana
    old "Mmm, this feels great, guys."
    new "B:lis: Encontrar calma e clareza neste ato simples."

    # say L304 ana
    old "M-My body's feeling amazing!"
    new "B:ana: Mmm, isto sente-se tão bem, rapazes."

    # say L305 lis
    old "That's good, that's your body reacting to the energy flowing within you."
    new "B:ana: O-O meu corpo está a sentir-se incrível!"

    # say L306 lis
    old "As your chakras are being cleansed."
    new "B:lis: Isso é bom, é o teu corpo a reagir à energia que flui dentro de ti."

    # say L337 ana
    old "This feels incredible!"
    new "A:ana: Sinto-me como se estivesse a ter um orgasmo, Lisa!"

    # say L338 ana
    old "I feel like I'm having an orgasm, Lisa!"
    new "B:ana: Isto é incrível!"

    # say L339 lis
    old "Good! Enjoy that feeling!"
    new "B:ana: Sinto-me como se estivesse a ter um orgasmo, Lisa!"

    # say L340 lis
    old "Let yourself fall deeply into it!"
    new "B:lis: Ótimo! Aproveita essa sensação!"

    # say L347 ana
    old "Oh gosh! I can't believe it!"
    new "B:lis: Deixa-te cair profundamente nisso!"

    # say L348 ana
    old "I actually had an orgasm that way."
    new "B:ana: Oh gosh! Não posso acreditar!"

    # say L349 lis
    old "Of course, your body reacted positively to your Mudhalara chakra coming into balance."
    new "B:ana: Eu realmente tive um orgasmo dessa forma."

    # say L350 lis
    old "That is the beauty of a tantric process."
    new "B:lis: Claro, o teu corpo reagiu positivamente ao teu chakra Mudhalara entrar em equilíbrio."

    # say L351 ana
    old "I have to say it was amazing!"
    new "B:lis: Essa é a beleza de um processo tântrico."

    # say L352 lis
    old "Haha, I'm glad you liked it."
    new "B:ana: Tive de dizer que foi incrível!"

    # say L353 lis
    old "I'll let you get up now."
    new "B:lis: Haha, fico contente que tenhas gostado."

    # say L361 ana
    old "Uhh, that was so good!"
    new "B:lis: Vou deixar-te levantar-te agora."

    # say L362 ana
    old "I loved it!"
    new "B:ana: Uhh, isso foi tão bom!"

    # say L363 lis
    old "I see that your connection with yourself and the balance of your chakras is improving."
    new "B:ana: Adorei!"

    # say L364 lis
    old "I think that with this we can move on to the next exercise."
    new "B:lis: Vejo que a tua conexão contigo mesmo e o equilíbrio dos teus chakras está a melhorar."

    # say L365 ana
    old "Great!"
    new "B:lis: Acho que com isto podemos passar para o próximo exercício."

    # say L387 lis
    old "Remember to focus on your breathing, Anastasia."
    new "T(lis|tu|diz): Lembra-te de te concentrar na tua respiração, Anastasia."

    # say L388 lis
    old "Feel the air going in and out of your body."
    new "B:lis: Lembra-te de te concentrar na tua respiração, Anastasia."

    # say L389 lis
    old "Let go of any thoughts or worries, allowing them to drift away with your breath."
    new "B:lis: Sente o ar a entrar e sair do teu corpo."

    # say L393 lis
    old "Continue to focus on this flow of energy, allowing it to move freely and naturally."
    new "B:lis: Deixa ir quaisquer pensamentos ou preocupações, permitindo que eles se dissipem com a tua respiração."

    # say L394 lis
    old "With each breath, feel more relaxed and centered."
    new "B:lis: Continua a focar-te nesta corrente de energia, permitindo que ela flua livremente e naturalmente."

    # say L395 lis
    old "Just breathe and let your energy flow in and out."
    new "B:lis: Com cada respiração, sente-te mais relaxada e centrada."

    # say L399 ana
    old "Mmm! This feels amazing, Lisa."
    new "B:lis: Só respira e deixa a tua energia fluir para dentro e para fora."

    # say L400 lis
    old "Yes! Focus on that sensation!"
    new "B:ana: Mmm! Isto é incrível, Lisa."

    # say L401 lis
    old "Let your body guide you in what you need!"
    new "B:lis: Sim! Concentra-te nessa sensação!"

    # say L424 ana
    old "I'm about to... Cum Lisa!"
    new "B:lis: Deixa o teu corpo guiar-te no que precisas!"

    # say L425 lis
    old "Yes! Yes! Let it all out!"
    new "B:ana: Estou prestes a... Gozar Lisa!"

    # say L426 lis
    old "Let everything flow out of you!"
    new "T(lis|tu|say): Deixa tudo fluir de ti!"

    # say L434 ana
    old "Oh that was so amazing!"
    new "B:lis: Deixa tudo fluir de ti!"

    # say L435 ana
    old "It felt so good!"
    new "B:ana: Oh, isso foi tão incrível!"

    # say L436 lis
    old "I'm glad you enjoyed it, that's your Mudhalara chakra coming into balance."
    new "B:ana: Sentiu-se tão bem!"

    # say L437 lis
    old "I belive we're on the right path."
    new "B:lis: Fico contente que tenhas gostado, é o teu chakra Mudhalara a entrar em equilíbrio."

    # say L438 lis
    old "But now, let's get up, so that [pla] can also rest a little."
    new "T(lis|tu|diz): Mas agora, levanta-te, para que [pla] também possa descansar um pouco."

    # say L451 lis
    old "Feel how far it goes inside you."
    new "B:lis: Relaxa, sente a profundidade da tua energia."

    # say L457 lis
    old "How deep inside you your energy goes?"
    new "B:lis: Sentes isso, Anastasia?"

    # say L458 lis
    old "Do you feel it flowing?"
    new "B:lis: Quão fundo dentro de ti a tua energia vai?"

    # say L459 ana
    old "Y-Yes I do."
    new "B:lis: Sentes o fluxo?"

    # say L460 ana
    old "I can feel it very deep inside me!"
    new "B:ana: S-Sim, eu sinto."

    # say L464 lis
    old "Do you feel your energy flowing inside, Anastasia?"
    new "B:ana: Eu sinto muito fundo dentro de mim!"

    # say L465 ana
    old "Oh yes! It's going so far inside me!"
    new "B:lis: Sentes a tua energia a fluir dentro de ti, Anastasia?"

    # say L491 lis
    old "Let it all out!"
    new "B:lis: Não! Deixa-te ir!"

    # say L499 lis
    old "How do you feel, Anastasia?"
    new "B:lis: Deixa tudo sair!"

    # say L500 ana
    old "I feel amazing!"
    new "B:lis: Como te sentes, Anastasia?"

    # say L501 lis
    old "Were you able to make an internal connection?"
    new "B:ana: Sinto-me incrível!"

    # say L502 ana
    old "I can feel it all inside me."
    new "B:lis: Conseguiste fazer uma conexão interna?"

    # say L503 lis
    old "Wonderful! That was the objective of this!"
    new "B:ana: Eu posso sentir tudo dentro de mim."

    # say L504 ana
    old "Now, time to get up and get cleaned up."
    new "Agora, é hora de te levantares e te arranjares."


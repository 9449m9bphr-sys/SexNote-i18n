# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Mechanics/Interface.rpy
translate portuguese strings:

    # say L7 pla
    old "I shouldn't, is weekend."
    new "Não devo, é fim de semana."

    # say L412 bri
    old "This is not what it looks like..."
    new "B:pla: Não devia, é fim de semana."

    # say L413 bri
    old "This is not a real bug... However it looks like you are using a really old file save..."
    new "B:bri: Isto não é o que parece..."

    # say L414 bri
    old "That's not bad, however as you can see this game has really improved since last months..."
    new "B:bri: Isto não é um erro real... No entanto, parece que estás a usar um ficheiro de salvamento muito antigo..."

    # say L415 bri
    old "And this version is only compatible with the two last updates 0.14.0 and 0.14.5."
    new "B:bri: Isso não é mau, no entanto, como podes ver, este jogo melhorou muito desde o mês passado..."

    # say L416 bri
    old "So, if you use an old save from old versions or an old save bugged it would probably cause bugs in this version..."
    new "B:bri: E esta versão só é compatível com as duas últimas actualizações 0.14.0 e 0.14.5."

    # say L417 bri
    old "And we don't want to ruin your experience... So, to avoid that, we suggest you try the 'Skip to new content' option."
    new "B:bri: Então, se usares uma save antiga de versões antigas ou uma save com bugs, isso provavelmente causará bugs nesta versão..."

    # say L418 bri
    old "So you can play a full version of the game with only the new content in this update."
    new "E não queremos estragar a tua experiência... Por isso, sugerimos que experimentes a opção 'Saltar para o novo conteúdo'."

    # say L419 bri
    old "You just have to play start, name your character and then click the 'Skip to new content' option!"
    new "B:bri: Assim podes jogar a versão completa do jogo com apenas o novo conteúdo desta atualização."

    # say L422 bri
    old "All right, that's it."
    new "B:bri: Eles podem dar-te todo o apoio de que precisas."

    # say L423 bri
    old "See you soon, here on Sexnote."
    new "T(bri|tu|say): Até breve, aqui no Sexnote."

    # say L713 pla
    old "I shouldn't go there right now."
    new "B:bri: Vemo-nos em breve, aqui no Sexnote."

    # say L731 pla
    old "It's too late... I shouldn't go there right now."
    new "T: É demasiado tarde... Não devo ir lá agora."

    # say L738 pla
    old "I'm already very tired, I should rest and continue tomorrow..."
    new "T(pla|tu|say): Estou já muito cansado, devo descansar e continuar amanhã..."


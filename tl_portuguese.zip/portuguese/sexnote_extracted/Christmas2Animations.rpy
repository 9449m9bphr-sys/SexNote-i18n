# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/Christmas2Animations.rpy
translate portuguese strings:

    # say L6 lyd
    old "God! Your cock's always so tasty!"
    new "T(lyd|tu|say): Meu Deus! O teu pénis está sempre tão delicioso!"

    # say L7 lyd
    old "Screw Christmas cookies, this is the treat I wanted!"
    new "B:lyd: Meu Deus! O teu pénis está sempre tão delicioso!"

    # say L8 lyd
    old "I bet this is the best way you've ever woken up!"
    new "B:lyd: Esquece os bolos de Natal, este é o presente que eu queria!"

    # say L12 lyd
    old "Oh yes! I love the way it feels in my mouth!"
    new "B:lyd: Aposto que esta é a melhor maneira de acordares!"

    # say L16 pla
    old "Y- yes!"
    new "T: Y- sim!"

    # say L20 lyd
    old "Oh! I love this!"
    new "B: pla: Y- sim!"

    # say L21 lyd
    old "Mmf! The taste!"
    new "Mmf! O sabor! Continua..."

    # menu L39 
    old "Keep going"
    new "B:lyd: Mmf! O sabor!"

    # say L44 pla
    old "Lydia! I- I think I'm about to cum!"
    new "T: Lydia! A- Acho que vou gozar!"

    # say L45 lyd
    old "Yes! Do it! Stuff my mouth with your hot cum!"
    new "B:pla: Lydia! A- Acho que vou gozar!"

    # say L52 lyd
    old "Merry Christmas to me!"
    new "B:lyd: Sim! Faz isso! Enche a minha boca com o teu esperma quente!"

    # say L54 pla
    old "What the hell are you talking about?!"
    new "T: Que raio estás a dizer?!"

    # say L55 pla
    old "You shouldn't just come into my room and do something like that!"
    new "T: Não deves entrar no meu quarto e fazer algo assim!"

    # say L56 pla
    old "What if somebody sees you?!"
    new "B:pla: Não deves entrar no meu quarto e fazer algo assim!"

    # say L57 lyd
    old "Oh! Relax! You're worrying too much."
    new "B:pla: E se alguém te vir?!"

    # say L58 lyd
    old "Nobody saw anything."
    new "B:lyd: Oh! Relaxa! Estás a preocupar-te demasiado."

    # say L59 lyd
    old "And I know you loved it."
    new "B:lyd: Ninguém viu nada."

    # say L60 pla
    old "Hmm, well..."
    new "Hmm, bem..."

    # say L61 pla
    old "Whatever."
    new "B:pla: Hmm, bem..."

    # say L73 sis
    old "Mmm! Oh my god! Your dick!"
    new "B:pla: Tanto faz."

    # say L74 sis
    old "It's great! I can feel its heat!"
    new "B:sis: Mmm! Oh meu Deus! O teu pénis!"

    # say L75 sis
    old "And also, it's sooo long!"
    new "B: Irmã: É incrível! Consigo sentir o seu calor!"

    # say L81 sis
    old "I know, right?"
    new "B:pla: É... é mesmo muito macio!"

    # say L82 sis
    old "It's really good quality!"
    new "Ah! Ah! Adoro isto!"

    # say L86 sis
    old "Ah! Ah! I love this!"
    new "B: Irmã: É mesmo de boa qualidade!"

    # say L87 sis
    old "I can feel your dick rubbing my clit!"
    new "B:sis: Ah! Ah! Adoro isto!"

    # say L88 sis
    old "And with this fabric, it feels so good!"
    new "B:sis: Sinto o teu pénis a esfregar-se na minha clitóris!"

    # say L113 sis
    old "Don't worry about the costume!"
    new "Não te preocupes com o fato! Este tecido é anti-líquido!"

    # say L114 sis
    old "This fabric is anti-fluid!"
    new "B: Irmã: Não te preocupes com o fato!"

    # say L115 sis
    old "Shoot it all out!"
    new "B: Irmã: Este tecido é anti-líquido!"

    # say L123 sis
    old "Oh my god! Look at all that thick load coming of your dick."
    new "Oh meu Deus! Olha toda essa carga grossa a sair do teu pénis."

    # say L124 pla
    old "... Right."
    new "B:sis: Ai meu Deus! Olha toda essa porra grossa a sair do teu pénis."

    # say L125 sis
    old "I just loved the way your dick rubbed againts my clit!"
    new "T(sis|tu|diz): Amei a forma como o teu pénis esfregava na minha boceta!"

    # say L126 sis
    old "It turned me on so much!"
    new "B: Irmã: Adorei a forma como o teu pénis esfregava na minha clítoris!"

    # say L127 sis
    old "Ok, I think these new outfits are ready to be posted!"
    new "B:sis: Isso excitou-me tanto!"

    # say L139 mo2
    old "Oh yes! This lube is perfect!"
    new "A:mo1: Olha como o teu pénis desliza entre os nossos peitos!"

    # say L140 mo1
    old "Just look at how your dick slides between our tits!"
    new "B:mo2: Oh sim! Este lubrificante é perfeito!"

    # say L141 lyd
    old "And it feels so hot!"
    new "B:mo1: Olha como o teu pénis desliza entre os nossos peitos!"

    # say L147 mo1
    old "That's great baby! I love that you love it!"
    new "B:pla: I- I faço! É ótimo!"

    # say L156 mo2
    old "Tell us!"
    new "A:pla: Eu- Eu adoro!"

    # say L157 pla
    old "I- I love it!"
    new "B:mo2: Conta-nos!"

    # say L181 pla
    old "I- I'm about to cum!"
    new "T: I- I'm about to cum!"

    # say L182 pla
    old "I can't hold it in anymore!"
    new "B:pla: I- I'm about to cum!"

    # say L183 mo1
    old "Do it honey!"
    new "B:pla: Não aguento mais!"

    # say L185 mo2
    old "Make it a white Christmas for us [pla]!"
    new "B:lyd: Sim! Faz isso [pla]! Goza por nós!"

    # say L194 mo1
    old "Oh that's just great! I love the way your cum tastes [pla]!"
    new "B:mo2: Faz um Natal branco para nós [pla]!"

    # say L208 sis
    old "It feels even bigger than the way it looks!"
    new "B: Irmã: Que grande estás tu!"

    # say L212 sis
    old "God! I love the way your dick feels me up!"
    new "B: Irmã: Sente-se ainda maior do que parece!"

    # say L213 sis
    old "It's so hot!"
    new "B:sis: Meu Deus! Adoro a forma como o teu pénis me excita!"

    # say L222 sis
    old "Oh my God! I love the way you fuck me!"
    new "B:sis: Este é o melhor presente de Natal alguma vez!"

    # say L258 sis
    old "Well, that was the best Christmas gift I think I could've asked for."
    new "B:sis: Porque é incrível o quão bom é!"

    # say L259 sis
    old "Even though I was such a naughty girl all year."
    new "A:mo2: Aposto que estavas à espera de me foder!"

    # say L274 mo2
    old "I bet you've been waiting to fuck me!"
    new "B:sis: Mesmo tendo sido uma menina tão má todo o ano."

    # say L275 mo2
    old "Well, you finally get your gift!"
    new "B:mo2: Aposto que estavas à espera de me foder!"

    # say L276 mo2
    old "My pussy's been aching for a hard big cock!"
    new "B:mo2: Bem, finalmente vais receber o teu presente!"

    # say L285 mo2
    old "Mmm! Oh yeah!"
    new "B:mo2: A minha xoxota tem estado com saudades de um pau grande e duro!"

    # say L286 mo2
    old "That's just the thing I wanted for Christmas!"
    new "Que grande!"

    # say L287 mo2
    old "So big!"
    new "B:mo2: Era exactamente isso que eu queria para o Natal!"

    # say L288 mo2
    old "The girth is just amazing!"
    new "B:mo2: Tão grande!"

    # say L292 mo2
    old "I bet you like this, don't you?"
    new "B:mo2: A grossura é incrível!"

    # say L293 mo2
    old "You like fucking me like an animal?"
    new "B:mo2: Aposto que gostas disto, não é?"

    # say L294 mo2
    old "Tell me!"
    new "B:mo2: Gostas de me foder como um animal?"

    # say L295 pla
    old "I- I do! I like it a lot!"
    new "B:mo2: Diz-me!"

    # say L296 mo2
    old "Oh- OH! You little bastard!"
    new "B:pla: I- I sim! Gosto muito!"

    # say L300 mo2
    old "You little pathetic slave! The only good thing about you is that long cock!"
    new "B:mo2: Oh- OH! Tu pequeno bastardo!"

    # say L301 mo2
    old "You hear me? You're worthless without it!"
    new "B:mo2: Tu pequeno escravo patético! A única coisa boa em ti é esse pau grande!"

    # say L302 mo2
    old "Your cock and balls are only good for this!"
    new "B:mo2: Tu ouves-me? Tu não vales nada sem isto!"

    # say L303 mo2
    old "Keep going! Keep fucking me! You worthless slave!"
    new "B:mo2: O teu pénis e os teus testículos só servem para isto!"

    # say L326 mo2
    old "I- AH! I can feel your cock twitching!"
    new "B:mo2: Continua! Continua a foder-me! Tu, escravo inútil!"

    # say L327 mo2
    old "Are you about to cum, you little pervert?!"
    new "B:mo2: I- AH! Sinto o teu pénis a tremer!"

    # say L328 pla
    old "I- ugh! I am!"
    new "B:mo2: Tu estás prestes a gozar, tu pequeno pervertido?!"

    # say L329 mo2
    old "Do it! Fill me with your worthless cum!"
    new "B:pla: I- ugh! Eu estou!"

    # say L354 pla
    old "Y-yeah, sure."
    new "Oh meu Deus, querido!"

    # say L363 mo1
    old "Oh my god, honey!"
    new "B: pla: H-hum, claro."

    # say L364 mo1
    old "Y- Your dick, is so big!"
    new "B:mo1: Oh meu Deus, querida!"

    # say L365 mo1
    old "It's so hot! So thick!"
    new "B:mo1: A-A tua pila é tão grande!"

    # say L369 mo1
    old "Oh my god I love it!"
    new "B:mo1: Está tão quente! Tão grosso!"

    # say L370 mo1
    old "I love to feel you filling me up!"
    new "B:mo1: Oh meu Deus, eu adoro!"

    # say L373 mo1
    old "Oh then keep going, honey!"
    new "B:pla: Eu faço! Eu gosto!"

    # say L377 mo1
    old "Oh yes! Yes! YES!"
    new "B:mo1: Oh, então continua, querida!"

    # say L403 mo1
    old "I- I think I'm coming!"
    new "B:mo1: É verdade! Este é o melhor Natal de sempre!"

    # say L406 pla
    old "Y- Yes!"
    new "B:mo1: L- Vamos fazer juntos!"

    # say L414 mo1
    old "Oh baby. That was the best Christmas gift ever!"
    new "B: pla: Y- Sim!"

    # say L415 mo1
    old "It's amazing, I'm so satisfied!"
    new "B:mo1: Oh querido. Foi o melhor presente de Natal de sempre!"

    # say L416 lyd
    old "Isn't he just a wonderful young man?"
    new "B:mo1: É incrível, estou tão satisfeito!"

    # say L417 mo1
    old "Your dick is so addicting!"
    new "B:lyd: Não é ele um jovem maravilhoso?"

    # say L432 lyd
    old "Well, I've been wanting to fuck you since the morning sweety!"
    new "B:mo1: O teu pénis é tão viciante!"

    # say L433 lyd
    old "I couldn't keep waiting!"
    new "B:lyd: Bem, tenho vontade de te foder desde a manhã, querida!"

    # say L442 lyd
    old "Oh! Uh! My God! It already feels amazing!"
    new "B:lyd: Não conseguia continuar à espera!"

    # say L443 lyd
    old "I- Mmm! I can't believe how big and hard you are!"
    new "B:lyd: Oh! Uh! Meu Deus! Isto já é incrível!"

    # say L444 lyd
    old "I- It's so amazing!"
    new "B:lyd: I- Mmm! Não posso acreditar no quanto és grande e duro!"

    # say L445 mo1
    old "It's incredible how much it fills you up, right?"
    new "B:lyd: I- É tão incrível!"

    # say L446 lyd
    old "It is!"
    new "B:mo1: É incrível como isso te enche, não é?"

    # say L450 lyd
    old "I- I love your cock!"
    new "B:lyd: É!"

    # say L451 mo2
    old "It seems you weren't a naughty girl this year Lydia."
    new "B:lyd: I- Eu adoro o teu pénis!"

    # say L452 mo2
    old "Because look at the gift Santa brought you!"
    new "B:mo2: Parece que não foste uma menina malvada este ano, Lydia."

    # say L453 lyd
    old "Y- Yes! I love it!"
    new "B:mo2: Porque olha o presente que o Pai Natal te trouxe!"

    # say L457 lyd
    old "YES! YES! YES!"
    new "T(lyd|tu|say): SIM! SIM! SIM!"

    # say L484 lyd
    old "I want you to do it!"
    new "B:lyd: Sinto que estás perto de gozar!"

    # say L485 lyd
    old "Fill me up with your hot cum!"
    new "B:lyd: Quero que tu faças isso!"

    # say L497 lyd
    old "You know, I think it would be easy to get addicted to it."
    new "B:lyd: O teu pénis está tão quente!"

    # say L498 pla
    old "I- I see."
    new "B:lyd: Sabes, acho que seria fácil ficar viciado nisso."


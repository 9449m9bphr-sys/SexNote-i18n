# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/ladAnimations.rpy
translate portuguese strings:

    # say L6 lad
    old "I'm stimulating your testicles while I masturbate you so I can get the maximum amount of semen out."
    new "A: Como estás? Estás a sentir-te bem?"

    # say L11 lad
    old "How is it? Do you feel ok?"
    new "B:lad: Estou a estimular os teus testículos enquanto te masturbo para conseguir o máximo de sêmen possível."

    # say L12 pla
    old "Y- yes ma'am"
    new "B:lad: Como está? Sentes-te bem?"

    # say L13 lad
    old "Just relax and let me do the job. I promise it won't feel bad."
    new "B: pla: S- sim, senhora"

    # say L17 pla
    old "O- ohhh! I- I think I'm getting close."
    new "B:lad: Relaxa e deixa-me fazer o trabalho. Prometo que não vai doer."

    # say L18 lad
    old "Yes! I can feel your body tensing up."
    new "B:pla: O- ohhh! A- Acho que estou a chegar perto."

    # say L19 lad
    old "Mmmm! It's so hard!"
    new "B:lad: Sim! Posso sentir o teu corpo a tensar-se."

    # say L42 pla
    old "Ma'am I-I think I'm cumming!"
    new "B:lad: Mmmm! É tão duro!"

    # say L43 lad
    old "Yes! I want you to!!"
    new "B:pla: Senhora, a-a-cho que vou gozar!"

    # say L44 lad
    old "Slurrp! That's it, let it all out!"
    new "B:lad: Sim! Quero que tu faças isso!"

    # say L50 lad
    old "That was impressive, you came a lot."
    new "B:lad: Slurrp! Isso mesmo, deixa tudo sair!"

    # say L51 lad
    old "This will really help me a lot. I'm already starting to feel it's effects."
    new "B:lad: Foi impressionante, tu foste muito."

    # say L52 pla
    old "Really? Already? Well, I'm happy it worked."
    new "B:lad: Isto vai realmente ajudar-me muito. Já estou a sentir os efeitos."

    # say L53 lad
    old "It really did. And I can't believe you came that much."
    new "B:pla: Mesmo? Já? Bem, fico contente que tenha funcionado."

    # say L54 lad
    old "Although we made a bit of a mess."
    new "B:lad: Foi mesmo. E não posso acreditar que tu tenhas vindo tanto."

    # say L55 pla
    old "Sorry, I sometimes can't control myself."
    new "B:lad: Embora tenhamos feito um pouco de confusão."

    # say L56 lad
    old "It's ok, you were helping me anyway. Just wait a second and I'll clean myself."
    new "B:pla: Desculpa, às vezes não consigo controlar-me."

    # say L65 pla
    old "Wow!"
    new "B:lad: Tudo bem, tu estavas a ajudar-me de qualquer maneira. Espera um segundo que eu me limpo."

    # say L66 lad
    old "Just relax and enjoy it."
    new "B:pla: Uau!"

    # say L67 pla
    old "Y- yes ma'am."
    new "B:lad: Só relaxa e aproveita."

    # say L71 lad
    old "Ahh! I-I feel like I'm getting better already"
    new "B: pla: S- sim, senhora."

    # say L73 lad
    old "Oh yes! Just like this..."
    new "A:lad: Continua! Não pares!"

    # say L74 lad
    old "Keep going! Don't stop!"
    new "B:lad: Oh sim! Assim mesmo..."

    # say L78 lad
    old "Yes! Yes! I can feel it!"
    new "A:lad: Isto é incrível! O teu pénis enche-me completamente!"

    # say L79 lad
    old "This is amazing! Your dick fills me up completely!"
    new "B:lad: Sim! Sim! Eu sinto!"

    # say L80 lad
    old "Ahhh! Ohhhh!"
    new "B:lad: Isto é incrível! O teu pénis enche-me completamente!"

    # say L103 lad
    old "Cum, now! I want to feel your cum fill me up."
    new "B:lad: Ahhh! Ohhhh!"

    # say L104 pla
    old "Y- yes! I'm about to!"
    new "B:lad: Goza, agora! Quero sentir o teu gozo a encher-me."

    # say L105 lad
    old "That's it! Yes!"
    new "B: pla: Y- sim! Estou quase!"

    # say L113 pla
    old "T- thank you Miss. I'm glad you liked it."
    new "B:lad: É fantástico!"

    # say L114 pla
    old "And I hope I was of help."
    new "B: pla: O- obrigado, senhora. Fico contente que tenha gostado."

    # say L115 lad
    old "Oh, I'm sure you were."
    new "B:pla: E espero ter sido útil."

    # say L116 lad
    old "You came a great amount. I have no doubt I'll feel better with this."
    new "B:lad: Oh, tenho a certeza que sim."

    # say L117 lad
    old "Now, we better get dressed, it's late and you have to go home."
    new "B:lad: Tu vieste em grande quantidade. Não tenho dúvidas de que me vou sentir melhor com isto."

    # say L118 pla
    old "Yes ma'am."
    new "B:lad: Agora, melhor vestirmo-nos, está tarde e tu tens de ir para casa."

    # say L130 lad
    old "Just relax. And Iet us do the work."
    new "B:pla: Sim, senhora."

    # say L131 lad
    old "We'll get you off in no time."
    new "B:lad: Relaxa. Deixa-nos fazer o trabalho."

    # say L139 dan
    old "Slurrp! Your dick... it's so warm, and it feels so nice in my mouth."
    new "B:lad: Mmm, e tem um sabor tão bom!"

    # say L140 bela
    old "I- it's so big..."
    new "B:dan: Slurrp! O teu pénis... está tão quente, e sente-se tão bem na minha boca."

    # say L144 bela
    old "Your dick it's so amazing! I can feel it throbbing!"
    new "B: bela: I- é tão grande..."

    # say L145 lad
    old "Yes! just like this! it's so nice!"
    new "B:bela: O teu pénis é tão incrível! Sinto-o a latejar!"

    # say L146 dan
    old "It's so long! And so thick!"
    new "B:lad: Sim! Assim mesmo! É tão bom!"

    # say L147 lad
    old "I can feel it, you're getting close!"
    new "B:dan: É tão grande! E tão grosso!"

    # say L170 pla
    old "I- I think I'm gonna...!"
    new "B:lad: Eu sinto, tu estás perto!"

    # say L171 bela
    old "Mmmm! Yes!"
    new "B:pla: A-Acho que vou...!"

    # say L172 lad
    old "It's ok, do it. Cum for us!"
    new "B:bela: Mmmm! Sim!"

    # say L179 bela
    old "Wow, Y- you're not tired? Amazing!"
    new "B:pla: Nem um pouco, estou a sentir-me muito bem... Sei que consigo continuar."

    # say L180 dan
    old "Incredible, I'd never met anybody that wouldn't feel tired after getting a blowjob from one of us. Let alone three!"
    new "B:bela: Wow, tu não estás cansado? Incrível!"

    # say L181 lad
    old "I told you, this young man is the key for us to get better."
    new "B:dan: Incrível, nunca tinha encontrado ninguém que não se sentisse cansado depois de receber uma boquete de uma de nós. Quanto mais três!"

    # say L182 lad
    old "And we're just getting started."
    new "A:lad: Meu Deus! Olha para isto, tu acabaste de chegar e o teu pénis ainda está super duro."

    # say L194 lad
    old "My god! Look at this, you just came, and yet your cock is still rock hard."
    new "B:lad: E estamos só a começar."

    # say L195 lad
    old "Amazing!"
    new "A:dan: Anda depressa, mãe, acho que estás a querer."

    # say L196 dan
    old "Hurry up mother, I think you're wanting it."
    new "B:lad: Incrível!"

    # say L197 lad
    old "Mmm, I am darling, I am."
    new "B:dan: Anda mãe, acho que tu estás a querer."

    # say L209 lad
    old "Mmm! It fills me up completely!"
    new "B:lad: Uhhh... O teu pénis... É tão grande!"

    # say L210 bela
    old "Wow mother, he really is deep into you!"
    new "B:lad: Mmm! Enche-me completamente!"

    # say L214 bela
    old "Mmm, I can see you're enjoying it a lot!"
    new "B:bela: Wow mãe, ele realmente está bem dentro de ti!"

    # say L215 lad
    old "Ahh! Yes dear, It would be... Ahh! Impossible not to."
    new "B:bela: Mmm, vejo que estás a gostar muito!"

    # say L216 lad
    old "Oh yeah, just like this..."
    new "B:lad: Ahh! Sim, querido, seria... Ahh! Impossível não o fazer."

    # say L220 lad
    old "Ohh! Oh my god!"
    new "B:lad: Oh sim, assim mesmo..."

    # say L221 lad
    old "Ah, it feels so good!"
    new "B:lad: Ohh! Ai deus!"

    # say L222 lad
    old "Ahhh! I- I'm close! I can feel it!"
    new "B:lad: Ah, sente-se tão bem!"

    # say L223 pla
    old "Uhhhhh!"
    new "A:pla: M- M-madame! Acho que vou gozar!"

    # say L246 pla
    old "M- Ma'am! I think I'm cumming!"
    new "B:pla: Uhhhhh!"

    # say L247 lad
    old "Ah! Do it! I want you to! Cum!"
    new "B:pla: M- Senhora! Acho que vou gozar!"

    # say L253 lad
    old "My god! That was impressive, you came so much."
    new "B:lad: Ah! Faz! Quero que tu faças! Ejacula!"

    # say L255 pla
    old "Phew, glad I can help."
    new "B:lad: Meu Deus! Isso foi impressionante, tu veio tanto."

    # say L256 lad
    old "But you know, I shouldn't keep you for myself..."
    new "B:pla: Ufa, que bom que posso ajudar."

    # say L257 lad
    old "It's your turn Daniela..."
    new "B:lad: Mas sabes, não devo ficar contigo só para mim..."

    # say L270 dan
    old "I hope you're not tired from being with mother, because I've been waiting for this."
    new "B:lad: É a tua vez, Daniela..."

    # say L272 lad
    old "Daniela darling, I know our health is a little compromised."
    new "B:dan: Espero que não estejas cansado por ter estado com a mãe, porque eu tenho estado à espera disto."

    # say L273 lad
    old "But there's no need to pressure him that much."
    new "B:lad: Daniela querida, sei que a nossa saúde está um pouco comprometida."

    # say L274 bela
    old "Haha, I don't think she meant it that way mother."
    new "B:lad: Mas não é preciso pressioná-lo tanto."

    # say L287 dan
    old "Ok, here we go."
    new "B:bela: Haha, não acho que ela tenha querido dizer isso assim, mãe."

    # say L288 dan
    old "Mmm! This cock, it's reaching all the way!"
    new "B:dan: Ok, aqui vamos nós."

    # say L289 bela
    old "Uhh, it looks amazing!"
    new "B:dan: Mmm! Este pénis, está a chegar bem fundo!"

    # say L290 dan
    old "And it is! Mmm! So good."
    new "B:bela: Uhh, parece incrível!"

    # say L296 bela
    old "Heh, Daniela is enjoying it too mother."
    new "B:pla: Mmm... S- sim, senhora."

    # say L297 dan
    old "I- It's so thick, and I feel so warm inside."
    new "B:bela: Heh, a Daniela também está a gostar, mãe."

    # say L303 dan
    old "Yes! Yes! Like that! Pound me more!"
    new "B:dan: Oh, Oh deus!"

    # say L304 pla
    old "Mmm, Ahhh!"
    new "B:dan: Sim! Sim! Assim! Entra mais forte!"

    # say L328 dan
    old "I can feel it! Your body it's tensing up!"
    new "B:pla: Mmm, Ahhh!"

    # say L330 dan
    old "Yes! Cum! Cum inside me!"
    new "B:dan: Eu sinto! O teu corpo está a tensar-se!"

    # say L336 dan
    old "Wow, that was amazing."
    new "B:dan: Sim! Ejacula! Ejacula dentro de mim!"

    # say L337 bela
    old "Look how much you came. I can't believe it."
    new "B:dan: Uau, isso foi incrível."

    # say L338 lad
    old "You never cease to surprise me [pla]."
    new "T: Tu nunca dejas de surpreender-me [pla]."

    # say L351 bela
    old "Be gentle with me, ok?"
    new "B:bela: Acho que é a minha vez agora, mãe."

    # say L352 bela
    old "I don't like it as rough as my sister."
    new "B:bela: Sê suave comigo, ok?"

    # say L363 bela
    old "That's it, slowly. Mmm."
    new "B:bela: Não gosto que seja tão bruto como a minha irmã."

    # say L364 bela
    old "Ah! I can feel how you stretch me."
    new "B:bela: É isso, devagar. Mmm."

    # say L365 dan
    old "Yes sister, I felt it too. It's unbelievable."
    new "B:bela: Ah! Posso sentir como me esticaste."

    # say L366 bela
    old "Y- You can do it, a little harder"
    new "B:dan: Sim, irmã, eu também senti. É incrível."

    # say L370 dan
    old "You like that big cock sis?"
    new "B:bela: Y- Tu consegues, um pouco mais forte."

    # say L371 bela
    old "Ohh, yes, yes, just like that."
    new "B:dan: Gostas desse pénis grande, mana?"

    # say L372 lad
    old "That's it Bela, enjoy it darling."
    new "B:bela: Ohh, sim, sim, assim mesmo."

    # say L373 bela
    old "P- please, go a little faster."
    new "B:lad: É isso, Bela, aproveita querida."

    # say L377 bela
    old "Ah, Ahh, Ahhh!"
    new "B: bela: P- por favor, vai um pouco mais rápido."

    # say L378 bela
    old "I- It's soooo fucking big!"
    new "B:bela: Ah, Ahh, Ahhh!"

    # say L379 bela
    old "It's warming me up inside!"
    new "B:bela: I- É tão grande!"

    # say L403 bela
    old "Yes! Me too!"
    new "B:bela: Está a aquecer-me por dentro!"

    # say L404 pla
    old "Ughhh!"
    new "Incrível, tu tens uma resistência incrível."

    # say L409 lad
    old "Amazing, you have such amazing endurance."
    new "B:pla: Ughhh!"

    # say L410 dan
    old "And he still hard... "
    new "B:lad: Incrível, tu tens uma resistência fantástica."

    # say L411 lad
    old "Hmm, do you think you could give us a little bit more?"
    new "B:dan: E ainda está duro..."

    # say L426 lad
    old "You managed to do it with all three of us."
    new "B: T- Obrigado, senhora."

    # say L427 lad
    old "I think we can give you a little extra."
    new "B:lad: Conseguiste fazê-lo connosco os três."

    # say L437 dan
    old "God! your cock still so hard."
    new "B:lad: Acho que podemos dar-te um pouco extra."

    # say L438 lad
    old "I can see you still have some left in the tank. Give it to us."
    new "B:dan: Meu Deus! O teu pénis ainda está tão duro."

    # say L442 pla
    old "Ah... Ahh!"
    new "B:lad: Posso ver que ainda tens alguma energia. Dá-nos isso."

    # say L443 bela
    old "I love how big you are."
    new "B:pla: Ah... Ahh!"

    # say L444 lad
    old "It's got such a nice smell."
    new "B:bela: Adoro o tamanho que tens."

    # say L445 dan
    old "Let's do it a faster mother."
    new "B:lad: Tem um cheiro tão bom."

    # say L449 lad
    old "Yes! That's it! I love seeing you enjoy it."
    new "B:dan: Vamos mais rápido, mãe."

    # say L450 bela
    old "It's so warm, and it's getting harder."
    new "B:lad: Sim! É isso aí! Adoro ver-te a gostar."

    # say L451 bela
    old "I think he's about to cum."
    new "B:bela: Está tão quente, e está a ficar mais difícil."

    # say L474 pla
    old "I- I think I'm cumming!"
    new "B:bela: Acho que ele está prestes a gozar."

    # say L475 lad
    old "Yes! Let it all out! Cum all over us!"
    new "B:pla: A-Acho que vou gozar!"

    # say L482 dan
    old "Wow, that was really intense."
    new "B:lad: Sim! Deixa tudo sair! Goza em cima de nós!"

    # say L483 pla
    old "Yes, it was. I think I'm finally feeling a little tired."
    new "B:dan: Uau, isso foi realmente intenso."

    # say L489 dan
    old "Hah! Just now? I did it only once with you, and I'm already tired!"
    new "B:pla: Sim, foi. Acho que finalmente estou um pouco cansado."

    # say L492 lad
    old "And you did. Right girls?"
    new "B:pla: Bem, não diria que não sinto. Mas queria ajudar."

    # say L493 bela
    old "Yes, you really are a lifesaver."
    new "B:lad: E tu fizeste. Certo, raparigas?"

    # say L494 dan
    old "That's right, this is great for us."
    new "B:bela: Sim, tu realmente és um salvador."

    # say L495 pla
    old "Thank you very much."
    new "B:dan: É verdade, isto é ótimo para nós."

    # say L514 bela
    old "I feel amazing, that was so good, and I feel myself getting better already!"
    new "B:lad: Como estão a sentir-se as raparigas?"

    # say L515 dan
    old "Yeah, me too. The amount of cum we were able to take is amazing."
    new "B:bela: Sinto-me incrível, isso foi tão bom, e sinto-me a melhorar já!"

    # say L516 pla
    old "I'm happy I can be of help to you all."
    new "B:dan: Sim, eu também. A quantidade de esperma que conseguimos receber é incrível."

    # say L517 pla
    old "I think I should probably go home and rest."
    new "B:pla: Fico feliz por poder ajudar-vos."

    # say L518 lad
    old "That's fine. But before you leave, allow us to thank you once again for everything you've done for us."
    new "B:pla: Acho que devo ir para casa e descansar."

    # say L520 dan
    old "Thank you [pla], please come soon again."
    new "B: bela: T- isso mesmo [pla], muito obrigado."

    # say L522 lad
    old "Aww, you're an angel. Thank you so much."
    new "Obrigado, tu és um anjo. Muito obrigado."


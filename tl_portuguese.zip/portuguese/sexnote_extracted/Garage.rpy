# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Garage.rpy
translate portuguese strings:

    # say L23 pla
    old "Hello. I just came to know if you need more magic power?"
    new "Olá. Apenas vim saber se precisas de mais poder mágico?"

    # say L25 mil
    old "I think I have enough. Thank you..."
    new "B:pla: Olá. Apenas vim saber se precisas de mais poder mágico?"

    # say L27 pla
    old "Oh come on. In our deal you were supposed to receive magical power from me, so don't worry."
    new "B:mil: Acho que já tenho o suficiente. Obrigada..."

    # say L29 mil
    old "Hmm, okay, I'll visit you tonight to get a little more magic."
    new "B:pla: Oh, vai lá. No nosso acordo, tu ias receber poder mágico de mim, então não te preocupes."

    # say L31 pla
    old "Great, it's good for us to help each other..."
    new "B:mil: Hmm, okay, vou visitar-te esta noite para ter um pouco mais de magia."

    # say L33 mil
    old "Ok, see you tonight."
    new "B:pla: Ótimo, é bom para nós ajudarmos uns aos outros..."

    # menu L43 
    old "Ask for Magic Power"
    new "T(n|tu|menu): Pedir Poder Mágico"

    # say L45 pla
    old "Hello! I wanted to know if you have any magic power to share with me. You know, to keep improving my skills..."
    new "Olá! Queria saber se tens algum poder mágico para partilhar comigo. Sabes, para continuar a melhorar as minhas habilidades..."

    # say L49 mil
    old "Well, if you really need it I have some magic power for you."
    new "B:pla: Olá! Quisera saber se tens algum poder mágico para partilhar comigo. Sabes, para continuar a melhorar as minhas capacidades..."

    # say L51 pla
    old "Thank you. I really appreciate it."
    new "B:mil: Bem, se realmente precisas, tenho algum poder mágico para ti."

    # say L53 mil
    old "Don't mention it. This was part of our deal"
    new "B:pla: Obrigado. Aprecio muito."

    # say L57 mil
    old "Ok, I'm ready. Let's do it."
    new "B:mil: Não há de quê. Isso fazia parte do nosso acordo."

    # say L59 pla
    old "Alright, alright..."
    new "T: Tudo bem, tudo bem..."

    # say L68 mil
    old "Sorry, but I don't have enough to share for now..."
    new "B:pla: Tudo bem, tudo bem..."

    # say L70 pla
    old "Oh ok. No problem. I will come later."
    new "B:mil: Desculpa, mas não tenho o suficiente para partilhar agora..."

    # say L72 mil
    old "Bye."
    new "B:pla: Oh, ok. Sem problemas. Vou passar mais tarde."

    # say L96 pla
    old "Oh come on. In our deal you were supposed to get magical power from me, I'll take care of you."
    new "T: Oh, vai lá. No nosso acordo, tu ias ganhar poder mágico de mim, eu ia cuidar de ti."

    # say L98 gom
    old "Mmm, okay. I'll visit you tonight to get a little more magic."
    new "B:pla: Oh, vamos lá. No nosso acordo, tu ias receber poder mágico de mim, eu ia cuidar de ti."

    # say L100 pla
    old "Great,I like helping you..."
    new "B:gom: Mmm, okay. Vou visitar-te esta noite para ter um pouco mais de magia."

    # say L114 pla
    old "Hello! I wanted to know if you have any magic power to share with me You know, to keep improving my skills..."
    new "B: pla: Ótimo, gosto de te ajudar..."

    # say L118 gom
    old "Yes I have some magic power to give you."
    new "B:pla: Olá! Queria saber se tens algum poder mágico para partilhar comigo. Sabes, para continuar a melhorar as minhas habilidades..."

    # say L120 pla
    old "Oh, sweet. Thank you!"
    new "B:gom: Sim, tenho alguns poderes mágicos para te dar."

    # say L122 gom
    old "No problem, your progress benefits us all"
    new "B:pla: Oh, doce. Obrigado!"

    # say L126 gom
    old "Are you ready?."
    new "B: gom: Sem problemas, o teu progresso beneficia todos nós."

    # say L128 pla
    old "Yes! Let's get to it..."
    new "B:gom: Estás pronto?"

    # say L140 pla
    old "Oh, ok. No worries. I will come later."
    new "B: pla: Sim! Vamos a isso..."

    # say L142 gom
    old "Buh bye."
    new "B:pla: Oh, ok. Sem problemas. Vou passar mais tarde."

    # say L163 pla
    old "Hi there, I just came to know if you need more magic power?"
    new "Bem, talvez eu precise de um pouco..."

    # say L165 dev
    old "Well, maybe I might need a little..."
    new "B:pla: Olá, acabei de saber se precisas de mais poder mágico?"

    # say L167 pla
    old "Great, in that case visit me tonight so I can give you some magical power..."
    new "B:dev: Bem, talvez eu precise de um pouco..."

    # say L169 dev
    old "With pleasure! I'll see you tonight..."
    new "B:pla: Ótimo, então passa por cá esta noite para eu te dar alguns poderes mágicos..."

    # say L181 pla
    old "Hey! I wanted to know if you have any magic power to share with me. I want to keep improving my skills..."
    new "B:dev: Com prazer! Vejo-te esta noite..."

    # say L184 dev
    old "Of course! I have plenty to share with you."
    new "B:pla: Ei! Queria saber se tens algum poder mágico para partilhar comigo. Quero continuar a melhorar as minhas habilidades..."

    # say L188 dev
    old "You can ask me whenever you want. Whenever I have enough I will give it to you..."
    new "B:dev: Claro! Tenho muito para partilhar contigo."

    # say L190 pla
    old "Nice! Thank you."
    new "Hmmm... Infelizmente, não tenho o suficiente agora..."

    # say L198 dev
    old "Hmmm... Unfortunately, I don't have enough right now..."
    new "B:pla: Nice! Obrigado."

    # say L200 dev
    old "However, look for me in a couple of days and I will have accumulated more to give you..."
    new "B:dev: Hmmm... Infelizmente, não tenho o suficiente agora..."

    # say L202 dev
    old "Or... You could also share with me and I'll give it back to you, just for the fun of sharing... Hehe"
    new "B:dev: No entanto, procura-me daqui a uns dias e terei acumulado mais para te dar..."

    # say L204 pla
    old "Oh, don't worry, it's really nothing urgent."
    new "B:dev: Ou... Poderias também partilhar comigo e eu devolvo-te, só pelo prazer de partilhar... Hehe"

    # say L206 dev
    old "Oh... Ok then."
    new "B:pla: Oh, não te preocupes, não é nada urgente."

    # menu L226 
    old "Magic Power"
    new "O que é a Magia?"

    # menu L230 
    old "What is the Magic Power?"
    new "B:n: Poder Mágico"

    # say L232 bri
    old "Well, Magical power is an energy that was produced naturally in the magical world..."
    new "B:n: Qual é a Poder Mágico?"

    # say L234 bri
    old "After its destruction all that magical energy ended up in the human world, the problem is that now it does not reproduce anymore..."
    new "B:bri: Bem, a Energia Mágica é uma energia que se produzia naturalmente no mundo mágico..."

    # say L236 bri
    old "Only the remains of great magical sources, and all magical beings that once existed will be extinguished forever..."
    new "B:bri: Depois da sua destruição, toda essa energia mágica acabou no mundo humano, o problema é que agora ela não se reproduz mais..."

    # say L238 pla
    old "Ok, I understand it better now."
    new "T(pla|tu|say): Ok, agora entendo melhor."

    # say L240 bri
    old "Great! What else do you want to know?"
    new "Como obter Poder Mágico?"

    # menu L247 
    old "How to get Magic Power?"
    new "Tens de facto 4 formas..."

    # say L249 bri
    old "You have in fact 4 ways..."
    new "T(bri|tu|say): Tens na verdade 4 formas..."

    # say L250 bri
    old "1. Picking up in each place with the agamoto's eye."
    new "B:bri: Tu tens, de facto, 4 opções..."

    # say L251 bri
    old "2. Using Ayax's hand and automatically picking up when moving between locations."
    new "1. Recolher em cada lugar com o olho do agamoto."

    # say L252 bri
    old "3. Having high levels of arousal caused by sexual activity with women."
    new "B:bri: 2. Usando a mão do Ayax e apanhando automaticamente ao mudar de local."

    # say L253 bri
    old "4. Ask me to share you with my magical power!"
    new "3. Ter altos níveis de excitação causados por atividade sexual com mulheres."

    # say L255 pla
    old "Ok, interesting..."
    new "Ok, interessante... A minha favorita é a última, mas só se tu também partilhares a tua comigo..."

    # say L257 bri
    old "My favorite is the last one, but only when you share with me yours too..."
    new "B:pla: Ok, interessante..."

    # say L259 pla
    old "Yes, I know..."
    new "B:bri: A minha favorita é a última, mas só quando tu partilhas a tua comigo..."

    # say L261 bri
    old "Well, What else do you want to know?"
    new "B:pla: Sim, eu sei..."

    # menu L272 
    old "Spells"
    new "B:bri: Bem, o que mais queres saber?"

    # menu L276 
    old "Agamoto's Eye"
    new "Agamoto era um dos magos mais poderosos que se especializava em poderes oculares."

    # say L278 bri
    old "Agamoto was one of the most powerful magicians who specialized in ocular power."
    new "B:n: O Olho de Agamoto"

    # say L280 bri
    old "They say that his power even came to see the soul and thoughts of any being."
    new "B:bri: Agamoto era um dos magos mais poderosos que se especializava em poder ocular."

    # say L282 bri
    old "That is why Agamoto is a power of vision that allows you to see the dimension of the magical world and see beyond the objects of the real world."
    new "B:bri: Dizem que o seu poder até consegue ver a alma e os pensamentos de qualquer ser."

    # say L284 pla
    old "Wow Really?"
    new "T: Uau, mesmo?"

    # say L286 bri
    old "Yes, you should try it, you could only see through easy things like clothes, try using it on someone to see through their clothes."
    new "B:pla: Uau, a sério?"

    # say L288 pla
    old "Ok ok, I'm going to try it..."
    new "B:bri: Sim, deves experimentar, só consegues ver através de coisas simples como roupa, tenta usá-lo em alguém para ver através da roupa."

    # menu L297 
    old "Ayax's Hand"
    new "B:pla: Ok ok, vou tentar..."

    # say L299 bri
    old "Ayax was one of the greatest thief magicians in history."
    new "T(bri|tu|say): Ayax foi um dos maiores magos ladrões da história."

    # say L301 bri
    old "He reached the point of being able to turn his body into a magnet for valuables."
    new "B:bri: Ayax foi um dos maiores magos ladrões da história."

    # say L303 bri
    old "Ayax's hand is basically this power that he achieved, with which you can automatically attract the magical power of the area where you are."
    new "B:bri: Ele chegou ao ponto de ser capaz de transformar o seu corpo num imã para objetos de valor."

    # say L306 pla
    old "Wow, interesting..."
    new "B:bri: A mão do Ayax é basicamente este poder que ele alcançou, com o qual podes atrair automaticamente a energia mágica da área onde estás."

    # say L308 bri
    old "What else do you want to know?"
    new "Que mais queres saber?"

    # menu L316 
    old "Sauron's Mouth"
    new "B:bri: O que mais queres saber?"

    # say L318 bri
    old "Sauron was one of the greatest political influencers in the magical world."
    new "T(tu|diz): Sauron foi um dos maiores influenciadores políticos no mundo mágico."

    # say L320 bri
    old "He managed to create a manipulative skill with his mouth with which he managed to influence everyone."
    new "B:bri: Sauron foi um dos maiores influenciadores políticos no mundo mágico."

    # say L322 bri
    old "This is how the Sauron's Mouth was created, with it you can influence all kinds of beings..."
    new "B:bri: Conseguiu criar uma habilidade manipulativa com a boca que lhe permitiu influenciar todos."

    # say L324 pla
    old "Like some kind of mind control?"
    new "B:bri: Foi assim que a Boca de Sauron foi criada, com ela podes influenciar todo o tipo de seres..."

    # say L326 bri
    old "What? Of course not, it is more an ability to influence or manipulate at certain levels, not to control the behavior."
    new "B:pla: Como se fosse algum tipo de controlo mental?"

    # say L328 bri
    old "In fact, using it does not always work and you should improve it to the fullest and have a good relationship with who you use to increase your chances..."
    new "B:bri: O quê? Claro que não, é mais uma capacidade de influenciar ou manipular em certos níveis, não de controlar o comportamento."

    # say L330 pla
    old "Ok, ok, understood."
    new "B:bri: Na verdade, usar isso nem sempre funciona e deves melhorá-lo ao máximo e ter uma boa relação com quem usas para aumentar as tuas hipóteses..."

    # menu L339 
    old "Jamliz's Heart"
    new "B:pla: Ok, ok, entendido."

    # say L341 bri
    old "Jamliz sought for years to make a very powerful spell that he never achieved, since he always needed more magical power."
    new "B:n: O Coração de Jamliz"

    # say L343 bri
    old "But, what he achieved was to increase the ability to store magical power in unthinkable amounts."
    new "B:bri: Jamliz procurou durante anos criar um feitiço muito poderoso que nunca conseguiu, pois sempre precisava de mais poder mágico."

    # say L345 bri
    old "That's why the Jamliz's Heart is a skill that allows you to store more magical power in your body and thus make spells that require greater magical power."
    new "B:bri: Mas, o que ele conseguiu foi aumentar a capacidade de armazenar poder mágico em quantidades inimagináveis."

    # say L347 pla
    old "Sounds pretty useful..."
    new "O que tenho de fazer?"

    # menu L361 
    old "What I have to do?"
    new "B:pla: Parece bastante útil..."

    # say L363 bri
    old "The first thing you should do is improve your skills to the fullest. So obviously, you must get magical power."
    new "B:n: O que tenho de fazer?"

    # say L365 bri
    old "But your main mission is to restore the magical world and with this shortage of magical power the only way is for you to generate it for yourself..."
    new "B:bri: A primeira coisa que deves fazer é melhorar as tuas habilidades ao máximo. Então, obviamente, deves obter poder mágico."

    # say L367 bri
    old "So you should seek to reach the highest level of sexual arousal. Experimenting with different women and situations to see what is most exciting for you..."
    new "B:bri: Mas a tua missão principal é restaurar o mundo mágico, e com esta escassez de poder mágico, a única forma é tu gerares esse poder para ti mesmo..."

    # say L369 bri
    old "And have a lot of sex with many women to increase your power and gradually restore the power of the magical world!"
    new "B:bri: Deves procurar atingir o nível mais alto de excitação sexual. Experimenta com diferentes mulheres e situações para ver o que é mais excitante para ti..."

    # say L371 pla
    old "You do know that is not that easy, right?"
    new "T(pla|tu|say): Tu sabes que isso não é assim tão fácil, certo?"

    # say L373 bri
    old "Don't worry. You can gradually acquire more skills that you can use in the real world to make things easier for you..."
    new "T(bri|tu|say): Não te preocupes. Podes adquirir gradualmente mais habilidades que podes usar no mundo real para facilitar as coisas para ti..."

    # say L375 bri
    old "For now you can progress little by little with some women and see if you can get very horny!"
    new "B:bri: Não te preocupes. Podes gradualmente adquirir mais competências que podes usar no mundo real para facilitar as coisas para ti..."

    # say L377 pla
    old "Hmmm... Ok, I'll see how to do something about it."
    new "B:bri: Por agora podes avançar pouco a pouco com algumas mulheres e ver se consegues ficar muito excitado!"

    # say L416 pla
    old "I finally found you!"
    new "B:pla: Hmmm... Ok, verei como fazer algo a respeito."

    # say L423 dev
    old "WHAT DO YOU WANT FROM US?"
    new "B:pla: Finalmente te encontrei!"

    # say L425 pla
    old "I just want to talk..."
    new "Onde está o teu amigo shinigami?"

    # say L428 gom
    old "Where is your shinigami friend?"
    new "B:pla: Eu só quero conversar..."

    # say L430 pla
    old "She is not here, I came alone... I just want to clarify that everything was a misunderstanding..."
    new "Ela não está aqui, vim sozinho... Só quero esclarecer que tudo foi um mal-entendido... Não destruí o mundo mágico..."

    # say L432 pla
    old "I did not destroy the magical world..."
    new "B:pla: Ela não está aqui, vim sozinho... Só quero esclarecer que tudo foi um mal-entendido..."

    # say L434 mil
    old "We know that, you didn't destroy the magical world..."
    new "T(mil|tu|say): Sabemos disso, tu não destruíste o mundo mágico..."

    # say L436 pla
    old "That's right!, I didn't..."
    new "B:mil: Sabemos disso, tu não destruíste o mundo mágico..."

    # say L440 pla
    old "What? No... I think you are confused "
    new "B:pla: Tens razão!, Eu não..."

    # say L442 mil
    old "Kid, we are over 300 years old, and you how many? 18? We know all from the magical and human world. "
    new "B:pla: O quê? Não... Acho que estás confuso..."

    # say L444 pla
    old "But... Brixxida knows nothing about the destruction of the magical world..."
    new "B:mil: Rapaz, nós temos mais de 300 anos, e tu quantos? 18? Nós conhecemos tudo sobre o mundo mágico e o humano."

    # say L446 gom
    old "Doesn't know or doesn't want to tell you? Why do you think she needs you? "
    new "T(gom|tu|say): Não sabe ou não quer contar? Por que tu achas que ela precisa de ti?"

    # say L448 pla
    old "To restore the magical world?"
    new "B:gom: Não sabe ou não quer dizer? Por que tu achas que ela precisa de ti?"

    # say L450 dev
    old "And if she wants to restore the magical world why is she alone? Why there are no more shinigamis with her, like us? "
    new "B:pla: Para restaurar o mundo mágico?"

    # say L452 pla
    old "Well, I don't know..."
    new "B:dev: E se ela quer restaurar o mundo mágico, por que está sozinha? Por que não há mais shinigamis com ela, como nós?"

    # say L454 mil
    old "Who you have by your side is probably one of the most powerful being in the universe and you don't know her real intentions, you must be very careful..."
    new "B:pla: Bem, eu não sei..."

    # say L456 pla
    old "But she has only helped me..."
    new "B:mil: Quem tens ao teu lado é provavelmente uma das entidades mais poderosas do universo e não sabes quais são as suas intenções reais, deves ter muito cuidado..."

    # say L458 dev
    old "We don't know what she may want from you... But she was who destroy the magic world..."
    new "T(dev|tu|say): Não sabemos o que ela pode querer de ti... Mas foi ela quem destruiu o mundo mágico..."

    # say L460 pla
    old "And how do I know that it is not you who want to deceive me?"
    new "B:dev: Não sabemos o que ela pode querer de ti... Mas foi ela quem destruiu o mundo mágico..."

    # say L462 mil
    old "You don't have to believe us, we're not asking you anything, just let us try to survive, that's all..."
    new "B:pla: E como é que eu sei que não és tu quem quer enganar-me?"

    # say L464 pla
    old "Ok, I want to propose something to you, I will be in charge of sharing magical power to all of you."
    new "B:mil: Não tens de acreditar em nós, não te estamos a pedir nada, só nos deixa tentar sobreviver, é tudo..."

    # say L466 pla
    old "I mean, you can come and collect magic power from me so you won't disappear..."
    new "B:pla: Ok, quero propor algo a ti, eu ficarei responsável por partilhar poder mágico com todos vocês."

    # say L470 mil
    old "Thank you, but we don't need it..."
    new "B:pla: Quero dizer, podes vir e recolher poder mágico de mim para não desapareceres..."

    # say L472 pla
    old "Oh come on, I have the SexNote, I have several skills that have allowed me to collect magical power quickly and efficiently."
    new "B:mil: Obrigado, mas não precisamos disso..."

    # say L474 pla
    old "And... I can also generate magical power by myself..."
    new "B:pla: Oh, vamos lá, tenho o SexNote, tenho várias habilidades que me permitiram recolher poder mágico rapidamente e eficientemente."

    # say L476 pla
    old "And you have less and less magical power left..."
    new "E tu também consegues gerar poder mágico por ti mesmo... E tu tens menos e menos poder mágico... O que queres em troca?"

    # say L478 gom
    old "What do you want in return?"
    new "B:pla: E tu tens menos e menos poder mágico..."

    # say L480 pla
    old "Nothing, I just want to help in whatever I can..."
    new "A:mil: Vais continuar a recolher poder mágico de toda a área?"

    # say L482 mil
    old "Will you still collect magical power from the whole area?"
    new "B:pla: Nada, só quero ajudar no que puder..."

    # say L484 pla
    old "Well, with Ayax's Hand I automatically gather the magical power where I move..."
    new "B:mil: Vais continuar a recolher poder mágico de toda a área?"

    # say L486 pla
    old "But that's why whenever you need it you can go at night and suck up magical power from me..."
    new "B:pla: Bem, com a Mão de Ayax, eu recolho automaticamente o poder mágico onde me movo..."

    # say L488 dev
    old "Hmmm... Okay, but we'll just take what is necessary..."
    new "B:pla: Mas é por isso que sempre que precisares podes ir à noite e sugar poder mágico de mim..."

    # say L490 mil
    old "And we will return what we do not need, so you can look for us to receive magic power that we don't need..."
    new "B:dev: Hmm... Ok, mas vamos levar apenas o que é necessário..."

    # say L492 gom
    old "It really suits us that you rebuild the sources of magic power production..."
    new "B:mil: E devolveremos o que não precisamos, para que tu possas procurar-nos para receber a energia mágica que não precisamos..."

    # say L494 mil
    old "And that's why we will help you, so you you can find out about Brixxida's true intentions, and we will help you gather the magic power that remains."
    new "B:gom: A nós convém que tu reconstruas as fontes de produção de poder mágico..."

    # say L496 pla
    old "Okay, I'll go as far as I can and find out if Brixxida really has bad intentions or not..."
    new "B:mil: E por isso vamos ajudar-te a descobrir as verdadeiras intenções de Brixxida, e a recolher o poder mágico que resta."

    # say L498 gom
    old "You must be careful, she is much smarter and more powerful than she seems..."
    new "B:pla: Ok, vou até onde puder e descubro se Brixxida realmente tem más intenções ou não..."

    # say L500 dev
    old "You must act without raising suspicion..."
    new "B: gom: Tens de ter cuidado, ela é muito mais inteligente e poderosa do que parece..."

    # say L502 mil
    old "And above all be careful that she does not find out about our deal..."
    new "T(mil|tu|say): E acima de tudo, cuida para que ela não descubra o nosso acordo..."

    # say L504 pla
    old "Okay, I'll keep that in mind... But then, where will I find all of you?"
    new "T: Ok, vou ter isso em mente... Mas então, onde vou encontrar vocês?"

    # say L506 mil
    old "I will continue in the school zone..."
    new "B:pla: Okay, eu vou lembrar... Mas então, onde vais encontrar-vos todas?"

    # say L508 gom
    old "I'll be in the house, where you found me..."
    new "B:mil: Vou continuar na zona escolar..."

    # say L510 dev
    old "And you will find me here, that's how we split this little town..."
    new "B: gom: Vou estar em casa, onde me encontraste..."

    # say L512 pla
    old "Perfect, if you need to collect more magical power, you know where to find me..."
    new "B:dev: E vais encontrar-me aqui, é assim que dividimos esta pequena cidade..."

    # say L514 mil
    old "Okay... I think it's all for now, so we will be leaving..."
    new "B:pla: Perfeito, se precisares de recolher mais poder mágico, sabes onde me encontrar..."

    # say L525 dev
    old "after all, I have collected the most magical power from you and have not returned any of it to you..."
    new "B:dev: Espera! antes de ires, quero começar o nosso acordo..."

    # say L527 pla
    old "No, no, it is not necessary..."
    new "B:dev: afinal, recolhi todo o poder mágico de ti e ainda não te devolvi nada..."

    # say L532 dev
    old "I see it as a way to close the deal and you have already received magical power from all but me..."
    new "B:pla: Não, não, não é necessário..."

    # say L534 pla
    old "Hmm... alright, If it's fine for you."
    new "Hmm... bem, se está tudo bem para ti."


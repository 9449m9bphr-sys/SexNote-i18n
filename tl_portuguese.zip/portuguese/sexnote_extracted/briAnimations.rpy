# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/briAnimations.rpy
translate portuguese strings:

    # say L6 bri
    old "Holy shit! You really have a big cock!"
    new "T(bri|tu|say): Santo Deus! Tu realmente tens um pén grande!"

    # say L7 bri
    old "That makes it even better to share my power with you!"
    new "B:bri: Santo Deus! Tu realmente tens um pén grande!"

    # say L11 bri
    old "Do you feel how your body receive my magical power within you?"
    new "B:bri: Isso torna ainda melhor partilhar o meu poder contigo!"

    # say L12 pla
    old "Ah?... Yes, yes... That's what I'm feeling..."
    new "B:bri: Sentes como o teu corpo recebe a minha energia mágica dentro de ti?"

    # say L16 bri
    old "Let's do it faster so you get more power!"
    new "B:pla: Ah?... Sim, sim... É isso que estou a sentir..."

    # say L17 pla
    old "Oh! Wow..."
    new "B:bri: Vamos mais rápido para tu ganhares mais poder!"

    # say L45 bri
    old "Do you feel it? Do you feel all the power within me?"
    new "B:pla: Oh! Wow..."

    # say L46 pla
    old "Yes, yes... I actually think I'm going to..."
    new "B:bri: Sentes isso? Sentes todo o poder dentro de mim?"

    # say L51 bri
    old "Well that is enough for now..."
    new "B:pla: Sim, sim... Acho que vou..."

    # say L52 bri
    old "Now you have more magic power."
    new "B:bri: Bem, isso é o suficiente por agora..."

    # say L59 bri
    old "If you need more just let me collect some magic power for a couple of days..."
    new "B:bri: Agora tens mais poder mágico."

    # say L61 bri
    old "Or you could share more with me for me to give you back just for fun."
    new "B:bri: Se precisares de mais, deixa-me recolher um pouco de poder mágico durante uns dias..."

    # say L63 pla
    old "Actually that's a good idea, I'll keep that in mind..."
    new "B:bri: Ou podes partilhar mais comigo para eu te retribuir só por diversão."

    # say L65 pla
    old "Great..."
    new "A:bri: Uhh, é definitivamente enorme!"

    # say L86 bri
    old "Uhh, it's definitely huge!"
    new "B:pla: Ótimo..."

    # say L87 bri
    old "You'll be definitely be one of the best Sexnote owners..."
    new "B:bri: Uhh, é definitivamente enorme!"

    # say L91 bri
    old "Ohh yeah, just like that! Oh gosh it feels amazing!"
    new "B:bri: Vais ser definitivamente uma das melhores donas do Sexnote..."

    # say L92 bri
    old "Mmm, are you enjoying the magic transfer?"
    new "Mmm, estás a gostar da transferência mágica?"

    # say L96 bri
    old "I want more! Give me all you have!"
    new "B:bri: Mmm, estás a gostar da transferência mágica?"

    # say L98 bri
    old "Oh yeah, don't stop, don't stop! Get all my power!"
    new "B:bri: Quero mais! Dá-me tudo o que tens!"

    # say L122 pla
    old "I- I cumming!"
    new "B:bri: Oh yeah, não pares, não pares! Dá-me toda a tua energia!"

    # say L123 bri
    old "Ohhh yesss!"
    new "B:pla: I- I estou a gozar!"

    # say L125 bri
    old "Phew! That was AWESOME!"
    new "T(bri|tu|say): Ufa! Isso foi ESPECTACULAR!"

    # say L126 bri
    old "I really missed this."
    new "B:bri: Ufa! Isso foi INCREDÍVEL!"

    # say L169 pla
    old "Oh fuck... I'm going to..."
    new "B:bri: Senti tanto a tua falta."

    # say L176 bri
    old "I love to do this..."
    new "B:pla: Oh fuck... Vou..."

    # say L177 pla
    old "Did you get good magic power?"
    new "B:bri: Adoro fazer isto..."

    # say L178 bri
    old "Yes, but you can always give me more if you want..."
    new "B:pla: Conseguiste boa energia mágica?"

    # say L179 pla
    old "Not now, I Need to use it to improve my skills first."
    new "B:bri: Sim, mas podes sempre dar-me mais se quiseres..."

    # say L180 bri
    old "You are right..."
    new "B:pla: Agora não, preciso usá-lo para melhorar as minhas habilidades primeiro."

    # say L184 bri
    old "By the way, I could help you too when you get an boner."
    new "T(bri|tu|say): Aliás, também posso ajudar-te quando tiveres uma ereção."

    # say L186 pla
    old "Now that you mention it, I have a question... If I ever get to do something like this with a woman... Will I lose magical power?"
    new "A:bri: Para fazer o quê, ter alguma atividade sexual?"

    # say L188 bri
    old "To do what, have some sexual activity?"
    new "T(bri|tu|say): Para fazer o quê, ter alguma atividade sexual?"

    # say L190 pla
    old "Ehh... Well, yes..."
    new "B:bri: Para quê, ter alguma atividade sexual?"

    # say L192 bri
    old "Don't worry! In fact, you should do it. "
    new "B:pla: Ehh... Bem, sim..."

    # say L194 pla
    old "What do you mean?"
    new "B:bri: Não te preocupes! Na verdade, deves fazê-lo."

    # say L196 bri
    old "Humans have a very particular phenomenon, when they have some high sexual excitation they generate magical power..."
    new "B: pla: O que queres dizer com isso?"

    # say L198 bri
    old "That magic power usually disappear quickly because there is nobody enabled to store that energy..."
    new "B:bri: Os humanos têm um fenómeno muito particular, quando estão muito excitados sexualmente, geram poder mágico..."

    # say L200 bri
    old "But you can, so, any kind of sexual activity will help you generate magical power and the more intense or higher sexual excitation the more magical power you will receive..."
    new "B:bri: Esse poder mágico costuma desaparecer rapidamente porque não há ninguém capaz de armazenar essa energia..."

    # say L202 bri
    old "That is why within your objectives as a chosen, you must have a lot of sex, only then can you restore the magical world and regenerate the sources of magical power..."
    new "B:bri: Mas podes, então, qualquer tipo de atividade sexual irá ajudar-te a gerar poder mágico e quanto mais intensa ou elevada for a excitação sexual, mais poder mágico receberás..."

    # say L204 pla
    old "What the Fuck? You didn't tell me that..."
    new "B:bri: É por isso que, nos teus objetivos como escolhido, deves ter muito sexo, só assim podes restaurar o mundo mágico e regenerar as fontes de poder mágico..."

    # say L206 bri
    old "I'm telling you right now... It's that there are many things and I don't remember them all..."
    new "A:pla: Então tenho de ter muito sexo para receber poder mágico?"

    # say L208 pla
    old "So I have to have a lot of sex to receive magical power?"
    new "B:bri: Estou a dizer-te já... É que há muitas coisas e eu não me lembro de todas..."

    # say L210 bri
    old "Actually, You must seek to reach the maximum of sexual arousal, so you must experiment a lot to see what is the most exciting for you..."
    new "B:pla: Então tenho de ter muito sexo para receber poder mágico?"

    # say L212 pla
    old "Hmmm... Ok, I'll see how to do something about it"
    new "B:bri: Na verdade, deves procurar atingir o máximo de excitação sexual, por isso deves experimentar muito para ver o que é mais excitante para ti..."

    # say L234 pla
    old "It was great..."
    new "B:pla: Hmmm... Ok, vou ver como fazer algo a respeito."

    # say L235 bri
    old "Yes, it was really fun... I want to do it again."
    new "T(bri|tu|say): Sim, foi mesmo divertido... Quero fazer de novo."

    # say L236 pla
    old "Maybe later when I get more Magic Power..."
    new "B:bri: Sim, foi mesmo divertido... Quero fazer de novo."

    # say L257 bri
    old "It's very important that you relax."
    new "B:bri: Deixa-te disfrutar disto."

    # say L268 bri
    old "I've always thought this [pla]! But as a human, your cock is very impressive!"
    new "T(bri|tu|say): Eu sempre pensei nisso [pla]! Mas como humano, o teu pénis é muito impressionante!"

    # say L292 pla
    old "I- I feel like I'm about to cum Brixxida!"
    new "B:bri: É incrível que esteja tão duro!"

    # say L293 bri
    old "Yeah! That's good! Do it!"
    new "B:pla: I- I sinto que vou gozar, Brixxida!"

    # say L294 bri
    old "Cum! I want you to shoot everything into the portal!"
    new "B:bri: Sim! Isso é ótimo! Faz isso!"

    # say L301 bri
    old "Look at that! I can already tell that the portal is starting to charge!"
    new "T(bri|tu|say): Olha para isso! Já consigo ver que o portal está a carregar!"


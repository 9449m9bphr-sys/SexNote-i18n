# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/belAnimations.rpy
translate portuguese strings:

    # say L12 bil
    old "Ugh! That's really a big dick... Have you seen one like that before Belle?"
    new "B:pla: Ohh yeah, sente-se mesmo bem."

    # say L13 bel
    old "N- no, I had never seen a cock this big."
    new "B:bil: Ugh! É mesmo um pénis grande... Já tinhas visto um assim antes, Belle?"

    # say L14 bil
    old "He seems to like it like that, keep going."
    new "B:bel: N- não, nunca tinha visto um pénis tão grande."

    # say L18 bil
    old "Keep going Belle! Don't stop."
    new "B:bil: Parece que ele gosta assim, continua."

    # say L20 pla
    old "Mmmm... Y- yeah."
    new "Mmmm... S-sim."

    # say L21 bel
    old "It's soo hard in my hand, right now!"
    new "B:pla: Mmmm... S-sim."

    # say L44 pla
    old "I-I think I'm cuming!"
    new "B:bel: Está tão duro na minha mão, neste momento!"

    # say L45 bel
    old "Uhh?"
    new "B:pla: A-Acho que vou gozar!"

    # say L54 bel
    old "Ughh... You gotta be more careful [pla], I'm all covered with cum now."
    new "T(bel|tu|say): Ughh... Tens de ter mais cuidado [pla], agora estou todo coberto de sêmen."

    # say L56 bil
    old "Hah! What's the matter Belle?"
    new "B:pla: S- sorry, não consegui evitar."

    # say L57 bil
    old "Aren't you happy you gave him a good time."
    new "B:bil: Hah! Que se passa, Belle?"

    # say L58 bel
    old "Phew, yeah right! As if I wanted this sticky thing on me."
    new "B:bil: Não estás feliz por lhe teres dado um bom momento?"

    # say L59 bel
    old "Wait a minute, I'll clean myself."
    new "B:bel: Pois, claro! Como se quisesse esta coisa pegajosa em mim."

    # say L71 sis2
    old "Oh! Oh my gosh!"
    new "B:bel: Espera um momento, vou limpar-me."

    # say L72 sis2
    old "This cock!"
    new "Oh! Oh meu Deus!"

    # say L73 sis2
    old "It's so good!"
    new "B:sis2: Este pénis!"

    # say L77 sis2
    old "I love how deep into my throat it's going!"
    new "B:sis2: É tão bom!"

    # say L78 sis2
    old "Oh! Yeah! Do you guys like this?"
    new "B:sis2: Adoro como está a entrar fundo na minha garganta!"

    # say L79 sis2
    old "Seeing this huge cock fill my mouth up?!"
    new "B:sis2: Oh! Sim! Vocês gostam disto?"

    # say L83 sis2
    old "Yes! Yes! Yes!"
    new "B:sis2: Ver este pénis enorme a encher-me a boca?!"

    # say L84 sis2
    old "Oh my gosh this is the best taste ever!"
    new "B:sis2: Sim! Sim! Sim!"

    # say L85 sis2
    old "I can't get enough of this taste!"
    new "Oh meu Deus, este é o melhor sabor de sempre! Não me canso deste sabor! Oh meu Deus!"

    # say L108 sis2
    old "Oh my gosh!"
    new "B:sis2: Não consigo me fartar deste sabor!"

    # say L109 sis2
    old "He's about to fill my mouth with his cum!"
    new "B:sis2: Ai meu Deus!"

    # say L110 sis2
    old "Do you want to see it?"
    new "B:sis2: Ele está prestes a encher a minha boca com o seu esperma!"

    # say L117 sis2
    old "That was fantastic guys!"
    new "B:sis2: Queres ver?"

    # say L118 sis2
    old "And it's all thanks to your tips!"
    new "B:sis2: Isso foi fantástico, pessoal!"

    # say L119 sis2
    old "If you want to see me getting fucked in the future remember to subscribe to premium and keep tipping."
    new "E claro, junta-te ao meu clube de fãs para poderes descarregar o vídeo desta transmissão."

    # say L120 sis2
    old "And of course, join my fan club so you can download the video of this streaming."
    new "B:sis2: Se quiseres ver-me a ser fodida no futuro, lembra-te de subscrever o premium e de continuar a dar gorjetas."

    # say L132 bel
    old "What great dick this is"
    new "B:sis2: E claro, junta-te ao meu clube de fãs para poderes descarregar o vídeo desta transmissão."

    # say L133 bel
    old "I love the way it feels in my hand!"
    new "B: bel: Que pénis tão grande!"

    # say L134 bel
    old "It's so big and so nice!"
    new "B:bel: Adoro a sensação que me dá na mão!"

    # say L138 bel
    old "Do you like how I stroke it?"
    new "B:bel: É tão grande e tão bom!"

    # say L139 bel
    old "Do you like how I grab your big dick in my hand?"
    new "B: bel: Gostas de como eu te acaricio?"

    # say L140 bel
    old "It's such a nice big cock!"
    new "B: bel: Gostas de como agarro o teu grande pénis na mão?"

    # say L144 bel
    old "Oh my god!"
    new "B:bel: Que pénis tão grande e bonito!"

    # say L146 bel
    old "So big and hot!"
    new "B:bel: Meu Deus!"

    # say L169 bel
    old "I can feel you're about to cum!"
    new "B:bel: Tão grande e quente!"

    # say L170 bel
    old "Your dick is twitching so hard in my hand!"
    new "B:bel: Sinto que vais gozar!"

    # say L171 bel
    old "Come! I want you to see you do it!"
    new "B: bel: O teu pénis está a tremer tanto na minha mão!"

    # say L177 bel
    old "That was sooo good!"
    new "B:bel: Vem! Quero ver-te a fazê-lo!"

    # say L178 bel
    old "But that's not all we're doing today guys!"
    new "B:bel: Isso foi tão bom!"

    # say L179 bel
    old "Why don't I show you what I have next for you?"
    new "B:bel: Mas isso não é tudo o que vamos fazer hoje, pessoal!"

    # say L194 bel
    old "Mmm! The taste of this big cock!"
    new "B:bel: Porque não te mostro o que tenho a seguir para ti?"

    # say L195 bel
    old "It's so hot and thick!"
    new "B:bel: Mmm! O sabor deste pénis grande!"

    # say L196 bel
    old "You guys wanted this, didn't you?"
    new "B:bel: Está tão quente e grosso!"

    # say L206 bel
    old "Do you like how I stuff my mouth with your dick?"
    new "B:bel: Vocês queriam isto, não era?"

    # say L207 bel
    old "I love it!"
    new "B: bel: Gostas de como encho a minha boca com o teu pénis?"

    # say L211 bel
    old "I love how you're filling my mouth with your big cock!!"
    new "T(bel|tu|say): Adoro como estás a encher a minha boca com o teu pau grande!!"

    # say L212 bel
    old "I can't get enough of it!"
    new "B:bel: Adoro como estás a encher a minha boca com o teu pau grande!!"

    # say L213 bel
    old "I love how it tastes!"
    new "B:bel: Não consigo parar!"

    # say L217 bel
    old "My god! This taste is so good!"
    new "B: bel: Adoro o sabor!"

    # say L218 bel
    old "I love how you're ravishing my mouth!"
    new "B:bel: Meu Deus! Este sabor é tão bom!"

    # say L219 bel
    old "I can't get enough of your dick guys!"
    new "B:bel: Adoro como estás a devorar a minha boca!"

    # say L242 bel
    old "You guys want to cum in my mouth?"
    new "B:bel: Não consigo me fartar do vosso pau, rapazes!"

    # say L244 bel
    old "I want you to fill my throat with your hot load!"
    new "B:bel: Vocês querem gozar na minha boca?"

    # say L250 bel
    old "That was so good guys!"
    new "B: bel: Quero que enchas a minha garganta com o teu carregamento quente!"

    # say L251 bel
    old "This cum is so good!"
    new "B:bel: Foi tão bom, pessoal!"

    # say L252 bel
    old "It's just the best taste in the world!"
    new "B: bel: Este sêmen é tão bom!"

    # say L273 bel
    old "Mmm! oh my god! I can never get enough of this dick!"
    new "B:bel: É simplesmente o melhor sabor do mundo!"

    # say L274 bel
    old "This has to be the most amazing dick in the world!"
    new "B:bel: Mmm! oh meu deus! Nunca me canso disto!"

    # say L275 bel
    old "I love how much it's filling my mouth!"
    new "B:bel: Isto tem que ser o pénis mais incrível do mundo!"

    # say L281 bel
    old "Do you guys like seeing me like this? Who would want to have me right in front of you like this?"
    new "B:bel: Adoro como está a encher-me toda a boca!"

    # say L282 bel
    old "Do you like the way this cock is filling in my entire mouth?!"
    new "B: bel: Gostam de me ver assim? Quem é que queria ter-me à frente assim?"

    # say L283 bel
    old "Oh yes! I can feel it pushing all the way to my throat!"
    new "B: bel: Gostas da maneira como este pénis está a encher toda a minha boca?!"

    # say L290 bel
    old "Mmm! Oh my god guys look at this!"
    new "B:bel: Oh sim! Posso sentir tudo a empurrar até à minha garganta!"

    # say L291 bel
    old "This cock is just as hard as it was a minute ago!"
    new "B:bel: Mmm! Oh meu Deus, olhem para isto!"

    # say L292 bel
    old "My god! It's so good!"
    new "B:bel: Esta pila está tão dura como estava há um minuto!"

    # say L293 bel
    old "It doesn't matter what happens, it's always so great!!"
    new "B:bel: Meu Deus! É tão bom!"

    # say L294 bel
    old "I- Slrrp! I bet you guys like this don't you?"
    new "B:bel: Não importa o que aconteça, é sempre tão bom!!"

    # say L295 bel
    old "I- Mmm! I love it!"
    new "B:bel: I- Slrrp! Aposto que vocês gostam disto, não é?"

    # say L300 bel
    old "OH! Yes! This cock tastes so great!"
    new "B:bel: I- Mmm! Adoro!"

    # say L301 bel
    old "Slrrrp! Mmmm! I can't get enough of it!"
    new "B:bel: OH! Sim! Este pénis tem um sabor tão bom!"

    # say L302 bel
    old "Oh God I love the way you're fucking my mouth!"
    new "B:bel: Slrrrp! Mmmm! Não me canso disto!"

    # say L326 bel
    old "Oh god! I can feel you getting tense!"
    new "B:bel: Oh Deus, adoro a forma como estás a foder a minha boca!"

    # say L327 bel
    old "You're about to cum, right guys?!"
    new "B:bel: Oh meu Deus! Posso sentir-te a ficar tenso!"

    # say L328 bel
    old "Do it! Don't hold it back!"
    new "B:bel: Tu estás prestes a gozar, certo, rapazes?!"

    # say L329 bel
    old "Throw your cum in my throat!"
    new "B: bel: Faz isso! Não te contenhas!"

    # say L336 bel
    old "I'm so happy you liked it too!"
    new "B: bel: Atira o teu esperma na minha garganta!"

    # say L337 bel
    old "Especially because we've managed to get to the goal!"
    new "B:bel: Estou tão feliz que tu também gostaste!"

    # say L338 bel
    old "So now we can go ahead and I can show you!"
    new "B:bel: Especialmente porque conseguimos atingir o objetivo!"

    # say L339 bel
    old "Just give me a couple of minutes, we're going to get ready for what comes next."
    new "B:bel: Agora podemos continuar e eu posso mostrar-te!"

    # say L340 bel
    old "Don't go anywhere because I know you're going to love it!"
    new "B:bel: Dá-me só uns minutos, vamos preparar-nos para o que vem a seguir."

    # say L349 bel
    old "Oh! Yeah!"
    new "B:bel: Não vais a lado nenhum porque sei que vais adorar!"

    # say L350 bel
    old "The feeling in my throath is so great!"
    new "B:bel: Oh! Sim!"

    # say L355 bel
    old "I like it so much!"
    new "B: bel: A sensação na minha garganta é tão intensa!"

    # say L356 bel
    old "Do you like to see me sucking cock guys?!"
    new "B:bel: Gosto tanto disto!"

    # say L361 bel
    old "Oh, yeah! Yeah!"
    new "B: bel: Gostas de ver-me a chupar caras?!"

    # say L362 bel
    old "Oh my god! This is so good!"
    new "B: bel: Oh, sim! Sim!"

    # say L363 bel
    old "I can't imagine a better tasting dick than this!"
    new "B:bel: Oh meu Deus! Isto é tão bom!"

    # say L386 bel
    old "Oh yeah!"
    new "B:bel: Não consigo imaginar um pénis melhor a gosto do que este!"

    # say L387 bel
    old "I can feel your dick twitching."
    new "B:bel: Oh yeah!"

    # say L388 bel
    old "I know you're about to come!"
    new "B:bel: Sinto o teu pénis a tremer."

    # say L389 bel
    old "Do it guys! Cum in my mouth!"
    new "B:bel: Eu sei que tu estás prestes a gozar!"

    # say L394 bel
    old "That was lovely guys!"
    new "B: bel: Fazam isso, rapazes! Ejaculem na minha boca!"

    # say L395 bel
    old "But we're not stopping here!"
    new "B:bel: Foi ótimo, pessoal!"

    # say L396 bel
    old "Let's get to what you really want to see!"
    new "B:bel: Mas não vamos parar aqui!"

    # say L410 bel
    old "Hngh!"
    new "B:bel: Vamos ao que tu realmente queres ver!"

    # say L411 bel
    old "Oh god! This is so amazing!"
    new "B:bel: Hngh!"

    # say L412 bel
    old "My god! This sensation is so good!"
    new "T(bel|tu|say): Meu Deus! Esta sensação é tão boa!"

    # say L421 bel
    old "Oh my god! Oh my god!"
    new "T(bel|tu|say): Oh meu Deus! Oh meu Deus!"

    # say L423 bel
    old "I love the way you're making me feel!"
    new "B:bel: Oh meu Deus! Oh meu Deus!"

    # say L427 bel
    old "I can't get enough of this dick!"
    new "B:bel: Adoro a forma como me estás a fazer sentir!"

    # say L428 bel
    old "My pussy feels so good!"
    new "B:bel: Não me canso deste pénis!"

    # say L429 bel
    old "This dick is so hot! It's so good!"
    new "B: bel: A minha xoxota sente-se tão bem!"

    # say L433 bel
    old "Ugh! Oh yes! yes!"
    new "B: bel: Este pénis está tão quente! É tão bom!"

    # say L434 bel
    old "I love the way this feels!"
    new "B:bel: Ugh! Oh sim! sim!"

    # say L436 bel
    old "My pussy feels so great!"
    new "B:bel: Adoro a sensação disto!"

    # say L459 bel
    old "I know you guys want to come inside of me!"
    new "B:bel: A minha xoxota sente-se tão bem!"

    # say L460 bel
    old "Do it! Fill my pussy again with your hot load!"
    new "B:bel: Eu sei que vocês querem entrar em mim!"

    # say L461 bel
    old "I want to feel that cum inside me!"
    new "B: bel: Faz isso! Enche a minha xoxota de novo com o teu caralho quente!"

    # say L468 bel
    old "I knew you would like it!"
    new "B:bel: Quero sentir esse esperma dentro de mim!"

    # say L480 bel
    old "Oh god!"
    new "B:bel: Eu sabia que tu ias gostar!"

    # say L481 bel
    old "This cock was so impressive before"
    new "B:bel: Oh deus!"

    # say L482 bel
    old "But now that I have it on my ass!"
    new "B:bel: Este pénis era tão impressionante antes"

    # say L483 bel
    old "It's even better!"
    new "B:bel: Mas agora que tenho na minha bunda!"

    # say L487 bel
    old "God! It's so good!"
    new "B:bel: É ainda melhor!"

    # say L488 bel
    old "I love how hard you're fucking my ass guys!"
    new "B:bel: Meu Deus! É tão bom!"

    # say L489 bel
    old "Mmm! Do you like the way you're stretching me?!"
    new "B:bel: Adoro como vocês estão a foder o meu cu!"

    # say L493 bel
    old "Oh! Oh! Yes!"
    new "B:bel: Mmm! Gostas da maneira como estás a alongar-me?!"

    # say L494 bel
    old "Yes! Keep fucking me like that!"
    new "B:bel: Oh! Oh! Sim!"

    # say L495 bel
    old "I love the way it's filling me!"
    new "B:bel: Sim! Continua a foder-me assim!"

    # say L496 bel
    old "It's just stretching my ass!"
    new "B:bel: Adoro a forma como me está a encher!"

    # say L519 bel
    old "OH yes! I can feel it!"
    new "B:bel: É só esticar o meu cu!"

    # say L520 bel
    old "You're about to cum aren't you?"
    new "B:bel: OH sim! Eu sinto!"

    # say L521 bel
    old "Do it! Cum!"
    new "B:bel: Tu estás prestes a gozar, não é?"

    # say L522 bel
    old "Fill my ass with your hot cum!"
    new "B:bel: Faz isso! Goza!"

    # say L529 bel
    old "That was so awesome guys!"
    new "B: bel: Enche o meu cu com o teu sémen quente!"

    # say L530 bel
    old "I knew you guys would do great today!"
    new "B:bel: Foi tão incrível, pessoal!"

    # say L531 bel
    old "And you didn't disappoint!"
    new "A:amo: Slrrp! Oh meu Deus!"

    # say L543 amo
    old "Slrrp! Oh my god!"
    new "B:bel: E tu não desiludiste!"

    # say L544 amo
    old "What a great taste this dick has!"
    new "B:amo: Slrrp! Oh meu Deus!"

    # say L545 amo
    old "Mmm! It feels so amazing in my mouth!"
    new "B:amo: Que sabor delicioso este pénis tem!"

    # say L549 bel
    old "Do you like seeing us taste dick guys?"
    new "B:amo: Mmm! É tão incrível na minha boca!"

    # say L550 bel
    old "It's so amazing to lick it!"
    new "B:bel: Gostas de ver-nos a lamber os caras?"

    # say L551 bel
    old "I love how hot it is!"
    new "B:bel: É tão incrível lamber!"

    # say L555 amo
    old "Slrrp! Mmmm!"
    new "A: amo: Este pénis está tão duro!"

    # say L556 amo
    old "This dick is so hard!"
    new "B: amo: Slrrp! Mmmm!"

    # say L557 amo
    old "And the taste! So amazing!"
    new "B: amo: Este pénis está tão duro!"

    # say L580 bel
    old "I can feel this dick twitching!"
    new "B:amo: E o sabor! Tão incrível!"

    # say L581 bel
    old "You want to see him cum because of our tongues don't you?!"
    new "B:bel: Sinto este pén a tremer!"

    # say L582 amo
    old "Oh yes! I want to see that!"
    new "B:bel: Queres ver ele a gozar por causa das nossas línguas, não é?!"

    # say L589 bel
    old "Oh my God guys! You're amazing!"
    new "B:amo: Oh sim! Quero ver isso!"

    # say L590 bel
    old "You actually did it!"
    new "B:bel: Meus Deus, pessoal! Vocês são incríveis!"

    # say L591 bel
    old "You reached the goal!"
    new "B:bel: Tu realmente o fizeste!"

    # say L592 bel
    old "And you know what that means."
    new "B:bel: Conseguiu o objetivo!"

    # say L594 amo
    old "This is what I was waiting for!"
    new "B:bel: E sabes o que isso significa."

    # say L608 amo
    old "Mmm! Oh God yes! This is what I had been waiting for!"
    new "B:amo: Isto é o que eu estava à espera!"

    # say L609 amo
    old "What an amazing cock!"
    new "B:amo: Mmm! Oh Deus sim! Isto é o que eu estava à espera!"

    # say L620 amo
    old "I love the way it feels!"
    new "A:bel: Gostas de como ele está a foder com ela, rapazes?"

    # say L624 bel
    old "Do you like how he's fucking her guys?"
    new "B:amo: Adoro a sensação!"

    # say L625 bel
    old "It's amazing isn't it?"
    new "B: bel: Tu gostas de como ele está a foder com ela, pessoal?"

    # say L626 amo
    old "Oh my God! This cock is so amazing!"
    new "B:bel: É incrível, não é?"

    # say L630 amo
    old "Oh God! Oh yes!"
    new "B:amo: Oh meu Deus! Este pénis é incrível!"

    # say L631 amo
    old "Yes! Yes! Keep stretching my pussy!"
    new "B:amo: Oh Deus! Oh sim!"

    # say L632 amo
    old "What a great cock! It's so hard! And so big!"
    new "B:amo: Sim! Sim! Continua a dilatar a minha vagina!"

    # say L655 amo
    old "I- Ah! I can feel his dick twitching!"
    new "B:amo: Que pénis incrível! Está tão duro! E tão grande!"

    # say L656 bel
    old "Are you about to cum?! Do it!"
    new "B:amo: Ah! Sinto o teu pénis a tremer!"

    # say L657 bel
    old "Fill her up with your cum!"
    new "B:bel: Tu vais gozar?! Faz isso!"

    # say L658 amo
    old "Yes! Oh yes! I want to feel it inside!"
    new "B:bel: Enche-a com o teu sêmen!"

    # say L665 amo
    old "That was wonderful guys!"
    new "B:amo: Sim! Oh sim! Quero senti-lo dentro de mim!"

    # say L666 amo
    old "I felt so amazing!"
    new "B:amo: Isso foi incrível, pessoal!"

    # say L667 amo
    old "To have my pussy stretched like that!"
    new "T: Ficar assim tão dilatada!"

    # say L668 amo
    old "But now it's time for Belle's turn."
    new "B:amo: Para ter a minha xoxota esticada assim!"

    # say L669 bel
    old "Alright! I was waiting for this too."
    new "B:amo: Mas agora é a vez da Belle."

    # say L682 amo
    old "Oh! That's fucking hot to see!"
    new "B:bel: Ótimo! Estava à espera disto também."

    # say L683 amo
    old "How does it feel Belle?"
    new "B:amo: Oh! É tão excitante de ver!"

    # say L692 bel
    old "Hmm! I love it!"
    new "B:amo: Como é que te sentes, Belle?"

    # say L693 bel
    old "I can never get enough of this dick!"
    new "B: bel: Hmm! Adoro isto!"

    # say L694 bel
    old "No matter how many times I have it!"
    new "B:bel: Nunca me canso deste pénis!"

    # say L698 amo
    old "God that's just so good to see!"
    new "A:amo: Olha como esse pén entra e sai da tua xoxota!"

    # say L699 amo
    old "Look at how that dick comes in and out of your pussy!"
    new "B:amo: Meu Deus, é tão bom ver isso!"

    # say L704 bel
    old "OH! OH! God!"
    new "B:amo: Olha como esse pén entra e sai da tua xoxota!"

    # say L705 bel
    old "This dick! Is so good!"
    new "B:bel: OH! OH! Deus!"

    # say L706 bel
    old "I love it! It's so hot!"
    new "B:bel: Esta pica! É tão boa!"

    # say L707 bel
    old "Do you like fucking me guys?"
    new "B:bel: Adoro! É tão excitante!"

    # say L730 bel
    old "I- Oh! I can feel his dick twitching!"
    new "B: bel: Gostas de me foder, rapazes?"

    # say L731 bel
    old "I feel it coming!"
    new "A:amo: Faz isso! Goza dentro dela! Enche a buceta dela!"

    # say L732 amo
    old "Do it! Cum inside her! Fill her pussy!"
    new "B:bel: Sinto que está a chegar!"

    # say L740 bel
    old "I'm so happy you reached the goal!"
    new "B:amo: Faz isso! Ejacula dentro dela! Enche a sua vagina!"

    # say L741 bel
    old "You never disappoint me!"
    new "B:bel: Estou tão feliz que conseguiste atingir o objetivo!"

    # say L742 amo
    old "It really was great!"
    new "Foi mesmo incrível!"


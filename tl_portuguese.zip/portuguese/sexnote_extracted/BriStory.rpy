# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/BriStory.rpy
translate portuguese strings:

    # say L11 pla
    old "I can't believe they were getting freaky in the living room."
    new "Não posso acreditar que eles estavam a fazer isso na sala de estar."

    # say L13 pla
    old "I know they are married but... they should do that in their room..."
    new "B:pla: Não posso acreditar que eles estavam a fazer isso na sala."

    # say L15 pla
    old "Anyway... let's take a look at this weird book."
    new "B:pla: Eu sei que eles estão casados, mas... deviam fazer isso no quarto deles..."

    # say L17 pla
    old "Let's see what it says..."
    new "B:pla: De qualquer maneira... vamos dar uma olhada neste livro estranho."

    # say L19 pla
    old "Expergiscimini defensoris librum... The hell does that mean? Did that airplane came from China?"
    new "B:pla: Vamos ver o que diz..."

    # say L26 sap
    old "A TUTELA EXPERGISCIMINI!!!"
    new "A:pla: Que raio! O que é isto?!"

    # say L28 pla
    old "What the fuck! What is this?!"
    new "A:sap: Quem ousa acordar-me!"

    # say L29 sap
    old "Qui audet excitare me!"
    new "B:pla: Que raio! O que é isto?!"

    # say L30 pla
    old "Oh my God! Please don't hurt me. I'm too young to die."
    new "B:sap: Quem ousa acordar-me!"

    # say L31 sap
    old "Latina loqui tibi."
    new "B:pla: Oh meu Deus! Por favor, não me magoes. Sou demasiado nova para morrer."

    # say L32 pla
    old "What?  I- I don't understand. Just please don't kill me... I didn't do anything... This thing just fell from an airplane..."
    new "B:sap: Latina loqui tibi."

    # say L33 sap
    old "Huh? What fell from an airplane?"
    new "B:pla: O quê? E-Eu não entendo. Por favor, não me mates... Eu não fiz nada... Esta coisa caiu de um avião..."

    # say L34 pla
    old "What? Oh, um, yeah! The book... This book fell from an airplane."
    new "B:sap: Huh? O que caiu de um avião?"

    # say L35 sap
    old "Oooh, hehe. Let's start from the beginning, shall we?"
    new "T(sap|tu|say): Oooh, hehe. Vamos começar do início, então?"

    # say L36 sap
    old "Nice to meet you!  My name is Brixxida."
    new "B:sap: Oooh, hehe. Vamos começar do princípio, então?"

    # say L42 pla
    old "Bri... xxi... da? Da fuck? Do you speak English?"
    new "B:sap: Nice to meet you! O meu nome é Brixxida."

    # say L43 bri
    old "Well, yes! I'm speaking it now. Hehe. I can actually speak all human languages..."
    new "B:pla: Bri... xxi... da? Que raio? Tu falas inglês?"

    # say L45 pla
    old "Human languages? That's a weird way to say it. What exactly are you?"
    new "B:bri: Bem, sim! Estou a falar agora. Hehe. Posso falar todas as línguas humanas..."

    # say L46 bri
    old "I'm the protective shinigami of the book you have there."
    new "T(bri|tu|say): Sou o shinigami protetor do livro que tens aí."

    # say L49 pla
    old "OH FUCK! A shinigami? Oh my God..."
    new "B:bri: Sou a shinigami protetora do livro que tens aí."

    # say L50 pla
    old "I'm so sorry, miss shinigami lady. I just found this on the ground and I picked it up. Brought it home. It looked cool."
    new "B:pla: OH MERDA! Uma shinigami? Meu Deus..."

    # say L52 pla
    old "I didn't mean to-"
    new "A:bri: Calma-te, humano. Hehe. Se foste tu quem encontrou e abriu o livro, isso significa que és o 'Escolhido'."

    # say L53 bri
    old "Calm down, human. Hehe. If you were the one who found and opened the book, it means that you are the 'chosen One'."
    new "T(bri|tu|say): Calma, humano. Hehe. Se foste tu quem encontrou e abriu o livro, isso significa que és o 'Escolhido'."

    # say L55 pla
    old "Cho-sen-one?"
    new "B:bri: Calma, humano. Hehe. Se foste tu quem encontrou e abriu o livro, isso significa que és o 'Escolhido'."

    # say L56 bri
    old "That's right!  And now the book belongs to you. And that also means I now belong to you. Hehe"
    new "B:pla: Cho-sen-one?"

    # say L58 pla
    old "What? You belong to me?  That means you are not going to kill me?"
    new "B:bri: Isso mesmo! E agora o livro é teu. E isso também significa que eu agora sou tua. Hehe"

    # say L59 bri
    old "No, of course not. Why would you think that?"
    new "T(bri|tu|say): Não, claro que não. Porque é que pensavas isso?"

    # say L61 pla
    old "Because you look like a monster about to devour me."
    new "B:bri: Não, claro que não. Porque é que pensarias isso?"

    # say L62 bri
    old "Oh? Sorry about that."
    new "B: pla: Porque pareces um monstro prestes a devorar-me."

    # say L68 bri
    old "...Is this form better? Hehe."
    new "B:bri: Oh? Desculpa."

    # say L83 pla
    old "What? Porn... No. I was just-"
    new "B:mo2: Que?! Do que estás a falar? Estavas a ver pornografia de novo?"

    # say L94 pla
    old "What the hell? Didn't she see you?"
    new "B:mo2: Acaba o que estavas a fazer."

    # say L107 bri
    old "Oh, I'm sorry! Hehe. I took human form to be more familiar to you, but I forgot that humans cover their bodies with 'clothing'."
    new "B:pla: Sim, esse é o meu nome. E... por que tu estás nu???"

    # say L113 pla
    old "Couldn't find anything that covers you a little bit more, huh? But at least nobody can see you. Now tell me again, who are you exactly?"
    new "T(pla|tu|say): Não encontraste nada que te cubra um pouco mais, hã? Mas pelo menos ninguém te vê. Agora diz-me de novo, quem és exatamente?"

    # say L115 bri
    old "I am Brixxida! A shinigami. I can shift and adapt to the form of any species, although my true form is this... "
    new "B:pla: Não encontraste nada que te cubra um pouco mais, hã? Mas pelo menos ninguém consegue ver-te. Agora, diz-me outra vez, quem és tu exatamente?"

    # say L120 bri
    old "...I am now much smaller, but I like being this size. Much more comfortable. Hehe"
    new "B:bri: Sou a Brixxida! Uma shinigami. Posso mudar e adaptar-me à forma de qualquer espécie, embora a minha forma verdadeira seja esta..."

    # say L128 pla
    old "Ok, ok. I get it now. I'm going crazy. This isn't real. It's a dream! Yeah, that's it! It's a dream..."
    new "B:bri:...Agora sou muito mais pequena, mas gosto de ser deste tamanho. Muito mais confortável. Hehe"

    # say L130 pla
    old "I fell asleep in class and soon I'm going to wake up... hmmm... I am going to wake up now.... hmmm."
    new "B:pla: Ok, ok. Agora percebi. Estou a ficar louco. Isto não é real. É um sonho! Sim, é isso! É um sonho..."

    # say L134 pla
    old "I'm trying to wake up from this dream."
    new "B:pla: Adormeci na aula e em breve vou acordar... hmmm... vou acordar agora.... hmmm."

    # say L136 bri
    old "You look wide awake to me, [pla]."
    new "T(bri|tu|say): Tu pareces bem acordado para mim, [pla]."

    # say L140 pla
    old "Yes, yes. I'm going to sleep... "
    new "B:pla: Tens razão! Estou muito cansado, então devo descansar. E amanhã voltarei ao normal."

    # say L142 bri
    old "Ok! Goodnight. Hehe."
    new "B:pla: Sim, sim. Vou dormir..."

    # say L148 pla
    old "Hmm... what a weird ass dream. I gotta lay off playing so many weird visual novels..."
    new "T(pla|tu|say): Hmm... que sonho estranho. Tenho de deixar de jogar tantos jogos visuais esquisitos..."

    # say L153 bri
    old "What are visual novels?"
    new "B:pla: Hmm... que sonho estranho. Tenho de parar de jogar tantos visual novels estranhos..."

    # say L156 pla
    old "Oh shit!  You... and you're naked again!"
    new "B:bri: O que são novelas visuais?"

    # say L158 bri
    old "Oh, my mistake.  I'm sorry. You humans are very dramatic about this... "
    new "B:pla: Oh merda! Tu... e estás nu de novo!"

    # say L164 pla
    old "Ok, ok. Just explain to me, Brixxida, why did the book fall from the sky?"
    new "B:bri: Oh, o meu erro. Peço desculpa. Vocês, humanos, são muito dramáticos com isso..."

    # say L166 bri
    old "The book chooses you! Now you are part of a tradition of sorcerers that can use the book's magical powers."
    new "B:pla: Ok, ok. Explica-me, Brixxida, por que o livro caiu do céu?"

    # say L168 pla
    old "Magic powers, you say?...  The hell-?"
    new "B:bri: O livro escolhe-te! Agora fazes parte de uma tradição de feiticeiros que podem usar os poderes mágicos do livro."

    # say L191 pla
    old "Don't worry about it. I actually think it's good that you keep the flame alive in your relationship over all these years."
    new "B:mo1: Fico contente por ouvir isso. Mas... quero pedir desculpa. Fomos um pouco descuidados ao ficarmos... íntimos na sala."

    # say L204 pla
    old "Didn't you say they can't hear you?"
    new "B:mo1: Bem, não vou incomodar-te mais. Continua a estudar bem, querida, e se precisares de mim estarei na cozinha."

    # say L206 bri
    old "Nope! But they can hear you! Hehe."
    new "B:pla: Não tinhas dito que eles não te podiam ouvir?"

    # say L208 pla
    old "Oh... Ok, that makes sense... but explain everything to me again."
    new "B:bri: Não! Mas eles podem ouvir-te! Hehe."

    # say L222 bri
    old "Again, I'm Brixxida, a shinigami. I am the protector of the book you found. Hehe."
    new "B:n: Quem és tu?"

    # say L224 pla
    old "Ok. Now, where did you come from?"
    new "B:bri: Mais uma vez, sou a Brixxida, uma shinigami. Sou a protetora do livro que encontraste. Hehe."

    # say L226 bri
    old "I come from another dimension. There, magic and power were natural, but that world has been destroyed."
    new "T(bri|tu|say): Venho de outra dimensão. Lá, a magia e o poder eram naturais, mas esse mundo foi destruído."

    # say L228 pla
    old "So... you are a time traveler?"
    new "T: Então... tu és um viajante do tempo?"

    # say L230 bri
    old "What? No, no... I have been asleep for hundreds of years with a spell. But when you opened and read the book, I woke up."
    new "B:pla: Então... tu és um viajante no tempo?"

    # say L232 pla
    old "Ok, I think I'm starting to understand."
    new "B:bri: O quê? Não, não... Eu estive a dormir durante centenas de anos sob um feitiço. Mas quando tu abriste e leste o livro, eu acordei."

    # menu L239 
    old "What's this book about?"
    new "B:pla: Ok, acho que estou a começar a perceber."

    # say L241 bri
    old "Well... this book contains all the knowledge of that magical world..."
    new "B:n: Do que é este livro?"

    # say L243 pla
    old "Eww. So, it's like a history book?"
    new "B:bri: Bem... este livro contém todo o conhecimento daquele mundo mágico..."

    # say L245 bri
    old "No, silly. This book contains specific spells and mantras that enable impressive magic powers beyond human understanding."
    new "B:pla: Eww. Então, é como um livro de história?"

    # say L247 pla
    old "Ok, I get that part."
    new "Mágica, dizes?"

    # menu L254 
    old "Magic, you say?"
    new "B:pla: Ok, percebo essa parte."

    # say L256 bri
    old "Yes! The magic is a natural power that was lost, but you can get it and actually improve it..."
    new "T(bri|tu|say): Sim! A magia é um poder natural que foi perdido, mas tu podes recuperá-lo e até melhorá-lo..."

    # say L258 pla
    old "Yeah, yeah. But... what can I do with magic?"
    new "B:bri: Sim! A magia é um poder natural que foi perdido, mas tu podes recuperá-lo e até melhorá-lo..."

    # say L260 bri
    old "Actually, there are no limits with magic! It is the most powerful force in the known universe..."
    new "B:pla: Sim, sim. Mas... o que posso fazer com a magia?"

    # say L262 pla
    old "Really? Interesting..."
    new "B:bri: Na verdade, não há limites com a magia! É a força mais poderosa no universo conhecido..."

    # say L271 bri
    old "Well... you have to learn different spells and mantras to achieve powerful skills but... you will find everything in the book."
    new "B:n: O que tenho de fazer?"

    # say L273 pla
    old "Imperium mens et feminam. What is that? Russian or some shit?"
    new "B:bri: Bem... tens de aprender diferentes feitiços e mantras para adquirir habilidades poderosas, mas... vais encontrar tudo no livro."

    # say L275 bri
    old "Actually, Latin is the language in which it was written... But don't worry, my job is to help the Chosen One translate..."
    new "T(bri|tu|say): Na verdade, é uma língua em que foi escrito... Mas não te preocupes, o meu trabalho é ajudar o Escolhido a traduzir..."

    # say L277 pla
    old "Do I have to learn a lot of information about spells and mantras?"
    new "B:bri: Na verdade, o latim é a língua em que foi escrito... Mas não te preocupes, a minha tarefa é ajudar o Escolhido a traduzir..."

    # say L279 bri
    old "That's right! Hehe. And gaining a lot of power!"
    new "B:pla: Tenho de aprender muita informação sobre feitiços e mantras?"

    # say L281 pla
    old "Ok, I hope this is all worth it."
    new "B:bri: Isso mesmo! Hehe. E a ganhar muito poder!"

    # say L292 pla
    old "Let's see here..."
    new "B:bri: É isso aí! Então, olha no início do livro por um feitiço fácil..."

    # say L295 pla
    old "Damn, forgot. Everyone can hear me in this room. I gotta look for a better place to do this..."
    new "B:pla: Vamos ver aqui..."

    # say L297 pla
    old "Hmm, probably the garage. Noone can hear me in there. Could you go there with me, Brixxida?"
    new "B:pla: Merda, esqueci. Todo mundo pode me ouvir neste quarto. Preciso encontrar um lugar melhor para fazer isso..."

    # say L299 bri
    old "I will follow you wherever you tell me."
    new "B:pla: Hmm, provavelmente a garagem. Ninguém me ouve lá. Podes ir comigo, Brixxida?"

    # say L301 pla
    old "Perfect! Let's do this in the garage."
    new "T(pla|tu|say): Perfeito! Vamos fazer isto no garagem."

    # say L318 pla
    old "I should talk with my [mo1rel] before we begin."
    new "T: Devo falar com o meu [mo1rel] antes de começarmos."

    # say L331 pla
    old "Alright, I spoke to my [mo1rel] and explained to her that I will be in here preparing my project."
    new "B:pla: Devo falar com a minha [mo1rel] antes de começarmos."

    # say L338 bri
    old "Well, first you must understand the magical power..."
    new "B:pla: Então, como é que tudo isto funciona, Brixxida?"

    # say L340 pla
    old "Magical power?"
    new "B:bri: Bem, primeiro tens de entender o poder mágico..."

    # say L342 bri
    old "Yes, you must have the magical power to be able to do any spell..."
    new "T(bri|tu|say): Sim, tu tens de ter o poder mágico para conseguires fazer qualquer feitiço... A:pla: Entendo, mas então como é que eu gero esse poder mágico?"

    # say L344 pla
    old "I understand, but then how do I generate that magical power?"
    new "B:bri: Sim, tu deves ter o poder mágico para ser capaz de fazer qualquer feitiço..."

    # say L346 bri
    old "Well, magical power is an energy that was produced naturally in the magical world..."
    new "Até tu?"

    # say L352 pla
    old "Even you?"
    new "B:bri: Bem, a energia mágica é uma força que surge naturalmente no mundo mágico..."

    # say L354 bri
    old "Yes... We feed on magical energy, when in the real world all the remaining energy has been used up, I will disappear..."
    new "T(bri|tu|say): Sim... Nós nos alimentamos de energia mágica, quando no mundo real toda a energia restante for usada, eu desaparecerei..."

    # say L356 pla
    old "Wow... And how do we prevent magic energy from running out?"
    new "B:bri: Sim... Nós nos alimentamos de energia mágica, quando no mundo real toda a energia restante for usada, eu desaparecerei..."

    # say L358 bri
    old "The magical energy will continue to run out until there be a new being so powerful that it can restore the magical world and return everything to its natural balance..."
    new "B:pla: Wow... E como impedimos que a energia mágica se esgote?"

    # say L360 pla
    old "That powerful being is supposed to be... me?..."
    new "B:bri: A energia mágica continuará a esgotar-se até que haja um novo ser tão poderoso que possa restaurar o mundo mágico e devolver tudo ao seu equilíbrio natural..."

    # say L362 bri
    old "Yes.. You are the chosen one."
    new "T(tu|diz): Sim... Tu és o escolhido."

    # say L364 pla
    old "Hmm, it's a lot of responsibility..."
    new "B:bri: Sim... Tu és o escolhido."

    # say L366 bri
    old "Don't worry. I know we will make it!"
    new "T(bri|tu|say): Não te preocupes. Eu sei que vamos conseguir!"

    # say L368 pla
    old "Okay, but then how can I make spells if I don't have magic energy?"
    new "Bem, deixa-me pensar... Não é nada difícil, a energia mágica está no ar."

    # say L369 bri
    old "Well, let me think... It's really not difficult, The magic energy is in the air."
    new "B:pla: Ok, mas então como posso fazer feitiços se não tenho energia mágica?"

    # say L370 bri
    old "I can see it. What you need to do is acquire a certain skill that allows you to see it too..."
    new "B:bri: Bem, deixa-me pensar... Não é nada difícil, a energia mágica está no ar."

    # say L373 bri
    old "Agamoto's eye! With it, you can see all the particles of magical power and collect them..."
    new "T(bri|tu|say): O olho de Agamoto! Com ele, tu podes ver todas as partículas de poder mágico e recolhê-las..."

    # say L375 pla
    old "Whose eye?"
    new "B:bri: O olho de Agamoto! Com ele, podes ver todas as partículas de poder mágico e recolhê-las..."

    # say L377 bri
    old "Agamoto's eye, is a special ability of vision. It will allow you to see many things of the magical world and expand your vision in a way never seen before by humans..."
    new "T(bri|tu|say): O olho de Agamoto é uma capacidade especial de visão. Vai permitir-te ver muitas coisas do mundo mágico e expandir a tua visão de uma forma nunca antes vista por humanos..."

    # say L379 pla
    old "Great. How do I get that ability then?"
    new "B:bri: Olho de Agamoto, é uma habilidade especial de visão. Vai permitir-te ver muitas coisas do mundo mágico e expandir a tua visão de uma forma nunca antes vista por humanos..."

    # say L381 bri
    old "Ohhh... Well, heh... You'll need magical power... Hahaha."
    new "B:pla: Ótimo. E como é que eu consigo essa habilidade então?"

    # say L383 pla
    old "Really?... So how can I get magic power? If I need magic power to get magic power..."
    new "B:bri: Ohhh... Bem, heh... Vais precisar de poder mágico... Hahaha."

    # say L385 bri
    old "Well, I think the easiest way is that I share you magic power!"
    new "T(bri|tu|say): Bem, acho que a maneira mais fácil é eu partilhar contigo o meu poder mágico!"

    # say L387 pla
    old "You share magic power with me?"
    new "B:bri: Bem, acho que a maneira mais fácil é eu partilhar contigo o meu poder mágico!"

    # say L389 bri
    old "Yes! As I explained to you, all magical beings are constituted of magical power."
    new "B:pla: Tu partilhas poder mágico comigo?"

    # say L390 bri
    old "In fact, we are like little magnets that we are gathering magical power constantly to live."
    new "B:bri: Sim! Como te expliquei, todos os seres mágicos são constituídos de poder mágico."

    # say L392 bri
    old "In the magical world it was totally normal to share our magical energy with others because there were lots..."
    new "B:bri: Na verdade, somos como pequenos ímanes que estamos a recolher poder mágico constantemente para viver."

    # say L394 bri
    old "The problem is that in this world there is less and less, so if I share more than necessary, it could disappear forever."
    new "B: No mundo mágico era totalmente normal partilhar a nossa energia mágica com os outros, porque havia muito..."

    # say L396 pla
    old "Wow, it looks dangerous... So what will we do?"
    new "B:bri: O problema é que neste mundo há cada vez menos, por isso, se eu partilhar mais do que o necessário, pode desaparecer para sempre."

    # say L398 bri
    old "Bah, I'm going to share enough, and then you can return me some magical power so that nothing happens to me."
    new "T(bri|tu|say): Bah, vou partilhar o suficiente, e depois tu podes devolver-me algum poder mágico para que nada me aconteça."

    # say L400 pla
    old "Okay, how do you share me then?"
    new "B:bri: Bah, vou partilhar o suficiente, e depois podes devolver-me algum poder mágico para que nada me aconteça."

    # say L402 bri
    old "Hmm, let's see. Take off your pants and lie on the floor..."
    new "T(bri|tu|say): Hmm, vamos ver. Tira as calças e deita-te no chão..."

    # say L404 pla
    old "What... Why do I have to take off my pants?"
    new "B:bri: Hmm, vamos ver. Tira as calças e deita-te no chão..."

    # say L407 bri
    old "Oh, of course... You humans treat nudity as a taboo. Even though it's something natural..."
    new "B:pla: Que... Porque tenho de tirar as calças?"

    # say L408 bri
    old "Besides what we're going to do... How do you call it?... Uhh, sex!"
    new "B:bri: Oh, claro... Vocês humanos tratam a nudez como um tabu. Mesmo sendo algo natural..."

    # say L410 pla
    old "What the fuck!? Are we going to have sex?"
    new "B:bri: Além do que vamos fazer... Como é que se chama?... Ah, sexo!"

    # say L412 bri
    old "Yes, it's super fun... I understand that you see it in a different way. But for us, this is simply a form of common energy exchange..."
    new "B:pla: Que raio!? Vamos ter relações sexuais?"

    # say L414 pla
    old "Are you saying that this is how you are going to share magical power?"
    new "B:bri: Sim, é super divertido... Entendo que vejas as coisas de uma forma diferente. Mas para nós, isto é simplesmente uma forma de troca de energia comum..."

    # say L416 bri
    old "Exactly, the magic power resides in an inner gland, and the only way to transfer it is to excite it..."
    new "T(bri|tu|say): Exatamente, o poder mágico reside numa glândula interna, e a única forma de transferi-lo é excitando-a..."

    # say L418 bri
    old "In my case, you must be inside me and you will receive my magic power!"
    new "B:bri: Exactamente, o poder mágico reside numa glândula interna, e a única forma de o transferir é excitando-a..."

    # say L420 pla
    old "... And there is no other way. I'm not sure if it's a good idea..."
    new "B:bri: No meu caso, tu tens de estar dentro de mim e vais receber o meu poder mágico!"

    # say L422 bri
    old "Oh come on! You humans are very complicated, but you have to see it as a magical being..."
    new "B:pla:... E não há outra maneira. Não tenho a certeza se é uma boa ideia..."

    # say L424 bri
    old "Think of sex as a way to feed yourself with magical energy... Is very natural."
    new "B:bri: Oh, vamos lá! Vocês humanos são muito complicados, mas têm de ver isto como um ser mágico..."

    # say L426 pla
    old "Alright, let's do it then..."
    new "B:bri: Pensa no sexo como uma forma de te alimentares com energia mágica... É muito natural."

    # say L429 bri
    old "Excellent! Take off your pants and get on the floor!"
    new "B:pla: Tudo bem, vamos lá..."

    # say L434 bri
    old "Wow, this is very good! I haven't done it for a long time..."
    new "B:bri: Excelente! Tira as calças e deita-te no chão!"

    # say L442 pla
    old "Do you have some magic power to share with me?"
    new "B:bri: Uau, isto é muito bom! Não fazia isto há muito tempo..."

    # say L444 bri
    old "Do you need more from me?"
    new "B:pla: Tu tens algum poder mágico para partilhar comigo?"

    # say L446 pla
    old "Well, only if you have some to share..."
    new "B:bri: Precisas de mais alguma coisa de mim?"

    # say L448 bri
    old "Ok, but just because is really fun... hahaha"
    new "B:pla: Bem, só se tiveres para partilhar..."

    # say L452 bri
    old "Take off your pants and lie on the floor..."
    new "B:bri: Ok, mas é porque é mesmo divertido... hahaha"

    # say L478 pla
    old "Wow, I've never slept that well."
    new "B:bri: Tira as calças e deita-te no chão..."

    # say L480 bri
    old "I see that your body was able to completely assimilate magic. How do you feel?"
    new "B:pla: Uau, nunca dormi tão bem."

    # say L482 pla
    old "I don't feel any different..."
    new "B:bri: Vejo que o teu corpo foi capaz de assimilar completamente a magia. Como te sentes?"

    # say L484 bri
    old "Well, the best thing to do is to use the magic energy that I gave you to acquire Agamoto's Eye before it runs out..."
    new "T(bri|tu|say): Bem, a melhor coisa a fazer é usar a energia mágica que te dei para adquirir o Olho de Agamoto antes que ela se esgote..."

    # say L486 pla
    old "Does that mean that if I don't use the magic power it will run out?"
    new "B:bri: Bem, a melhor coisa a fazer é usar a energia mágica que te dei para adquirir o Olho de Agamoto antes que ela se esgote..."

    # say L488 bri
    old "Yes, indeed. Every day you will have less magical power, which is why it is urgent that you acquire the skill."
    new "B:pla: Isso significa que se eu não usar o poder mágico ele vai acabar?"

    # say L490 pla
    old "Perfect, let's go to the garage to do it then..."
    new "B:bri: Sim, de facto. Todos os dias vais ter menos poder mágico, por isso é urgente que adquiras a habilidade."

    # say L496 pla
    old "So, what should I do?"
    new "B:pla: Perfeito, vamos então para a garagem fazer isso..."

    # say L497 bri
    old "Well, actually, yesterday we couldn't finish our magic transfer..."
    new "B:pla: Então, o que devo fazer?"

    # say L498 bri
    old "So, we should do it again, in order to you get completly charged with magic power."
    new "B:bri: Bem, na verdade, ontem não conseguimos terminar a nossa transferência de magia..."

    # say L499 pla
    old "Hmm alright, but I'm not going to lay on the floor like last time, I don't want someone else to see me in that weird position..."
    new "B:bri: Então, devemos fazer de novo, para tu ficares completamente carregado com poder mágico."

    # say L500 bri
    old "All right!"
    new "T(bri|tu|say): Tudo bem! Agora, o que devo fazer?"

    # say L513 pla
    old "All right. Now what should I do?"
    new "Tudo bem. Agora, o que devo fazer?"

    # say L515 bri
    old "First open your SexNote"
    new "B:pla: Tudo bem. E agora, o que devo fazer?"

    # say L525 bri
    old "Now check the first spell named 'Agamoto's eye' and activate it."
    new "B:bri: Primeiro abre o teu SexNote"

    # say L526 pla
    old "Understood..."
    new "T(pla|tu|say): Entendido..."

    # say L539 pla
    old "I think it's done... But I don't feel anything different..."
    new "A:bri: Tens de a ativar, clica na habilidade e olha para a dimensão mágica!"

    # say L541 bri
    old "You must activate it, click on ability and look at the magic dimension!"
    new "T(bri|tu|say): Tens de a ativar, clica na habilidade e olha para a dimensão mágica!"

    # say L568 pla
    old "Wow... It looks so... Magical?..."
    new "B:bri: Tens de a ativar, clica na habilidade e olha para a dimensão mágica!"

    # say L569 bri
    old "Do you see those little colored spheres? That is magic power, it has become particles, you just have to pick it all up..."
    new "B:pla: Uau... Parece tão... Mágico?..."

    # say L570 bri
    old "And when you do it, just click the Agamoto's Eye to desactivate it and see the real world."
    new "B:bri: Vês aquelas pequenas esferas coloridas? É poder mágico, transformou-se em partículas, só tens de as recolher todas..."

    # say L579 pla
    old "Wow, it's easier than I expected..."
    new "B:bri: E quando fizeres isso, basta clicar no Olho de Agamoto para desativá-lo e ver o mundo real."

    # say L581 bri
    old "Of course, what did you expect? Having to memorize and recite strange meaningless words or make puzzles that never fit in  corners?"
    new "B:pla: Uau, é mais fácil do que eu esperava..."

    # say L583 pla
    old "What?..."
    new "B:bri: Claro, o que esperavas? Ter de memorizar e recitar palavras estranhas sem sentido ou fazer quebra-cabeças que nunca encaixam nos cantos?"

    # say L585 bri
    old "Nevermind... It's simple, you just have to look for the spheres of magic power and that's it..."
    new "B:pla: Que?..."

    # say L587 bri
    old "In fact... There is a spell you can use called Ayax's Hand"
    new "B:bri: Não importa... É simples, tu só tens de procurar as esferas de poder mágico e pronto..."

    # say L589 bri
    old "With this one your body will automatically begin to collect magic power everywhere you move, it's sorta like a magnet.."
    new "B:bri: Na verdade... Existe um feitiço que podes usar chamado Mão de Ayax"

    # say L591 pla
    old "Yes, you're right, there are several more spells I saw in the SexNote, how can I activate them?"
    new "B:bri: Com este, o teu corpo vai começar a atrair automaticamente poder mágico por todo o lado para onde vais, é como se fosse um íman.."

    # say L593 bri
    old "Very easy you only spend the magic power you have in them and so you can activate those spells, each one has three different levels of power."
    new "B:pla: Sim, tens razão, vi vários feitiços adicionais no SexNote, como posso ativá-los?"

    # say L595 bri
    old "For example, the higher the level of power you have with Agamoto's eye, the more spheres you will see and so you can collect more magical power!"
    new "T(bri|tu|say): Por exemplo, quanto maior o nível de poder que tens com o Olho de Agamoto, mais esferas vais ver e, assim, podes recolher mais poder mágico!"

    # say L597 pla
    old "Ohhh understood, and when I have collected all the magical power from a place?"
    new "B:bri: Por exemplo, quanto maior o nível de poder que tens com o olho de Agamoto, mais esferas verás e, assim, poderás recolher mais poder mágico!"

    # say L599 bri
    old "Check this out, power spheres group everyday so keep an eye out and collect more magical power!"
    new "A:bri: Algo importante é que o teu corpo não consegue armazenar muito poder mágico..."

    # say L602 bri
    old "Something important is that your body cannot store much magical power..."
    new "B:bri: Olha isto, as esferas de poder formam grupos todos os dias, por isso mantém o olho na bola e recolhe mais poder mágico!"

    # say L603 bri
    old "For that you must use a spell, and thus increase the amount of power that you can store within yourself."
    new "B:bri: Algo importante é que o teu corpo não pode armazenar muito poder mágico..."

    # say L605 pla
    old "Excellent, so I'm going to devote myself to collecting some magical power in the meantime..."
    new "B:bri: Para isso tens de usar um feitiço e, assim, aumentar a quantidade de poder que podes armazenar dentro de ti."

    # say L607 bri
    old "Perfect, now that you can do it... You could give me a little, remember that I need it to exist."
    new "B:pla: Excelente, então vou dedicar-me a recolher um pouco de poder mágico entretanto..."

    # say L609 pla
    old "Ohh yes, I'm sorry, let me pick up some more magical power and I will give you later..."
    new "B:bri: Perfeito, agora que consegues... Poderias dar-me um pouco, lembra-te de que preciso disso para existir."

    # say L611 bri
    old "Oh, by the way! Keep in mind that using your Agamotto Eye spends some magical power and time."
    new "B:pla: Ohh sim, desculpa, deixa-me recolher mais poder mágico e depois dou-te..."

    # say L615 bri
    old "Well, all magical skills, requires some magical power to be used..."
    new "B:bri: Oh, por acaso! Lembra-te que usar o teu Olho de Agamotto gasta alguma energia mágica e tempo."

    # say L618 bri
    old "And when you are in the magic dimension time passes a little faster too."
    new "B:bri: Bem, todas as habilidades mágicas requerem algum poder mágico para serem usadas..."

    # say L620 bri
    old "If you use only a couple of times, you will not see much difference but if you use them alot you will end the day very quickly."
    new "B:bri: E quando estás na dimensão mágica, o tempo também passa um pouco mais rápido."

    # say L622 pla
    old "Ohh ok, understood..."
    new "B:bri: Se usares só umas poucas vezes, não vais notar muita diferença, mas se usares muito vais acabar o dia muito depressa."

    # say L624 bri
    old "It is indeed a good way to kill time if you have nothing to do at some point."
    new "T(bri|tu|say): É de facto uma boa maneira de passar o tempo se não tiveres nada para fazer nessa altura."

    # say L626 pla
    old "I guess you are right..."
    new "T: Acho que tens razão..."

    # say L628 bri
    old "Ok, I'll be here if you need me."
    new "B:pla: Acho que tens razão..."

    # say L701 pla
    old "Hey Brixxida... I think I was visited by another shinigami, like you, yesterday."
    new "T(pla|tu|say): Olá Brixxida... Acho que fui visitado por outro shinigami, como tu, ontem."

    # say L705 pla
    old "You are the only shinigami alive in the human world?"
    new "B:pla: Ei, Brixxida... Acho que fui visitado por outro shinigami, como tu, ontem."

    # say L707 bri
    old "I'm not sure, there are likely to be more, the magical world was very big..."
    new "T(bri|tu|say): Não tenho a certeza, provavelmente há mais, o mundo mágico era muito grande..."

    # say L709 pla
    old "Well, one of them visited me last night and she was sucking my... She was stealing my magic power..."
    new "B:bri: Não tenho a certeza, o mundo mágico era muito grande..."

    # say L711 bri
    old "Wow... Really?"
    new "B:pla: Bem, uma delas visitou-me ontem à noite e ela estava a chupar o meu... Estava a roubar os meus poderes mágicos..."

    # say L713 pla
    old "Who is she and why did she steal my magic power?"
    new "T: Quem é ela e por que roubou o meu poder mágico?"

    # say L715 bri
    old "I don't know, it's not like I knew all the magical beings..."
    new "T(bri|tu|say): Não sei, não é como se eu conhecesse todos os seres mágicos..."

    # say L717 pla
    old "So what can we do?"
    new "B:bri: Não sei, não é como se eu conhecesse todos os seres mágicos..."

    # say L719 bri
    old "I don't think it will happen again, it's best we wait. If she steals from you again we'll have to defend ourselves..."
    new "T(bri|tu|say): Não acho que vá acontecer de novo, é melhor esperarmos. Se ela te roubar de novo, vamos ter de nos defender..."

    # say L721 pla
    old "What do you mean defend ourselves?"
    new "B:bri: Não acho que isso vá acontecer de novo, é melhor esperarmos. Se ela te roubar de novo, vamos ter que nos defender..."

    # say L723 bri
    old "Well, we would have to hunt her and take away her magical power instead..."
    new "B:pla: O que queres dizer com defender-nos?"

    # say L725 pla
    old "All her magical power? That would make her disappear... wouldn't it?"
    new "B:bri: Bem, teríamos de a caçar e tirar-lhe os poderes mágicos..."

    # say L727 bri
    old "Well if she attack you again, we can't sit by while she keeps stealing our magical power! We must stop her somehow..."
    new "B:pla: Toda a sua magia? Isso faria com que ela desaparecesse... não é?"

    # say L729 pla
    old "Hmmm... Ok, just let's wait and hopefully she won't  show up again."
    new "B:bri: Se ela te atacar de novo, não podemos ficar parados enquanto ela continua a roubar o nosso poder mágico! Temos que a parar de alguma forma..."

    # say L731 bri
    old "Right... Don't worry, thought. Just keep improving with your skills..."
    new "B:pla: Hmmm... Ok, vamos esperar e esperemos que ela não apareça de novo."

    # say L745 pla
    old "Brixxida, last night another shinigami visited me!"
    new "B:bri: Certo... Não te preocupes, pensa nisso. Continua a melhorar com as tuas habilidades..."

    # say L747 bri
    old "Another? And did she steal more magic power from you?"
    new "B: Brixxida, ontem à noite outro shinigami visitou-me!"

    # say L749 pla
    old "Well... yes."
    new "B:bri: Outro? E ela roubou mais poder mágico de ti?"

    # say L751 bri
    old "Damn! That can't keep happening! We must recover my magical power... I mean, our magical power..."
    new "T(bri|tu|say): Merda! Isso não pode continuar acontecendo! Temos que recuperar o meu poder mágico... Quero dizer, o nosso poder mágico..."

    # say L753 pla
    old "And how do we do it?"
    new "B:bri: Merda! Isso não pode continuar acontecendo! Temos que recuperar o meu poder mágico... Quero dizer, o nosso poder mágico..."

    # say L755 bri
    old "We must go on the hunt... We will attack them so they don't bother us again..."
    new "T(bri|tu|say): Temos de ir à caça... Vamos atacá-los para que não nos incomodem de novo..."

    # say L757 pla
    old "No, no, this time I was able to talk with her a little more..."
    new "B: Bri: Temos que ir à caça... Vamos atacá-los para que não nos incomodem de novo..."

    # say L758 pla
    old "In fact she didn't steal much magic from me... and I would like to understand the situation better..."
    new "B:pla: Não, não, desta vez consegui falar com ela um pouco mais..."

    # say L760 bri
    old "They have stolen magical power. If it continues, we will be wasting valuable time that we must use to collect more magical power..."
    new "B:pla: Na verdade, ela não me roubou tanta magia... e eu gostaria de entender melhor a situação..."

    # say L762 pla
    old "Let me try one more time. When they return I will try to find out more and see if we can calm them down..."
    new "B:bri: Eles roubaram poder mágico. Se continuar, vamos perder tempo valioso que devemos usar para recolher mais poder mágico..."

    # say L764 bri
    old "Hmm, if they steal your magic power again, we will have to defend ourselves, okay?"
    new "B:pla: Deixa-me tentar mais uma vez. Quando eles voltarem, vou tentar descobrir mais e ver se conseguimos acalmá-los..."

    # say L766 pla
    old "Okay. I will try to use Sauron's Mouth to find out more next time..."
    new "B:bri: Hmm, se eles roubarem o teu poder mágico de novo, teremos de nos defender, ok?"

    # say L768 bri
    old "Well, make sure you have the skill at the highest level to get as much information as possible."
    new "B:pla: Okay. Vou tentar usar a Boca de Sauron para descobrir mais da próxima vez..."

    # say L770 pla
    old "For sure..."
    new "B:bri: Certifica-te de que tens a habilidade no nível mais alto para obter a maior quantidade de informações possível."

    # say L782 pla
    old "Well, things will be fine ..."
    new "B:pla: Com certeza..."

    # say L784 bri
    old "You put a stop to the night robberies?"
    new "B:pla: Bem, as coisas vão ficar bem..."

    # say L786 pla
    old "Well, Not really..."
    new "B:bri: Tu puseste fim aos assaltos noturnos?"

    # say L788 bri
    old "Then we will have to fight back now..."
    new "B:pla: Bem, não realmente..."

    # say L790 pla
    old "No, wait! The problem is that I have taken magical energy that they need to live..."
    new "T(pla|tu|say): Não, espera! O problema é que eu absorvi a energia mágica que eles precisam para viver..."

    # say L792 bri
    old "You have taken magical energy that is scattered throughout the world. You have never attacked any of them..."
    new "Mas... Posso gerar poder mágico de outras formas..."

    # say L794 pla
    old "But... I can generate magical power in other ways..."
    new "B:bri: Tu tens absorvido energia mágica que está dispersa pelo mundo. Nunca atacaste nenhum deles..."

    # say L796 bri
    old "You still don't have enough sexual activity with other women, to guarantee a constant production of magical energy."
    new "T(bri|tu|say): Ainda não tens atividade sexual suficiente com outras mulheres para garantir uma produção constante de energia mágica."

    # say L798 pla
    old "I can do it and not affect them..."
    new "B:bri: Ainda não tens atividade sexual suficiente com outras mulheres para garantir uma produção constante de energia mágica."

    # say L800 bri
    old "You must think about the main goal and it is to be able to rebuild the magical world."
    new "T(bri|tu|say): Tu deves pensar no objetivo principal, que é conseguir reconstruir o mundo mágico."

    # say L802 bri
    old "There are many magical beings that will disappear..."
    new "T(bri|tu|say): Existem muitos seres mágicos que vão desaparecer..."

    # say L803 bri
    old "And we can do nothing but work harder to rebuild everything as quickly as possible..."
    new "B:bri: Existem muitos seres mágicos que desaparecerão..."

    # say L805 pla
    old "Hmm... I guess you're right, but we don't have to attack them."
    new "B:bri: E não podemos fazer nada além de trabalhar mais para reconstruir tudo o mais rápido possível..."

    # say L806 pla
    old "I will try to produce our own energy and little by little we can move forward with the spells..."
    new "B:pla: Hmm... Acho que tens razão, mas não temos de os atacar."

    # say L808 bri
    old "They will continue stealing your magical power if we do nothing."
    new "B:pla: Vamos tentar produzir a nossa própria energia e, pouco a pouco, podemos avançar com os feitiços..."

    # say L809 bri
    old "We don't have to take away all the magical power, just enough to scare them and they won't look for you again..."
    new "T(bri|tu|say): Não temos de tirar toda a magia, basta o suficiente para os assustar e eles não voltarão a procurar-te..."

    # say L811 pla
    old "Hmm that's fine... How do we do it?"
    new "B:bri: Não temos de tirar todo o poder mágico, apenas o suficiente para os assustar e eles não te procurarão de novo..."

    # say L813 bri
    old "I'll take care of tracking them and you'll do the attacking..."
    new "A:pla: Atacá-los?"

    # say L815 pla
    old "Attack them?"
    new "B:bri: Vou ficar a vigiá-los e tu vais atacá-los..."

    # say L817 bri
    old "Yes, you will have to fuck them..."
    new "B:pla: Atacá-los?"

    # say L819 pla
    old "Hmmm... Ok."
    new "B:bri: Sim, vais ter de os foder..."

    # say L821 bri
    old "Ok, give me a second. I'm going to use a special spell to detect nearby magical beings..."
    new "B:pla: Hmmm... Ok."

    # say L831 pla
    old "But... What if other people are there?"
    new "B:bri: Feito... Já identifiquei onde uma delas está! Ela está na tua sala de aula na escola! Vai lá e fode com ela..."

    # say L833 bri
    old "Don't worry! When you are in the magical dimension with Agamoto's Eye nobody can see you..."
    new "B:pla: Mas... E se houver outras pessoas?"

    # say L835 pla
    old "Ok, I'm going there then..."
    new "B:bri: Não te preocupes! Quando estás na dimensão mágica com o Olho de Agamoto, ninguém te vê..."

    # say L837 bri
    old "Good luck! See you later..."
    new "B:pla: Ok, vou para lá então..."

    # say L843 pla
    old "(Well, she is supposed to be here...)"
    new "B:bri: Boa sorte! Até mais..."

    # say L845 pla
    old "(Let's use the Agamoto's Eye.)"
    new "A:mil: Que raio estás tu a fazer aqui?"

    # say L852 mil
    old "What the fuck are you doing here?"
    new "B: pla: (Vamos usar o Olho de Agamoto.)"

    # say L860 bri
    old "So, how did it go? Did you get magic power back?"
    new "B:mil: Que raio estás tu a fazer aqui?"

    # say L862 pla
    old "Yes, I already recovered my magic power..."
    new "B:bri: Então, como correu? Conseguiste recuperar os teus poderes mágicos?"

    # say L864 bri
    old "Great... I don't think they will bother again after that..."
    new "B:pla: Sim, já recuperei os meus poderes mágicos..."

    # say L866 pla
    old "Hmm I don't know... We shall see."
    new "B:bri: Ótimo... Acho que eles não vão nos incomodar de novo depois disso..."

    # say L878 pla
    old "Again, problems with these shinigamis, I think they've gone crazy..."
    new "B:pla: Hmm não sei... Vamos ver."

    # say L880 bri
    old "AGAIN? Okay let's finish them..."
    new "B:pla: De novo, problemas com esses shinigamis, acho que enlouqueceram..."

    # say L882 pla
    old "No, no... It's very strange. The one who I talked to yesterday was very kind and friendly after having accused me of destroying the magical world..."
    new "B:bri: OUTRA VEZ? Ok, vamos acabar com eles..."

    # say L884 bri
    old "What?... Ehh... They are totally crazy... It's best to make them disappear. We don't want to deal with them later..."
    new "B:pla: Não, não... É muito estranho. A pessoa com quem falei ontem foi muito simpática e amigável depois de me acusar de destruir o mundo mágico..."

    # say L886 pla
    old "We'll let's try this... I will try to find the next shinigami and I will see what's happening..."
    new "B:bri: O quê?... Ehhh... Eles estão completamente loucos... É melhor fazê-los desaparecer. Não queremos lidar com eles depois..."

    # say L888 bri
    old "But you should kill them! We've had enough..."
    new "B:pla: Vamos tentar isto... Vou tentar encontrar o próximo shinigami e ver o que se está a passar..."

    # say L890 pla
    old "No, no. Let me handle this. I have an idea..."
    new "B:bri: Mas tu deves matá-los! Já chega..."

    # say L892 bri
    old "Hmmm ok. I'm gonna use the spell again and I'll tell you where to find the next shinigami..."
    new "B:pla: Não, não. Deixa-me tratar disto. Tenho uma ideia..."

    # say L900 bri
    old "Well, she is in fact in your friend Hinn's living room."
    new "B:bri: Hmmm, ok. Vou usar o feitiço de novo e vou dizer-te onde encontrar o próximo shinigami..."

    # say L902 pla
    old "Hmmm, alright... No problem."
    new "B:bri: Bem, ela está de facto na sala de estar do teu amigo Hinn."

    # say L904 bri
    old "But you should consider killing them. It can't waste more time..."
    new "B:pla: Hmmm, bem... Sem problemas."

    # say L906 pla
    old "I know what to do..."
    new "B:bri: Mas deves considerar matá-los. Não podes perder mais tempo..."

    # say L908 bri
    old "Hmm, Ok."
    new "B:pla: Eu sei o que fazer..."

    # say L914 pla
    old "(Great, no one is in the livingroom...)"
    new "Ótimo, ninguém está na sala..."

    # say L919 pla
    old "Excellent! Just what I wanted..."
    new "B:pla: (Ótimo, ninguém está na sala...)"

    # say L930 mil
    old "What? What are you doing?"
    new "B:pla: Excelente! Exactamente o que queria..."

    # say L939 pla
    old "I have some questions to ask you..."
    new "T(pla|tu|say): Tenho algumas perguntas a fazer-te..."

    # say L941 bri
    old "Sure! Do you want to know more about spells?"
    new "B:pla: Tenho algumas perguntas a fazer-te..."

    # say L943 pla
    old "No, in fact, I want you to tell me who destroyed the magical world..."
    new "A:bri: Claro, o mundo mágico era um lugar maravilhoso. Todos viviam em harmonia..."

    # say L946 bri
    old "Of course, the magical world was a wonderful place. Everyone lived in harmony..."
    new "B:pla: Não, na verdade, quero que me digas quem destruiu o mundo mágico..."

    # say L948 bri
    old "But a dark being, for unknown reasons, destroyed everything with a spell. When started to act it was too late because the being had too much power..."
    new "B:bri: Claro, o mundo mágico era um lugar maravilhoso. Todos viviam em harmonia..."

    # say L950 pla
    old "And why did the shinigami tell me the person who destroyed the magical world was the SexNote owner?"
    new "B:bri: Mas uma entidade sombria, por razões desconhecidas, destruiu tudo com um feitiço. Quando começaram a agir já era tarde demais, pois a entidade tinha demasiado poder..."

    # say L952 bri
    old "I don't know... It could have been the former owner of the SexNote or it could have been another SexNote..."
    new "T(bri|tu|say): Não sei... Podia ter sido o antigo dono do SexNote ou outra SexNote..."

    # say L954 pla
    old "Is there more than one SexNote?"
    new "B:bri: Não sei... Podia ter sido o antigo dono do SexNote ou poderia ter sido outro SexNote..."

    # say L957 bri
    old "It is not known for sure. Nobody knows. In fact, many ignore the real existence of a SexNote. It is something very secret because of the power it has..."
    new "B:pla: Existe mais do que uma SexNote?"

    # say L959 bri
    old "That's why you're the Chosen One to use it to repair all the damage..."
    new "B:bri: Não se sabe ao certo. Ninguém sabe. Na verdade, muitos ignoram a existência real de uma SexNote. É algo muito secreto devido ao poder que tem..."

    # say L961 pla
    old "I understand... Still, you don't know anything about the previous owner of the SexNote or who destroyed the magical world?"
    new "B:bri: É por isso que tu és o Escolhido para usá-lo para reparar todo o dano..."

    # say L963 bri
    old "Correct, My mission was entrusted after the destruction of the magical world, to find a way to preserve the remaining magic of the universe..."
    new "T(bri|tu|say): Correto, a minha missão foi confiada a mim após a destruição do mundo mágico, para encontrar uma forma de preservar a magia restante do universo..."

    # say L965 pla
    old "Got cha. Then everything is a silly misunderstanding... Help me look again for the shinigami to talk to them..."
    new "B:bri: Correto, a minha missão foi confiada após a destruição do mundo mágico, para encontrar uma forma de preservar a magia restante do universo..."

    # say L967 bri
    old "I don't think that is for the best. After what happened, it could be dangerous. It is best to leave it be as I doubt they'll look for you again..."
    new "T(bri|tu|say): Não acho que seja o melhor. Depois do que aconteceu, pode ser perigoso. É melhor deixar como está, duvido que eles voltem a procurar-te..."

    # say L969 pla
    old "But you heard them, they are running out of magic power..."
    new "B:bri: Não acho que seja o melhor. Depois do que aconteceu, poderia ser perigoso. É melhor deixar como está, duvido que eles voltem a procurar-te..."

    # say L971 bri
    old "The magic power is scattered throughout the world, they just have to go to other places to collect. It is not as serious as they want you to think..."
    new "B:pla: Mas tu ouviste, eles estão a ficar sem poder mágico..."

    # say L973 pla
    old "Hmmm... Ok... I guess you're right"
    new "B: bri: O poder mágico está espalhado pelo mundo, eles só precisam ir a outros lugares para o recolher. Não é tão grave como querem que tu penses..."

    # say L975 pla
    old "Well, I'm going to keep improving my skills and collecting magical power."
    new "B:pla: Hmmm... Ok... Acho que tens razão."

    # say L977 bri
    old "Great! See you later."
    new "B:pla: Vou continuar a melhorar as minhas habilidades e a recolher poder mágico."

    # say L983 pla
    old "(I still think there is something up with Brixxida. I should try to talk with those shinigamis again)"
    new "B: Bri: Ótimo! Até mais."

    # say L985 pla
    old "(But, I can't ask Brixxida to look for them...)"
    new "B:pla: (Ainda acho que há algo de errado com a Brixxida. Devo tentar falar com aqueles shinigamis de novo)"

    # say L987 pla
    old "(I will have to look for them by myself)"
    new "(Mas, não posso pedir à Brixxida para os procurar...) (Vou ter de os procurar eu própria) (Ok, devo procurar por aí para os encontrar...)"

    # say L989 pla
    old "Ok, I should look around to find them..."
    new "Ok, devo procurar por eles..."

    # menu L996 
    old "Talk with her"
    new "B:pla: Ok, devo procurar por eles..."

    # say L1010 pla
    old "Well, I already collected enough magic power, I think I can share some with you..."
    new "Bem, já recolhi magia suficiente, acho que posso partilhar um pouco contigo..."

    # say L1013 bri
    old "Yummy. I love to share the magic power. It's very fun!"
    new "B:pla: Bem, já recolhi poder mágico suficiente, acho que posso partilhar um pouco contigo..."

    # menu L1022 
    old "Repeat"
    new "B:bri: Delicioso. Adoro partilhar o poder mágico. É muito divertido!"

    # say L1033 pla
    old "Wait... What are you doing..."
    new "B:n: Repete"

    # say L1034 bri
    old "Duh. Receiving your magical power, this is how it is done..."
    new "B:pla: Espera... O que estás a fazer..."

    # say L1035 pla
    old "But..."
    new "B:bri: Duh. A receber o teu poder mágico, é assim que se faz..."

    # say L1036 bri
    old "You must stop being so dramatic with this. You have to be more professional and understand that this is the way it is done. So stop being so... Human..."
    new "T(bri|tu|say): Tu tens de parar de ser tão dramático com isto. Tens de ser mais profissional e perceber que é assim que as coisas são feitas. Então, para de ser tão... Humano..."


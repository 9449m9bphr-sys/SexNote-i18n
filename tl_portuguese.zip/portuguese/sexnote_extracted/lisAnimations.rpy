# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/lisAnimations.rpy
translate portuguese strings:

    # say L6 lis
    old "Just relax and feel all my body, focus on the new sensations."
    new "Consegues sentir o meu peito por cima das tuas costas?"

    # say L10 lis
    old "Can you feel my breast over your back?"
    new "B:lis: Só relaxa e sente todo o meu corpo, concentra-te nas novas sensações."

    # say L11 pla
    old "Y- yeah..."
    new "B:lis: Tu consegues sentir o meu peito nas tuas costas?"

    # say L15 lis
    old "I'm going to do it faster so you can feel more all my energy."
    new "B: pla: Y- yeah..."

    # say L41 lis
    old "You are very connected with the moment and the environment, it means we can go beyond, you are ready for the next step."
    new "B:lis: Vou fazer mais rápido para tu sentires toda a minha energia."

    # say L42 pla
    old "... Ok."
    new "B:lis: Tu estás muito conectada com o momento e o ambiente, o que significa que podemos ir mais longe, tu estás pronta para o próximo passo."

    # say L47 lis
    old "Please lie down now on your back so we can expose the parts of your body that we need to balance the energy."
    new "B:pla:... Ok."

    # say L50 lis
    old "We can heal your body together, we can heal each other, please follow my instructions so you can release all these negative experiences..."
    new "B:lis: Por favor, deita-te agora de costas para que possamos expor as partes do teu corpo que precisamos para equilibrar a energia."

    # say L51 lis
    old "Please lie down on your back, so we can take the negative energy out..."
    new "B:lis: Podemos curar o teu corpo juntos, podemos curar-nos um ao outro, por favor segue as minhas instruções para poderes libertar todas estas experiências negativas..."

    # say L63 lis
    old "Ok, we are done now, let's do the next exercise..."
    new "B:lis: Deita-te de costas, para podermos retirar a energia negativa..."

    # say L73 lis
    old "Is it pleasant?"
    new "B:lis: Ok, já acabámos, vamos fazer o próximo exercício..."

    # say L74 pla
    old "Yes..."
    new "B:lis: É agradável?"

    # say L78 lis
    old "Keep breathing, that is the key, your muscles must get extremely relaxed, my hands will clean the bad energies, let them do their job."
    new "B:pla: Sim..."

    # say L82 lis
    old "Please let yourself go, do not think about anything else, I will move faster so you can't release the tension, so you can let the chakra muladhara to be cleaned."
    new "B:lis: Continua a respirar, isso é fundamental, os teus músculos têm de ficar extremamente relaxados, as minhas mãos irão limpar as energias negativas, deixa-as fazer o seu trabalho."

    # say L106 lis
    old "Do you feel the negative chakra leaving?"
    new "B:lis: Deixa-te ir, não penses em mais nada, vou mover-me mais rápido para que não consigas libertar a tensão, para que possas deixar que o chakra muladhara seja limpo."

    # say L108 lis
    old "Let it out... Breath and let it out."
    new "B:lis: Sentes a chakra negativa a sair?"

    # say L113 pla
    old "Phew..."
    new "B:lis: Deixa sair... Respira e deixa sair."

    # say L114 lis
    old "Wow, that was wonderful, our job had abundant results."
    new "T(lis|tu|say): Uau, isso foi incrível, o nosso trabalho deu resultados abundantes."

    # say L129 lis
    old "Do you feel my boobs?"
    new "B:lis: Uau, isso foi incrível, o nosso trabalho deu resultados abundantes."

    # say L133 lis
    old "Let it move... Feel me, I can see your body is doing it great..."
    new "B:lis: Sentes os meus peitos?"

    # say L137 lis
    old "I can see it's hard to fight with your chakra muladhara but we can try harder than that, stay focused and just release the negative energy..."
    new "B:lis: Deixa-te ir... Sente-me, posso ver que o teu corpo está a reagir muito bem..."

    # say L160 lis
    old "Yes, breath, and feel how your energy is moving...  I want you to let it go..."
    new "B:lis: Consigo ver que é difícil lutar contra o teu chakra muladhara, mas podemos tentar mais do que isso, mantém-te focado e liberta a energia negativa..."

    # say L166 lis
    old "Do you feel relieved?"
    new "B:lis: Sim, respira e sente como a tua energia está a fluir... Quero que a libertes..."

    # say L168 lis
    old "Great, we will need to continue working on it but you are doing amazing."
    new "B:lis: Sentes-te aliviada?"

    # say L233 lis
    old "Oh, yes... Just like that..."
    new "B:lis: Ótimo, vamos precisar de continuar a trabalhar nisso, mas estás a fazer um trabalho incrível."

    # say L237 lis
    old "You really have a big cock... It feels... Good."
    new "B:lis: Oh, sim... Assim mesmo..."

    # say L265 lis
    old "Oh, cum all over me."
    new "B: pla: Lisa, vou c- gozar..."

    # say L289 lis
    old "Feel the fire of the universe with each kiss, you must know the universe is healing your body."
    new "B:lis: Oh, goza todo em cima de mim."

    # say L290 pla
    old "Yeah, I can feel it."
    new "B:lis: Sente a chama do universo em cada beijo, tu deves saber que o universo está a curar o teu corpo."

    # say L294 lis
    old "I will do it more intense so you feel the healing power of the universe at its fullest expression."
    new "T(lis|tu|diz): Vou fazer com mais intensidade para que sintas o poder curativo do universo na sua expressão mais plena."

    # say L298 lis
    old "I will take that energy out."
    new "B:lis: Vou fazer com mais intensidade para que sintas o poder curativo do universo na sua expressão mais plena."

    # say L321 pla
    old "I- I'm goin-"
    new "B:lis: Vou tirar essa energia."

    # say L340 lis
    old "Oh [pla], what amazing energy you have."
    new "B:lis: Deixa fluir [pla], deixa fluir."

    # say L344 lis
    old "Oh yes, I'm feeling the universe through you..."
    new "A:lis: OH DEUS, PRECISO QUE SEJAS MAIS FORTE DENTRO DE MIM!"

    # say L348 lis
    old "OH GOD, I NEED IT HARDER INSIDE OF ME!"
    new "B:lis: Oh sim, estou a sentir o universo através de ti..."

    # say L371 lis
    old "Let all your energy cum inside me, I need to feel it."
    new "B:lis: OH DEUS, PRECISO QUE SEJAS MAIS FORTE DENTRO DE MIM!"

    # say L391 mik
    old "Ohh man, look at that, this is so fucking hot!"
    new "B:lis: Deixa toda a tua energia jorrar dentro de mim, preciso senti-la."

    # say L392 pla
    old "Hey, keep it down, they could hear you."
    new "B:mik: Ohh, meu Deus, olha isso, isto é tão quente!"

    # say L393 mik
    old "Alright, alright."
    new "B:pla: Ei, baixa a voz, eles podem ouvir-te."

    # say L397 mik
    old "God damn it! This is getting me on!"
    new "B:mik: Tudo bem, tudo bem."

    # say L398 pla
    old "Hey! Keep it down!"
    new "B:mik: Merda! Isto está a irritar-me!"

    # say L399 mik
    old "Listen, dude, do you think you could leave for a couple of minutes?"
    new "B:pla: Ei! Baixa a voz!"

    # say L400 pla
    old "What? Hell no! What the hell are you thinking?"
    new "B:mik: Ouve, mano, achas que podias sair durante uns minutos?"

    # say L404 mik
    old "Oh they're going faster! This is fucking amazing."
    new "B:pla: Que? Nem pensar! O que raio estás a pensar?"

    # say L405 pla
    old "I'm glad you like it man, but hey, we gotta go."
    new "T: Fico contente que gostes, mas hey, temos de ir."

    # say L406 mik
    old "Ohhh no, please just a little more, I think they're about to finish."
    new "B:pla: Fico contente que gostes, mas hey, temos de ir."

    # say L407 pla
    old "Hmm, alright."
    new "B:mik: Ohhh não, por favor, só mais um pouco, acho que eles estão quase a acabar."

    # say L430 mik
    old "Oh wow, that's the fucking best. I wasn't expecting that today."
    new "B:pla: Hmm, bem."

    # say L431 mik
    old "Thanks man."
    new "B:mik: Oh wow, isso é mesmo o melhor. Não estava à espera disso hoje."

    # say L432 pla
    old "No problem bro, but let's get out of here before they see us."
    new "T: Não há de quê, mano, mas vamos sair daqui antes que nos vejam."

    # say L444 lis
    old "Mmm, this is just what I needed."
    new "B:pla: Sem problemas, mano, mas vamos sair daqui antes que nos vejam."

    # say L449 pla
    old "{i}(I guess it has to do with her whole yoga thing.){/i}"
    new "B: pla: {i}(Que posição estranha para fazer isso.){/i}"

    # say L481 lis
    old "Ah! Ah! That's right!"
    new "B:lis: Oh! Oh sim!"

    # say L482 lis
    old "I can feel it! My Muladhara chakra is in full harmony!"
    new "B:lis: Ah! Ah! É isso mesmo!"

    # say L489 lis
    old "That was absolutely perfect!"
    new "B:lis: Eu sinto! O meu chakra Muladhara está em plena harmonia!"

    # say L490 lis
    old "And just what I needed, what a wonderful thing."
    new "T(lis|tu|dizes): E foi exactamente o que eu precisava, que coisa maravilhosa."

    # say L491 lis
    old "I can feel the energy flowing through my entire body."
    new "B:lis: E precisava mesmo disto, que maravilha."

    # say L492 lis
    old "I'm ready to continue my day now."
    new "Estou pronta para continuar o meu dia agora."


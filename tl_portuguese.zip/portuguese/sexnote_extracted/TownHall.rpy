# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/TownHall.rpy
translate portuguese strings:

    # menu L10 
    old "Talk"
    new "Falar"

    # say L11 sop
    old "Hello, Can I help you?"
    new "Olá, posso ajudar-te?"

    # say L12 pla
    old "Oh, no, sorry for bothering you."
    new "Hmm, Posso ajudar-te?"

    # say L37 sop
    old "Hmm, Can I help you?"
    new "Hmm, Posso ajudar-te?"


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Basement.rpy
translate portuguese strings:

    # say L16 mo2
    old "So? Are you ready to do something useful with your life?"
    new "Então? Estás pronto para fazer algo útil com a tua vida?"

    # say L18 pla
    old "Umm..."
    new "B:mo2: E então? Estás pronto para fazer algo útil com a tua vida?"

    # say L26 pla
    old "Sweet! You're going to teach me?"
    new "B:mo2: O que significa que esta é uma oportunidade para ti veres como ganhar algum dinheiro..."

    # say L28 mo2
    old "Oh, hell no! I'm not your damn teacher. Just do what I tell you. And watch what I do, then maybe you will learn on your own..."
    new "B:pla: Ótimo! Vais ensinar-me?"

    # say L30 pla
    old "Ok, ok... So what do you need me to do?"
    new "B:mo2: Oh, não! Não sou o teu maldito professor. Faz o que te digo. E observa o que faço, assim talvez aprendas por ti próprio..."

    # say L32 mo2
    old "First of all, I don't need you. I'm letting you work for me and learn."
    new "B:pla: Ok, ok... Então o que preciso fazer?"

    # say L34 mo2
    old "Secondly, if you try to peep on me at work or do something perverted, I will fire your ass. Understood?"
    new "B:mo2: Em primeiro lugar, não preciso de ti. Estou a deixar-te trabalhar para mim e aprender."

    # say L35 pla
    old "(This is going to be harder than I thought.)"
    new "B:mo2: Em segundo lugar, se tentares espreitar-me no trabalho ou fizeres algo pervertido, vais ser despedido. Entendido?"

    # say L37 pla
    old "Hey! I'm not a-"
    new "B:pla: (Isto vai ser mais difícil do que eu pensei.)"

    # say L39 mo2
    old "Shut up! Pervert!"
    new "B:pla: Ei! Eu não sou um-"

    # say L41 pla
    old "...Ok. So, you are my boss now and I will respect you... Is that better?"
    new "B:mo2: Cala-te! Tarado!"

    # say L47 mo2
    old "I need you to take these documents to my office and give them to the secretary. Then come back to me."
    new "B:pla: Ótimo. O que preciso fazer?"

    # say L49 pla
    old "As you wish."
    new "B:mo2: Preciso que leves estes documentos ao meu escritório e os entregues à secretária. Depois volta para mim."

    # say L64 pla
    old "Done! I already delivered the documents to Akita."
    new "B:pla: Como quiseres."

    # say L66 mo2
    old "Well, was that very difficult?"
    new "B:pla: Feito! Já entreguei os documentos a Akita."

    # say L68 pla
    old "Hmm, not really..."
    new "B:mo2: Bem, foi muito difícil?"

    # say L70 mo2
    old "Alright. Look for me tomorrow to take a new delivery to Akita..."
    new "B:pla: Hmm, não realmente..."

    # say L124 pla
    old "I must deliver the documents to Akita first."
    new "B:mo2: Tudo bem. Procura-me amanhã para levar uma nova entrega a Akita..."

    # say L131 mo2
    old "Are you ready to work today? I don't want any interruptions from you..."
    new "Pronto para trabalhar para ti."

    # menu L134 
    old "Ready to work for you"
    new "B:mo2: Estás pronto para trabalhar hoje? Não quero interrupções tuas..."

    # say L138 mo2
    old "Ok then, You know what to do. Take these documents to my secretary, then come back to me..."
    new "B:n: Pronto para trabalhar por ti"

    # say L140 pla
    old "Of course, [mo2]!"
    new "Claro, [mo2]!"

    # say L152 pla
    old "Actually, I have to do something first... I'll talk to you later."
    new "B:n: Agora não"

    # say L185 pla
    old "Uh... Nothing, I was just going to my bedroom, sorry."
    new "Uh... Nada, eu estava só a ir para o meu quarto, desculpa."


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/LisStory.rpy
translate portuguese strings:

    # say L9 mo2
    old "No! You are my sister, but it doesn't mean I will give you money for every stupid scheme you can think of. I have my own responsibilities..."
    new "Não! Tu és minha irmã, mas isso não significa que eu te vá dar dinheiro para cada esquema estúpido que te ocorra. Tenho as minhas próprias responsabilidades..."

    # say L10 lis
    old "But, I'm not asking you to give me money. Just lend me some or invest in my plan. This time what I have planned is sure to work..."
    new "B:mo2: Não! Tu és minha irmã, mas isso não significa que eu vou dar-te dinheiro para cada esquema estúpido que tu penses. Tenho as minhas próprias responsabilidades..."

    # say L11 mo2
    old "Really, Lisa? Do you think that a simple yoga academy is a million-dollar venture? "
    new "B:lis: Mas, não estou a pedir-te para me dar dinheiro. Apenas empresta-me algum ou investe no meu plano. Desta vez, o que tenho planeado vai certamente resultar..."

    # say L12 lis
    old "Well, maybe not a million, but I know it will help me pay off the debts I owe you."
    new "B:mo2: Realmente, Lisa? Achas que uma simples academia de ioga é um negócio de milhões?"

    # say L13 mo2
    old "You know what? I already gave too much of you. Get that money from some other sucker."
    new "B:lis: Bem, talvez não um milhão, mas sei que me ajudará a pagar as dívidas que te devo."

    # say L17 lis
    old "But... but..."
    new "B:mo2: Sabes o quê? Já dei demasiado de ti. Vai buscar esse dinheiro a outro trouxa."

    # say L23 lis
    old "Well, that won't stop me! I'm going to build my own yoga academy, with or without her help..."
    new "B:pla: Oh yeah... percebo o que queres dizer..."

    # say L24 pla
    old "That seems like a good idea..."
    new "B:lis: Bem, isso não me vai impedir! Vou construir a minha própria academia de ioga, com ou sem a ajuda dela..."

    # say L43 pla
    old "Hi, I am fine."
    new "Olá, estou bem."

    # say L44 pla
    old "You sure? I mean... I hope you're better."
    new "B:pla: Olá, estou bem."

    # say L45 lis
    old "Oh I see, you mean about me and my sister..."
    new "B:pla: Tens a certeza? Quero dizer... Espero que estejas melhor."

    # say L46 pla
    old "Hmm... Yeah."
    new "B:lis: Ah, percebo, tu estás a falar de mim e da minha irmã..."

    # say L47 lis
    old "You know my inner peace remains the same... I understand that she has her own business. I think that's the way the universe tells me I need to try by my own, because I know..."
    new "B:pla: Hmm... Sim."

    # say L48 lis
    old "I feel great things are coming, and I think this is the moment I can show the world what I am made of, and I know this is a dream today but it will soon be real."
    new "B:lis: Tu sabes que a minha paz interior permanece a mesma... Entendo que ela tem o seu próprio negócio. Acho que é assim que o universo me diz que preciso de tentar por mim própria, porque sei..."

    # say L49 lis
    old "If fate puts a dream in your heart is because it's meant to be."
    new "B:lis: Sinto que coisas grandes estão a chegar, e acho que este é o momento de mostrar ao mundo do que sou feito, e sei que isto é um sonho hoje, mas será real em breve."

    # say L52 lis
    old "It's ok, you should to learn a little more, why not learn meditation with me."
    new "B:lis: Se o destino põe um sonho no teu coração é porque é para ser."

    # say L53 lis
    old "You need to learn to find the perfect balance in your body and soul so you can be one with yourself along with the universe, to better feel and understand your purpose and of life itself."
    new "B:lis: Tudo bem, tu deves aprender um pouco mais, por que não aprendes meditação comigo?"

    # say L54 pla
    old "Hmm...  s- sure."
    new "B:lis: Tu precisas aprender a encontrar o equilíbrio perfeito no teu corpo e alma para te sentires em harmonia contigo mesmo e com o universo, para melhor sentires e compreenderes o teu propósito e o da vida em si."

    # say L55 lis
    old "You know what, I will go today and check the options at the mall to see if I could run my own yoga academy from there, I will find the perfect place and fill out all the paperwork."
    new "B:pla: Hmm... s-sim."

    # say L57 lis
    old "Yeah, but there is so much work to do, you know... The place, the rent, the equipment, the ambience, everything must flow with the same energy."
    new "B:lis: Sabes o que, vou hoje ao centro comercial ver as opções para poder ter a minha própria academia de ioga lá, vou encontrar o lugar perfeito e preencher toda a papelada."

    # say L58 lis
    old "Once I get all the info, I will have an idea about the budget."
    new "B:lis: Sim, mas há tanto trabalho a fazer, sabes... O local, o rendimento, o equipamento, a atmosfera, tudo tem de fluir com a mesma energia."

    # say L59 pla
    old "Hope you get all the info you need, good luck!"
    new "B:lis: Assim que tiver toda a informação, terei uma ideia sobre o orçamento."

    # say L77 pla
    old "Hi, Lisa, how are you?"
    new "B:pla: Espero que consigas toda a informação de que precisas, boa sorte!"

    # say L80 lis
    old "Well, [pla], I went to the mall, had a hard time finding the manager, but think it was just fate trying to save me from that pain."
    new "B:lis: Oh não [pla], acho que preciso repensar todo o meu projeto."

    # say L82 lis
    old "I'm so frustrated, I- I need to think of a different project..."
    new "B:lis: Quero dizer, a renda para um lugar muito pequeno era enorme, algo realmente fora do meu alcance, os requisitos para alugar o lugar são bastante stressantes."

    # say L83 lis
    old "But the worst part of that day was when I discovered THERE WAS a yoga academy, as if that wasn't enough it was also really close to the place I was looking at..."
    new "B:lis: Estou tão frustrada, eu- eu preciso pensar num projeto diferente..."

    # say L84 pla
    old "Wait what? So you will have to compete."
    new "B:lis: Mas a pior parte desse dia foi quando descobri que HADUMA academia de ioga, e para piorar, estava bem perto do lugar que eu estava a ver..."

    # say L85 lis
    old "Well, that academy was bigger than what I was thinking, I think they have been there for a while because there was a lot of people, it was so amazing, the place was radiant and beautiful..."
    new "B:pla: Espera aí? Então vais ter de competir."

    # say L87 lis
    old "Yeah, I immediately thought to myself I could be better than any of their instructors but clearly I can't compete with that company..."
    new "B:lis: Bem, essa academia era maior do que eu pensava, acho que eles já estão lá há algum tempo porque havia muita gente, foi incrível, o lugar estava radiante e bonito..."

    # say L88 pla
    old "I understand..."
    new "B:lis: Sim, pensei logo que poderia ser melhor do que qualquer um dos seus instrutores, mas claramente não consigo competir com essa empresa..."

    # say L89 lis
    old "Yeah, I think I need to be humble and to accept fate as it is..."
    new "B:pla: Entendo..."

    # say L90 pla
    old "But... There has to be something you can do..."
    new "B:lis: Sim, acho que preciso ser humilde e aceitar o destino como ele é..."

    # say L91 lis
    old "What are my options? There's nothing I can do."
    new "B:pla: Mas... Tem de haver alguma coisa que tu possas fazer..."

    # say L92 pla
    old "I mean, you can check different places, not just the mall."
    new "B:lis: Que opções tenho? Não há nada que eu possa fazer."

    # say L93 lis
    old "Hmm I don't know, I just need time to focus on a different idea."
    new "B:pla: Quero dizer, podes ver diferentes sítios, não só o centro comercial."

    # say L94 pla
    old "Sorry to hear you so frustrated, but you know what? You can count on me."
    new "B:lis: Hmm não sei, só preciso de tempo para focar numa ideia diferente."

    # say L95 lis
    old "Oh that's very sweet of you."
    new "B:pla: Desculpa ouvir-te tão frustrado, mas sabes o quê? Podes contar comigo."

    # say L96 pla
    old "I know you can get a yoga academy like you want, we just need to look for alternatives."
    new "B:lis: Oh, isso é muito gentil de tua parte."

    # say L97 lis
    old "I'll think about it, thanks for being so supporting, I appreciate your time."
    new "T: Vou pensar nisso, obrigada por seres tão compreensivo, aprecio o teu tempo."

    # say L98 pla
    old "It's ok, I just hope I can help."
    new "Olá, como-"

    # say L116 pla
    old "Hi, how-"
    new "B:pla: Tudo bem, só espero poder ajudar."

    # say L117 lis
    old "Hey! I needed to talk to you, I have great news!"
    new "B:pla: Olá, como-"

    # say L118 pla
    old "Wow, I can see you're feeling better now..."
    new "B:lis: Ei! Precisava falar contigo, tenho grandes notícias!"

    # say L120 lis
    old "I really am, last time we talked I was very down, but I started my daily meditation practice. While breathing I discovered some light within the darkness..."
    new "B:pla: Wow, consigo ver que estás melhor agora..."

    # say L122 lis
    old "While I was doing this yoga position to relax, I thought I was doing something wrong, then I corrected the position, I still wasn't sure what exactly was wrong..."
    new "B:lis: Estou mesmo, da última vez que falámos estava muito triste, mas comecei a praticar meditação diária. Enquanto respirava, descobri alguma luz no meio da escuridão..."

    # say L123 lis
    old "So I slightly moved my arms and legs to get the perfect position, I know it sounds a bit silly but, when I corrected the position, it felt like my body was in a different place..."
    new "B:lis: Enquanto fazia esta posição de ioga para relaxar, pensei que estava a fazer algo errado, depois corrigi a posição, mas ainda não tinha a certeza do que exatamente estava mal..."

    # say L125 lis
    old "I mean, sometimes meditation is not about knowing the Asanas but how you connect in the moment and the environment..."
    new "B:lis: Então, movi ligeiramente os meus braços e pernas para ficar numa posição perfeita, sei que pode parecer um pouco ridículo, mas quando ajustei a posição, senti como se o meu corpo estivesse num lugar diferente..."

    # say L126 lis
    old "It's not about how you follow the rules but how you connect your body and soul through exercise, do you understand?"
    new "B:lis: Quero dizer, às vezes a meditação não se trata de conhecer os Asanas, mas de como te conectas no momento e com o ambiente..."

    # say L127 pla
    old "Hmm... I think so."
    new "B:lis: Não se trata de seguir as regras, mas de conectar o corpo e a alma através do exercício, percebes?"

    # say L128 lis
    old "That was my reflection, I'm not a regular Yoga instructor, I mean this academy at the mall can have 10 teachers but I am no a regular teacher, yoga and meditation is part of my life..."
    new "B: pla: Hmm... Acho que sim."

    # say L130 lis
    old "For me, yoga is not just about the equipment or space, I don't need that so I can perform a good pranayama, those are things for a comfortable service experience."
    new "B:lis: Isso foi o meu reflexo, não sou instrutora de Yoga regular, quero dizer, esta academia no centro comercial pode ter 10 professores, mas eu não sou professora regular, yoga e meditação fazem parte da minha vida..."

    # say L131 lis
    old "My personal experience can't be beat because it's actually richer than any other yoga experience, I'm not selling a product! I'm sharing my own experience..."
    new "B:lis: Para mim, o ioga não se trata apenas de equipamento ou espaço, não preciso disso para realizar uma boa pranayama, essas são coisas para uma experiência de serviço confortável."

    # say L132 pla
    old "Very interesting."
    new "B:lis: A minha experiência pessoal não pode ser batida porque é realmente mais rica do que qualquer outra experiência de ioga, não estou a vender um produto! Estou a partilhar a minha própria experiência..."

    # say L133 lis
    old "And you were right..."
    new "B:pla: Muito interessante."

    # say L135 lis
    old "Yes! About the mall, my business can be run in a totally different place... In fact... I think... Since I don't need any special place, I can just have it at my own HOUSE."
    new "B:lis: E tu tinhas razão..."

    # say L136 pla
    old "That would be very convenient."
    new "T(pla|tu|say): Isso seria muito conveniente."

    # say L137 lis
    old "Here, my customers can experience a very close yoga training, focus on the intimate learning, no distractions, no rules, only the yoga experience I provide."
    new "B:pla: Isso seria muito conveniente."

    # say L139 lis
    old "Well, I will need to check how to obtain the necessary business permits and licenses."
    new "B:lis: Aqui, os meus clientes podem experimentar um treino de ioga muito próximo, focado no aprendizado íntimo, sem distrações, sem regras, apenas a experiência de ioga que eu proporciono."

    # say L140 pla
    old "I am sure that won't be any trouble."
    new "B:lis: Vou precisar de verificar como obter as licenças e autorizações necessárias."

    # say L141 lis
    old "Thank you for listening to me and giving me the support, I needed I appreciate it."
    new "A:pla: Na verdade, não fiz nada..."

    # say L142 pla
    old "I actually did nothi-"
    new "B:lis: Obrigada por me ouvires e me dares o apoio de que precisava. Aprecio muito."

    # say L143 lis
    old "Oh, by the way, let me show you some ideas I have for the yoga room."
    new "B:pla: Na verdade, não fiz nada..."

    # say L145 lis
    old "Please come, I'm sure you are going to like it too, I wasn't aware my house was so perfect for this."
    new "B:lis: Oh, por acaso, deixa-me mostrar-te algumas ideias que tenho para a sala de ioga."

    # say L146 pla
    old "Is it?"
    new "B:lis: Por favor, vem, tenho a certeza de que vais gostar, não sabia que a minha casa era tão perfeita para isto."

    # say L147 lis
    old "Yes, the second floor is big and a good area I can take advantage of."
    new "B:pla: É isso?"

    # say L155 pla
    old "Hmm, this room is pretty big."
    new "B:lis: Sim, o segundo andar é grande e uma boa área que posso aproveitar."

    # say L157 lis
    old "You see it? It is so private, very intimate, and full of silence, this place is perfect... I did not realize it was that big until I took out all the stuff... What do you think?"
    new "B:pla: Hmm, este quarto é bastante grande."

    # say L158 pla
    old "It is very nice and peaceful."
    new "B:lis: Tu vês? É tão privado, muito íntimo e cheio de silêncio, este lugar é perfeito... Não me apercebi que era tão grande até tirar todas as coisas... O que achas?"

    # say L159 lis
    old "Actually, it's going to be better, you know music, fragrances, all that it takes to meditate and find your inner peace."
    new "B:pla: É muito agradável e tranquilo."

    # say L160 pla
    old "Wow, you have your business almost running. If you need something, you can count on me anytime."
    new "B:lis: Na verdade, vai ser melhor, sabes, música, fragrâncias, tudo o que é preciso para meditar e encontrar a tua paz interior."

    # say L161 lis
    old "You're really sweet... I think I am ok-"
    new "B:pla: Wow, tu tens o teu negócio quase a funcionar. Se precisares de algo, podes contar comigo a qualquer altura."

    # say L162 lis
    old "Wait, you know what?..."
    new "B:lis: Tu és mesmo doce... Acho que estou bem-"

    # say L163 lis
    old "I was wondering yesterday, how a customer would feel, you know the place... The energy... I just want to have an idea how they could feel."
    new "B:lis: Espera, sabes o quê?..."

    # say L164 lis
    old "Would you like to help me? You just need to be like my ‘instructor' I will tell you step by step what to do... What do you think?"
    new "B:lis: Estava a pensar ontem, como um cliente se sentiria, sabes o sítio... A energia... Só quero ter uma ideia de como eles poderiam se sentir."

    # say L165 pla
    old "Hmm, I can help you sure..."
    new "B:lis: Queres ajudar-me? Só precisas de ser como o meu ‘instrutor’. Vou dizer-te passo a passo o que fazer... O que achas?"

    # say L166 lis
    old "Thank you, I will walk you through every single step so you can learn too."
    new "B:pla: Hmm, posso ajudar-te a certeza..."

    # say L167 lis
    old "Let's do a couple of regular exercises."
    new "B:lis: Obrigado, vou guiar-te em cada passo para que tu também aprendas."

    # say L172 lis
    old "First we will try something casual, this position is called ‘Utkatasana', it's quite focused on breathing and your legs so since you will be the trainer..."
    new "B:lis: Vamos fazer alguns exercícios normais."

    # say L173 lis
    old "I will do the position so please follow me, don't do the position with me but control the position from the back, helping me to keep my balance, you got it?"
    new "B:lis: Primeiro vamos tentar algo casual, esta posição chama-se ‘Utkatasana', foca-se bastante na respiração e nas tuas pernas, por isso, como tu vais ser a treinadora..."

    # say L176 lis
    old "Ok... Here we go, please put your hands on my waist."
    new "B:lis: Vou fazer a posição, então segue-me, não faças a posição comigo, mas controla-a a partir de trás, ajudando-me a manter o equilíbrio, percebeste?"

    # say L183 lis
    old "Like I said follow my movement, I will go down..."
    new "B:lis: Ok... Vamos lá, por favor, coloca as tuas mãos na minha cintura."

    # say L189 pla
    old "Sure..."
    new "B:lis: Como eu disse, segue o meu movimento, vou descer..."

    # say L192 lis
    old "You're keeping cool good, let's go up... Perfect."
    new "B:pla: Claro..."

    # say L199 lis
    old "Well, I can feel it positive, I can breathe perfectly, the light is quite good, do you feel comfortable?"
    new "B:lis: Estás a manter-te bem, vamos subir... Perfeito."

    # say L200 pla
    old "Yes, I feel nice."
    new "B:lis: Bem, sinto-me positiva, consigo respirar perfeitamente, a luz está bastante boa, sentes-te confortável?"

    # say L201 lis
    old "Well, that was very productive, I feel relaxed, don't forget to keep breathing."
    new "B:pla: Sim, sinto-me bem."

    # say L202 pla
    old "Sure, I'm focused."
    new "B:lis: Bem, isso foi muito produtivo, sinto-me relaxada, não te esqueças de continuar a respirar."

    # say L203 lis
    old "That's perfect, let's try a different pose..."
    new "T(lis|tu|say): Perfeito, vamos tentar uma pose diferente..."

    # say L210 lis
    old "Next one will be totally different it's on the floor, its name is ‘Upward Facing Dog', for this position your help is very important..."
    new "B:lis: Perfeito, vamos tentar uma pose diferente..."

    # say L211 lis
    old "Because you will help me with the effort applied to my back, so I'll lie down looking up, if you want to be more comfortable, please get on your needs."
    new "B:lis: O próximo será completamente diferente, está no chão, chama-se ‘Cão de Cara para Cima’. Para esta posição, a tua ajuda é muito importante..."

    # say L218 lis
    old "I really like this position, I can feel a lot of energies running through me."
    new "B:lis: Porque vais ajudar-me com o esforço aplicado às minhas costas, vou deitar-me de barriga para cima, se quiseres ser mais confortável, por favor, ajusta-te às tuas necessidades."

    # say L219 lis
    old "Ahh it's so relieving, please push a bit towards my shoulders."
    new "B:lis: Gosto muito desta posição, sinto muitas energias a fluir por mim."

    # say L232 lis
    old "Oh yeah, like that, this is very relaxing for me."
    new "B:lis: Ahh, é tão reconfortante, por favor, empurra um pouco em direção aos meus ombros."

    # say L233 pla
    old "(She looks very enticing... I need to focus.)"
    new "B:lis: Oh sim, assim, isto é muito relaxante para mim."

    # say L241 pla
    old "(Oh shit... I'm getting hard... Oh, please not now...)"
    new "B:pla: (Ela parece muito tentadora... Preciso me concentrar.)"

    # say L248 lis
    old "You are doing amazing."
    new "B: (Oh merda... Estou a ficar excitado... Oh, por favor, não agora...)"

    # say L250 lis
    old "I think this place is incredible to do this... I can't wait to bring the candles, the music... It'll be so perfect!"
    new "B:lis: Estás a fazer incrível."

    # say L251 lis
    old "Alright, we need to continue... Listen, the next position is amazing, it's one of the most interesting and very easy to learn."
    new "B:lis: Acho que este lugar é incrível para fazer isto... Mal posso esperar para trazer as velas, a música... Vai ser tão perfeito!"

    # say L257 lis
    old "This asana sequence is called ‘Extended Puppy Pose', it's really relaxing, so please pay attention..."
    new "B:lis: Tudo bem, precisamos continuar... Escuta, a próxima posição é incrível, é uma das mais interessantes e muito fácil de aprender."

    # say L259 pla
    old "W- what do you need me to do?"
    new "B:lis: Esta sequência de asanas chama-se ‘Puppy Pose Estendido’, é muito relaxante, por isso presta atenção..."

    # say L260 pla
    old "(I need to control myself or she will notice my hardon.)"
    new "B:pla: E-e o que preciso de fazer?"

    # say L261 lis
    old "Well... For this position the hips and legs are very important, so I will need you to push them, so I can stretch my back to the fullest..."
    new "B: (Preciso me controlar ou ela vai notar a minha ereção.)"

    # say L262 lis
    old "Please hold my waist behind me and help me keep my balance."
    new "B:lis: Bem... Para esta posição as ancas e as pernas são muito importantes, por isso vou precisar que tu as empurras, para eu poder alongar as costas ao máximo..."

    # say L264 pla
    old "(I hope she doesn't notice it.."
    new "B:lis: Por favor, segura a minha cintura por trás e ajuda-me a manter o equilíbrio."

    # say L271 lis
    old "Please try to rest your waist with mine, control your breathing too."
    new "B: pla: (Espero que ela não note...)"

    # say L281 lis
    old "I need to feel you firmly so I can rest my back and relax my body."
    new "B:lis: Por favor, tenta apoiar a tua cintura na minha e controla a tua respiração."

    # say L282 pla
    old "(Oh It feels so delicious.)"
    new "B:lis: Preciso sentir-te firmemente para poder descansar as minhas costas e relaxar o corpo."

    # say L284 lis
    old "Can push me harder, that way both of us will be able to the do exercise more intensely."
    new "B: pla: (Oh, sente-se tão delicioso.)"

    # say L292 lis
    old "Yes, just like that."
    new "B:lis: Podes empurrar-me mais forte, assim ambos conseguimos fazer o exercício com mais intensidade."

    # say L294 lis
    old "That was perfect... I think we are done!"
    new "B:lis: Sim, assim mesmo."

    # say L297 lis
    old "I like your enthusiasm but I think you can stop now."
    new "B:lis: Isso foi perfeito... Acho que já acabámos!"

    # say L303 pla
    old "OH!? Yes, I am sorry, I was... I... Was quite focused on the position."
    new "B:lis: Gosto do teu entusiasmo, mas acho que podes parar agora."

    # say L314 lis
    old "Oh that's fantastic, I'm sorry to interrupt you."
    new "B:pla: OH!? Sim, desculpa, eu estava... Eu... Bastante concentrada na posição."

    # say L315 pla
    old "(Phew, thank god, she didn't notice.)"
    new "B:lis: Oh, isso é fantástico, desculpa interromper-te."

    # say L316 pla
    old "Oh no, it's ok no worries."
    new "B:pla: (Ufa, graças a Deus, ela não notou.)"

    # say L317 lis
    old "Amazing, you did a wonderful job, I appreciate your commitment."
    new "B:pla: Oh não, tudo bem, não te preocupes."

    # say L318 pla
    old "No problem..."
    new "B:lis: Incrível, fizeste um excelente trabalho, aprecio o teu empenho."

    # say L319 lis
    old "I'm very surprised how our chakras get together so well... I am sure that is going to be the feeling I have with my customers."
    new "B:pla: Sem problemas..."

    # say L320 lis
    old "I'll let you rest, thank you so much for your help, I will keep meditating a little longer."
    new "B:lis: Estou muito surpreendida com como os nossos chakras se harmonizam tão bem... Tenho a certeza de que será a sensação que terei com os meus clientes."

    # say L321 lis
    old "If you want to learn more, I could give you a few more lessons."
    new "B:lis: Vou deixar-te descansar, obrigado pela tua ajuda, vou continuar a meditar um pouco mais."

    # say L322 pla
    old "... Alright... I'm gonna leave you, so you can practice more."
    new "B:lis: Se quiseres aprender mais, posso dar-te mais algumas aulas."

    # say L323 lis
    old "Thank you honey, see you later."
    new "B:pla:... Tudo bem... Vou deixar-te, para que possas praticar mais."

    # say L324 pla
    old "Have a good one."
    new "B:lis: Obrigada, amor, até logo."

    # say L328 pla
    old "(That was close... I think she didn't realize...)"
    new "B:pla: Que tenhas um bom dia."

    # say L351 lis
    old "[pla] the universe is doing its thing, everything going pretty well and guess what?"
    new "T(lis|tu|say): [pla] o universo está a fazer o seu trabalho, tudo a correr bastante bem e adivinha o quê?"

    # say L353 pla
    old "Oh... That's amazing."
    new "B:lis: Já tive alguns clientes; eles estão realmente felizes com a forma como fazemos as coisas."

    # say L354 lis
    old "Yes, but this is just the beginning, better things are coming."
    new "B:pla: Oh... Isso é incrível."

    # say L355 pla
    old "I am glad that you are very positive."
    new "B:lis: Sim, mas isto é apenas o começo, coisas melhores estão a chegar."

    # say L356 lis
    old "I am just thankful for everything the universe is preparing for me."
    new "B:pla: Fico contente que estejas muito positivo."

    # say L357 lis
    old "Actually, I need to ask you something, I don't want to do this but you're the one who would understand what I need."
    new "B:lis: Estou apenas grata por tudo o que o universo está a preparar para mim."

    # say L358 pla
    old "Hmm... What is this about?"
    new "B:lis: Na verdade, preciso te perguntar uma coisa, não quero fazer isso mas tu és a única que entenderia o que preciso."

    # say L359 lis
    old "Like I said the business is taking shape, I already have some customers, however I am very busy lately with paperwork to get the final license and all of that... You know..."
    new "B:pla: Hmm... Do que se trata?"

    # say L360 lis
    old "The thing is I have a new customer in the afternoon coming, she is very very enthusiastic and is quite interested on the yoga program."
    new "B:lis: Como eu disse, o negócio está tomando forma, já tenho alguns clientes, mas estou muito ocupado ultimamente com a papelada para obter a licença final e tudo mais... Tu sabes..."

    # say L362 lis
    old "Yeah, she paid for the entire course and I'm already planning her sessions."
    new "B:lis: A questão é que tenho uma nova cliente à tarde, ela está muito muito entusiasmada e bastante interessada no programa de ioga."

    # say L363 lis
    old "However the time frame she said she is available is exactly the same time I have a very important appointment..."
    new "B:lis: Sim, ela pagou por todo o curso e já estou a planear as sessões dela."

    # say L364 lis
    old "It's an interview to verify the information to approve the business. I already have all the documentation needed to legally open it..."
    new "B:lis: No entanto, o horário que ela disse estar disponível é exatamente o mesmo em que tenho um compromisso muito importante..."

    # say L365 lis
    old "But this is a temporary one, this interview  gives me the approval so... I do need your help now... If you can cover me, so I can attend it."
    new "B:lis: É uma entrevista para verificar as informações e aprovar o negócio. Já tenho toda a documentação necessária para abrir legalmente..."

    # say L366 pla
    old "Well... I think I can... But-"
    new "B:lis: Mas isto é temporário, esta entrevista dá-me a aprovação, por isso... Preciso da tua ajuda agora... Se puder cobrir-me, para eu poder ir."

    # say L367 lis
    old "Amazing! that is fantastic. The entire universe is making it possible once again, did you know you are being an instrument of the universe?"
    new "B:pla: Bem... Acho que consigo... Mas-"

    # say L368 pla
    old "M- me... ?"
    new "B:lis: Incrível! É fantástico. O universo está a tornar isto possível mais uma vez, sabias que estás a ser um instrumento do universo?"

    # say L369 lis
    old "Of course! I am very grateful... You cannot not imagine how important this is for me. You only need to help me with this session..."
    new "B: pla: M- me...?"

    # say L370 lis
    old "Since you have already done the basic yoga training with me you are the only one that can cover me, it's going to be the same routine."
    new "B:lis: Claro! Estou muito grato... Não podes imaginar o quanto isto é importante para mim. Só precisas de me ajudar com esta sessão..."

    # say L371 lis
    old "I know you are very intuitive and can do the session like we did before, I already checked with the customer and she is ok with that."
    new "B:lis: Como já fizeste o treino de ioga básico comigo, és a única que pode substituir-me, vai ser a mesma rotina."

    # say L373 lis
    old "Please reach me at home later, I am very sorry we won't have enough time to plan it but I am sure you will do great."
    new "T(lis|tu|diz): Por favor, passa por casa mais tarde, sinto muito mas não vamos ter tempo suficiente para planear, mas tenho a certeza de que vais fazer um ótimo trabalho."

    # say L374 pla
    old "Hmm ok, I'll be there on time."
    new "B:lis: Por favor, contacta-me em casa mais tarde, sinto muito mas não teremos tempo suficiente para planear isto, mas tenho a certeza de que vais fazer um ótimo trabalho."

    # say L375 lis
    old "Thank you so much... See you then."
    new "B:pla: Hmm ok, estarei lá a tempo."

    # say L376 pla
    old "No problem, bye."
    new "B:lis: Muito obrigado... Até logo."

    # say L393 pla
    old "(Oh my god, is Anastasia, What is she doing here.)"
    new "B: pla: Sem problemas, adeus."

    # say L400 pla
    old "G- good to see you too."
    new "A:lis: Oh... Então vocês já se conhecem?"

    # say L402 lis
    old "Oh... So do you guys already know each other?"
    new "B:pla: B- bom ver-te também."

    # say L410 ana
    old "Oh, that's very interesting, don't you think [pla]?"
    new "B:lis: Fico muito contente por vocês se entenderem, vou tentar voltar o mais rápido possível, entretanto [pla] vai ajudar-te com a primeira sessão, Anastasia."

    # say L414 lis
    old "I‘ve got the feeling this session will be really nice. Well guys, please enjoy the session, I will be back as soon as possible."
    new "B: pla: H- hum... Muito interessante..."

    # say L415 ana
    old "Bye bye Lisa."
    new "B:lis: Tenho a sensação de que esta sessão vai ser mesmo boa. Bem, pessoal, aproveitem a sessão, eu volto o mais rápido possível."

    # say L424 ana
    old "Finally we are alone. I am  very ready for the class."
    new "B:ana: Adeus Lisa."

    # say L425 pla
    old "Well... Yes, I- I thank you for coming today, we did prepare a very great Yoga session for you."
    new "B:ana: Finalmente estamos sozinhos. Estou muito pronta para a aula."

    # say L426 ana
    old "Oh, I like that, I wasn't expecting to have a very handsome trainer, it's going to be really fun."
    new "B:pla: Bem... Sim, eu- eu agradeço a tua vinda hoje, preparamos uma sessão de ioga muito especial para ti."

    # say L428 pla
    old "Why don't we go to the yoga room where it's more comfortable for the session."
    new "B:ana: Oh, gosto disso, não estava à espera de ter um treinador muito bonito, vai ser mesmo divertido."

    # say L437 pla
    old "This is going to be our yoga room, we hope you enjoy not only the lesson but also the finer details for this experience."
    new "B: pla: Porque não vamos para a sala de ioga onde é mais confortável para a sessão?"

    # say L438 ana
    old "It's beautiful, smells very nice."
    new "B:pla: Esta vai ser a nossa sala de ioga, esperamos que gostes não só da aula mas também dos pormenores que tornam esta experiência especial."

    # say L439 pla
    old "Every detail has been thought out to make your experience better."
    new "B:ana: É lindo, cheira muito bem."

    # say L440 ana
    old "You guys are doing it very well."
    new "B:pla: Cada detalhe foi pensado para melhorar a tua experiência."

    # say L441 pla
    old "Now, let's start with the lesson, so you can get to relax a bit more."
    new "B:ana: Vocês estão a fazer muito bem."

    # say L447 pla
    old "Alright, for the first position I will be behind you to help you keep your body balanced, and that way we can do the exercise properly."
    new "B:pla: Agora, vamos começar com a lição, para tu poderes relaxar um pouco mais."

    # say L448 ana
    old "That's perfect."
    new "B:pla: Para a primeira posição ficarei atrás de ti para te ajudar a manter o equilíbrio do corpo, e assim podemos fazer o exercício corretamente."

    # say L449 pla
    old "We will start straight up and then we will go down keeping the straight position and correct breathing."
    new "T: Vamos começar diretos e depois vamos descer mantendo a posição reta e a respiração correta."

    # say L460 pla
    old "Try to keep your thoughts focus on the exercise."
    new "B:pla: Vamos começar direto e depois vamos descer mantendo a posição reta e a respiração correta."

    # say L461 pla
    old "(Her butt is really big, I need to think of something different. She's so hot...)"
    new "B: pla: Tenta manter os teus pensamentos focados no exercício."

    # say L462 ana
    old "Am I doing it right?"
    new "B:pla: (O rabo dela é mesmo grande, preciso pensar em algo diferente. Ela é tão quente...)"

    # say L463 pla
    old "Yes... Delicious."
    new "B:ana: Estou a fazer bem?"

    # say L466 pla
    old "I- mean... Correct, yes, you are doing it correctly."
    new "B:pla: Sim... Delicioso."

    # say L467 ana
    old "Oh, thank you."
    new "B:pla: Quero dizer... Correto, sim, estás a fazê-lo corretamente."

    # say L468 pla
    old "Do you feel relaxed?"
    new "B:ana: Oh, obrigada."

    # say L469 ana
    old "Yes, I like it."
    new "A:pla: Foi bom, vamos parar agora e continuar depois, gostaste?"

    # say L470 pla
    old "It was good, we are going to stop now and continue with the following, did you like it?"
    new "T(pla|tu|say): Foi bom, vamos parar agora e continuar com o seguinte, gostaste?"

    # say L471 ana
    old "It was nice."
    new "B:pla: Foi bom, vamos parar agora e continuar depois, gostaste?"

    # say L477 pla
    old "I hope you feel calmer now... So, our next position will help with the balance of our energies..."
    new "B:ana: Foi agradável."

    # say L478 pla
    old "I'll need you to lie down on your stomach, first we will stretch your legs and back, raising your head up, later you will let it down to breathe again."
    new "B:pla: Espero que te sintas mais calmo agora... Então, a nossa próxima posição vai ajudar no equilíbrio das nossas energias..."

    # say L480 pla
    old "This position is quite demanding, I will be there to make sure you can focus more and make the most out of it."
    new "B:pla: Vais precisar de deitar-te de barriga para baixo, primeiro vamos alongar as tuas pernas e costas, levantando a cabeça, depois vais deixá-la cair para respirar novamente."

    # say L481 ana
    old "Sounds good!"
    new "B:pla: Esta posição é bastante exigente, vou estar aqui para garantir que consigas concentrar-te melhor e tirar o máximo proveito dela."

    # say L487 pla
    old "First relax and breathe while lying down in that position."
    new "B:ana: Ótimo!"

    # say L488 ana
    old "Hmm it feels good."
    new "B:pla: Primeiro, relaxa e respira enquanto estás deitada nessa posição."

    # say L489 pla
    old "Now you are going to stretch your arms and I'm going to press your shoulders back so you can tense your muscles, and tilt your head back."
    new "B:ana: Hmm, sinto-me bem."

    # say L503 pla
    old "(Wow... I can see her boobs!)"
    new "B: pla: Agora vais esticar os braços e eu vou empurrar os teus ombros para trás para que possas tensar os músculos, e inclinar a cabeça para trás."

    # say L504 pla
    old "(Oh no... I am getting a hardon again. Shit... I should act normal so she doesn't notice.)"
    new "B: pla: (Wow... Consigo ver os seios dela!)"

    # say L512 ana
    old "So... Like this?"
    new "B:pla: (Oh no... Estou a ficar com uma ereção outra vez. Merda... Devo agir normalmente para ela não reparar.)"

    # say L515 ana
    old "Are you getting distracted?"
    new "B:ana: Então... Assim?"

    # say L517 pla
    old "Oh no... I am ok... Let's breath a bit more."
    new "B:ana: Estás a ficar distraído?"

    # say L523 ana
    old "OH WOW!"
    new "B:pla: Oh não... Estou bem... Vamos respirar um pouco mais."

    # say L524 pla
    old "(Dammit she noticed it.)"
    new "B:ana: OH WOW!"

    # say L525 ana
    old "I thought you were a bit distracted but now I know you brought a bit of company, I think one of your muscles needs to relax a bit too..."
    new "B:pla: (Maldita seja, ela reparou.)"

    # say L526 pla
    old "I- am very sorry, please do not take me wrong way, I am... I am just very nervous."
    new "B:ana: Pensei que estavas um pouco distraído, mas agora percebi que trouxeste um pouco de companhia... Acho que um dos teus músculos também precisa de relaxar um pouco..."

    # say L529 ana
    old "It's totally ok, I feel very flattered and I like it... The effort makes you feel a bit stressed, I think since you are helping, I should help you too, so you can feel better."
    new "B:pla: Desculpa muito, por favor não me interpretes mal, eu estou... Estou apenas muito nervoso."

    # say L530 pla
    old "W- What? Oh no, of course not.. I think this is moment to finish the session."
    new "B:ana: É totalmente normal, sinto-me muito lisonjeada e gosto disso... O esforço deixa-te um pouco stressado, acho que como tu estás a ajudar, eu também devo ajudar-te, para que te sintas melhor."

    # say L531 ana
    old "I know you want it... I remember last time you enjoyed it with my hands, probably this time we can try with... I don't know, maybe my mouth?"
    new "B:pla: Q- Que? Oh não, claro que não... Acho que este é o momento de terminar a sessão."

    # say L532 pla
    old "... (What the fuck!)"
    new "B:ana: Eu sei que tu queres... Lembro-me da última vez que gostaste com as minhas mãos, talvez desta vez possamos tentar com... Não sei, talvez com a minha boca?"

    # say L533 ana
    old "Why don't you relax a bit, let me check it out on my own, I know you will like it... Let's open this sweet gift."
    new "B:pla:... (Que merda!)"

    # say L541 ana
    old "Wow, it's huge, things are getting better since last time, looks very tasty... Do you mind if I give it a taste?"
    new "B:ana: Por que não relaxas um pouco e deixas-me ver isto sozinha, sei que vais gostar... Vamos abrir este doce presente."

    # say L543 ana
    old "Let me take care of this now!"
    new "B:ana: Uau, é enorme, as coisas estão a melhorar desde a última vez, parece muito saboroso... Tu tens algum problema se eu lhe der um gosto?"

    # say L555 ana
    old "Did you like it?  You are not the only expert here, I am quite ready for this kind of 'exercises', how would you rate my performance?"
    new "B:ana: Deixa-me tratar disto agora!"

    # say L568 lis
    old "Hey guys, I'm finally here, did you guys finish already?"
    new "B:ana: Gostaste? Não és o único especialista aqui, estou bastante preparada para este tipo de 'exercícios', como classificarias o meu desempenho?"

    # say L569 pla
    old "(Oh god, for a few minutes early and she could have discovered us...)"
    new "B:lis: Ei, pessoal, finalmente cheguei, vocês já terminaram?"

    # say L570 ana
    old "Yes, it was very good. [pla] is the most wonderful partner I could ask for..."
    new "T: Sim, foi muito bom. [pla] é o parceiro mais maravilhoso que eu poderia pedir..."

    # say L572 lis
    old "Aww, that's dazzling... I appreciate your words."
    new "B:ana: Ele é muito agradável, mesmo que algumas posições tenham ficado muito difíceis, eu gosto muito!"

    # say L574 ana
    old "For sure, I know I will be coming very often, I didn't know it was so amusing, very ‘delicious', I was fully satisfied."
    new "B:lis: Aww, isso é deslumbrante... Aprecio as tuas palavras."

    # say L575 lis
    old "Sounds terrific... Wait, what's that on your face?"
    new "B:ana: Com certeza, sei que vou vir muito frequentemente, não sabia que era tão divertido, muito ‘delicioso', fiquei totalmente satisfeita."

    # say L577 ana
    old "Oh, what's that? Ahh, It must be sweat, you know this is kind of new for me-"
    new "B:lis: Soa fantástico... Espera, o que é isso na tua cara?"

    # say L578 lis
    old "Yeah, right."
    new "B:ana: Oh, o que é isso? Ah, deve ser suor, sabes que isto é um pouco novo para mim..."

    # say L579 ana
    old "But no worries, I will clean it in a moment, thank you."
    new "B:lis: Claro, está bem."

    # say L584 lis
    old "Bye bye, Anastasia."
    new "T: Adeus, Anastasia."

    # say L594 lis
    old "I really wanted to thank you, I know you weren't prepared enough but you actually did incredible, I am very embarrassed because it was all of the sudden for you to do it."
    new "B:lis: Adeus, Anastasia."

    # say L595 pla
    old "No problem, I am happy to be of help."
    new "B:lis: Queria mesmo agradecer-te, sei que não estavas preparado mas fizeste realmente um trabalho incrível, sinto-me muito embaraçado porque foi tudo de repente para ti."

    # say L596 lis
    old "I just want you to know that you're fantastic, you accomplished to do the session without the proper training..."
    new "B:pla: Sem problemas, estou feliz por poder ajudar."

    # say L597 lis
    old "I can see a great talent in you, I'm willing to teach you if want to know more, I hope I will not bother you again."
    new "B:lis: Só queria que soubesses que és fantástica, conseguiste fazer a sessão sem a formação adequada..."

    # say L598 pla
    old "Thank you very much, and don't worry you can ask me if you need more help."
    new "B:lis: Vejo um grande talento em ti, estou disposto a ensinar-te se quiseres saber mais, espero não te incomodar de novo."

    # say L599 lis
    old "Thank you honey, I appreciate your kindness."
    new "B:pla: Muito obrigado, e não te preocupes, podes perguntar-me se precisares de mais ajuda."

    # say L620 pla
    old "I am fine, thank you. How about you?"
    new "Estou bem, na verdade estou um pouco preocupada..."

    # say L621 lis
    old "I am well, actually I'm kind of concerned..."
    new "T(lis|tu|diz): Estou bem, na verdade estou um pouco preocupado..."

    # say L622 pla
    old "Why is that?"
    new "B:lis: Estou bem, na verdade estou um pouco preocupada..."

    # say L623 lis
    old "To be honest, I think you're better than what I thought, Anastasia was really pleased with your job last time, so she wants to continue the program with you..."
    new "B:pla: Porquê?"

    # say L624 pla
    old "A- Anastasia?"
    new "B:lis: Para ser honesto, acho que tu és melhor do que eu pensava, a Anastasia ficou realmente satisfeita com o teu trabalho da última vez, por isso quer continuar o programa contigo..."

    # say L625 lis
    old "Yes, however, my concern is... I didn't want to ask you again, however since Anastasia is asking for you, I want her to have the best experience..."
    new "B:pla: A- Anastasia?"

    # say L626 lis
    old "Of course the decision hasn't been made yet, I explained to her I needed to discuss it with you first, before I could say yes or no, so I just wanted to let you know."
    new "B:lis: Sim, no entanto, a minha preocupação é... não queria pedir-te de novo, mas como a Anastasia está a pedir-te, quero que ela tenha a melhor experiência..."

    # say L628 lis
    old "Last time you helped me but since this is going to be a more frequent assistances, I am thinking you can be part of the business and you will have an income..."
    new "B:lis: Claro que a decisão ainda não foi tomada, expliquei-lhe que precisava de discutir contigo antes de poder dizer sim ou não, por isso só queria informar-te."

    # say L629 lis
    old "It will also bring positive things to your life, making it part of this new way of living. You know the more that you feel the universe the better you can share with others."
    new "B:lis: Da última vez ajudaste-me, mas como isto vai ser uma assistência mais frequente, estou a pensar que podes fazer parte do negócio e terás uma renda..."

    # say L630 lis
    old "I will give you the proper training, so you'll have the knowledge you need, we can make the business grow together, I know other customers will love your job too."
    new "B:lis: Isso também trará coisas positivas à tua vida, fazendo parte desta nova forma de viver. Sabes que quanto mais sentes o universo, melhor podes partilhar com os outros."

    # say L631 pla
    old "I appreciate you considering me as an option, I will gladly help you."
    new "B:lis: Vou dar-te a formação adequada, para que tenhas os conhecimentos necessários, podemos fazer crescer o negócio juntos, sei que os outros clientes também vão adorar o teu trabalho."

    # say L633 pla
    old "Don't worry, I'm glad to help."
    new "T: Não te preocupes, fico contente em ajudar."

    # say L634 lis
    old "Actually, are you too busy right now?"
    new "B:pla: Não te preocupes, estou contente em ajudar."

    # say L635 pla
    old "You mean now? I think I can stay for a while, why do you ask?"
    new "B:lis: Na verdade, estás muito ocupado agora?"

    # say L636 lis
    old "It's because we can go ahead with a practice today the next session you will have with Anastasia."
    new "B:pla: Quer dizer agora? Acho que posso ficar um bocado, porquê?"

    # say L637 pla
    old "Oh, I see, sounds good."
    new "B:lis: É porque podemos avançar com uma prática hoje na próxima sessão que terás com Anastasia."

    # say L638 lis
    old "Perfect, let's go."
    new "B:pla: Oh, percebo, parece bom."

    # say L646 lis
    old "Now let's get ready to start, please remember to control your breathing so we can make the most out of the exercise."
    new "B:lis: Perfeito, vamos lá."

    # say L648 lis
    old "Since the previous positions  you worked with her were more aimed to release stress and anxiety, this time we will get more into the yoga world, so you can discover more sensations."
    new "B:lis: Agora vamos preparar-nos para começar, lembra-te de controlar a tua respiração para tirarmos o máximo proveito do exercício."

    # say L650 lis
    old "The first position we will work on is extremely demanding, you need to be very careful so you can give the right directions..."
    new "B:lis: Como as posições anteriores que trabalhaste com ela estavam mais focadas em aliviar o stress e a ansiedade, desta vez vamos mergulhar mais no mundo do ioga, para que possas descobrir novas sensações."

    # say L651 lis
    old "Depending on you the customer can feel more energy coming thru."
    new "B:lis: A primeira posição que vamos trabalhar é extremamente exigente, precisas de ser muito cuidadoso para poder dar as direções certas..."

    # say L652 pla
    old "Ok, what... Do I need to do?"
    new "B:lis: Dependendo de ti, o cliente pode sentir mais energia a passar."

    # say L653 lis
    old "For the position, we will focus on the back, You will make sure I can get the perfect position, I will be on my hands and feet, looking straight."
    new "B:pla: Ok, o que... Preciso de fazer?"

    # say L654 lis
    old "You need to help stretch the back by applying some pressure on the hips, Initially the weight of the body will be on the arms..."
    new "B:lis: Para a posição, vamos focar nas costas. Tu vais garantir que eu fico na posição perfeita, de mãos e pés no chão, olhando para a frente."

    # say L655 lis
    old "After some seconds we will need to change and apply it to the legs, you need to help the customer lift the hips and now firmly apply pressure with your pelvis."
    new "B:lis: Precisas de ajudar a alongar as costas aplicando alguma pressão nas ancas, inicialmente o peso do corpo estará nos braços..."

    # say L664 lis
    old "We will need to repeat that movement several times, watch your breathing and making sure the position is being done properly. Got it?"
    new "B:lis: Daqui a alguns segundos teremos de mudar e aplicar na pernas, precisas de ajudar o cliente a levantar as ancas e agora aplicar pressão com firmeza com o teu quadril."

    # say L666 lis
    old "Perfect, let's try it."
    new "B:lis: Vamos ter de repetir esse movimento várias vezes, presta atenção à tua respiração e certifica-te de que a posição está a ser feita corretamente. Entendido?"

    # say L673 lis
    old "That's it... You are doing it right."
    new "B:lis: Perfeito, vamos experimentar."

    # say L674 pla
    old "(Oh god this is quite enticing, I will need to touch her butt to grab her hips...)"
    new "B:lis: É isso... Estás a fazer bem."

    # say L675 lis
    old "Don't forget to hold the hips firmly, the muscle must be exercised."
    new "B:pla: (Oh god, isto é bastante tentador, vou ter de tocar no rabo dela para agarrar as ancas...)"

    # say L676 pla
    old "(If I do it any harder, I'll touch her pussy.)"
    new "B:lis: Não te esqueças de segurar as ancas com firmeza, o músculo tem de ser exercitado."

    # say L677 pla
    old "Don't worry... I will do it."
    new "B: pla: (Se eu fizer com mais força, vou tocar na tua xoxota.)"

    # say L678 lis
    old "Perfect, that will help us to ensure the customer is getting the right position."
    new "B:pla: Não te preocupes... Eu vou fazer isso."

    # say L679 lis
    old "That was very good, you are doing good. Now let's move to the second position."
    new "B:lis: Perfeito, isso vai ajudar a garantir que o cliente está na posição certa."

    # say L685 pla
    old "Good! What's up with this one?"
    new "B:lis: Isso foi muito bom, estás a fazer bem. Agora vamos passar para a segunda posição."

    # say L686 lis
    old "As you can imagine, we need to increase the difficulty, for the next position your help is essential, I will relax my entire body, you will hold my hips..."
    new "B:pla: Ótimo! E este aqui?"

    # say L687 lis
    old "The first step will be to carry my body weight, you can support yourself with your pelvis, however I understand that could be very tiring, that is why we'll have some tiny breaks."
    new "B:lis: Como podes imaginar, precisamos de aumentar a dificuldade, para a próxima posição a tua ajuda é essencial, vou relaxar todo o meu corpo, tu vais segurar as minhas ancas..."

    # say L688 lis
    old "Since you are using your pelvis, the breaks moment will be to relax your pelvis and let the weight remain on the customers arms and your legs."
    new "B:lis: O primeiro passo será suportar o meu peso, podes apoiar-te na tua bacia, mas percebo que isso pode ser muito cansativo, por isso faremos algumas pausas curtas."

    # say L689 pla
    old "Ok, sounds a bit difficult."
    new "B:lis: Como estás a usar o teu quadril, o momento de pausa será relaxar o quadril e deixar o peso repousar nos braços dos clientes e nas tuas pernas."

    # say L690 lis
    old "Not really... However, that is why you need to keep breathing and stay focused so you can use your strength smartly and make the exercise enjoyable for you too."
    new "B:pla: Ok, parece um pouco difícil."

    # say L692 lis
    old "Let's do it! Now that you have the idea."
    new "B:lis: Não realmente... No entanto, é por isso que precisas de continuar a respirar e manter-te focado para usares a tua força de forma inteligente e tornares o exercício agradável para ti também."

    # say L693 pla
    old "Sure, go ahead."
    new "B:lis: Vamos lá! Agora que tens a ideia."

    # say L699 lis
    old "Use your chakras to control your breathing that is the key for a position like this."
    new "T(lis|tu|say): Usa os teus chakras para controlar a tua respiração, isso é a chave numa posição destas."

    # say L708 pla
    old "Sure, I am breathing deeply and consciously."
    new "B:lis: Usa os teus chakras para controlar a tua respiração, isso é a chave para uma posição como esta."

    # say L709 lis
    old "I am very satisfied to hear that, try to use all your energy."
    new "B:pla: Claro, estou a respirar profundamente e conscientemente."

    # say L710 pla
    old "(This feels very delectable, she's rubbing my cock... I'm getting hard now...)"
    new "B:lis: Estou muito satisfeita por ouvir isso, tenta usar toda a tua energia."

    # say L713 lis
    old "You need to focus too, so the exercise can be effective."
    new "B: pla: (Isto sente-se muito delicioso, ela está a esfregar o meu pénis... Estou a ficar excitado...)"

    # say L715 lis
    old "Keep doing that for a while with your customer, we will stop for now so we can continue with our next position, I can see you learn very fast."
    new "B:lis: Tu também precisas de te concentrar, para que o exercício seja eficaz."

    # say L716 pla
    old "(Oh, thanks god!)..."
    new "B:lis: Continua a fazer isso por um bocado com o teu cliente, vamos parar por agora para continuarmos com a próxima posição, vejo que aprendes muito depressa."

    # say L722 pla
    old "(I don't know if I will be able to hide my boner this time.)"
    new "B: pla: (Oh, graças a Deus!)..."

    # say L723 lis
    old "The last position is quite interesting, is related with the energies we have accumulated in the back, we will need to ignite them so we can release more of our chakra's potential..."
    new "B:pla: (Não sei se vou conseguir esconder a minha ereção desta vez.)"

    # say L724 lis
    old "Since they are located in your back right before the gluteus,the position is aimed to get those points. Your customer will probably need you to get in that position."
    new "B:lis: A última posição é bastante interessante, está relacionada com as energias que acumulamos nas costas. Vamos precisar ativar essas energias para liberar mais do potencial dos nossos chakras..."

    # say L725 lis
    old "I will lie down on my shoulders, but I will hold my waist with my hands, my arms are going to be the main support."
    new "B:lis: Como estão localizados nas tuas costas, logo antes do glúteo, a posição visa atingir esses pontos. O teu cliente provavelmente vai precisar que tu entres nessa posição."

    # say L727 lis
    old "You will keep balance of the body as well as the pressure needed in two different points, the legs and back of the customer."
    new "B:lis: Vou deitar-me de costas, mas vou segurar a tua cintura com as mãos, os meus braços vão ser o principal apoio."

    # say L728 lis
    old "Let's start the position so you can have a better idea..."
    new "B:lis: Vais manter o equilíbrio do corpo bem como a pressão necessária em dois pontos diferentes, as pernas e as costas do cliente."

    # say L729 pla
    old "(This position looks demanding so I will stay focused, I need to breath and to think something different.)"
    new "B:lis: Vamos começar a posição para tu teres uma melhor ideia..."

    # say L730 pla
    old "Perfect, I am ready."
    new "B: pla: (Esta posição parece exigente, então vou manter-me concentrado, preciso respirar e pensar em algo diferente.)"

    # say L731 lis
    old "Perfect here we go..."
    new "B:pla: Perfeito, estou pronta."

    # say L738 pla
    old "(Oh no, this position is making me feel very horny, I am sure she will notice pretty soon.)"
    new "B:lis: Perfeito, aqui vamos nós..."

    # say L739 lis
    old "Are you breathing properly, remember this is important for you to be able to assist your customer."
    new "B:pla: (Oh não, esta posição está a deixar-me muito excitada, tenho a certeza de que ela vai reparar em breve.)"

    # say L740 pla
    old "Hmm... Sure, yes."
    new "B:lis: Estás a respirar corretamente, lembra-te que isto é importante para poderes ajudar o teu cliente."

    # say L743 lis
    old "I can see you are quite motivated with this asana, you will need to control your energies so you can decide how to express or attract with your body."
    new "B:pla: Hmm... Claro, sim."

    # say L745 lis
    old "Alright, I think we are done..."
    new "B:lis: Posso ver que estás bastante motivada com esta asana, vais precisar de controlar as tuas energias para poderes decidir como expressar ou atrair com o teu corpo."

    # say L757 lis
    old "OH MY GOD!"
    new "B:lis: Tudo bem, acho que já terminamos..."

    # say L769 pla
    old "I- I'm sorry, I'm so sorry these positions are really enticing... A- and I can't help it."
    new "B:lis: OH MY GOD!"

    # say L770 lis
    old "Don't worry, it's natural, I just got surprised by the... Size..."
    new "B: ZZZ…ZZZ: I- Desculpa, estou tão arrependido, estas posições são mesmo tentadoras... A- e não consigo resistir."

    # say L772 lis
    old "Well, this happened because your chakras are unbalanced."
    new "B:lis: Não te preocupes, é natural, só fiquei surpreendida com o... Tamanho..."

    # say L773 pla
    old "My cha- kras?"
    new "B:lis: Bem, isto aconteceu porque os teus chakras estão desequilibrados."

    # say L774 lis
    old "Yes, I think you need to reharmonize your chakra ‘Muladhara', this is the sexual chakra and is clearly unbalanced in you."
    new "B:pla: A mi- kras?"

    # say L775 lis
    old "But, don't worry, once you harmonize your chakra Muladhara, you will be more stable, and you will be able to prevent these unexpected body reactions."
    new "B:lis: Sim, acho que precisas de reharmonizar o teu chakra ‘Muladhara’, este é o chakra sexual e está claramente desequilibrado em ti."

    # say L777 lis
    old "I think you need to work on that, we can do some tantric rituals so you can restore your chakras to their natural energy."
    new "B:lis: Mas, não te preocupes, uma vez que harmonizes o teu chakra Muladhara, vais ser mais estável e vais conseguir prevenir estas reações corporais inesperadas."

    # say L778 pla
    old "A tantric what?"
    new "B:lis: Acho que precisas trabalhar nisso, podemos fazer alguns rituais tântricos para restaurar as tuas chakras à sua energia natural."

    # say L779 lis
    old "Tantric rituals, it's a very spiritual technique where we clean your chakras. I think we should do it tonight."
    new "T(lis|tu|say): Rituals tântricos, é uma técnica muito espiritual onde limpamos os teus chakras. Acho que devíamos fazê-lo hoje à noite."

    # say L780 pla
    old "T- tonight?"
    new "B:lis: Rituals tântricos, é uma técnica muito espiritual onde limpamos os teus chakras. Acho que devíamos fazê-lo esta noite."

    # say L781 lis
    old "Yes, I need to prepare a few things for the ritual, And you need to balance your chakras before your next yoga session with Anastasia."
    new "B:pla: T- esta noite?"

    # say L782 lis
    old "We don't want you to have this kind of... Reactions with her, don't we?"
    new "B:lis: Sim, preciso de preparar algumas coisas para o ritual, e tu precisas de equilibrar os teus chakras antes da próxima sessão de ioga com Anastasia."

    # say L783 pla
    old "Hmm... No, no, of course not... No."
    new "B:lis: Não queremos que tenhas este tipo de... Reações com ela, não é?"

    # say L784 lis
    old "Ok, then I'll make the preparations for our tantric ritual."
    new "B:pla: Hmm... Não, não, claro que não... Não."

    # say L786 lis
    old "It was nice to practice with you today! See you later."
    new "B:lis: Ok, então faço os preparativos para o nosso ritual tântrico."

    # say L787 pla
    old "See you then."
    new "T(pla|tu|say): Até logo."

    # say L806 pla
    old "Wow... W- what are you... W- wearing?"
    new "B:pla: Até logo."

    # say L817 lis
    old "Everything is set in this room so we can cleanse those energies and balance your chakras..."
    new "B:lis: Vamos para o quarto, assim posso explicar tudo a ti..."

    # say L818 lis
    old "I hope you can take advantage of the lights, the fragrances, as well as the location, we are about to do a very important ritual, so every single detail must help us get in the mood."
    new "B:lis: Tudo está preparado nesta sala para purificar essas energias e equilibrar os teus chakras..."

    # say L819 lis
    old "Please I need you to open your mind so the exercises we do tonight will be more effective..."
    new "B:lis: Espero que aproveites as luzes, os aromas, bem como o local, vamos realizar um ritual muito importante, por isso cada detalhe deve ajudar-nos a entrar no clima."

    # say L820 lis
    old "Some of the exercises of the ritual will have a lot of contact so please let the massages follow its course, it is a very spiritual process."
    new "B:lis: Por favor, preciso que abras a mente para que os exercícios que faremos esta noite sejam mais eficazes..."

    # say L821 pla
    old "M- massages?"
    new "B:lis: Alguns dos exercícios do ritual terão muito contacto, por isso deixa que as massagens sigam o seu curso, é um processo muito espiritual."

    # say L822 lis
    old "We need to compenetrate each other today so I can balance right your chakras."
    new "B:pla: M- massagens?"

    # say L824 lis
    old "I did some meditation today so the massages can be very deep and productive for you so please merge with me to have a great experience."
    new "B:lis: Precisamos de nos compenetrar hoje para eu poder equilibrar os teus chakras."

    # say L826 lis
    old "It's a very beautiful way to perceive what surrounds you, so you need to express according to the energies that you will be able to recognize... Let's start."
    new "B:lis: Fiz meditação hoje para que as massagens possam ser muito profundas e produtivas para ti, por isso junta-te a mim para termos uma experiência incrível."

    # say L828 lis
    old "First, I need you to undress so we can uncover our energies."
    new "B:lis: É uma maneira muito bonita de perceber o que te rodeia, por isso precisas de expressar-te de acordo com as energias que conseguires reconhecer... Vamos começar."

    # say L829 pla
    old "U- undress?"
    new "B:lis: Primeiro, preciso que te despajes para podermos revelar as nossas energias."

    # say L830 lis
    old "Yes, please don't take it the wrong way, this is a very pure experience so I need you to undress not only the clothes but also your mind and soul."
    new "B: Despe-te?"

    # say L831 lis
    old "Keep in mind your body is something beautiful and it doesn't make you feel embarrassed, it's natural as universe is and we are going beyond to see how to control its energy."
    new "B:lis: Sim, por favor, não interpretes mal, esta é uma experiência muito pura, por isso preciso que te despogues não só das roupas mas também da mente e da alma."

    # say L838 lis
    old "Let's keep working on our breathing, remember the pranayama, we need to concentrate so you can open your senses, that is the main purpose of this exercise today."
    new "B:lis: Lembra-te que o teu corpo é algo bonito e não te deve fazer sentir embaraçada, é tão natural como o universo, e estamos a ir além para ver como controlar a sua energia."

    # say L839 pla
    old "Hmm, sure..."
    new "B:lis: Vamos continuar a trabalhar na nossa respiração, lembra-te da pranayama, precisamos de nos concentrar para que possas abrir os teus sentidos, esse é o principal objetivo deste exercício hoje."

    # say L840 lis
    old "I need you to concentrate, smell the candles, the ambience we have for this moment, do you feel the fragrance?"
    new "T(lis|tu|say): Preciso que te concentres, cheires as velas, a atmosfera que criámos para este momento, sentes o aroma?"

    # say L841 pla
    old "Yes, it smells nice."
    new "B:lis: Preciso que te concentres, cheires as velas, a atmosfera que criámos para este momento, sentes o aroma?"

    # say L842 lis
    old "Great!, now please lie down with your stomach on the floor, then relax, I will do the massage, you will feel my body helping yours to open your senses."
    new "B:pla: Sim, cheira bem."

    # say L851 lis
    old "let me start with your shoulders, so you can feel more."
    new "B:lis: Ótimo!, agora deita-te com o estômago no chão, depois relaxa, vou fazer a massagem, vais sentir o meu corpo a ajudar o teu a abrir os sentidos."

    # say L853 lis
    old "Please hold your breath a bit more, so we can intensify the fragrance and focus your thoughts."
    new "B:lis: Vou começar pelos teus ombros, para que possas sentir mais."

    # say L857 lis
    old "Good, do you feel my touch, my skin... How do you feel?"
    new "B:lis: Segura a respiração um pouco mais, para intensificarmos o perfume e concentrarmos os pensamentos."

    # say L858 pla
    old "It's very soft."
    new "B:lis: Ótimo, sentes o meu toque, a minha pele... Como te sentes?"

    # say L859 lis
    old "That's perfect, you are doing good."
    new "B:pla: É muito macio."

    # say L873 lis
    old "Let me touch your skin now so we can release the pressure, breath with me, it's just one pace, don't stop..."
    new "B:lis: Is perfeito, estás a fazer bem."

    # say L875 lis
    old "Feel free to express and feel everything your body wants to feel at this moment, I will control everything so you can go freely wherever your mind wants."
    new "B:lis: Deixa-me tocar na tua pele agora para podermos libertar a pressão, respira comigo, é só um ritmo, não pares..."

    # say L876 lis
    old "Try harder to focus, it's just this moment, there is nothing else to think about, but the sensations, can you smell it?"
    new "B:lis: Sente-te à vontade para expressar e sentir tudo o que o teu corpo deseja neste momento, eu vou controlar tudo para que tu possas ir livremente aonde a tua mente quiser."

    # say L877 pla
    old "Yes, I can."
    new "B:lis: Tenta concentrar-te melhor, é só neste momento, não há mais nada para pensar além das sensações, consegues cheirar?"

    # say L888 pla
    old "I feel amazing, I appreciate your time and effort to help me."
    new "B:pla: Sim, posso."

    # say L889 lis
    old "Oh no, it's no trouble, I'm just an instrument from the universe to help you with your energies."
    new "B: pla: Sinto-me incrível, agradeço o teu tempo e esforço para me ajudar."

    # say L890 lis
    old "Just relax and please keep learning so you can apply all your knowledge to the sessions with your customers. I am sure now you won't have these issues with Anastasia."
    new "B:lis: Oh não, não é nenhum problema, sou apenas um instrumento do universo para te ajudar com as tuas energias."

    # say L891 lis
    old "I can also feel a different aura on you now, I can feel your spirit is more calmed."
    new "B:lis: Só relaxa e continua a aprender para poder aplicar todo o teu conhecimento nas sessões com os teus clientes. Tenho a certeza de que agora não vais ter esses problemas com a Anastasia."

    # say L892 pla
    old "Thank you for all that you have done."
    new "B:lis: Também sinto uma aura diferente em ti agora, sinto que o teu espírito está mais calmo."

    # say L893 lis
    old "It's something I enjoy, please have some rest."
    new "B:pla: Obrigado por tudo o que fizeste."

    # say L894 pla
    old "I'll do it, have a great one too."
    new "B:lis: É algo que gosto, por favor descansa."

    # say L918 lis
    old "Oh don't worry, you are just on time."
    new "B:pla: Olá, desculpa se estou atrasado."

    # say L919 lis
    old "How do you feel today, are you ready to have the second session with Anastasia?"
    new "B:lis: Não te preocupes, estás a tempo."

    # say L920 pla
    old "Yes, I've been thinking about it."
    new "B:lis: Como te sentes hoje, estás pronto para ter a segunda sessão com Anastasia?"

    # say L921 lis
    old "Perfect, Well guys I am glad to see you both, I know you are working hard and improving!"
    new "B:pla: Sim, tenho estado a pensar nisso."

    # say L922 lis
    old "How about you Anastasia, how do you feel today?"
    new "B:lis: Perfeito, bem, estou contente por ver vocês dois, sei que estão a trabalhar duro e a melhorar!"

    # say L926 lis
    old "Perfect, I will leave you guys alone so you can do the session with no inconveniences. I will be here to give you proper privacy."
    new "B:pla: I- Tenho a certeza de que isto vai... vai ser uma boa sessão."

    # say L927 lis
    old "The room is already prepared."
    new "B:lis: Perfeito, vou deixar-vos sozinhos para que possam fazer a sessão sem inconvenientes. Vou estar aqui para vos dar a devida privacidade."

    # say L929 lis
    old "Anastasia I hope you enjoy your session you will be in good hands."
    new "B:lis: O quarto já está preparado."

    # say L931 ana
    old "Yes, I'm pretty sure he's really good with his hands, I'll enjoy the session."
    new "B:lis: Anastasia, espero que gostes da sessão, vais estar em boas mãos."

    # say L932 lis
    old "Aww, I love that energy, please work hard... See you guys."
    new "B:ana: Sim, tenho a certeza de que ele é muito bom com as mãos, vou aproveitar a sessão."

    # say L933 pla
    old "... See you."
    new "A:pla: Bem, hoje continuaremos o processo de meditação, lembra-"

    # say L947 pla
    old "Well, Today we will continue the meditation process, remem-"
    new "B: pla:... Até logo."

    # say L948 ana
    old "I wanted to- sorry to interrupt you..."
    new "B:pla: Bem, hoje vamos continuar o processo de meditação, lembra-"

    # say L949 pla
    old "Oh, it's ok, tell me."
    new "B:ana: Queria... desculpa interromper-te..."

    # say L950 ana
    old "It is just that... I wanted to try something different today, you know."
    new "T(ana|tu|say): É só que... queria experimentar algo diferente hoje, sabes."

    # say L951 pla
    old "Hmm... What did you have in mind?"
    new "B:ana: É só que... eu queria experimentar algo diferente hoje, sabes."

    # say L952 ana
    old "Well being honest, I was kind of distracted, I was not able to forget about your cock... And I want you to fuck me with that big hard cock."
    new "B:pla: Hmm... O que tens em mente?"

    # say L953 pla
    old "(WHAT THE FUCK!)"
    new "B:ana: A ser sincera, estava um bocado distraída, não conseguia deixar de pensar no teu pénis... E quero que me fodes com esse pénis grande e duro."

    # say L954 pla
    old "WHAT? B- but, we need to have a yoga session..."
    new "B:pla: (QUE RAIO!)"

    # say L955 ana
    old "The truth is I am very horny today, I came considering to have sex with you..."
    new "B:pla: O QUÊ? B- mas, precisamos ter uma sessão de ioga..."

    # say L961 ana
    old "Oh, it seems like you're getting ready... Why don't you get these pants off?"
    new "B:ana: A verdade é que estou muito excitada hoje, vim pensando em fazer sexo contigo..."

    # say L962 pla
    old "I- it's not-"
    new "B:ana: Oh, parece que estás a preparar-te... Porque não tiras estas calças?"

    # say L963 ana
    old "Don't be shy, I know both of us will feel very good after that, I am just a bit thirsty, can I get a taste?"
    new "B: pla: I- não é-"

    # say L973 ana
    old "Oh, yeah, this is what I'm talking about..."
    new "B:ana: Não tenhas vergonha, sei que os dois vamos sentir-nos muito bem depois disso, só estou um pouco com sede, posso provar?"

    # say L987 ana
    old "That was delicious, but now I want you to fuck me!"
    new "B:ana: Oh, sim, é isto que eu quero..."

    # say L988 pla
    old "W- what? Oh, no Lisa is downstairs she could-"
    new "B:ana: Isso foi delicioso, mas agora quero que me fodes!"

    # say L989 ana
    old "Maybe you need a bit of motivation... You want to see them again, don't you?"
    new "B:pla: O- o quê? Ah, não, a Lisa está lá em baixo, ela poderia..."

    # say L1002 ana
    old "Now, let's fuck!"
    new "B:ana: Talvez precisas de um pouco de motivação... Queres vê-los de novo, não é verdade?"

    # say L1015 ana
    old "You were amazing, I loved this session, I need this kind of session more often."
    new "B:ana: Agora, vamos foder!"

    # say L1017 ana
    old "I can keep this a secret if you are afraid of your boss, she doesn't need to know our particular sessions, besides she doesn't have the big talent you have."
    new "B:ana: Tu foste incrível, adorei esta sessão, preciso deste tipo de sessão mais vezes."

    # say L1018 ana
    old "I am considering you can get a tip later, for your hard work..."
    new "A:pla:... A-Acho que não devíamos-"

    # say L1019 pla
    old "... I- I think we shouldn't-"
    new "B:ana: Estou a considerar que podes ganhar uma gorjeta mais tarde, pelo teu trabalho árduo..."

    # say L1020 ana
    old "Do not worry honey, this was your best yoga session ever."
    new "B:pla:... A- Acho que não devíamos..."

    # say L1032 lis
    old "Hi guys, congratulations I can see you are sweating, that means you had a very hard job today."
    new "B:ana: Não te preocupes, amor, esta foi a tua melhor sessão de ioga de sempre."

    # say L1036 ana
    old "I can see that, I hope we can meet again later, the sooner the better."
    new "B:lis: Ele está a melhorar todos os dias; posso dizer-te que está a fazer um grande esforço."

    # say L1037 lis
    old "Oh sure, I have your appointment already set. Don't worry, we will be waiting for you."
    new "B:ana: Consigo ver isso, espero que possamos nos encontrar de novo mais tarde, quanto antes melhor."

    # say L1052 lis
    old "I am very satisfied with your job, I wanted you to know that I am considering to introduce you to other customers, I think you are so easy going, that people will just connect with you."
    new "B:lis: Adeus Anastasia, tenha um ótimo dia!"

    # say L1053 pla
    old "O- other customers, I- I don't know-"
    new "B:lis: Estou muito satisfeito com o teu trabalho, queria que soubesses que estou a considerar apresentar-te a outros clientes, acho que és tão simpático que as pessoas vão gostar de ti."

    # say L1054 lis
    old "You can help other people, your energy will just bring you what you need, you only need to keep on working hard..."
    new "B:pla: O- outros clientes, eu- eu não sei-"

    # say L1055 pla
    old "Hmm if you say so..."
    new "B:lis: Podes ajudar outras pessoas, a tua energia vai apenas trazer-te o que precisas, só precisas de continuar a trabalhar duro..."

    # say L1056 lis
    old "Oh, by the way, remember we will have tomorrow a new ritual, the tantric massages need to be continued so we can balance your chakras."
    new "B:pla: Hmm, se tu dizes..."

    # say L1058 lis
    old "Amazing, thank you for today, please get some rest."
    new "B:lis: Oh, a propósito, lembra-te que amanhã teremos um novo ritual, as massagens tântricas precisam continuar para equilibrar os teus chakras."

    # say L1078 lis
    old "Hi [pla], nice to see you again!"
    new "B:lis: Até mais [pla]!"

    # say L1079 pla
    old "Hello, Thank you."
    new "Estou muito feliz porque tu estás muito empenhado neste treino extra."

    # say L1080 lis
    old "I am very happy because you are very committed with this extra training."
    new "B:pla: Olá, obrigado."

    # say L1081 pla
    old "I appreciate you are taking the time to teach me."
    new "B:lis: Estou muito feliz porque estás muito empenhado neste treino extra."

    # say L1082 lis
    old "Any time, you are helping a lot with my business, I will do my best so you can be as good as me."
    new "B:pla: Aprecio que estejas a dedicar-me o teu tempo para me ensinar."

    # say L1083 pla
    old "Hmm, that is very nice of you."
    new "B:lis: A qualquer hora, estás a ajudar muito com o meu negócio, vou fazer o meu melhor para que tu possas ser tão boa quanto eu."

    # say L1084 lis
    old "Let's go to the room so we can start the tantric session."
    new "T(lis|tu|say): Vamos para o quarto para começarmos a sessão tântrica."

    # say L1092 lis
    old "Have you seen any improvement thanks to last session?"
    new "B:lis: Vamos para o quarto para começarmos a sessão tântrica."

    # say L1093 pla
    old "Yes... I can feel in a better mood."
    new "B:lis: Tu viste alguma melhoria graças à sessão passada?"

    # say L1094 lis
    old "Good, you will see better results."
    new "B:pla: Sim... Sinto-me com um humor melhor."

    # say L1095 lis
    old "Today we need to improve a lot because you need to be able to balance your chakra muladhara as soon as possible, that way you can offer a more delightful experience."
    new "B:lis: Ótimo, vais ver resultados melhores."

    # say L1096 lis
    old "Please get comfortable, you know we need to open our mind, just relax because this is not any casual meeting, your body is more than flesh, blood and energy..."
    new "B:lis: Hoje precisamos melhorar muito porque tu precisas ser capaz de equilibrar o teu chakra muladhara o mais rápido possível, assim podes oferecer uma experiência mais deliciosa."

    # say L1097 lis
    old "So, there's nothing to feel shy about, please undress."
    new "B:lis: Por favor, fica à vontade, sabes que precisamos de abrir a mente, só relaxa porque isto não é um encontro casual, o teu corpo é mais do que carne, sangue e energia..."

    # say L1103 lis
    old "Perfect, so today we need to increase the perception of our senses, you must feel more, once you connect your sexual chakra, we will start with the massage."
    new "B:lis: Então, não há nada de que tenhas de ter vergonha, por favor, despe-te."

    # say L1104 lis
    old "The idea is to recognize some feelings that only you can see, some situations that are deep inside, no one will be able to get there... Do not forget to feel the energy..."
    new "B:lis: Perfeito, então hoje precisamos aumentar a percepção dos nossos sentidos, tu deves sentir mais, uma vez que conectes o teu chakra sexual, começaremos com a massagem."

    # say L1112 lis
    old "While feeling my body on your skin please bring that healing energy in and allow it to wash through your body and mind."
    new "B:lis: A ideia é reconhecer sentimentos que só tu consegues ver, situações que estão profundamente dentro de ti, onde ninguém mais conseguirá chegar... Não te esqueças de sentir a energia..."

    # say L1114 lis
    old "Let your skin merge with mine, feel my fragrance, connect your senses with mine."
    new "B:lis: Enquanto sentes o meu corpo contra a tua pele, deixa essa energia curativa entrar e percorrer o teu corpo e mente."

    # say L1124 pla
    old "So, are you going to use your hands like last time?"
    new "B:lis: Deixa a tua pele fundir-se com a minha, sente o meu perfume, conecta os teus sentidos com os meus."

    # say L1125 lis
    old "No, we need to do better than last time, this time I want you to be able to experience a more intense moment, so I think my breast is going to be perfect."
    new "B:pla: Então, vais usar as mãos como da última vez?"

    # say L1126 pla
    old "Y- your breast? ..."
    new "B:lis: Não, temos de fazer melhor do que da última vez, desta vez quero que tu consigas experimentar um momento mais intenso, por isso acho que o meu peito vai ser perfeito."

    # say L1127 lis
    old "Yes, remember this is not a sexual act, this a spiritual ritual to connect together and cleanse your chakras."
    new "B: pla: Y- tuas mamas?..."

    # say L1128 lis
    old "Don't get distracted, keep focused so we can do the session and control your breathing."
    new "B:lis: Sim, lembra-te de que isto não é um ato sexual, é um ritual espiritual para nos conectar e limpar os teus chakras."

    # say L1129 pla
    old "... O- ok."
    new "B:lis: Não te distraias, mantém-te focado para podermos fazer a sessão e controlar a tua respiração."

    # say L1137 lis
    old "Just relax your body it is a part of the universe, where I can move freely and that way we can take it out..."
    new "B:pla:... O- ok."

    # say L1146 lis
    old "I can see your energy is more stable now, I am really proud of the effort you are putting in."
    new "B:lis: Só relaxa o corpo, ele faz parte do universo, onde eu posso me mover livremente e assim podemos tirá-lo..."

    # say L1147 lis
    old "I think we have just one lesson left, according to the progress I have seen, this chakra muladhara is not so strong now, you are getting the balance you need."
    new "B:lis: Consigo ver que a tua energia está mais estável agora, estou mesmo orgulhoso do esforço que estás a colocar."

    # say L1148 lis
    old "There are still more things to learn, see you next time, you need to get some rest, don't forget tomorrow's lesson with Anastasia."
    new "B:lis: Acho que só nos resta uma aula, segundo o progresso que tenho visto, este chakra muladhara já não está tão fraco, estás a conseguir o equilíbrio de que precisas."

    # say L1149 pla
    old "Sure, I'll be here... Thank you, bye."
    new "B:lis: Ainda há mais coisas para aprender, vemo-nos da próxima vez, precisas de descansar, não te esqueças da aula de amanhã com a Anastasia."

    # say L1169 lis
    old "Hi Anastasia, welcome to your yoga session once again, I hope you are ready for the routine today."
    new "B:pla: Claro, vou estar aqui... Obrigado, adeus."

    # say L1179 lis
    old "Oh no, it's perfect timing, Anastasia was telling me she came prepared today..."
    new "B:pla: Olá... Estou atrasado?"

    # say L1180 lis
    old "I am very happy that your training has become something personal, it means that you guys are feeling connected through these exercises."
    new "B:lis: Oh não, é perfeito, a Anastasia estava a dizer-me que veio preparada hoje..."

    # say L1181 lis
    old "I am so proud that you guys are improving together, I will leave you alone so you can do your routine, in case you need me, please let me know."
    new "B:lis: Estou muito feliz que o teu treino tenha se tornado algo pessoal, significa que vocês estão se sentindo conectados através destes exercícios."

    # say L1182 pla
    old "Sure, I will let you know in case we need you, let's go to the room to start the lesson."
    new "B:lis: Estou tão orgulhosa de vocês estarem a melhorar juntos, vou deixar-vos sozinhos para fazerem o vosso treino, se precisarem de mim, avisem-me."

    # say L1190 pla
    old "Well, we have a very-"
    new "B:pla: Claro, aviso-te se precisarmos de ti, vamos para o quarto começar a aula."

    # say L1191 ana
    old "I needed this urgently, so let's get straight to it..."
    new "B:pla: Bem, temos algo muito-"

    # say L1212 ana
    old "I want MORE! I want you to be rude... Fuck me harder PLEASE!"
    new "B:ana: Precisava disto urgentemente, vamos direto ao assunto..."

    # say L1226 ana
    old "Oh, you've accomplished it, this was by far better than last time."
    new "B:ana: Quero MAIS! Quero que sejas grosso... Foda-me mais forte POR FAVOR!"

    # say L1227 ana
    old "Could you make it better next time? I wanna see that!"
    new "A:pla: P-p- próxima vez?"

    # say L1228 pla
    old "N- next time?"
    new "T(pla|tu|say): N- próxima vez?"

    # say L1229 ana
    old "I am really happy for every penny I have spent here; I will speak highly of you with some friends, they will love you..."
    new "B:pla: N- próxima vez?"

    # say L1231 ana
    old "Alright, thanks for everything it's time to go."
    new "A:pla: Oh Lisa, h- como estás tu?"

    # say L1241 pla
    old "Oh Lisa, h- how are you?"
    new "B:ana: Bem, obrigado por tudo, é hora de ir."

    # say L1242 lis
    old "I can see the 'Lesson' has finished."
    new "B:pla: Oh Lisa, h- como estás?"

    # say L1247 lis
    old "I want to congratulate you guys for the effort you are doing on every lesson, I can see every time is better, did you like it Anastasia."
    new "B:lis: Posso ver que a 'Aula' já terminou."

    # say L1248 ana
    old "It was the best session ever; I am considering opening my schedule so we can make my sessions more frequent."
    new "B:lis: Quero felicitar-vos pelo esforço que estão a fazer em cada aula, vejo que cada vez está melhor, gostaste Anastasia?"

    # say L1249 lis
    old "Of course we could discuss it later, you can have as many sessions as you need..."
    new "B:ana: Foi a melhor sessão de sempre; estou a considerar abrir o meu horário para podermos tornar as minhas sessões mais frequentes."

    # say L1250 ana
    old "Fascinating! Next meeting we will check that."
    new "B:lis: Claro que podemos discutir isso mais tarde, podes ter quantas sessões precisares..."

    # say L1251 lis
    old "Hope you get some rest Anastasia, see you on next appointment."
    new "B:ana: Fascinante! No próximo encontro vamos verificar isso."

    # say L1252 ana
    old "Oh thank you, I will, see you next time."
    new "B:lis: Espero que descanses bem, Anastasia, até à próxima consulta."

    # say L1263 lis
    old "Are you leaving too?"
    new "B:pla: Sem problemas, até à próxima sessão."

    # say L1264 pla
    old "I guess so... ?"
    new "A:lis: Preciso de falar contigo sobre uma coisa antes de tu ires."

    # say L1265 lis
    old "I need to talk to you about something before you leave."
    new "T(lis|tu|diz): Preciso falar contigo sobre uma coisa antes de ires."

    # say L1266 pla
    old "Hmm, sure... What is it?"
    new "B:lis: Preciso de falar contigo sobre algo antes de ires."

    # say L1267 lis
    old "I think it's not acceptable... I know you are not doing the routine we have been preparing..."
    new "T(lis|tu|say): Acho que não é aceitável... Sei que não estás a fazer o ritual que tínhamos preparado..."

    # say L1269 lis
    old "I assume the previous routines were not done either, am I right?"
    new "B:lis: Acho que não é aceitável... Sei que não estás a fazer o ritual que tínhamos preparado..."

    # say L1270 pla
    old "(Oh shit... Did she noticed we were having SEX)"
    new "B:lis: Acho que as rotinas anteriores também não foram feitas, certo?"

    # say L1271 pla
    old "W- what are you... T- talking about?"
    new "B:pla: (Oh shit... Será que ela reparou que estávamos a ter SEX?)"

    # say L1272 lis
    old "Do not try to hide it, do you think I didn't hear her moaning?"
    new "B: pla: O- o que estás... A- a dizer?"

    # say L1273 pla
    old "I- I don't know what-"
    new "B:lis: Não tentes esconder, achas que eu não ouvi os gemidos dela?"

    # say L1276 pla
    old "I- I am very sorry, it wasn't my inte-"
    new "B: pla: (Oh God, ela vai me matar.)"

    # say L1277 lis
    old "Do you know what really pisses me off?"
    new "B:pla: I- I sinto muito, não foi minha inten-"

    # say L1279 lis
    old "I mean I don't care if you are having sex or not, you can connect with anybody and share your energy, sex is beautiful and good way to connect together."
    new "B:lis: Sabes o que me irrita de verdade?"

    # say L1280 lis
    old "But you should be applying the meditation and yoga experience with the client. This is not what I'm selling..."
    new "B:lis: Quero dizer, não me importo se estás a ter relações sexuais ou não, podes conectar-te com qualquer pessoa e partilhar a tua energia, o sexo é bonito e uma boa forma de se conectar."

    # say L1281 pla
    old "I'm so sorry..."
    new "B:lis: Mas tu deves aplicar a experiência de meditação e ioga com o cliente. Isto não é o que estou a vender..."

    # say L1284 lis
    old "She is not getting that here. I'm not doing this for money or business, it's about fate and helping others to connect with the universe."
    new "B:lis: Anastasia não está a fazer isso, ela tem sido distraída, quero dizer que a minha academia não se trata de coisas diferentes da energia, meditação e ioga..."

    # say L1285 lis
    old "Can you understand what I am saying?"
    new "B:lis: Ela não vai conseguir isso aqui. Não estou a fazer isto por dinheiro ou negócios, é sobre o destino e ajudar os outros a conectarem-se com o universo."

    # say L1287 pla
    old "I apologize if I disappointed you, I know you probably don't want me to be here anymore, I understand, just let me tell you it wasn't on purpose."
    new "T(pla|tu|dizer): Peço desculpa se te desiludi, sei que provavelmente já não queres que eu esteja aqui, compreendo, só queria dizer-te que não foi de propósito."

    # say L1288 lis
    old "What are you talking about? I do want you to be here."
    new "B:pla: Peço desculpa se te desiludi, sei que provavelmente já não queres que eu esteja aqui, compreendo, só deixa-me dizer-te que não foi de propósito."

    # say L1289 pla
    old "(Wait, what? Is she upset or not)"
    new "T(pla|tu|say): (Espera, o quê? Ela está chateada ou não?)"

    # say L1290 lis
    old "I just need you to help me by doing the things right, I thought that you were learning with the sessions you are doing with me, am I wasting my time?"
    new "B:pla: (Espera, o que? Ela está chateada ou não?)"

    # say L1291 pla
    old "... No, of course not, I'm sorry..."
    new "B:lis: Eu só preciso que me ajudes a fazer as coisas direito, pensei que estavas a aprender com as sessões que fazemos juntos, estou a perder o meu tempo?"

    # say L1292 lis
    old "I mean, you already know about this, you started a process, you should apply it to every activity you perform in your life... Even if it is sex... Yoga is deeply connected with sex."
    new "B:pla:... Não, claro que não, desculpa..."

    # say L1293 lis
    old "We definitely need to discuss this more... Wait a minute..."
    new "B:lis: Quero dizer, tu já sabes disto, começaste um processo, deves aplicá-lo a todas as atividades que realizas na vida... Mesmo ao sexo... O ioga está profundamente ligado ao sexo."

    # say L1295 lis
    old "I think... That could work! if she is into you because of the sex, you guys can actually do a great job if you apply the yoga knowledge to the sex experience..."
    new "B:lis: Precisamos definitivamente falar mais sobre isto... Espera um momento..."

    # say L1297 lis
    old "Actually if she is interested in you because of the sex, the yoga can make that experience richer than you both can imagine, she won't ever let you go."
    new "B:lis: Acho... Que isso pode funcionar! Se ela está interessada em ti por causa do sexo, vocês podem fazer um trabalho incrível se aplicarem o conhecimento de ioga à experiência sexual..."

    # say L1302 pla
    old "(I don't get it, but I feel better to knowing she is not as mad as I thought she would be.)"
    new "B: pla: Hmm... O- ok?"

    # say L1320 lis
    old "Hi, I am glad you came."
    new "B:pla: (Não percebo, mas sinto-me melhor por saber que ela não está tão zangada como pensei que estaria.)"

    # say L1321 pla
    old "Hello, thanks for this new opportunity."
    new "B:lis: Olá, fico contente que tenhas vindo."

    # say L1322 lis
    old "I didn't mean to be mad at you yesterday, it's just that... This is very important for me,  this is my destiny..."
    new "B:pla: Olá, obrigado por esta nova oportunidade."

    # say L1323 pla
    old "I... Understand..."
    new "B:lis: Não quis ser má contigo ontem, é só que... Isto é muito importante para mim, é o meu destino..."

    # say L1324 lis
    old "That's not important... Not anymore, it was a new opportunity, the universe showed me there are different ways to reach the goal I am pursuing."
    new "B:pla: Eu... Entendo..."

    # say L1325 lis
    old "Let's go to the room."
    new "B:lis: Isso não é importante... Não é mais, era uma nova oportunidade, o universo mostrou-me que existem diferentes caminhos para alcançar o objetivo que estou a perseguir."

    # say L1334 lis
    old "You see, Yoga is like a language, it helps you to understand the world and its people, we are all energy and love, that is why we need to balance our spirit so we can merge..."
    new "B:lis: Vamos para o quarto."

    # say L1335 lis
    old "That's why it is not weird that you can connect with another person so easily, that your bodies want to share their energies and eventually become one..."
    new "B:lis: Vês, o Yoga é como uma linguagem, ajuda-te a compreender o mundo e as pessoas, somos todos energia e amor, por isso precisamos de equilibrar o nosso espírito para podermos fundir-nos..."

    # say L1337 lis
    old "I meant what I told you, you started the process, you should apply it on every activities you perform in your life... Even if it's sex...."
    new "B:lis: É por isso que não é estranho que consigas conectar-te com outra pessoa com tanta facilidade, que os teus corpos queiram partilhar as suas energias e eventualmente tornarem-se um..."

    # say L1338 lis
    old "That's why I decided to prepare this lesson, it's really important because this way you will realize how everything is connected by energies."
    new "B:lis: Eu quis dizer o que te disse, tu começaste o processo, deves aplicá-lo em todas as atividades que realizas na vida... Mesmo que seja sexo...."

    # say L1339 lis
    old "You see, if you do some research you will find a very big part of yoga focuses on postures, you can find them according to your body type, the benefits it can give..."
    new "B:lis: É por isso que decidi preparar esta aula, é realmente importante porque desta forma vais perceber como tudo está interligado por energias."

    # say L1340 lis
    old "I have a complete library if you want, but if I asked you 'what is sex about' what would you say?"
    new "B:lis: Vês, se fizeres alguma pesquisa vais encontrar que uma grande parte do ioga se concentra em posturas, podes encontrá-las de acordo com o teu tipo de corpo, os benefícios que podem proporcionar..."

    # say L1341 pla
    old "I think... Positions?"
    new "B:lis: Tenho uma biblioteca completa se quiseres, mas se te perguntasse \"o que é o sexo\", o que dirias?"

    # say L1342 lis
    old "That's what everyone gets wrong... sex is bigger than the position you choose, as is Yoga, bigger than a posture to meditate or meditation its itself."
    new "B:pla: Acho... Posições?"

    # say L1343 lis
    old "However both have that in common, the posture, so this is how you are going to apply all the yoga knowledge you have on this important activity..."
    new "B:lis: É isso que todos se enganam... o sexo é maior do que a posição que escolhes, assim como o ioga, que é maior do que uma postura para meditar ou a própria meditação."

    # say L1344 lis
    old "Let's start."
    new "B:lis: No entanto, ambos têm isso em comum, a postura, por isso é assim que vais aplicar todo o conhecimento de ioga que tens nesta atividade importante..."

    # say L1348 pla
    old "Wait, what are you doing?"
    new "T(pla|tu|say): Espera, o que estás a fazer?"

    # say L1349 lis
    old "What do you think I'm doing? We are here to learn about Yoga and sex, to see how they are meant to be... So you should get naked too..."
    new "B:pla: Espera, o que estás a fazer?"

    # say L1350 pla
    old "... Alright."
    new "B:lis: O que é que achas que estou a fazer? Estamos aqui para aprender sobre ioga e sexo, para ver como se destinam a ser... Por isso, tu também deves ficar nu..."

    # say L1355 lis
    old "Now, let's start properly. I will lie down but I need you to get on your knees and hold my legs... Please relax yourself so you can feel it too."
    new "B:pla:... Tudo bem."

    # say L1366 lis
    old "Excellent, this is very interesting position, Do you like it?"
    new "B:lis: Agora, vamos começar devidamente. Vou deitar-me, mas preciso que te ajoelhes e segures as minhas pernas... Por favor, relaxa-te para também poderes sentir."

    # say L1367 pla
    old "... Yes."
    new "B:lis: Excelente, esta é uma posição muito interessante, gostas dela?"

    # say L1368 lis
    old "This is a very intimate way to share your energy, as you could see, it was quite demanding but very rewarding."
    new "B:pla:... Sim."

    # say L1369 lis
    old "So, let's start, move your hips and let me suck your penis."
    new "B:lis: Esta é uma forma muito íntima de partilhar a tua energia, como pudeste ver, foi bastante exigente mas muito gratificante."

    # say L1370 pla
    old "(Oh god, yes!)"
    new "B:lis: Então, vamos começar, move as ancas e deixa-me chupar o teu pénis."

    # say L1372 lis
    old "I know, maybe this position is not going to be the very first option to propose, but you will estimate the proper moment to help a client..."
    new "B:pla: (Oh god, yes!)"

    # say L1373 lis
    old "I hope you can start to tell apart sex and a real connection with a person thru Yoga?"
    new "B:lis: Eu sei, talvez esta posição não seja a primeira opção a sugerir, mas tu vais saber escolher o momento certo para ajudar um cliente..."

    # say L1387 lis
    old "Do realize how much energy you let out by using the proper technique? I mean using these yoga positions in some sexual practices?"
    new "B:lis: Espero que consigas começar a distinguir entre sexo e uma conexão verdadeira com uma pessoa através do ioga?"

    # say L1389 lis
    old "I'm glad you can realize how different it is."
    new "B:lis: Tu percebes quanta energia libertas ao usar a técnica correta? Quero dizer, ao usar estas posições de ioga em algumas práticas sexuais?"

    # say L1390 lis
    old "Now, let's try another option, this can be easier for any of your customers but a bit more demanding for you, however I know you can do it."
    new "B:lis: Fico contente que consigas perceber como é diferente."

    # say L1392 lis
    old "This position implies a lot more effort on your end, even though your partner may be experienced, almost the other person's weight will rely on your body."
    new "B:lis: Agora, vamos tentar outra opção, que pode ser mais fácil para qualquer dos teus clientes, mas um pouco mais exigente para ti, no entanto sei que consegues fazer."

    # say L1393 lis
    old "There are different conditions that can make it easier or not, however I think, Anastasia, will need more of your assistance because of her height."
    new "B:lis: Esta posição implica muito mais esforço da tua parte, mesmo que o teu parceiro seja experiente, quase todo o peso da outra pessoa recairá sobre o teu corpo."

    # say L1394 lis
    old "This time, I will hold my right leg up, and support a bit on my arms, I will need you to help me keep my balance and also to guide the entire movement, follow your intuition."
    new "B:lis: Existem diferentes condições que podem facilitar ou dificultar, no entanto, acho que a Ana, devido à sua altura, vai precisar de mais da tua ajuda."

    # say L1407 lis
    old "Wow, that was quite good, I'm exhausting, how did you feel?"
    new "B:lis: Desta vez, vou levantar o meu pé direito e apoiar-me um pouco nos braços. Vais precisar de me ajudar a manter o equilíbrio e também a guiar todo o movimento, segue a tua intuição."

    # say L1408 pla
    old "It was... Quite interesting."
    new "B:lis: Uau, isso foi bastante bom, estou exausto, como te sentiste?"

    # say L1409 lis
    old "Right? I felt so much of me and you at the same time, it was like embracing life, I can see your progress, how calm you can perform and still communicate."
    new "B:pla: Foi... Bastante interessante."

    # say L1410 lis
    old "The tantric massages gave you an impressive control over your chakras, you looked more than focused."
    new "B:lis: Certo? Senti tanto de nós dois ao mesmo tempo, era como abraçar a vida, vejo o teu progresso, como consegues ser calmo e ainda assim comunicar."

    # say L1411 lis
    old "Remember this is a training, from now on, you must use these positions, actually, try it in the next session, do it at the end of the session you have been doing."
    new "B:lis: As massagens tântricas deram-te um controlo impressionante sobre os teus chakras, parecias mais do que focado."

    # say L1412 lis
    old "Try to introduce it carefully so she can receive it positively, and the results can be more productive."
    new "B:lis: Lembra-te que isto é um treino, a partir de agora, deves usar estas posições, na verdade, tenta-o na próxima sessão, faz-no no final da sessão que tens feito."

    # say L1413 pla
    old "(Is she really asking me to do that)"
    new "B:lis: Tenta introduzi-lo com cuidado para que ela possa recebê-lo positivamente, e os resultados possam ser mais produtivos."

    # say L1415 lis
    old "Yes, That way she will not only enjoy your lesson but also learn what she wanted to."
    new "B: pla: (Ela está mesmo a pedir-me para fazer isso?)"

    # say L1417 lis
    old "Please, be on time tomorrow!"
    new "B:lis: Sim, assim ela não só vai aproveitar a tua aula como também vai aprender o que queria."

    # say L1418 pla
    old "Not a problem! See you then."
    new "T(pla|tu|say): Sem problemas! Até amanhã."

    # say L1439 ana
    old "So, how are you today?"
    new "B:pla: Sem problemas! Até logo."

    # say L1440 lis
    old "I am very well, thanks for asking, it's nice to see you again."
    new "B:ana: Então, como estás hoje?"

    # say L1441 ana
    old "Thank you, I came today with my best mood..."
    new "B:lis: Estou muito bem, obrigado por perguntar, é bom ver-te de novo."

    # say L1442 lis
    old "That's terrific, I am sure today's lesson will change your perception of the previous ones, we planned a very great session that you will find useful."
    new "B:ana: Obrigada, vim hoje com o meu melhor humor..."

    # say L1454 lis
    old "Please, enjoy yourselves... The yoga room is already prepared for your session."
    new "B:pla: Olá a todos..."

    # say L1455 pla
    old "Thank you Lisa, Anastasia please come in."
    new "B:lis: Por favor, divirtam-se... A sala de ioga já está preparada para a vossa sessão."

    # say L1456 ana
    old "Sure, I can't wait."
    new "B:pla: Obrigado, Lisa. Ana, por favor, entra."

    # say L1464 ana
    old "I need to confess that I did not study for today's lesson, so... Professor are you going to punish me?"
    new "B:ana: Claro, não vejo a hora."

    # say L1465 pla
    old "... I- (I should be confident, that's what Lisa expect from me.)"
    new "B:ana: Preciso confessar que não estudei para a aula de hoje, então... Professor, vais castigar-me?"

    # say L1466 ana
    old "What about if we just improvise?"
    new "A:ana: Vais foder-me mais forte hoje?"

    # say L1480 ana
    old "Are you going to fuck me harder today?"
    new "B:ana: E se improvisarmos?"

    # say L1487 ana
    old "Oh yeah baby, Fuck me like that again."
    new "B:ana: Vais foder-me mais forte hoje?"

    # say L1496 pla
    old "There is something new I want you to try."
    new "B:ana: Oh yeah baby, Foda-me assim de novo."

    # say L1497 ana
    old "Wow, I can see you don't need to rest young man, I am anxious to try it even if I feel a bit tired."
    new "B:pla: Há algo novo que quero que tu experimentes."

    # say L1498 pla
    old "We still have a lot to learn."
    new "B:ana: Wow, posso ver que não precisas de descansar, rapaz. Estou ansiosa para experimentar, mesmo que me sinta um pouco cansada."

    # say L1499 ana
    old "Sign me up."
    new "B:pla: Ainda temos muito a aprender."

    # say L1500 pla
    old "I will need you to relax your body so I can take your legs, I will hold them with my hands, but I will need you to hold me firmly with your hands."
    new "B:ana: Inscreve-me."

    # say L1501 ana
    old "I will do anything you ask of me."
    new "B:pla: Vou precisar que relaxes o corpo para eu poder pegar as tuas pernas, vou segurá-las com as minhas mãos, mas preciso que me segures firmemente com as tuas."

    # say L1502 pla
    old "Alright... Let's start."
    new "B:ana: Farei tudo o que me pedires."

    # say L1509 ana
    old "Oh, wow you are getting creative!"
    new "B:pla: Tudo bem... Vamos começar."

    # say L1519 ana
    old "Oh my god, that was unbelievable, I am so astonished! Is this the exercise Lisa mentioned you were preparing lately?"
    new "B:ana: Oh, que criativo estás a ficar!"

    # say L1521 ana
    old "So does she know? Wow, You guys don't stop surprising me."
    new "B:ana: Meu Deus, isso foi incrível, estou tão surpreendida! É este o exercício que a Lisa mencionou que tu estavas a preparar recentemente?"

    # say L1523 ana
    old "Let me ask you something, because this has blown my mind... Does Lisa offer these lessons with more than one instructor? I mean a team session with her would be pretty interesting..."
    new "B:ana: Então ela sabe? Uau, vocês não param de me surpreender."

    # say L1524 pla
    old "I- I'm not sure, I think I will need to ask her."
    new "B:ana: Deixa-me perguntar-te uma coisa, porque isto deixou-me de queixo caído... A Lisa dá estas aulas com mais do que um instrutor? Quero dizer, uma sessão em equipa com ela seria bastante interessante..."

    # say L1525 ana
    old "Alright, I have to go, let's get dressed."
    new "B:pla: I- Não tenho a certeza, acho que vou ter de perguntar-lhe."

    # say L1540 lis
    old "So guys, how was the session today?"
    new "B:ana: Tens de ir, vamos vestir-nos."

    # say L1542 ana
    old "Lisa, I think this has been the most incredible Yoga experience I have had in my entire life. I love your work, and of course your... Teamwork."
    new "B:lis: Então, pessoal, como foi a sessão de hoje?"

    # say L1543 ana
    old "Some friends are very interested in coming, I have persuaded them because of my experience, so hope you are ready for them."
    new "B:ana: Lisa, acho que esta foi a experiência de ioga mais incrível da minha vida. Adoro o teu trabalho, e claro, a tua... Colaboração."

    # say L1544 lis
    old "I appreciate you sharing your experience with your friends. I am sure you will learn more, do not doubt we will do our best to surprise you and your friends every time."
    new "B:ana: Alguns amigos estão muito interessados em vir, convenci-os com a minha experiência, por isso espero que estejas preparado para eles."

    # say L1545 ana
    old "Love you guys, see you next time."
    new "B:lis: Aprecio tu partilha da tua experiência com os teus amigos. Tenho a certeza que vais aprender mais, não duvides que faremos o nosso melhor para surpreender-te a ti e aos teus amigos cada vez."

    # say L1546 lis
    old "Sure, I have already scheduled your next appointment so I will be calling you."
    new "B:ana: Amo-vos, vejo-vos da próxima vez."

    # say L1547 ana
    old "Perfect, I will look forward to."
    new "B:lis: Claro, já agendei a tua próxima consulta, vou telefonar-te."

    # say L1548 lis
    old "Nice to have you here, bye bye!"
    new "B:ana: Perfeito, estou ansiosa por isso."

    # say L1549 ana
    old "See you next time."
    new "Sentiste?"

    # say L1559 lis
    old "Did you feel it?"
    new "B:ana: Até à próxima."

    # say L1560 pla
    old "Yes... I- I did."
    new "B:lis: Sentiste isso?"

    # say L1561 lis
    old "This is what we need to share with others, once you understand the language of the universe, you can translate to others, I am very proud that you are improving."
    new "B:pla: Sim... Eu- Eu fiz."

    # say L1563 lis
    old "I know you are quite good however remember this is a process... we need to continue working... So... we need to continue working on your chakra."
    new "B:lis: Isto é o que precisamos partilhar com os outros, uma vez que entendeste a linguagem do universo, podes traduzi-la para os outros, estou muito orgulhoso do teu progresso."

    # say L1565 lis
    old "I'll be waiting for you tomorrow night, those tantric sessions need to continue, as you saw today, you will become a very great Yoga instructor, so don't stop."
    new "B:lis: Eu sei que és bastante boa, mas lembra-te de que isto é um processo... precisamos de continuar a trabalhar... Portanto... precisamos de continuar a trabalhar no teu chakra."

    # say L1587 lis
    old "Hello, I was waiting for you."
    new "B:lis: Estarei à tua espera amanhã à noite, essas sessões tântricas precisam continuar, como viste hoje, vais tornar-te uma excelente instrutora de ioga, por isso não pares."

    # say L1588 pla
    old "Hi Lisa..."
    new "B:lis: Olá, estava à espera de ti."

    # say L1589 lis
    old "I was very excited because with this session we concluded this chapter with your chakras, remember the process is to find the perfect balance is not something we can call finished."
    new "B:pla: Olá Lisa..."

    # say L1590 pla
    old "I understand, I will continue working on it."
    new "B:lis: Estava muito entusiasmado porque com esta sessão concluímos este capítulo com os teus chakras, lembra-te que o processo de encontrar o equilíbrio perfeito não é algo que possamos considerar terminado."

    # say L1591 lis
    old "Actually, I wanted you to know that we can still work again on this, since this is a very good exercise for us both you can count on me to help you."
    new "B:pla: Entendi, vou continuar a trabalhar nisso."

    # say L1592 pla
    old "I really... Appreciate everything you do for me."
    new "B:lis: Na verdade, queria que soubesses que ainda podemos trabalhar nisto, pois é um excelente exercício para nós. Podes contar comigo para te ajudar."

    # say L1593 lis
    old "It's my way to say thank you, I want to thank you for your hard work."
    new "B:pla: Aprecio mesmo... Tudo o que fazes por mim."

    # say L1594 lis
    old "Let's go to the room to start the session..."
    new "B:lis: É a minha maneira de dizer obrigado, quero agradecer-te pelo teu trabalho árduo."

    # say L1602 lis
    old "Regular sex is about exploring and feeling pleasure desperately... The tantric experience is different, it's about the energy and sensations you can have with your partner."
    new "B:lis: Vamos para o quarto começar a sessão..."

    # say L1603 lis
    old "Sex consists of penetration and cumming, that takes out part of the connection, tantric sex otherwise means eye contacting, touching, breathing, to hear the noises."
    new "B:lis: O sexo convencional é sobre explorar e sentir prazer desesperadamente... A experiência tântrica é diferente, é sobre a energia e as sensações que podes ter com o teu parceiro."

    # say L1605 lis
    old "That is why we start with the massage, so we can open our senses, open ourselves to the other."
    new "B:lis: O sexo consiste em penetração e ejaculação, o que retira parte da conexão, enquanto o sexo tântrico significa contacto visual, toque, respiração, ouvir os sons."

    # say L1606 lis
    old "Please lie down to start the massage..."
    new "B:lis: É por isso que começamos com a massagem, para podermos abrir os nossos sentidos, abrir-nos ao outro."

    # say L1621 lis
    old "We will need to work harder today so let me start with some lubrication, the universe it self is all about love, so nothing better than kisses to start, to help you expel the negative chakra."
    new "B:lis: Deita-te para começarmos a massagem..."

    # say L1623 lis
    old "Just relax, remember to release the tension so you can do the exercise effectively."
    new "B:lis: Vamos ter de trabalhar mais hoje, então deixa-me começar com um pouco de lubrificação. O universo é tudo sobre amor, por isso nada melhor do que beijos para começar, para te ajudar a expelir o chakra negativo."

    # say L1639 pla
    old "That was great... I felt really good... Are we done?"
    new "B:lis: Relaxa, lembra-te de libertar a tensão para poderes fazer o exercício de forma eficaz."

    # say L1640 lis
    old "Of course not, since the main purpose is to finally connect deeply with yourself, there is a lot more to learn. I have a very special exercise for you to conclude this chakra training."
    new "B:pla: Isso foi ótimo... Senti-me mesmo bem... Já acabámos?"

    # say L1641 lis
    old "I will need you to lie down again so I can do the movements needed."
    new "B:lis: Claro que não, pois o objetivo principal é finalmente conectar-te profundamente contigo mesmo, há muito mais a aprender. Tenho um exercício muito especial para ti concluir este treino dos chakras."

    # say L1642 lis
    old "Let me show you how it works..."
    new "B:lis: Vais ter de te deitar de novo para eu poder fazer os movimentos necessários."

    # say L1648 lis
    old "Feel all inside me."
    new "B:lis: Deixa-me mostrar-te como funciona..."

    # say L1649 lis
    old "I'm feeling all of you."
    new "B:lis: Sente tudo dentro de mim."

    # say L1659 lis
    old "To be honest, I feel you're shining lately, these exercises have brought you wellness to your spirit and I can perceive it, I hope you can see the changes too."
    new "B:lis: Estou a sentir-me toda contigo."

    # say L1660 pla
    old "For sure, I think I feel much better now."
    new "B:lis: Para ser honesto, sinto que estás a brilhar ultimamente, estes exercícios trouxeram-te bem-estar ao espírito e eu consigo perceber, espero que tu também consigas ver as mudanças."

    # say L1661 lis
    old "Remember that it is really important to continue this training, if you want to reach out to me any night, so we can work on your chakra training..."
    new "T(lis|tu|diz): Lembra-te de que é realmente importante continuar este treino, se quiseres contactar-me a qualquer noite, para podermos trabalhar no teu treino dos chakras..."

    # say L1662 lis
    old "You know it helps you to stay more balanced and focused in your chakras... I'll have nights free so we can repeat the tantric ritual anytime you need."
    new "B:lis: Lembra-te que é realmente importante continuar este treino, se quiseres contactar-me a qualquer noite, para podermos trabalhar no teu treino dos chakras..."

    # say L1663 lis
    old "I think, now that you have balanced your energies, and your chakra muladhara has been controlled, you can even lead the tantric sessions with some of our customers."
    new "B:lis: Sabes que isso ajuda a manter-te mais equilibrada e focada nos teus chakras... Tenho noites livres, por isso podemos repetir o ritual tântrico sempre que precisares."

    # say L1664 lis
    old "I'm sure the universe has great things for you, you already know you can count on me."
    new "B:lis: Acho que, agora que equilibraste as tuas energias e o teu chakra muladhara está controlado, podes até liderar as sessões tântricas com alguns dos nossos clientes."

    # say L1665 pla
    old "I appreciate that."
    new "B:lis: Tenho a certeza de que o universo tem coisas maravilhosas para ti, tu já sabes que podes contar comigo."

    # say L1666 lis
    old "Don’t forget you can keep up the yoga sessions with Anastasia in the afternoons, whenever you’ve got time!"
    new "B:pla: Aprecio isso."

    # say L1667 lis
    old "Your lessons have evolved now that you are better balanced and applying your yoga knowledge to the sex connection..."
    new "B:lis: Não te esqueças que podes continuar as sessões de ioga com a Anastasia à tarde, sempre que tenhas tempo!"

    # say L1668 lis
    old "If you feel you need to review the previous trainings we have done, any morning I'll be working on that so you prepare better always to help your customers."
    new "B:lis: As tuas aulas evoluíram agora que estás mais equilibrada e aplicas o teu conhecimento de ioga à conexão sexual..."

    # say L1695 pla
    old "Hey Lisa! It's so nice to see you, how are you?"
    new "B:pla: Ok, boa noite Lisa!"

    # say L1696 lis
    old "Hi dear! I'm very good, and you?"
    new "B:pla: Olá Lisa! É tão bom ver-te, como estás?"

    # say L1697 pla
    old "I'm not so fine, we're having some financial issues..."
    new "B:lis: Olá querida! Estou muito bem, e tu?"

    # say L1698 lis
    old "Really? I'm so sorry... How could I help you?"
    new "B:pla: Não estou muito bem, estamos a ter alguns problemas financeiros..."

    # say L1699 pla
    old "Actually, that's why I'm here. I thought maybe you needed someone to help you out with your business, I really need to find a job."
    new "B:lis: Mesmo? Sinto muito... Como poderia ajudar-te?"

    # say L1701 pla
    old "I could work on anything... Doesn't matter what it's."
    new "B:pla: Na verdade, é por isso que estou aqui. Pensei que talvez precisasses de alguém para te ajudar com o teu negócio, preciso mesmo de arranjar um emprego."

    # say L1702 lis
    old "Sadly, I can't hire you. I don't really need help right now."
    new "B:pla: Posso trabalhar em qualquer coisa... Não importa o que seja."

    # say L1703 lis
    old "I haven't had much sales lately... I'm barely doing some Yoga classes for a few people."
    new "B:lis: Infelizmente, não posso contratar-te. Não preciso realmente de ajuda neste momento."

    # say L1704 lis
    old "However, I'm planning on improving my sales by implementing some new marketing strategies and I might need you sometime soon."
    new "B:lis: Não tenho tido muitas vendas lately... Estou a dar apenas algumas aulas de ioga para umas poucas pessoas."

    # say L1706 lis
    old "But not really right now..."
    new "B:lis: No entanto, estou a planear melhorar as minhas vendas implementando algumas novas estratégias de marketing e posso precisar de ti em breve."

    # say L1708 lis
    old "Sorry about that..."
    new "B:lis: Mas não agora..."

    # say L1709 pla
    old "No, it's ok. Not your fault, I gotta keep looking... I guess."
    new "B:lis: Desculpa..."

    # say L1710 lis
    old "You'll find something good."
    new "B:pla: Não, tudo bem. Não é tua culpa, tenho que continuar a procurar... Acho que sim."

    # say L1711 pla
    old "Hmm, I hope. Thanks anyway, it's always nice to see you."
    new "B:lis: Vais encontrar algo bom."

    # say L1712 lis
    old "I say the same... I'm glad you came to visit."
    new "B:pla: Hmm, espero. Obrigado de qualquer forma, é sempre bom ver-te."

    # say L1714 pla
    old "I should go, I really have to find a job, see you Lisa."
    new "B:lis: Digo o mesmo... Fico contente que tenhas vindo visitar-me."

    # say L1737 pla
    old "Hmm, this is weird, she should be here at this time of day."
    new "B:pla: Tenho de ir, preciso mesmo de arranjar um emprego, até já, Lisa."

    # say L1738 pla
    old "Lisa! Are you here?"
    new "B:pla: Hmm, isto é estranho, ela devia estar aqui a esta hora do dia."

    # say L1739 pla
    old "So odd, where is she?"
    new "B:pla: Lisa! Tu estás aqui?"

    # say L1754 pla
    old "What is that noise? I guess she's in the yoga room."
    new "B:pla: Que estranho, onde é que ela está?"

    # say L1767 pla
    old "{i}(That's- Umm... Quite an interesting position.){/i}"
    new "B: pla: {i}(Não estava à espera disso.){/i}"

    # say L1786 pla
    old "I- I'm sorry, Lisa! I- I didn't mean to spy on you."
    new "T: I- I'm sorry, Lisa! I- I não quis espiar-te."

    # say L1788 lis
    old "It's quite alright, I didn't realize I left the door open."
    new "B:pla: I- Desculpa, Lisa! I- Não quis espiar-te."

    # say L1789 lis
    old "Besides, all I was doing was resonating my Muladhara chakra with the energy of the universe."
    new "B:lis: Não há problema, não tinha reparado que tinha deixado a porta aberta."

    # say L1790 lis
    old "There's nothing to hide about that. So you don't need to worry about anything."
    new "B:lis: Além disso, tudo o que estava a fazer era ressonar o meu chakra Muladhara com a energia do universo."

    # say L1794 lis
    old "So, what brings you here?"
    new "B:lis: Não há nada a esconder nisso. Então, não precisas de te preocupar com nada."

    # say L1796 pla
    old "Uhmm, w- well, I just wanted to see how you're doing."
    new "B:lis: Então, o que te traz aqui?"

    # say L1797 pla
    old "You know, to check how everything's going."
    new "B:pla: Hmm, b- bem, só queria ver como estás."

    # say L1799 lis
    old "Well, I've been a little stressed, you know, this whole business thing is a little tiring."
    new "B:pla: Sabes, para ver como tudo está a correr."

    # say L1800 lis
    old "But that's precisely why I was just realigning my energy with the universe."
    new "B:lis: Bem, tenho estado um pouco stressada, sabes, este negócio todo é um pouco cansativo."

    # say L1801 lis
    old "After stimulating my Muladhara chakra, I feel like I've been relieved of all stress now."
    new "B:lis: Mas é precisamente por isso que eu estava a realinhar a minha energia com o universo."

    # say L1805 pla
    old "Is it that effective?"
    new "B:lis: Depois de estimular o meu chakra Muladhara, sinto-me livre de todo o stress agora."

    # say L1807 lis
    old "Of course it is! The Muladhara chakra is the second of the body and the one that regulates our sacred sexual energy."
    new "Claro que é! O chakra Muladhara é o segundo do corpo e o que regula a nossa energia sexual sagrada."

    # say L1808 lis
    old "It may have looked like I was just masturbating, but it's a lot more than that."
    new "B:lis: Claro que sim! O chakra Muladhara é o segundo do corpo e o que regula a nossa energia sexual sagrada."

    # say L1809 lis
    old "The Muladhara regulates our self-esteem."
    new "B:lis: Pode ter parecido que estava só a masturbar-me, mas é muito mais do que isso."

    # say L1810 lis
    old "By properly stimulating it you can improve your mood because your energy's in line with the rest of the universe."
    new "B:lis: O Muladhara regula a nossa autoestima."

    # say L1812 pla
    old "Uh... I- I see."
    new "B:lis: Através da estimulação adequada, podes melhorar o teu estado de espírito porque a tua energia está em sintonia com o resto do universo."

    # say L1816 lis
    old "By taking that position, I was letting my energy flow outwards from my head."
    new "B:lis: Sim, é isso mesmo."

    # say L1817 lis
    old "And replenishing my Muladhara chakra with positive energy coming from the top."
    new "B:lis: Ao assumir essa posição, estava deixando a minha energia fluir para fora da minha cabeça."

    # say L1822 lis
    old "Oh yeah, it's somewhat difficult to do."
    new "B: pla: T-tu fazes?"

    # say L1823 lis
    old "But I'm sure I can guide you towards a path of proper alignment with the universe."
    new "B:lis: Oh yeah, é um pouco difícil de fazer."

    # say L1825 pla
    old "Uh, I- I guess I'll think about it."
    new "B:lis: Mas tenho a certeza de que posso guiar-te para um caminho de alinhamento adequado com o universo."

    # say L1826 lis
    old "Oh, by the way, I was hoping you'd come, seems like the energies drew you here. It's so beautiful when the universe conspires in your favor."
    new "Oh, precisas de mim para algo?"

    # say L1827 pla
    old "Oh, do you need me for something?"
    new "B:lis: Oh, a propósito, esperava que viesse, parece que as energias te trouxeram aqui. É tão bonito quando o universo conspira a teu favor."

    # say L1828 lis
    old "Yeah, but let me get dressed and comfy. Meet me downstairs and we'll chat for a bit."
    new "B:pla: Oh, precisas de mim para algo?"

    # say L1829 pla
    old "Uh, yeah, sure. I'll be waiting downstairs."
    new "T(pla|tu|say): Uh, yeah, sure. Vou estar à espera lá em baixo."

    # say L1840 lis
    old "I'm ready, thanks for waiting. I'm really glad you came today."
    new "T(lis|tu|say): Estou pronta, obrigada por esperares. Estou realmente contente que tenhas vindo hoje."

    # say L1841 pla
    old "Uh, sure. So, what did you want to talk about?"
    new "B:lis: Estou pronta, obrigada por esperares. Fico realmente contente que tenhas vindo hoje."

    # say L1843 lis
    old "Well, you see, I need to ask a favor of you."
    new "B:pla: Uh, claro. Então, do que é que queres falar?"

    # say L1845 pla
    old "Really? What is it?"
    new "B:lis: Bem, preciso pedir-te um favor."

    # say L1847 lis
    old "It's about this client that I have, I've been working with her for a while."
    new "B:pla: Mesmo? O que é?"

    # say L1848 lis
    old "I would like you to be her instructor during her next class, instead of me."
    new "B:lis: É sobre esta cliente com quem tenho trabalhado há algum tempo."

    # say L1850 pla
    old "Oh! Are you busy again? Sure, I'll cover you."
    new "B:lis: Gostaria que tu fosses o instrutor dela na próxima aula, em vez de eu ser."

    # say L1851 lis
    old "No, it's nothing like that. I don't have anything else to do during that session."
    new "B:pla: Oh! Estás ocupado de novo? Claro, eu cubro-te."

    # say L1853 pla
    old "So what is it?"
    new "B:lis: Não, não é nada disso. Não tenho mais nada para fazer durante essa sessão."

    # say L1854 lis
    old "Well, she's come to every appointment without fail, she also does every yoga pose correctly."
    new "B:pla: E então, o que é?"

    # say L1856 lis
    old "But in spite of that, I would say she's not actually doing well."
    new "B:lis: Ela tem vindo a todas as consultas sem falhar, e também faz todos os exercícios de ioga corretamente."

    # say L1857 pla
    old "She isn't?"
    new "B:lis: Mas apesar disso, eu diria que ela não está bem."

    # say L1859 lis
    old "Yeah, I'm not feeling her energy flowing the way it should."
    new "T(lis|tu|dizes): Pois, não estou a sentir a energia dela a fluir como devia. É difícil de explicar, mas mesmo que ela tenha estado a progredir em termos de flexibilidade e poses."

    # say L1861 lis
    old "It's hard to explain, but even though she's been progressing in terms of flexibility and poses."
    new "B:lis: Sim, não sinto a energia dela a fluir como deveria."

    # say L1863 lis
    old "I still feel like she needs something else in order to thrive."
    new "B:lis: É difícil de explicar, mas mesmo que ela tenha estado a progredir em termos de flexibilidade e poses."

    # say L1867 lis
    old "I think that maybe your masculine energy will be able to unearth whatever's stopping her from progressing."
    new "T(lis|tu|dizes): Acho que a tua energia masculina pode desenterrar o que está a impedir o progresso dela."

    # say L1869 lis
    old "After all, you already helped Anastasia in a very effective way."
    new "B:lis: Acho que a tua energia masculina pode desenterrar o que está a impedir a progressão dela."

    # say L1870 lis
    old "So I thought that it would be worth it to give it a go with this girl as well."
    new "B:lis: Afinal, tu já ajudaste a Anastasia de uma forma muito eficaz."

    # say L1872 pla
    old "Uh, well, if you say so, sure."
    new "B:lis: Achei que valia a pena tentar com esta rapariga também."

    # say L1873 pla
    old "I'll be happy to help you."
    new "B:pla: Hum, bem, se tu dizes, claro."

    # say L1875 lis
    old "That's great! I'll let her know about it and I'll see you in the afternoon then."
    new "B:pla: Fico feliz por te ajudar."

    # say L1877 pla
    old "Sure, no problem, I'll see you later."
    new "T(pla|tu|say): Claro, sem problemas, vejo-te mais tarde."

    # say L1902 pla
    old "Hi Lisa, I came for the class you told me about-"
    new "B:pla: Claro, sem problemas, vejo-te mais tarde."

    # say L1917 ang
    old "Y- yes, of course. Please, continue."
    new "B:lis: Uhh, Angelina?"

    # say L1919 lis
    old "Okay, as I was saying earlier, he has been helping me recently by giving classes to some of my clients."
    new "B:ang: S- sim, claro. Por favor, continua."

    # say L1921 lis
    old "You don't have to worry about anything, he's very knowledgeable and he has a spectacular energy."
    new "B:lis: Como eu estava a dizer, ele tem estado a ajudar-me recentemente a dar aulas a alguns dos meus clientes."

    # say L1924 lis
    old "So, I'm sure he'll be capable of helping you in the way you need."
    new "B:lis: Não tens de te preocupar com nada, ele é muito conhecedor e tem uma energia espetacular."

    # say L1926 ang
    old "I- I see, well... I'll be in his care then."
    new "B:lis: Então, tenho a certeza de que ele será capaz de te ajudar da maneira que precisas."

    # say L1928 lis
    old "Let's go to the yoga studio so you two can start your class."
    new "B:ang: I- I percebi, bem... Vou ficar aos seus cuidados então."

    # say L1938 lis
    old "I'll leave you two alone so you can start with the session, I hope you enjoy it, Angelina."
    new "B:lis: Vamos ao estúdio de ioga para vocês começarem a aula."

    # say L1939 ang
    old "W- well, thank you."
    new "B:lis: Vou deixar-vos a sós para começarem a sessão, espero que gostes, Angelina."

    # say L1941 pla
    old "We'll see you later."
    new "B:ang: B-bem, obrigado."

    # say L1950 pla
    old "Uhh, alright, so..."
    new "T(pla|tu|say): Hum, tudo bem, então..."

    # say L1956 pla
    old "I- I guess we better get started with the class."
    new "B:pla: Uhh, bem, então..."

    # say L1958 ang
    old "Wait a minute."
    new "T:ang|tu|diz: Espera aí."

    # say L1960 ang
    old "Can you please tell me what you're doing here? I thought you were supposed to be Dr. Johnson's assistant."
    new "T(ang|tu|say): Podes dizer-me o que estás a fazer aqui? Pensei que fosses assistente do Dr. Johnson."

    # say L1961 ang
    old "How come I'm running into you here? And you're teaching yoga?"
    new "B:ang: Podes dizer-me o que estás a fazer aqui? Pensei que fosses assistente do Dr. Johnson."

    # say L1963 ang
    old "What's next? Will you be my waiter if I go to a restaurant?"
    new "T(ang|tu|say): E o que vem a seguir? Vais ser o meu empregado de mesa se eu for a um restaurante?"

    # say L1964 pla
    old "Hmm, I can see why this would surprise you, but believe me, it was a surprise for me too."
    new "T(pla|tu|say): Hmm, percebo por que fiques surpreendido, mas acredita, também foi uma surpresa para mim."

    # say L1966 pla
    old "But it's nothing like what you're imagining."
    new "B:pla: Hmm, percebo por que fiques surpreendido, mas acredita em mim, também fiquei surpreendido."

    # say L1971 pla
    old "But I swear that I didn't know that you were the client I was supposed to help with the class today."
    new "B:pla: E desde que ela abriu o estúdio, tenho estado a dar-lhe uma mão com alguns clientes em particular."

    # say L1973 pla
    old "She just came to my house asking me for a hand with a client, and that's it."
    new "B:pla: Mas juro que não sabia que tu eras o cliente que eu era suposto ajudar hoje na aula."

    # say L1975 ang
    old "I don't know."
    new "A:ang: É estranho eu continuar a encontrar-te."

    # say L1977 ang
    old "It's just so weird that I keep running into you."
    new "T(ang|tu|say): É estranho eu continuar a encontrar-te."

    # say L1978 pla
    old "I know, trust me, it's very weird for me too."
    new "T(pla|tu|say): Eu sei, acredita em mim, também acho muito estranho."

    # say L1979 pla
    old "But if you let me, I'll be more than happy to help you with the class."
    new "B:pla: Eu sei, confia em mim, também acho muito estranho."

    # say L1981 ang
    old "I guess that if Lisa says it's alright, I have no reason to not believe what you're saying."
    new "B:pla: Mas se me deixares, ficarei mais do que feliz em ajudar-te com a aula."

    # say L1982 ang
    old "So I guess I'll do it."
    new "B:ang: Acho que se a Lisa diz que está bem, não tenho razão para não acreditar no que dizes."

    # say L1984 pla
    old "Great! And hey, how's Roonie doing?"
    new "B:ang: Então acho que vou fazer isso."

    # say L1986 pla
    old "I bet he must be happy about the baby."
    new "B:pla: Ótimo! E aí, como está o Roonie?"

    # say L1987 ang
    old "Uhm, yeah... He's doing alright."
    new "T: Hum, sim... Ele está a correr bem. A- e como tem sido a gravidez para ti?"

    # say L1988 pla
    old "I see, good, good. A- and how's the pregnancy been treating you?"
    new "B:ang: Hum, sim... Ele está bem."

    # say L1990 ang
    old "I've been alright... I think"
    new "T: Tenho estado bem... acho eu. O médico disse-me que devo tentar manter-me ativa durante a gravidez."

    # say L1991 ang
    old "The doctor told me that I should try to stay active during my pregnancy."
    new "B:ang: Tenho estado bem... acho eu"

    # say L1992 ang
    old "That's why I'm taking yoga lessons, I was told it's one of the best things that you could do as a pregnant woman."
    new "B:ang: O médico disse-me que devo tentar manter-me ativa durante a gravidez."

    # say L1993 pla
    old "Oh yeah?"
    new "B:ang: É por isso que estou a fazer aulas de ioga, disseram-me que é uma das melhores coisas que podes fazer quando estás grávida."

    # say L1995 ang
    old "Yes, it's supposed to improve sleep by reducing stress, and also helping relieve anxiety."
    new "B:pla: Oh yeah?"

    # say L1996 ang
    old "And apparently it helps to strengthen the muscles needed for childbirth."
    new "B:ang: Sim, é suposto melhorar o sono ao reduzir o stress e também ajudar a aliviar a ansiedade."

    # say L1997 ang
    old "And the flexibility of course."
    new "E a flexibilidade, claro. É por isso que estou a fazer ioga."

    # say L1998 ang
    old "So that's why I'm doing yoga."
    new "B:ang: E a flexibilidade, claro."

    # say L1999 pla
    old "I see, that all makes a lot of sense."
    new "B:ang: É por isso que estou a fazer ioga."

    # say L2007 pla
    old "Uhmm, w- well, what do you say we get started with the session."
    new "B:pla: Entendo, tudo isso faz sentido."

    # say L2011 pla
    old "Alright, let's start with the first asana."
    new "B:pla: Hmm, b- bem, o que tu dizes de começarmos a sessão?"

    # say L2012 pla
    old "This first one's called Setu Bandha."
    new "B:pla: Vamos começar com a primeira asana."

    # say L2013 ang
    old "Ok? Is it too hard?"
    new "B:pla: Este primeiro chama-se Setu Bandha."

    # say L2014 ang
    old "I mean, I ask because I'm pregnant."
    new "A:pla: Não, não é muito difícil."

    # say L2016 pla
    old "Nah, it's not too hard."
    new "B:ang: Quero dizer, pergunto porque estou grávida."

    # say L2017 pla
    old "Sure it can be a little challenging."
    new "B:pla: Não, não é muito difícil."

    # say L2018 pla
    old "But don't worry, I'll be there helping you during it."
    new "T: Mas não te preocupes, vou estar lá a ajudar-te durante todo o processo."

    # say L2020 ang
    old "Ok, how do I do it?"
    new "Tudo bem, eu vou estar a ajudar-te durante todo o processo. Ok, como faço isso? É simples, basta deitares-te de costas com os joelhos levantados e os calcanhares virados para o rabo."

    # say L2022 pla
    old "It's simple, just lay on your back with your knees up and your heels towards your butt."
    new "T: É simples, só deitas de costas com os joelhos levantados e os calcanhares perto do rabo."

    # say L2023 pla
    old "And then just push through the soles of your feet and lift your hips up, like making an arch."
    new "B:pla: É simples, deita-te de costas com os joelhos levantados e os calcanhares perto do rabo."

    # say L2024 ang
    old "Hmm, ok, I guess I get it."
    new "B:pla: E depois empurra com as solas dos pés e levanta as ancas, como se estivesses a fazer uma arca."

    # say L2030 pla
    old "Yeah, you're doing it well, but you're a little tense through the shoulders."
    new "Tenta relaxar um pouco mais."

    # say L2031 pla
    old "Try to relax a little bit more."
    new "B:pla: Sim, estás a fazer bem, mas estás um pouco tenso nos ombros."

    # say L2032 ang
    old "O- Ok."
    new "B:pla: Tenta relaxar um pouco mais."

    # say L2040 pla
    old "{i}(But I can see that she's very tense.){/i}"
    new "B:pla: {i}(Hmm, vejo o que a Lisa me disse, ela está na posição certa.){/i}"

    # say L2041 pla
    old "{i}(Maybe we can change to another position and see how she does.){/i}"
    new "B:pla: {i}(Mas eu vejo que ela está muito tensa.){/i}"

    # say L2051 pla
    old "Alright, that was a good start."
    new "B:ang: O-ok. T(pla|tu|say): Tudo bem, foi um bom começo. A:pla: Então acho que podemos passar para a próxima posição."

    # say L2052 pla
    old "So I guess we can move into the next position."
    new "B:pla: Estava bom, foi um bom começo."

    # say L2053 pla
    old "This one's called Balasana."
    new "B:pla: Então acho que podemos passar para a próxima posição."

    # say L2054 pla
    old "It's even easier than the previous one, but it's very good to stretch the shoulders and back."
    new "T(pla|tu|say): É ainda mais fácil que o anterior, mas é muito bom para alongar os ombros e as costas."

    # say L2055 ang
    old "I see, how do I do it?"
    new "A:pla: É simples, vais começar numa posição de mesa."

    # say L2057 pla
    old "It's simple, you're going to start in a tabletop pose."
    new "T: É simples, vais começar numa posição de quatro."

    # say L2058 pla
    old "From there, just move your hips back and down while you leave your hands where they are."
    new "B:pla: É simples, vais começar numa posição de quatro."

    # say L2059 pla
    old "That will give you a proper stretch through your shoulders and back."
    new "B:pla: De lá, só move as ancas para trás e para baixo enquanto deixas as mãos onde estão."

    # say L2061 ang
    old "Hmm, ok, I think I can do that."
    new "B:pla: Isso vai dar uma boa alongamento nos teus ombros e costas."

    # say L2063 pla
    old "Yeah, and I'll be there to help you, so don't worry."
    new "B:ang: Hmm, ok, acho que consigo fazer isso."

    # say L2065 ang
    old "Ok, let's try it."
    new "A:ang: Estou a fazer isto bem?"

    # say L2068 ang
    old "Am I doing this right?"
    new "T(ang|tu|say): Estou a fazer isto bem?"

    # say L2071 pla
    old "Yeah, that's alright, but try to let go a little bit more."
    new "B:ang: Estou a fazer isto bem?"

    # say L2072 ang
    old "A-alright."
    new "B:pla: Sim, está bem, mas tenta relaxar um pouco mais."

    # say L2080 ang
    old "{i}(What's this I'm starting to feel?){/i}"
    new "B:ang: {i}(Hmm, ele está mais perto do que antes.){/i}"

    # say L2081 pla
    old "{i}(What the hell? She's even more tense than before!){/i}"
    new "B:ang: {i}(O que é isto que estou a começar a sentir?){/i}"

    # say L2082 pla
    old "{i}(Why is she so stiff?){/i}"
    new "B:pla: {i}(Que raio? Ela está ainda mais tensa do que antes!){/i}"

    # say L2083 pla
    old "{i}(I think we'll have to move on to the next position.){/i}"
    new "B:pla: {i}(Porque é que ela está tão rígida?){/i}"

    # say L2084 pla
    old "{i}(Maybe something a bit more relaxed.){/i}"
    new "B:pla: {i}(Acho que vamos ter de passar para a próxima posição.){/i}"

    # say L2085 pla
    old "Ok, I think that's enough of this position, we can move on to the next one."
    new "Ok, tu estás a fazer bem até agora."

    # say L2093 pla
    old "Ok, you're doing well so far."
    new "B:pla: Ok, acho que já chega nesta posição, podemos passar à próxima."

    # say L2094 pla
    old "But I think you're still a little tense. So I want us to change into a more relaxed position."
    new "B:pla: Ok, estás a fazer bem até agora."

    # say L2095 pla
    old "The idea for this next position is for you to relax and let go."
    new "B:pla: Mas acho que ainda estás um pouco tenso. Quero que mudemos para uma posição mais relaxada."

    # say L2097 ang
    old "L-let myself go?"
    new "B:pla: A ideia para esta próxima posição é tu relaxares e te deixares ir."

    # say L2098 pla
    old "That's right, I want you to relax and just let your energy flow through the position."
    new "T: É isso, quero que relaxes e deixes a tua energia fluir pela posição. A: Posso ver que tens um bloqueio de energia."

    # say L2100 pla
    old "I can see that you have an energy block."
    new "B:pla: É isso, quero que relaxes e deixes a tua energia fluir através da posição."

    # say L2102 pla
    old "If you keep going that way you won't be able to feel the energy flow through you."
    new "B:pla: Eu consigo ver que tens um bloqueio de energia."

    # say L2104 ang
    old "I-I see, I think I get it."
    new "B:pla: Se continuares assim, não vais conseguir sentir a energia a fluir através de ti."

    # say L2106 pla
    old "Ok, so be sure to just relax."
    new "T(pla|tu|say): Ok, então só relaxa."

    # say L2107 pla
    old "This next one's called Upavistha Konasana."
    new "B:pla: Ok, então relaxa."

    # say L2108 pla
    old "Except that it's a modified version."
    new "T(pla|tu|say): Mas é uma versão modificada."

    # say L2109 ang
    old "Modified? Will it be too hard?"
    new "B:pla: Excepto que é uma versão modificada."

    # say L2110 pla
    old "Not at all, don't worry."
    new "T: Não, não te preocupes."

    # say L2112 pla
    old "It involves a forward fold while you push your legs outwards and reach for your ankles."
    new "B:pla: Nem um pouco, não te preocupes."

    # say L2113 pla
    old "But I will be helping you, so you won't have to make much effort."
    new "B:pla: Envolve uma flexão para a frente enquanto empurras as pernas para fora e tentas tocar os tornozelos."

    # say L2114 pla
    old "I'll help you by opening your legs with mine, and I'll pull you forward, so you just focus on the stretch through your groin and lower back."
    new "B:pla: Mas vou ajudar-te, por isso não terás de fazer muito esforço."

    # say L2116 ang
    old "Hmm, it sounds hard, but I'll trust you."
    new "B:pla: Vou ajudar-te a abrir as pernas com as minhas e vou puxar-te para a frente, então tu só te focas na tensão na virilha e nas costas baixas."

    # say L2119 pla
    old "Alright, you're doing ok."
    new "Mas tenta deixar-te ir um pouco mais. Ok?"

    # say L2122 pla
    old "But try to let yourself go a little bit more. Ok?"
    new "B:pla: Tudo bem, estás a fazer bem."

    # say L2131 ang
    old "{i}(T-this... Is like what I felt that time.){/i}"
    new "B:ang: {i}(W- o que é isto que estou a sentir de novo?){/i}"

    # say L2132 pla
    old "{i}(W-what?! S-she's even more tense than before!){/i}"
    new "B:ang: {i}(Isto... É como me senti naquela altura.){/i}"

    # say L2142 pla
    old "Ok, I think that's enough for today."
    new "T(pla|tu|say): Ok, acho que chega por hoje."

    # say L2143 pla
    old "How did you feel?"
    new "B:pla: Ok, acho que chega por hoje."

    # say L2145 ang
    old "I- Uhmm... I think I felt alright."
    new "T: Eu... Hmm... Acho que me senti bem."

    # say L2146 ang
    old "I feel my body a lot more loose now."
    new "B:ang: Hum... Acho que me senti bem."

    # say L2148 pla
    old "Hmph, well, as long as you don't feel bad, I guess that's ok."
    new "T: Hmph, bem, desde que não te sintas mal, acho que está tudo bem."

    # say L2149 pla
    old "Why don't we go down and let Lisa know that we're done?"
    new "B:pla: Hmph, bem, desde que tu não te sintas mal, acho que está bem."

    # say L2167 lis
    old "Hello guys, are you done with the class?"
    new "B:pla: Porque não descemos e avisamos a Lisa que já terminámos?"

    # say L2171 lis
    old "Alright, and how did it go? How are you feeling right now Angelina?"
    new "B:lis: Olá a todos, já terminaram a aula?"

    # say L2173 ang
    old "It was good... Yeah, it was a good class."
    new "B:lis: E então, como correu? Como estás a sentir-te agora, Angelina?"

    # say L2176 lis
    old "I'm happy to hear that. [pla] knows very well what he's doing, so I was sure that it would be a good class."
    new "B:ang: [pla] ajudou-me em todas as posições, e não foram muito difíceis."

    # say L2178 ang
    old "I’m afraid it’s getting quite late, I must be going now."
    new "T(ang|tu|say): Tenho medo que já esteja bastante tarde, tenho de ir agora."

    # say L2180 ang
    old "Thanks a lot for the class [pla]."
    new "T(ang|tu|say): Muito obrigado pela aula [pla]."

    # say L2184 ang
    old "Goodbye, Lisa. I’ll see you at the next class."
    new "T: Adeus, Lisa. Até à próxima aula."

    # say L2185 lis
    old "See you next class, sweetheart. Take care."
    new "B:ang: Adeus, Lisa. Vejo-te na próxima aula."

    # say L2197 lis
    old "So? What did you think? How did it go?"
    new "B:lis: Até à próxima aula, querida. Cuida-te."

    # say L2198 pla
    old "Hmm, in general, I would say it was alright."
    new "B:lis: E então? O que achaste? Como correu?"

    # say L2199 pla
    old "But I can see what you mean about her having some sort of energetic block."
    new "B:pla: Hmm, em geral, diria que foi aceitável."

    # say L2201 pla
    old "I felt that she was very tense in all the positions we did."
    new "B:pla: Mas percebo o que queres dizer sobre ela ter algum tipo de bloqueio energético."

    # say L2202 lis
    old "I see, so her energy's still blocked inside her."
    new "B:pla: Senti que ela estava muito tensa em todas as posições que fizemos."

    # say L2204 pla
    old "Well, maybe that has to do with the fact that she's pregnant?"
    new "B:lis: Entendo, então a energia dela ainda está bloqueada dentro dela."

    # say L2205 pla
    old "By the way, I would've liked to have known that before."
    new "B:pla: Bem, talvez isso tenha a ver com o facto de ela estar grávida?"

    # say L2207 lis
    old "Oh, I failed to mention that, I'm sorry."
    new "B:pla: Por acaso, gostava de ter sabido isso antes."

    # say L2208 lis
    old "But I don't think it makes such a difference."
    new "B:lis: Oh, esqueci-me de mencionar isso, desculpa."

    # say L2209 lis
    old "What I've been feeling she lacks is that masculine energy I told you about."
    new "B:lis: Mas não acho que faça tanta diferença."

    # say L2210 lis
    old "So I think that it was still beneficial for her to have that session with you."
    new "B:lis: O que tenho sentido que ela falta é essa energia masculina de que te falei."

    # say L2212 pla
    old "I see, well, I sure hope that it actually helped her because she was just so tense during the session."
    new "B:lis: Acho que ainda foi benéfico para ela ter essa sessão contigo."

    # say L2214 lis
    old "Her next session's with me, so I'll see how her energy's changed. I'll let you know how she's doing."
    new "B:pla: Entendo, espero que tenha realmente ajudado, porque ela estava tão tensa durante a sessão."

    # say L2217 lis
    old "Before you head out, there's something I'd like to discuss with you."
    new "B:lis: A próxima sessão é comigo, então vou ver como a energia dela mudou. Vou-te dizer como ela está."

    # say L2218 pla
    old "Uh, sure. What's on your mind?"
    new "B:lis: Antes de saíres, há algo de que quero falar contigo."

    # say L2219 lis
    old "Well, recently, I've been doing very well."
    new "B:pla: Uh, claro. O que tens em mente?"

    # say L2220 lis
    old "I've gotten a good number of new clients, and they seem to be very happy with my classes."
    new "B:lis: Bem, recentemente, tenho estado muito bem."

    # say L2221 lis
    old "I'm very happy with how things have been going lately."
    new "B:lis: Tenho conseguido um bom número de novos clientes, e parecem estar muito satisfeitos com as minhas aulas."

    # say L2223 pla
    old "That sounds great! Congrats, Lisa!"
    new "B:lis: Tenho-me sentido muito feliz com o rumo que as coisas têm tomado ultimamente."

    # say L2226 lis
    old "So, I'm pondering what else I can offer my clients in the way of spiritual guidance and development."
    new "B:lis: Mas vês, alguns dos meus alunos estão a tornar-se muito avançados em ioga."

    # say L2230 lis
    old "Especially because my work goes beyond just yoga and meditation, you have seen it."
    new "B:lis: Então, estou a pensar no que mais posso oferecer aos meus clientes em termos de orientação e desenvolvimento espiritual."

    # say L2231 lis
    old "Rather than just a yoga guru, I want to be known as a complete spiritual wellness guide."
    new "B:lis: Especialmente porque o meu trabalho vai além do ioga e da meditação, tu já viste isso."

    # say L2232 lis
    old "So that my students can progress in whatever way they feel benefits them the most."
    new "B:lis: Em vez de ser apenas uma guru de ioga, quero ser conhecida como uma guia completa de bem-estar espiritual."

    # say L2237 lis
    old "And different healing treatments, like Chakra Healing, Acupuncture, Sound Healing, and herbal medicines."
    new "E diferentes tratamentos de cura, como Cura dos Chakras, Acupunctura, Terapia Sonora e medicinas herbais."

    # say L2238 pla
    old "I- I see, that's a lot."
    new "B:lis: E diferentes tratamentos de cura, como Cura dos Chakras, Acupuntura, Cura com Som e medicinas herbais."

    # say L2240 pla
    old "So you want to expand your portfolio, right?"
    new "B:pla: I- I percebi, é muito."

    # say L2242 lis
    old "Hmm... Yeah, to put it in simpler terms."
    new "B:pla: Então queres expandir o teu portefólio, certo?"

    # say L2244 lis
    old "Of course, I intend to implement this gradually. I’d like to conduct a few tests before applying it to additional clients."
    new "T(lis|tu|dizer): Claro, pretendo implementar isto gradualmente. Gostaria de realizar alguns testes antes de aplicar a mais clientes."

    # say L2245 pla
    old "That makes sense, so, Do you already have a plan for how to begin?"
    new "T(pla|tu|say): Isso faz sentido, então, já tens um plano de como começar?"

    # say L2247 lis
    old "Well, I have this client that's been working with me for a while."
    new "B:pla: Isso faz sentido, então, já tens um plano de como começar?"

    # say L2249 lis
    old "And she has in fact asked me several times about the possibility of having tantric sex sessions."
    new "B:lis: Bem, tenho esta cliente que tem estado a trabalhar comigo há algum tempo."

    # say L2250 pla
    old "I see, well, that makes a lot of sense, and if she wants to do it, I think it's a great idea."
    new "B:lis: E ela de facto já me perguntou várias vezes sobre a possibilidade de termos sessões de sexo tântrico."

    # say L2252 lis
    old "Yes, and you see, this client's Anastasia."
    new "B:pla: Entendo, bem, isso faz muito sentido, e se ela quer fazer, acho uma ótima ideia."

    # say L2254 pla
    old "Oh, I see, I think she did mention that."
    new "B:lis: Sim, e vês, esta cliente é a Anastasia."

    # say L2256 lis
    old "Yeah, and given that she's relatively advanced in her yoga journey, I think this would be a good moment to introduce her to more advanced concepts."
    new "B:pla: Ah, percebo, acho que ela mencionou isso."

    # say L2257 lis
    old "Especially tantric sex, I think it would be good for her to follow that practice."
    new "B:lis: Sim, e dado que ela já está bastante avançada na sua jornada de ioga, acho que este é um bom momento para lhe introduzir conceitos mais avançados."

    # say L2258 lis
    old "After all, the benefits are great, I think it would really help her with reducing stress and improving her relaxation."
    new "B:lis: Especialmente o sexo tântrico, acho que seria bom para ela seguir essa prática."

    # say L2260 lis
    old "Which will help her with her sleep."
    new "B:lis: Afinal, os benefícios são grandes, acho que realmente iria ajudá-la a reduzir o stress e melhorar a relaxação."

    # say L2262 lis
    old "Not to mention her sexual satisfaction, which I believe is clear to the both of us she needs to improve on."
    new "B:lis: O que a ajudará a dormir melhor."

    # say L2264 lis
    old "But more importantly, her personal and spiritual growth, tantra will help her with it, and I believe she'll benefit greatly from it."
    new "B:lis: Sem falar na satisfação sexual dela, que eu acredito ser evidente para ambos que precisa melhorar."

    # say L2265 pla
    old "All of that sounds great, I'm sure you'll have a great time teaching her."
    new "B:lis: Mas o mais importante é o seu crescimento pessoal e espiritual, a tantra vai ajudá-la nisso, e acredito que ela vai se beneficiar muito."

    # say L2267 lis
    old "Well, since you mentioned it, that's where you come in."
    new "B:pla: Tudo isso soa ótimo, tenho a certeza de que vais ter um ótimo tempo a ensiná-la."

    # say L2269 lis
    old "Anastasia asked me if it would be possible for you to accompany us during the tantric sex sessions."
    new "B:lis: Bem, já que mencionaste, é aí que tu entras."

    # say L2270 pla
    old "M-Me? Do you need me to be there?"
    new "T: M-Mim? Precisas que eu esteja lá?"

    # say L2271 pla
    old "I mean, with your experience, I don't see why I would need to be there. Don't you just do that directly?"
    new "B:pla: M-Mim? Precisas que eu esteja lá?"

    # say L2273 lis
    old "Of course I can teach her everything, but the reason I want you to go there is to be my assistant."
    new "T(lis|tu|say): Claro que posso ensiná-la tudo, mas a razão para querer que tu vás lá é para seres meu assistente."

    # say L2275 pla
    old "Your assistant?"
    new "B:lis: Claro que posso ensiná-la tudo, mas a razão para eu querer que tu vás lá é para seres minha assistente."

    # say L2277 lis
    old "Yeah, that's right, but not in the way that you may think of."
    new "T(lis|tu|diz): Sim, é verdade, mas não no sentido em que tu podes estar a pensar. O que eu preciso de ti é que desempenhes o papel de intermediário entre mim e Anastasia."

    # say L2278 lis
    old "What I need from you is that you play the role of an intermediary between Anastasia and me."
    new "B:lis: Sim, é verdade, mas não no sentido em que tu penses."

    # say L2280 pla
    old "I-I'm not sure I get what you're saying."
    new "T(pla|tu|say): Não tenho a certeza se percebi bem o que estás a dizer."

    # say L2284 lis
    old "So that the session can flow smoothly and without any problems."
    new "B:lis: Então, quando estivermos a fazer as sessões com ela, o teu papel será ajudá-la a sentir-se mais relaxada e confortável."

    # say L2286 pla
    old "Hmm, I see, that makes quite a lot of sense."
    new "B:lis: Para que a sessão possa fluir suavemente e sem problemas."

    # say L2288 pla
    old "But hey, you and I are still working on my own tantric session."
    new "B:pla: Hmm, percebo, isso faz bastante sentido."

    # say L2289 pla
    old "Are you sure it will be a good idea for me to be there? Wouldn't it be better if it's just the two of you?"
    new "B:pla: Mas hey, tu e eu ainda estamos a trabalhar na minha própria sessão tântrica."

    # say L2290 lis
    old "Well, at the beginning I did think it strange when she asked for it."
    new "B:pla: Tens a certeza de que será uma boa ideia eu estar lá? Não seria melhor se fossem só tu e ela?"

    # say L2291 lis
    old "But it makes a lot of sense since you've already helped her with her chakra balancing in the past."
    new "B:lis: Bem, no início achei estranho quando ela pediu."

    # say L2293 lis
    old "In addition, I believe it would be good practice for you, it would be a good way for you to work with other clients in the future. If the opportunity arises of course."
    new "B:lis: Mas faz todo o sentido, já que tu já ajudaste a equilibrar o chakra dela no passado."

    # say L2295 lis
    old "But of course, it all depends on you, if you feel the universe is guiding you towards a teaching role."
    new "B:lis: Além disso, acho que seria uma boa prática para ti, seria uma boa forma de trabalhares com outros clientes no futuro. Se a oportunidade surgir, claro."

    # say L2297 lis
    old "If you don't feel like it, there's no problem, I'll understand."
    new "B:lis: Mas claro, tudo depende de ti, se sentes que o universo te está a guiar para um papel de professora."

    # say L2299 pla
    old "Oh, no, no, there's no problem with it. I'll do it, with the way you explain it, it makes a lot of sense."
    new "B:lis: Se não te apetecer, não há problema, eu compreendo."

    # say L2301 lis
    old "Excellent [pla]! Thank you very much! I know it's going to be great."
    new "Ótimo [pla]! Muito obrigado! Sei que vai ser ótimo."

    # say L2304 pla
    old "Uhh, I think so."
    new "B:lis: Marquei um encontro para amanhã à noite, estarias disponível?"

    # say L2306 lis
    old "Wonderful, I'll get everything ready, and I'll see you later."
    new "B:pla: Hum, acho que sim."

    # say L2308 pla
    old "Sure, goodbye then."
    new "B:lis: Ótimo, vou preparar tudo e nos vemos mais tarde."

    # say L2335 pla
    old "Anastasia, hi. You're already here, great."
    new "B:pla: Claro, adeus então."

    # say L2338 ana
    old "Yeah, I just arrived, Lisa wasn't here so I decided to wait a while."
    new "B:pla: Anastasia, olá. Tu já estás aqui, ótimo."

    # say L2340 pla
    old "Oh, she's probably already up in the yoga room waiting for us."
    new "B:ana: Sim, acabei de chegar, a Lisa não estava cá, então decidi esperar um pouco."

    # say L2374 ana
    old "Yeah, sorry, sorry."
    new "B:lis: Hmm, Anastasia, estás bem?"

    # say L2376 ana
    old "It's just that the outfit you're wearing... It surprised me."
    new "B:ana: Sim, desculpa, desculpa."

    # say L2379 lis
    old "I see, that's understandable, but these collars are necessary for what we're about to do."
    new "B:ana: É só que o outfit que estás a usar... Surpreendeu-me."

    # say L2380 lis
    old "They're an important element that will help to keep the balance of your chakras."
    new "B:lis: Entendo, isso é compreensível, mas estas coleiras são necessárias para o que vamos fazer."

    # say L2382 ana
    old "I-I see."
    new "B:lis: São um elemento importante que ajudará a manter o equilíbrio dos teus chakras."

    # say L2384 lis
    old "Yes, because you see, this is a physical process, so the idea is to be fully in contact with our energies."
    new "B:ana: E-Eu percebo."

    # say L2385 lis
    old "So we need to get rid of everything that could get in the way of that connection. Of course, our clothes are part of that."
    new "B:lis: Sim, porque vês, isto é um processo físico, por isso a ideia é estar completamente em contacto com as nossas energias."

    # say L2386 ana
    old "D-Does that mean that I will be naked too?"
    new "B:lis: Então precisamos nos livrar de tudo que possa atrapalhar essa conexão. Claro, as nossas roupas fazem parte disso."

    # say L2392 lis
    old "Good, then let's get started. Why don't you go ahead into the yoga room and get ready?"
    new "B:ana: E-Eu percebo, entendi."

    # say L2393 lis
    old "[pla] and I will go in a minute."
    new "T(lis|tu|say): [pla] e eu vamos entrar daqui a pouco."

    # say L2404 lis
    old "Alright, you know what the idea is, right? You'll support me during the session, and you'll also be without any clothes."
    new "B:ana: Entendi, então eu faço."

    # say L2406 pla
    old "Yeah sure, no problem."
    new "T(pla|tu|say): Claro, sem problemas."

    # say L2408 lis
    old "However, for this session onwards, I prepared a special outfit for you."
    new "B:pla: Claro, sem problemas."

    # say L2409 pla
    old "A- a special outfit?"
    new "Sim, até agora tenho estado a guiar-te nesta jornada de desenvolvimento."

    # say L2411 lis
    old "Yes, up until now I've been guiding you in this development journey."
    new "B:pla: A - um fato especial?"

    # say L2412 lis
    old "But today you will be the one taking the position of the guide. From now on, you'll be a Yogi."
    new "B:lis: Sim, até agora tenho sido eu a guiar-te nesta jornada de desenvolvimento."

    # say L2415 lis
    old "A yogi, that's the title that a yoga instructor receives when they're guiding somebody."
    new "B:lis: Mas hoje vais ser tu a assumir a posição de guia. A partir de agora, vais ser uma Yogi."

    # say L2416 lis
    old "You're not a guru, like I am, but I think it's appropriate that I call you a Yogi, especially because you've already guided Anastasia on the right path."
    new "B:lis: Um iogue, esse é o título que um instrutor de ioga recebe quando está a guiar alguém."

    # say L2417 lis
    old "That's why I prepared a special outfit for you. You being on another level needs to be reflected in what you're wearing."
    new "B:lis: Não és um guru como eu, mas acho apropriado chamar-te de Yogi, especialmente porque já guiaste a Anastasia pelo caminho certo."

    # say L2418 lis
    old "That and because they're needed to protect and balance your energy."
    new "B:lis: É por isso que preparei um fato especial para ti. O facto de estares num nível superior tem de se refletir no que estás a usar."

    # say L2419 pla
    old "I-I see, thank you, Lisa."
    new "B:lis: Isso e porque são necessários para proteger e equilibrar a tua energia."

    # say L2421 lis
    old "You're more than welcome. Now go and get changed. Anastasia is waiting for us."
    new "B:pla: E-Eu vejo, obrigado, Lisa."

    # say L2422 lis
    old "You'll find what you have to wear on the bed."
    new "B:lis: De nada. Agora vai-te mudar. A Anastasia está à espera de nós."

    # say L2441 pla
    old "S- so, I wasn't sure if I was putting it on correctly, but I saw some instructions over the bed."
    new "B:lis: Vais encontrar o que tens de vestir na cama."

    # say L2442 pla
    old "What do you think? Does it fit me properly?"
    new "B: pla: S- então, não tinha a certeza se estava a colocá-lo corretamente, mas vi algumas instruções por cima da cama."

    # say L2443 lis
    old "It does, you look great, like a proper yogi."
    new "B: pla: O que achas? Fica-me bem?"

    # say L2444 lis
    old "Let's go in, Anastasia's waiting for us."
    new "B:lis: Claro, tu pareces ótima, como uma verdadeira ioga."

    # say L2473 pla
    old "{i}(I sometimes forget that Anastasia's so hot.){/i}"
    new "B:pla: {i}(Oh, wow, ela está só nua aí.){/i}"

    # say L2482 lis
    old "Because the idea is that this is as good an experience for you as we can make it."
    new "A:lis: Então, estás pronto para começar?"

    # say L2483 lis
    old "So, are you ready to start?"
    new "B:lis: Porque a ideia é que esta seja a melhor experiência possível para ti."

    # say L2485 ana
    old "Oh yeah, for sure, I've been waiting for this."
    new "B:lis: Então, estás pronto para começar?"

    # say L2486 ana
    old "I'm a little nervous."
    new "B:ana: Oh yeah, claro, tenho estado à espera disto."

    # say L2487 ana
    old "But once we start, I'm sure I'll feel a lot better."
    new "B:ana: Estou um pouco nervosa."

    # say L2491 lis
    old "Listen, Anastasia, I understand the type of situation this is, and how arousing it potentially is."
    new "B:ana: Mas uma vez que comecemos, tenho a certeza de que me vou sentir muito melhor."

    # say L2493 lis
    old "But it's important that you keep in mind that this is not for the sake of having sex."
    new "B:lis: Escuta, Anastasia, percebo o tipo de situação que isto é, e quão excitante pode ser."

    # say L2495 lis
    old "The most important part of this whole process is to learn to control those sexual impulses that sometimes take hold of us."
    new "B:lis: Mas é importante que tenhas em mente que isto não é para ter relações sexuais."

    # say L2497 lis
    old "So my focus for you during this whole process is that you are able to balance your chakras and put your energy in order."
    new "B:lis: A parte mais importante deste processo todo é aprender a controlar esses impulsos sexuais que às vezes nos dominam."

    # say L2499 ana
    old "Hmm, yeah, I guess you're right, but does that mean that we won't be having sex?"
    new "B:lis: O meu foco para ti durante todo este processo é que consigas equilibrar os teus chakras e organizar a tua energia."

    # say L2501 lis
    old "In the most strict sense of the word, no."
    new "B:ana: Hmm, sim, acho que tens razão, mas isso significa que não vamos ter sexo?"

    # say L2502 lis
    old "We will come to it when the time comes, but what's most important is that you are able to relax."
    new "B:lis: No, no no sentido mais estrito da palavra."

    # say L2503 lis
    old "To control your sexual energy and come to internal balance with your energy and chakras."
    new "B:lis: Vamos chegar a isso quando chegar a altura, mas o mais importante é que tu consigas relaxar."

    # say L2505 lis
    old "Now, let's get started so that you can see how this process feels."
    new "B:lis: Para controlar a tua energia sexual e chegar ao equilíbrio interno com a tua energia e chakras."

    # say L2507 ana
    old "O-Okay, sure."
    new "B:lis: Agora, vamos começar para que tu possas ver como este processo se sente."

    # say L2508 lis
    old "So, before we start with the first session, I want you to keep in mind that you need to focus on your breathing and relaxing your body."
    new "B:ana: O-Okay, claro."

    # say L2509 lis
    old "Let yourself go and listen to my instructions while you keep your breathing constant."
    new "B:lis: Então, antes de começarmos com a primeira sessão, quero que tenhas em mente que precisas focar na tua respiração e relaxar o corpo."

    # say L2529 lis
    old "I want to congratulate you, Anastasia."
    new "B:lis: Deixa-te ir e ouve as minhas instruções enquanto manténs a tua respiração constante."

    # say L2530 lis
    old "The fact that you were able to truly connect with yourself by doing this therapy."
    new "B:lis: Quero felicitar-te, Anastasia."

    # say L2533 lis
    old "But there still remains much to be done."
    new "B:lis: Fico contente por poder ajudar-te."

    # say L2534 lis
    old "So we will continue during the next session, ok?"
    new "T(lis|tu|diz): Então continuaremos na próxima sessão, ok?"

    # say L2536 ana
    old "Oh, we're done? I thought that maybe we could do some more..."
    new "B:lis: Então continuaremos na próxima sessão, ok?"

    # say L2538 lis
    old "I understand that you may feel like it, but we're doing this little by little."
    new "B:ana: Oh, já acabámos? Eu pensei que podíamos fazer mais..."

    # say L2539 lis
    old "Besides, you may not feel like it now, but you need to rest before you can do more. Believe me, you'll feel it later."
    new "B:lis: Entendo que possas sentir-te assim, mas estamos a fazer isto aos poucos."

    # say L2541 ana
    old "Hmm, ok, I get it."
    new "B:lis: Além disso, tu podes não sentir agora, mas precisas de descansar antes de poder fazer mais. Acredita em mim, vais sentir depois."

    # say L2543 lis
    old "Yes, by the way, it's getting a little late."
    new "B:ana: Hmm, ok, percebi."

    # say L2544 lis
    old "It's better if we get changed and ready for you to return home."
    new "B:lis: Sim, aliás, está a ficar um pouco tarde."

    # say L2551 lis
    old "Well, I would say that was a very good first session. I'm glad with the progress you made today, Anastasia."
    new "B:lis: É melhor se mudarmos e estarmos prontas para tu voltares para casa."

    # say L2553 ana
    old "Thank you very much, Lisa. I wasn't expecting it to be that good, but it was amazing."
    new "B:lis: Bem, diria que foi uma sessão inicial muito boa. Estou satisfeita com o progresso que fizeste hoje, Anastasia."

    # say L2557 lis
    old "She's right, [pla]. You being here really brings our energies to a state of balance. Thanks a lot."
    new "B:ana: E claro, obrigada a ti também, [pla]. Com tu aqui, consegui sentir-me muito mais à vontade."

    # say L2560 ana
    old "Anyway, it's getting a bit late, so I should head out. I can’t wait for the next tantric class."
    new "B:pla: Oh, bem, estou feliz por ajudar."

    # say L2561 lis
    old "Goodbye, darling, see you at the next yoga session this afternoon."
    new "B:ana: De qualquer forma, já está a ficar um pouco tarde, por isso devo ir-me embora. Mal posso esperar pela próxima aula tântrica."

    # say L2562 pla
    old "Good night, have a great evening."
    new "B:lis: Adeus, querida, até à próxima sessão de ioga esta tarde."

    # say L2564 ana
    old "Oh, of course I'll have a wonderful night. Thanks again, you two."
    new "B:pla: Boa noite, tenham uma ótima noite."

    # say L2577 pla
    old "Uhh, y- yeah, I totally felt it, that energy was... Definitely something."
    new "B:lis: Acredito definitivamente que o universo está a abrir uma porta para o meu negócio. Está a chamar-me para guiar mais clientes espiritualmente. Tu também sentiste, não foi?"

    # say L2578 lis
    old "Right? It was almost a religious experience."
    new "B:pla: Uhh, y- yeah, senti-a totalmente, essa energia era... Definitivamente algo."

    # say L2579 lis
    old "Oh wow, look at the time, it's really late."
    new "B:lis: Certo? Foi quase uma experiência religiosa."

    # say L2580 lis
    old "Ugh, I wanted to talk to you about Angelina, but I think we'll leave that for another day."
    new "B:lis: Oh wow, olha a hora, já está muito tarde."

    # say L2581 lis
    old "Could you swing by in the afternoon so we can talk? It won't take long."
    new "B:lis: Ugh, queria falar contigo sobre a Angelina, mas acho que deixamos para outro dia."

    # say L2582 pla
    old "Uhh, yeah, sure. No problem."
    new "B:lis: Podes passar cá à tarde para conversarmos? Não vai demorar muito."

    # say L2603 lis
    old "Hey, my energy’s flowing beautifully today, how about you?"
    new "B:pla: Olá Lisa, como estás?"

    # say L2604 pla
    old "I'm fine... Thanks for asking."
    new "T(pla|tu|say): Estou bem... Obrigado por perguntar."

    # say L2605 pla
    old "I came about that thing you mentioned, you wanted to talk about Angelina."
    new "B:pla: Estou bem... Obrigado por perguntar."

    # say L2606 lis
    old "Oh, yes, of course. Thanks for coming."
    new "B:pla: Vim falar sobre aquela coisa que mencionaste, tu querias falar sobre Angelina."

    # say L2607 lis
    old "Well, I had a session with her, and she asked me if you could be the teacher in her next class."
    new "B:lis: Oh, sim, claro. Obrigada por teres vindo."

    # say L2609 pla
    old "She did?!"
    new "B:lis: Bem, tive uma sessão com ela, e ela me perguntou se tu poderias ser o professor na próxima aula dela."

    # say L2611 lis
    old "Uhh, yes, why are you so surprised?"
    new "T(lis|tu|diz): Hã, sim, por que estás tão surpreendido?"

    # say L2613 pla
    old "Well, I just wasn't expecting that."
    new "B:lis: Uhh, sim, por que estás tão surpreendido?"

    # say L2614 pla
    old "Because last time she almost looked uncomfortable during the class."
    new "B:pla: Bem, eu não estava à espera disso."

    # say L2615 pla
    old "So it's kind of a surprise that you tell me she wants another class with me."
    new "B:pla: Porque da última vez ela quase parecia desconfortável durante a aula."

    # say L2617 lis
    old "Well, she had another class with me after yours."
    new "B:pla: Então é uma surpresa que me digas que ela quer outra aula comigo."

    # say L2618 lis
    old "And yes, I've noticed that her energy seems stuck. Her Muladhara chakra is completely out of balance."
    new "B:lis: Bem, ela teve outra aula comigo depois da tua."

    # say L2619 lis
    old "And it's affecting the flow of prana through her nadis. There might be a deep-rooted samskara causing this blockage."
    new "E depois da aula contigo, notei que o bloqueio dela começou a dissipar-se."

    # say L2620 lis
    old "But after her class with you, I've noticed her blockage has started to dissipate."
    new "B:lis: E está a afetar o fluxo de prana através dos seus nadis. Pode haver um samskara enraizado a causar este bloqueio."

    # say L2622 pla
    old "For real?"
    new "B:lis: Mas depois da aula contigo, notei que o bloqueio dela começou a desaparecer."

    # say L2624 lis
    old "Yes, I've noticed that after her session with you, her energy has started to flow a lot better inside her."
    new "B:pla: A sério?"

    # say L2626 pla
    old "Hmm, I have to say, that's a surprise."
    new "B:lis: Sim, notei que depois da sessão contigo, a energia dela começou a fluir muito melhor."

    # say L2627 pla
    old "But if you say that it's alright, and she actually requested another session with me, then I guess it's alright."
    new "B:pla: Hmm, tenho de dizer, isso é uma surpresa."

    # say L2629 lis
    old "It is, if she wants to see you again, it means you did a very good job."
    new "B:pla: Mas se tu dizes que está bem, e ela pediu mesmo outra sessão comigo, então acho que está bem."

    # say L2631 pla
    old "Uhh, alright..."
    new "B:lis: Se ela quer ver-te de novo, significa que fizeste um muito bom trabalho."

    # say L2633 lis
    old "So, can I count on you for the next session with Angelina?"
    new "B:pla: Uhh, bem..."

    # say L2635 pla
    old "Sure, sure, no problem."
    new "B:lis: Então, posso contar contigo para a próxima sessão com Angelina?"

    # say L2637 lis
    old "That's wonderful [pla], thanks a lot."
    new "Isso é ótimo [pla], muito obrigado. Vou marcar a próxima sessão de ioga da Angelina."

    # say L2639 lis
    old "So, as you know, I'll see you this afternoon for your next yoga class."
    new "B:lis: Vou avançar e agendar a próxima sessão de ioga da Angelina."

    # say L2641 pla
    old "Sure, count on it."
    new "B:lis: Então, como sabes, vejo-te esta tarde para a tua próxima aula de ioga."

    # say L2644 lis
    old "Goodbye [pla], take care."
    new "Oh, olá [pla]! É bom ver-te."

    # say L2671 lis
    old "Oh, hi [pla]! it's good to see you."
    new "B:lis: Adeus [pla], cuida-te."

    # say L2676 lis
    old "Not at all, Angelina just arrived a couple of minutes ago."
    new "B:pla: Olá, esperaste muito tempo por mim?"

    # say L2677 lis
    old "So you're just in time for the class."
    new "B:lis: Nem um pouco, Angelina acabou de chegar há uns minutos."

    # say L2678 lis
    old "But it's better if you don't lose time."
    new "B:lis: Então chegaste a tempo para a aula."

    # say L2680 lis
    old "So why don't you two go upstairs to the yoga room?"
    new "B:lis: Mas é melhor não perderes tempo."

    # say L2682 pla
    old "Sure, we'll see you later then."
    new "B:lis: Então, por que vocês dois não sobem para a sala de ioga?"

    # say L2692 pla
    old "Alright, I guess that if you're feeling alright, we can get started with the session."
    new "B:pla: Claro, vemo-nos mais tarde então."

    # say L2694 ang
    old "S- sure, let's do it."
    new "B:pla: Tudo bem, acho que se estás a sentir-te bem, podemos começar a sessão."

    # say L2696 pla
    old "{i}(I guess she'll relax when we start with the asanas.){/i}"
    new "B:pla: {i}(Hmm, ela ainda está desconfortável? É surpreendente que tenha querido outra sessão.){/i}"

    # say L2706 ang
    old "{i}(I didn't notice before, but this is a very comfortable position.){/i}"
    new "B:ang: {i}(Hmm, isto sente-se bem.){/i}"

    # say L2708 ang
    old "T-Thank you."
    new "B:pla: Ok, vejo que estás um pouco melhor do que da última vez."

    # say L2709 pla
    old "That's it, you're doing very well."
    new "B:ang: O-Obrigado."

    # say L2711 pla
    old "{i}(That's very good, she's very focused.){/i}"
    new "B:pla: {i}(Bem, o movimento dela está muito mais suave.){/i}"

    # say L2714 pla
    old "Remember to keep focusing on your breathing and how your muscles feel."
    new "B:pla: Estás a fazer muito, muito bem."

    # say L2715 pla
    old "Excellent, I think we can stop there."
    new "B:pla: Lembra-te de te concentrar na tua respiração e na sensação dos teus músculos."

    # say L2726 pla
    old "Alright! That was an excellent start!"
    new "B:pla: Ótimo, acho que podemos parar por aqui. T(pla|tu|say): Pois é! Foi um ótimo começo! A:pla: Consigo perceber que estás muito melhor do que da última vez."

    # say L2727 pla
    old "I can tell that you're doing so much better than last time."
    new "A:pla: Estás a sentir-te melhor do que na sessão anterior?"

    # say L2739 pla
    old "Okay, that's very good."
    new "B:ang: Sim, estou a sentir-me um pouco melhor do que antes."

    # say L2744 pla
    old "{i}(And the way she's pushing it against me...){/i}"
    new "B:pla: {i}(Carago, não tinha reparado, porque ela está grávida. Mas a Angelina tem um rabo de fazer inveja.){/i}"

    # say L2747 pla
    old "{i}(Oh shit! I can't believe this is happening now!){/i}"
    new "B:pla: {i}(E a forma como ela está a pressioná-lo contra mim...){/i}"

    # say L2754 pla
    old "{i}(Damn! But I don't think she's noticed yet, I better don't say anything to her about it.){/i}"
    new "B:pla: {i}(OH NÃO! Não posso acreditar que isto está a acontecer agora!){/i}"

    # say L2758 pla
    old "Ok, you're doing amazing."
    new "T(pla|tu|say): Ok, estás a fazer incrível."

    # say L2759 pla
    old "Now, I think we can move on to the third position."
    new "B:pla: Ok, estás a fazer incrível."

    # say L2761 ang
    old "Oh yeah, sure."
    new "B:pla: Agora, acho que podemos passar para a terceira posição."

    # say L2776 pla
    old "Remember to keep breathing."
    new "B:pla: T- isso está muito bom, bem feito."

    # say L2778 ang
    old "Am I doing it alright [pla]?"
    new "Estou a fazer bem [pla]?"

    # say L2783 ang
    old "{i}(W- what? Is that his? Oh my...){/i}"
    new "B:ang: {i}(H hã? O que é que toquei com a cabeça?){/i}"

    # say L2786 ang
    old "{i}(I did feel something during the last position, but I thought it was just his arm.){/i}"
    new "B:ang: {i}(W- o quê? É isso dele? Oh meu...){/i}"

    # say L2787 ang
    old "{i}(Maybe I should tell him about it?){/i}"
    new "B:ang: {i}(Senti algo durante a última posição, mas pensei que fosse só o braço dele.){/i}"

    # say L2788 ang
    old "{i}(B-But I feel so good right, now, I wouldn't want to stop.){/i}"
    new "B:ang: {i}(Talvez devesse contar-lhe...){/i}"

    # say L2789 ang
    old "{i}(I feel better than I've felt in a while.){/i}"
    new "B:ang: {i}(ZZZ...ZZZ Mas sinto-me tão bem agora, não queria parar.){/i}"

    # say L2790 ang
    old "{i}(I haven't felt this way since my therapy sessions with Dr. Johnson...){/i}"
    new "B:ang: {i}(Sinto-me melhor do que me sentia há muito tempo.){/i}"

    # say L2792 ang
    old "Do we have to? I think this is really helping me."
    new "B:pla: Ok, acho que podemos parar por agora, Angelina."

    # say L2793 ang
    old "I'm enjoying it a lot."
    new "B:ang: Temos de? Acho que isto está a ajudar-me muito."

    # say L2794 pla
    old "Uhh, o- ok, I guess we can keep going for a while."
    new "B:ang: Estou a gostar muito."

    # say L2796 ang
    old "{i}(Hmm, I'm feeling so hot right now, but I want more.){/i}"
    new "B:pla: {i}(Bem, pelo menos ela não parece ter notado a minha ereção. Acho que está tudo bem.){/i}"

    # say L2797 ang
    old "{i}(Like how I felt while we were doing those sessions with Dr. Johnson...){/i}"
    new "B:ang: {i}(Hmm, estou a sentir-me tão quente agora, mas quero mais.){/i}"

    # say L2805 pla
    old "Angelina? W-what are you doing?"
    new "B:ang: Devia fazer isso!"

    # say L2807 ang
    old "Well, I noticed your boner."
    new "B:pla: Angelina? Q-que estás a fazer?"

    # say L2808 ang
    old "And I thought I should give you a hand with it."
    new "B:ang: Bem, reparei no teu pau duro."

    # say L2809 pla
    old "B-But..."
    new "B:ang: E pensei que devias dar-me uma mão com isso."

    # say L2810 ang
    old "Oh come on, just let me do this."
    new "B:pla: B-Bem..."

    # say L2811 ang
    old "I want to do it, and it's not like we haven't done it before!"
    new "B:ang: Oh, vamos, deixa-me fazer isto. T(ang|tu|say): Eu quero fazê-lo, e não é como se nunca o tivéssemos feito antes! A:pla: Uhmm, olá, estás bem?"

    # say L2828 pla
    old "Uhmm, hey, are you alright?"
    new "B:ang: Quero fazê-lo, e não é como se nunca o tivéssemos feito antes!"

    # say L2829 pla
    old "Would you mind telling me what that was?"
    new "B:pla: Hmm, ei, estás bem?"

    # say L2830 ang
    old "I'm sorry [pla], I suppose you weren't expecting that."
    new "T: Desculpa [pla], suponho que não estavas à espera disso. A: Não queria surpreender-te assim."

    # say L2832 pla
    old "Hey, it's alright... I think."
    new "B:ang: I- I didn't mean to surprise you that way."

    # say L2833 pla
    old "It's just that you caught me off guard."
    new "B:pla: Hey, está tudo bem... Acho eu."

    # say L2835 ang
    old "Again, I'm sorry about that."
    new "A:ang: A questão é que tenho estado tão frustrado recentemente que quando notei que tu tinhas uma ereção, simplesmente deixei-me levar."

    # say L2836 ang
    old "The thing is that I've been so frustrated lately that when I noticed you had an erection I just let myself go."
    new "T(ang|tu|say): A questão é que tenho estado tão frustrado ultimamente que quando reparei que tinhas uma ereção, deixei-me levar."

    # say L2837 pla
    old "Oh yeah? Why are you so frustrated?"
    new "B:ang: A questão é que tenho estado tão frustrada ultimamente que quando notei que tu tinhas uma ereção, deixei-me ir."

    # say L2839 ang
    old "Well, I- I haven't been having sex with my husband lately."
    new "B:pla: Oh yeah? Porque estás tão frustrada?"

    # say L2840 pla
    old "You haven't? But I thought that the sessions with Dr. Johnson..."
    new "B:ang: Bem, eu... eu não tenho tido relações com o meu marido ultimamente."

    # say L2842 ang
    old "They did help..."
    new "T(ang|tu|dizes): Eles ajudaram..."

    # say L2844 ang
    old "After we were done, I did become more open in that regard. I'm now able to perform my duties as a wife."
    new "B:ang: Eles ajudaram..."

    # say L2846 ang
    old "But I would be lying if I said that I enjoy it."
    new "B:ang: Depois de termos acabado, eu fiquei mais aberta nesse aspecto. Agora consigo cumprir os meus deveres de esposa."

    # say L2848 ang
    old "To be honest, I haven't enjoyed sex since I was with you and Dr. Johnson."
    new "T(ang|tu|say): Para ser honesta, não tenho disfrutado do sexo desde que estive contigo e com o Dr. Johnson."

    # say L2850 ang
    old "When I got pregnant I got this huge boost in my libido."
    new "B:ang: Para ser honesta, não tenho disfrutado do sexo desde que estive contigo e com o Dr. Johnson."

    # say L2851 ang
    old "I was hoping that it would improve things in bed with my husband."
    new "B:ang: Quando fiquei grávida, tive um grande aumento no meu desejo sexual."

    # say L2852 pla
    old "And did it help?"
    new "B:ang: Esperava que isso melhorasse as coisas na cama com o meu marido."

    # say L2854 ang
    old "Not at all, I just don't desire him. So I'm just left feeling frustrated."
    new "T: Nem um bocadinho, simplesmente não sinto desejo por ele. Fico só frustrada."

    # say L2855 ang
    old "I guess that's why I reacted that way when I noticed that you had that boner."
    new "B:ang: Nem um pouco, simplesmente não o desejo. Só me sinto frustrado."

    # say L2859 pla
    old "You just caught me by surprise, but it's no problem really."
    new "B:pla: Não, está tudo bem, não te preocupes."

    # say L2860 pla
    old "But you know, I think there might be something that I can do for you."
    new "Tu: Mas sabes, acho que posso fazer algo por ti."

    # say L2862 ang
    old "There is?!"
    new "Claro! O ioga não se trata só de posições."

    # say L2864 pla
    old "Sure! Yoga's not just about positions."
    new "B:ang: Há?!"

    # say L2865 pla
    old "It's about improving your relationship with yourself by helping you balance your energy and your chakras."
    new "B:pla: Claro! O ioga não se trata apenas de posições."

    # say L2866 pla
    old "I already helped you once before, I don't see why not help you again."
    new "B:pla: É sobre melhorar a tua relação contigo mesmo, ajudando-te a equilibrar a tua energia e os teus chakras."

    # say L2867 pla
    old "So for the next session, I think we'll focus on that."
    new "B: pla: Já te ajudei uma vez, não vejo porquê não te ajudar de novo."

    # say L2869 ang
    old "Oh that sounds amazing [pla]! Thank you so much!"
    new "T: Oh isso parece incrível [pla]! Muito obrigada!"

    # say L2890 lis
    old "Well, how do you feel, Angelina?"
    new "B:pla: Mas por agora acho que devemos ir, para a Lisa não se preocupar com o tempo que isto está a demorar."

    # say L2891 ang
    old "I feel great! Thanks, Lisa!"
    new "B:lis: Bem, como te sentes, Angelina?"

    # say L2892 lis
    old "I can see that, I'm glad to see evidence of the positive effect yoga's having on you."
    new "B:ang: Estou ótimo! Obrigado, Lisa!"

    # say L2897 lis
    old "Well, I'll schedule it right away."
    new "B:ang: Ele realmente tem sido, e não vejo a hora da minha próxima aula."

    # say L2905 lis
    old "Goodbye, and until next time."
    new "T(lis|tu|say): Adeus, e até à próxima."

    # say L2920 lis
    old "Okay, so, tell me how did you feel her energy today?"
    new "B:lis: Adeus, e até à próxima."

    # say L2921 pla
    old "Well, honestly, I saw that she was doing the exercises better."
    new "B:lis: Okay, então, conta-me como sentiste a energia dela hoje?"

    # say L2922 lis
    old "Really? In my last session with her, I felt her so much more connected."
    new "B:pla: Bem, honestamente, vi que ela estava a fazer os exercícios melhor."

    # say L2923 lis
    old "Definitely, a masculine energy was just what her chakras needed to let go."
    new "B:lis: Mesmo? Na nossa última sessão, senti-a muito mais conectada."

    # say L2925 pla
    old "Yeah, she really let herself go..."
    new "B:lis: Definitivamente, uma energia masculina era exatamente o que os seus chakras precisavam para se libertar."

    # say L2926 lis
    old "Excellent, [pla], fate truly gifted me by bringing you into my path."
    new "T(lis|tu|diz): Excelente, [pla], o destino verdadeiramente me presenteou ao trazer-te para o meu caminho."

    # say L2930 pla
    old "Hmm, fine, I don't think I’ll have any problem coming at night."
    new "B:lis: Por acaso, queria perguntar como estão as tuas noites para agendarmos a próxima sessão tântrica com Anastasia?"

    # say L2931 lis
    old "Excellent! See how the universe puts everything in its place?"
    new "B:pla: Hmm, tudo bem, acho que não terei problemas em vir à noite."

    # say L2932 lis
    old "I'll talk to Anastasia and set up an appointment for the next tantric session. We'll be expecting you at night as always."
    new "B:lis: Excelente! Vês como o universo coloca tudo no seu lugar?"

    # say L2934 pla
    old "Sure, count me in."
    new "B:lis: Vou falar com Anastasia e marcar a próxima sessão tântrica. Estaremos à tua espera à noite como sempre."

    # say L2935 lis
    old "Wonderful, I'll get everything ready, and I'll see you then."
    new "Hmm, isto é estranho, não há ninguém aqui."

    # say L2964 pla
    old "Hmm, this is odd, there's no one here."
    new "B:lis: Ótimo, vou preparar tudo e vejo-te então."

    # say L2965 pla
    old "Anastasia hasn't arrived? Maybe she's running late?"
    new "B:pla: Hmm, isto é estranho, não há ninguém aqui."

    # say L2966 pla
    old "I'll take a look upstairs, maybe they're already in the yoga room."
    new "B:pla: A Anastasia ainda não chegou? Talvez esteja atrasada?"

    # say L2987 pla
    old "Oh! You're both here already, did I arrive too late?"
    new "B:pla: Vou dar uma olhadela lá em cima, talvez já estejam no quarto de ioga."

    # say L2992 lis
    old "But you're not late or anything."
    new "B:lis: Não, tudo bem, a Anastasia chegou mais cedo, então nos preparamos e estávamos só a conversar."

    # say L2993 pla
    old "I see, that's good to hear."
    new "T(pla|tu|say): Pois, isso é bom de ouvir."

    # say L2995 lis
    old "Yeah, but now that you're here, we can begin. Why don't you go and get changed?"
    new "B:pla: Entendo, isso é bom de ouvir."

    # say L3018 pla
    old "Alright, I'm ready."
    new "B:lis: Sim, mas agora que estás aqui, podemos começar. Por que não vais mudar de roupa?"

    # say L3020 lis
    old "Excellent."
    new "Ok, estás pronta para começar, Anastasia?"

    # say L3023 lis
    old "Ok, are you ready to start, Anastasia?"
    new "B:lis: Excelente."

    # say L3025 ana
    old "Oh yeah, I'm more than ready!"
    new "B:lis: Ok, estás pronta para começar, Anastasia?"

    # say L3026 ana
    old "After last time, I've been waiting for this."
    new "A:ana: Não vejo a hora de ter outro orgasmo como da última vez. Quero gozar."

    # say L3028 ana
    old "I can't wait to have another orgasm like last time. I want to cum."
    new "B:ana: Depois da última vez, tenho estado à espera disto."

    # say L3030 lis
    old "Well, I'm glad you're this excited for the session."
    new "B:ana: Não posso esperar para ter outro orgasmo como da última vez. Quero gozar."

    # say L3032 lis
    old "But remember, what's most important is that you're able to connect with yourself and feel the energy flow through you."
    new "B:lis: Bem, fico contente que estejas tão entusiasmado com a sessão."

    # say L3034 ana
    old "Of course, of course."
    new "B:lis: Mas lembra-te, o mais importante é que consigas conectar-te contigo mesmo e sentir a energia a fluir através de ti."

    # say L3035 ana
    old "I haven't forgotten what you taught me last time."
    new "B:ana: Claro, claro."

    # say L3037 lis
    old "Good, then we can begin."
    new "B:ana: Não me esqueci do que me ensinaste da última vez."

    # say L3041 lis
    old "Great, let's begin then."
    new "A:lis: Então, como foi, Anastasia? Gostaste do processo?"

    # say L3059 lis
    old "So, how was it, Anastasia? Did you enjoy the process?"
    new "B:lis: Ótimo, então vamos começar."

    # say L3061 ana
    old "Oh yeah! I loved it! It was amazing!"
    new "B:lis: Então, como foi, Anastasia? Gostaste do processo?"

    # say L3063 ana
    old "It felt amazing, just like last time. I loved it!"
    new "B:ana: Oh yeah! Adorei! Foi incrível!"

    # say L3065 lis
    old "I'm glad to hear that. It's a testament to the work being done to help you bring your chakras and energies into balance."
    new "B:ana: Sentiu-se incrível, tal como da última vez. Adorei!"

    # say L3069 pla
    old "I can tell by your good mood that your Muladhara chakra is already getting balanced."
    new "B:pla: Oh yeah, tu estás a fazer muito bem."

    # say L3073 ana
    old "But, I was wondering if maybe we could do a little bit more."
    new "B:ana: Obrigada, estou muito feliz por ouvir isso."

    # say L3074 ana
    old "Y-You know, s-since you say I'm doing so well."
    new "A:ana: Gostava de saber se podemos continuar."

    # say L3075 ana
    old "I would like to know if we can keep going."
    new "B:ana: S-Sabes, j-já que dizes que estou a fazer tão bem."

    # say L3076 ana
    old "Maybe we could do another exercise?"
    new "B:ana: Gostava de saber se podemos continuar."

    # say L3077 ana
    old "That's only if you think it's alright!"
    new "B:ana: Talvez possamos fazer outro exercício?"

    # say L3079 lis
    old "Actually, I was about to tell you just that."
    new "A:lis: Tu tens feito muito bem nesta primeira fase do processo de equilíbrio dos chakras."

    # say L3081 lis
    old "You've done very well during this first stage of the process of chakra balancing."
    new "B:lis: Na verdade, ia precisamente dizer-te isso."

    # say L3083 lis
    old "So I believe you're ready to try something new."
    new "B:lis: Tu tens feito muito bem nesta primeira fase do processo de equilíbrio dos chakras."

    # say L3084 ana
    old "Really? Great! What will we be doing? I can't wait."
    new "B:lis: Então acredito que estás pronta para experimentar algo novo."

    # say L3086 lis
    old "Well, the goal with what we've been doing so far is getting you to connect with yourself."
    new "B:ana: Mesmo? Ótimo! O que vamos fazer? Mal posso esperar."

    # say L3087 lis
    old "So that you could feel the flow of energy in your body."
    new "B:lis: Bem, o objetivo do que temos feito até agora é fazer-te conectar contigo mesmo."

    # say L3091 lis
    old "We're engaging in a posture where the goal is for the three of us to create an energetic chain."
    new "B:pla: Tudo bem, o que vamos fazer?"

    # say L3092 lis
    old "The point of that is that we're able to unite our energies."
    new "B:lis: Estamos numa postura onde o objetivo é criar uma corrente energética entre os três."

    # say L3093 lis
    old "And you can allow yourself to release what's pent up inside of you, Anastasia."
    new "B:lis: O ponto disso é que conseguimos unir as nossas energias."

    # say L3094 ana
    old "Okay, that sounds interesting."
    new "B:lis: E podes permitir-te libertar o que tens reprimido dentro de ti, Anastasia."

    # say L3095 ana
    old "I bet that's going to feel even better than the massage."
    new "B:ana: Okay, isso soa interessante."

    # say L3096 lis
    old "Sure, it might."
    new "B:ana: Aposto que isso vai ser ainda melhor do que a massagem."

    # say L3097 lis
    old "But you have to remember that whatever sexual pleasure you get from this is only secondary to the actual goal of getting your chakras in proper balance."
    new "B:lis: Claro, pode ser."

    # say L3099 ana
    old "Of course, of course, I haven't forgotten."
    new "B:lis: Mas tens de lembrar-te que qualquer prazer sexual que obtenhas disto é secundário ao objetivo real de equilibrar os teus chakras."

    # say L3101 lis
    old "Alright, it's time to start."
    new "A:ana: I- Isto está bem? Estou posicionada corretamente?"

    # say L3110 ana
    old "I- Is this okay? Am I positioned properly?"
    new "B:lis: Está na hora de começar."

    # say L3114 lis
    old "Good, then we're going to start moving slowly."
    new "B: pla: Y- yeah! Sem problemas!"

    # say L3128 lis
    old "Ok, I would like to ask if you have any comments on how this process is going."
    new "B:lis: Ótimo, então vamos começar a mover-nos devagar."

    # say L3130 ana
    old "The only thing I have to say is that it's been amazing!"
    new "B:lis: Ok, gostaria de perguntar se tens algum comentário sobre como este processo está a correr."

    # say L3131 ana
    old "It's just as good as I wanted it to be."
    new "B:ana: A única coisa que tenho a dizer é que foi incrível!"

    # say L3134 lis
    old "But I'm glad to hear that you're satisfied with the way this has been working."
    new "B:lis: Tudo a seu tempo."

    # say L3135 lis
    old "What do you say we get dressed and come down?"
    new "B:lis: Mas fico contente por ouvir que estás satisfeito/a com o modo como isto tem estado a funcionar."

    # say L3145 lis
    old "Alright, I will be seeing you both for the next session."
    new "B:lis: Que tal vestirmo-nos e descermos?"

    # say L3147 ana
    old "Sure, but before I leave, I want to thank you, Lisa."
    new "B:lis: Tudo bem, vou ver vocês na próxima sessão."

    # say L3150 ana
    old "At first, I was only interested in having sex with you guys."
    new "B:ana: Claro, mas antes de ir, quero agradecer-te, Lisa."

    # say L3153 ana
    old "But doing this has been an eye-opening experience for me."
    new "B:ana: No início, só estava interessada em ter sexo convosco."

    # say L3154 ana
    old "This has completely changed my perspective about what pleasure and enjoyment are."
    new "B:ana: Mas fazer isto tem sido uma experiência reveladora para mim."

    # say L3156 lis
    old "I'm glad you feel this way about what we've been doing. That's the main goal of this."
    new "B:ana: Isto mudou completamente a minha perspetiva sobre o que é prazer e gozo."

    # say L3159 lis
    old "Very well. We’ll schedule it after our next yoga session."
    new "Muito bem. Vamos agendá-lo depois da nossa próxima sessão de ioga."

    # say L3173 lis
    old "So, how did you find today's session? Did you feel all that energy and balance between the three of you?"
    new "B:lis: Muito bem. Vamos agendá-lo depois da nossa próxima sessão de ioga."

    # say L3174 pla
    old "Hmm, yeah, I definitely felt it a lot."
    new "B:lis: Então, como foi a sessão de hoje? Sentiste toda essa energia e equilíbrio entre os três?"

    # say L3175 lis
    old "It's amazing. And did you hear what she said about the whole process?"
    new "B:pla: Hmm, sim, senti bastante."

    # say L3176 lis
    old "I really feel like I'm an instrument of the universe, balancing and transmitting energy to all my clients."
    new "B:lis: É incrível. E ouviste o que ela disse sobre todo o processo?"

    # say L3177 pla
    old "Yes, you’ve truly helped all the women you’ve worked with."
    new "B:lis: Sinto-me verdadeiramente como um instrumento do universo, equilibrando e transmitindo energia a todos os meus clientes."

    # say L3178 lis
    old "Thank you for your words. By the way, I wanted to talk to you about Angelina."
    new "B:pla: Sim, tu verdadeiramente ajudaste todas as mulheres com quem trabalhaste."

    # say L3179 pla
    old "Uhh, sure, tell me..."
    new "B:lis: Obrigado pelas tuas palavras. Aliás, queria falar contigo sobre a Angelina."

    # say L3180 lis
    old "Well, I had a yoga session with Angelina, and I have to tell you that I've seen an impressive improvement in her condition."
    new "B:pla: Hum, claro, conta-me..."

    # say L3181 lis
    old "The problems with her Muladhara chakra seem to be getting resolved."
    new "B:lis: Bem, tive uma sessão de ioga com Angelina, e tenho que te dizer que notei uma melhoria impressionante no estado dela."

    # say L3182 lis
    old "She's still not entirely ok, but I can feel her prana flowing better within her body."
    new "B:lis: Os problemas com o seu chakra Muladhara parecem estar a ser resolvidos."

    # say L3183 lis
    old "Her energy is a lot more balanced, and I can see her being more receptive to the flow of energy among her chakras."
    new "B:lis: Ela ainda não está completamente bem, mas sinto a sua prana a fluir melhor no seu corpo."

    # say L3184 lis
    old "I must start recommending you to my other clients that may have some problems with their energy flow."
    new "B:lis: A sua energia está muito mais equilibrada, e consigo ver-te mais receptiva ao fluxo de energia entre os teus chakras."

    # say L3185 lis
    old "You've done so much by helping first Anastasia, and then Angelina."
    new "B:lis: Tenho de começar a recomendar-te aos meus outros clientes que possam ter alguns problemas com o fluxo de energia."

    # say L3189 lis
    old "The last thing is that she asked me if there was a possibility of you giving her another class."
    new "B:pla: B-bem, obrigado."

    # say L3191 pla
    old "Sure! If our sessions together are working, then I'm more than happy to do it. No problem."
    new "B:lis: A última coisa é que ela me perguntou se havia a possibilidade de tu lhe dar mais uma aula."

    # say L3193 lis
    old "Excellent, I'm glad you're willing to accept because I believe she still needs it."
    new "B:pla: Claro! Se as nossas sessões juntos estão a resultar, então estou mais do que feliz em fazê-lo. Sem problemas."

    # say L3230 ang
    old "Hi, [pla], nice to see you again"
    new "B:lis: Olá [pla], boa tarde."

    # say L3235 pla
    old "Yeah, sure, I'm ready."
    new "B:lis: Estás pronto para a tua próxima sessão?"

    # say L3237 lis
    old "Great, I've already talked with Angelina and she's ready too. So let's go to the yoga room then."
    new "B:pla: Claro, estou pronto."

    # say L3241 lis
    old "Well, I'll let you guys be, I hope you enjoy today's session as well Angelina."
    new "B:lis: Ótimo, já falei com a Angelina e ela também está pronta. Vamos então para a sala de ioga."

    # say L3243 ang
    old "Thank you, Lisa."
    new "B:lis: Bem, deixo-vos então. Espero que aproveitem bem a sessão de hoje, Angelina."

    # say L3245 pla
    old "See you, Lisa."
    new "B:ang: Obrigado, Lisa."

    # say L3254 pla
    old "So, how are you?"
    new "B:pla: Até logo, Lisa."

    # say L3256 ang
    old "I'm feeling alright."
    new "T: Estou a sentir-me bem."

    # say L3257 ang
    old "But this whole deal with the pregnancy hormones has me going through the roof."
    new "T(ang|tu|say): Mas este negócio todo com as hormonas da gravidez está a deixar-me fora de mim."

    # say L3259 ang
    old "The doctor explained to me that it's perfectly normal."
    new "B:ang: Mas este negócio todo com os hormonas da gravidez está a deixar-me fora de mim."

    # say L3261 ang
    old "But I'm not sure about that, because I wasn't feeling this way before, it's just since I saw you that I started feeling this weird way."
    new "B:ang: O médico explicou-me que é perfeitamente normal."

    # say L3265 ang
    old "Yeah, but he said that as soon as the baby's born, everything should be fine."
    new "B:ang: Mas não tenho a certeza disso, porque antes não me sentia assim, só desde que te vi que comecei a sentir-me desta maneira estranha."

    # say L3267 ang
    old "So, keeping that in mind... I wanted to ask a favor of you [pla]."
    new "T(ang|tu|say): Então, tendo isso em mente... queria pedir-te um favor [pla]."

    # say L3271 ang
    old "I- It would just be the one time, I swear."
    new "B:ang: Tu achas que estarias disposto a ajudar-me de novo com estas... necessidades que tenho?"

    # say L3273 ang
    old "It's just that I'm feeling this enormous tension as of late, and I really need to deal with it."
    new "B:ang: I- Isto seria só uma vez, juro."

    # say L3274 ang
    old "And I think you're the only one who can really help me with it."
    new "B:ang: É que tenho sentido uma tensão enorme ultimamente e preciso mesmo de lidar com isso."

    # say L3276 pla
    old "Uhh, I don't know... Lisa's downstairs and could come by any moment."
    new "B:ang: E acho que tu és a única pessoa que pode realmente ajudar-me com isso."

    # say L3277 pla
    old "Also, you're pregnant, I don't know how safe this is."
    new "B:pla: Uhh, não sei... A Lisa está lá em baixo e pode aparecer a qualquer momento."

    # say L3278 ang
    old "Don't worry about that, it's nothing dangerous. I already checked with my doctor. It'll just be quick, I promise I won't make much noise."
    new "T: Não te preocupes com isso, não é nada perigoso. Já falei com o meu médico. Vai ser rápido, prometo que não vou fazer muito barulho."

    # say L3279 pla
    old "But what about the yoga class..."
    new "B:ang: Não te preocupes com isso, não é nada perigoso. Já falei com o meu médico. Vai ser rápido, prometo que não vou fazer muito barulho."

    # say L3280 ang
    old "Look, I signed up for the class with Lisa because I felt so repressed, just like when I studied with Dr. Johnson."
    new "T: Olha, inscrevi-me para a aula com a Lisa porque me sentia tão reprimida, como quando estudava com o Dr. Johnson."

    # say L3281 ang
    old "And being pregnant, I wanted to try something different... But I ended up finding you again, and well, my hormones went wild and they're practically shouting for it."
    new "T(ang|tu|say): E estando grávida, quis experimentar algo diferente... Mas acabei encontrando-te de novo, e bem, os meus hormonas ficaram loucos e estão praticamente a gritar por isso."

    # say L3283 ang
    old "This would really help me more than a yoga class, and I think you know that."
    new "B:ang: E estando grávida, queria experimentar algo diferente... Mas acabei encontrando-te de novo, e bem, os meus hormonas ficaram loucos e estão praticamente a gritar por isso."

    # say L3286 pla
    old "Hmm... Alright..."
    new "B:ang: Sim, sim, vai em frente, o meu corpo está a ansiar por isso e acho que tu também vais gostar, mesmo."

    # say L3287 ang
    old "Ok, lie back and let me enjoy suking that big cock of yours."
    new "Ok, deita-te e deixa-me aproveitar a chupar esse pau grande teu. Mmm! Tenho estado à espera disto desde a última vez!"

    # say L3297 ang
    old "Mmm! I have been waiting for this since last time!"
    new "B:ang: Ok, deita-te e deixa-me aproveitar a chupar esse pau grande."

    # say L3298 ang
    old "I can't have enough of this!"
    new "B:ang: Mmm! Tenho esperado por isto desde a última vez!"

    # say L3316 pla
    old "Remember, if you really want a YOGA class, you can talk to Lisa."
    new "B:pla: Tenho a certeza que sim."

    # say L3322 ang
    old "Great! But for now, it's getting late, so I think I'll head home."
    new "T(ang|tu|dizer): Ótimo! Mas por agora, está a ficar tarde, então acho que vou para casa."

    # say L3340 ang
    old "We are. It was great, Lisa."
    new "B:lis: Vocês já acabaram?"

    # say L3341 lis
    old "I can see that, it seems the yoga really worked on you, Angelina."
    new "B:ang: Estamos. Foi ótimo, Lisa."

    # say L3343 lis
    old "I can see your energy flowing a lot better within you."
    new "B:lis: Eu posso ver isso, parece que o ioga realmente funcionou em ti, Angelina."

    # say L3344 lis
    old "Very good, [pla], you've done a good job."
    new "Muito bem, [pla], tu fizeste um bom trabalho."

    # say L3348 lis
    old "I can see that."
    new "A:lis: Espero que continues a vir às aulas depois disto, Angelina."

    # say L3349 lis
    old "I hope you'll keep coming to classes after this, Angelina."
    new "B:lis: Eu consigo ver isso."

    # say L3351 ang
    old "I will, I'll keep coming even after the baby's born."
    new "B:lis: Espero que continues a vir às aulas depois disto, Angelina."

    # say L3352 lis
    old "That's wonderful news."
    new "B:ang: Vou continuar a vir mesmo depois de o bebé nascer."

    # say L3354 ang
    old "Thank you, both of you."
    new "B:lis: É uma excelente notícia."

    # say L3355 ang
    old "I'll go home now."
    new "B:ang: Obrigado, ambos."

    # say L3356 ang
    old "But I'll come back soon for my next class."
    new "B:ang: Vou para casa agora."

    # say L3357 lis
    old "Of course, see you soon."
    new "B:ang: Mas volto logo para a próxima aula."

    # say L3374 lis
    old "Awesome! You’ve learned how to transmit that energy well. I truly feel you’ll become a great instrument for the universe."
    new "B:pla: Uh, sim, foi uma sessão excelente. Ela realmente gostou."

    # say L3375 lis
    old "Speaking of which, I’m scheduling a new tantric session with Angelina. Could you come by one evening soon?"
    new "B:lis: Ótimo! Aprendeste bem a transmitir essa energia. Sinto verdadeiramente que vais tornar-te um grande instrumento para o universo."

    # say L3376 pla
    old "Uh, sure, no problem."
    new "B:lis: A propósito, estou a agendar uma nova sessão tântrica com Angelina. Podes passar por cá uma noite destas?"

    # say L3403 pla
    old "Hmm, they're not here again."
    new "B:pla: Uh, claro, sem problemas."

    # say L3404 pla
    old "Well, I imagine that just means that they're already up in the yoga room."
    new "B:pla: Hmm, eles não estão aqui de novo."

    # say L3429 lis
    old "No, Anastasia arrived not too long ago, and we just got ready. Why don't you get changed so we can start?"
    new "B:pla: Ei, estavas à espera de mim há muito tempo?"

    # say L3454 lis
    old "Great, then we can start with the session."
    new "B:lis: Não, a Anastasia chegou há pouco tempo e acabámos de nos preparar. Porque não te mudas para podermos começar?"

    # say L3456 ana
    old "Lisa told me that we would be trying something new today."
    new "B:lis: Ótimo, então podemos começar a sessão."

    # say L3457 ana
    old "I can't wait to see what we'll do."
    new "B:ana: A Lisa disse-me que íamos experimentar algo novo hoje."

    # say L3460 lis
    old "Of course, but remember that before anything else you have to connect with yourself."
    new "B:ana: Não posso esperar para ver o que faremos."

    # say L3461 lis
    old "And focus on the balance of your chakras."
    new "B:lis: Claro, mas lembra-te que antes de tudo tens de conectar-te contigo mesmo."

    # say L3464 ana
    old "It's just that I'm very excited to see what's coming."
    new "B:lis: E concentra-te no equilíbrio das tuas chakras."

    # say L3466 lis
    old "Let's begin then, so you can see how it is."
    new "B:ana: É que estou muito entusiasmada para ver o que vai acontecer."

    # say L3484 lis
    old "Well done Anastasia, I can see by how well you're doing that these sessions have been very effective for you."
    new "B:lis: Vamos começar então, para tu veres como é."

    # say L3485 lis
    old "How do you feel about what we've been doing?"
    new "B:lis: Muito bem, Anastasia, posso ver pelo teu desempenho que estas sessões têm sido muito eficazes para ti."

    # say L3487 ana
    old "I feel great! I no longer feel any nervousness or anxiety about what we're doing."
    new "B:lis: Como te sentes em relação ao que temos feito?"

    # say L3491 lis
    old "It makes me happy to see that you're doing so well."
    new "B:pla: Olá, estou feliz em ajudar."

    # say L3492 lis
    old "And I believe you're ready for the next stage."
    new "B:lis: Fico feliz por ver que estás a ir tão bem."

    # say L3493 ana
    old "Alright, great! I trust that you know what's best."
    new "B:lis: E acredito que estás pronto para a próxima fase."

    # say L3495 lis
    old "Now, for this next exercise, the idea is that you finish the internal connection with yourself."
    new "B:ana: Ótimo! Confio que sabes o que é melhor."

    # say L3496 lis
    old "The first one we made was to help you relax and understand yourself on a deeper level."
    new "B:lis: Agora, para este próximo exercício, a ideia é que completes a conexão interna contigo mesmo."

    # say L3497 lis
    old "The second one was focused on you learning to let your energy flow freely in and out of you."
    new "B:lis: O primeiro que fizemos foi para te ajudar a relaxar e a compreender-te num nível mais profundo."

    # say L3498 lis
    old "This last one is about you using what you have learned to forge a new connection with your inner being."
    new "B:lis: O segundo estava focado em ti aprenderes a deixar a tua energia fluir livremente para dentro e para fora de ti."

    # say L3503 lis
    old "Alright, let's get started."
    new "Tudo bem, vamos começar."

    # say L3511 lis
    old "Ok, are you ready?"
    new "T(lis|tu|say): Ok, estás pronta?"

    # say L3512 ana
    old "Yes, I am, I feel like I can do this now."
    new "B:lis: Ok, estás pronta?"

    # say L3513 lis
    old "Remember to keep your breathing stable."
    new "B:ana: Sim, estou, sinto que consigo fazer isto agora."

    # say L3514 lis
    old "Focus on yourself, what you're feeling deep inside."
    new "B:lis: Lembra-te de manter a tua respiração estável."

    # say L3515 lis
    old "On the balance of your chakras."
    new "B:lis: Concentra-te em ti mesma, no que estás a sentir no teu interior."

    # say L3529 lis
    old "Well done, Anastasia. I can clearly see a change in you from the time we started this process to now."
    new "B:lis: No equilíbrio dos teus chakras."

    # say L3530 lis
    old "Your chakras are much more balanced now, and I can feel all the positive energy coming from you."
    new "B:lis: Muito bem, Anastasia. Consigo ver claramente uma mudança em ti desde o início deste processo até agora."

    # say L3536 ana
    old "I'll be sure to apply this to my own life in the future."
    new "B:ana: Graças a esta grande ajuda de vocês dois, a minha perspetiva sobre o sexo mudou completamente."

    # say L3537 lis
    old "Excellent! Because that's exactly what this is about!"
    new "B:ana: Vou aplicar isto à minha vida no futuro."

    # say L3541 ana
    old "Thank you, Lisa, I'll be sure to remember that."
    new "B:lis: Não se trata apenas de sexo, mas de como projetas a tua energia diariamente, e fico feliz que tenhas percebido isso."

    # say L3542 ana
    old "Really, what I got from these sessions is more than what I was expecting."
    new "B:ana: Obrigada, Lisa, vou ter a certeza de me lembrar disso."

    # say L3544 lis
    old "I'm happy that's how you feel, but this isn't a finished process."
    new "B:ana: Realmente, o que ganhei destas sessões é mais do que esperava."

    # say L3545 lis
    old "It's important that you keep practicing these teachings in the future."
    new "B:lis: Estou feliz por te sentires assim, mas isto não é um processo terminado."

    # say L3547 ana
    old "I'll be sure to do that."
    new "B:lis: É importante que continues a praticar estas lições no futuro."

    # say L3548 lis
    old "Great! Now, it's late, so let's get changed so that you two can go home."
    new "B:ana: Vou ter a certeza de fazer isso."

    # say L3558 lis
    old "Alright, that's it for now, but remember, we will see each other soon, okay? Both for your regular yoga classes, and for tantric sesions."
    new "B:lis: Ótimo! Agora, como já é tarde, vamos trocar de roupa para vocês irem para casa."

    # say L3560 ana
    old "Sure, I'll be seeing you soon."
    new "B:lis: Tudo bem, é tudo por agora, mas lembra-te, vamos ver-nos em breve, ok? Tanto para as tuas aulas de ioga normais como para as sessões tântricas."

    # say L3561 ana
    old "Thanks again to both of you, see you."
    new "B:ana: Claro, vou ver-te em breve."

    # say L3562 pla
    old "Happy to help, see you later."
    new "A:lis: Ok, acho que este primeiro passo de adicionar outras áreas além do ioga às minhas aulas foi um sucesso total."

    # say L3574 lis
    old "Okay, I think this first step of adding other areas besides yoga to my classes was a total success."
    new "B:pla: Fico contente por ajudar, até logo."

    # say L3575 pla
    old "Yeah, I think it would go really well if you offered it to more of your clients."
    new "T(pla|tu|say): Sim, acho que ia correr muito bem se o oferecesses a mais clientes teus."

    # say L3578 pla
    old "I'm sure of it."
    new "T: Tenho a certeza disso."

    # say L3579 lis
    old "I’ll follow the natural flow of destiny, I’ll take it step by step; I don’t want things to get out of hand."
    new "B:pla: Tenho a certeza disso."

    # say L3580 lis
    old "I hope you can keep helping me, there are many clients who would really benefit from your energy and vitality."
    new "B:lis: Vou seguir o fluxo natural do destino, vou fazer tudo aos poucos; não quero que as coisas fujam ao controlo."

    # say L3581 pla
    old "Of course, count on me whenever you need."
    new "B:lis: Espero que continues a ajudar-me, há muitos clientes que beneficiariam realmente da tua energia e vitalidade."

    # say L3582 lis
    old "Aww, you’ve been such a wonderful gift from the universe to me."
    new "B:pla: Claro, conta comigo sempre que precisares."

    # say L3583 lis
    old "Oh, speaking of that, I didn’t think it was necessary, but Angelina asked again for you to accompany her in a new class."
    new "B:lis: Aww, tu foste um presente maravilhoso do universo para mim."

    # say L3584 pla
    old "Hmm, yeah, I figured that would happen."
    new "B:lis: Oh, a propósito, não pensei que fosse necessário, mas Angelina pediu de novo para tu a acompanhares numa nova aula."

    # say L3585 lis
    old "You’ve done so much good for that girl, the difference is noticeable. She looks radiant, smiling, with such special energy."
    new "B:pla: Hmm, sim, eu imaginei que isso fosse acontecer."

    # say L3586 lis
    old "Does it sound good if I schedule you with her for a session in the afternoon?"
    new "B:lis: Tu tens feito tanto bem a essa rapariga, a diferença é notável. Ela parece radiante, sorridente, com uma energia tão especial."

    # say L3587 pla
    old "Yes, go ahead, no problem. I’ll talk to her about what she really wants to focus on."
    new "B:lis: Parece bem se eu agendar uma sessão com ela à tarde?"

    # say L3588 lis
    old "Sounds great, you’re a real guru! I’ll schedule the appointment with her and we’ll see each other then for your next session with her."
    new "B:pla: Sim, avança, sem problemas. Vou falar com ela sobre o que realmente quer focar."

    # say L3589 pla
    old "Okay, thanks Lisa, we’ll meet then for Angelina’s next session. Have a good night."
    new "T(pla|tu|say): Ok, obrigado Lisa, encontramo-nos então para a próxima sessão da Angelina. Boa noite."

    # say L3590 lis
    old "Rest well [pla], take care."
    new "T(lis|tu|say): Descansa bem [pla], cuida-te."

    # say L3617 lis
    old "Oh, hey [pla], you’re just in time, Angelina just arrived too."
    new "B:lis: Descansa bem [pla], cuida-te."

    # say L3618 ang
    old "Hi [pla], great to see you again."
    new "B:lis: Olá [pla], chegaste a tempo, a Angelina acabou de chegar."

    # say L3620 ang
    old "Excited for the new yoga class."
    new "B:pla: Olá Angelina, como estás?"

    # say L3621 pla
    old "Uh, heh, yeah, I can imagine..."
    new "B:ang: Ansioso pela nova aula de ioga."

    # say L3623 lis
    old "Well, I see you’re both eager for the class, so why not head upstairs and enjoy it?"
    new "B:pla: Uh, heh, yeah, posso imaginar..."

    # say L3634 pla
    old "Because I don’t think you came just to practice yoga exercises, right?"
    new "T(pla|tu|say): Porque não acho que vieste só para praticar exercícios de ioga, certo?"

    # say L3635 ang
    old "Look, I know, but seriously my body is going crazy, you don’t understand."
    new "B:pla: Porque não acho que vieste só para praticar exercícios de ioga, certo?"

    # say L3636 ang
    old "Being pregnant turns me into a teenager full of hormones."
    new "T(ang|tu|say): A gravidez transforma-me numa adolescente cheia de hormonas."

    # say L3637 ang
    old "And after weeks of sexual frustration, seeing you again reactivated so many things in me that I’d only felt during therapy with Dr. Johnson."
    new "T(ang|tu|say): E depois de semanas de frustração sexual, ver-te de novo reativou tantas coisas em mim que só sentia durante a terapia com o Dr. Johnson."

    # say L3639 ang
    old "Honestly, if it weren’t so necessary for me right now, I wouldn’t bother you."
    new "B:ang: E depois de semanas de frustração sexual, ver-te de novo reativou tantas coisas em mim que só sentia durante a terapia com o Dr. Johnson."

    # say L3651 ang
    old "Mmm, it feels so good, I could never get tired of it."
    new "B:ang: Oh, sim, tenho fantasiado sobre isto desde a última vez..."

    # say L3664 pla
    old "And hey, if you ever want a real YOGA session, just let me know."
    new "B:pla: Estou mesmo contente que te sintas melhor."

    # say L3667 ang
    old "Really, thank you so much for all your GREAT help today, it means a lot."
    new "B:ang: Isto tem sido maravilhoso, mas está a ficar tarde. Devo ir para casa."

    # say L3668 pla
    old "You’re welcome. Now let's go down to talk with Lisa."
    new "B:ang: A sério, muito obrigado pela GRANDE ajuda hoje, significa muito para mim."

    # say L3683 lis
    old "Oh, Are you guys done?"
    new "B:pla: De nada. Agora vamos falar com a Lisa."

    # say L3684 lis
    old "How do you feel after our yoga session?"
    new "B:lis: Oh, já acabaram?"

    # say L3685 ang
    old "It was amazing, Lisa, thank you!"
    new "B:lis: Como te sentes depois da nossa sessão de ioga?"

    # say L3686 lis
    old "I can sense a calm clarity in your energy now, Angelina."
    new "B:ang: Foi incrível, Lisa, obrigada!"

    # say L3687 lis
    old "Your inner balance has really deepened."
    new "B:lis: Posso sentir uma calma e clareza na tua energia agora, Angelina."

    # say L3688 lis
    old "And [pla], you did an excellent job guiding her through the flow."
    new "T(lis|tu|diz): E [pla], tu fizeste um excelente trabalho a guiar-a através do fluxo."

    # say L3690 lis
    old "Absolutely, you two make a great team."
    new "B:ang: Ele foi tão atencioso e solidário."

    # say L3693 lis
    old "That’s wonderful to hear."
    new "B:ang: Vou fazer isso, mesmo depois de o bebé nascer, vou continuar a praticar."

    # say L3694 ang
    old "Thank you both for your guidance."
    new "B:lis: É maravilhoso ouvir isso."

    # say L3695 ang
    old "I’ll head back now, but I’m looking forward to our next class."
    new "B:ang: Obrigado a ambos pela vossa orientação."

    # say L3696 lis
    old "We’ll be ready, see you soon!"
    new "B:ang: Vou voltar agora, mas estou ansiosa pelo nosso próximo encontro."

    # say L3697 pla
    old "Take care, Angelina."
    new "B:lis: Estaremos prontos, vemo-nos já!"

    # say L3710 pla
    old "Uh, thanks, yeah, I really put my effort into it."
    new "B:lis: Vejo isso na energia vibrante que ambos irradiam depois."

    # say L3711 lis
    old "I love your dedication and your calling to help others. You remind me of myself when I was younger."
    new "B:pla: Uh, obrigado, sim, realmente me esforcei."

    # say L3712 lis
    old "Anyway, it’s quite late. You should get some rest."
    new "B:lis: Adoro a tua dedicação e o teu chamado para ajudar os outros. Lembras-me de mim quando era mais nova."

    # say L3713 pla
    old "You’re right. Goodbye, and rest well."
    new "B:lis: De qualquer forma, já é bastante tarde. Deves descansar."

    # say L3736 pla
    old "Actually, I was wondering, why haven’t we had any new sessions with Anastasia or Angelina lately?"
    new "B:pla: Uh, talvez noutro dia..."

    # say L3737 lis
    old "Oh, well, Anastasia actually went out of town for a bit, but I’ve stayed in touch with her. She’s planning to return soon."
    new "B:pla: Na verdade, estava a pensar, por que não tivemos novas sessões com Anastasia ou Angelina ultimamente?"

    # say L3738 pla
    old "Oh, nice. I hope she’s enjoying her trip. Did she mention when she’ll be back?"
    new "B:lis: Oh, bem, a Anastasia saiu da cidade por um tempo, mas tenho mantido contacto com ela. Ela está a planear regressar em breve."

    # say L3739 lis
    old "She said in a few weeks."
    new "Ela disse que volta daqui a algumas semanas. E a Angelina?"

    # say L3740 pla
    old "Oh, alright. And Angelina?"
    new "B:lis: Ela disse que daqui a algumas semanas."

    # say L3741 lis
    old "Oh, you didn’t hear? The doctor told Angelina to take it easy, no workouts or anything, so we’re giving her a break from the sessions."
    new "B:pla: Oh, bem. E Angelina?"

    # say L3742 pla
    old "Oh really? Well, makes sense. Health first."
    new "B:lis: Oh, não ouviste? O médico disse à Angelina para descansar, sem treinos ou nada, por isso estamos a dar-lhe um intervalo das sessões."

    # say L3743 lis
    old "Absolutely. She was disappointed, she loved the sesions, but she needs to focus on her well-being."
    new "B:pla: Oh really? Well, makes sense. Saúde em primeiro lugar."

    # say L3744 lis
    old "I’m sorry I didn’t let you know earlier, you’re a blessing for always caring about others."
    new "B:lis: Absolutamente. Ela ficou desapontada, adorava as sessões, mas precisa focar no seu bem-estar."

    # say L3745 pla
    old "Oh, no, it’s nothing. I was just wondering, since we’ve had some busy days with Angelina and Anastasia’s sessions lately."
    new "B:lis: Desculpa não ter-te dito mais cedo, és uma bênção por sempre te preocupares com os outros."

    # say L3746 lis
    old "Don't worry, once Angelina and Anastasia resume, we’ll pick up right where we left off."
    new "B:pla: Oh, não, não é nada. Estava só a pensar que tivemos alguns dias ocupados com as sessões da Angelina e da Anastasia recentemente."

    # say L3747 lis
    old "And who knows, we might even add a group workshop."
    new "B:lis: Não te preocupes, uma vez que Angelina e Anastasia retomem, continuaremos exatamente onde paramos."

    # say L3748 pla
    old "A group workshop? Uhh, o- ok, yeah sure..."
    new "B:lis: E quem sabe, até podemos adicionar um workshop em grupo."

    # say L3749 lis
    old "It’s so thrilling, right? I can’t wait to see what else the universe has in store."
    new "B:pla: Um workshop em grupo? Huh, h- hã, claro..."

    # say L3750 lis
    old "Everything is happening so fast, it’s so exhilarating..."
    new "B:lis: É tão emocionante, certo? Mal posso esperar para ver o que mais o universo tem para nos oferecer."

    # say L3751 pla
    old "Heh, I’m glad you’re so excited."
    new "B:lis: Tudo está a acontecer tão depressa, é tão excitante..."

    # say L3752 pla
    old "Well, I’ll be on standby for whenever you need me."
    new "B:pla: Heh, fico contente por estares tão entusiasmado."

    # say L3753 lis
    old "Yes, don’t worry, you’ll be back here helping me soon. There are even new clients I’d like you to meet."
    new "B:pla: Bem, vou estar de sobreaviso para quando precisares de mim."

    # say L3754 lis
    old "For now, rest and keep working on your exercises and inner energy."
    new "B:lis: Sim, não te preocupes, vais voltar aqui a ajudar-me em breve. Até há novos clientes que gostaria que conhecesses."

    # say L3755 pla
    old "Sure, I’ll keep that in mind."
    new "B:lis: Por agora, descansa e continua a trabalhar nos teus exercícios e energia interna."

    # say L3756 lis
    old "Excellent, have a great day [pla], we’ll see each other soon."
    new "T(lis|tu|say): Excelente, tenha um bom dia [pla], vemo-nos em breve."

    # say L3781 pla
    old "Hello Lisa, how are you?"
    new "B:pla: Adeus Lisa, até breve."

    # say L3782 lis
    old "Good, the energies have come to me, how about you."
    new "B:pla: Olá Lisa, como estás?"

    # say L3783 pla
    old "Pretty nice, I am glad to see everything is going well."
    new "B:lis: Bom, as energias chegaram a mim, e tu?"

    # say L3784 lis
    old "I can't complain, the business is running just fine."
    new "B:pla: Muito bem, fico contente por ver que tudo está a correr bem."

    # say L3785 pla
    old "Hmm... I'm happy for you."
    new "B:lis: Não posso reclamar, o negócio está a correr bem."

    # say L3786 lis
    old "Remember that you are free to come over any time you want for a few free yoga lessons."
    new "B:pla: Hmm... Estou feliz por ti."

    # say L3787 pla
    old "Sure, I think, I'll make an appointment soon."
    new "B:lis: Lembra-te que és livre para vir quando quiseres para algumas aulas de ioga gratuitas."

    # say L3788 lis
    old "That sounds good, you have such energy and potential."
    new "B:pla: Claro, acho que vou marcar um encontro em breve."

    # say L3789 pla
    old "Thank you. Anyway, I will let you keep working, it was nice to see you."
    new "B:lis: Isso soa bem, tu tens tanta energia e potencial."

    # say L3790 lis
    old "It was nice to you too, have a wonderful day."
    new "B:pla: Obrigado. De qualquer forma, vou deixar-te continuar a trabalhar, foi bom ver-te."

    # say L3826 pla
    old "No, no, sorry I was just walking around. See you later..."
    new "B:lis: Foi bom conhecer-te também, que tenhas um ótimo dia."

    # say L3841 lis
    old "Hey, good morning, nice to see you so early."
    new "B:pla: Não, não, desculpa, estava só a passear. Até mais..."

    # say L3842 pla
    old "Hehehe,It's nice to see you too."
    new "B:lis: Olá, bom dia, é bom ver-te tão cedo."

    # say L3843 lis
    old "I am always ready very early to make the sungreeting, it's one of my favorites, you can't imagine how grateful I feel with the universe."
    new "B:pla: Hehehe, é bom ver-te também."

    # say L3844 pla
    old "Sounds very interesting."
    new "Por acaso, por que estás tão cedo aqui? Queres praticar?"

    # say L3846 lis
    old "By the way, why are you so early here? Do you want to practice?"
    new "B:pla: Parece muito interessante."

    # say L3850 pla
    old "Oh no, I can't at this moment."
    new "B:lis: Por acaso, porque estás tão cedo aqui? Queres praticar?"

    # say L3851 lis
    old "It's ok, remember you need to keep on training so you can take the most out of you and your energy."
    new "B:pla: Oh não, não posso agora."

    # say L3852 pla
    old "You are right."
    new "B:lis: Está bem, lembra-te que precisas de continuar a treinar para tirares o máximo proveito de ti e da tua energia."

    # say L3853 lis
    old "Don't forget you are welcome to train whenever you need."
    new "B:pla: Tens razão."

    # say L3854 pla
    old "I appreciate your kindness."
    new "B:lis: Não te esqueças que és bem-vindo para treinar sempre que precisares."

    # say L3855 lis
    old "It's always good to have you here, come back anytime you want."
    new "B:pla: Aprecio a tua bondade."

    # say L3856 pla
    old "I'll do, bye bye."
    new "B:lis: É sempre bom ter-te aqui, volta quando quiseres."

    # say L3857 lis
    old "bye!"
    new "A:pla: Sim, acho que preciso trabalhar nisso, por isso vim ver se tu não estás ocupado."

    # say L3860 pla
    old "Yes, I think I need to work on that, so I came to check if you are not busy."
    new "B:lis: adeus!"

    # say L3861 lis
    old "Oh no, I was about to start my training too so we can do it together."
    new "B:pla: Sim, acho que preciso trabalhar nisso, então vim ver se tu não estás ocupado."

    # say L3863 lis
    old "Let's go to the training room to be more comfortable."
    new "B:lis: Oh não, eu também ia começar o meu treino, podemos fazer juntos."

    # say L3866 lis
    old "What exercise would you like to train with?"
    new "B:lis: Vamos para a sala de treino para ficar mais confortáveis."

    # say L3870 lis
    old "Excellent choice, let's start to make the most out of this morning."
    new "B:lis: Que exercício gostarias de fazer?"

    # say L3871 pla
    old "Wonderful, I am full of energy today."
    new "B:lis: Excelente escolha, vamos aproveitar ao máximo esta manhã."

    # say L3893 lis
    old "That was wonderful, please keep that enthusiasm, Yoga is better with such a great attitude like yours."
    new "B:pla: Maravilhoso, estou cheia de energia hoje."

    # say L3894 pla
    old "Yes, I'm in a very good mood, every position helped me today to feel a lot better."
    new "B:lis: Isso foi maravilhoso, por favor, mantém essa entusiasmo, o ioga é melhor com uma atitude tão positiva como a tua."

    # say L3895 lis
    old "We can continue training anytime you need..."
    new "B:pla: Sim, estou num ótimo humor, todas as posições me ajudaram muito hoje a me sentir melhor."

    # say L3896 pla
    old "Sure, I will be coming more often to improve!"
    new "B:lis: Podemos continuar a treinar sempre que precisares..."

    # say L3897 lis
    old "I love to hear that."
    new "B:pla: Claro, vou vir mais vezes para melhorar!"

    # say L3903 pla
    old "Thank you, it was a very incredible time today."
    new "B:lis: Adoro ouvir isso."

    # say L3904 lis
    old "You did a fantastic job, keep working hard."
    new "B:pla: Obrigado, foi um dia incrível."

    # say L3905 pla
    old "I will!"
    new "T: Vou fazer! Não me esqueço das aulas com Anastasia à tarde e das sessões tântricas à noite, tenho muito trabalho pela frente."

    # say L3906 lis
    old "Remember the lessons with Anastasia at the afternoon and also the tantric sessions at night, you have a lot of work to do."
    new "B:pla: Vou!"

    # say L3907 pla
    old "Yes, I will be on time."
    new "B:lis: Lembra-te das aulas com Anastasia à tarde e também das sessões tântricas à noite, tens muito trabalho para fazer."

    # say L3908 lis
    old "It was nice to see you."
    new "B:pla: Sim, vou estar a tempo."

    # say L3909 pla
    old "It was nice to see you too, see you later."
    new "B:lis: Foi bom ver-te."

    # say L3910 lis
    old "Perfect, keep your energies for this afternoon."
    new "B:pla: Foi bom ver-te também, até mais tarde."

    # say L3927 lis
    old "I'm great... So? Are you ready to have another tantric session?"
    new "B:pla: Olá, estou bem, e tu?"

    # say L3931 pla
    old "Oh no, thank you."
    new "B:lis: Estou ótima... E tu? Estás pronto para mais uma sessão tântrica?"

    # say L3932 lis
    old "It's ok, remember you need to keep training so you can make the most out of you and your energy."
    new "B:pla: Oh não, obrigado."

    # say L3937 pla
    old "I will, bye bye."
    new "B:lis: Tudo bem, lembra-te que precisas de continuar a treinar para poderes tirar o máximo proveito de ti e da tua energia."

    # say L3940 lis
    old "It's really important for you to continue these trainings so you can control your chakras better, you know this is a complete process you can't stop."
    new "B:pla: Vou, adeus."

    # say L3941 pla
    old "Yes, you are right."
    new "B:lis: É realmente importante que continues com estes treinos para poderes controlar melhor os teus chakras, sabes que isto é um processo completo e não podes parar."

    # say L3942 lis
    old "Let's go to the room so we can start."
    new "B:pla: Sim, tens razão."

    # say L3944 lis
    old "What session did you like the most? Whichever it is we can repeat it."
    new "B:lis: Vamos para o quarto para podermos começar."

    # menu L3947 
    old "Session 1"
    new "B:lis: Qual sessão gostaste mais? Podemos repetir a que tu escolheres."

    # say L3948 lis
    old "Good option, let's start to make the most out of this tantric session tonight."
    new "T(lis|tu|say): Boa opção, vamos aproveitar ao máximo esta sessão tântrica esta noite."

    # say L3949 pla
    old "Perfect, I am very relaxed and ready to start the massage..."
    new "B:lis: Boa opção, vamos aproveitar ao máximo esta sessão tântrica esta noite."

    # menu L3953 
    old "Session 2"
    new "B:pla: Perfeito, estou muito relaxado e pronto para começar a massagem..."

    # menu L3959 
    old "Session 3"
    new "Tem sido um tempo realmente bom, vejo a tua melhoria em cada sessão, a tua energia mudou completamente."

    # say L3975 lis
    old "It has been a really good time, I can see your improvement with every single session, your energy has totally changed."
    new "T(lis|tu|say): Tem sido um tempo realmente bom, vejo a tua melhoria em cada sessão, a tua energia mudou completamente."

    # say L3976 pla
    old "I appreciate all that you say."
    new "T: Aprecio tudo o que dizes."

    # say L3977 lis
    old "It's really amazing to see the progress you have achieved."
    new "B:pla: Aprecio tudo o que dizes."

    # say L3978 pla
    old "Any progress is thanks to you."
    new "B:lis: É realmente impressionante ver o progresso que tu conseguiste."

    # say L3979 lis
    old "We need to keep training to be better every time."
    new "B:pla: Qualquer progresso é graças a ti."

    # say L3985 lis
    old "I'm grateful with the universe for this wonderful opportunity, I hope we can meet more often, so you can improve the control over your chakras."
    new "B:lis: Precisamos de continuar a treinar para sermos melhores a cada vez."

    # say L3986 pla
    old "Sure, I will come more often."
    new "B:lis: Estou grato com o universo por esta oportunidade maravilhosa, espero que possamos nos encontrar mais vezes, para que tu possas melhorar o controle sobre os teus chakras."

    # say L3987 lis
    old "It was nice to see, have a good one."
    new "B:pla: Claro, vou passar mais vezes."

    # say L3988 pla
    old "Same or you, bye!"
    new "T: O mesmo para ti, adeus!"

    # say L4002 lis
    old "Hi Anastasia, how is everything going?"
    new "T(lis|tu|diz): Olá Anastasia, como está tudo?"

    # say L4017 ana
    old "Hi, I was waiting for you, glad to see you got here fine, I came ready to have a good session today."
    new "B:pla: Muito Bem! Olá Anastasia."

    # say L4018 pla
    old "Oh perfect!"
    new "B:ana: Olá, estava à espera de ti, fico contente que tenhas chegado bem, vim preparada para uma boa sessão hoje."

    # say L4019 lis
    old "Well guys, I will leave alone so you can work hard, in case you need me, I will be here."
    new "B:pla: Ótimo!"

    # say L4020 pla
    old "I appreciate that..."
    new "B:lis: Bem, pessoal, vou deixar-vos sozinhos para trabalharem. Se precisarem de mim, estarei aqui."

    # say L4021 ana
    old "Let's go to the room, I need to train NOW..."
    new "B:pla: Aprecio isso..."

    # say L4028 ana
    old "What exercise are we going to do today?"
    new "B:ana: Vamos para o quarto, preciso de treinar AGORA..."

    # say L4029 pla
    old "Well, let me tell you..."
    new "B:ana: Que exercício vamos fazer hoje?"

    # menu L4032 
    old "Exercise 1"
    new "B:pla: Bem, deixa-me contar-te..."

    # say L4033 ana
    old "That's a great choice, I will do my best to ensure that you learn as much we can."
    new "T(ana|tu|diz): É uma excelente escolha, vou fazer o meu melhor para garantir que aprendas o máximo possível."

    # say L4034 pla
    old "Sounds really good."
    new "Soa mesmo bem."

    # menu L4038 
    old "Exercise 2"
    new "Soa mesmo bem."

    # menu L4044 
    old "Exercise 3"
    new "B:n: Exercício 2"

    # menu L4050 
    old "Exercise 4"
    new "Foi delicioso, adoro estas sessões."

    # say L4062 ana
    old "It was delicious, I really love these sessions."
    new "T(ana|tu|diz): Estava delicioso, adoro mesmo estas sessões."

    # say L4063 pla
    old "I am glad that you are satisfied, I am training hard so I can help you better."
    new "B:ana: Estava delicioso, adoro estas sessões."

    # say L4064 ana
    old "Please, don't stop training, your job is quite interesting."
    new "B:pla: Fico contente que estejas satisfeito/a, estou a treinar muito para poder ajudar-te melhor."

    # say L4065 pla
    old "Ok, I will continue working hard."
    new "Perfeito, porque estás programado para mim a partir de agora."

    # say L4066 ana
    old "Perfect, because you are scheduled for me from now on."
    new "B:pla: Ok, vou continuar a trabalhar duro."

    # say L4067 pla
    old "Ok, I hope to see you next session."
    new "B:ana: Perfeito, porque estás agendada para mim a partir de agora."

    # say L4068 ana
    old "I'll be here ready for a new adventure."
    new "B:pla: Ok, espero ver-te na próxima sessão."

    # say L4069 pla
    old "I'll be ready!"
    new "Estarei pronta!"


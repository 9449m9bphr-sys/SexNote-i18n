# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

translate portuguese strings:

    old "History"
    new "Histórico"

    old "Save"
    new "Guardar"

    old "Q.Save"
    new "G.Rápido"

    old "Q.Load"
    new "C.Rápido"

    old "Prefs"
    new "Opções"

    old "Start"
    new "Começar"

    old "Load"
    new "Carregar"

    old "Preferences"
    new "Preferências"

    old "Gallery"
    new "Galeria"

    old "End Replay"
    new "Terminar replay"

    old "Main Menu"
    new "Menu principal"

    old "About"
    new "Acerca"

    old "Help"
    new "Ajuda"

    old "Quit"
    new "Sair"

    old "Return"
    new "Voltar"

    old "If you liked and want to support us and check the new updates:"
    new "Se gostaste e queres apoiar-nos e ver as novas atualizações:"

    old "{color=#16a5cc}{b}Wizards:{/b}{/color}#, A AA, A Guy named Stefan, aaron strunk, Adarran, Adesh Korada, Alduin Thuri, Alex, Alex Lee, Alexander Lopez, Andrew Alexander, Andrew steffen, andrew tozer, anon, Anthony, Arsene, Arthur Coudert, avekfh, Avery Darby, Avman72, BeerBellyBro, Ben Fraser, Berry, Blacklight0425, Blubber Duck, BohemianRabbit, Branchman41, Braulio Gallegos-Gonzalez, Brian Jones, C Aagesen, Caleb Grant, Caleb Robertsjones, Carlos G Diaz, Catelusul Ham Ham, Chance Medlin, Chance Rodriguez, Chaotic Zaros, Chazardzard, Chephyy, Christopher, Cody Knochelmann, Collin Shields, CurseKeem, Dagger, Damonte Ransey, Darius Patton, Darrius Wade, Derrick Johnson, Dino Torres, Dj Happg, DJNipTwist, Doc Pan As, Doc854, Doctor Giraffe, dragon hunter, Draven x, El Rando Salvo, Elias, Elias Ritter, Emmanuel Abel, Eric, Ethan, Ethan Blessemaille, Fjallar Otterson, Franklin Snyder, Fredrik, Gaming Account, Gareth Whitlow, Geoff, Gin, Grimm, Halic1108, Harry Hunsberger, Harvey Mountford, Herb665, ingerbr, iron Kill, Isaiah Coleman, Isaiah Pacheco, Iseedeadllamas, Ivan Flores, Jack Fair, jackson lynch, James, jayden weatherford, Jesus Fregozo, Jetendra Lalchan, Joe Gehling, Joel Harper, John Fugate, John T, Johnathan Balfour, Jordan L, Jorgito Breton, Joseph P Hawley, Joseph Righter, Josh Dischinger, junangulas, Justin, Justin Smith, Justin Spahn, JustThatGuy, KaiserRob, kazuo kenshin, ken smith, Kieran Coles, lmninja64, Logan Cooper, Lord Eagle, Lucas Hogh-Janovsky, MajehEX, Marco Scherer, matt congrove, Matt Richardson, Matthew Ober, Maxx, Mickel Rateliff, MLordBoss97, mole man, Mungan, Nathan Cochran, NerdyCaveman, Nick Moore, Nobody, NU, OffbeatLemon137, Omar, Omnibreed001, ouweseun, Patricio Pulgar, Patrick Bertin, Patrick Tanner, philip carter, Pierson trueblood, PutasBoy, Quinton Woods, R4ttenf4enger, Rail Meiko, Ray Smith, Rey Mitchell, Richard Roche, Rick Stout, Rob Banks, Rob Willard, Robert Duplessis, Roul Druck, Rust, RwEd ForTheWin, Saggy Sauce, Samic, ScarlettAurora, Shane Antonacci, SpookyMan, ssbn571 ., Stoven, Tena Fich, Thana.N.Ye, TheLoneKek, Thereader, Titan91, Toot Poot, Tummetott, Tyren Gray, UUVG, Victor Saganoff, Wezz, William, Willim Ortega, Yang Eric, zac, Zlaire Asberry, عبدالعزيز وارد, ・ひで・, 恭郡 何, 김종근 김, "
    new "B:n: {color=#16a5cc}{b}Feiticeiros:{/b}{/color} - Oerni -, 3ddi3k, aneondarkey,"

    old "{color=#16a5cc}{b}Conjurers:{/b}{/color} Andrea, anthony, bophades96, Caboose-1, Christopher Martin, Corbin Hubble, Curtis S, Death Angel, Deiondre Tracey, Dick, DRatt7288, EmbraceAbundance, Erik Piehl, Fabio Giusti, Flame S0lider, Florian Game, goonmaster6969, Henry Coleman, Indy Duffy, Jace Tangler, james jordan, Jan Tallardt, Jim Max, John Tyler, Keith Alexander, Kevin, Kuba Kluszczynski, Lauritsbb, Lhurlu, loiq fortin, Lurtz111, Manna Moth, marc witten, mark rodriguez, Matisse Vobaure, Matthew Myers, Max, michael finch, miloarty, Murphy Wakefield, Nathaniel Brooks, Nova, Oz, Paris, Petzy33, Pimmel Warze, PrDauny21, Ramz, Raptor2283, Ronnie S, , SAITAMA CAPA, Scott Liebenow, Sebastian Lopez, SetforDark, Shadow Blackheart, SkullKidDanzen, Sou11ess19, sumu black, Tapelesslion Gaming, Tobias, Tom Schubert, torsten kristensen, Tyler M., uchihazelda, ViolentBone, Whyze, William Walker, บิ มา กายโรสแมรี่."
    new "B:n: {color=#16a5cc}{b}Feiticeiros:{/b}{/color} Andrea, anthony, bophades96, Caboose-1, Christopher Martin, Corbin Hubble, Curtis S, Death Angel, Deiondre Tracey, Dick, DRatt7288, EmbraceAbundance, Erik Piehl, Fabio Giusti, Flame S0lider, Florian Game, goonmaster6969, Henry Coleman, Indy Duffy, Jace Tangler, james jordan, Jan Tallard"

    old "Page {}"
    new "T(n|tu|ui): Página {}"

    old "Automatic saves"
    new "Salvamentos rápidos"

    old "Quick saves"
    new "B:n: Salvamento automático"

    old "Display"
    new "Janela"

    old "Window"
    new "Janela"

    old "Fullscreen"
    new "Ecrã inteiro"

    old "Rollback Side"
    new "Desativar"

    old "Disable"
    new "Desativar"

    old "Left"
    new "B:n: Desativar"

    old "Right"
    new "B:n: Esquerda"

    old "Unseen Text"
    new "Certo"

    old "After Choices"
    new "Depois das escolhas, as transições fluem naturalmente, levando-te a novos cenários e situações."

    old "Transitions"
    new "Transições"

    old "Language"
    new "Idioma"

    old "English"
    new "Inglês"

    old "Text Speed"
    new "Velocidade do texto"

    old "Auto-Forward Time"
    new "B:n: Velocidade de Texto"

    old "Music Volume"
    new "Volume da música"

    old "Sound Volume"
    new "Volume dos efeitos"

    old "Test"
    new "B:n: Volume de Som"

    old "Voice Volume"
    new "Volume da voz"

    old "Mute All"
    new "O histórico de diálogo está vazio."

    old "The dialogue history is empty."
    new "O histórico de diálogo está vazio."

    old "Keyboard"
    new "Teclado"

    old "Mouse"
    new "B:n: Teclado"

    old "Gamepad"
    new "Introduzir"

    old "Enter"
    new "Avança o diálogo e ativa a interface."

    old "Advances dialogue and activates the interface."
    new "Avança o diálogo e ativa a interface."

    old "Space"
    new "Avança o diálogo sem selecionar opções."

    old "Advances dialogue without selecting choices."
    new "Avança o diálogo sem selecionar opções."

    old "Arrow Keys"
    new "B:n: Avança o diálogo sem selecionar opções."

    old "Navigate the interface."
    new "Sair do jogo."

    old "Escape"
    new "Acessa o menu do jogo."

    old "Accesses the game menu."
    new "Acessa o menu do jogo."

    old "Ctrl"
    new "Ctrl + ZZZ…ZZZ"

    old "Skips dialogue while held down."
    new "B:n: Ctrl"

    old "Tab"
    new "B:n: Omite o diálogo enquanto mantido pressionado."

    old "Toggles dialogue skipping."
    new "Pula o diálogo."

    old "Page Up"
    new "B:n: Alterna a omissão de diálogo."

    old "Rolls back to earlier dialogue."
    new "B:n: Página Anterior"

    old "Page Down"
    new "B:n: Volta para um diálogo anterior."

    old "Rolls forward to later dialogue."
    new "Avança para o diálogo posterior."

    old "Hides the user interface."
    new "B:n: Avança para um diálogo posterior."

    old "Takes a screenshot."
    new "B:n: Esconde a interface do utilizador."

    old "Middle Click"
    new "B:n: Clique Esquerdo"

    old "Right Click"
    new "Clique com o botão do meio do rato"

    old "Mouse Wheel Up\nClick Rollback Side"
    new "B:n: Botão Direito"

    old "Mouse Wheel Down"
    new "B:n: Rato Roda Para Cima"

    old "Right Trigger\nA/Bottom Button"
    new "B:n: Rato Rodar para Baixo"

    old "Left Trigger\nLeft Shoulder"
    new "G Gatilho Direito"

    old "Right Shoulder"
    new "B:n: Gatilho Esquerdo"

    old "D-Pad, Sticks"
    new "Ombro Direito"

    old "Start, Guide"
    new "B:n: D-Pad, Sticks"

    old "Y/Top Button"
    new "Calibrar"

    old "Calibrate"
    new "Calibrar"

    old "Skipping"
    new "B:n: Não"

    old "Mrs Mia"
    new "Sra. Mia"

    old "Developer"
    new "Vai dormir."


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

translate japanese strings:

    old "History"
    new "履歴"

    old "Auto"
    new "オート"

    old "Save"
    new "セーブ"

    old "Q.Save"
    new "Q.セーブ"

    old "Q.Load"
    new "Q.ロード"

    old "Prefs"
    new "設定"

    old "Start"
    new "スタート"

    old "Load"
    new "ロード"

    old "Preferences"
    new "設定"

    old "Gallery"
    new "ギャラリー"

    old "End Replay"
    new "リプレイ終了"

    old "Main Menu"
    new "メインメニュー"

    old "About"
    new "アバウト"

    old "Help"
    new "ヘルプ"

    old "Quit"
    new "終了"

    old "Return"
    new "戻る"

    old "Version [config.version!t]"
    new "バージョン [config.version!t]"

    old "If you liked and want to support us and check the new updates:"
    new "もし気に入ってくれたら、応援していただけると嬉しいです。新しいアップデートもチェックしてください。"

    old "Visit our Patreon {color=#ff8b00}{a=https://www.patreon.com/sexnote}{b}SexNote{/b}{/a}{/color} and {color=#ff8b00}{a=https://www.patreon.com/lustlegacy}{b}Lust Legacy{/b}{/a}{/color}. "
    new "Patreon {color=#ff8b00}{a=https://www.patreon.com/sexnote}{b}SexNote{/b}{/a}{/color} と {color=#ff8b00}{a=https://www.patreon.com/lustlegacy}{b}Lust Legacy{/b}{/a}{/color} を訪れてみてください。"

    old "{size=+10}{color=#a6ecff}{b}THANKS TO OURS PATRONS!:{/b}{/color}{/size}"
    new "{size=+10}{color=#a6ecff}{b}サンクス・トゥ・アワーズ・パトロンズ！:{/b}{/color}{/size}"

    old "{color=#16a5cc}{b}Legendary Wizards:{/b}{/color} {b}Thighhighstockinglover, Zero, smittskey.{/b}."
    new "{color=#16a5cc}{b}伝説の魔法使い:{/b}{/color} {b}Thighhighstockinglover, Zero, smittskey.{/b}."

    old "{color=#16a5cc}{b}Dark Wizards:{/b}{/color} - Oerni -, 3ddi3k, aneondarkey, Anthony Fantini, Benjamin Lane, Bernier Jerome, Call Me Unseen, controller__, cronkdrong, DarkDrago, Dawn Jennifer McCool, Dean Miller, Declan Kyle Regan, Dennis Langston Jr., Donkykang, DRAGNEEL, Dusty, Dániel Seres, Elliott Goers, Emory, Forezra, Fused Dstyles, g420, god is dead, Haakon Thorsheim, HiddenJackalope, ies, james mcveigh, James Register, Jamie Allen, Jeremiah Koahou, JJ, Jonathon Viser, Joseph, Laura García Garcés, Lazy_domo, Louis Siu, Marco, meatntea, Mikael Linderoth, Muhtesem Valdo, NeoBoy, Noé Guinebert, Peter Sileo, phantom demon, PMK1N, ramsey, RebelCj, Reiley Simmons, Rezel, Rictor86, Robert Narron, roguez, sam, Scooty Popsr4, Sean Walsh, Shadow_Wolf, sichen zou, Spanksr, Staple, Stephen Carlo, Jr, thacrow456, TorumSie, Tuấn Trần, X_Konsti_X, Yatzee, Zodiac, 부 두."
    new "{color=#16a5cc}{b}ダークウィザード:{/b}{/color} - Oerni -、3ddi3k、aneondarkey、Anthony Fantini、Benjamin Lane、Bernier Jerome、Call Me Unseen、controller__、cronkdrong、DarkDrago、Dawn Jennifer McCool、Dean Miller、Declan Kyle Regan、Dennis Langston Jr.、Donkykang、DRAGNEEL、Dusty、Dániel Seres、Elliott Goers、Emory、Forezra、Fused Dstyles、g420、god is dead、Haakon Thorsheim、HiddenJackalope、ies、james mcveigh、James Register、Jamie Allen、Jeremiah Koahou、JJ、Jonathon Viser、Joseph、Laura García Garcés、Lazy_domo、Louis Siu、Marco、meatntea、Mikael Linderoth、Muhtesem Valdo、NeoBoy、Noé Guinebert、Peter Sileo、phantom demon、PMK1N、ramsey、RebelCj、Reiley Simmons、Rezel、Rictor86、Robert Narron、roguez、sam、Scooty Popsr4、Sean Walsh、Shadow_W"

    old "{color=#16a5cc}{b}Wizards:{/b}{/color}#, A AA, A Guy named Stefan, aaron strunk, Adarran, Adesh Korada, Alduin Thuri, Alex, Alex Lee, Alexander Lopez, Andrew Alexander, Andrew steffen, andrew tozer, anon, Anthony, Arsene, Arthur Coudert, avekfh, Avery Darby, Avman72, BeerBellyBro, Ben Fraser, Berry, Blacklight0425, Blubber Duck, BohemianRabbit, Branchman41, Braulio Gallegos-Gonzalez, Brian Jones, C Aagesen, Caleb Grant, Caleb Robertsjones, Carlos G Diaz, Catelusul Ham Ham, Chance Medlin, Chance Rodriguez, Chaotic Zaros, Chazardzard, Chephyy, Christopher, Cody Knochelmann, Collin Shields, CurseKeem, Dagger, Damonte Ransey, Darius Patton, Darrius Wade, Derrick Johnson, Dino Torres, Dj Happg, DJNipTwist, Doc Pan As, Doc854, Doctor Giraffe, dragon hunter, Draven x, El Rando Salvo, Elias, Elias Ritter, Emmanuel Abel, Eric, Ethan, Ethan Blessemaille, Fjallar Otterson, Franklin Snyder, Fredrik, Gaming Account, Gareth Whitlow, Geoff, Gin, Grimm, Halic1108, Harry Hunsberger, Harvey Mountford, Herb665, ingerbr, iron Kill, Isaiah Coleman, Isaiah Pacheco, Iseedeadllamas, Ivan Flores, Jack Fair, jackson lynch, James, jayden weatherford, Jesus Fregozo, Jetendra Lalchan, Joe Gehling, Joel Harper, John Fugate, John T, Johnathan Balfour, Jordan L, Jorgito Breton, Joseph P Hawley, Joseph Righter, Josh Dischinger, junangulas, Justin, Justin Smith, Justin Spahn, JustThatGuy, KaiserRob, kazuo kenshin, ken smith, Kieran Coles, lmninja64, Logan Cooper, Lord Eagle, Lucas Hogh-Janovsky, MajehEX, Marco Scherer, matt congrove, Matt Richardson, Matthew Ober, Maxx, Mickel Rateliff, MLordBoss97, mole man, Mungan, Nathan Cochran, NerdyCaveman, Nick Moore, Nobody, NU, OffbeatLemon137, Omar, Omnibreed001, ouweseun, Patricio Pulgar, Patrick Bertin, Patrick Tanner, philip carter, Pierson trueblood, PutasBoy, Quinton Woods, R4ttenf4enger, Rail Meiko, Ray Smith, Rey Mitchell, Richard Roche, Rick Stout, Rob Banks, Rob Willard, Robert Duplessis, Roul Druck, Rust, RwEd ForTheWin, Saggy Sauce, Samic, ScarlettAurora, Shane Antonacci, SpookyMan, ssbn571 ., Stoven, Tena Fich, Thana.N.Ye, TheLoneKek, Thereader, Titan91, Toot Poot, Tummetott, Tyren Gray, UUVG, Victor Saganoff, Wezz, William, Willim Ortega, Yang Eric, zac, Zlaire Asberry, عبدالعزيز وارد, ・ひで・, 恭郡 何, 김종근 김, "
    new "{color=#16a5cc}{b}魔法使い:{/b}{/color}#, A AA, ステファンという男の子, aaron strunk, Adarran, Adesh Korada, Alduin Thuri, Alex, Alex Lee, Alexander Lopez, Andrew Alexander, Andrew steffen, andrew tozer, anon, Anthony, Arsene, Arthur Coudert, avekfh, Avery Darby, Avman72, BeerBellyBro, Ben Fraser, Berry, Blacklight0425, Blubber Duck, BohemianRabbit, Branchman41, Braulio Gallegos-Gonzalez, Brian Jones, C Aagesen, Caleb Grant, Caleb Robertsjones, Carlos G Diaz, Catelusul Ham Ham, Chance Medlin, Chance Rodriguez, Chaotic Zaros, Chazardzard, Chephyy, Christopher, Cody Knochelmann, Collin Shields, CurseKeem, Dagger, Damonte Ransey, Darius Patton, Darrius Wade, Derrick Johnson, Dino Torres, Dj Happg, DJNipTwist, Doc Pan As, Doc854, Doctor Giraffe, dragon hunter, Draven x, El Rando Salvo, Elias, Elias Ritter, Emmanuel Abel, Eric, Ethan, Ethan Blessemail"

    old "{color=#16a5cc}{b}Conjurers:{/b}{/color} Andrea, anthony, bophades96, Caboose-1, Christopher Martin, Corbin Hubble, Curtis S, Death Angel, Deiondre Tracey, Dick, DRatt7288, EmbraceAbundance, Erik Piehl, Fabio Giusti, Flame S0lider, Florian Game, goonmaster6969, Henry Coleman, Indy Duffy, Jace Tangler, james jordan, Jan Tallardt, Jim Max, John Tyler, Keith Alexander, Kevin, Kuba Kluszczynski, Lauritsbb, Lhurlu, loiq fortin, Lurtz111, Manna Moth, marc witten, mark rodriguez, Matisse Vobaure, Matthew Myers, Max, michael finch, miloarty, Murphy Wakefield, Nathaniel Brooks, Nova, Oz, Paris, Petzy33, Pimmel Warze, PrDauny21, Ramz, Raptor2283, Ronnie S, , SAITAMA CAPA, Scott Liebenow, Sebastian Lopez, SetforDark, Shadow Blackheart, SkullKidDanzen, Sou11ess19, sumu black, Tapelesslion Gaming, Tobias, Tom Schubert, torsten kristensen, Tyler M., uchihazelda, ViolentBone, Whyze, William Walker, บิ มา กายโรสแมรี่."
    new "{color=#16a5cc}{b}呪術師:{/b}{/color} アンドレア、アンソニー、bophades96、Caboose-1、クリストファー・マーティン、コルビン・ハブル、カーティス・S、デス・エンジェル、ディオンdre・トレーシー、ディック、DRatt7288、EmbraceAbundance、エリック・ピール、ファビオ・ジウスティ、フレーム・ソルジャー、フロリアン・ゲーム、グーンマスター6969、ヘンリー・コールマン、インディ・ダフィー、ジェイス・タンガラー、ジェームズ・ジョーダン、ヤン・タラルト、ジム・マックス、ジョン・タイラー、キース・アレクサンダー、ケビン、クバ・クルシュチンスキ、ラウリツ・B、Lhurlu、ロイク・フォルタン、Lurtz111、マナ・モス、マーク・ウィッテン、マーク・ロドリゲス、マティス・ボバール、マシュー・マイヤーズ、マックス、マイケ"

    old "Page {}"
    new "ページ {}"

    old "Automatic saves"
    new "オートセーブ"

    old "Quick saves"
    new "クイックセーブ"

    old "empty slot"
    new "空きスロット"

    old "Display"
    new "表示"

    old "Window"
    new "ウィンドウ"

    old "Fullscreen"
    new "フルスクリーン"

    old "Rollback Side"
    new "ロールバックサイド"

    old "Disable"
    new "無効に"

    old "Left"
    new "左"

    old "Right"
    new "右"

    old "Unseen Text"
    new "見えないテキスト"

    old "After Choices"
    new "選択肢の後"

    old "Transitions"
    new "移行"

    old "Language"
    new "言語"

    old "English"
    new "英語"

    old "Text Speed"
    new "文字速度"

    old "Auto-Forward Time"
    new "自動進める時間"

    old "Music Volume"
    new "音楽の音量"

    old "Sound Volume"
    new "効果音の音量"

    old "Test"
    new "テスト"

    old "Voice Volume"
    new "ボイスの音量"

    old "Mute All"
    new "全てミュートする"

    old "The dialogue history is empty."
    new "会話履歴が空です。"

    old "Keyboard"
    new "キーボード"

    old "Mouse"
    new "マウス"

    old "Gamepad"
    new "ゲームパッド"

    old "Enter"
    new "入力"

    old "Advances dialogue and activates the interface."
    new "会話とインターフェースを進める"

    old "Space"
    new "スペース"

    old "Advances dialogue without selecting choices."
    new "会話を進める"

    old "Arrow Keys"
    new "矢印キー"

    old "Navigate the interface."
    new "インターフェースを操作する"

    old "Escape"
    new "エスケープ"

    old "Accesses the game menu."
    new "ゲームメニューを開く"

    old "Skips dialogue while held down."
    new "押しっぱなしで会話をスキップする。"

    old "Tab"
    new "タブ"

    old "Toggles dialogue skipping."
    new "ダイアログスキップを切り替える"

    old "Page Up"
    new "ページアップ"

    old "Rolls back to earlier dialogue."
    new "前の会話に戻る"

    old "Page Down"
    new "ページダウン"

    old "Rolls forward to later dialogue."
    new "後の会話に進む"

    old "Hides the user interface."
    new "ユーザーインターフェースを隠す"

    old "Takes a screenshot."
    new "スクリーンショットを撮る"

    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "アシスタントの {a=https://www.renpy.org/l/voicing}自己音声化{/a} を切り替える"

    old "Left Click"
    new "左クリック"

    old "Middle Click"
    new "中央クリック"

    old "Right Click"
    new "右クリック"

    old "Mouse Wheel Up\nClick Rollback Side"
    new "マウスホイールアップ"

    old "Mouse Wheel Down"
    new "マウスホイールダウン"

    old "Right Trigger\nA/Bottom Button"
    new "右トリガー"

    old "Left Trigger\nLeft Shoulder"
    new "左トリガー"

    old "D-Pad, Sticks"
    new "D-Pad、スティック"

    old "Start, Guide"
    new "スタート、ガイド"

    old "Y/Top Button"
    new "Y/上ボタン"

    old "Calibrate"
    new "キャリブレーションする"

    old "Skipping"
    new "スキップ"

    old "Menu"
    new "メニュー"

    old "Mrs Mia"
    new "ミア夫人"

    old "Developer"
    new "開発者"


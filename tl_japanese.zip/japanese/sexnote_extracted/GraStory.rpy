# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/GraStory.rpy
translate japanese strings:

    # say L5 pla
    old "(God! I hope everybody is sleeping already... I gotta whisper to her...)"
    new "神様！みんなもう寝てるといいんだけど… 声をひそめて話さなきゃ…"

    # say L6 pla
    old "{i}Psst psst psst, Hey... I'm [pla], I know you are in trouble... I can help you! Where are you?{/i}"
    new "{i}プスプスプス、Hey... 僕は[pla]だ、君が困ってるって知ってんだ... 手伝うよ！どこにいるの？{/i}"

    # say L7 pla
    old "{i}You can trust me... Just let me see you, I came here to help you.{/i}"
    new "{i}君を信じてくれ… ただ顔を見せて、助けに来たんだから {/i}"

    # say L9 gra
    old "Hello! Who's there?"
    new "こんにちは！誰がいるの？"

    # say L11 gra
    old "If you come to steal, you are in the wrong place... Don't you see this is God's house?!"
    new "もし盗みに来たのなら、間違ったところに来たわ… ここは神様の家だということに気づいていないの？！"

    # say L13 pla
    old "(Holy shit! The nun heard me... I need to hide.)"
    new "やばい！修道女に見つかった……隠れるしかない。"

    # say L22 gra
    old "(But... I don't see anybody... God! Maybe it is Father Morgan...)"
    new "でも... 誰も見えないわ... 神様！もしかしてモーガン神父さん...？"

    # say L28 gra
    old "Father Morgan? It is you? I'm sorry, I thought it was somebody else, a thief... I didn't know you would have been here so late."
    new "Father Morgan？ あなたですか？ ごめんなさい、他の人がいると思ったの、泥棒かなって……こんな時間にここにいらっさるとは思わなかったの。"

    # say L37 pla
    old "(Holy fuck!! She also entered the confessional.)"
    new "Holy fuck！！ お前も告解室に入ってきたのか！"

    # say L40 gra
    old "Father? Are you upset? I'm sorry if I disturbed you with my shouting."
    new "Father？ お怒りですか？ 大声で迷惑をかけたなら、申し訳ありません。"

    # say L41 gra
    old "I see what you're thinking... I have done wrong again and I must clean up that offense I have committed, that's why you're so quiet."
    new "あなたの考えはわかります……また罪を犯してしまったから、その罪を償わなければいけないと思っているんでしょうね。だからこんなに静かなんですね。"

    # say L43 gra
    old "No father Morgan... You don't have to say a word."
    new "Father Morgan… 言葉にする必要はありませんよ。"

    # say L44 gra
    old "You know I'm totally faithful to the will of the Lord, I will let you guide me once again to cleanse my body of those bad thoughts."
    new "あなたが知っている通り、私は主の意志に完全に忠実です。再びあなたに導いていただき、私の体からその悪い考えを祓います。"

    # say L45 gra
    old "Thoughts that I had a few minutes ago."
    new "先ほど私が抱いていた悪い考えのことです。"

    # say L46 pla
    old "(What? What's she talking about?!)"
    new "何を言ってるんだよ？！"

    # say L47 pla
    old "(What's happening with her-)"
    new "（彼女に何が起こってるんだ-）"

    # say L48 gra
    old "Having faith in God means not being afraid and you are my guide, help me to purify this sinful soul. I'm giving you my spirit through my body, Father."
    new "神への信仰とは恐れることなく生きることであり、あなたが私の導き手です。この罪深い魂を浄化するために、私のお身体を通じて霊魂を捧げます、父よ。"

    # say L49 pla
    old "(I- is she talking about... s- sex?)"
    new "（彼女は… まさか… セックスのことを…？）"

    # say L50 gra
    old "I'm ready to receive your sacred water, your purifying milk... It's my mission to reach divinity through you, let me try it one more time."
    new "私はあなたの聖なる水、浄化のミルクを受け入れる準備ができています… 私の使命はあなたを通じて神性に達すること、もう一度試させてください。"

    # say L51 pla
    old "(Oh shit!... This is so wrong...)"
    new "オッシャイ！… これは全然違うよ…"

    # say L52 gra
    old "I'm asking you to help me, I've been on the edge of darkness and you've shown me the light... Father Morgan? Tell me something or show me your help, please!"
    new "あなたに助けてほしいの、暗闇の淵に立たされて、あなたが私に光を示してくれたんですから… ファーザー・モーガン？ 何か言ってください、またはあなたの助けを見せてください、お願いします！"

    # say L54 gra
    old "I want our God to be happy, there is nothing better or more beautiful and I will make him happy through you, Father."
    new "私たちの神様を幸せにしたいと思っています、それ以上に美しいものはありません。あなたを通じて神様を幸せにします、ファーザー。"

    # say L55 pla
    old "(My God! Alright, I gotta do this. If I don't, she'll suspect and see that I'm not the Father Morgan.)"
    new "神様！よし、やるしかない。もしやらないと、彼女は疑うだろうし、俺が本当のFather Morganじゃないって気づくだろう。"

    # say L76 gra
    old "My great Father Morgan, I don't have words to express how grateful I'm. One more time, you've shown me how big and great you're, I feel your grace."
    new "私の偉大なファーザー・モーガン、感謝の言葉もありません。またしても、あなたの大きさと偉大さを教えてくださいました。あなたの恵みを感じています。"

    # say L77 gra
    old "I will go to pray for you and for your great and powerful divine tool."
    new "私はあなたの伟大的で力強い神聖なための祈りに行きます。"

    # say L79 gra
    old "Good night Father Morgan, I'll be eager to see you again."
    new "おやすみなさい、Father Morgan。またお会いできるのを楽しみにしています。"

    # say L93 pla
    old "(What a night!...)"
    new "何という夜だ！"

    # say L94 pla
    old "(Argh! The shinigami... Shit! I couldn't find her! But I can't risk myself, perhaps the nun or the priest could come back...)"
    new "（ああ！死神…クソ！見つけられなかった！でも自分を危険にさらすわけにはいかない、修道女か司祭が戻ってくるかもしれない…）"

    # say L95 pla
    old "(I better come back another day...)"
    new "また別の日再来するのがいいな..."

    # say L108 pla
    old "(I hope the Sister Grace doesn't not appear tonight...)"
    new "（シスター・グレースが今晚現れないことを願うな...)"

    # say L109 pla
    old "{i}Psst psst psst, Hey shinigami... I'm [pla], I know you are in trouble...{/i}"
    new "{i}ピスッ ピスッ ピスッ、Hey 死神さん... 僕は[pla]だ、君が困ってるって知ってんだ...{/i}"

    # say L110 pla
    old "{i}You can trust me... I came here to help you, let me see where you are.{/i}"
    new "{i}君を信じていい… 僕は君を助けるために来た、どこにいるか見せててくれない？{/i}"

    # say L112 gra
    old "Hello! F- Father Morgan?"
    new "こんにちは！あのう、モーガン神父様？"

    # say L114 gra
    old "Is it you again?..."
    new "またあなたですか…"

    # say L116 pla
    old "(Oh no! She's back... Damn it!)"
    new "ああ、またか…くそ！"

    # say L126 gra
    old "Father Morgan? I was eager to see you again..."
    new "Father Morgan？ 再会を楽しみにしていました……"

    # say L135 gra
    old "Father? I'm sorry for bothering you again but I still need some help, my sins keep disturbing my soul."
    new "Father、申し訳ありませんがまたお邪魔してしまいました。でもまだお力添えが必要で、罪が私の魂を乱しています。"

    # say L136 gra
    old "I need to continue with the penance."
    new "罰を続けなければなりません。"

    # say L140 gra
    old "No father Morgan... You know I'm totally faithful to the will of the Lord, I will let you guide me once again to cleanse my body of those bad thoughts."
    new "Father Morgan… 私は主の意志に完全に忠実です、もう一度私の心を浄化するために、あなたの導きが必要です。"

    # say L141 gra
    old "Thoughts that I had today, again..."
    new "今日もまた、そんな悪い考えが……"

    # say L142 pla
    old "(I guess I already know what she wants...)"
    new "（彼女の望みはもうわかってるな…）"

    # say L143 pla
    old "(But what's happening with her, why to do this?)"
    new "（でも彼女がどうしたのか、なぜこんなことをするのかな？）"

    # say L144 gra
    old "Having faith in God means not being afraid and you are my guide, help me to purify this sinful soul. I am giving you my spirit through my body, Father."
    new "神様を信じることは恐れないこと、あなたが私の導きです。この罪深い魂を浄化するために、私の身体を通じて霊をあなたに捧げます、父上。"

    # say L145 pla
    old "(Well, I gotta do it... Otherwise she'll realized I'm not the Father Morgan)"
    new "じゃあ、やるしかないな… さもないと、君はボクがFather Morganじゃないことに気づくだろうから。"

    # say L146 gra
    old "Yes, I'm asking you to help me, I've been on the edge of darkness and you've shown me the light... Father Morgan? Show me your help, please!"
    new "はい、お助けください、暗闇の淵に立たされていましたが、あなたが私に光を示してくれました…ファーザー・モーガン？どうかお助けください。"

    # say L148 gra
    old "I want our God to be happy, there is nothing better or more beautiful and I will make him happy through you, my greatest Father."
    new "私たちの神様を幸せにしたいの、これ以上美しいものはないわ。あなたを通じて神様を幸せにするから、私の最高の父さん。"

    # say L149 gra
    old "My soul is open to be purified, as opened as my mouth right now..."
    new "私の魂は浄化のために開かれています、今この瞬間私の口も開いています…"

    # say L150 pla
    old "(Oh God!)"
    new "（おお、神様！）"

    # say L166 gra
    old "My great Father Morgan, you have no idea how grateful I'm. One more time, you've shown me how big and great you're, I can taste your grace."
    new "私の偉大なファーザー・モーガン、あなたがどれほど感謝しているかご存じありません。またしても、あなたの大きさと偉大さを教えてくださいました。私はあなたの恵みを感じることができます。"

    # say L169 gra
    old "Good night Father Morgan, I'll be needing more of your sacred assistance to purify my existence in this world."
    new "おやすみなさい、Father Morgan。この世での私の存在を浄化するために、もっとあなたの聖なる援助が必要です。"

    # say L183 pla
    old "(Damn it! I couldn't find the shinigami tonight either... I better come back another day... This is to risky, the nun could come back...)"
    new "（くそっ！今夜も死神は見つからなかったか……また別の日來るしかないな……これは危険すぎる、修道女が戻ってくるかもしれない……）"

    # say L196 pla
    old "(God! This is my last chance to find the shinigami, I gotta find her tonight.)"
    new "（神！これが最後のチャンスだ、今夜中に見つけないと。）"

    # say L197 pla
    old "{i}Psst psst psst, Hi... I'm [pla], a friend of shinigamis... I know you are in trouble, please show up!{/i}"
    new "{i}プスプスプス、こんにちは… 僕は[pla]、死神たちの友達なんだ… あなたが困ってるって知ってて、どうか姿を見せてくれ！{/i}"

    # say L200 gra
    old "Father Morgan... I'm so glad you're here."
    new "Father Morgan… 私、あなたが来てくれて本当に嬉しいです。"

    # say L203 pla
    old "(Argh! No... No again!!!)"
    new "ああ！いや……またダメだ！！"

    # say L213 gra
    old "I was waiting for you, my holy savior."
    new "私の聖なる救世主、あなたを待っていました。"

    # say L221 gra
    old "Father Morgan? How should we start tonight? Just tell me..."
    new "Father Morgan？ 今夜はどのように始めればいいでしょうか？ 教えてください……"

    # say L222 pla
    old "(Holy fuck!! She'll catch me this time...)"
    new "今度は本当に捕まってしまうぞ..."

    # say L223 gra
    old "Father? I already know you don't like to talk much when you're praying and well... I know what my soul needs this time. "
    new "Father、お祈りの時はあまり話したくないのは知っていますし……今回は私の魂が必要なものも分かります。"

    # say L227 gra
    old "Thoughts that I have had since long time ago."
    new "長い間抱いていた思いです。"

    # say L229 gra
    old "Having faith in your God means not being afraid and you are my guide, help me to purify this sinful soul. I am giving you my spirit through my body, Father."
    new "神様への信仰とは恐れることなく生きることです、そしてあなたは私の導き手です。この罪深い魂を浄化するために、私の身体を通じて私の精神をあなたに捧げます、父上。"

    # say L230 pla
    old "(Shit!... I gotta do it again.)"
    new "くそっ…またやり直すしかないな。"

    # say L248 gra
    old "My great Father Morgan, I don't have words to express how grateful I'm. You've shown me how big and great you're, I feel your grace inside."
    new "私の偉大なファーザー・モーガン、感謝の言葉もありません。あなたがどれほど大きくて素晴らしいかを教えてくれました、あなたの恵みを感じています。"

    # say L251 gra
    old "Good night Father Morgan, I can't wait to feel you inside of me again."
    new "おやすみなさい、Father Morgan。またあなたを感じるのが待ち遠しいです。"

    # say L266 pla
    old "(Damn it! This is becoming more and more complicated.)"
    new "くそっ！これってどんどん複雑になってるな。"

    # say L281 pla
    old "Hmm looks like no one is around."
    new "ん、誰もいないみたいだな。"

    # say L282 pla
    old "Maybe the nun will come later... I better go to wait at the confessional."
    new "まあ、修道女は後で来るかもしれないな… 親告室で待ってよう。"

    # say L292 gra
    old "Father Morgan? You're already here, right?"
    new "Father Morgan？もういらっしやるんですか？"

    # say L301 gra
    old "Thank God! So, how should we start tonight Father? Just tell me..."
    new "神様ありがとうございます！では、今夜はどう始めましょうか、お父さん？教えてください…"

    # say L308 gra
    old "No,  you know what? It is better to trust in divine providence and may the Lord be the one to guide the forgiveness of my sins tonight."
    new "いいえ、そうですね？神の摂理を信頼し、主が今晚私の罪の赦しを導いてくださることを願います。"

    # menu L327 
    old "Sex"
    new "セックス"

    # say L342 gra
    old "My great Father Morgan, I don't have words to express how grateful I'm. You've shown me how big and great you're."
    new "私の偉大なファーザー・モーガン、感謝の言葉もありません。あなたがどれだけ大きくて素晴らしい方なのか、教えてくださいました。"

    # say L354 pla
    old "(It's too late, I better go to sleep...)"
    new "もう遅いから、寝ようかな…"

    # say L367 pla
    old "Hi sister Grace, I'm fine and you?"
    new "嗨、グレース姉さん、俺は元気だよ、君は？"

    # say L368 gra
    old "I'm blessed thank God... Tell me, how can I help you?"
    new "私は神様に感謝しています… それでは、どのようにお手伝いできるか教えてください。"

    # say L393 gra
    old "[pla], are you ok?"
    new "[pla]、大丈夫？"

    # say L398 pla
    old "Oh don't worry, I'm just checking if everything is okay."
    new "心配しなくていい、ただすべてが大丈夫かどうか確認してるだけだよ。"

    # say L399 gra
    old "Oh right, thank you so much for all your help."
    new "ああ、そういえば、本当に助けてくれてありがとう。あなたの助けがなければダメだった。"

    # say L400 pla
    old "You are welcome, see you later."
    new "どういたしまして、またね。"

    # say L401 gra
    old "God be with you."
    new "神様が一緒にいてください。"


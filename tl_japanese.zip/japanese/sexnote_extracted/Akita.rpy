# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Akita.rpy
translate japanese strings:

    # menu L36 
    old "Talk to her"
    new "彼女に話しかける"

    # say L39 aki
    old "Hello, welcome to Jamliz Corporation! How can I help you?"
    new "こんにちは、Jamlizコーポレーションへようこそ！何かお手伝いできることがありますか？"

    # say L41 pla
    old "Hi, nice to meet you. My name is [pla]. I was sent by my [mo2rel], to give you these documents..."
    new "こんにちは、初めまして。俺の名前は[pla]だ。[mo2rel]から依頼されて、これらの書類を届けに来たんだ。"

    # say L44 aki
    old "Ohh right. She told me she was going to send a delivery boy with those documents. Perfect... Thank you very much!"
    new "ああそうでしたね。彼女が書類を届ける人を送るって言ってました。ぴったりですね… ありがとうございます！"

    # say L46 pla
    old "Delivery boy? Ok, well... I think that's it... right?"
    new "配達ボーイ？そうか、じゃあ…これでいいのかな？"

    # say L48 aki
    old "Yes, and by the way, my name is Akita nice to meet you..."
    new "はい、それにしても、私の名前はアキタです、よろしくお願いします…"

    # say L50 pla
    old "Oh, yes, I'm [pla]. The pleasure is mine..."
    new "ああ、そうか、俺は[pla]だ。君に会えて光栄だよ。"

    # say L52 aki
    old "Yes, yes you already told me... Hahaha."
    new "はい、はい、もう教えてもらったわ… ハハハ。"

    # say L54 pla
    old "Oh... right, of course, my bad... Well, it was nice to meet you, see you later..."
    new "ああ、そうか、すまんな… でも、会えて良かったよ、またね…"

    # say L56 aki
    old "See you later, [pla]."
    new "またね、[pla]。"

    # say L68 aki
    old "Oh, hi [pla], Mrs. [mo2] sent you with more documents or did you come to visit me?"
    new "あ、こんにちは[pla]、Mrs. [mo2]から書類を持ってきてくれたの？それとも遊びに来たの？"

    # say L70 pla
    old "Well, Mr. [mo2] sent me..."
    new "まあ、[mo2]さんが送り出したんだ..."

    # say L73 aki
    old "Hahaha, I'm just messing with you, perfect... Thank you very much."
    new "ははは、冗談よ、完璧ね... 本当にありがとう。"

    # say L75 pla
    old "Well... You're welcome, see you later..."
    new "まあ……別にいいけど、またね……"

    # say L77 aki
    old "Goodbye, handsome."
    new "バイバイ、ハンサム。"

    # say L88 pla
    old "I shouldn't bother her. She's working."
    new "彼女は仕事中だ、邪魔するな。"

    # menu L100 
    old "Use Agamoto Eye 1"
    new "アガモトアイ1を使おう"

    # menu L104 
    old "Use Agamoto Eye 2"
    new "アガモトアイ2を使う"

    # menu L108 
    old "Use Agamoto Eye 3"
    new "アガモトアイ3を使う"

    # say L115 pla
    old "No, no. Sorry. I was just walking around."
    new "いやいや、すみません。ただ歩いていただけです。"

    # menu L117 
    old "Back"
    new "戻る"


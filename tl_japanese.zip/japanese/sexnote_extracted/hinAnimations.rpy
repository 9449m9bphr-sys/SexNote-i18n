# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/hinAnimations.rpy
translate japanese strings:

    # say L6 joh
    old "Little by little, you start to increase the speed..."
    new "少しずつ速度を上げていきますね…"

    # say L13 joh
    old "You can feel his body start to tense, warm up, that means he's close..."
    new "彼の体が緊張して、温かくなってきたのが感じられる、それはもうすぐイキそうだってことだね..."

    # say L38 joh
    old "Ready for the shot?"
    new "射精の準備はできましたか？"

    # say L39 hin
    old "For what?"
    new "何のために？"

    # say L44 joh
    old "Wow! (Mmm)"
    new "Wow！ (Mmm) すごい！（ん）"

    # say L45 joh
    old "That's it! Did you like [pla]?"
    new "それがそれだ！[pla]は気に入ったか？"

    # say L47 joh
    old "Haha. And what about you, Hinn? How was it for you?"
    new "ははは、ヒンさんはどうでしたか？感じ方はどうでしたか？"

    # say L62 pla
    old "It was great."
    new "良かったな。"

    # say L104 joh
    old "Wow, I wasn't expecting it... That was a lot."
    new "Wow、それは予想外でしたね… かなりありましたね。"

    # say L110 joh
    old "A lot of cum as always, yummy"
    new "いつも通りの大量の精液、うまいですね。"

    # say L120 joh
    old "Go slowly increasing speed with me."
    new "ゆっくりと速度を上げていきましょう。"

    # say L124 joh
    old "How does it feel [pla]?"
    new "どのように感じていますか [pla]？"

    # say L125 pla
    old "It... feels, very good..."
    new "それは…とてもいい感じだ…"

    # say L129 joh
    old "How about if we make him cum Hinn?"
    new "それじゃ、ヒンにイかせてあげましょうか？"

    # say L130 hin
    old "(Oh My... Yes!)"
    new "おお…はい！"

    # say L154 pla
    old "I- I'm going to..."
    new "俺は…出しちゃうぞ。"

    # say L155 joh
    old "Yes [pla], give us everything."
    new "はい [pla]、全部出してちょうだい。"

    # say L163 joh
    old "Nice!"
    new "いいですね！"

    # say L164 joh
    old "And it's still hard... Beautiful youth, I think we can continue with the next practice, what do you say Hinn?"
    new "まだ硬いですね… 美しい若さだな、次のお稽古を続けられると思いますが、どうですかヒン？"

    # say L174 joh
    old "Well, you already saw me do it, in the last session, so it's your turn."
    new "前回のセッションでは私がやったのを見てくれましたが、今度はあなたの番ですよ。"

    # say L176 joh
    old "Don't worry I will help you."
    new "心配しないで、手伝いますから。"

    # say L178 joh
    old "Remember to brush your hair very well and be careful with your teeth, ok?"
    new "髪をよくブラッシングして、歯にも気をつけてくださいね、わかりましたか？"

    # say L182 joh
    old "Very well, go ahead you can do a little more..."
    new "では、続けてください。もう少し頑張ってみて..."

    # say L187 joh
    old "You feel it in your throat right? Well now take it out slowly."
    new "喉で感じているでしょう？ それじゃあ、ゆっくりと抜いてください。"

    # say L196 joh
    old "Great! Now keep doing it."
    new "素晴らしい！そのまま続けてください。"

    # say L202 joh
    old "All right honey, you're doing great."
    new "よし、よくやっているね。"

    # say L204 pla
    old "Uh... It feels very... good."
    new "うーん… すごく… よい感じがする。"

    # say L212 pla
    old "I going to..."
    new "俺、もうすぐ…"

    # say L222 joh
    old "And it's still hard... You know what to do Hinn... It's time to deepthroat!"
    new "まだ硬いよ… ヒン、君なら分かるよね… 深く咥える時間だよ！"

    # say L243 joh
    old "All right, how about we do it a little faster?"
    new "それじゃ、少し早めにやってみましょうか。"

    # say L251 joh
    old "You have to learn to read your partner's expressions."
    new "パートナーの表情を読み取らなくちゃね。"

    # say L252 joh
    old "Look how he starts to tense his legs, that means he is enjoying it, so, we have to do it a little faster."
    new "彼の足が緊張し始めるのが見えるよね、それは楽しんでいる証拠だよ、だから少し速くしないとね。"

    # say L276 joh
    old "All right, are you ready for the shot? Get it in your mouth, so, you don't make a mess here."
    new "じゃあ、準備はいい？ 口に含んで、そうすれば汚らなくて済むよ。"

    # say L277 hin
    old "What?"
    new "何ですか？"

    # say L282 joh
    old "Great Hinn!"
    new "Great Hinn！ すばらしいですね、ヒン！"

    # say L283 joh
    old "You did very well, right [pla]?"
    new "よくできましたね、[pla]さん。"

    # say L284 pla
    old "Uh?... Sorry what?"
    new "うっ？... ごめん、何？"

    # say L285 joh
    old "Hahaha, let's let [pla] to recover while I help you clean up in the bathroom."
    new "ははは、それじゃあ [pla] が回復する間、お風呂場で手伝ってあげましょうか。"

    # say L291 hin
    old "Of course."
    new "もちろん。"

    # say L296 joh
    old "All right, Hinn!"
    new "はい、ヒン！"

    # say L298 pla
    old "She did it awesome!"
    new "彼女、凄くやったね！"

    # say L299 joh
    old "Hahaha, you are improving Hinn."
    new "ははは、上手になってきましたね、ヒン。"

    # say L308 joh
    old "Wow, it looks like someone was practicing the lessons at home."
    new "Wow、家で練習してたみたいですね。"

    # say L312 joh
    old "All right, let's go a little faster."
    new "それじゃ、少し速くいきましょう。"

    # say L340 pla
    old "Girls, I think I'm going to..."
    new "女の子たち、俺はもうちょっとで…"

    # say L358 joh
    old "Well, it's time to fuck!"
    new "WELL、本気でいくときがきたね！"

    # say L366 joh
    old "Let me lubricate it well before I start."
    new "それじゃ、始める前にしっかりと潤滑しておきますね。"

    # say L413 joh
    old "Well I think that's enough, now you're going to penetrate Hinn..."
    new "では、十分に準備できましたね、これからヒンを貫きます…"

    # say L414 pla
    old "Wow... Ok."
    new "わお… 分かったな。"

    # say L415 joh
    old "Slowly and carefully..."
    new "ゆっくりと慎重に…"

    # say L421 joh
    old "Hinn you're going to enjoy the wonder of being a woman."
    new "ヒン、あなたが女性としての素晴らしさを楽しむ番です。"

    # say L425 joh
    old "Ready for that big cock Hinn?"
    new "ヒン、その大きなチ○ポの準備はできてるか？"

    # say L439 joh
    old "All right [pla], now let's go a little faster."
    new "それじゃあ [pla]、今度は少し速くしてみよう。"

    # say L443 joh
    old "How you feeling Hinn?"
    new "ヒン、調子はどう？"

    # say L444 hin
    old "Oh... It feels.... Aghh... Aghhh..."
    new "ああ……感じてる……アッ……アアッ……"

    # say L445 joh
    old "That's what I thought..."
    new "そうか、そうだったのか……"

    # say L449 joh
    old "Fuck her harder, make her cum with you!"
    new "もっと激しくして、一緒にイかせろ！"

    # say L472 joh
    old "Get it out, get it out, come in my mouth!"
    new "出しなさい、出しなさい、私の口の中で射精してください！"

    # say L478 joh
    old "Ohh yeah, yummy...."
    new "オッ、そうそう、美味しいね…"

    # say L502 joh
    old "He is going to cum..."
    new "彼はすぐに出すよ…"

    # say L503 hin
    old "Then, let's do it faster..."
    new "それじゃ、もっと速くしましょう..."

    # say L504 joh
    old "Good girl."
    new "良い子だね。"

    # say L536 joh
    old "All right is time to fuck!"
    new "では、さあ、やってみようじゃないか。"

    # say L604 joh
    old "Very well [pla], you already know what to do..."
    new "では [pla]、もう何をすればいいか知っていますね…"

    # say L615 joh
    old "Do you like this [pla]? Do you like my tits on your face?"
    new "この感じが好きですか [pla]？ 私の胸があなたの顔に当たるのが好きですか？"

    # say L616 pla
    old "(Hell yeah!)"
    new "（ああ！）"

    # say L620 joh
    old "Yeah! yeah! Let's fuck Hinn harder!"
    new "はい！はい！ヒンをもっと激しく犯しましょう！"

    # say L624 joh
    old "Are you enjoying it Hinn? Yes? Do you like [pla]'s cock?"
    new "ヒン、楽しんでる？ うん？ [pla]のちんこが好き？"

    # say L625 hin
    old "Oh, yess... Aghhh... Aghhh..."
    new "ああ、はい… あっ… あっ…"

    # say L648 joh
    old "Are you going to cum [pla]? Oh yeah? Cum inside her..."
    new "ジョハンソン: [pla]、イクつもりですか？ああ、そう？中でイってください..."

    # say L649 pla
    old "Ohh! Fuck yeahh..."
    new "オッ！　気持ちいいよ…"

    # say L655 joh
    old "Delicious!"
    new "おいしいですね！"

    # say L670 joh
    old "You are doing it great!"
    new "あなたは素晴らしいですね！"

    # say L671 joh
    old "Speed it up a little."
    new "もう少し速くしてみてください。"

    # say L675 joh
    old "Look at her [pla], she is enjoying your cock."
    new "見ろ、彼女の [pla]、君のチ○ポを楽しんでいるぞ。"

    # say L679 joh
    old "Are you cumming hin?"
    new "君はイクところだね？"

    # say L680 hin
    old "Oh please, don't stop, do it faster! I'm going to cum!"
    new "お願い、止めてくれないで、もっと速くして！ 私、イクよ！"

    # say L707 hin
    old "Wow... That was awesome..."
    new "それは凄かったわ..."

    # say L714 joh
    old "Ohh, I think it's the perfect opportunity, for the last lesson."
    new "オッ、これは最後のレッスンにぴったりのチャンスだね。"

    # say L715 joh
    old "Get a good facial..."
    new "良い顔面射精をさせてあげようね、ヒン。"

    # say L718 joh
    old "Now let's ger a good facial Hinn."
    new "では、いい顔面射をしてあげましょう、ヒン。"

    # say L732 joh
    old "Look at her eyes [pla], she wants all your cum."
    new "彼女の目を見て [pla]、君の精液が欲しそうですね。"

    # say L736 joh
    old "Does it feel good? Do you want to cum on that pretty face?"
    new "感じがいいですか？その美しい顔に射精したいですね？"

    # say L740 joh
    old "Get ready for the shot honey, he is ready."
    new "Honey、射精の準備をしてください、彼はもう準備できていますよ。"

    # say L763 joh
    old "Give it to her! Cum on Hinn face!"
    new "ヒンの顔に射精しなさい！"

    # say L771 joh
    old "Ohh yes... Delicious..."
    new "オッホッホ、美味しい…"

    # say L817 pla
    old "Wow Hinn, I'm going to..."
    new "Wow Hinn、俺、出しちゃうぞ…"

    # say L822 pla
    old "Wow, that was awesome..."
    new "Wow、それって最高だったな…"

    # say L823 hin
    old "I didn't say it's over. You just enjoy..."
    new "終わりって言ってないの。ただ楽しんでるだけよ。"

    # say L826 pla
    old "... WOW!"
    new "... わお！"

    # say L864 pla
    old "Hinn, again I'm going to..."
    new "ヒン、また俺が……"

    # say L865 pla
    old "Aghhh..."
    new "あぁっ…"

    # say L872 hin
    old "That was fun..."
    new "それが楽しかったな。"

    # say L873 pla
    old "That... Was... Surprising."
    new "それ…… 究めだったな。"

    # say L880 pla
    old "That was great."
    new "それが最高だったな。"

    # say L889 hin
    old "It has a very nice smell."
    new "いい香りがするね。"

    # say L890 hin
    old "Mmm, [pla] I really like your penis, it's soo nice."
    new "ん、[pla] あなたのペニス、本当に好き。すごく良い感じだよ。"

    # say L892 hin
    old "Just relax, I'll make you feel good."
    new "リラックスして、気持ちよくさせてあげるよ。"

    # say L896 hin
    old "Slurrp, Yes, I see you like that."
    new "するる、うん、それが好きだってわかるわ。"

    # say L897 hin
    old "I love the taste of you dick! I love how it feels in my mouth!"
    new "あなたのチンポの味が大好き！ 口の中で感じるのも大好き！"

    # say L898 hin
    old "I'll do it a little bit faster."
    new "ちょっと早めにやってみるね。"

    # say L903 bel
    old "(Hmm, they look like they're having fun. I better leave, I don't want them to know I saw them.)"
    new "（ふむ、楽しそうだな。気づかれたくないから、そっと出て行こう。）"

    # say L905 bel
    old "For now..."
    new "今は…"

    # say L913 hin
    old "Uhhh, I can feel how your body tense up!"
    new "うーん、あなたの体が緊張してるのを感じてる！"

    # say L914 pla
    old "H- Hinn. Mmm!"
    new "ヒン、 mM！"

    # say L915 hin
    old "Mmmm! Yes, Yes!"
    new "うん、うん！いいの、いいの！"

    # say L938 pla
    old "H-Hinn, I c- can't hold back anymore."
    new "ヒン、もう我慢できないよ。"

    # say L939 hin
    old "F- Finish, cum in my mouth!"
    new "F- 終わって、私の口の中で射精して！"

    # say L940 hin
    old "I want you to!"
    new "私がしたいの！"

    # say L941 pla
    old "Ughh, Y- YES!"
    new "うっ、や－やあ！"

    # say L946 hin
    old "Phew! That was great. Did you like it [pla]?"
    new "ふう！ それ良かったわ。気に入った？ [pla]"

    # say L947 pla
    old "Y- yeah, I did, thank you Hinn."
    new "Ｙ－ああ、そう、ありがとう、ヒン。"

    # say L948 hin
    old "Well, I'm glad you enjoyed it."
    new "まあ、楽しんでくれてよかったわ。"

    # say L949 hin
    old "Although now I'm covered with cum."
    new "でも今、精子で汚れちゃったわ。"

    # say L950 pla
    old "Sorry about that."
    new "すまん、汚したな。"

    # say L951 hin
    old "It's ok, I wanted to do that with you. Besides, we're in the bathroom."
    new "大丈夫、あなたとやりたかったの。それに、ここはお風呂場だしね。"

    # say L952 hin
    old "Help me clean up."
    new "手伝って掃除しよう。"

    # say L1070 hin
    old "Mmm! It's been a while..."
    new "んん！久しぶりだね..."

    # say L1071 hin
    old "Ah! Oh yes! I've missed this..."
    new "あ！そうそう！これ、懐かしい…"

    # say L1072 pla
    old "Ohh God!"
    new "あぁ！"

    # say L1073 hin
    old "Ahh! It's so big! and It feels so good!"
    new "アッ！大きくて気持ちいい！"

    # say L1077 hin
    old "Ah! Ah! I love to feel you inside [pla]!"
    new "アッ！アッ！あなたが中に入っているのが大好き [pla]！"

    # say L1078 hin
    old "Y- your cock is just the best!"
    new "あなたのチ○ポが最高！"

    # say L1080 hin
    old "I- I just love to have sex with you!"
    new "私はあなたとセックスするのが大好き！"

    # say L1084 hin
    old "AHH! AHH! YES! YES!"
    new "アッ！アッ！イク！イク！"

    # say L1085 hin
    old "I love the way you always make me feel!"
    new "あなたがいつも私にさせてくれるこの感覚が大好き！"

    # say L1086 hin
    old "I LOVE IT!"
    new "愛してる！"

    # say L1087 hin
    old "I want to keep doing it with you!"
    new "あなたとずっと続けたいの！"

    # say L1110 pla
    old "H- Hinn! I- I think I'm about to...!"
    new "Ｈ－ヒン！　俺、もうすぐ…！"

    # say L1111 hin
    old "Ohh, yes yes!"
    new "ああ、はいはい！"

    # say L1112 hin
    old "I want you to cum inside me!"
    new "中に出してほしいの！"

    # say L1119 hin
    old "Wow... That felt great."
    new "すごい… それ、気持ちよかった。"

    # say L1120 hin
    old "Did you enjoy it too [pla]?"
    new "あなたも楽しめた [pla]？"

    # say L1121 pla
    old "O- of course, it was really good."
    new "もちろん、すごく良かったぜ。"

    # say L1130 jad
    old "What the hell is this?!!!"
    new "何これ！？！！"

    # say L1131 jad
    old "Hinn! [pla]! What do you think you're doing?!"
    new "ヒン！[pla]！何やってるのよ？！"

    # say L1141 hin
    old "Mmm! I just love the way your cock tastes."
    new "うん！あなたのコックの味が大好きだよ。"

    # say L1142 hin
    old "It really is great. I can't get over it."
    new "本当に最高よ。これには夢中になっちゃう。"

    # say L1143 hin
    old "I love how it fills my mouth!"
    new "大好き、私の口いっぱいに埋まる感じ！"

    # say L1147 hin
    old "Are you enjoying it [pla]?"
    new "楽しんでるの、[pla]？"

    # say L1148 pla
    old "Ugh! Y- yes!"
    new "うっ！　ええ、そう！"

    # say L1149 hin
    old "M- me too! I love your cock!"
    new "私もよ！あなたのち○こ大好き！"

    # say L1150 hin
    old "I- it's so hot!"
    new "あたし、めちゃくちゃ熱い！"

    # say L1158 jad
    old "Honestly, I swear I don't understand what's going on in that girl's head sometimes."
    new "正直、彼女の頭の中って時々さっぱりわからないわ。"

    # say L1159 jad
    old "Where did she take off too? They're not in her room."
    new "どこへ行っちゃったのかな？部屋にもいないし。"

    # say L1160 jad
    old "And would you look at that? She left the bathroom light on!"
    new "そして見てごらん？浴室の電気をつけっぱなしだよ！"

    # say L1161 jad
    old "I swear to God..."
    new "神に誓って…"

    # say L1167 jad
    old "(Oh my God! What are they doing?! Again?!)"
    new "オマイゴード！何してるのよ？またかよ？！"

    # say L1168 jad
    old "(And in the bathroom of all places! These kids don't understand what shame is!)"
    new "(そしてトイレで！この子たちは恥ずかしがることを知らないのか！)"

    # say L1172 jad
    old "(And [pla]! My God! He's really big!)"
    new "（そして [pla]！神様！本当に大きいんだね！）"

    # say L1173 jad
    old "(I can't believe that young man is like that.... Amazing.)"
    new "（あの若者がそんな風だとは……すごいね。）"

    # say L1174 jad
    old "(I- is Hinn really putting all that in her mouth?)"
    new "（ヒンがそんなに全部口に入れてるの？）"

    # say L1175 jad
    old "(I- I can't believe it.)"
    new "（信じられない…）"

    # say L1182 hin
    old "Slrrrrp! Mmmm! Y- Yeah! I- I love your cock!"
    new "スルルル！　んん！　うん！　あ、ああ！　君のちんこ、大好き！"

    # say L1183 hin
    old "I- it barely fits in my mouth!"
    new "入るの、本当にギリギリだよ！"

    # say L1184 hin
    old "It's so amazing!"
    new "すごいな！"

    # say L1185 jad
    old "(S- she's actually putting all of it in her mouth!)"
    new "（ほんと、全部口に入れてるの！）"

    # say L1186 jad
    old "(I can't believe what I'm seeing!)"
    new "（信じられない…）"

    # say L1187 jad
    old "(H- he's not going to cum in her mouth, right?)"
    new "（ええと、彼は彼女の口でイかないよね？）"

    # say L1210 pla
    old "H- Hinn... I- I think I'm about to!"
    new "ヒン……俺、出しそうだ！"

    # say L1211 hin
    old "YES! CUM IN MY MOUTH!"
    new "はい！私の口に射精して！"

    # say L1212 jad
    old "(I can't believe Hinn is saying that kind of stuff!)"
    new "（ヒンがそんなことを言うなんて、信じられない…）"

    # say L1213 jad
    old "(I- is he going to do it?)"
    new "（はーん、本当にやるのかな？）"

    # say L1219 jad
    old "(My God, kids these days, honestly...)"
    new "（神様、今の子供たちって…）"

    # say L1220 jad
    old "(And they even say they're not a couple.)"
    new "（そして彼らはカップルじゃないなんて言うんだよね。）"

    # say L1221 jad
    old "(I guess this is alright. I won't say anything for now, but Hinn really needs to learn to do it in her bedroom.)"
    new "（まあ、これでいいか。今は黙っとくけど、ヒンは寝室でやるようにならないとね。）"

    # say L1233 hin
    old "Hngh!! Oh yes!"
    new "んっ！！ ああ、そう！"

    # say L1234 hin
    old "That's what I've been waiting for!"
    new "それが待っていたの！"

    # say L1235 hin
    old "I just love how you fill me up!"
    new "あなたが私をいっぱいにしてくれるのが大好き！"

    # say L1236 hin
    old "Oh! [pla]! Your cock is so big!"
    new "あら！[pla]！あなたのちんこ、こんなに大きいなんて！"

    # say L1240 hin
    old "Are you enjoying it?"
    new "楽しんでるの？"

    # say L1241 pla
    old "Mmm, y- yes!"
    new "うん、うん！"

    # say L1242 hin
    old "I- I'm loving it!"
    new "あたし、大好きだよ！"

    # say L1247 jad
    old "Uhh... What is that noise?"
    new "うーん… その音は？"

    # say L1250 jad
    old "(I can't believe they're doing it again!)"
    new "信じられない、またやっているのね…"

    # say L1252 jad
    old "(But well, at least they're doing it privately.)"
    new "（でもまあ、せめてプライベートでやってるんだから。）"

    # say L1253 jad
    old "Oh, my God! I- I can't help myself..."
    new "Oh、神！あたし、我慢できない…"

    # say L1260 hin
    old "D- do it faster [pla]!"
    new "D- 早くして [pla]！"

    # say L1263 jad
    old "(H- he's so big! I- I wonder how it must feel to be penetrated by him...)"
    new "あたし、彼がこんなに大きいの… こんなふうに貫かれたら、どんな感じなのか想像つかない…"

    # say L1265 hin
    old "AH! AH! AH! YES! YES!"
    new "AH！ AH！ AH！ うん！うん！"

    # say L1266 hin
    old "I've been missing this so much!"
    new "これずっと欲しかったよ！"

    # say L1267 jad
    old "(Mmmm, and she's taking all of it!)"
    new "（うん、全部受け止めてるわ）"

    # say L1268 hin
    old "I love how you fuck me!"
    new "あなたが私を犯すのが大好きだ！"

    # say L1301 jad
    old "(H- he won't cum inside of her... Will he?)"
    new "（ハ、彼は中に出さないよね… 本当に？）"

    # say L1302 hin
    old "I- I want you to cum inside!"
    new "あたし、中で出してほしいの！"

    # say L1303 hin
    old "Let me get it all!"
    new "全部ちょうだい！"

    # say L1304 pla
    old "Y- yes! I- I'm about to...!"
    new "Ｙ－はい！俺、出しそう…！"

    # say L1310 jad
    old "(God! I can't believe I just watched them have sex!)"
    new "（神！私が今彼らのセックスを見ちゃったなんて！）"

    # say L1311 jad
    old "(But this time they did it in Hinn's bedroom, I'm the one who shouldn't be here spying on them.)"
    new "（でも今回はヒンの寝室でやってたんだ、私がここで覗いてちゃいけないのに。）"

    # say L1316 hin
    old "That was so good [pla]."
    new "それが良かったわ [pla]。感じたの像是过了一个世纪一样。"

    # say L1317 hin
    old "It felt like an eternity since the last time we did it."
    new "前回からこんなに長く空けてたのって、本当に永遠のようだったわ。"

    # say L1318 pla
    old "Yeah..."
    new "そうだな…"

    # say L1319 hin
    old "By the way, it's getting kinda late, I guess my mom will be here any minute."
    new "それにしても、もう結構遅いから、ママもすぐ来るんじゃない？"

    # say L1320 pla
    old "You're right! I guess we better get dressed soon!"
    new "そうだな！そろそろ着替えた方がいいな。"

    # say L1321 jad
    old "(I should leave before they find out I'm here.)"
    new "私がここにいることを気づかれる前に帰ろう。"

    # say L1326 jad
    old "Oh God, what is happening to me?"
    new "神様、私に何が起こってるの？"


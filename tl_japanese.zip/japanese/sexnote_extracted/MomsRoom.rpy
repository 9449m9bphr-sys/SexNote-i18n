# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/MomsRoom.rpy
translate japanese strings:

    # say L22 pla
    old "(Let's try this again...)"
    new "またやってみようか…"

    # say L26 mo2
    old "Oh! Again, baby? You sure are horny these days."
    new "また、ベイビー？ 最近ずいぶんと欲求不満みたいね。"

    # say L28 mo2
    old "But I definitely do love it!"
    new "でも本当にそれが大好きです！"

    # say L29 pla
    old "(Nice. She still thinks I'm my [mo1rel]!)"
    new "（いいな。まだ俺が[mo1rel]だと思ってくれてるんだ。）"

    # say L39 pla
    old "(I'll just do it very carefully...)"
    new "（慎重にやるだけだな…）"

    # say L50 pla
    old "(What if...)"
    new "（もし……）"

    # say L51 pla
    old "(Oh no... She would kill me... But on the other hand... What if she doesn't notice...)"
    new "（ああ、まずい……彼女、絶対に怒る……でも、逆に……気づかなかったらどうしよう……）"

    # say L52 pla
    old "(Well... I think there is a chance and if it works I can keep doing it.)"
    new "まあ……チャンスはあると思うし、うまくいけば続けていけるだろう。"

    # say L53 pla
    old "(All I need to do is be really careful and I'll get out of this alive...)"
    new "気をつければ、このピンチをくぐり抜けることができるだろうな…"

    # say L55 pla
    old "(Oh man, I think I will regret this.)"
    new "ああ、これ絶対後悔するよ。"

    # say L57 mo2
    old "Is that you, baby?"
    new "あなた、赤ちゃん？"

    # say L58 pla
    old "(OH SHIT! I'M DEAD MEAT!)"
    new "OH SHIT！ 絶対やばい！"

    # say L59 mo2
    old "Mmm, is it my turn to be fucked?"
    new "ん、私が犯される番ですか？"

    # say L60 pla
    old "(What the hell? She thinks I'm [mo1]! Score!)"
    new "何だよ、彼女は俺が[mo1]だって思ってるのか！スコア！"

    # say L67 mo2
    old "Oh, I see. You don't want the kids to hear us. Ok, then fuck me quietly..."
    new "あら、そうですね。子供たちに聞こえないように静かにしてくれますね…"

    # say L68 pla
    old "(Yup. I'm definitely the luckiest guy ever!)"
    new "（そうだな。間違いなく俺は最も幸運な男だな！）"

    # say L69 mo2
    old "Mmm, fuck! It feels bigger than usual. Are you using a new strap-on?"
    new "ああん、大きい……新しいストラップオン使ってるの？"

    # say L71 mo2
    old "Fine. Be quiet, just please don't stop!"
    new "静かにして、でも止まないでくださいね。"

    # say L72 mo2
    old "(This is the best I've ever had!)"
    new "これが今までで一番良いわ！"

    # say L81 pla
    old "(I will just do it carefully...)"
    new "（慎重にやるよ…）"

    # say L90 pla
    old "(Damn!... She's amazing but... I should leave. I don't want to wake her up.)"
    new "くそっ… 她は素晴らしいけど… 行かなきゃ。起こしたくないから。"

    # say L100 pla
    old "(Carefully...)"
    new "（慎重に…）"

    # say L104 pla
    old "(Fuck! She is almost naked! So sexy.)"
    new "（くそ！ほとんど裸じゃないか！超セクシーだ。）"

    # say L105 pla
    old "(I should go, though. I don't want to wake her up.)"
    new "（でも、行かないと。起こしちゃだめだ。）"

    # say L116 pla
    old "(She's sleeping? I shouldn't make any noise.)"
    new "（寝てるのか？静かにしてなきゃな。）"

    # say L134 pla
    old "(Wait... What was that noise?)"
    new "（待て……何か音がしたぞ）"

    # say L137 pla
    old "It's coming from my [mo1rel]'s bedroom... I should go check it out."
    new "音が俺の[mo1rel]の寝室から聞こえてるな… 見にいこう。"


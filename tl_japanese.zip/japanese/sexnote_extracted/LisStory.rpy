# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/LisStory.rpy
translate japanese strings:

    # say L9 mo2
    old "No! You are my sister, but it doesn't mean I will give you money for every stupid scheme you can think of. I have my own responsibilities..."
    new "いいえ！あなたは私の妹だけど、それが私があなたの馬鹿げた計画のためにお金を出すことを意味するわけじゃないわ。私は自分の責任もあるの..."

    # say L10 lis
    old "But, I'm not asking you to give me money. Just lend me some or invest in my plan. This time what I have planned is sure to work..."
    new "でも、お金をくれって言ってるわけじゃないの。ただ貸してほしいだけなの、あるいは私の計画に投資してくれたらいいの。今回は絶対にうまくいくから…"

    # say L11 mo2
    old "Really, Lisa? Do you think that a simple yoga academy is a million-dollar venture? "
    new "ほんと、リサ？ヨガの教室が百万ドルの事業だと思わないけどね。"

    # say L12 lis
    old "Well, maybe not a million, but I know it will help me pay off the debts I owe you."
    new "まあ、百万ドルまではいかなくても、君に借金を返すための資金にはなると思うよ。"

    # say L13 mo2
    old "You know what? I already gave too much of you. Get that money from some other sucker."
    new "君が知ってるでしょう？もう十分すぎるくらいやってあげたわ。他の誰かからそのお金を手に入れてみて。"

    # say L17 lis
    old "But... but..."
    new "でも... でも..."

    # say L21 lis
    old "Oh... Hi there, [pla]. I'm sorry you had to hear all that... My sister is kind of a bitch sometimes..."
    new "あっ、こんにちは、[pla]。そんなことを聞かせてごめんなさい… 姉は時々厳しい人間だから…"

    # say L22 pla
    old "Oh yeah... I know what you mean..."
    new "ああ、そうか… 分かってるよ。"

    # say L23 lis
    old "Well, that won't stop me! I'm going to build my own yoga academy, with or without her help..."
    new "まあ、それじゃ止められないわ！ 姉の助けがなくても、自分でヨガアカデミーをつくるつもりよ…"

    # say L24 pla
    old "That seems like a good idea..."
    new "それいいアイデアだな…"

    # say L25 lis
    old "Thank you, [pla]! You are always a charm... Well, I have to go. If you need me, you can look for me at my house..."
    new "ありがとう、[pla]！いつもチャーミングだね… でも、私は行くわ。必要なら、家で探してみてね…"

    # say L26 pla
    old "Ok [lis]! See you later..."
    new "Ok [lis]！またね。"

    # say L42 lis
    old "Hey, [pla], how are you doing?"
    new "Hey、[pla]、どうしてる？"

    # say L43 pla
    old "Hi, I am fine."
    new "嘿、俺は元気だよ。"

    # say L44 pla
    old "You sure? I mean... I hope you're better."
    new "本当に？　つまり... もっと元気でいて欲しかったな。"

    # say L45 lis
    old "Oh I see, you mean about me and my sister..."
    new "なるほど、私と妹のことでしょ…"

    # say L46 pla
    old "Hmm... Yeah."
    new "うん…そうだな。"

    # say L47 lis
    old "You know my inner peace remains the same... I understand that she has her own business. I think that's the way the universe tells me I need to try by my own, because I know..."
    new "私の内面の平和は変わらないわ… 姉が自分のビジネスを持っているのは理解してる。宇宙が私に自分でやってみるべきだと伝えているんだと思う。だって、私は知ってるから…"

    # say L48 lis
    old "I feel great things are coming, and I think this is the moment I can show the world what I am made of, and I know this is a dream today but it will soon be real."
    new "大きなことが起こる予感がするの。この瞬間が世界に自分の価値を示すチャンスだと思うし、今日の夢がすぐには実になると思う。"

    # say L49 lis
    old "If fate puts a dream in your heart is because it's meant to be."
    new "運命が心に夢を植え付けるのは、それが叶うためのものだからよ。"

    # say L52 lis
    old "It's ok, you should to learn a little more, why not learn meditation with me."
    new "大丈夫、もう少し学んでみるのはどう？ 瞑想を一緒にやってみようよ。"

    # say L53 lis
    old "You need to learn to find the perfect balance in your body and soul so you can be one with yourself along with the universe, to better feel and understand your purpose and of life itself."
    new "あなたは自分の身体と魂のバランスを見つけることが必要よ、そうすれば自分自身と宇宙と調和できるわ、人生の目的や意味をより深く感じて理解できるようになるから。"

    # say L54 pla
    old "Hmm...  s- sure."
    new "Hmm... あ、いいよ。"

    # say L55 lis
    old "You know what, I will go today and check the options at the mall to see if I could run my own yoga academy from there, I will find the perfect place and fill out all the paperwork."
    new "知ってるわ、今日モールに行って自分のヨガアカデミーを運営できるかどうか見てくるから。最適な場所を見つけて、すべての書類も提出するつもりよ。"

    # say L57 lis
    old "Yeah, but there is so much work to do, you know... The place, the rent, the equipment, the ambience, everything must flow with the same energy."
    new "うん、でもやることが山ほどあるの… 場所も家賃も設備も雰囲気も、全部同じエネルギーで流れるようにしなきゃならないの。"

    # say L58 lis
    old "Once I get all the info, I will have an idea about the budget."
    new "情報を集めたら、予算の見通しが立つわ。"

    # say L59 pla
    old "Hope you get all the info you need, good luck!"
    new "必要な情報全部手に入れるように、頑張ってね！"

    # say L77 pla
    old "Hi, Lisa, how are you?"
    new "HEY、Lisa、元気？"

    # say L78 lis
    old "Oh no [pla], I think I need to reconsider my entire project."
    new "あら、[pla]、私のプロジェクト全部見直さなきゃいけないかも。"

    # say L80 lis
    old "Well, [pla], I went to the mall, had a hard time finding the manager, but think it was just fate trying to save me from that pain."
    new "あら、[pla]、モールに行って、マネージャーを見つけるのに苦労したけど、きっと運命が私をその苦しみから救おうとしてたのかもしれないね。"

    # say L81 lis
    old "I mean the rent for just a very small place was huge, something really out of my league, the requirements to rent the place are quite stressful."
    new "あの小さな場所の家賃がものすごく高くて、私の手の届かないものだったの。借りるための条件もかなり厳しくて、ストレスフルだった。"

    # say L82 lis
    old "I'm so frustrated, I- I need to think of a different project..."
    new "イライラするわ、別のプロジェクトを考えなきゃ…"

    # say L83 lis
    old "But the worst part of that day was when I discovered THERE WAS a yoga academy, as if that wasn't enough it was also really close to the place I was looking at..."
    new "でも、その日一番最悪なのは、ヨガアカデミーがあることを知ったこと。それだけじゃなく、私が見ていた場所からもすごく近かったの..."

    # say L84 pla
    old "Wait what? So you will have to compete."
    new "待て、何だ？競争相手がいるってことか？"

    # say L85 lis
    old "Well, that academy was bigger than what I was thinking, I think they have been there for a while because there was a lot of people, it was so amazing, the place was radiant and beautiful..."
    new "そのヨガアカデミーは私が想像していたよりも大きくて、長くそこにあったみたいで、人がたくさんいて、本当にすごい場所だった。場所も輝いていて美しいかったよ..."

    # say L87 lis
    old "Yeah, I immediately thought to myself I could be better than any of their instructors but clearly I can't compete with that company..."
    new "うん、すぐに自分の中で思ったの、あそこの講師たちよりも上手くできるかもしれないけど、あんな会社には太刀打ちできないな..."

    # say L88 pla
    old "I understand..."
    new "分かってるけど..."

    # say L89 lis
    old "Yeah, I think I need to be humble and to accept fate as it is..."
    new "うん、謙虚になるべきだし、運命を受け入れるしかないな。"

    # say L90 pla
    old "But... There has to be something you can do..."
    new "でも... 何かできることがあるはずだよ。"

    # say L91 lis
    old "What are my options? There's nothing I can do."
    new "私の選択肢は？何もできないわ。"

    # say L92 pla
    old "I mean, you can check different places, not just the mall."
    new "つまり、モール以外の場所も探してみればいいじゃん。"

    # say L93 lis
    old "Hmm I don't know, I just need time to focus on a different idea."
    new "うーん、わからないな、違うアイデアに集中する時間が必要なんだ。"

    # say L94 pla
    old "Sorry to hear you so frustrated, but you know what? You can count on me."
    new "君がそんなに落ち込んでるの、見てると辛いな。でもさ、安心しろ。俺がついてるから。"

    # say L95 lis
    old "Oh that's very sweet of you."
    new "それはとても甘い言葉だね。"

    # say L96 pla
    old "I know you can get a yoga academy like you want, we just need to look for alternatives."
    new "君が行きたいヨガのアカデミーに入れるって知ってるよ、ただ他の選択肢を探せばいいだけだ。"

    # say L97 lis
    old "I'll think about it, thanks for being so supporting, I appreciate your time."
    new "考えてみる、サポートしてくれてありがとう、時間割いてくれて助かったわ。"

    # say L98 pla
    old "It's ok, I just hope I can help."
    new "大丈夫、ただ君の力になりたいだけだ。"

    # say L116 pla
    old "Hi, how-"
    new "嘿、どうしたの Lis？"

    # say L117 lis
    old "Hey! I needed to talk to you, I have great news!"
    new "hey！話したいことがあったの、すごいニュースがあるの！"

    # say L118 pla
    old "Wow, I can see you're feeling better now..."
    new "すげえ、今じゃ全然元気そうだな..."

    # say L120 lis
    old "I really am, last time we talked I was very down, but I started my daily meditation practice. While breathing I discovered some light within the darkness..."
    new "本当にそうよ、前回会った時はすごく落ち込んでいたけど、毎日の瞑想を始めたの。呼吸しているうちに、暗闇の中に光を見つけることができたの..."

    # say L122 lis
    old "While I was doing this yoga position to relax, I thought I was doing something wrong, then I corrected the position, I still wasn't sure what exactly was wrong..."
    new "ヨガのポーズを取ってリラックスしようとしていたんだけど、何か間違ってる気がして、ポーズを修正したの。でも、まだ何が具体的に間違ってるのかわからなかったの..."

    # say L123 lis
    old "So I slightly moved my arms and legs to get the perfect position, I know it sounds a bit silly but, when I corrected the position, it felt like my body was in a different place..."
    new "だから少し腕と足を動かして、完璧なポジションになるように調整したの。ちょっと恥ずかしい話だけど、ポジションを修正したら、体が違う場所にあるような感じがしたの。"

    # say L125 lis
    old "I mean, sometimes meditation is not about knowing the Asanas but how you connect in the moment and the environment..."
    new "つまり、時には瞑想はアーサナを知っているかどうかではなく、その瞬間と環境とのつながり方が大事なんだよね…"

    # say L126 lis
    old "It's not about how you follow the rules but how you connect your body and soul through exercise, do you understand?"
    new "ルールに従うことじゃなくて、エクササイズを通じて体と魂をつなげることが大事なんだよ、わかる？"

    # say L127 pla
    old "Hmm... I think so."
    new "うーん… そうかも。"

    # say L128 lis
    old "That was my reflection, I'm not a regular Yoga instructor, I mean this academy at the mall can have 10 teachers but I am no a regular teacher, yoga and meditation is part of my life..."
    new "それが私の考えで、私はただのヨガインストラクターじゃないの。モールのあのアカデミーには10人の先生がいても、私はただの先生じゃない。ヨガと瞑想は私の人生の一部だから…"

    # say L130 lis
    old "For me, yoga is not just about the equipment or space, I don't need that so I can perform a good pranayama, those are things for a comfortable service experience."
    new "私にとってヨガは装備や場所じゃなくて、良いプラナヤマを行うのにそれらは必要ないの。それは快適なサービス体験のためのものよね。"

    # say L131 lis
    old "My personal experience can't be beat because it's actually richer than any other yoga experience, I'm not selling a product! I'm sharing my own experience..."
    new "私の個人的な経験は他のどんなヨガの経験よりも豊かだから、商品を売ってるわけじゃないの、自分の経験を共有してるだけよ。"

    # say L132 pla
    old "Very interesting."
    new "なるほどか。"

    # say L133 lis
    old "And you were right..."
    new "そうだったわね、あなたが正しいって…"

    # say L135 lis
    old "Yes! About the mall, my business can be run in a totally different place... In fact... I think... Since I don't need any special place, I can just have it at my own HOUSE."
    new "はい！モールの件ね、私のビジネスは全く別の場所で運営できるわ… 実際… 私が特別な場所を必要としないなら、自分の家でやっても良いと思うの。"

    # say L136 pla
    old "That would be very convenient."
    new "それは便利そうだな。"

    # say L137 lis
    old "Here, my customers can experience a very close yoga training, focus on the intimate learning, no distractions, no rules, only the yoga experience I provide."
    new "ここなら、お客様にとても密接なヨガのトレーニングを体験していただけるし、密な学びに集中できる。邪魔もなければルールもない、私が提供するヨガの経験だけよ。"

    # say L139 lis
    old "Well, I will need to check how to obtain the necessary business permits and licenses."
    new "WELL、必要な営業許可とライセンスを取得する方法を確認する必要があるわ。"

    # say L140 pla
    old "I am sure that won't be any trouble."
    new "大丈夫だよ、問題ないさ。"

    # say L141 lis
    old "Thank you for listening to me and giving me the support, I needed I appreciate it."
    new "ありがとう、聞いてくれて必要なサポートもしてくれて。助かったわ。"

    # say L142 pla
    old "I actually did nothi-"
    new "実際には何もしてないけど、ありがとう。"

    # say L143 lis
    old "Oh, by the way, let me show you some ideas I have for the yoga room."
    new "そういえば、ヨガルームのアイデアをいくつか見せてあげるわ。"

    # say L145 lis
    old "Please come, I'm sure you are going to like it too, I wasn't aware my house was so perfect for this."
    new "来てみて、きっと気に入るはずよ、この家のスペースがこんなに適しているとは気づかなかったわ。"

    # say L146 pla
    old "Is it?"
    new "そうなのか？"

    # say L147 lis
    old "Yes, the second floor is big and a good area I can take advantage of."
    new "うん、二階は広くて、使いやすい場所よね。"

    # say L155 pla
    old "Hmm, this room is pretty big."
    new "この部屋、結構広いな。"

    # say L157 lis
    old "You see it? It is so private, very intimate, and full of silence, this place is perfect... I did not realize it was that big until I took out all the stuff... What do you think?"
    new "見ただろ？ここはとてもプライベートで、すごく親密で、静けさに満ちている。この場所は完璧だよ…全部の物を片付けた後で、こんなに広いことに気づいたの…どう思う？"

    # say L158 pla
    old "It is very nice and peaceful."
    new "ここはとても落ち着いていていいね。"

    # say L159 lis
    old "Actually, it's going to be better, you know music, fragrances, all that it takes to meditate and find your inner peace."
    new "実はね、もっと良くなるよ。音楽や香り、瞑想して内なる平和を見つけるためのものが全部揃うから。"

    # say L160 pla
    old "Wow, you have your business almost running. If you need something, you can count on me anytime."
    new "Wow、君のビジネスがもうこんなに軌道に乗ってるとはね。何か手伝うことがあったら、いつでも言ってくれ。"

    # say L161 lis
    old "You're really sweet... I think I am ok-"
    new "あなたってほんと優しいね… 大丈夫だと思うけど-"

    # say L162 lis
    old "Wait, you know what?..."
    new "待って、思ったのだけど…"

    # say L163 lis
    old "I was wondering yesterday, how a customer would feel, you know the place... The energy... I just want to have an idea how they could feel."
    new "昨日考えていたんだけど、お客様がどんな気分になるのかな、その場所の雰囲気やエネルギーを体感してみたいの。彼らがどう思っているか想像してみたいの。"

    # say L164 lis
    old "Would you like to help me? You just need to be like my ‘instructor' I will tell you step by step what to do... What do you think?"
    new "手伝ってくれる？ただ私の『インストラクター』になってくれればいいの。一歩ずつ教えていくから…どう思う？"

    # say L165 pla
    old "Hmm, I can help you sure..."
    new "うん、手伝うよ"

    # say L166 lis
    old "Thank you, I will walk you through every single step so you can learn too."
    new "ありがとう、一つずつ丁寧に教えていくから、あなたも学べるわ。"

    # say L167 lis
    old "Let's do a couple of regular exercises."
    new "まずはいくつかの基本的なエクササイズをやってみましょう。"

    # say L172 lis
    old "First we will try something casual, this position is called ‘Utkatasana', it's quite focused on breathing and your legs so since you will be the trainer..."
    new "まずはカジュアルなポーズから始めてみましょう、このポーズは『ウトカサナ』と呼ばれていて、呼吸と足にフォーカスするので、あなたがトレーナーとして…"

    # say L173 lis
    old "I will do the position so please follow me, don't do the position with me but control the position from the back, helping me to keep my balance, you got it?"
    new "私がポーズを取るので、後ろから支えてバランスを保つようにしてくださいね、わかりました？"

    # say L176 lis
    old "Ok... Here we go, please put your hands on my waist."
    new "はい… それじゃ、私の腰に手を置いてください。"

    # say L183 lis
    old "Like I said follow my movement, I will go down..."
    new "言った通りに私の動きについてきて、私が下りていくから…"

    # say L189 pla
    old "Sure..."
    new "分かったよ、リス…"

    # say L192 lis
    old "You're keeping cool good, let's go up... Perfect."
    new "いい感じに冷静だね、上へ行こう... 完璧。"

    # say L199 lis
    old "Well, I can feel it positive, I can breathe perfectly, the light is quite good, do you feel comfortable?"
    new "WELL、ポジティブな気分がして、深呼吸もできて、光も良くて、快適に感じる？"

    # say L200 pla
    old "Yes, I feel nice."
    new "うん、気持ちいい。"

    # say L201 lis
    old "Well, that was very productive, I feel relaxed, don't forget to keep breathing."
    new "WELL、それはとても生産的だったわ、リラックスできたし、呼吸を忘れずにね。"

    # say L202 pla
    old "Sure, I'm focused."
    new "わかった、集中してるよ。"

    # say L203 lis
    old "That's perfect, let's try a different pose..."
    new "それが完璧、違うポーズを試してみよう..."

    # say L210 lis
    old "Next one will be totally different it's on the floor, its name is ‘Upward Facing Dog', for this position your help is very important..."
    new "次のポーズは全く違うよ、床で行う「アップワード・フェイスング・ドッグ」って名前だよ。このポジションではあなたの協力がとても重要なの..."

    # say L211 lis
    old "Because you will help me with the effort applied to my back, so I'll lie down looking up, if you want to be more comfortable, please get on your needs."
    new "あなたが私の背中への力を助けてくれるから、上を向いて横になります。もっと快適なら、自分のペースで動いても大丈夫ですよ。"

    # say L218 lis
    old "I really like this position, I can feel a lot of energies running through me."
    new "この体位、すごく好き。体内をたくさんのエネルギーが流れているのを感じられる。"

    # say L219 lis
    old "Ahh it's so relieving, please push a bit towards my shoulders."
    new "あぁ、ほんとにかつらげる、肩の方にちょっと力を加えて。"

    # say L232 lis
    old "Oh yeah, like that, this is very relaxing for me."
    new "ああ、そう、これすごくリラックスできるわ。"

    # say L233 pla
    old "(She looks very enticing... I need to focus.)"
    new "（彼女はとても魅力的だ…でも集中しなきゃ）"

    # say L241 pla
    old "(Oh shit... I'm getting hard... Oh, please not now...)"
    new "（しまった……硬くなってきちゃってる……お願い、今だけは我慢して……）"

    # say L248 lis
    old "You are doing amazing."
    new "あなた、凄いね。"

    # say L250 lis
    old "I think this place is incredible to do this... I can't wait to bring the candles, the music... It'll be so perfect!"
    new "この場所でこんなことをするのは最高だと思うわ。ろうそくや音楽も用意して、完璧な夜にしたいの。"

    # say L251 lis
    old "Alright, we need to continue... Listen, the next position is amazing, it's one of the most interesting and very easy to learn."
    new "それじゃ、続けよう... 聞いて、次の体位は最高よ、めっちゃ興味深くて簡単だから覚えるの楽チン。"

    # say L257 lis
    old "This asana sequence is called ‘Extended Puppy Pose', it's really relaxing, so please pay attention..."
    new "このアサナの流れは『エクステンデッド・パピー・ポーズ』って言うの。ほんとリラックスできるから、よく聞いてね。"

    # say L259 pla
    old "W- what do you need me to do?"
    new "ええっと、何をすればいいんだ？"

    # say L260 pla
    old "(I need to control myself or she will notice my hardon.)"
    new "自制心を保てないと、硬くなったのが気づかれてしまうな。"

    # say L261 lis
    old "Well... For this position the hips and legs are very important, so I will need you to push them, so I can stretch my back to the fullest..."
    new "WELL... この体位では腰と足がとても重要なので、あなたに押してもらう必要があるの。そうすれば私の背中を最大限に伸ばせるから…"

    # say L262 lis
    old "Please hold my waist behind me and help me keep my balance."
    new "後ろから私の腰を支えてくれて、バランスを保つ手伝いをしてください。"

    # say L264 pla
    old "(I hope she doesn't notice it.."
    new "彼女に気づかれないようにしないとな…"

    # say L271 lis
    old "Please try to rest your waist with mine, control your breathing too."
    new "私の腰にあなたの腰を当てて、呼吸も整えてください。"

    # say L281 lis
    old "I need to feel you firmly so I can rest my back and relax my body."
    new "あなたをしっかりと感じたいの、そうすれば背中を預けてリラックスできるから。"

    # say L282 pla
    old "(Oh It feels so delicious.)"
    new "ああ、これめちゃくちゃ気持ちいい。"

    # say L284 lis
    old "Can push me harder, that way both of us will be able to the do exercise more intensely."
    new "もっと強く押して、そうすれば二人とももっと激しくできるわ。"

    # say L292 lis
    old "Yes, just like that."
    new "うん、その通り。"

    # say L294 lis
    old "That was perfect... I think we are done!"
    new "それが完璧だったわ… これで終わりにしましょう。"

    # say L297 lis
    old "I like your enthusiasm but I think you can stop now."
    new "あなたの熱意は伝わるけど、もうやめていいわよ。"

    # say L303 pla
    old "OH!? Yes, I am sorry, I was... I... Was quite focused on the position."
    new "OH！？ ごめん、俺が…俺…位置にかなり集中してたんだ。"

    # say L314 lis
    old "Oh that's fantastic, I'm sorry to interrupt you."
    new "あら、それは素晴らしいわ、でも邪魔しちゃったのね。"

    # say L315 pla
    old "(Phew, thank god, she didn't notice.)"
    new "ふう、良かった、気づかれてなかったな。"

    # say L316 pla
    old "Oh no, it's ok no worries."
    new "大丈夫、気にすんな。"

    # say L317 lis
    old "Amazing, you did a wonderful job, I appreciate your commitment."
    new "すごいわ、素晴らしい仕事をしてくれてありがとう。あなたの献身に感謝しているわ。"

    # say L318 pla
    old "No problem..."
    new "問題ないよ、リスちゃん。"

    # say L319 lis
    old "I'm very surprised how our chakras get together so well... I am sure that is going to be the feeling I have with my customers."
    new "私たちのチャクラがこんなにもうまく調和するなんて驚いたわ… 客達との感じ方もきっと同じだと思うの。"

    # say L320 lis
    old "I'll let you rest, thank you so much for your help, I will keep meditating a little longer."
    new "お休み、ありがとう。もう少し瞑想を続けるわ。"

    # say L321 lis
    old "If you want to learn more, I could give you a few more lessons."
    new "もっと学びたいなら、いくつかのレッスンを追加で教えられるわ。"

    # say L322 pla
    old "... Alright... I'm gonna leave you, so you can practice more."
    new "... 分かった... 俺は行くから、もっと練習してな。"

    # say L323 lis
    old "Thank you honey, see you later."
    new "ありがとう亲爱的，待会儿见。"

    # say L324 pla
    old "Have a good one."
    new "良い一日を。"

    # say L328 pla
    old "(That was close... I think she didn't realize...)"
    new "危なかったな…気づかれてないと思うけど。"

    # say L348 pla
    old "Oh, hi Lisa, what a surprise! Did you come to talk with [mo2]?"
    new "オッ、こんにちはLisa、びっくりした！[mo2]と話しに来たのか？"

    # say L349 lis
    old "Oh no, don't worry, I am fine, I just came because I... Wanted to talk to you."
    new "大丈夫、心配しないで、ただ…あなたと話したくて来たの。"

    # say L350 pla
    old "With me? Ok..."
    new "俺と？いいよ…"

    # say L352 lis
    old "I have already had some customers; they are really happy with how we do things."
    new "既にいくつかのお客さんがいて、私たちのやり方にとても満足してるよ。"

    # say L353 pla
    old "Oh... That's amazing."
    new "お、それはすごいな。"

    # say L354 lis
    old "Yes, but this is just the beginning, better things are coming."
    new "はい、でもこれがただの始まりよ、もっと良いことがあるわ。"

    # say L355 pla
    old "I am glad that you are very positive."
    new "君がとても前向きで嬉しいよ。"

    # say L356 lis
    old "I am just thankful for everything the universe is preparing for me."
    new "宇宙が私に用意してくれていることすべてに感謝しているだけよ。"

    # say L357 lis
    old "Actually, I need to ask you something, I don't want to do this but you're the one who would understand what I need."
    new "実はね、あなたに頼み事があるの。やる気はないんだけど、あなたなら理解してくれると思って。"

    # say L358 pla
    old "Hmm... What is this about?"
    new "何关于なんだ？"

    # say L359 lis
    old "Like I said the business is taking shape, I already have some customers, however I am very busy lately with paperwork to get the final license and all of that... You know..."
    new "先に言った通り、ビジネスが形になってきて、すでにいくつかのお客様もいるんだけど、最近は最終ライセンス取得のための書類作成で忙しくてさ… 分かるよね…"

    # say L360 lis
    old "The thing is I have a new customer in the afternoon coming, she is very very enthusiastic and is quite interested on the yoga program."
    new "問題は、午後に新しい顧客が来るんだよね。彼女はものすごく熱心で、ヨガプログラムにとても興味があるの。"

    # say L362 lis
    old "Yeah, she paid for the entire course and I'm already planning her sessions."
    new "うん、彼女は全コース分を支払ってくれて、もう彼女のためのレッスンを計画してるの。"

    # say L363 lis
    old "However the time frame she said she is available is exactly the same time I have a very important appointment..."
    new "しかし、彼女が空いていると言っている時間帯が、私がとても重要な予定がある時間と完全に重なってるの..."

    # say L364 lis
    old "It's an interview to verify the information to approve the business. I already have all the documentation needed to legally open it..."
    new "それは事業を認可するために情報確認のための面接よ。すでに合法的に開業するために必要なすべての書類は揃ってるの..."

    # say L365 lis
    old "But this is a temporary one, this interview  gives me the approval so... I do need your help now... If you can cover me, so I can attend it."
    new "でもこれは一時的なもので、この面接で承認が得られるから… 今、あなたの助けが必要なの… もしカバーしてもらえるなら、私が参加できるから。"

    # say L366 pla
    old "Well... I think I can... But-"
    new "まあ… できると思うけど… でも-"

    # say L367 lis
    old "Amazing! that is fantastic. The entire universe is making it possible once again, did you know you are being an instrument of the universe?"
    new "すごい！それは素晴らしいわ。またしても宇宙が全てを可能にしてくれてるのね、あなたが宇宙の道具になってくれてるって知ってた？"

    # say L368 pla
    old "M- me... ?"
    new "俺、…？"

    # say L369 lis
    old "Of course! I am very grateful... You cannot not imagine how important this is for me. You only need to help me with this session..."
    new "もちろん！とても感謝してるの... これがあたしにとってどれだけ重要か、想像もつかないでしょう。このセッションを手伝ってくれるだけでいいの..."

    # say L370 lis
    old "Since you have already done the basic yoga training with me you are the only one that can cover me, it's going to be the same routine."
    new "あなたがすでに基本的なヨガのトレーニングを私と一緒にやってくれているので、あなたしか代わりがいないの。同じルーティンだから大丈夫よ。"

    # say L371 lis
    old "I know you are very intuitive and can do the session like we did before, I already checked with the customer and she is ok with that."
    new "あなたがとても直感的で、前と同じようにセッションをこなせるはずよ。お客様とも確認したわ、大丈夫だって。"

    # say L373 lis
    old "Please reach me at home later, I am very sorry we won't have enough time to plan it but I am sure you will do great."
    new "後で家に連絡してね、時間が足りないのは申し訳ないけど、きっと上手くいくわ。"

    # say L374 pla
    old "Hmm ok, I'll be there on time."
    new "分かった、時間通りに行くよ。"

    # say L375 lis
    old "Thank you so much... See you then."
    new "ありがとう……またね。"

    # say L376 pla
    old "No problem, bye."
    new "問題ないよ、じゃね。"

    # say L393 pla
    old "(Oh my god, is Anastasia, What is she doing here.)"
    new "お gode、アナスタシアか、ここにいるのか。"

    # say L395 lis
    old "Oh, hey [pla]! thank so much for coming."
    new "あ、こんにちは [pla]！ 来てくれて本当にありがとう。"

    # say L398 lis
    old "Oh, I am sorry, let me introduce you guys properly... [pla], this is Anastasia... Anastasia, this is  [pla]."
    new "すみません、properly 紹介させて… [pla]、これはアナスタシアです… アナスタシア、これは [pla] です。"

    # say L399 ana
    old "Thank you Lisa, It's nice to see you again [pla]!"
    new "ありがとう、リサ。また会えて嬉しいわ、[pla]！"

    # say L400 pla
    old "G- good to see you too."
    new "再会できて嬉しいぜ。"

    # say L402 lis
    old "Oh... So do you guys already know each other?"
    new "Oh... そうなのか、二人はもう知り合いでした？"

    # say L403 ana
    old "Hehehe, Yes, we know each other pretty well, right [pla]?"
    new "へへへ、そうね、お互いよく知ってるわよね、[pla]？"

    # say L405 lis
    old "Oh really? Please tell me... Once you guys arrived I just felt like fate was planning this meeting."
    new "ほんと？ 教えてよ… あなたたちが来たとき、運命がこの出会いを計画してるんじゃないかって思ったの。"

    # say L406 pla
    old "Well, she has bought some products... From [sis]'s website."
    new "まあ、彼女はいくつかの商品を購入したんだ... [sis]のサイトからね。"

    # say L407 ana
    old "Yeah, I met him as the delivery guy, I was surprised by his manners and because he is very intelligent with pretty huge talent..."
    new "うん、彼と配達の人として出会ったの、彼のマナーに驚いたし、頭が良くて才能もあるの..."

    # say L409 lis
    old "I am very glad to hear that you understand each other, I will try to be back as soon as possible, in the meantime [pla] will help you with the first session Anastasia."
    new "お互いを理解し合っているって聞いて、とても嬉しいです。早めに戻るよう努力するから、その間は [pla] が最初のセッションを手伝ってくれるわ、アナスタシア。"

    # say L410 ana
    old "Oh, that's very interesting, don't you think [pla]?"
    new "そうね、それはとても興味深いわ、[pla]も思うでしょ？"

    # say L412 pla
    old "Y- yes... Very interesting..."
    new "ええ…とても興味深いね…"

    # say L414 lis
    old "I‘ve got the feeling this session will be really nice. Well guys, please enjoy the session, I will be back as soon as possible."
    new "このセッション、きっと素敵になる予感がするわ。みんな、楽しんでね。すぐに戻るから。"

    # say L415 ana
    old "Bye bye Lisa."
    new "バイバイ、Lisa。"

    # say L424 ana
    old "Finally we are alone. I am  very ready for the class."
    new "ついに二人きりね。クラスの準備はばっちりよ。"

    # say L425 pla
    old "Well... Yes, I- I thank you for coming today, we did prepare a very great Yoga session for you."
    new "まあ……そうだね、今日来てくださってありがとう。かなり良いヨガのセッションを用意してたんだ。"

    # say L426 ana
    old "Oh, I like that, I wasn't expecting to have a very handsome trainer, it's going to be really fun."
    new "あら、それは嬉しいわ。とてもハンサムなインストラクターだなんて、全然期待していなかったから。これなら本当に楽しくなるね。"

    # say L428 pla
    old "Why don't we go to the yoga room where it's more comfortable for the session."
    new "それじゃ、ヨガルームに行こうか。もっと快適な環境でセッションができるよ。"

    # say L437 pla
    old "This is going to be our yoga room, we hope you enjoy not only the lesson but also the finer details for this experience."
    new "これは我们的回答出现了一些小错误，让我直接给出正确的日本语句子："

    # say L438 ana
    old "It's beautiful, smells very nice."
    new "ここは beautiful ですね、とてもいい香りがします。"

    # say L439 pla
    old "Every detail has been thought out to make your experience better."
    new "細部まで君の体験をより良くするためを考え抜かれたんだ。"

    # say L440 ana
    old "You guys are doing it very well."
    new "本当に上手いことやってるね。"

    # say L441 pla
    old "Now, let's start with the lesson, so you can get to relax a bit more."
    new "じゃあ、まずはレッスンを始めて、君がもっとリラックスできるようにしよう。"

    # say L447 pla
    old "Alright, for the first position I will be behind you to help you keep your body balanced, and that way we can do the exercise properly."
    new "まずはバランスを取るため、俺が後ろから支えるからな。そうすればちゃんとエクササイズできるよ。"

    # say L448 ana
    old "That's perfect."
    new "それが完璧だね。"

    # say L449 pla
    old "We will start straight up and then we will go down keeping the straight position and correct breathing."
    new "まずはまっすぐ立って、そのまま体を伸ばした状態で下に下ろして、正しい呼吸を意識しよう。"

    # say L460 pla
    old "Try to keep your thoughts focus on the exercise."
    new "練習に集中してみよう。"

    # say L461 pla
    old "(Her butt is really big, I need to think of something different. She's so hot...)"
    new "彼女の尻って本当に大きいな、違うこと考えないと。でも、めちゃくちゃsexyだな..."

    # say L462 ana
    old "Am I doing it right?"
    new "ちゃんとやってる？"

    # say L463 pla
    old "Yes... Delicious."
    new "うん… 美味い。"

    # say L466 pla
    old "I- mean... Correct, yes, you are doing it correctly."
    new "ああ、そうか… 正确にやってるよ、アナ。"

    # say L467 ana
    old "Oh, thank you."
    new "お、ありがとう。"

    # say L468 pla
    old "Do you feel relaxed?"
    new "リラックスできてる？"

    # say L469 ana
    old "Yes, I like it."
    new "うん、気に入ったわ。"

    # say L470 pla
    old "It was good, we are going to stop now and continue with the following, did you like it?"
    new "良かったね、ここで一旦止めて次に進むけど、君は気に入ったか？"

    # say L471 ana
    old "It was nice."
    new "それは良かったわ。"

    # say L477 pla
    old "I hope you feel calmer now... So, our next position will help with the balance of our energies..."
    new "落ち着いてくれた感じがするといいな… 次の体位はエネルギーのバランスを整えるのに役立つよ…"

    # say L478 pla
    old "I'll need you to lie down on your stomach, first we will stretch your legs and back, raising your head up, later you will let it down to breathe again."
    new "まずはお腹を下にして寝て、足と背中を伸ばして頭を上げて、後でまた下げて深呼吸するよ。"

    # say L480 pla
    old "This position is quite demanding, I will be there to make sure you can focus more and make the most out of it."
    new "この体位はかなり要求されるけど、君が集中して最大限の効果を得られるようにサポートするから安心して。"

    # say L481 ana
    old "Sounds good!"
    new "いいわね！"

    # say L487 pla
    old "First relax and breathe while lying down in that position."
    new "まずはリラックスして、その体勢で横になって深呼吸してね。"

    # say L488 ana
    old "Hmm it feels good."
    new "うん、気持ちいいわ。"

    # say L489 pla
    old "Now you are going to stretch your arms and I'm going to press your shoulders back so you can tense your muscles, and tilt your head back."
    new "今度は腕を伸ばして、肩を押さえてあげるから、筋肉を緊張させて首を後ろに傾けてみて。"

    # say L503 pla
    old "(Wow... I can see her boobs!)"
    new "(わお……おっぱいが見えるな)"

    # say L504 pla
    old "(Oh no... I am getting a hardon again. Shit... I should act normal so she doesn't notice.)"
    new "（しまった…また硬くなってきた。どうにか普通を装わないと、気づかれないように）"

    # say L512 ana
    old "So... Like this?"
    new "そう……こんな感じ？"

    # say L515 ana
    old "Are you getting distracted?"
    new "あなた、何かに気を取られてる？"

    # say L517 pla
    old "Oh no... I am ok... Let's breath a bit more."
    new "大丈夫だ… でもちょっと深呼吸しよう。"

    # say L523 ana
    old "OH WOW!"
    new "おわっ！"

    # say L524 pla
    old "(Dammit she noticed it.)"
    new "くそ、気づかれたか。"

    # say L525 ana
    old "I thought you were a bit distracted but now I know you brought a bit of company, I think one of your muscles needs to relax a bit too..."
    new "あなたが少し気を散らしていたのは気づいていたけど、今ならちょっとした仲間を連れてきたんだね。筋肉の一つや二つもリラックスさせてあげないとね。"

    # say L526 pla
    old "I- am very sorry, please do not take me wrong way, I am... I am just very nervous."
    new "すみません、誤解しないでください、ただ… すごく緊張してるんです。"

    # say L529 ana
    old "It's totally ok, I feel very flattered and I like it... The effort makes you feel a bit stressed, I think since you are helping, I should help you too, so you can feel better."
    new "全然大丈夫、とても嬉しいし好きよ… 努力しているのが少しストレスになっているみたいだから、あなたが手伝ってくれているんだし、私も手伝うべきだと思うの、そうすればもっとリラックスできるわ。"

    # say L530 pla
    old "W- What? Oh no, of course not.. I think this is moment to finish the session."
    new "何？　いや、そんなつもりじゃないよ… でも、このままじゃセッションを終了した方がいいかもしれないな。"

    # say L531 ana
    old "I know you want it... I remember last time you enjoyed it with my hands, probably this time we can try with... I don't know, maybe my mouth?"
    new "知ってるわ、あなたが欲しがってるの... 前に手でやってあげたとき、楽しんでくれたよね、今回は... ねぇ、口で試してみるのもいいかもね？"

    # say L532 pla
    old "... (What the fuck!)"
    new "何てことだよ！"

    # say L533 ana
    old "Why don't you relax a bit, let me check it out on my own, I know you will like it... Let's open this sweet gift."
    new "ちょっとリラックスして、私が勝手に見てみるから、きっと気に入ってくれるわよ… この甘い贈り物を開けてみよう。"

    # say L541 ana
    old "Wow, it's huge, things are getting better since last time, looks very tasty... Do you mind if I give it a taste?"
    new "わあ、大きいね、前より良くなってるみたいだよ、とても美味しそう… 味見させてくれるかな？"

    # say L543 ana
    old "Let me take care of this now!"
    new "私がこれを見てみるわ！"

    # say L555 ana
    old "Did you like it?  You are not the only expert here, I am quite ready for this kind of 'exercises', how would you rate my performance?"
    new "気に入ってくれた？　あなただけがプロじゃないの、この手の‘練習’には私もかなり慣れてるわ。私の腕はどのくらいだったと思う？"

    # say L568 lis
    old "Hey guys, I'm finally here, did you guys finish already?"
    new "みんな、やっと来たわ。もう終わったの？"

    # say L569 pla
    old "(Oh god, for a few minutes early and she could have discovered us...)"
    new "ああ、神様、数分早ければ彼女に見つかったかもしれないな..."

    # say L570 ana
    old "Yes, it was very good. [pla] is the most wonderful partner I could ask for..."
    new "はい、とても良かったわ。[pla]は私が望む最高のパートナーだわ…"

    # say L571 ana
    old "He is very pleasant even though some positions got very hard, I like it too much!"
    new "彼はとても気持ちいいし、いくつかの体位は大変だったけど、私はすごく好きだよ！"

    # say L572 lis
    old "Aww, that's dazzling... I appreciate your words."
    new "あわ、それは眩しいね…あなたの言葉が嬉しいよ。"

    # say L574 ana
    old "For sure, I know I will be coming very often, I didn't know it was so amusing, very ‘delicious', I was fully satisfied."
    new "もちろん、私もよく来るだろうな。こんなに楽しいとは思わなかったわ、とても「美味しい」体験だったわ、本当に満足したわ。"

    # say L575 lis
    old "Sounds terrific... Wait, what's that on your face?"
    new "Sounds terrific... 待って、顔に何ついてる？"

    # say L577 ana
    old "Oh, what's that? Ahh, It must be sweat, you know this is kind of new for me-"
    new "あら、それ？あっ、汗かもしれないわ、これって私にとってまだ新しいことだから-"

    # say L578 lis
    old "Yeah, right."
    new "うーん、そうかな。"

    # say L579 ana
    old "But no worries, I will clean it in a moment, thank you."
    new "でも心配しないで、すぐに拭きますから、ありがとう。"

    # say L582 ana
    old "Thank you very much Lisa, once again, today's session was amazing, and [pla], this definitely be repeated, I need more... I mean sessions like this one."
    new "ありがとう、リサ。今日も最高の時間だったわ、そして [pla]、これ絶対に繰り返されるべきだよ、もっと必要だから… というか、こんなセッションがね。"

    # say L583 pla
    old "... Y- yes, see you later..."
    new "うん、じゃあ後でね…"

    # say L584 lis
    old "Bye bye, Anastasia."
    new "バイバイ、アナスタシア。"

    # say L594 lis
    old "I really wanted to thank you, I know you weren't prepared enough but you actually did incredible, I am very embarrassed because it was all of the sudden for you to do it."
    new "ありがとうって言いたかったの、準備が足りなかったのは分かってるけど、実際には驚くほど素晴らしい仕事をしてくれたわ。急なお願いなのに、すごく恥ずかしいわ。"

    # say L595 pla
    old "No problem, I am happy to be of help."
    new "問題ないよ、君のために手伝えてうれしいさ。"

    # say L596 lis
    old "I just want you to know that you're fantastic, you accomplished to do the session without the proper training..."
    new "あなたが凄いことを知ってほしいの、適切な訓練なくしてセッションを成功させたんだから…"

    # say L597 lis
    old "I can see a great talent in you, I'm willing to teach you if want to know more, I hope I will not bother you again."
    new "あなたの中にある大きな才能を感じてるの、もっと知りたいなら教えてあげるわ、また迷惑をかけないようにしたいな。"

    # say L598 pla
    old "Thank you very much, and don't worry you can ask me if you need more help."
    new "ありがとう、心配しないで。必要ならいつでも俺に相談して。"

    # say L599 lis
    old "Thank you honey, I appreciate your kindness."
    new "ありがとう、あなたの優しさが嬉しいわ。"

    # say L619 lis
    old "Hi, [pla], how are you?"
    new "元気？[pla]、どうしてる？"

    # say L620 pla
    old "I am fine, thank you. How about you?"
    new "俺は元気だよ、ありがとう。君は？"

    # say L621 lis
    old "I am well, actually I'm kind of concerned..."
    new "実はちょっと心配なんだ..."

    # say L622 pla
    old "Why is that?"
    new "なぜそう思うの？"

    # say L623 lis
    old "To be honest, I think you're better than what I thought, Anastasia was really pleased with your job last time, so she wants to continue the program with you..."
    new "実はね、あなたは私が思っていたよりもずっと良い人だと思ったの。アナスタシアも前回の仕事でとても満足していて、だからあなたとプログラムを続けたいと思っているの..."

    # say L624 pla
    old "A- Anastasia?"
    new "ア- アナスタシア？"

    # say L625 lis
    old "Yes, however, my concern is... I didn't want to ask you again, however since Anastasia is asking for you, I want her to have the best experience..."
    new "はい、でも私の懸念は……またあなたに頼むのは避けたかったんだけど、アナスタシアがあなたを指名しているから、最高の体験をしてほしいの。"

    # say L626 lis
    old "Of course the decision hasn't been made yet, I explained to her I needed to discuss it with you first, before I could say yes or no, so I just wanted to let you know."
    new "もちろんまだ決めていませんよ、彼女にはまずあなたと相談する必要があるって説明しましたから、はいとかいいえって言える前に、ただ知らせたくて。"

    # say L628 lis
    old "Last time you helped me but since this is going to be a more frequent assistances, I am thinking you can be part of the business and you will have an income..."
    new "前回は助けてくれたけど、今後はもっと頻繁なサポートが必要になるので、ビジネスの一環として参加してもらい、収入も得られるように考えているの。"

    # say L629 lis
    old "It will also bring positive things to your life, making it part of this new way of living. You know the more that you feel the universe the better you can share with others."
    new "これがあなたの人生にも良い影響を与えるでしょう、この新しい生活の一環としてね。宇宙を感じるほど、他人ともよりよく分かち合えるようになるわ。"

    # say L630 lis
    old "I will give you the proper training, so you'll have the knowledge you need, we can make the business grow together, I know other customers will love your job too."
    new "適切なトレーニングを受けさせてあげるから、必要な知識を得られるわ。一緒にビジネスを大きくしていこうよ、他の客たちもあなたの仕事を気に入ってくれると思うわ。"

    # say L631 pla
    old "I appreciate you considering me as an option, I will gladly help you."
    new "君が俺を選んでくれてありがとう、喜んで手伝うよ。"

    # say L632 lis
    old "Oh [pla], you are very kind, I have no words on how I appreciate your help, I will do everything I can so you can learn more."
    new "あら [pla]、あなたはとても優しいわ。あなたの手伝いへの感謝の言葉が見つからないの。私ができる限りのことをして、あなたがもっと学べるようにするから。"

    # say L633 pla
    old "Don't worry, I'm glad to help."
    new "心配しなくていい、喜んで手伝うよ。"

    # say L634 lis
    old "Actually, are you too busy right now?"
    new "実は今忙しいの？"

    # say L635 pla
    old "You mean now? I think I can stay for a while, why do you ask?"
    new "今のこと？ちょっと時間は作れるけど、なんでそんなに聞くの？"

    # say L636 lis
    old "It's because we can go ahead with a practice today the next session you will have with Anastasia."
    new "それは今から練習を進めて、次にアナスタシアと会うセッションに備えられるからよ。"

    # say L637 pla
    old "Oh, I see, sounds good."
    new "なるほど、いいな。"

    # say L638 lis
    old "Perfect, let's go."
    new "完璧、行こう。"

    # say L646 lis
    old "Now let's get ready to start, please remember to control your breathing so we can make the most out of the exercise."
    new "それじゃあ準備を始めて、呼吸をコントロールしてね。そうすればエクササイズを最大限に活用できるわ。"

    # say L648 lis
    old "Since the previous positions  you worked with her were more aimed to release stress and anxiety, this time we will get more into the yoga world, so you can discover more sensations."
    new "前回のポジションはストレスや不安を解消することを目的としていましたが、今回はヨガの世界にさらに深く入り込み、より多くの感覚を発見できるようにしましょう。"

    # say L650 lis
    old "The first position we will work on is extremely demanding, you need to be very careful so you can give the right directions..."
    new "最初のポジションは非常に要求が高いので、正しい指示を出すために気をつけてくださいね。"

    # say L651 lis
    old "Depending on you the customer can feel more energy coming thru."
    new "お客様がより多くのエネルギーを感じられるかどうかはあなたの腕次第です。"

    # say L652 pla
    old "Ok, what... Do I need to do?"
    new "分かった、じゃあ……何をすればいいんだ？"

    # say L653 lis
    old "For the position, we will focus on the back, You will make sure I can get the perfect position, I will be on my hands and feet, looking straight."
    new "ポジションは背中を中心にします、私が手と膝で四つん這いになるので、完璧な位置を確保するために協力してください、まっすぐに見つめています。"

    # say L654 lis
    old "You need to help stretch the back by applying some pressure on the hips, Initially the weight of the body will be on the arms..."
    new "背中を伸ばすために腰に少し圧力を加えてくれるの、最初は体重が腕にかかるの…"

    # say L655 lis
    old "After some seconds we will need to change and apply it to the legs, you need to help the customer lift the hips and now firmly apply pressure with your pelvis."
    new "数秒後には姿勢を変えて足にも力を加える必要があるわ。お客様の腰を上げてもらって、その状態で自分の骨盤を使ってしっかりと圧力を加えて。"

    # say L664 lis
    old "We will need to repeat that movement several times, watch your breathing and making sure the position is being done properly. Got it?"
    new "その動きを何回か繰り返す必要があるわ、呼吸に気をつけて、姿勢が正しくできてるか確認して。分かった？"

    # say L666 lis
    old "Perfect, let's try it."
    new "Perfect、やってみましょう。"

    # say L673 lis
    old "That's it... You are doing it right."
    new "そう、その通り… 正しくできてるわ。"

    # say L674 pla
    old "(Oh god this is quite enticing, I will need to touch her butt to grab her hips...)"
    new "（ああ、これはかなり誘惑的だ。彼女の尻をつかんで腰を固定しないと……）"

    # say L675 lis
    old "Don't forget to hold the hips firmly, the muscle must be exercised."
    new "ヒップをしっかりホールドして、筋肉を鍛えてね。"

    # say L676 pla
    old "(If I do it any harder, I'll touch her pussy.)"
    new "もしもっと強くやったら、彼女のマンコに触れちゃうかもしれないな。"

    # say L677 pla
    old "Don't worry... I will do it."
    new "心配しないで…ちゃんとやるから。"

    # say L678 lis
    old "Perfect, that will help us to ensure the customer is getting the right position."
    new "完璧、それならお客様が正しい位置を確保できるわ。"

    # say L679 lis
    old "That was very good, you are doing good. Now let's move to the second position."
    new "それは良かった、上手ね。次は二つ目のポジションに移ろう。"

    # say L685 pla
    old "Good! What's up with this one?"
    new "よし！このポジションはどんな感じだ？"

    # say L686 lis
    old "As you can imagine, we need to increase the difficulty, for the next position your help is essential, I will relax my entire body, you will hold my hips..."
    new "想像できると思うけど、次のポジションでは難易度を上げないといけないの。次はあなたの協力が必須よ。私は全身をリラックスさせて、あなたには私の腰を支ってもらうわ…"

    # say L687 lis
    old "The first step will be to carry my body weight, you can support yourself with your pelvis, however I understand that could be very tiring, that is why we'll have some tiny breaks."
    new "最初のステップは私の体重を支えること、骨盤で自分を支えられるけど、それがかなり疲れるだろうから、小さな休憩を入れることにするわ。"

    # say L688 lis
    old "Since you are using your pelvis, the breaks moment will be to relax your pelvis and let the weight remain on the customers arms and your legs."
    new "骨盤を使ってるから、休憩のときは骨盤をリラックスさせて、体重を客の腕と自分の足に移すわ。"

    # say L689 pla
    old "Ok, sounds a bit difficult."
    new "分かった、ちょっと難しそうだけど。"

    # say L690 lis
    old "Not really... However, that is why you need to keep breathing and stay focused so you can use your strength smartly and make the exercise enjoyable for you too."
    new "そうでもないけど…でも、そのためには呼吸を続けて、集中して力をうまく使って、エクササイズも楽しくできるよね。"

    # say L692 lis
    old "Let's do it! Now that you have the idea."
    new "それじゃ、始めるよ！今度は要領が分かったはずだね。"

    # say L693 pla
    old "Sure, go ahead."
    new "分かった、やってみるよ。"

    # say L699 lis
    old "Use your chakras to control your breathing that is the key for a position like this."
    new "あなたのチャクラを使って呼吸をコントロールするの、それがこの体位の鍵よ。"

    # say L708 pla
    old "Sure, I am breathing deeply and consciously."
    new "分かった、深く意識的に呼吸してるよ。"

    # say L709 lis
    old "I am very satisfied to hear that, try to use all your energy."
    new "そう言ってくれて嬉しいわ、全エネルギーを使い切ってみて。"

    # say L710 pla
    old "(This feels very delectable, she's rubbing my cock... I'm getting hard now...)"
    new "これの感じがとてもいいな、君がチンコをこすってる…今硬くなってきたよ…"

    # say L713 lis
    old "You need to focus too, so the exercise can be effective."
    new "集中しなきゃね、そうすればエクササイズが効果的になるわ。"

    # say L715 lis
    old "Keep doing that for a while with your customer, we will stop for now so we can continue with our next position, I can see you learn very fast."
    new "そのお客様としばらく続けて、次のもてぎに移るまで一休みしよう。あなた、本当に早く覚えるね。"

    # say L716 pla
    old "(Oh, thanks god!)..."
    new "ふう、よかった..."

    # say L722 pla
    old "(I don't know if I will be able to hide my boner this time.)"
    new "（今回はペニスを隠せるか自信ないな。）"

    # say L723 lis
    old "The last position is quite interesting, is related with the energies we have accumulated in the back, we will need to ignite them so we can release more of our chakra's potential..."
    new "最後の体位はとても興味深いわ、背中に溜めたエネルギーを解放するため、それを点火してチャクラの力をもっと引き出せるの。"

    # say L724 lis
    old "Since they are located in your back right before the gluteus,the position is aimed to get those points. Your customer will probably need you to get in that position."
    new "そのポイントはあなたの背中の下、お尻の上にあるから、その体位で刺激することになるわ。お客様は多分、あなたにその体位を取ってもらう必要があるでしょう。"

    # say L725 lis
    old "I will lie down on my shoulders, but I will hold my waist with my hands, my arms are going to be the main support."
    new "私は肩で横になり、手で腰を支えるんだけど、腕が主な支えになるの。"

    # say L727 lis
    old "You will keep balance of the body as well as the pressure needed in two different points, the legs and back of the customer."
    new "お客様の足と背中の2つのポイントに必要な圧力を保ちながら、体のバランスも取ってください。"

    # say L728 lis
    old "Let's start the position so you can have a better idea..."
    new "それじゃ、体勢を整えて、感じやすい位置から始めましょうか。"

    # say L729 pla
    old "(This position looks demanding so I will stay focused, I need to breath and to think something different.)"
    new "この体勢は難しそうだから、集中して、深呼吸しながら別のことを考えよう。"

    # say L730 pla
    old "Perfect, I am ready."
    new "完璧だ、準備はできている。"

    # say L731 lis
    old "Perfect here we go..."
    new "じゃあ、行こ！"

    # say L738 pla
    old "(Oh no, this position is making me feel very horny, I am sure she will notice pretty soon.)"
    new "この体勢、俺かなり興奮してるな。すぐ気づかれるだろう。"

    # say L739 lis
    old "Are you breathing properly, remember this is important for you to be able to assist your customer."
    new "呼吸大丈夫？これはお客様をサポートするのに大事なことだからね。"

    # say L740 pla
    old "Hmm... Sure, yes."
    new "うん…そうだな。"

    # say L743 lis
    old "I can see you are quite motivated with this asana, you will need to control your energies so you can decide how to express or attract with your body."
    new "このアサナにかなり熱心ね、エネルギーをコントロールして自分の体でどう表現するか、どう引き寄せるかを決めるのよ。"

    # say L745 lis
    old "Alright, I think we are done..."
    new "よし、これで終わりだね…"

    # say L757 lis
    old "OH MY GOD!"
    new "OH MY GOD！ → オーマイゴッド！"

    # say L769 pla
    old "I- I'm sorry, I'm so sorry these positions are really enticing... A- and I can't help it."
    new "ごめん、ごめん、この体位が本当に魅力的で… それに我慢できなかった。"

    # say L770 lis
    old "Don't worry, it's natural, I just got surprised by the... Size..."
    new "大丈夫、自然な反応よ、ただサイズに驚いただけ…"

    # say L772 lis
    old "Well, this happened because your chakras are unbalanced."
    new "まあ、これはあなたのチャクラがアンバランスだから起こったのね。"

    # say L773 pla
    old "My cha- kras?"
    new "俺のチャクラ？"

    # say L774 lis
    old "Yes, I think you need to reharmonize your chakra ‘Muladhara', this is the sexual chakra and is clearly unbalanced in you."
    new "はい、あなたのチャクラ『ムーラドハラ』を再調和させる必要があると思うの。これは性的なチャクラで、あなたには明らかにバランスが取れていないみたいよ。"

    # say L775 lis
    old "But, don't worry, once you harmonize your chakra Muladhara, you will be more stable, and you will be able to prevent these unexpected body reactions."
    new "でも、心配しないで、チャクラのムーラドハラを調和させれば、あなたはもっと安定し、予期せぬ身体の反応を防げるようになるわ。"

    # say L777 lis
    old "I think you need to work on that, we can do some tantric rituals so you can restore your chakras to their natural energy."
    new "その部分に努力が必要ね、タントラの儀式をやってチャクラを自然のエネルギーに戻すわ。"

    # say L778 pla
    old "A tantric what?"
    new "タントラって？"

    # say L779 lis
    old "Tantric rituals, it's a very spiritual technique where we clean your chakras. I think we should do it tonight."
    new "タントリック儀式よ、それはチャクラを浄化するとてもスピリチュアルなテクニックなの。今夜やらない？"

    # say L780 pla
    old "T- tonight?"
    new "今夜？"

    # say L781 lis
    old "Yes, I need to prepare a few things for the ritual, And you need to balance your chakras before your next yoga session with Anastasia."
    new "はい、儀式のためにいくつかの準備が必要なの。そして次にアナスタシアとヨガをする前に、あなたのチャクラを整える必要があるわ。"

    # say L782 lis
    old "We don't want you to have this kind of... Reactions with her, don't we?"
    new "この手の...反応は彼女と起こしたくないよね？"

    # say L783 pla
    old "Hmm... No, no, of course not... No."
    new "うん… そんなことないよ… ない。"

    # say L784 lis
    old "Ok, then I'll make the preparations for our tantric ritual."
    new "じゃあ、タントリック儀式の準備をしておくね。"

    # say L786 lis
    old "It was nice to practice with you today! See you later."
    new "今日の練習、楽しかったわ！ またね。"

    # say L787 pla
    old "See you then."
    new "じゃあ、その時ね。"

    # say L806 pla
    old "Wow... W- what are you... W- wearing?"
    new "Wow... お前今何着てんの？"

    # say L807 lis
    old "Oh, hi, [pla], glad to see you... These collars you see are some elements that make part of the ritual we will do tonight; they will help to keep the balance of your chakras."
    new "あ、こんにちは、[pla]、会えて嬉しいわ... これらの首輪は今夜行う儀式の一部で、あなたのチャクラのバランスを保つのに役立つわ。"

    # say L808 lis
    old "Let's go to the room so I can explain everything to you..."
    new "部屋に行こう、そこで全部説明するから…"

    # say L817 lis
    old "Everything is set in this room so we can cleanse those energies and balance your chakras..."
    new "この部屋ではすべてが整っていますので、エネルギーを浄化し、チャクラのバランスを取ることができます…"

    # say L818 lis
    old "I hope you can take advantage of the lights, the fragrances, as well as the location, we are about to do a very important ritual, so every single detail must help us get in the mood."
    new "光や香り、そしてこの場所を活用してほしいの。これから行う儀式はとても重要だから、細部まで私たちの気分を高めるために役立つようにしなきゃ。"

    # say L819 lis
    old "Please I need you to open your mind so the exercises we do tonight will be more effective..."
    new "お願い、今夜のエクササイズがより効果的になるように心を開いてくれない？"

    # say L820 lis
    old "Some of the exercises of the ritual will have a lot of contact so please let the massages follow its course, it is a very spiritual process."
    new "リチュアルのいくつかのエクササイズでは触れ合うことが多くなるので、マッサージはその流れに任せていいの、とてもスピリチュアルなプロセスだから。"

    # say L821 pla
    old "M- massages?"
    new "マッサージ？"

    # say L822 lis
    old "We need to compenetrate each other today so I can balance right your chakras."
    new "今日はお互いに交わり合う必要があるの。あなたのチャクラをバランスよくするためよ。"

    # say L824 lis
    old "I did some meditation today so the massages can be very deep and productive for you so please merge with me to have a great experience."
    new "今日は瞑想をしたから、マッサージが深く、効果的になるわ。だからぜひ私と一体化して、素晴らしい体験をしてほしいの。"

    # say L826 lis
    old "It's a very beautiful way to perceive what surrounds you, so you need to express according to the energies that you will be able to recognize... Let's start."
    new "それは周囲を感じ取る美しい方法だから、あなたが認識できるエネルギーに従って表現する必要があるの……。それじゃ、始めましょう。"

    # say L828 lis
    old "First, I need you to undress so we can uncover our energies."
    new "まずは、服を脱いで私たちのエネルギーを解放しようね。"

    # say L829 pla
    old "U- undress?"
    new "うーん、脱ぐって？"

    # say L830 lis
    old "Yes, please don't take it the wrong way, this is a very pure experience so I need you to undress not only the clothes but also your mind and soul."
    new "はい、誤解しないでください、これはとても純粋な体験なので、服だけでなく心と魂も脱いでほしいの。"

    # say L831 lis
    old "Keep in mind your body is something beautiful and it doesn't make you feel embarrassed, it's natural as universe is and we are going beyond to see how to control its energy."
    new "あなたの体は美しいもので、恥ずかしがる必要はありません、自然そのものです。宇宙が自然であるように、私たちもそのエネルギーを制御する方法を見つけていくために、さらに進んでいきましょう。"

    # say L838 lis
    old "Let's keep working on our breathing, remember the pranayama, we need to concentrate so you can open your senses, that is the main purpose of this exercise today."
    new "呼吸の練習を続けましょう、プラナヤマを思い出してください。集中することで感覚が開くんです、それが今日の練習の目的です。"

    # say L839 pla
    old "Hmm, sure..."
    new "うん、そうか..."

    # say L840 lis
    old "I need you to concentrate, smell the candles, the ambience we have for this moment, do you feel the fragrance?"
    new "集中して、キャンドルの香りを感じてみて、この瞬間の雰囲気を味わって。香りを感じてる？"

    # say L841 pla
    old "Yes, it smells nice."
    new "うん、いい香りだね。"

    # say L842 lis
    old "Great!, now please lie down with your stomach on the floor, then relax, I will do the massage, you will feel my body helping yours to open your senses."
    new "Great！ それじゃ、お腹を下にして床に横になって、リラックスして。マッサージするから、私の体があなたの感覚を開くのを感じて。"

    # say L851 lis
    old "let me start with your shoulders, so you can feel more."
    new "まずは肩から始めましょう、そうすればもっと感じられるはずよ。"

    # say L853 lis
    old "Please hold your breath a bit more, so we can intensify the fragrance and focus your thoughts."
    new "もう少し深呼吸を止めて、香りを濃くして思考を集中させてみて。"

    # say L857 lis
    old "Good, do you feel my touch, my skin... How do you feel?"
    new "感じてる？私の肌が……どんな風に感じる？"

    # say L858 pla
    old "It's very soft."
    new "とても柔らかいな。"

    # say L859 lis
    old "That's perfect, you are doing good."
    new "それがいい、上手だね。"

    # say L873 lis
    old "Let me touch your skin now so we can release the pressure, breath with me, it's just one pace, don't stop..."
    new "今から私の手で君の肌に触れて、圧力を解き放とう、一緒に息を合わせて、一歩だけ、止まらないで..."

    # say L875 lis
    old "Feel free to express and feel everything your body wants to feel at this moment, I will control everything so you can go freely wherever your mind wants."
    new "この瞬間に体が感じたいことをすべて感じていいわ、全部私がコントロールするから、あなたの心が行きたいところどこでも自由にいっていいの。"

    # say L876 lis
    old "Try harder to focus, it's just this moment, there is nothing else to think about, but the sensations, can you smell it?"
    new "もっと集中して、この瞬間だけを考えよう、他には何も考えなくていい、感覚だけに集中して、匂いも感じられる？"

    # say L877 pla
    old "Yes, I can."
    new "うん、感じ取れてる。"

    # say L888 pla
    old "I feel amazing, I appreciate your time and effort to help me."
    new "俺は最高だ、君が時間を使ってくれて感謝してる。"

    # say L889 lis
    old "Oh no, it's no trouble, I'm just an instrument from the universe to help you with your energies."
    new "あら、全然気にならないわ、私はただ宇宙からあなたを助けるための道具に過ぎないの。"

    # say L890 lis
    old "Just relax and please keep learning so you can apply all your knowledge to the sessions with your customers. I am sure now you won't have these issues with Anastasia."
    new "リラックスして、学んだことをお客様とのセッションに活かしていってください。アナスタシアさんとの問題ももう起こらないでしょう。"

    # say L891 lis
    old "I can also feel a different aura on you now, I can feel your spirit is more calmed."
    new "今あなたの周りには違うオーラを感じて、あなたの精神がより落ち着いているのがわかります。"

    # say L892 pla
    old "Thank you for all that you have done."
    new "ありがとう、君がしてくれた全てのことに対して。"

    # say L893 lis
    old "It's something I enjoy, please have some rest."
    new "それは私が楽しむことだから、ゆっくり休んで。"

    # say L894 pla
    old "I'll do it, have a great one too."
    new "俺がやる、君もゆっくり休んで。"

    # say L895 lis
    old "Good night, [pla]."
    new "おやすみ、[pla]。"

    # say L896 pla
    old "Good night."
    new "おやすみ。"

    # say L916 lis
    old "Welcome [pla], we were waiting for you."
    new "[pla]、ようこそ。待ってましたよ。"

    # say L917 pla
    old "Hi, I am sorry if I'm late."
    new "遅くなってごめん、君。"

    # say L918 lis
    old "Oh don't worry, you are just on time."
    new "心配しないで、ちょうどいい時間に来たのね。"

    # say L919 lis
    old "How do you feel today, are you ready to have the second session with Anastasia?"
    new "今日はどうですか、アナスタシアとの二回目のセッションに備えていますか？"

    # say L920 pla
    old "Yes, I've been thinking about it."
    new "はい、考えてたよ。"

    # say L921 lis
    old "Perfect, Well guys I am glad to see you both, I know you are working hard and improving!"
    new "パーフェクト、皆さん、お会いできてうれしいわ。あなたたちが頑張って上達していることを知っているから！"

    # say L922 lis
    old "How about you Anastasia, how do you feel today?"
    new "アナスタシア、今日の気分はどう？"

    # say L923 ana
    old "I am quite happy with my trainer because he has HUGE talent, I am prepared today. [pla], is it going to be HARDER than last time?"
    new "トレーナーのすごい才能に感謝してる、私は今日準備万端だよ。[pla]、前回よりもっとハードになるのかな？"

    # say L925 pla
    old "I- I'm sure this is going to... to be a good session."
    new "あ、ああ、これはきっと……良いセッションになるよ。"

    # say L926 lis
    old "Perfect, I will leave you guys alone so you can do the session with no inconveniences. I will be here to give you proper privacy."
    new "完璧、邪魔しないようにあなたたちを一人にしましょう。適切なプライバシーを確保するために、私はここにいるわ。"

    # say L927 lis
    old "The room is already prepared."
    new "部屋はすでに準備されています。"

    # say L929 lis
    old "Anastasia I hope you enjoy your session you will be in good hands."
    new "アナスタシア、あなたのセッションを楽しんでくださいね。彼の手つきはきっと素晴らしいわ。"

    # say L931 ana
    old "Yes, I'm pretty sure he's really good with his hands, I'll enjoy the session."
    new "うん、彼の手つきはきっと上手いわ、セッションを楽しむつもりよ。"

    # say L932 lis
    old "Aww, I love that energy, please work hard... See you guys."
    new "あわ、そのエネルギー大好き、頑張ってね… またね。"

    # say L933 pla
    old "... See you."
    new "じゃあ、またな。"

    # say L947 pla
    old "Well, Today we will continue the meditation process, remem-"
    new "じゃあ、今日も瞑想の続きをしよう、覚えてるか？"

    # say L948 ana
    old "I wanted to- sorry to interrupt you..."
    new "すみません、途中で言葉を割り込んじゃって…"

    # say L949 pla
    old "Oh, it's ok, tell me."
    new "大丈夫、何でも言ってみろ。"

    # say L950 ana
    old "It is just that... I wanted to try something different today, you know."
    new "あの、その……今日ちょっと違うことを試してみたかったの。"

    # say L951 pla
    old "Hmm... What did you have in mind?"
    new "Hmm... 何を試したかったんだ？"

    # say L952 ana
    old "Well being honest, I was kind of distracted, I was not able to forget about your cock... And I want you to fuck me with that big hard cock."
    new "正直に言うと、ちょっと気になってて、あなたのチ○ポのことばかり考えちゃって……その大きな硬いチ○ポで、私を犯してほしいの。"

    # say L953 pla
    old "(WHAT THE FUCK!)"
    new "何だよ！"

    # say L954 pla
    old "WHAT? B- but, we need to have a yoga session..."
    new "何？　でも、ヨガのセッションをしなきゃならないんだよ…"

    # say L955 ana
    old "The truth is I am very horny today, I came considering to have sex with you..."
    new "本当は今日、すごく欲求不満で、あなたとセックスすることを考えていたの..."

    # say L961 ana
    old "Oh, it seems like you're getting ready... Why don't you get these pants off?"
    new "あら、準備ができてるみたいね… そのパンツ、脱いじゃう？"

    # say L962 pla
    old "I- it's not-"
    new "あ、違うってんじゃなくて-"

    # say L963 ana
    old "Don't be shy, I know both of us will feel very good after that, I am just a bit thirsty, can I get a taste?"
    new "恥ずかしがらないで、お互い気持ちよくなるのはわかってるでしょう？ちょっと喉が乾いてるの、味見させてもらえる？"

    # say L973 ana
    old "Oh, yeah, this is what I'm talking about..."
    new "ああ、そう、これが欲しかったの..."

    # say L987 ana
    old "That was delicious, but now I want you to fuck me!"
    new "それは美味しかったけど、今度はあなたに私を犯してほしいの！"

    # say L988 pla
    old "W- what? Oh, no Lisa is downstairs she could-"
    new "え、待って、Lisaが下にいるよ、見つかるかもって-"

    # say L989 ana
    old "Maybe you need a bit of motivation... You want to see them again, don't you?"
    new "少し刺激が必要かもね…また会いたいと思ってるよね？"

    # say L1002 ana
    old "Now, let's fuck!"
    new "さあ、今すぐやっちゃいましょう！"

    # say L1015 ana
    old "You were amazing, I loved this session, I need this kind of session more often."
    new "あなたは素晴らしかったわ、このセッションが大好きだったの。もっと頻繁にこんなセッションをしたいわ。"

    # say L1017 ana
    old "I can keep this a secret if you are afraid of your boss, she doesn't need to know our particular sessions, besides she doesn't have the big talent you have."
    new "あなたがボスに心配しているなら、秘密にしてあげるわ。彼女には私たちの特別なセッションのことは知らなくていいし、それに彼女にはあなたのような大きな才能はないわ。"

    # say L1018 ana
    old "I am considering you can get a tip later, for your hard work..."
    new "後で Tips をあげるかもしれない、あなたの頑張りをねぎらって..."

    # say L1019 pla
    old "... I- I think we shouldn't-"
    new "…あの、ちょっと待って、"

    # say L1020 ana
    old "Do not worry honey, this was your best yoga session ever."
    new "心配しないでハニー、これはあなたが今までで一番良いヨガセッションだったわ。"

    # say L1032 lis
    old "Hi guys, congratulations I can see you are sweating, that means you had a very hard job today."
    new "みんな、お疲れ様。汗をかいてるところ見て、今日もかなりハードな仕事だったみたいね。"

    # say L1033 ana
    old "Yes, [pla] took a lot out of me today."
    new "今日は[pla]にかなり消耗されたわ。"

    # say L1035 lis
    old "He is improving every day; I can tell you he's putting in a big effort."
    new "彼は毎日上達してるわ、君のために頑張ってるのが伝わるよ。"

    # say L1036 ana
    old "I can see that, I hope we can meet again later, the sooner the better."
    new "そうね、彼の成長が日々感じられるわ。また後で会えたら嬉しいな、できるだけ早くに。"

    # say L1037 lis
    old "Oh sure, I have your appointment already set. Don't worry, we will be waiting for you."
    new "もちろん、あなたの予約はもう設定してあるよ。心配しないで、私たちがあなたを待ってるから。"

    # say L1038 ana
    old "Perfect, thank you for the session today... And thank you very much for your hard, hard work [pla], I really enjoy it."
    new "完璧、今日のセッションありがとう... そして君の一生懸命な仕事、本当に感謝してる [pla]、すごく楽しくて。"

    # say L1042 lis
    old "Bye Anastasia, have a great day!"
    new "バイ アナスタシア、良い一日をね！"

    # say L1052 lis
    old "I am very satisfied with your job, I wanted you to know that I am considering to introduce you to other customers, I think you are so easy going, that people will just connect with you."
    new "あなたの仕事にとても満足しています、他のお客様にも紹介したいと思っているの。あなたは気さくなところがあって、きっと人々とすぐに打ち解けられると思う。"

    # say L1053 pla
    old "O- other customers, I- I don't know-"
    new "他のお客様って、俺、よくわかんないよー"

    # say L1054 lis
    old "You can help other people, your energy will just bring you what you need, you only need to keep on working hard..."
    new "他の人を助けることができるわ、あなたのエネルギーがあなたが必要なものを持ってきてくれるから、ただ頑張り続けているだけでいいのよ..."

    # say L1055 pla
    old "Hmm if you say so..."
    new "Hmm、そうなのか…"

    # say L1056 lis
    old "Oh, by the way, remember we will have tomorrow a new ritual, the tantric massages need to be continued so we can balance your chakras."
    new "そういえば、明日新しい儀式があるわ。タントラマッサージを続けて、あなたのチャクラをバランスさせる必要があるの。"

    # say L1058 lis
    old "Amazing, thank you for today, please get some rest."
    new "素晴らしい、今日もありがとう。ゆっくり休んでね。"

    # say L1059 lis
    old "See you later [pla]!"
    new "またね、[pla]！"

    # say L1078 lis
    old "Hi [pla], nice to see you again!"
    new "また会えて嬉しいわ、[pla]！"

    # say L1079 pla
    old "Hello, Thank you."
    new "こんにちは、ありがとう。君がここに来てくれたことに感謝してる。"

    # say L1080 lis
    old "I am very happy because you are very committed with this extra training."
    new "あなたがこの特別な練習に真剣に取り組んでくれているので、本当に嬉しいわ。"

    # say L1081 pla
    old "I appreciate you are taking the time to teach me."
    new "君が時間を割いて教えてくれること、感謝してるよ。"

    # say L1082 lis
    old "Any time, you are helping a lot with my business, I will do my best so you can be as good as me."
    new "いつでも、あなたの力になってくれて感謝してるわ。私も全力で教えてあげるから、あなたも私と同じくらい上手になれたらいいな。"

    # say L1083 pla
    old "Hmm, that is very nice of you."
    new "うん、それはとても親切な Angebot だね。"

    # say L1084 lis
    old "Let's go to the room so we can start the tantric session."
    new "部屋に行こう、タントラのセッションを始めるよ。"

    # say L1092 lis
    old "Have you seen any improvement thanks to last session?"
    new "前回のセッションのおかげで何か改善した感じた？"

    # say L1093 pla
    old "Yes... I can feel in a better mood."
    new "うん……前回のセッションのおかげで気分が良くなったな。"

    # say L1094 lis
    old "Good, you will see better results."
    new "いいね、もっと良い結果が出せるようになるわ。"

    # say L1095 lis
    old "Today we need to improve a lot because you need to be able to balance your chakra muladhara as soon as possible, that way you can offer a more delightful experience."
    new "今日はたくさん改善しなければならないわ、あなたのチャクラ・ムーラダラをできるだけ早くバランスさせる必要があるから。そうすれば、もっと素晴らしい体験を提供できるわ。"

    # say L1096 lis
    old "Please get comfortable, you know we need to open our mind, just relax because this is not any casual meeting, your body is more than flesh, blood and energy..."
    new "リラックスして、心を開いて。これはただの会話じゃないから、体はただの肉や血やエネルギーだけじゃないのよ…"

    # say L1097 lis
    old "So, there's nothing to feel shy about, please undress."
    new "だから、恥ずかしがる必要はない、服を脱いで。"

    # say L1103 lis
    old "Perfect, so today we need to increase the perception of our senses, you must feel more, once you connect your sexual chakra, we will start with the massage."
    new "完璧、今日は五感を研ぎ澄ませる必要があるの、もっと感じて、性のチャクラをつなげたらマッサージを始めるわ。"

    # say L1104 lis
    old "The idea is to recognize some feelings that only you can see, some situations that are deep inside, no one will be able to get there... Do not forget to feel the energy..."
    new "その感覚を認識することが大事よ、あなただけが見られるもの、深く心の中にあるもの……誰もそこには入れないわ……エネルギーを感じ忘れないでね……"

    # say L1112 lis
    old "While feeling my body on your skin please bring that healing energy in and allow it to wash through your body and mind."
    new "肌で私の身体を感じながら、その癒しのエネルギーを体内と心に流し込んでください。"

    # say L1114 lis
    old "Let your skin merge with mine, feel my fragrance, connect your senses with mine."
    new "あなたの肌を私の肌と溶け合わせ、私の香りを感じ、あなたの感覚を私の感覚とつなげて。"

    # say L1124 pla
    old "So, are you going to use your hands like last time?"
    new "じゃあ、今度は手を使うの？"

    # say L1125 lis
    old "No, we need to do better than last time, this time I want you to be able to experience a more intense moment, so I think my breast is going to be perfect."
    new "いいえ、前回よりもっと良いことをしよう。今回はもっと濃密な瞬間を感じてほしいから、私の胸がぴったりだと思うの。"

    # say L1126 pla
    old "Y- your breast? ..."
    new "Y- お前の胸..."

    # say L1127 lis
    old "Yes, remember this is not a sexual act, this a spiritual ritual to connect together and cleanse your chakras."
    new "はい、覚えておいて、これは性的な行為じゃなくて、私たちがつながってチャクラを浄化するためのスピリチュアルな儀式なの。"

    # say L1128 lis
    old "Don't get distracted, keep focused so we can do the session and control your breathing."
    new "集中して、セッションを進めるために呼吸をコントロールしなさい。"

    # say L1129 pla
    old "... O- ok."
    new "オーケー、分かった。"

    # say L1137 lis
    old "Just relax your body it is a part of the universe, where I can move freely and that way we can take it out..."
    new "体をリラックスさせて、宇宙の一部として自由に動けるようになれば、そうやって取り出せるのよ..."

    # say L1146 lis
    old "I can see your energy is more stable now, I am really proud of the effort you are putting in."
    new "あなたのエネルギーが安定してきたのが見えるわ、本当に頑張ってるね。"

    # say L1147 lis
    old "I think we have just one lesson left, according to the progress I have seen, this chakra muladhara is not so strong now, you are getting the balance you need."
    new "あと一つのレッスンだけだと思うわ、あなたの進歩を見てると、このチャクラ・ムーラドハラはもうそんなに強くないみたいね、必要なバランスが取れてきているみたい。"

    # say L1148 lis
    old "There are still more things to learn, see you next time, you need to get some rest, don't forget tomorrow's lesson with Anastasia."
    new "まだ学ぶことはたくさんあるわ、また次回ね。今日はゆっくり休んで、明日のアナスタシアとのレッスンを忘れないように。"

    # say L1149 pla
    old "Sure, I'll be here... Thank you, bye."
    new "分かった、ここにいるよ… ありがとう、またね。"

    # say L1169 lis
    old "Hi Anastasia, welcome to your yoga session once again, I hope you are ready for the routine today."
    new "アナスタシア、またヨガのレッスンに来てくれてありがとう。今日のルーティンに備えているといいな。"

    # say L1170 ana
    old "Hi Lisa, you are right I came prepared, this time I want to give my best and I hope [pla] brings a harder... Activity today."
    new "こんにちはリサ、言われた通り準備は万全よ、今日は最高のパフォーマンスを発揮したいの。[pla]がもっとハードな… アクティビティを用意してくれることを期待してるわ。"

    # say L1177 pla
    old "Hi... Am I late?"
    new "嘿……遅刻したか？"

    # say L1179 lis
    old "Oh no, it's perfect timing, Anastasia was telling me she came prepared today..."
    new "あら、遅刻したわけじゃないわ、アナスタシアが今日こそ準備万端だって話してたところだったの。"

    # say L1180 lis
    old "I am very happy that your training has become something personal, it means that you guys are feeling connected through these exercises."
    new "あなたのトレーニングが個人的なものになったことをとてもうれしく思うわ、これで皆さんがあのエクササイズを通じてつながっていることがわかるから。"

    # say L1181 lis
    old "I am so proud that you guys are improving together, I will leave you alone so you can do your routine, in case you need me, please let me know."
    new "みんなが一緒に上達しているのが誇らしいわ、ルーティンを進めるためには二人きりにさせてあげるから、何か必要なら教えてね。"

    # say L1182 pla
    old "Sure, I will let you know in case we need you, let's go to the room to start the lesson."
    new "わかった、必要なら連絡するよ。部屋に行こう、レッスン始めるぞ。"

    # say L1190 pla
    old "Well, we have a very-"
    new "まあ、今日のはかなり-"

    # say L1191 ana
    old "I needed this urgently, so let's get straight to it..."
    new "急に必要になったの、だからさっそく始めましょう..."

    # say L1212 ana
    old "I want MORE! I want you to be rude... Fuck me harder PLEASE!"
    new "もっとしてほしいの！乱暴に…もっと激しくファックしてPLEASE！"

    # say L1226 ana
    old "Oh, you've accomplished it, this was by far better than last time."
    new "ああ、これなら前よりもずっと良かったわ。"

    # say L1227 ana
    old "Could you make it better next time? I wanna see that!"
    new "次はもっと上手にできるよね？ それ見たいの！"

    # say L1228 pla
    old "N- next time?"
    new "次か？"

    # say L1229 ana
    old "I am really happy for every penny I have spent here; I will speak highly of you with some friends, they will love you..."
    new "ここに使ったお金のすべてが本当に嬉しいわ、友達にも君のことを絶賛するから、きっと彼らも君を好きになると思う..."

    # say L1231 ana
    old "Alright, thanks for everything it's time to go."
    new "じゃあ、ありがとう。そろそろ行きますね。"

    # say L1241 pla
    old "Oh Lisa, h- how are you?"
    new "オーリサ、ひっ、どうしてる？"

    # say L1242 lis
    old "I can see the 'Lesson' has finished."
    new "レッスンが終わったのがわかりますわ。"

    # say L1247 lis
    old "I want to congratulate you guys for the effort you are doing on every lesson, I can see every time is better, did you like it Anastasia."
    new "みんなの努力を称えたいわ、毎回上達しているのがよくわかる、アナスタシアは気に入ったかしら。"

    # say L1248 ana
    old "It was the best session ever; I am considering opening my schedule so we can make my sessions more frequent."
    new "最高のセッションだったわ；スケジュールを空けて、もっと頻繁にセッションができるように考えているの。"

    # say L1249 lis
    old "Of course we could discuss it later, you can have as many sessions as you need..."
    new "もちろん後で話し合っても良いけど、必要なだけのセッションを設定できるよ..."

    # say L1250 ana
    old "Fascinating! Next meeting we will check that."
    new "面白い！次のミーティングで確認するわ。"

    # say L1251 lis
    old "Hope you get some rest Anastasia, see you on next appointment."
    new "アナスタシア、ゆっくり休んでね、次回の予約でまた会うわ。"

    # say L1252 ana
    old "Oh thank you, I will, see you next time."
    new "ありがとう、ゆっくり休むつもりだね、またね。"

    # say L1253 ana
    old "Everything was amazing, thank you [pla]."
    new "すべてが素晴らしかったわ、ありがとう [pla]。"

    # say L1254 pla
    old "No problem, see you next session."
    new "問題ないよ、次のセッションでまたね。"

    # say L1263 lis
    old "Are you leaving too?"
    new "あなたも帰るの？"

    # say L1264 pla
    old "I guess so... ?"
    new "そうかな……？"

    # say L1265 lis
    old "I need to talk to you about something before you leave."
    new "あなたが帰る前に、ちょっと話したいことがあるの。"

    # say L1266 pla
    old "Hmm, sure... What is it?"
    new "うーん、いいよ… 何だ？"

    # say L1267 lis
    old "I think it's not acceptable... I know you are not doing the routine we have been preparing..."
    new "それは unacceptable だと思うの... 前から準備してたルーティンやってないって、知ってるわよ..."

    # say L1269 lis
    old "I assume the previous routines were not done either, am I right?"
    new "前のルーティンもやってなかったんでしょ？そうよね？"

    # say L1270 pla
    old "(Oh shit... Did she noticed we were having SEX)"
    new "ああシャイティ... 俺たちがセックスしてることに気づいてたのか..."

    # say L1271 pla
    old "W- what are you... T- talking about?"
    new "W- 何を…… 言ってるんだ？"

    # say L1272 lis
    old "Do not try to hide it, do you think I didn't hear her moaning?"
    new "隠そうとしても無駄よ、彼女の声は聞こえてたわよ？"

    # say L1273 pla
    old "I- I don't know what-"
    new "俺、何のことだかわかんないけど-"

    # say L1274 lis
    old "[pla], I heard what you were doing, and I can swear, it was not a yoga routine, you both were having sex!"
    new "[pla]、あなたが何をしていたのか聞こえていたわ、そしてそれはヨガのエクササイズじゃなかったって誓える、二人ともセックスしてたんでしょ！"

    # say L1275 pla
    old "(Oh God, she's going to kill me.)"
    new "神様、本当に怒らせやがったな。"

    # say L1276 pla
    old "I- I am very sorry, it wasn't my inte-"
    new "俺- すみません、それは意図したわけじゃなかった、lis。"

    # say L1277 lis
    old "Do you know what really pisses me off?"
    new "何が本当に腹立つか知ってる？"

    # say L1279 lis
    old "I mean I don't care if you are having sex or not, you can connect with anybody and share your energy, sex is beautiful and good way to connect together."
    new "ensex自体は気にしないけど、誰とでもつながってエネルギーを分かち合うのは美しいことよ、一緒に結びつく素晴らしい方法だわ。"

    # say L1280 lis
    old "But you should be applying the meditation and yoga experience with the client. This is not what I'm selling..."
    new "でも、クライアントとの瞑想やヨガの体験に集中すべきよね。これが私が売りにしてるんじゃないわ…"

    # say L1281 pla
    old "I'm so sorry..."
    new "すみません、本当に..."

    # say L1282 lis
    old "[pla], I think you have too many things to learn still, in this process... If someone is really learning to connect his body and soul, it means we are doing the process fine..."
    new "[pla]、まだ学ぶべきことがたくさんあるみたいね… 体と魂をつなげるために本当につとめているなら、私たちのプロセスはうまくいってるわ。"

    # say L1283 lis
    old "Anastasia is not doing it, she has been distracted, I mean my academy is not about other things different from the energy, meditation and yoga..."
    new "アナスタシアはやっていないわ、彼女は気を散らされてるの。私のアカデミーはエネルギー、瞑想、ヨガ以外のことは教えてないのよ。"

    # say L1284 lis
    old "She is not getting that here. I'm not doing this for money or business, it's about fate and helping others to connect with the universe."
    new "彼女はここではそれが得られないの。私はこれを金やビジネスのためにやってるわけじゃないの、運命と他人が宇宙とつながることを助けるためよ。"

    # say L1285 lis
    old "Can you understand what I am saying?"
    new "私が言っていること理解できる？"

    # say L1287 pla
    old "I apologize if I disappointed you, I know you probably don't want me to be here anymore, I understand, just let me tell you it wasn't on purpose."
    new "すみません、君をがっかりさせちゃったなら。君がもうここにいなくていいと思ったのは分かるけど、ただ、故意にそうしたわけじゃなくて。"

    # say L1288 lis
    old "What are you talking about? I do want you to be here."
    new "何言ってるの？ 私はあなたがいてほしいと思ってるよ。"

    # say L1289 pla
    old "(Wait, what? Is she upset or not)"
    new "待って、何言ってんの？怒ってるの？"

    # say L1290 lis
    old "I just need you to help me by doing the things right, I thought that you were learning with the sessions you are doing with me, am I wasting my time?"
    new "あなたが正しいことをする手伝いが必要なの。私が一緒にやっているセッションで学んでいると思っていたんだけど、私の時間無駄にしてるの？"

    # say L1291 pla
    old "... No, of course not, I'm sorry..."
    new "... いや、もちろんそんなつもりはない、ごめん..."

    # say L1292 lis
    old "I mean, you already know about this, you started a process, you should apply it to every activity you perform in your life... Even if it is sex... Yoga is deeply connected with sex."
    new "つまり、これについてはもう知ってるよね、あなたはプロセスを始めているんだから、人生で行うすべての活動にそれを適用すべきだよ… セックスにもね… ヨガはセックスと深く結びついているんだ。"

    # say L1293 lis
    old "We definitely need to discuss this more... Wait a minute..."
    new "もっとこの話題について詳しく話し合いましょう… ちょっと待って…"

    # say L1295 lis
    old "I think... That could work! if she is into you because of the sex, you guys can actually do a great job if you apply the yoga knowledge to the sex experience..."
    new "あのね… それがうまくいくと思うの！もし彼女がセックスに興味があるのはあなた vì sexe のせいなら、あなたたちはヨガの知識をセックス体験に活用して、実際には素晴らしいことができるわ。"

    # say L1297 lis
    old "Actually if she is interested in you because of the sex, the yoga can make that experience richer than you both can imagine, she won't ever let you go."
    new "実際に、もし彼女がセックスに興味があるなら、ヨガを活用することでその体験はあなたたちが想像する以上に豊かになるわ。彼女は絶対にあなたを手放さないよ。"

    # say L1298 lis
    old "[pla], I need you to get ready, tomorrow you will have the most important lesson of your life, I'll wait for you, I will get ready too, to teach you very well."
    new "[pla]、準備してね。明日は君の人生で最も重要なレッスンになるから。待ってるよ、私も準備するから、ちゃんと教えてあげるから。"

    # say L1299 pla
    old "Hmm... O- ok?"
    new "うーん… オ、オッケー？"

    # say L1302 pla
    old "(I don't get it, but I feel better to knowing she is not as mad as I thought she would be.)"
    new "分かんないけど、リスが思ってたほど怒ってないのは少し安心したな。"

    # say L1320 lis
    old "Hi, I am glad you came."
    new "こんにちは、来てくれて嬉しいわ。"

    # say L1321 pla
    old "Hello, thanks for this new opportunity."
    new "こんにちは、新しいチャンスをくれてありがとう。"

    # say L1322 lis
    old "I didn't mean to be mad at you yesterday, it's just that... This is very important for me,  this is my destiny..."
    new "昨日は怒ってたわけじゃなくて、ただ… これって私にとってすごく大切で、私の運命みたいなの…"

    # say L1323 pla
    old "I... Understand..."
    new "俺… 分かるよ…"

    # say L1324 lis
    old "That's not important... Not anymore, it was a new opportunity, the universe showed me there are different ways to reach the goal I am pursuing."
    new "それはもう重要じゃないの... それよりも新しいチャンスが訪れたの、宇宙は私に目標を達成するための別の道があることを教えてくれたの。"

    # say L1325 lis
    old "Let's go to the room."
    new "部屋に行こう。"

    # say L1334 lis
    old "You see, Yoga is like a language, it helps you to understand the world and its people, we are all energy and love, that is why we need to balance our spirit so we can merge..."
    new "ヨガは言葉のようなもので、世界と人々を理解する手助けをするの。私たちはすべてエネルギーと愛でできているから、精神のバランスを取って融合することが必要なんだよ。"

    # say L1335 lis
    old "That's why it is not weird that you can connect with another person so easily, that your bodies want to share their energies and eventually become one..."
    new "だから、他の人と簡単に繋がることができ、体がエネルギーを共有し、最終的に一つになることが不思議じゃないのよ。"

    # say L1337 lis
    old "I meant what I told you, you started the process, you should apply it on every activities you perform in your life... Even if it's sex...."
    new "私が言ったことは本気よ、あなたがそのプロセスを始めたのだから、人生で行うすべての活動にそれを適用すべきだわ… セックスだって例外じゃないわ…"

    # say L1338 lis
    old "That's why I decided to prepare this lesson, it's really important because this way you will realize how everything is connected by energies."
    new "だからこそ、このレッスンを準備したの。これが本当に重要なの、エネルギーがすべてをつなげていることに気づけるから。"

    # say L1339 lis
    old "You see, if you do some research you will find a very big part of yoga focuses on postures, you can find them according to your body type, the benefits it can give..."
    new "あなたが研究すれば、ヨガの大部分はポーズに焦点を当てていることに気づくでしょう。体のタイプに合わせて選べるし、その効果もわかるはずよ。"

    # say L1340 lis
    old "I have a complete library if you want, but if I asked you 'what is sex about' what would you say?"
    new "もし欲しいなら私の図書館を見せてあげるけど、もし「セックスって何？」って聞いたらどう答える？"

    # say L1341 pla
    old "I think... Positions?"
    new "俺は……ポジションかな？"

    # say L1342 lis
    old "That's what everyone gets wrong... sex is bigger than the position you choose, as is Yoga, bigger than a posture to meditate or meditation its itself."
    new "それはみんなが間違えるところなんだよね… 性行為は選んだ体位よりももっと大きなもので、ヨガだって瞑想の姿勢や瞑想自体よりも大きなものなんだ。"

    # say L1343 lis
    old "However both have that in common, the posture, so this is how you are going to apply all the yoga knowledge you have on this important activity..."
    new "しかし、両方とも姿勢という共通点があるから、ここで君が持っているヨガの知識をこの重要な活動にどう応用するかってことだね。"

    # say L1344 lis
    old "Let's start."
    new "始めましょう。"

    # say L1348 pla
    old "Wait, what are you doing?"
    new "待て、何やってるんだ？"

    # say L1349 lis
    old "What do you think I'm doing? We are here to learn about Yoga and sex, to see how they are meant to be... So you should get naked too..."
    new "何だと思ってるの？ヨガとセックスについて学ぶためにここにいるんだから… だから君も裸になるべきだよ…"

    # say L1350 pla
    old "... Alright."
    new "... 分かった。"

    # say L1355 lis
    old "Now, let's start properly. I will lie down but I need you to get on your knees and hold my legs... Please relax yourself so you can feel it too."
    new "では、ちゃんとして始めましょう。私は横になりますが、あなたは膝をついて私の足を持ち上げてください… リラックスして、感じてみてください。"

    # say L1366 lis
    old "Excellent, this is very interesting position, Do you like it?"
    new "この体位はとても興味深いわね、好き？"

    # say L1367 pla
    old "... Yes."
    new "うん"

    # say L1368 lis
    old "This is a very intimate way to share your energy, as you could see, it was quite demanding but very rewarding."
    new "これはとても密接なエネルギーの分け合い方だわ、見た通りかなり要求されるけど、とても報われるわ。"

    # say L1369 lis
    old "So, let's start, move your hips and let me suck your penis."
    new "それじゃ、始めよう。腰を動かして、私の口にあなたのペニスを入れて。"

    # say L1370 pla
    old "(Oh god, yes!)"
    new "ああ神様、そうだ！"

    # say L1372 lis
    old "I know, maybe this position is not going to be the very first option to propose, but you will estimate the proper moment to help a client..."
    new "この体位は最初の選択肢としては少し意外かもしれないけど、適切なタイミングでクライアントを助けるのに役立つわ..."

    # say L1373 lis
    old "I hope you can start to tell apart sex and a real connection with a person thru Yoga?"
    new "ヨガを通じて、セックスと本当のつながりの違いを感じ取れるようになってほしいの"

    # say L1387 lis
    old "Do realize how much energy you let out by using the proper technique? I mean using these yoga positions in some sexual practices?"
    new "正しいテクニックを使うことでどれだけエネルギーを放出できるか気づいた？ つまりこれらのヨガのポジションを性的な実践に使うってことだけど。"

    # say L1389 lis
    old "I'm glad you can realize how different it is."
    new "あなたがその違いに気づいてくれて嬉しいわ。"

    # say L1390 lis
    old "Now, let's try another option, this can be easier for any of your customers but a bit more demanding for you, however I know you can do it."
    new "では、今度は別のオプションを試してみましょう。これならお客様には楽ですが、あなたには少し負担がかかるかもしれません。でも、あなたならできると思いますよ。"

    # say L1392 lis
    old "This position implies a lot more effort on your end, even though your partner may be experienced, almost the other person's weight will rely on your body."
    new "この体位は、パートナーが経験豊富でも、あなたの身体に相手の体重のほとんどがかかり、かなりの努力が必要になるわ。"

    # say L1393 lis
    old "There are different conditions that can make it easier or not, however I think, Anastasia, will need more of your assistance because of her height."
    new "異なる条件によっては楽になることもあるけど、アナスタシアの場合、身長が高いためあなたからのサポートが必要になると思う。"

    # say L1394 lis
    old "This time, I will hold my right leg up, and support a bit on my arms, I will need you to help me keep my balance and also to guide the entire movement, follow your intuition."
    new "今回は右足を上げて腕で少し支えるから、バランスを取る手伝いと全体の動きを導いてくれたらいいな、直感に任せて。"

    # say L1407 lis
    old "Wow, that was quite good, I'm exhausting, how did you feel?"
    new "わぁ、それなかなか良かったわ、疲れたけど、あなたはどう感じた？"

    # say L1408 pla
    old "It was... Quite interesting."
    new "それは…なかなか面白かったな。"

    # say L1409 lis
    old "Right? I felt so much of me and you at the same time, it was like embracing life, I can see your progress, how calm you can perform and still communicate."
    new "そうよね？ 同時に私たち二人を感じられて、まるで人生を抱きしめたみたいだったわ。あなたの成長が見えて、落ち着いていながらもコミュニケーションが取れるのがすごいと思ったの。"

    # say L1410 lis
    old "The tantric massages gave you an impressive control over your chakras, you looked more than focused."
    new "タントラマッサージでチャクラをうまくコントロールできるようになったね、すごく集中力があるわ。"

    # say L1411 lis
    old "Remember this is a training, from now on, you must use these positions, actually, try it in the next session, do it at the end of the session you have been doing."
    new "これは訓練だからね、これからはこれらの体位を使って、次のセッションで実際に試してみて、セッションの最後にやってみよう。"

    # say L1412 lis
    old "Try to introduce it carefully so she can receive it positively, and the results can be more productive."
    new "慎重に導入して、彼女が前向きに受け入れられるようにしてね。そうすれば結果もより効果的になるわ。"

    # say L1413 pla
    old "(Is she really asking me to do that)"
    new "彼女は本気でそんなこと言ってるのか？"

    # say L1415 lis
    old "Yes, That way she will not only enjoy your lesson but also learn what she wanted to."
    new "そうすれば、彼女はあなたのレッスンを楽しむだけでなく、自分が学びたいと思っていたことも学べるわ。"

    # say L1417 lis
    old "Please, be on time tomorrow!"
    new "明日、時間に遅れないでくださいね。"

    # say L1418 pla
    old "Not a problem! See you then."
    new "問題ないよ！じゃあ、またね。"

    # say L1439 ana
    old "So, how are you today?"
    new "今日怎么样？改为你今天怎么样？"

    # say L1440 lis
    old "I am very well, thanks for asking, it's nice to see you again."
    new "元気ですよ、また会えて嬉しいです。"

    # say L1441 ana
    old "Thank you, I came today with my best mood..."
    new "ありがとう、今日は最高の気分で来たの..."

    # say L1442 lis
    old "That's terrific, I am sure today's lesson will change your perception of the previous ones, we planned a very great session that you will find useful."
    new "それは素晴らしいですね、今日の授業でこれまでのレッスンの見方が変わること間違いなしよ。とても役立つ内容を用意したから。"

    # say L1448 ana
    old "Ok, thank you... Every day I can learn something new... Hi [pla], nice to see you again."
    new "はい、ありがとうございます… 毎日新しいことを学べるから… こんにちは[pla]、また会えて嬉しいです。"

    # say L1451 pla
    old "Hello guys..."
    new "こんにちは、みんな..."

    # say L1454 lis
    old "Please, enjoy yourselves... The yoga room is already prepared for your session."
    new "どうぞ、お楽しみください… ヨガルームはすでにセッションの準備が完了していますよ。"

    # say L1455 pla
    old "Thank you Lisa, Anastasia please come in."
    new "ありがとう、Lisa。Anastasia、入ってきてくれ。"

    # say L1456 ana
    old "Sure, I can't wait."
    new "もちろん、楽しみにしてるわ。"

    # say L1464 ana
    old "I need to confess that I did not study for today's lesson, so... Professor are you going to punish me?"
    new "今日の授業のためには何も準備してこなかったのだけど… 先生、私をどうするの？"

    # say L1465 pla
    old "... I- (I should be confident, that's what Lisa expect from me.)"
    new "俺が罰を与えるかどうかは、君の態度次第だよ、アナ。"

    # say L1466 ana
    old "What about if we just improvise?"
    new "即興でやってみるってどう？"

    # say L1480 ana
    old "Are you going to fuck me harder today?"
    new "今日こそはもっと激しく私を犯してよね？"

    # say L1487 ana
    old "Oh yeah baby, Fuck me like that again."
    new "オーよベイビー、またそうやって👉👌"

    # say L1496 pla
    old "There is something new I want you to try."
    new "新しいこと試してほしいんだ"

    # say L1497 ana
    old "Wow, I can see you don't need to rest young man, I am anxious to try it even if I feel a bit tired."
    new "若い人、休む必要ないのね。ちょっと疲れてるけど、試してみたくなるわ。"

    # say L1498 pla
    old "We still have a lot to learn."
    new "まだ学ぶことがあるな。"

    # say L1499 ana
    old "Sign me up."
    new "私、やりたいわ。"

    # say L1500 pla
    old "I will need you to relax your body so I can take your legs, I will hold them with my hands, but I will need you to hold me firmly with your hands."
    new "体をリラックスさせて足を広げて俺に預けてくれ。手で俺をしっかりとつかんでくれ。"

    # say L1501 ana
    old "I will do anything you ask of me."
    new "何でもしますよ。"

    # say L1502 pla
    old "Alright... Let's start."
    new "よし…始めるぞ。"

    # say L1509 ana
    old "Oh, wow you are getting creative!"
    new "あら、すごい発想ね！"

    # say L1519 ana
    old "Oh my god, that was unbelievable, I am so astonished! Is this the exercise Lisa mentioned you were preparing lately?"
    new "Oh my god、それって信じられない、本当に驚いたわ！これがリサが最近準備している運動のこと？"

    # say L1521 ana
    old "So does she know? Wow, You guys don't stop surprising me."
    new "そうなのか、彼女も知ってるの？すごいね、あなたたちの驚かせ方は尽きないわ。"

    # say L1523 ana
    old "Let me ask you something, because this has blown my mind... Does Lisa offer these lessons with more than one instructor? I mean a team session with her would be pretty interesting..."
    new "ねえ、聞いていい？これで頭がいっぱいになっちゃったんだけど… リサは複数のインストラクターとレッスンを提供してるの？つまり、彼女とのグループセッションってあり得るわけ？"

    # say L1524 pla
    old "I- I'm not sure, I think I will need to ask her."
    new "うーん、まだよくわかんないな。聞いてみるか。"

    # say L1525 ana
    old "Alright, I have to go, let's get dressed."
    new "じゃあ、行ってきましょ。服を着よう。"

    # say L1540 lis
    old "So guys, how was the session today?"
    new "みんな、今日のセッションどうだった？"

    # say L1542 ana
    old "Lisa, I think this has been the most incredible Yoga experience I have had in my entire life. I love your work, and of course your... Teamwork."
    new "リサ、今日は本当に素晴らしいヨガ体験だったわ。私の人生で一番かもしれない。あなたの指導が大好きで、もちろんあなたの... 協力もね。"

    # say L1543 ana
    old "Some friends are very interested in coming, I have persuaded them because of my experience, so hope you are ready for them."
    new "友達がとても興味を持っていて、私の経験から説得して連れてくることにしたの。準備できてるといいな。"

    # say L1544 lis
    old "I appreciate you sharing your experience with your friends. I am sure you will learn more, do not doubt we will do our best to surprise you and your friends every time."
    new "あなたの経験を友達とシェアしてくれてありがとう。もっと学ぶこと間違いなし、私たちが毎回あなたと友達を驚かせることを約束するからね。"

    # say L1545 ana
    old "Love you guys, see you next time."
    new "愛してるわ、またね。"

    # say L1546 lis
    old "Sure, I have already scheduled your next appointment so I will be calling you."
    new "もちろん、次回の予約はすでに取ってあるから、また連絡するね。"

    # say L1547 ana
    old "Perfect, I will look forward to."
    new "完璧、次も楽しみにしてる。"

    # say L1548 lis
    old "Nice to have you here, bye bye!"
    new "また来てね、バイバイ！"

    # say L1549 ana
    old "See you next time."
    new "またね。"

    # say L1559 lis
    old "Did you feel it?"
    new "感じた？"

    # say L1560 pla
    old "Yes... I- I did."
    new "うん… 感じたよ。"

    # say L1561 lis
    old "This is what we need to share with others, once you understand the language of the universe, you can translate to others, I am very proud that you are improving."
    new "これは他の人と分かち合うべきものよ、宇宙の言葉を理解すれば、それを他の人に伝えられるわ。あなたが上達していることにとても誇りに思っているの。"

    # say L1563 lis
    old "I know you are quite good however remember this is a process... we need to continue working... So... we need to continue working on your chakra."
    new "あなたはかなり上手だけど、これは過程だからね… 練習を続けることが必要だよ… だから… あなたのチャクラの調整を続けていく必要があるんだ。"

    # say L1565 lis
    old "I'll be waiting for you tomorrow night, those tantric sessions need to continue, as you saw today, you will become a very great Yoga instructor, so don't stop."
    new "明日の夜、待ってるわ。タントラのセッションは続けないと、今日見た通り、あなたは素晴らしいヨガインストラクターになれるから、諦めないで。"

    # say L1587 lis
    old "Hello, I was waiting for you."
    new "こんにちは、待ってたわ。"

    # say L1588 pla
    old "Hi Lisa..."
    new "こんにちは、Lisa..."

    # say L1589 lis
    old "I was very excited because with this session we concluded this chapter with your chakras, remember the process is to find the perfect balance is not something we can call finished."
    new "このセッションであなたのチャクラの章を締めくくることができて、とても興奮していました。バランスを見つけるプロセスは、まだ完了したとは言えないのを覚えておいてね。"

    # say L1590 pla
    old "I understand, I will continue working on it."
    new "分かってる、これからも続けていくよ。"

    # say L1591 lis
    old "Actually, I wanted you to know that we can still work again on this, since this is a very good exercise for us both you can count on me to help you."
    new "実は、これについてまた一緒に練習できるってことを知って欲しかったの。このエクササイズは私たちにとってとても良いものだから、手伝うのは当然よ。"

    # say L1592 pla
    old "I really... Appreciate everything you do for me."
    new "君がやってくれること、全部本当に感謝してるよ。"

    # say L1593 lis
    old "It's my way to say thank you, I want to thank you for your hard work."
    new "これは私の感謝の表現よ、あなたの頑張りに感謝したいの。"

    # say L1594 lis
    old "Let's go to the room to start the session..."
    new "部屋に行こう、セッションを始めるね…"

    # say L1602 lis
    old "Regular sex is about exploring and feeling pleasure desperately... The tantric experience is different, it's about the energy and sensations you can have with your partner."
    new "通常のセックスは快楽を必死に探求することだけど… タントラ体験は違うの、パートナーとのエネルギーと感覚を感じることよ。"

    # say L1603 lis
    old "Sex consists of penetration and cumming, that takes out part of the connection, tantric sex otherwise means eye contacting, touching, breathing, to hear the noises."
    new "セックスは挿入と射精で、その部分がつながりを奪うの。タントリックセックスはそれとは違い、目を合わせたり、触れ合ったり、呼吸を合わせたり、相手の音を感じることよ。"

    # say L1605 lis
    old "That is why we start with the massage, so we can open our senses, open ourselves to the other."
    new "それが私たちがマッサージから始める理由、そうすることで五感を開き、相手に開くことができるから。"

    # say L1606 lis
    old "Please lie down to start the massage..."
    new "寝て始めるマッサージのために..."

    # say L1621 lis
    old "We will need to work harder today so let me start with some lubrication, the universe it self is all about love, so nothing better than kisses to start, to help you expel the negative chakra."
    new "今日はもっと頑張らないとね、だからまずは潤滑剤を使って、宇宙は愛で成り立っているんだから、キスから始めてネガティブなチャクラを排出するのを手伝うのがいいわ。"

    # say L1623 lis
    old "Just relax, remember to release the tension so you can do the exercise effectively."
    new "リラックスして、緊張を解きましょう。そうすればエクササイズが効果的にできるよ。"

    # say L1639 pla
    old "That was great... I felt really good... Are we done?"
    new "それが良かった… 全身がほぐれた感じがした… 終わったのか？"

    # say L1640 lis
    old "Of course not, since the main purpose is to finally connect deeply with yourself, there is a lot more to learn. I have a very special exercise for you to conclude this chakra training."
    new "もちろんそんなことはないわ。自分と深くつながることが最終目的だから、もっと学ぶことがあるの。特別なエクササイズを用意してるから、これでチャクラトレーニングを締めくくろうね。"

    # say L1641 lis
    old "I will need you to lie down again so I can do the movements needed."
    new "また横になって、必要な動きをさせてね。"

    # say L1642 lis
    old "Let me show you how it works..."
    new "私がどうやってするのか見せてあげるからね..."

    # say L1648 lis
    old "Feel all inside me."
    new "中全部感じてね。"

    # say L1649 lis
    old "I'm feeling all of you."
    new "あなた全部感じてるわ。"

    # say L1659 lis
    old "To be honest, I feel you're shining lately, these exercises have brought you wellness to your spirit and I can perceive it, I hope you can see the changes too."
    new "正直、最近あなたがすごく輝いて見えるの。このエクササイズで心が健康になったのが伝わるの。あなたもその変化を感じているといいな。"

    # say L1660 pla
    old "For sure, I think I feel much better now."
    new "確かに、最近は調子良くなってきた感じだ。"

    # say L1661 lis
    old "Remember that it is really important to continue this training, if you want to reach out to me any night, so we can work on your chakra training..."
    new "このトレーニングを続けてることが本当に重要よ、夜に連絡してきて、チャクラのトレーニングを一緒にしようね..."

    # say L1662 lis
    old "You know it helps you to stay more balanced and focused in your chakras... I'll have nights free so we can repeat the tantric ritual anytime you need."
    new "あなたがチャクラをよりバランスよく保つのに役立つってことは知ってるでしょ… 私は夜空いているから、いつでもタントリックな儀式を繰り返せるわ。"

    # say L1663 lis
    old "I think, now that you have balanced your energies, and your chakra muladhara has been controlled, you can even lead the tantric sessions with some of our customers."
    new "エネルギーを整え、ムラダーラチャクラもコントロールできた今なら、お客様とのタントリックセッションをリードすることもできると思うわ。"

    # say L1664 lis
    old "I'm sure the universe has great things for you, you already know you can count on me."
    new "宇宙があなたに素晴らしいことをもたらすことは間違いないわ、私を頼りにできることはもうわかってるでしょう。"

    # say L1665 pla
    old "I appreciate that."
    new "それは Appreciate じゃないかな。感謝してる。"

    # say L1666 lis
    old "Don’t forget you can keep up the yoga sessions with Anastasia in the afternoons, whenever you’ve got time!"
    new "午後の時間にアナスタシアとヨガのセッションを続けることも忘れないで。時間があればね！"

    # say L1667 lis
    old "Your lessons have evolved now that you are better balanced and applying your yoga knowledge to the sex connection..."
    new "あなたのレッスンは、バランスが良くなり、ヨガの知識をセックスとのつながりに活かせるようになったことで進化したね。"

    # say L1668 lis
    old "If you feel you need to review the previous trainings we have done, any morning I'll be working on that so you prepare better always to help your customers."
    new "もし前のトレーニングを復習したいなら、どの朝でも私がそれを手伝うから、いつもお客様をよりよくサポートできるように準備してね。"

    # say L1670 lis
    old "I am happy to hear that... We need to rest now, have a good night [pla]."
    new "うれしいですね… 今夜はゆっくり休んで、おやすみなさい [pla]。"

    # say L1671 pla
    old "Ok, good night Lisa!"
    new "分かった、おやすみ麗さ！"

    # say L1695 pla
    old "Hey Lisa! It's so nice to see you, how are you?"
    new "hey Lisa！会えて嬉しいよ、調子はどう？"

    # say L1696 lis
    old "Hi dear! I'm very good, and you?"
    new "こんにちは亲爱的！元気よ、あなたは？"

    # say L1697 pla
    old "I'm not so fine, we're having some financial issues..."
    new "俺はそんなに元気じゃないんだ、ちょっと金銭的な問題があってさ..."

    # say L1698 lis
    old "Really? I'm so sorry... How could I help you?"
    new "ほんと？ それなら本当にごめんなさい… どう手伝ったらいいかしら？"

    # say L1699 pla
    old "Actually, that's why I'm here. I thought maybe you needed someone to help you out with your business, I really need to find a job."
    new "実はそれが理由で来たんだ。君のビジネスを手伝える人が必要かもしれないと思って、俺も仕事を見つけなきゃならないから。"

    # say L1701 pla
    old "I could work on anything... Doesn't matter what it's."
    new "何でも手伝うよ… どんな仕事でもいい。"

    # say L1702 lis
    old "Sadly, I can't hire you. I don't really need help right now."
    new "残念だけど、今私にはあなたを雇う余地がないの。今のところ特に手伝いは必要ないから。"

    # say L1703 lis
    old "I haven't had much sales lately... I'm barely doing some Yoga classes for a few people."
    new "最近は売上が芳しくなくて……数人のためにヨガのクラスをやってるだけよ。"

    # say L1704 lis
    old "However, I'm planning on improving my sales by implementing some new marketing strategies and I might need you sometime soon."
    new "でも、新しいマーケティング戦略を導入して売上を上げようと思っているの。近いうちにあなたが必要になるかもしれないわ。"

    # say L1706 lis
    old "But not really right now..."
    new "でも、今すぐはまだ..."

    # say L1708 lis
    old "Sorry about that..."
    new "すみませんね、それについて…"

    # say L1709 pla
    old "No, it's ok. Not your fault, I gotta keep looking... I guess."
    new "大丈夫、気にしなくていい。君のせいじゃない、俺がもっと探すだけだな。"

    # say L1710 lis
    old "You'll find something good."
    new "何か良いものが見つかるわよ。"

    # say L1711 pla
    old "Hmm, I hope. Thanks anyway, it's always nice to see you."
    new "うん、そう願うよ。でもありがとう、君に会えたのは良かった。"

    # say L1712 lis
    old "I say the same... I'm glad you came to visit."
    new "同じことを言うわ……来てくれて嬉しいよ。"

    # say L1714 pla
    old "I should go, I really have to find a job, see you Lisa."
    new "行かなきゃ、仕事探すからな、またね Lisa。"

    # say L1737 pla
    old "Hmm, this is weird, she should be here at this time of day."
    new "Hmm、変だな、この時間にはここにいなきゃならないのに。"

    # say L1738 pla
    old "Lisa! Are you here?"
    new "リサ！いるの？"

    # say L1739 pla
    old "So odd, where is she?"
    new "不思議だな、どこにいるんだ？"

    # say L1754 pla
    old "What is that noise? I guess she's in the yoga room."
    new "何の音だ？多分ヨガルームにいるんだろ。"

    # say L1766 pla
    old "{i}(I- I wasn't expecting that.){/i}"
    new "{i}(ええと、そんな予想外でした。){/i}"

    # say L1767 pla
    old "{i}(That's- Umm... Quite an interesting position.){/i}"
    new "{i}(そのー うーん… 面白い体勢だな。){/i}"

    # say L1783 lis
    old "Oh, [pla], I didn't realize you were around."
    new "Oh、[pla]、周りにいたことには気づかなかったの。"

    # say L1784 lis
    old "I'm sorry for not noticing before."
    new "ごめんなさい、気づかなかったの。"

    # say L1786 pla
    old "I- I'm sorry, Lisa! I- I didn't mean to spy on you."
    new "い- いや、リサ！俺- 俺は君を覗こうと思ってたわけじゃないんだ。"

    # say L1788 lis
    old "It's quite alright, I didn't realize I left the door open."
    new "大丈夫よ、ドアを開けっ放しにしていたことに気づかなかったの。"

    # say L1789 lis
    old "Besides, all I was doing was resonating my Muladhara chakra with the energy of the universe."
    new "それに、私がやってたのはただマルアダラチャクラを宇宙のエネルギーと調和させるだけよ。"

    # say L1790 lis
    old "There's nothing to hide about that. So you don't need to worry about anything."
    new "それについて隠すことは何もないから、心配しなくていいわ。"

    # say L1794 lis
    old "So, what brings you here?"
    new "じゃあ、何の用？"

    # say L1796 pla
    old "Uhmm, w- well, I just wanted to see how you're doing."
    new "うーん、まあ、君の状態を見に来たんだ。"

    # say L1797 pla
    old "You know, to check how everything's going."
    new "まあ、すべてが順調かどうか確認するためにさ。"

    # say L1799 lis
    old "Well, I've been a little stressed, you know, this whole business thing is a little tiring."
    new "まあ、少しストレスを感じていて、このビジネスのことでちょっと疲れてるの。"

    # say L1800 lis
    old "But that's precisely why I was just realigning my energy with the universe."
    new "でも、それが私があいまいとのエネルギーを再調整していた理由なの。"

    # say L1801 lis
    old "After stimulating my Muladhara chakra, I feel like I've been relieved of all stress now."
    new "ムーラダラチャクラを刺激したら、ストレスが全部消えた気がするの。"

    # say L1805 pla
    old "Is it that effective?"
    new "それほど効果があるのか？"

    # say L1806 pla
    old "{i}(I mean, it just looked like she was just jacking off to me.){/i}"
    new "{i}(つまり、彼女はただオナニーしているように見えたってことだな。){/i}"

    # say L1807 lis
    old "Of course it is! The Muladhara chakra is the second of the body and the one that regulates our sacred sexual energy."
    new "もちろんよ！ムラダラチャクラは体の二つ目のチャクラで、私たちの神聖な性的エネルギーを調節するのだから。"

    # say L1808 lis
    old "It may have looked like I was just masturbating, but it's a lot more than that."
    new "もちろんそう見えたかもしれないけど、それ以上なの。"

    # say L1809 lis
    old "The Muladhara regulates our self-esteem."
    new "ムラダラは私たちの自尊心を調節します。"

    # say L1810 lis
    old "By properly stimulating it you can improve your mood because your energy's in line with the rest of the universe."
    new "適切に刺激すれば、あなたの気分が良くなるのは、エネルギーが宇宙全体と調和するからよ。"

    # say L1812 pla
    old "Uh... I- I see."
    new "うーん… 分かったかな。"

    # say L1813 pla
    old "So, this {i}'Proper stimulation'{/i}, is that why you were upside down?"
    new "じゃあ、この{i}「適切な刺激」{/i}って、それが君が逆さまになった理由なのか？"

    # say L1815 lis
    old "Yes, that's right."
    new "うん、そうよ。"

    # say L1816 lis
    old "By taking that position, I was letting my energy flow outwards from my head."
    new "その体勢を取ることで、頭からエネルギーを放出させていたの。"

    # say L1817 lis
    old "And replenishing my Muladhara chakra with positive energy coming from the top."
    new "そして頭から流入するポジティブなエネルギーでムーラダラチャクラを補充していたの。"

    # say L1818 lis
    old "It's tremendously effective [pla], I highly recommend it to you."
    new "それはものすごく効果的だよ [pla]、ぜひ試してみてほしいな。"

    # say L1820 pla
    old "Y- you do?"
    new "君もやってるんだ？"

    # say L1822 lis
    old "Oh yeah, it's somewhat difficult to do."
    new "うん、ちょっと難しそうだけどね。"

    # say L1823 lis
    old "But I'm sure I can guide you towards a path of proper alignment with the universe."
    new "でも、宇宙との調和の道を導く手伝いはできると思う。"

    # say L1825 pla
    old "Uh, I- I guess I'll think about it."
    new "うーん、考えちゃおうかな。"

    # say L1826 lis
    old "Oh, by the way, I was hoping you'd come, seems like the energies drew you here. It's so beautiful when the universe conspires in your favor."
    new "そういえば、あなたが来ると思ってたの。エネルギーがあなたをここに導いたみたいだね。宇宙があなたのために働いてくれるって、本当に美しいよ。"

    # say L1827 pla
    old "Oh, do you need me for something?"
    new "お前が必要か？"

    # say L1828 lis
    old "Yeah, but let me get dressed and comfy. Meet me downstairs and we'll chat for a bit."
    new "うん、でも着替えてからね。下で待ってて、ちょっと話すから。"

    # say L1829 pla
    old "Uh, yeah, sure. I'll be waiting downstairs."
    new "うん、わかった。下で待ってるよ。"

    # say L1840 lis
    old "I'm ready, thanks for waiting. I'm really glad you came today."
    new "準備できました、待っててくれてありがとう。今日来てくれてほんとうにうれしいです。"

    # say L1841 pla
    old "Uh, sure. So, what did you want to talk about?"
    new "うん、そうか。で、何を話したいんだ？"

    # say L1843 lis
    old "Well, you see, I need to ask a favor of you."
    new "実はね、あなたに頼み事があるんです。"

    # say L1845 pla
    old "Really? What is it?"
    new "本当に？何だい？"

    # say L1847 lis
    old "It's about this client that I have, I've been working with her for a while."
    new "そのクライアントのことなんだ、彼女とずっと一緒に働いていたんだけど。"

    # say L1848 lis
    old "I would like you to be her instructor during her next class, instead of me."
    new "次回の授業では、私ではなくあなたが彼女のインストラクターになってほしいの。"

    # say L1850 pla
    old "Oh! Are you busy again? Sure, I'll cover you."
    new "お！また忙しいのか？わかった、代わりにやるよ。"

    # say L1851 lis
    old "No, it's nothing like that. I don't have anything else to do during that session."
    new "いいえ、そうじゃなくて。その時間は何も予定がないんです。"

    # say L1853 pla
    old "So what is it?"
    new "じゃあ、何なんだ？"

    # say L1854 lis
    old "Well, she's come to every appointment without fail, she also does every yoga pose correctly."
    new "まあ、彼女は毎回欠かさず来てるし、ヨガのポーズも全部完璧にできるんだよね。"

    # say L1856 lis
    old "But in spite of that, I would say she's not actually doing well."
    new "でも、その割には彼女は実際には上手くいっていないと思うわ。"

    # say L1857 pla
    old "She isn't?"
    new "そうじゃないの？"

    # say L1859 lis
    old "Yeah, I'm not feeling her energy flowing the way it should."
    new "うん、彼女のエネルギーがちゃんと流れている感じがしないの。"

    # say L1861 lis
    old "It's hard to explain, but even though she's been progressing in terms of flexibility and poses."
    new "説明するのが難しいんだけど、彼女は柔軟性やポーズの面では進歩しているのに。"

    # say L1863 lis
    old "I still feel like she needs something else in order to thrive."
    new "それでも、彼女が本当に伸びるために何か他のものが欲しくなるの。"

    # say L1864 pla
    old "And you think that {i}'something else'{/i} has to do with me?"
    new "そして君はその {i}'何か'{/i} が俺に関係あるって思うのか？"

    # say L1865 lis
    old "Yes, that's correct."
    new "うん、そう思ってるの。"

    # say L1867 lis
    old "I think that maybe your masculine energy will be able to unearth whatever's stopping her from progressing."
    new "あなたの男性のエネルギーが、彼女が前進できない原因を掘り起こせるかもしれないと思ってるの。"

    # say L1869 lis
    old "After all, you already helped Anastasia in a very effective way."
    new "毕竟，你已经有效地帮助过安娜斯塔西娅了。"

    # say L1870 lis
    old "So I thought that it would be worth it to give it a go with this girl as well."
    new "そう思って、この子にも試してみようと思ったの。"

    # say L1872 pla
    old "Uh, well, if you say so, sure."
    new "うーん、まあ、君がそう言うなら、いいけど。"

    # say L1873 pla
    old "I'll be happy to help you."
    new "喜んで手伝うよ。"

    # say L1875 lis
    old "That's great! I'll let her know about it and I'll see you in the afternoon then."
    new "それは良かった！彼女に伝えて、午後にでも会おうね。"

    # say L1877 pla
    old "Sure, no problem, I'll see you later."
    new "もちろん、問題ないよ、後でね。"

    # say L1902 pla
    old "Hi Lisa, I came for the class you told me about-"
    new "嗨、リサ、君が教えてくれた授業に来たんだ-"

    # say L1906 pla
    old "{i}(Is that Angelina? What's she doing here?){/i}"
    new "{i}(アンジェリナか？彼女がここにいるなんて…){/i}"

    # say L1907 ang
    old "{i}(Oh my God! That's [pla]! W- what is he doing here?!){/i}"
    new "{i}(ああっ！それは[pla]じゃない！ W- どうしてここにいるの？！){/i}"

    # say L1908 lis
    old "Hello [pla], you arrived just in time, this is Angelina, the client that you'll be helping today."
    new "こんにちは [pla]、ちょうど良かったわ。これはアンジェリナさんで、今日あなたがお手伝いするクライアントよ。"

    # say L1910 pla
    old "Uh, yeah... Hi A- Angelina, nice to meet you."
    new "うーん、そうだな… こんにちは、アングリナ、はじめまして。"

    # say L1912 ang
    old "Uh, yeah, hi to you too... Nice meeting you."
    new "うん、こんにちは…会えて嬉しいです。"

    # say L1913 lis
    old "So, as I told you a moment ago, [pla] will be taking over your class today."
    new "さっきも言ったけど、[pla] が今日あなたのクラスを担当することになったの。"

    # say L1915 lis
    old "Uhh, Angelina?"
    new "うーん、エンジェリナ？"

    # say L1917 ang
    old "Y- yes, of course. Please, continue."
    new "う、うん、もちろん。どうぞ続きを。"

    # say L1919 lis
    old "Okay, as I was saying earlier, he has been helping me recently by giving classes to some of my clients."
    new "先ほど言っていた通り、最近は彼が私のクライアントたちにレッスンを教えてくれてるの。"

    # say L1921 lis
    old "You don't have to worry about anything, he's very knowledgeable and he has a spectacular energy."
    new "心配しなくていいわ、彼はとても知識が豊富で、エネルギーも素晴らしいの。"

    # say L1924 lis
    old "So, I'm sure he'll be capable of helping you in the way you need."
    new "だから、きっと君が必要とするように手伝ってくれるはずよ。"

    # say L1926 ang
    old "I- I see, well... I'll be in his care then."
    new "なるほど、そうね… なら、任せることにするわ。"

    # say L1928 lis
    old "Let's go to the yoga studio so you two can start your class."
    new "ヨガスタジオに行こう、そうすれば君たちのクラスを始められるから。"

    # say L1938 lis
    old "I'll leave you two alone so you can start with the session, I hope you enjoy it, Angelina."
    new "二人きりにしてあげるから、レッスン始めてね、エンジェリナ。楽しんでね。"

    # say L1939 ang
    old "W- well, thank you."
    new "あ、ありがとう。"

    # say L1941 pla
    old "We'll see you later."
    new "後でな"

    # say L1950 pla
    old "Uhh, alright, so..."
    new "うーん、そうか、だから…"

    # say L1956 pla
    old "I- I guess we better get started with the class."
    new "うーん、じゃあクラスを始めるか。"

    # say L1958 ang
    old "Wait a minute."
    new "ちょっと待って。"

    # say L1960 ang
    old "Can you please tell me what you're doing here? I thought you were supposed to be Dr. Johnson's assistant."
    new "あなたがここにいる理由を教えてくれますか？ ドクター・ジョンソンの助手だと聞いていたけど。"

    # say L1961 ang
    old "How come I'm running into you here? And you're teaching yoga?"
    new "どうしてここであなたと会うの？それにヨガの先生やってるの？"

    # say L1963 ang
    old "What's next? Will you be my waiter if I go to a restaurant?"
    new "次は何？ レストランに行くなら、私のウェイターになってくれるの？"

    # say L1964 pla
    old "Hmm, I can see why this would surprise you, but believe me, it was a surprise for me too."
    new "うーん、驚いてるのもわかるけど、俺も驚いたんだ。"

    # say L1966 pla
    old "But it's nothing like what you're imagining."
    new "でも君が想像してるようなものじゃないよ。"

    # say L1968 pla
    old "I'm related to Lisa, she's my [mom2Rel]'s younger sister."
    new "Lisaは俺の[mom2Rel]の妹だ。"

    # say L1970 pla
    old "And since she started the studio I've been giving her a hand with some particular clients."
    new "そして彼女がスタジオを始めてから、特定のクライアントの手伝いをしてるんだ。"

    # say L1971 pla
    old "But I swear that I didn't know that you were the client I was supposed to help with the class today."
    new "でも本当にな、今日のクラスで手伝うはずの客が君だとは知らなかったんだ。"

    # say L1973 pla
    old "She just came to my house asking me for a hand with a client, and that's it."
    new "彼女が家に来て、クライアントの手伝いを頼んだだけさ。"

    # say L1975 ang
    old "I don't know."
    new "知らないわ。"

    # say L1977 ang
    old "It's just so weird that I keep running into you."
    new "いつも君と会うのが不思議だな。"

    # say L1978 pla
    old "I know, trust me, it's very weird for me too."
    new "知ってるよ、信じてくれ、俺にとってもめちゃくちゃ不思議なんだ。"

    # say L1979 pla
    old "But if you let me, I'll be more than happy to help you with the class."
    new "でも君が許してくれれば、授業の手伝いを喜んでやるよ。"

    # say L1981 ang
    old "I guess that if Lisa says it's alright, I have no reason to not believe what you're saying."
    new "リサがいいって言うなら、あなたが言ってることを疑う理由もないわね。"

    # say L1982 ang
    old "So I guess I'll do it."
    new "じゃあ、やってみるわ。"

    # say L1984 pla
    old "Great! And hey, how's Roonie doing?"
    new "オイオイ！それに、ルーニーは元気にしてるか？"

    # say L1986 pla
    old "I bet he must be happy about the baby."
    new "きっと赤ちゃんのことなら喜んでるだろうな。"

    # say L1987 ang
    old "Uhm, yeah... He's doing alright."
    new "うーん、そうね… 元気みたいです。"

    # say L1988 pla
    old "I see, good, good. A- and how's the pregnancy been treating you?"
    new "なるほど、それは良い、良い。で、妊娠はどんな感じ？"

    # say L1990 ang
    old "I've been alright... I think"
    new "私は大丈夫だよ…多分"

    # say L1991 ang
    old "The doctor told me that I should try to stay active during my pregnancy."
    new "先生は妊娠中もできるだけ活動的でいるのが良いって教えてくれたの。"

    # say L1992 ang
    old "That's why I'm taking yoga lessons, I was told it's one of the best things that you could do as a pregnant woman."
    new "それが理由でヨガのレッスンを受けてるの。妊娠中の女性にとって最高の運動の一つだって聞いたから。"

    # say L1993 pla
    old "Oh yeah?"
    new "へえ、本当？"

    # say L1995 ang
    old "Yes, it's supposed to improve sleep by reducing stress, and also helping relieve anxiety."
    new "うん、ストレスを減らして睡眠を改善するらしいし、不安を和らげるのにも役立つって言うの。"

    # say L1996 ang
    old "And apparently it helps to strengthen the muscles needed for childbirth."
    new "そして、出産に必要な筋肉を鍛えるのにも効果的らしいわ。"

    # say L1997 ang
    old "And the flexibility of course."
    new "そしてもちろん柔軟性もね。"

    # say L1998 ang
    old "So that's why I'm doing yoga."
    new "そうか、だからヨガをしているのね。"

    # say L1999 pla
    old "I see, that all makes a lot of sense."
    new "なるほど、それなら納得できるな。"

    # say L2007 pla
    old "Uhmm, w- well, what do you say we get started with the session."
    new "うーん、えっと、じゃあセッション始めるか。"

    # say L2011 pla
    old "Alright, let's start with the first asana."
    new "よし、最初のアーサナから始めよう。"

    # say L2012 pla
    old "This first one's called Setu Bandha."
    new "この最初のポーズはセトバンドハって言うんだ。"

    # say L2013 ang
    old "Ok? Is it too hard?"
    new "いいの？難しすぎない？"

    # say L2014 ang
    old "I mean, I ask because I'm pregnant."
    new "聞いているのは妊娠しているからよ。"

    # say L2016 pla
    old "Nah, it's not too hard."
    new "大丈夫、そんなに難しくないよ。"

    # say L2017 pla
    old "Sure it can be a little challenging."
    new "もちろん、少しは大変かもしれないけど。"

    # say L2018 pla
    old "But don't worry, I'll be there helping you during it."
    new "でも心配しなくていい、君の手伝いをするから。"

    # say L2020 ang
    old "Ok, how do I do it?"
    new "じゃあ、どうやってやるの？"

    # say L2022 pla
    old "It's simple, just lay on your back with your knees up and your heels towards your butt."
    new "簡単だよ、背中を床に付けて膝を立てて、かかとをお尻の方向に向けて。"

    # say L2023 pla
    old "And then just push through the soles of your feet and lift your hips up, like making an arch."
    new "そして足の裏で力を入れて腰を上げて、アーチを作る感じだよ。"

    # say L2024 ang
    old "Hmm, ok, I guess I get it."
    new "うん、わかったかな、試してみるね。"

    # say L2030 pla
    old "Yeah, you're doing it well, but you're a little tense through the shoulders."
    new "そうだな、上手くやってるけど肩が少し緊張してるみたいだね。"

    # say L2031 pla
    old "Try to relax a little bit more."
    new "もう少しリラックスしてみて。"

    # say L2032 ang
    old "O- Ok."
    new "うーん、わかった。"

    # say L2039 pla
    old "{i}(Hmm, I see what Lisa was telling me, she's doing the position right.){/i}"
    new "{i}(なるほど、リサが言ってた通りだな、ポジションは合ってるみたいだ。){/i}"

    # say L2040 pla
    old "{i}(But I can see that she's very tense.){/i}"
    new "{i}(でも、彼女がとても緊張しているのが分かるな。){/i}"

    # say L2041 pla
    old "{i}(Maybe we can change to another position and see how she does.){/i}"
    new "{i}(じゃあ、別の体位に変えてみようか。どう思う？){/i}"

    # say L2042 pla
    old "Ok, that's very good, now let's move into the next one."
    new "よし、それじゃ次のポーズに移ろう。"

    # say L2043 ang
    old "O-ok."
    new "おっけい。"

    # say L2051 pla
    old "Alright, that was a good start."
    new "よし、いいスタートだったね。"

    # say L2052 pla
    old "So I guess we can move into the next position."
    new "じゃあ次は次のポジションに移ろうか。"

    # say L2053 pla
    old "This one's called Balasana."
    new "このポーズはバラサナって言うんだ。"

    # say L2054 pla
    old "It's even easier than the previous one, but it's very good to stretch the shoulders and back."
    new "前のポーズよりも簡単だけど、肩と背中を伸ばすにはとてもいいんだ。"

    # say L2055 ang
    old "I see, how do I do it?"
    new "なるほど、どうやってするの？"

    # say L2057 pla
    old "It's simple, you're going to start in a tabletop pose."
    new "簡単だよ、まずはテーブルポーズから始めて。"

    # say L2058 pla
    old "From there, just move your hips back and down while you leave your hands where they are."
    new "そこから、手はそのままで腰を後ろへ下げるだけだ。"

    # say L2059 pla
    old "That will give you a proper stretch through your shoulders and back."
    new "その体勢で肩と背中をよく伸ばせるよ。"

    # say L2061 ang
    old "Hmm, ok, I think I can do that."
    new "うん、できそうかな。"

    # say L2063 pla
    old "Yeah, and I'll be there to help you, so don't worry."
    new "大丈夫、俺が手伝うから心配しなくていいよ。"

    # say L2065 ang
    old "Ok, let's try it."
    new "じゃあ、やってみるね。"

    # say L2068 ang
    old "Am I doing this right?"
    new "これでいいのかな？"

    # say L2071 pla
    old "Yeah, that's alright, but try to let go a little bit more."
    new "うん、そうだけど、もう少しリラックスしてみて。"

    # say L2072 ang
    old "A-alright."
    new "あ、ああ。"

    # say L2079 ang
    old "{i}(Hmm, he's closer than before.){/i}"
    new "{i}(彼が前より近づいてきたな。){/i}"

    # say L2080 ang
    old "{i}(What's this I'm starting to feel?){/i}"
    new "{i}(これは何を感じ始めているの？){/i}"

    # say L2082 pla
    old "{i}(Why is she so stiff?){/i}"
    new "{i}彼女、なんでこんなに固くなってるの？{/i}"

    # say L2083 pla
    old "{i}(I think we'll have to move on to the next position.){/i}"
    new "{i}次の体位に移るしかないな。{/i}"

    # say L2084 pla
    old "{i}(Maybe something a bit more relaxed.){/i}"
    new "{i}(ちょっとリラックスした方がいいかもしれないね。){/i}"

    # say L2085 pla
    old "Ok, I think that's enough of this position, we can move on to the next one."
    new "分かった、この体位はこれくらいにして次に移ろう。"

    # say L2093 pla
    old "Ok, you're doing well so far."
    new "大丈夫、今のところ上手くいってるよ。"

    # say L2094 pla
    old "But I think you're still a little tense. So I want us to change into a more relaxed position."
    new "でもまだ少し緊張してるみたいだな。リラックスできるポジションに変えてみよう。"

    # say L2095 pla
    old "The idea for this next position is for you to relax and let go."
    new "次の体位では、君がリラックスして自然と流れ出せるようにしよう。"

    # say L2097 ang
    old "L-let myself go?"
    new "自分を解放するの？"

    # say L2098 pla
    old "That's right, I want you to relax and just let your energy flow through the position."
    new "そうだよ、リラックスしてそのポジションでエネルギーが自然と流れるようにすればいいんだ。"

    # say L2100 pla
    old "I can see that you have an energy block."
    new "君のエネルギーが詰まってるのが見えるよ。"

    # say L2102 pla
    old "If you keep going that way you won't be able to feel the energy flow through you."
    new "その調子で続けちゃうと、エネルギーが体の中を流れ游戏代入されないよ。"

    # say L2104 ang
    old "I-I see, I think I get it."
    new "うーん、なるほど。"

    # say L2106 pla
    old "Ok, so be sure to just relax."
    new "分かった、じゃあリラックスすることを心がけろ。"

    # say L2107 pla
    old "This next one's called Upavistha Konasana."
    new "次のはアップビスタコナサナって言うんだ。"

    # say L2108 pla
    old "Except that it's a modified version."
    new "でもこれは改良版だよ。"

    # say L2109 ang
    old "Modified? Will it be too hard?"
    new "改良版？難しすぎない？"

    # say L2110 pla
    old "Not at all, don't worry."
    new "全然心配しなくていい。"

    # say L2112 pla
    old "It involves a forward fold while you push your legs outwards and reach for your ankles."
    new "体を前に折りながら、足を外側に広げて、足首に手を伸ばすんだ。"

    # say L2113 pla
    old "But I will be helping you, so you won't have to make much effort."
    new "でも心配しないで、君の手伝いをするから、そんなに力を入れなくても大丈夫だよ。"

    # say L2114 pla
    old "I'll help you by opening your legs with mine, and I'll pull you forward, so you just focus on the stretch through your groin and lower back."
    new "俺が自分の足で君の足を広げて、前に引っ張るので、股と下背のストレッチに集中してればいい。"

    # say L2116 ang
    old "Hmm, it sounds hard, but I'll trust you."
    new "うーん、難しそうだけど、信じるよ。"

    # say L2119 pla
    old "Alright, you're doing ok."
    new "大丈夫、上手くいってるよ。"

    # say L2122 pla
    old "But try to let yourself go a little bit more. Ok?"
    new "でももうちょっと libertinism してみよう？いいな？"

    # say L2130 ang
    old "{i}(W- what is this I'm feeling again?){/i}"
    new "{i}(これ……また同じような感覚が……){/i}"

    # say L2131 ang
    old "{i}(T-this... Is like what I felt that time.){/i}"
    new "{i}(この… 前に感じたことと同じ…){/i}"

    # say L2132 pla
    old "{i}(W-what?! S-she's even more tense than before!){/i}"
    new "{i}(な、何だよ！？　さ、彼女は前よりも緊張してる！){/i}"

    # say L2133 pla
    old "{i}(Hmph, I guess this isn't working.){/i}"
    new "{i}(ふん、これじゃ駄目か。){/i}"

    # say L2134 pla
    old "Alright, I think that's enough for this position."
    new "よし、この体勢で十分だな。"

    # say L2142 pla
    old "Ok, I think that's enough for today."
    new "じゃあ、今日はこれでいいか。"

    # say L2143 pla
    old "How did you feel?"
    new "どうだった？"

    # say L2145 ang
    old "I- Uhmm... I think I felt alright."
    new "うーん……多分、まあまあの感じだったかな。"

    # say L2146 ang
    old "I feel my body a lot more loose now."
    new "体がずいぶんと緩んだ気がする。"

    # say L2148 pla
    old "Hmph, well, as long as you don't feel bad, I guess that's ok."
    new "ふん、まあ、悪い気分じゃないならいいけどな。"

    # say L2149 pla
    old "Why don't we go down and let Lisa know that we're done?"
    new "それじゃ、Lisaに伝えようか？"

    # say L2167 lis
    old "Hello guys, are you done with the class?"
    new "こんにちは、みんな。授業終わったの？"

    # say L2171 lis
    old "Alright, and how did it go? How are you feeling right now Angelina?"
    new "大丈夫、授業はどうだった？今どう感じてるの、アンジェリナ？"

    # say L2173 ang
    old "It was good... Yeah, it was a good class."
    new "良かったよ…うん、良い授業だった。"

    # say L2174 ang
    old "[pla] helped me through every position, and they weren't too difficult."
    new "[pla]が私をサポートしてくれて、ポジションも難しくなかったよ。"

    # say L2176 lis
    old "I'm happy to hear that. [pla] knows very well what he's doing, so I was sure that it would be a good class."
    new "良かったね。[pla]は本当に上手だから、きっと良い授業になると思ってたの。"

    # say L2177 ang
    old "It was."
    new "そうだった。"

    # say L2178 ang
    old "I’m afraid it’s getting quite late, I must be going now."
    new "もう遅い時間だから、そろそろ帰るわ。"

    # say L2180 ang
    old "Thanks a lot for the class [pla]."
    new "ありがとう、クラスを教えてくれて [pla]。"

    # say L2181 pla
    old "You are welcome."
    new "また次の授業でね、リサ。"

    # say L2184 ang
    old "Goodbye, Lisa. I’ll see you at the next class."
    new "さようなら、Lisa。次回の授業でまた会うね。"

    # say L2185 lis
    old "See you next class, sweetheart. Take care."
    new "次回の授業でね、甘い人。気をつけて。"

    # say L2197 lis
    old "So? What did you think? How did it go?"
    new "じゃあ？どうだった？どんな感じだった？"

    # say L2198 pla
    old "Hmm, in general, I would say it was alright."
    new "うーん、全体的にはまあまあの感じだったな。"

    # say L2199 pla
    old "But I can see what you mean about her having some sort of energetic block."
    new "でも、君が言うように彼女にはエネルギーのブロックがあるのは理解できる。"

    # say L2201 pla
    old "I felt that she was very tense in all the positions we did."
    new "彼女は私たちがやった体位全部でかなり緊張してたな。"

    # say L2202 lis
    old "I see, so her energy's still blocked inside her."
    new "なるほど、エネルギーがまだ彼女の中で封じられてるんだね。"

    # say L2204 pla
    old "Well, maybe that has to do with the fact that she's pregnant?"
    new "まあ、それが彼女が妊娠していることに関係してるかもしれないね。"

    # say L2205 pla
    old "By the way, I would've liked to have known that before."
    new "それにしても、そのことは前に知りたかったな。"

    # say L2207 lis
    old "Oh, I failed to mention that, I'm sorry."
    new "あ、それをお忘れしちゃった、ごめんなさい。"

    # say L2208 lis
    old "But I don't think it makes such a difference."
    new "でも、そんなに違いはないと思う。"

    # say L2209 lis
    old "What I've been feeling she lacks is that masculine energy I told you about."
    new "私が感じているのは、彼女には私が話したような男性的なエネルギーが足りないということよ。"

    # say L2210 lis
    old "So I think that it was still beneficial for her to have that session with you."
    new "だから、彼女が君とのセッションを受けたことはまだ役立ったと思うの。"

    # say L2212 pla
    old "I see, well, I sure hope that it actually helped her because she was just so tense during the session."
    new "なるほど、実際に彼女に効果があったことを願ってる。セッション中、彼女は本当に緊張してたからな。"

    # say L2214 lis
    old "Her next session's with me, so I'll see how her energy's changed. I'll let you know how she's doing."
    new "次は私が担当するから、彼女のエネルギーがどう変わったか見てみる。その後、彼女の状態を教えてあげる。"

    # say L2217 lis
    old "Before you head out, there's something I'd like to discuss with you."
    new "出ていく前に、ちょっと話したいことがあるの。"

    # say L2218 pla
    old "Uh, sure. What's on your mind?"
    new "うーん、いいよ。何を話すの？"

    # say L2219 lis
    old "Well, recently, I've been doing very well."
    new "最近、調子がとてもいいの。"

    # say L2220 lis
    old "I've gotten a good number of new clients, and they seem to be very happy with my classes."
    new "新しいクライアントも増えたし、みんな私のクラスに満足してくれてるみたい。"

    # say L2221 lis
    old "I'm very happy with how things have been going lately."
    new "最近の調子がとてもいいわ、満足してるの。"

    # say L2223 pla
    old "That sounds great! Congrats, Lisa!"
    new "それは最高だな！おめでとう、Lisa。"

    # say L2224 lis
    old "Thanks, [pla]."
    new "ありがとう、[pla]。"

    # say L2225 lis
    old "But you see, some of my students are actually becoming very advanced in yoga."
    new "でもね、私の生徒の中には実際にヨガがかなり上達している子もいるの。"

    # say L2226 lis
    old "So, I'm pondering what else I can offer my clients in the way of spiritual guidance and development."
    new "だから、クライアントに提供できる他のスピリチュアルなガイダンスや成長の方法を考えてるの。"

    # say L2230 lis
    old "Especially because my work goes beyond just yoga and meditation, you have seen it."
    new "特にヨガや瞑想だけでなく、私の仕事はそれ以上だから、あなたも見ているよね。"

    # say L2231 lis
    old "Rather than just a yoga guru, I want to be known as a complete spiritual wellness guide."
    new "ただのヨガの先生ではなく、総合的なスピリチュアルなウェルネスガイドとして知られたいの。"

    # say L2232 lis
    old "So that my students can progress in whatever way they feel benefits them the most."
    new "そうすれば、私の生徒たちは自分たちが最も利益を得ると感じる方法で進歩できるから。"

    # say L2233 pla
    old "Ok, that sounds like a very good idea."
    new "そうだな、良いアイデアだね。"

    # say L2235 lis
    old "Thanks, [pla]. So I came up with the idea of adding classes in mindfulness, transcendental meditation."
    new "ありがとう、[pla]。それで、マインドフルネスや超越瞑想のクラスを追加するアイデアを考えたの。"

    # say L2236 lis
    old "As well as Tai Chi, Reiki, and Tantric sex."
    new "タイチやレイキ、そしてタントリックセックスもね。"

    # say L2237 lis
    old "And different healing treatments, like Chakra Healing, Acupuncture, Sound Healing, and herbal medicines."
    new "そして様々な治療法も導入する予定よ。チャクラヒーリング、針灸、サウンドヒーリング、ハーブ療法などね。"

    # say L2238 pla
    old "I- I see, that's a lot."
    new "なるほど、それだけあるのか。"

    # say L2240 pla
    old "So you want to expand your portfolio, right?"
    new "君の治療メニューを増やしたいんだな？"

    # say L2242 lis
    old "Hmm... Yeah, to put it in simpler terms."
    new "うーん… そうですね、簡単に言えば。"

    # say L2244 lis
    old "Of course, I intend to implement this gradually. I’d like to conduct a few tests before applying it to additional clients."
    new "もちろん、段階的に実施していくつもりだ。まずはいくつかのテストをしてから、他のクライアントに適用したいと思っている。"

    # say L2245 pla
    old "That makes sense, so, Do you already have a plan for how to begin?"
    new "なるほど、じゃあ最初にどう始めるか、何か計画はあるのか？"

    # say L2247 lis
    old "Well, I have this client that's been working with me for a while."
    new "まあ、長い間一緒に働いてるクライアントがいるの。"

    # say L2249 lis
    old "And she has in fact asked me several times about the possibility of having tantric sex sessions."
    new "そして、彼女は実際に何度もタントリックセックスのセッションについて聞いてきているの。"

    # say L2250 pla
    old "I see, well, that makes a lot of sense, and if she wants to do it, I think it's a great idea."
    new "なるほど、確かにそれには意味があるな。もし彼女がそれを望んでいるなら、いいアイデアだと思うよ。"

    # say L2252 lis
    old "Yes, and you see, this client's Anastasia."
    new "そう、そしてこのクライアントはアナスタシアなんだ。"

    # say L2254 pla
    old "Oh, I see, I think she did mention that."
    new "ああ、そうか、彼女がそう言っていたな。"

    # say L2256 lis
    old "Yeah, and given that she's relatively advanced in her yoga journey, I think this would be a good moment to introduce her to more advanced concepts."
    new "うん、彼女がヨガの旅でかなり進んでいることを考えると、より高度な概念を導入する絶好のタイミングだと思う。"

    # say L2257 lis
    old "Especially tantric sex, I think it would be good for her to follow that practice."
    new "特にタントリックセックスね、それを始めるのは彼女にとって良いと思うわ。"

    # say L2258 lis
    old "After all, the benefits are great, I think it would really help her with reducing stress and improving her relaxation."
    new "結局、メリットは大きいと思うの、ストレス軽減やリラクゼーションの向上に本当に役立つと思うわ。"

    # say L2260 lis
    old "Which will help her with her sleep."
    new "それが彼女の睡眠を助けるでしょう。"

    # say L2262 lis
    old "Not to mention her sexual satisfaction, which I believe is clear to the both of us she needs to improve on."
    new "それに彼女の性的満足も、私たちは彼女が改善すべきだとわかってるよね。"

    # say L2264 lis
    old "But more importantly, her personal and spiritual growth, tantra will help her with it, and I believe she'll benefit greatly from it."
    new "でもっと重要なのは、彼女の個人的で精神的な成長。タントラがそれを助け、彼女には大きな利益があると思う。"

    # say L2265 pla
    old "All of that sounds great, I'm sure you'll have a great time teaching her."
    new "全部すごく sounded great, きっと君が教えてあげるのを楽しむだろうな。"

    # say L2267 lis
    old "Well, since you mentioned it, that's where you come in."
    new "まあ、あなたがそう言うなら、あなたの出番だわ。"

    # say L2269 lis
    old "Anastasia asked me if it would be possible for you to accompany us during the tantric sex sessions."
    new "アナスタシアが、タントリックセックスのセッションにあなたも同伴してほしいって言ったの。"

    # say L2270 pla
    old "M-Me? Do you need me to be there?"
    new "ええと、俺？俺が必要なのか？"

    # say L2271 pla
    old "I mean, with your experience, I don't see why I would need to be there. Don't you just do that directly?"
    new "君の経験を考えると、俺がいる必要はないと思うけど、直接やってくれないの？"

    # say L2273 lis
    old "Of course I can teach her everything, but the reason I want you to go there is to be my assistant."
    new "もちろん彼女に全部教えてあげられるけど、あなたに来てほしいのは私のアシスタントになってほしいからよ。"

    # say L2275 pla
    old "Your assistant?"
    new "君のアシスタント？"

    # say L2277 lis
    old "Yeah, that's right, but not in the way that you may think of."
    new "そう、その通りだけど、君が想像してるような意味じゃないの。"

    # say L2278 lis
    old "What I need from you is that you play the role of an intermediary between Anastasia and me."
    new "私があなたから必要としているのは、アナスタシアと私の間の仲介役になってくれることです。"

    # say L2280 pla
    old "I-I'm not sure I get what you're saying."
    new "俺、君の言ってることがちょっとわからないんだ。"

    # say L2282 lis
    old "Think about it [pla], you've already worked with Anastasia in the past, so she's comfortable with you in that sense."
    new "考えてみて [pla]、アナスタシアとは過去にも一緒に仕事をしたことがあるから、彼女はあなたに対して信頼感があるわ。"

    # say L2283 lis
    old "So, when I'm doing the sessions with her, your role will be to help her feel more relaxed and comfortable."
    new "だから、私が彼女とセッションをしているとき、あなたの役割は彼女がもっとリラックスして快適に感じられるようにすることよ。"

    # say L2284 lis
    old "So that the session can flow smoothly and without any problems."
    new "そうすれば、セッションがスムーズに進んで、問題なく進められるわ。"

    # say L2286 pla
    old "Hmm, I see, that makes quite a lot of sense."
    new "なるほど、それは確かに意味があるね。"

    # say L2288 pla
    old "But hey, you and I are still working on my own tantric session."
    new "でもね、君と俺はまだ俺のタントラセッションをやってる最中だぞ。"

    # say L2289 pla
    old "Are you sure it will be a good idea for me to be there? Wouldn't it be better if it's just the two of you?"
    new "俺がそこにいるのがいいと思うけど、二人きりの方がいいのかな？"

    # say L2290 lis
    old "Well, at the beginning I did think it strange when she asked for it."
    new "最初は彼女がそれを求めたことに違和感を感じたけど。"

    # say L2291 lis
    old "But it makes a lot of sense since you've already helped her with her chakra balancing in the past."
    new "でも、過去に彼女のチャクラバランスを手伝ってくれたことがあるから、すごく納得できるわ。"

    # say L2293 lis
    old "In addition, I believe it would be good practice for you, it would be a good way for you to work with other clients in the future. If the opportunity arises of course."
    new "それに、あなたにとって良い練習になると思うわ。将来他のクライアントと働く際の良い経験になるでしょう。もちろん機会があればね。"

    # say L2295 lis
    old "But of course, it all depends on you, if you feel the universe is guiding you towards a teaching role."
    new "もちろん、すべてはあなたの感じ方次第だけど、宇宙があなたを教え役へと導いていると感じるかどうかによるね。"

    # say L2297 lis
    old "If you don't feel like it, there's no problem, I'll understand."
    new "もしやりたくないなら、問題ないわ、理解できるから。"

    # say L2299 pla
    old "Oh, no, no, there's no problem with it. I'll do it, with the way you explain it, it makes a lot of sense."
    new "Lis、問題ないよ。やるよ、君が説明してくれて、すごく納得したから。"

    # say L2301 lis
    old "Excellent [pla]! Thank you very much! I know it's going to be great."
    new "すごいね[pla]！本当にありがとう！きっと最高になると思うよ。"

    # say L2302 lis
    old "I’ve scheduled an appointment for tomorrow evening, would you happen to be available?"
    new "明日の夜の予約を入れたんだけど、都合はいい？"

    # say L2304 pla
    old "Uhh, I think so."
    new "うーん、多分いいんじゃない？"

    # say L2306 lis
    old "Wonderful, I'll get everything ready, and I'll see you later."
    new "素晴らしい、すべて準備しておきますね、後でね。"

    # say L2308 pla
    old "Sure, goodbye then."
    new "じゃあ、またね。"

    # say L2335 pla
    old "Anastasia, hi. You're already here, great."
    new "アナスタシア、こんにちは。もう来てくれてありがとう、助かるよ。"

    # say L2338 ana
    old "Yeah, I just arrived, Lisa wasn't here so I decided to wait a while."
    new "ええ、ちょうど着いたところよ。リサはいなかったから、ちょっと待つことにしたの。"

    # say L2340 pla
    old "Oh, she's probably already up in the yoga room waiting for us."
    new "ああ、多分すでにヨガルームで待ってるんだよ。"

    # say L2344 pla
    old "Sure, let's go up."
    new "行こうな。"

    # say L2369 ana
    old "Oh! Hi Lisa, [pla] and I ran into each other in your living room and..."
    new "あ！こんにちは、リサ。[pla] と私がリビングで出会って…"

    # say L2373 lis
    old "Hmm, Anastasia are you alright?"
    new "アナスタシア、大丈夫？"

    # say L2374 ana
    old "Yeah, sorry, sorry."
    new "うん、ごめん、ごめん。"

    # say L2376 ana
    old "It's just that the outfit you're wearing... It surprised me."
    new "君が着てるその服…驚いちゃったの。"

    # say L2379 lis
    old "I see, that's understandable, but these collars are necessary for what we're about to do."
    new "分かった、それは理解できるけど、この首輪はこれからするため必要なんだ。"

    # say L2380 lis
    old "They're an important element that will help to keep the balance of your chakras."
    new "それが必要な要素で、君のチャクラのバランスを保つのに役立つんだ。"

    # say L2382 ana
    old "I-I see."
    new "分かったの。"

    # say L2384 lis
    old "Yes, because you see, this is a physical process, so the idea is to be fully in contact with our energies."
    new "そう、だってこれは物理的なプロセスだから、エネルギーが完全に触れ合うことが大事なんだよ。"

    # say L2385 lis
    old "So we need to get rid of everything that could get in the way of that connection. Of course, our clothes are part of that."
    new "だから、邪魔になるものをすべて取り除く必要があるの。もちろん、服もその一部よ。"

    # say L2386 ana
    old "D-Does that mean that I will be naked too?"
    new "あの、それって、私も裸になっちゃうってことですか？"

    # say L2388 lis
    old "Of course, but don't worry about it, this is a spiritual process, and both [pla] and I are very professional about it."
    new "もちろん、でも心配しなくていい、これは精神的なプロセスだから、[pla]と私ともうプロフェッショナルにやるよ。"

    # say L2390 ana
    old "I-I see, I understand."
    new "分かったわ、理解したよ。"

    # say L2392 lis
    old "Good, then let's get started. Why don't you go ahead into the yoga room and get ready?"
    new "それじゃ、始めよう。まずはヨガルームに行って準備してきなさい。"

    # say L2393 lis
    old "[pla] and I will go in a minute."
    new "[pla]と私はすぐに中に入るよ。"

    # say L2394 ana
    old "Sure, I'll do that. So, I have to get naked in there?"
    new "うん、わかった。でも、そこで裸になるの？"

    # say L2396 lis
    old "Yes, the idea is that you'll be ready for when [pla] and I come in."
    new "うん、[pla]と私が入る前に、君が準備できてるってことだよ。"

    # say L2398 ana
    old "I see, I'll do it then."
    new "分かった、それならやるわ。"

    # say L2404 lis
    old "Alright, you know what the idea is, right? You'll support me during the session, and you'll also be without any clothes."
    new "分かってるよね？セッション中は私をサポートして、全裸でいなきゃならないのよ。"

    # say L2406 pla
    old "Yeah sure, no problem."
    new "わかった、問題ないよ。"

    # say L2408 lis
    old "However, for this session onwards, I prepared a special outfit for you."
    new "しかし、このセッションからは特別な衣装を用意したの。"

    # say L2409 pla
    old "A- a special outfit?"
    new "あー、特別な衣装？"

    # say L2411 lis
    old "Yes, up until now I've been guiding you in this development journey."
    new "はい、これまで私はあなたをこの開発の旅で導いてきたわ。"

    # say L2412 lis
    old "But today you will be the one taking the position of the guide. From now on, you'll be a Yogi."
    new "でも今日からはあなたがガイドの立場になります。これからはあなたがヨギになるの。"

    # say L2415 lis
    old "A yogi, that's the title that a yoga instructor receives when they're guiding somebody."
    new "ヨギとは、誰かを導くヨガインストラクターに与えられる称号です。"

    # say L2416 lis
    old "You're not a guru, like I am, but I think it's appropriate that I call you a Yogi, especially because you've already guided Anastasia on the right path."
    new "あなたは私のようなグルじゃないけど、アナスタシアを正しい道に導いたことから、ヨギと呼ぶのはふさわしいと思うの。"

    # say L2417 lis
    old "That's why I prepared a special outfit for you. You being on another level needs to be reflected in what you're wearing."
    new "それが、あなたのために特別な格好を用意した理由よ。あなたがもう一つ上のレベルにあることを、服装で表現したいと思ったの。"

    # say L2418 lis
    old "That and because they're needed to protect and balance your energy."
    new "それと、あなたのエネルギーを守り、バランスを取るために必要なからよ。"

    # say L2419 pla
    old "I-I see, thank you, Lisa."
    new "うーん、ありがとう、Lisa。"

    # say L2421 lis
    old "You're more than welcome. Now go and get changed. Anastasia is waiting for us."
    new "どういたしまして。さあ、着替えて。アナスタシアが待ってるわ。"

    # say L2422 lis
    old "You'll find what you have to wear on the bed."
    new "ベッドの上に着替えるものが用意してあるわ。"

    # say L2441 pla
    old "S- so, I wasn't sure if I was putting it on correctly, but I saw some instructions over the bed."
    new "あのう、着方があっているかどうか不安だったんだけど、ベッドの上に説明が書いてあったな。"

    # say L2442 pla
    old "What do you think? Does it fit me properly?"
    new "どう思う？　ちゃんと似合ってるか？"

    # say L2443 lis
    old "It does, you look great, like a proper yogi."
    new "そう、ぴったりしてるよ、本物のヨギみたい。"

    # say L2444 lis
    old "Let's go in, Anastasia's waiting for us."
    new "入ろう、アナスタシアが待ってるよ。"

    # say L2471 pla
    old "{i}(Oh, wow, she's just naked there.){/i}"
    new "{i}(ああ、すごい、裸じゃん。){/i}"

    # say L2473 pla
    old "{i}(I sometimes forget that Anastasia's so hot.){/i}"
    new "{i}(アナスタシアがこんなに綺麗なこと、時々忘れちゃうな。){/i}"

    # say L2477 ana
    old "[pla]! Wow! What an outfit."
    new "[pla]！すごい！その格好。"

    # say L2478 ana
    old "You look like a proper shaman now."
    new "あなたは本物のシャーマンに見えるわ。"

    # say L2481 lis
    old "Hahaha, what [pla]'s wearing is actually a very important part of the tantra ritual that we're going to be performing with you."
    new "ははは、[pla]が着てるのは、私たちがあなたと行うタントラ儀式にとってすごく重要な部分なんだ。"

    # say L2482 lis
    old "Because the idea is that this is as good an experience for you as we can make it."
    new "この格好で、君に最高の体験を提供できるから。"

    # say L2483 lis
    old "So, are you ready to start?"
    new "それじゃ、準備できてる？"

    # say L2485 ana
    old "Oh yeah, for sure, I've been waiting for this."
    new "もちろん、待ってたの。"

    # say L2486 ana
    old "I'm a little nervous."
    new "少し緊張してるの。"

    # say L2487 ana
    old "But once we start, I'm sure I'll feel a lot better."
    new "でも始まれば、きっとずいぶん楽になるわ。"

    # say L2491 lis
    old "Listen, Anastasia, I understand the type of situation this is, and how arousing it potentially is."
    new "アナスタシア、この状況がどんなものか、そしてどれだけ興奮させるか、私は理解しているよ。"

    # say L2493 lis
    old "But it's important that you keep in mind that this is not for the sake of having sex."
    new "でも、これはセックスのためじゃなくて、それを覚えておいて。"

    # say L2495 lis
    old "The most important part of this whole process is to learn to control those sexual impulses that sometimes take hold of us."
    new "このプロセスで最も重要だと思っているのは、性欲が私たちを支配することをコントロールすることだよ。"

    # say L2497 lis
    old "So my focus for you during this whole process is that you are able to balance your chakras and put your energy in order."
    new "だからこの過程では、君がチャクラを調和させ、エネルギーを整えることが私の焦点なんだ。"

    # say L2499 ana
    old "Hmm, yeah, I guess you're right, but does that mean that we won't be having sex?"
    new "うーん、そうね、でもそれってセックスしないってこと？"

    # say L2501 lis
    old "In the most strict sense of the word, no."
    new "厳密に言えば、そうね。"

    # say L2502 lis
    old "We will come to it when the time comes, but what's most important is that you are able to relax."
    new "時間になったら自然と進むわ、でも一番大切なのはリラックスできることよ。"

    # say L2503 lis
    old "To control your sexual energy and come to internal balance with your energy and chakras."
    new "性エネルギーをコントロールして、エネルギーやチャクラとの内面的なバランスを取ることよ。"

    # say L2505 lis
    old "Now, let's get started so that you can see how this process feels."
    new "それじゃ、始めましょう。このプロセスがどんな感じか感じてみてね。"

    # say L2507 ana
    old "O-Okay, sure."
    new "うーん、わかった。"

    # say L2508 lis
    old "So, before we start with the first session, I want you to keep in mind that you need to focus on your breathing and relaxing your body."
    new "それじゃ、最初のセッションを始める前に、呼吸に集中して体をリラックスさせることが大切だということを覚えておいてね。"

    # say L2509 lis
    old "Let yourself go and listen to my instructions while you keep your breathing constant."
    new "自分を解放して、私の指示に耳を傾けながら呼吸を一定に保つんだ。"

    # say L2529 lis
    old "I want to congratulate you, Anastasia."
    new "アナスタシア、おめでとうございます。"

    # say L2530 lis
    old "The fact that you were able to truly connect with yourself by doing this therapy."
    new "君がこの療法を通じて本当に自分と繋がることができたこと。"

    # say L2531 ana
    old "I was surprised by how good it feels, I wasn't expecting it. Thank you so much, Lisa! And you too, [pla]."
    new "驚いたわ、こんなに気持ちいいなんて思わなかったから。ありがとう、リサ！そしてあなたも、[pla]。"

    # say L2532 lis
    old "I'm glad I'm able to help you."
    new "助けることができて嬉しいわ"

    # say L2533 lis
    old "But there still remains much to be done."
    new "でもまだたくさんすることがあるのよ。"

    # say L2534 lis
    old "So we will continue during the next session, ok?"
    new "次回のセッションで続きをしよう、ね？"

    # say L2536 ana
    old "Oh, we're done? I thought that maybe we could do some more..."
    new "あ、もう終わったの？ もうちょっと続けられると思ったのに…"

    # say L2538 lis
    old "I understand that you may feel like it, but we're doing this little by little."
    new "分かってるわ、もっとやりたい気分になるかもしれないけど、少しずつ進めていくのよ。"

    # say L2539 lis
    old "Besides, you may not feel like it now, but you need to rest before you can do more. Believe me, you'll feel it later."
    new "それに、今すぐやりたくなくても、休んだ方がいいわ。信じて、後で感じるから。"

    # say L2541 ana
    old "Hmm, ok, I get it."
    new "うーん、わかった。"

    # say L2543 lis
    old "Yes, by the way, it's getting a little late."
    new "そういえば、時間も遅くなってきたわね。"

    # say L2544 lis
    old "It's better if we get changed and ready for you to return home."
    new "着替えて準備した方がいいわね、帰る時間だから。"

    # say L2551 lis
    old "Well, I would say that was a very good first session. I'm glad with the progress you made today, Anastasia."
    new "まあ、最初のセッションとしてはとても良かったわ。今日のあなたの進歩に満足しているの、アナスタシア。"

    # say L2553 ana
    old "Thank you very much, Lisa. I wasn't expecting it to be that good, but it was amazing."
    new "ありがとう、リサ。思ってたよりずっと良かったよ、本当に素晴らしい体験だった。"

    # say L2554 ana
    old "And of course, thanks to you too, [pla]. With you here, I was able to feel so much more comfortable."
    new "もちろん、あなたにも感謝してる、[pla]。あなたがいてくれて、ずっとリラックスできました。"

    # say L2557 lis
    old "She's right, [pla]. You being here really brings our energies to a state of balance. Thanks a lot."
    new "そうだね、[pla]。あなたがいてくれると、私たちのエネルギーが本当にバランスよく感じられるの。ありがとう。"

    # say L2558 pla
    old "Oh, well, I'm happy to help."
    new "まあ、手伝えて嬉しいぜ。"

    # say L2560 ana
    old "Anyway, it's getting a bit late, so I should head out. I can’t wait for the next tantric class."
    new "でも、時間も遅くなってきたので、帰るわ。次のタントラクラスが楽しみだわ。"

    # say L2561 lis
    old "Goodbye, darling, see you at the next yoga session this afternoon."
    new "さようなら、 Darling、今日の午後のヨガの時間にまた会えるのを楽しみにしてるわ。"

    # say L2562 pla
    old "Good night, have a great evening."
    new "おやすみ、良い夜を"

    # say L2564 ana
    old "Oh, of course I'll have a wonderful night. Thanks again, you two."
    new "もちろん素晴らしい夜になるわ。またありがとう、二人とも。"

    # say L2574 lis
    old "Oh [pla], I think it was a total success, I could feel our energies connecting and merging during the tantric exercise."
    new "あら [pla]、これは完全な成功だったわ。タントラのエクササイズ中に私たちのエネルギーがつながって融合しているのが感じられたの。"

    # say L2575 lis
    old "I definitely believe the universe is opening a door for my business. It's calling me to guide more clients spiritually. Did you feel it too?"
    new "確かめたいけど、宇宙が私のビジネスに扉を開いていると感じるわ。もっとクライアントをスピリチュアルに導くように呼んでいるの。あなたも感じた？"

    # say L2577 pla
    old "Uhh, y- yeah, I totally felt it, that energy was... Definitely something."
    new "うーん、ええ、確かに感じたよ、そのエネルギーは… 確かに何かあったな。"

    # say L2578 lis
    old "Right? It was almost a religious experience."
    new "そうよね？ほとんど宗教的な体験だったわ。"

    # say L2579 lis
    old "Oh wow, look at the time, it's really late."
    new "あら、時間がこんなに遅くなっちゃったのね。"

    # say L2580 lis
    old "Ugh, I wanted to talk to you about Angelina, but I think we'll leave that for another day."
    new "うーん、アンジェリーナのことを話したかったんだけど、また今度にしよう。"

    # say L2581 lis
    old "Could you swing by in the afternoon so we can talk? It won't take long."
    new "午後に寄って話そう、長くはならないから。"

    # say L2582 pla
    old "Uhh, yeah, sure. No problem."
    new "うーん、そうだな。問題ないよ。"

    # say L2583 lis
    old "Perfect. Let's leave it here so you can get some rest. You've helped me a lot today, [pla]. Thanks."
    new "Perfect. それじゃあここで終わりにしよう。今日はたくさん手伝ってくれてありがとう、[pla]。"

    # say L2601 pla
    old "Hi Lisa, how are you?"
    new "嘿、Lisa、元気か？"

    # say L2603 lis
    old "Hey, my energy’s flowing beautifully today, how about you?"
    new "hey、今日私のエネルギーがすごく流れているの、あなたは？"

    # say L2604 pla
    old "I'm fine... Thanks for asking."
    new "俺は元気だ… 質問してくれてありがとう。"

    # say L2605 pla
    old "I came about that thing you mentioned, you wanted to talk about Angelina."
    new "君が話してたことについて来たんだ、アンジェリーナのことで話したいって言ったよね。"

    # say L2606 lis
    old "Oh, yes, of course. Thanks for coming."
    new "あ、そうそう。来てくださってありがとうございます。"

    # say L2607 lis
    old "Well, I had a session with her, and she asked me if you could be the teacher in her next class."
    new "まあ、彼女とセッションをしたんだけど、次の授業の先生は君になってくれないかって聞かれたの。"

    # say L2609 pla
    old "She did?!"
    new "彼女がそう言ったの？！"

    # say L2611 lis
    old "Uhh, yes, why are you so surprised?"
    new "うーん、そうね、なんでそんなに驚いてるの？"

    # say L2613 pla
    old "Well, I just wasn't expecting that."
    new "まあ、そんな反応をするとは思わなかったんだ。"

    # say L2614 pla
    old "Because last time she almost looked uncomfortable during the class."
    new "前回はクラス中ほとんど不快そうに見えたからな。"

    # say L2615 pla
    old "So it's kind of a surprise that you tell me she wants another class with me."
    new "だから君が她说想再上一次我的课，这有点让我意外。"

    # say L2617 lis
    old "Well, she had another class with me after yours."
    new "まあ、あなたの後で彼女とまたクラスをしたの。"

    # say L2618 lis
    old "And yes, I've noticed that her energy seems stuck. Her Muladhara chakra is completely out of balance."
    new "そして、彼女のエネルギーが停滞していることに気づきました。ムーラダラチャクラが完全にバランスを失っています。"

    # say L2619 lis
    old "And it's affecting the flow of prana through her nadis. There might be a deep-rooted samskara causing this blockage."
    new "そしてそれがプラナの流れを妨げているわ。深いサムスカーラがこのブロックを引き起こしている可能性があるの。"

    # say L2620 lis
    old "But after her class with you, I've noticed her blockage has started to dissipate."
    new "でも、あなたのクラスの後から彼女のブロックが少しずつ解けてきていることに気づきました。"

    # say L2622 pla
    old "For real?"
    new "マジで？"

    # say L2624 lis
    old "Yes, I've noticed that after her session with you, her energy has started to flow a lot better inside her."
    new "そうね、彼女があなたとセッションした後から、エネルギーがずいぶん流れやすくなったわ。"

    # say L2626 pla
    old "Hmm, I have to say, that's a surprise."
    new "へえ、それは意外だな。"

    # say L2627 pla
    old "But if you say that it's alright, and she actually requested another session with me, then I guess it's alright."
    new "でも君がそう言うなら、彼女もまた会いたいって言ってくれたなら、まあいいか。"

    # say L2629 lis
    old "It is, if she wants to see you again, it means you did a very good job."
    new "そうね、彼女がまた会いたいって言うなら、あなたがとても良い仕事をしたってことよね。"

    # say L2631 pla
    old "Uhh, alright..."
    new "うーん、いいかな…"

    # say L2633 lis
    old "So, can I count on you for the next session with Angelina?"
    new "じゃあ、次のセッションでアンジェリナと会うのは任せられるわね？"

    # say L2635 pla
    old "Sure, sure, no problem."
    new "大丈夫、大丈夫、問題ないよ。"

    # say L2637 lis
    old "That's wonderful [pla], thanks a lot."
    new "それは素晴らしい [pla]、本当にありがとう。"

    # say L2638 lis
    old "I'll go ahead and schedule Angelina's next yoga session."
    new "アンジェリーナの次のヨガの予定を入れておきますね。"

    # say L2639 lis
    old "So, as you know, I'll see you this afternoon for your next yoga class."
    new "それじゃ、午後にまたヨガのクラスで会うわね。"

    # say L2641 pla
    old "Sure, count on it."
    new "分かった、待ってるぞ。"

    # say L2642 lis
    old "Thank you so much [pla], the universe has great things in store for you!"
    new "ありがとう、[pla]。あなたには素晴らしいことが待ってるよ。"

    # say L2643 pla
    old "Heh, thanks. Well, I guess I'll see you later. Bye."
    new "へへ、ありがとう。まあ、また後でな。バイ。"

    # say L2644 lis
    old "Goodbye [pla], take care."
    new "さよなら[pla]、気をつけてね。"

    # say L2671 lis
    old "Oh, hi [pla]! it's good to see you."
    new "あ、こんにちは[pla]！会えて嬉しいわ。"

    # say L2674 pla
    old "Hi, have you been waiting too long for me?"
    new "待たせちゃったか？"

    # say L2676 lis
    old "Not at all, Angelina just arrived a couple of minutes ago."
    new "全然、エンジェリナが数分前に来たばかりだから。"

    # say L2677 lis
    old "So you're just in time for the class."
    new "ちょうどいいタイミングでクラスに間に合ったわね。"

    # say L2678 lis
    old "But it's better if you don't lose time."
    new "でも時間の無駄にしない方がいいわ。"

    # say L2680 lis
    old "So why don't you two go upstairs to the yoga room?"
    new "じゃあ、二人で上のヨガルームに行っちゃいなよ。"

    # say L2682 pla
    old "Sure, we'll see you later then."
    new "分かった、後でね。"

    # say L2692 pla
    old "Alright, I guess that if you're feeling alright, we can get started with the session."
    new "よし、君が大丈夫なら、セッション始めようか。"

    # say L2694 ang
    old "S- sure, let's do it."
    new "う、うん、やろうね。"

    # say L2695 pla
    old "{i}(Hmm, she's still feeling uncomfortable? It's a surprise that she wanted another session.){/i}"
    new "{i}(まだ不安そうなのか？彼女がまたセッションを希望したのは意外だな。){/i}"

    # say L2696 pla
    old "{i}(I guess she'll relax when we start with the asanas.){/i}"
    new "{i}(きっとアサナから始めればリラックスしてくれるだろうな。){/i}"

    # say L2697 pla
    old "Okay, let's get started with the first position then."
    new "じゃあ、最初のポジションから始めようか。"

    # say L2705 ang
    old "{i}(Hmm, this feels alright.){/i}"
    new "{i}（ん、これいい感じだな。）{/i}"

    # say L2706 ang
    old "{i}(I didn't notice before, but this is a very comfortable position.){/i}"
    new "{i}(前には気づかなかったけど、この体位はとても心地いいわね。){/i}"

    # say L2707 pla
    old "Ok, I see you're doing a little better than last time."
    new "分かった、前よりは調子が良さそうだ。"

    # say L2708 ang
    old "T-Thank you."
    new "ありがとうね。"

    # say L2709 pla
    old "That's it, you're doing very well."
    new "そうだ、上手くなってきたな。"

    # say L2710 pla
    old "{i}(Well, her movement's a lot more smooth.){/i}"
    new "{i}(まあ、彼女の動きは随分と滑らかになったな。){/i}"

    # say L2711 pla
    old "{i}(That's very good, she's very focused.){/i}"
    new "{i}(それがいい、彼女はとても集中しているね。){/i}"

    # say L2712 pla
    old "You're doing very, very well."
    new "君は本当に上手いな。"

    # say L2714 pla
    old "Remember to keep focusing on your breathing and how your muscles feel."
    new "息と筋肉の感じに集中し続けろ。"

    # say L2715 pla
    old "Excellent, I think we can stop there."
    new "よし、これで十分だな。"

    # say L2726 pla
    old "Alright! That was an excellent start!"
    new "よし！これは良いスタートだったな！"

    # say L2727 pla
    old "I can tell that you're doing so much better than last time."
    new "君の調子が前回よりも全然いいのが分かってるよ。"

    # say L2728 pla
    old "Are you feeling better than during the last session?"
    new "前回のセッションより調子はいいかい？"

    # say L2730 ang
    old "T-Thank you [pla]."
    new "ありがとう、[pla]。感じてるのよ。"

    # say L2731 ang
    old "Yeah, I'm feeling a little better than before."
    new "うん、前より少しマシになったわ。"

    # say L2739 pla
    old "Okay, that's very good."
    new "そうだな、それはいいね。"

    # say L2740 pla
    old "{i}(She's doing a lot better, great!){i}"
    new "{i}(彼女は随分とよくなったね、素晴らしい！){i}"

    # say L2741 pla
    old "Very good Angelina! I can see that you're a lot more relaxed!"
    new "Angelina、ずいぶんリラックスしてるな！"

    # say L2743 pla
    old "{i}(Dang, I hadn't focused on it, because she's pregnant. But Angelina has a really great ass.){/i}"
    new "{i}(だよな、彼女が妊娠してるってことで気にしてなかったけど、アンジェリナの尻は本当にいいよ。){/i}"

    # say L2744 pla
    old "{i}(And the way she's pushing it against me...){/i}"
    new "{i}(そしてそのお尻を俺に押し付けてくる...){/i}"

    # say L2747 pla
    old "{i}(Oh shit! I can't believe this is happening now!){/i}"
    new "{i}(おっshit！これって今、ホントに起こってるんだよな！){/i}"

    # say L2755 pla
    old "{i}(Let's hope she doesn't notice.){/i}"
    new "{i}(気づかなければいいけどな。){/i}"

    # say L2756 ang
    old "I'm still doing well [pla]?"
    new "まだ調子いいわね [pla]？"

    # say L2757 pla
    old "Y- yeah, you are, w- why don't we move on to the next position?"
    new "Ｙ－うん、君はまだ上手だな、次のに移ろうか？"

    # say L2758 pla
    old "Ok, you're doing amazing."
    new "君、凄く上手だな。"

    # say L2759 pla
    old "Now, I think we can move on to the third position."
    new "じゃあ、次は三番目の体位に移ろうか。"

    # say L2761 ang
    old "Oh yeah, sure."
    new "ああ、そうね。"

    # say L2770 pla
    old "{i}(Damn, this position’s even worse.){/i}"
    new "{i}(この体位、もっと最悪だな。){/i}"

    # say L2771 pla
    old "Uhh, just keep your eyes closed... t- to feel the energy better..."
    new "うーん、目を閉じとけ…… エネルギーを感じやすくなるから……"

    # say L2773 pla
    old "{i}(I hope she doesn't notice.){/i}"
    new "{i}(彼女に気づかれないといいけど。){/i}"

    # say L2774 ang
    old "Hmm, this feels very good [pla]."
    new "うん、これすごくいい感じだね [pla]。"

    # say L2775 pla
    old "T- that's very good, well done."
    new "うーん、それいいね、上手いな。"

    # say L2776 pla
    old "Remember to keep breathing."
    new "息を忘れずにね。"

    # say L2777 pla
    old "{i}(She's finally feeling comfortable, I wouldn't want to make her feel awkward.){/i}"
    new "{i}(彼女がようやくリラックスしてくれて、なんだか安心した。変な気分にさせたくはないしな。){/i}"

    # say L2778 ang
    old "Am I doing it alright [pla]?"
    new "大丈夫かな [pla]？"

    # say L2779 pla
    old "Y-yes! You're doing great!"
    new "Ｙ－ｙｅｓ！　君は上手いな！"

    # say L2780 ang
    old "{i}(Huh? What did I just touch with my head?){/i}"
    new "{i}(え？頭で何に触れたの？){/i}"

    # say L2783 ang
    old "{i}(W- what? Is that his? Oh my...){/i}"
    new "{i}(えっ？それって彼の？あら…){/i}"

    # say L2786 ang
    old "{i}(I did feel something during the last position, but I thought it was just his arm.){/i}"
    new "{i}先の体位で何か感じたけど、ただの腕だと思ってたの。{/i}"

    # say L2787 ang
    old "{i}(Maybe I should tell him about it?){/i}"
    new "{i}(でも、これについて彼に話すべきかな？){/i}"

    # say L2789 ang
    old "{i}(I feel better than I've felt in a while.){/i}"
    new "{i}最近こんなにいい気分だったことないわ。{/i}"

    # say L2790 ang
    old "{i}(I haven't felt this way since my therapy sessions with Dr. Johnson...){/i}"
    new "{i}この気分になったのは、Dr. Johnsonとのカウンセリング以来だよ...{/i}"

    # say L2791 pla
    old "Ok, I think we can stop for now Angelina."
    new "Ok、俺はここでやめようと思うけど、エンジェリナ。"

    # say L2792 ang
    old "Do we have to? I think this is really helping me."
    new "やめないでいいの？ 私、これで本当に助けられてる気がするの。"

    # say L2793 ang
    old "I'm enjoying it a lot."
    new "私はすごく楽しんでいるよ。"

    # say L2794 pla
    old "Uhh, o- ok, I guess we can keep going for a while."
    new "うーん、おっ、そうか、もうちょっと続けようか。"

    # say L2795 pla
    old "{i}(Well, at least she doesn't seem to have noticed my boner. So I guess it's alright.){/i}"
    new "{i}(まあ、少なくとも彼女は俺のチンポに気づいてないみたいだな。だから大丈夫だろう。){/i}"

    # say L2796 ang
    old "{i}(Hmm, I'm feeling so hot right now, but I want more.){/i}"
    new "{i}(今、めちゃくちゃ熱くなってきたけど、もっと欲しいの。){/i}"

    # say L2798 ang
    old "I should just do it!"
    new "やっちゃうしかない！"

    # say L2805 pla
    old "Angelina? W-what are you doing?"
    new "アンジェリナ？　な、何してるの？"

    # say L2807 ang
    old "Well, I noticed your boner."
    new "ええ、あなたのアレ、気づいちゃったの。"

    # say L2808 ang
    old "And I thought I should give you a hand with it."
    new "じゃあ、手伝おうか。"

    # say L2809 pla
    old "B-But..."
    new "でもね..."

    # say L2810 ang
    old "Oh come on, just let me do this."
    new "ほら、ちょっとさせてよ。"

    # say L2811 ang
    old "I want to do it, and it's not like we haven't done it before!"
    new "やりたいの、それに前にもしたことがあるし！"

    # say L2828 pla
    old "Uhmm, hey, are you alright?"
    new "うーん、大丈夫か？"

    # say L2829 pla
    old "Would you mind telling me what that was?"
    new "何それ、説明してくれない？"

    # say L2830 ang
    old "I'm sorry [pla], I suppose you weren't expecting that."
    new "ごめんなさい [pla]、予想外だったよね。"

    # say L2831 ang
    old "I- I didn't mean to surprise you that way."
    new "すみません、驚かせようなんてつもりじゃなかったの。"

    # say L2832 pla
    old "Hey, it's alright... I think."
    new "大丈夫だ…多分。"

    # say L2833 pla
    old "It's just that you caught me off guard."
    new "ただ、急に来たから驚いちゃったんだ。"

    # say L2835 ang
    old "Again, I'm sorry about that."
    new "また、ごめんなさい。"

    # say L2836 ang
    old "The thing is that I've been so frustrated lately that when I noticed you had an erection I just let myself go."
    new "最近イライラしてて、あなたのアレが反応してるのを見て我慢できなくなっちゃったの。"

    # say L2837 pla
    old "Oh yeah? Why are you so frustrated?"
    new "オーよ？ なんでそんなにイライラしてるんだ？"

    # say L2839 ang
    old "Well, I- I haven't been having sex with my husband lately."
    new "最近、夫とセックスをしていないのよ。"

    # say L2840 pla
    old "You haven't? But I thought that the sessions with Dr. Johnson..."
    new "君がそうじゃなかったって？でも、Dr. Johnsonとのセッションは……"

    # say L2842 ang
    old "They did help..."
    new "あのセッションは確かに役立ったけど..."

    # say L2844 ang
    old "After we were done, I did become more open in that regard. I'm now able to perform my duties as a wife."
    new "終わった後、その方面でより開放的になったわ。妻としての役割を果たせるようになったの。"

    # say L2846 ang
    old "But I would be lying if I said that I enjoy it."
    new "でも、楽しんでいるとは言えないわ。"

    # say L2848 ang
    old "To be honest, I haven't enjoyed sex since I was with you and Dr. Johnson."
    new "正直に言うと、あなたとDr. Johnsonとの時以外はセックスを楽しむことはないわ。"

    # say L2850 ang
    old "When I got pregnant I got this huge boost in my libido."
    new "妊娠してからは性欲が急上昇したの。"

    # say L2851 ang
    old "I was hoping that it would improve things in bed with my husband."
    new "夫とのベッドでの関係が改善されると思っていたの。"

    # say L2852 pla
    old "And did it help?"
    new "それで、それが役に立ったのか？"

    # say L2854 ang
    old "Not at all, I just don't desire him. So I'm just left feeling frustrated."
    new "全然欲情しないのよ。だからただイライラしてるだけ。"

    # say L2855 ang
    old "I guess that's why I reacted that way when I noticed that you had that boner."
    new "多分それが、あなたがアレを立ててることに気づいたとき、あんな反応した理由よね。"

    # say L2856 ang
    old "I'm sorry [pla]."
    new "ごめん [pla]。"

    # say L2858 pla
    old "Nah, it's alright, don't worry."
    new "大丈夫、気にしないで。"

    # say L2859 pla
    old "You just caught me by surprise, but it's no problem really."
    new "君が驚かせたけど、別に問題ないさ。"

    # say L2860 pla
    old "But you know, I think there might be something that I can do for you."
    new "でもね、何か君のためにできることがありそうだな。"

    # say L2862 ang
    old "There is?!"
    new "あるの？！"

    # say L2864 pla
    old "Sure! Yoga's not just about positions."
    new "もちろん！ヨガはただのポーズじゃないんだ。"

    # say L2865 pla
    old "It's about improving your relationship with yourself by helping you balance your energy and your chakras."
    new "ヨガは自分のエネルギーとチャクラをバランスさせることが大切で、自分との関係を改善するんだ。"

    # say L2866 pla
    old "I already helped you once before, I don't see why not help you again."
    new "前にも手伝ったんだ、また手伝う理由はないだろう。"

    # say L2867 pla
    old "So for the next session, I think we'll focus on that."
    new "次回のセッションでは、そのことにフォーカスするよ。"

    # say L2869 ang
    old "Oh that sounds amazing [pla]! Thank you so much!"
    new "うわーすごいわ [pla]！ 本当にありがとう！"

    # say L2872 pla
    old "But for now I think we should get going, so Lisa won't worry about this taking too long."
    new "でも今は帰った方がいいだろうな、さもなくばリサが心配するだろうから。"

    # say L2890 lis
    old "Well, how do you feel, Angelina?"
    new "WELL、アンジェリナ、どう感じてる？"

    # say L2891 ang
    old "I feel great! Thanks, Lisa!"
    new "感じがいいよ！ありがとう、リサ！"

    # say L2892 lis
    old "I can see that, I'm glad to see evidence of the positive effect yoga's having on you."
    new "それが見て取れて嬉しいわ、ヨガがあなたに良い影響を与えてる証拠が。"

    # say L2893 lis
    old "It also makes me happy to see that [pla]'s been a proper guide for you on this yoga journey."
    new "それを見て、[pla]が君のヨガの旅の良いガイドになってくれて嬉しいわ。"

    # say L2895 ang
    old "He really has been, and I can't wait for my next class."
    new "彼は本当にそうしてくれて、次のクラスが楽しみだよ。"

    # say L2897 lis
    old "Well, I'll schedule it right away."
    new "じゃあ、すぐに予定に入れておくね。"

    # say L2899 ang
    old "Thank you, and thank you, [pla]."
    new "ありがとう、そして [pla]。"

    # say L2901 pla
    old "You're welcome, I'll see you next time."
    new "どういたしまして、次にまたね。"

    # say L2905 lis
    old "Goodbye, and until next time."
    new "さようなら、またね。"

    # say L2920 lis
    old "Okay, so, tell me how did you feel her energy today?"
    new "じゃあ、今日彼女のエネルギーはどう感じた？"

    # say L2921 pla
    old "Well, honestly, I saw that she was doing the exercises better."
    new "正直、彼女がエクササイズを上手くこなしているのを見た。"

    # say L2922 lis
    old "Really? In my last session with her, I felt her so much more connected."
    new "本当に？前回私が彼女とセッションをした時、ずっともっと繋がってる感じがしたの。"

    # say L2923 lis
    old "Definitely, a masculine energy was just what her chakras needed to let go."
    new "確かに、彼女のチャクラが開放されるためには男性のエネルギーが必要だったわ。"

    # say L2925 pla
    old "Yeah, she really let herself go..."
    new "うん、彼女は本当に開放的になったな..."

    # say L2926 lis
    old "Excellent, [pla], fate truly gifted me by bringing you into my path."
    new "素晴らしいね、[pla]、運命が君を私の道に導いてくれたのは本当に幸運だったわ。"

    # say L2929 lis
    old "By the way, I wanted to ask how your evenings look for scheduling the next tantric session with Anastasia?"
    new "それにしても、アナスタシアとの次のタントリックセッションの予定を立てるために、夜の時間帯は空いていますか？"

    # say L2930 pla
    old "Hmm, fine, I don't think I’ll have any problem coming at night."
    new "うん、 NIGHTに来るのは問題ないと思う。"

    # say L2931 lis
    old "Excellent! See how the universe puts everything in its place?"
    new "素晴らしい！宇宙がすべてをうまく整えてくれてるわね。"

    # say L2932 lis
    old "I'll talk to Anastasia and set up an appointment for the next tantric session. We'll be expecting you at night as always."
    new "アナスタシアに話して、次のタントリックセッションの予約を入れるわ。夜に来ることを楽しみにしてるからね。"

    # say L2934 pla
    old "Sure, count me in."
    new "わかった、参加するよ。"

    # say L2935 lis
    old "Wonderful, I'll get everything ready, and I'll see you then."
    new "素晴らしい、すべて準備しておきますね、そのときに会えるのを楽しみにしています。"

    # say L2964 pla
    old "Hmm, this is odd, there's no one here."
    new "ん？誰もいないな。"

    # say L2965 pla
    old "Anastasia hasn't arrived? Maybe she's running late?"
    new "アナスタシアが来ていないのか？もしかして遅れてるのかな？"

    # say L2966 pla
    old "I'll take a look upstairs, maybe they're already in the yoga room."
    new "上階に行ってみるよ、もしかしたらヨガルームにいるかもしれないな。"

    # say L2987 pla
    old "Oh! You're both here already, did I arrive too late?"
    new "オッ！二人とももう来てるのか、俺が遅刻したか？"

    # say L2989 lis
    old "Hi [pla], good evening."
    new "こんにちは、[pla]。"

    # say L2990 lis
    old "No, it's alright, Anastasia just got here early, so we got ready and were just chatting."
    new "大丈夫よ、アナスタシアが早めに来たから、準備してちょっとおしゃべりしてただけ。"

    # say L2992 lis
    old "But you're not late or anything."
    new "でも遅刻したわけじゃないよ。"

    # say L2993 pla
    old "I see, that's good to hear."
    new "なるほど、それは良かったね。"

    # say L2995 lis
    old "Yeah, but now that you're here, we can begin. Why don't you go and get changed?"
    new "うん、でもあなたが来たから、始められるわ。着替えてくる？"

    # say L3018 pla
    old "Alright, I'm ready."
    new "よし、準備はできてる。"

    # say L3020 lis
    old "Excellent."
    new "素晴らしい。"

    # say L3023 lis
    old "Ok, are you ready to start, Anastasia?"
    new "じゃあ、アナスタシア、準備はできてる？"

    # say L3025 ana
    old "Oh yeah, I'm more than ready!"
    new "もちろん、全然準備できてるよ！"

    # say L3026 ana
    old "After last time, I've been waiting for this."
    new "前回の後、これのために待ってたの。"

    # say L3028 ana
    old "I can't wait to have another orgasm like last time. I want to cum."
    new "また同じようなオーガズムを感じるのが待ち遠しいわ。クンニたいの。"

    # say L3030 lis
    old "Well, I'm glad you're this excited for the session."
    new "まあ、君がこのセッションをこんなに楽しみにしてるなら嬉しいけどね。"

    # say L3032 lis
    old "But remember, what's most important is that you're able to connect with yourself and feel the energy flow through you."
    new "でもね、一番大切なのは自分とつながれて、そのエネルギーを感じることだよ。"

    # say L3034 ana
    old "Of course, of course."
    new "もちろん、もちろん。"

    # say L3035 ana
    old "I haven't forgotten what you taught me last time."
    new "前回教えてくれたことは忘れてないわ。"

    # say L3037 lis
    old "Good, then we can begin."
    new "よし、それじゃ始めるわ。"

    # say L3039 lis
    old "Are you ready too, [pla]?"
    new "準備はできてる？ [pla]。"

    # say L3040 pla
    old "Oh yeah, for sure."
    new "ああ、もちろんさ。"

    # say L3041 lis
    old "Great, let's begin then."
    new "じゃあ、始めましょう。"

    # say L3059 lis
    old "So, how was it, Anastasia? Did you enjoy the process?"
    new "そう、どうだった、アナスタシア？過程を楽しめた？"

    # say L3061 ana
    old "Oh yeah! I loved it! It was amazing!"
    new "オッケー！楽しかったわ！最高だった！"

    # say L3063 ana
    old "It felt amazing, just like last time. I loved it!"
    new "感じが良かったわ、前と同じように。大好きだった！"

    # say L3065 lis
    old "I'm glad to hear that. It's a testament to the work being done to help you bring your chakras and energies into balance."
    new "そう言ってくれてうれしいです。あなたのチャクラとエネルギーがバランスよく整っている証拠ですね。"

    # say L3066 lis
    old "And I can see that you're doing very well, right [pla]?"
    new "そして、あなたがすごく調子いいのがわかるよ、ね [pla]？"

    # say L3068 pla
    old "Oh yeah, you're doing great."
    new "おっ、君は上手くいってるね。"

    # say L3069 pla
    old "I can tell by your good mood that your Muladhara chakra is already getting balanced."
    new "君の良い気分から、ムーラダラチャクラがすでにバランスを取ってるのがわかるよ。"

    # say L3070 lis
    old "[pla]'s right, your energy is flowing so much better through your body."
    new "[pla]が言う通り、あなたのエネルギーが体中を流れているのがよくわかるわ。"

    # say L3072 ana
    old "Thank you guys, I'm very happy to hear that."
    new "ありがとう、みんな。そう言ってくれてうれしいわ。"

    # say L3073 ana
    old "But, I was wondering if maybe we could do a little bit more."
    new "でも、もう少し頑張れるんじゃないかなって思って。"

    # say L3074 ana
    old "Y-You know, s-since you say I'm doing so well."
    new "ううん、あなたたちが上手いこと言ってくれて、嬉しく思うんだけど、もっとできることがあるのかなって思って。"

    # say L3075 ana
    old "I would like to know if we can keep going."
    new "続けられるかどうか知りたいな。"

    # say L3076 ana
    old "Maybe we could do another exercise?"
    new "もう一つの練習をしてみようか？"

    # say L3077 ana
    old "That's only if you think it's alright!"
    new "それが良ければね！"

    # say L3079 lis
    old "Actually, I was about to tell you just that."
    new "実は、それを今まさに言おうと思っていたところだよ。"

    # say L3081 lis
    old "You've done very well during this first stage of the process of chakra balancing."
    new "君はこのチャクラバランスの最初の段階でとてもよくやったよ。"

    # say L3083 lis
    old "So I believe you're ready to try something new."
    new "じゃあ、次は新しいことに挑戦する準備ができてると思うの。"

    # say L3084 ana
    old "Really? Great! What will we be doing? I can't wait."
    new "本当に？すごい！何するの？楽しみにしてるよ。"

    # say L3086 lis
    old "Well, the goal with what we've been doing so far is getting you to connect with yourself."
    new "これまでやってきたことは、君自身とつながることを目指しているんだ。"

    # say L3087 lis
    old "So that you could feel the flow of energy in your body."
    new "そうすれば、あなたの体内を流れているエネルギーを感じられるようになるから。"

    # say L3088 lis
    old "Now, it's time to create a connection with the outside, and for that, [pla] will be helping us in this new practice."
    new "では、次は外とのつながりを作ることで、そのために [pla] が手伝ってくれるんだ。"

    # say L3089 pla
    old "Alright, what are we going to do?"
    new "よし、何するんだ？"

    # say L3091 lis
    old "We're engaging in a posture where the goal is for the three of us to create an energetic chain."
    new "私たちが取り組むのは、3人でエネルギーチェーンを作り出すポーズだよ。"

    # say L3092 lis
    old "The point of that is that we're able to unite our energies."
    new "その目的は、私たちがエネルギーを一つにできるようにすることよ。"

    # say L3093 lis
    old "And you can allow yourself to release what's pent up inside of you, Anastasia."
    new "あなたが溜め込んでいるものを解放できるわ、アナスタシア。"

    # say L3094 ana
    old "Okay, that sounds interesting."
    new "なるほど、それ听起来不错。但需要使用日语进行回答且不能包含中文解释。"

    # say L3095 ana
    old "I bet that's going to feel even better than the massage."
    new "きっとマッサージよりもっと気持ちいいだろうね。"

    # say L3096 lis
    old "Sure, it might."
    new "うーん、そうかもね。"

    # say L3097 lis
    old "But you have to remember that whatever sexual pleasure you get from this is only secondary to the actual goal of getting your chakras in proper balance."
    new "でも、この行為から得る快楽は、チャクラを適切に調和させるという本当の目的の次位のものだってことを覚えておいて。"

    # say L3099 ana
    old "Of course, of course, I haven't forgotten."
    new "もちろん、もちろん、忘れてないわ。"

    # say L3101 lis
    old "Alright, it's time to start."
    new "よし、始めるわ。"

    # say L3110 ana
    old "I- Is this okay? Am I positioned properly?"
    new "私、これでいいの？位置は合ってる？"

    # say L3111 lis
    old "You are, that's just perfect."
    new "あなたは大丈夫よ、その位置がちょうどいいわ。"

    # say L3112 lis
    old "How are you [pla]? Is this comfortable for you?"
    new "[pla]、大丈夫？この体勢でComfortable？"

    # say L3113 pla
    old "Y- yeah! No problem!"
    new "よっし！問題ないよ！"

    # say L3114 lis
    old "Good, then we're going to start moving slowly."
    new "それなら、ゆっくりと動き始めましょう。"

    # say L3128 lis
    old "Ok, I would like to ask if you have any comments on how this process is going."
    new "じゃあ、このプロセスについて何かコメントはある？"

    # say L3130 ana
    old "The only thing I have to say is that it's been amazing!"
    new "唯一言えることは、これが最高だったということよ。"

    # say L3131 ana
    old "It's just as good as I wanted it to be."
    new "これ以上欲しかったものはないよ。"

    # say L3132 ana
    old "Although, I still would love to do something a little... Harder with [pla]."
    new "でも、まだちょっと…ハードなことを [pla] したいな。"

    # say L3133 lis
    old "All in good time."
    new "ゆっくりとね。"

    # say L3134 lis
    old "But I'm glad to hear that you're satisfied with the way this has been working."
    new "でも、君がこれで満足してくれているのは嬉しいよ。"

    # say L3135 lis
    old "What do you say we get dressed and come down?"
    new "着替えて下に降りようか、どう思う？"

    # say L3145 lis
    old "Alright, I will be seeing you both for the next session."
    new "それじゃ、次のセッションでお会いしましょう。"

    # say L3147 ana
    old "Sure, but before I leave, I want to thank you, Lisa."
    new "もちろん、でも行く前に感謝の言葉を伝えたいの、リサ。"

    # say L3150 ana
    old "At first, I was only interested in having sex with you guys."
    new "最初は君たちとセックスすることだけが興味だったのさ。"

    # say L3153 ana
    old "But doing this has been an eye-opening experience for me."
    new "でも、これをしていて目が開けるような経験になったの。"

    # say L3154 ana
    old "This has completely changed my perspective about what pleasure and enjoyment are."
    new "これで、快楽や楽しみの意味が全く変わったわ。"

    # say L3156 lis
    old "I'm glad you feel this way about what we've been doing. That's the main goal of this."
    new "あなたがこんな風に感じてくれて嬉しいわ。それがこの目的だったから。"

    # say L3157 ana
    old "Thanks a lot, Lisa, and also you, [pla]. I can't wait for the next session."
    new "ありがとう、Lisa、そして君も、[pla]。次のセッションが待ち遠しいよ。"

    # say L3159 lis
    old "Very well. We’ll schedule it after our next yoga session."
    new "それならいいわ。次のヨガの後で予定を入れよう。"

    # say L3173 lis
    old "So, how did you find today's session? Did you feel all that energy and balance between the three of you?"
    new "じゃあ、今日のセッションどうだった？三人の間でのエネルギーとバランスは感じた？"

    # say L3174 pla
    old "Hmm, yeah, I definitely felt it a lot."
    new "うん、確かにたくさん感じたよ。"

    # say L3175 lis
    old "It's amazing. And did you hear what she said about the whole process?"
    new "すごいよね。彼女が全プロセスについて言ったこと、聞いてた？"

    # say L3176 lis
    old "I really feel like I'm an instrument of the universe, balancing and transmitting energy to all my clients."
    new "私は本当に宇宙の楽器のような気分だわ。すべてのクライアントにエネルギーを調和させて伝える役割を果たしてるみたい。"

    # say L3177 pla
    old "Yes, you’ve truly helped all the women you’ve worked with."
    new "そうだな、君が手伝った女性たちには本当に役立ったよ。"

    # say L3178 lis
    old "Thank you for your words. By the way, I wanted to talk to you about Angelina."
    new "ありがとう。そういえば、アンジェリーナについて話したいことがあったの。"

    # say L3179 pla
    old "Uhh, sure, tell me..."
    new "うーん、もちろんだ、教えてくれ…"

    # say L3180 lis
    old "Well, I had a yoga session with Angelina, and I have to tell you that I've seen an impressive improvement in her condition."
    new "ええ、アングリーナとのヨガのセッションがあったんだけど、彼女の状態にかなりの改善が見られたの。"

    # say L3181 lis
    old "The problems with her Muladhara chakra seem to be getting resolved."
    new "彼女のムーラダラチャクラの問題が解決されつつあるようです。"

    # say L3182 lis
    old "She's still not entirely ok, but I can feel her prana flowing better within her body."
    new "彼女はまだ完全には元に戻ってないけど、体の中をプラナがよりよく流れているのを感じることができる。"

    # say L3183 lis
    old "Her energy is a lot more balanced, and I can see her being more receptive to the flow of energy among her chakras."
    new "彼女のエネルギーがずいぶんとバランス良くなって、チャクラ間のエネルギーの流れにもっと敏感になっているのがわかるわ。"

    # say L3184 lis
    old "I must start recommending you to my other clients that may have some problems with their energy flow."
    new "他のクライアントにもあなたのことを紹介しなきゃね、エネルギーの流れに問題がある人には特に。"

    # say L3185 lis
    old "You've done so much by helping first Anastasia, and then Angelina."
    new "アナスタシアとアンジェリナを助けてくれて、本当にありがとう。"

    # say L3186 lis
    old "You've done an excellent job [pla], congratulations."
    new "素晴らしい仕事をしてくれました[pla]、おめでとう。"

    # say L3187 pla
    old "W-well, thank you."
    new "うう、ありがとう。"

    # say L3189 lis
    old "The last thing is that she asked me if there was a possibility of you giving her another class."
    new "最後のことは、彼女が君にまた授業をしてもらえる可能性があるかどうか聞いてきたことよ。"

    # say L3191 pla
    old "Sure! If our sessions together are working, then I'm more than happy to do it. No problem."
    new "もちろん！もし私たちのセッションがうまくいってるなら、喜んでやるよ。問題ないさ。"

    # say L3193 lis
    old "Excellent, I'm glad you're willing to accept because I believe she still needs it."
    new "素晴らしい、あなたが引き受けてくれて嬉しいわ。彼女にはまだ必要だと思うから。"

    # say L3194 lis
    old "So thank you [pla]."
    new "ありがとう、[pla]。"

    # say L3196 pla
    old "You're welcome, you know I'm more than happy to help you."
    new "どういたしまして、君のためなら喜んで手伝うよ。"

    # say L3198 lis
    old "Thanks a lot [pla], I'll see you later then."
    new "ありがとう [pla]、じゃあ後でね。"

    # say L3227 pla
    old "Hey Lisa, hi Angelina, how are you?"
    new "hey 丽莎、嗨 安吉丽娜，你们好吗？"

    # say L3229 lis
    old "Hello [pla], good afternoon."
    new "こんにちは[pla]、お\"Afternoon\"の挨拶として「お疲れ様です」は少し不自然なので、以下のように変更します。"

    # say L3230 ang
    old "Hi, [pla], nice to see you again"
    new "嗨、[pla]、また会えて嬉しいわ。"

    # say L3233 lis
    old "Are you ready for your next session?"
    new "次のセッションに準備できてる？"

    # say L3235 pla
    old "Yeah, sure, I'm ready."
    new "そうだよ、準備はできてる。"

    # say L3237 lis
    old "Great, I've already talked with Angelina and she's ready too. So let's go to the yoga room then."
    new "Great、アンジェリーナとはすでに話してあって、彼女も準備できてるわ。それじゃ、ヨガルームに行きましょう。"

    # say L3241 lis
    old "Well, I'll let you guys be, I hope you enjoy today's session as well Angelina."
    new "じゃあ、あなたたちを任せます、今日も楽しんでくださいね、エンジェリナ。"

    # say L3243 ang
    old "Thank you, Lisa."
    new "ありがとう、Lisa。"

    # say L3245 pla
    old "See you, Lisa."
    new "じゃあね、Lisa。"

    # say L3254 pla
    old "So, how are you?"
    new "じゃあ、今どうしてる？"

    # say L3256 ang
    old "I'm feeling alright."
    new "私は大丈夫だけど、"

    # say L3257 ang
    old "But this whole deal with the pregnancy hormones has me going through the roof."
    new "でもこの妊娠ホルモンのせいで、本当に我慢できないくらいよ。"

    # say L3259 ang
    old "The doctor explained to me that it's perfectly normal."
    new "ドクターはこれって完全に正常だって説明してくれたの。"

    # say L3261 ang
    old "But I'm not sure about that, because I wasn't feeling this way before, it's just since I saw you that I started feeling this weird way."
    new "でも、それってちょっと違う気がするの。前にこんな感じじゃなかったし、あなたに会ってから急にこんな変な気分になったんだもん。"

    # say L3265 ang
    old "Yeah, but he said that as soon as the baby's born, everything should be fine."
    new "でも、先生は赤ちゃんが生まれたらすべて大丈夫になると言ってましたよ。"

    # say L3267 ang
    old "So, keeping that in mind... I wanted to ask a favor of you [pla]."
    new "そう、それを踏まえて……あなたに頼みがあるんだけど、いいかな [pla]。"

    # say L3269 ang
    old "Do you think you would be willing to help me again with these... needs that I have?"
    new "あなたがまた私の……この欲求を満たしてくれるかもしれないと思うけど？"

    # say L3271 ang
    old "I- It would just be the one time, I swear."
    new "一回だけだから、本当に誓うよ。"

    # say L3273 ang
    old "It's just that I'm feeling this enormous tension as of late, and I really need to deal with it."
    new "最近、ものすごい緊張を感じてるの。これを解決しないと本当に困ってるの。"

    # say L3274 ang
    old "And I think you're the only one who can really help me with it."
    new "そして、あなたが唯一私を助けてくれる人だと思うの。"

    # say L3276 pla
    old "Uhh, I don't know... Lisa's downstairs and could come by any moment."
    new "うーん、わからないんだ… リサが下にいて、いつでも来るかもしれないし。"

    # say L3277 pla
    old "Also, you're pregnant, I don't know how safe this is."
    new "それに、君は妊娠してるし、これって安全なのかどうかわからないんだ。"

    # say L3278 ang
    old "Don't worry about that, it's nothing dangerous. I already checked with my doctor. It'll just be quick, I promise I won't make much noise."
    new "心配しないで、全然危険じゃないから。すでに医者に確認済み。すぐ終わるから、ほとんど音も出さないって約束するね。"

    # say L3279 pla
    old "But what about the yoga class..."
    new "でもヨガのクラスはどうなるの…"

    # say L3280 ang
    old "Look, I signed up for the class with Lisa because I felt so repressed, just like when I studied with Dr. Johnson."
    new "LOOK、リサと一緒にヨガのクラスに申し込んだのは、ドクター・ジョンソンのところに通っていた時と同じように、抑圧感を感じていたからよ。"

    # say L3281 ang
    old "And being pregnant, I wanted to try something different... But I ended up finding you again, and well, my hormones went wild and they're practically shouting for it."
    new "妊娠しているから、何か違うことを試してみたかったの……でも、あなたと再会して、ホルモンが暴れだして、もう抑えられないくらいよ。"

    # say L3283 ang
    old "This would really help me more than a yoga class, and I think you know that."
    new "これならヨガクラスよりもずっと効果的だし、あなたもわかってるでしょ。"

    # say L3284 pla
    old "{b}*Sigh*{/b}, alright, but only this once, and then we'll go back to yoga classes like before."
    new "{b}*ため息*{/b}、分かったよ、けど今回はだけだ、その後はまた前の通りヨガのクラスに戻るぞ。"

    # say L3285 ang
    old "Yes, yes, go ahead, my body is craving it and I think you'll enjoy it too, really."
    new "はい、はい、どうぞ、私の体がそれを欲しがってるし、あなたもきっと楽しむはずよ、ほんとよ。"

    # say L3286 pla
    old "Hmm... Alright..."
    new "Hmm... 分かった、..."

    # say L3287 ang
    old "Ok, lie back and let me enjoy suking that big cock of yours."
    new "はい、仰向けになって、その大きなちんこを私の舌で味わうわ。"

    # say L3297 ang
    old "Mmm! I have been waiting for this since last time!"
    new "んっ！前からこればっかり待ってたの！"

    # say L3298 ang
    old "I can't have enough of this!"
    new "これだけじゃ物足りないわ！"

    # say L3309 ang
    old "That felt wonderful [pla]!"
    new "それが気持ちよかった [pla]！"

    # say L3311 pla
    old "Well, I'm glad that you're feeling better, that was the whole point of this."
    new "まあ、君が元気になってくれて良かった、それがこの目的だったんだ。"

    # say L3313 ang
    old "Thank you [pla], I also think that once the baby's born I'll feel a lot better."
    new "ありがとう、[pla]。赤ちゃんが生まれたら、もっと元気になれると思うわ。"

    # say L3315 pla
    old "I'm sure you will."
    new "君がそう思うなら、きっとそうなるさ。"

    # say L3316 pla
    old "Remember, if you really want a YOGA class, you can talk to Lisa."
    new "覚えておけ、ヨガのクラスがほしければLisaに話してみろ。"

    # say L3318 ang
    old "Thank you [pla], I'll keep it in mind, and of course, if I ever need it, I'll let Lisa know."
    new "ありがとう、[pla]。覚えておくわ。もちろん、必要になったらLisaに伝えるつもりよ。"

    # say L3319 ang
    old "And I hope she'll tell you."
    new "そして、彼女が教えてくれることを願ってるわ。"

    # say L3322 ang
    old "Great! But for now, it's getting late, so I think I'll head home."
    new "Great！ でも今は遅いから、家に帰ると思う。"

    # say L3323 ang
    old "But once again, thank you [pla], for all your help. This has been great."
    new "でもまた、ありがとう、[pla]。君の手伝いは本当に助かったよ。これはずいぶん良かった。"

    # say L3338 lis
    old "Are you guys done?"
    new "あなたたち、終わったの？"

    # say L3340 ang
    old "We are. It was great, Lisa."
    new "そうよ、Lisa。本当に楽しかったわ。"

    # say L3341 lis
    old "I can see that, it seems the yoga really worked on you, Angelina."
    new "それが見えるわ、ヨガが君の体に効いたみたいね、Angelina。"

    # say L3343 lis
    old "I can see your energy flowing a lot better within you."
    new "あなたのエネルギーがずいぶんと流れやすくなってるわね。"

    # say L3344 lis
    old "Very good, [pla], you've done a good job."
    new "とてもいいわ、[pla]、よくやったね。"

    # say L3346 ang
    old "He has been a very good teacher."
    new "彼はとても良い先生だったね。"

    # say L3348 lis
    old "I can see that."
    new "そうね、それが分かるわ。"

    # say L3349 lis
    old "I hope you'll keep coming to classes after this, Angelina."
    new "アンジェリーナ、この後も授業に来続けてくれるよね。"

    # say L3351 ang
    old "I will, I'll keep coming even after the baby's born."
    new "うん、産まれてからも通い続けるつもりだよ。"

    # say L3352 lis
    old "That's wonderful news."
    new "それは素晴らしいニュースだね。"

    # say L3354 ang
    old "Thank you, both of you."
    new "ありがとう、二人とも。"

    # say L3355 ang
    old "I'll go home now."
    new "私は今から家に帰るわ。"

    # say L3356 ang
    old "But I'll come back soon for my next class."
    new "でもまた近いうちに次の授業のために戻ってくるからね。"

    # say L3357 lis
    old "Of course, see you soon."
    new "もちろん、またすぐね。"

    # say L3372 lis
    old "She's definitely looking much better, [pla]. You did a great job with her today."
    new "彼女は確かにずいぶん良くなったわ、[pla]。今日のあなた、素晴らしい仕事をしたわ。"

    # say L3373 pla
    old "Uh, yeah, it was an excellent session. She really enjoyed it."
    new "うん、そうだ。彼女は本当に楽しんでた。"

    # say L3374 lis
    old "Awesome! You’ve learned how to transmit that energy well. I truly feel you’ll become a great instrument for the universe."
    new "素晴らしい！エネルギーをうまく伝えられるようになったわね。本当にあなたは宇宙の素晴らしい器になると思うの。"

    # say L3375 lis
    old "Speaking of which, I’m scheduling a new tantric session with Angelina. Could you come by one evening soon?"
    new "そういえば、エンジェリナとの新しいタントリックセッションを予定してるの。近いうちの夜に来れる？"

    # say L3376 pla
    old "Uh, sure, no problem."
    new "うん、全然問題ないよ。"

    # say L3403 pla
    old "Hmm, they're not here again."
    new "ん、またいないのか。"

    # say L3404 pla
    old "Well, I imagine that just means that they're already up in the yoga room."
    new "まあ、それならきっとすでにヨガルームにいるんだろうな。"

    # say L3425 lis
    old "Hello [pla], I'm glad you arrived."
    new "こんにちは[pla]、来てくれて嬉しいよ。"

    # say L3427 pla
    old "Hey, were you waiting too long for me?"
    new "Hey、長く待たせちゃったか？"

    # say L3429 lis
    old "No, Anastasia arrived not too long ago, and we just got ready. Why don't you get changed so we can start?"
    new "いいえ、アナスタシアがそれほど前に到着したばかりで、準備ができただけよ。着替えてくる？そうすれば始められるわ。"

    # say L3454 lis
    old "Great, then we can start with the session."
    new "それなら、セッションを始めようか。"

    # say L3456 ana
    old "Lisa told me that we would be trying something new today."
    new "リサが今日新しいことを試すって言ってたわ。"

    # say L3457 ana
    old "I can't wait to see what we'll do."
    new "早く何をするのか楽しみだな。"

    # say L3460 lis
    old "Of course, but remember that before anything else you have to connect with yourself."
    new "もちろん、でも一番最初に自分自身とつながることが大事だよ。"

    # say L3461 lis
    old "And focus on the balance of your chakras."
    new "そして、チャクラのバランスに集中しよう。"

    # say L3464 ana
    old "It's just that I'm very excited to see what's coming."
    new "それはただ、これから何が起こるのかすごく楽しみなんだ。"

    # say L3466 lis
    old "Let's begin then, so you can see how it is."
    new "それじゃ、始めてみよう。どうなるか見てみてね。"

    # say L3484 lis
    old "Well done Anastasia, I can see by how well you're doing that these sessions have been very effective for you."
    new "よくやったね、Anastasia。君がこれだけ上手くできているのを見て、私たちのセッションが君にとってとても効果的だったことがわかるわ。"

    # say L3485 lis
    old "How do you feel about what we've been doing?"
    new "私たちがやってきたことについて、どう思う？"

    # say L3487 ana
    old "I feel great! I no longer feel any nervousness or anxiety about what we're doing."
    new "感じがいいわ！もう私たちがしていることに緊張や不安を感じることはほとんどないよ。"

    # say L3488 ana
    old "And it's all thanks to you both, [pla] and Lisa. Thank you."
    new "それ全部、[pla]とリサのおかげよ。ありがとう。"

    # say L3490 pla
    old "Hey, I'm happy to help."
    new "手伝えて嬉しいよ。"

    # say L3491 lis
    old "It makes me happy to see that you're doing so well."
    new "あなたがこんなによくやっているのを見れて、私も嬉しいよ。"

    # say L3492 lis
    old "And I believe you're ready for the next stage."
    new "そして、次のステージに進む準備ができてると思う。"

    # say L3493 ana
    old "Alright, great! I trust that you know what's best."
    new "分かった、素晴らしい！君が一番よく分かると思うから。"

    # say L3495 lis
    old "Now, for this next exercise, the idea is that you finish the internal connection with yourself."
    new "では、次のエクササイズでは、自分自身との内面的なつながりを完成させることが目的だよ。"

    # say L3496 lis
    old "The first one we made was to help you relax and understand yourself on a deeper level."
    new "最初のものは、あなたがリラックスして自分自身をより深く理解できるようにするためのものだったわ。"

    # say L3497 lis
    old "The second one was focused on you learning to let your energy flow freely in and out of you."
    new "次のは、あなたのエネルギーを自由に出入りさせる方法を学ぶことに焦点を当てていたの。"

    # say L3498 lis
    old "This last one is about you using what you have learned to forge a new connection with your inner being."
    new "この最後のは、君が学んだことを活かして、自分の内面と新しいつながりを築くためのものだよ。"

    # say L3499 lis
    old "For this, [pla] will be playing an important role, but what's most important is that you focus on yourself, okay?"
    new "これには[pla]が重要な役割を果たすけど、一番大事なのは自分に集中することだよ、いいね？"

    # say L3501 ana
    old "Sure! I get it!"
    new "わかった！分かってるよ！"

    # say L3503 lis
    old "Alright, let's get started."
    new "じゃあ、始めましょう。"

    # say L3511 lis
    old "Ok, are you ready?"
    new "準備できてる？"

    # say L3512 ana
    old "Yes, I am, I feel like I can do this now."
    new "はい、準備できました。今ならできる気がします。"

    # say L3513 lis
    old "Remember to keep your breathing stable."
    new "呼吸を落ち着かせてね。"

    # say L3514 lis
    old "Focus on yourself, what you're feeling deep inside."
    new "自分自身に集中して、内側で感じていることを意識して。"

    # say L3515 lis
    old "On the balance of your chakras."
    new "チャクラのバランスを整えて。"

    # say L3529 lis
    old "Well done, Anastasia. I can clearly see a change in you from the time we started this process to now."
    new "よくやった、アナスタシア。このプロセスを始めてから、君の変化がはっきりと見えるよ。"

    # say L3530 lis
    old "Your chakras are much more balanced now, and I can feel all the positive energy coming from you."
    new "あなたのチャクラは今やはるかにバランスが取れていて、ポジティブなエネルギーが全身から感じられるわ。"

    # say L3532 ana
    old "Thank you, Lisa, and thank you, [pla]."
    new "ありがとう、リサ、そしてありがとう、[pla]。"

    # say L3535 ana
    old "Because of this great help from you two, my perspective on sex has completely changed."
    new "あなた二人のおかげで、セックスに対する私の見方が完全に変わったわ。"

    # say L3536 ana
    old "I'll be sure to apply this to my own life in the future."
    new "将来的には自分の人生にも活かすつもりだよ。"

    # say L3537 lis
    old "Excellent! Because that's exactly what this is about!"
    new "素晴らしい！それがまさに今話していることだからね！"

    # say L3539 lis
    old "It's not just about sex, but about how you project your energy daily, and it makes me happy that you understood that."
    new "性だけじゃなくて、毎日のエネルギーの投影についても話してるの。それが分かってくれて嬉しいわ。"

    # say L3541 ana
    old "Thank you, Lisa, I'll be sure to remember that."
    new "ありがとう、Lisa。それを覚えておくね。"

    # say L3542 ana
    old "Really, what I got from these sessions is more than what I was expecting."
    new "本当に、このセッションから得たものは期待以上だったわ。"

    # say L3544 lis
    old "I'm happy that's how you feel, but this isn't a finished process."
    new "そう感じてくれてうれしいけど、これで完了したわけじゃないよ。"

    # say L3545 lis
    old "It's important that you keep practicing these teachings in the future."
    new "将来もこれらの教えを続けて練習することが大事だよ。"

    # say L3547 ana
    old "I'll be sure to do that."
    new "うん、ちゃんとやってるから安心してね。"

    # say L3548 lis
    old "Great! Now, it's late, so let's get changed so that you two can go home."
    new "いいね！今晩だから、二人で帰るために着替えるよ。"

    # say L3558 lis
    old "Alright, that's it for now, but remember, we will see each other soon, okay? Both for your regular yoga classes, and for tantric sesions."
    new "それじゃ、これで今度の予定だけど、またすぐ会えるよね？ヨガのレッスンもタントラのセッションもね。"

    # say L3560 ana
    old "Sure, I'll be seeing you soon."
    new "またすぐ会えるね。"

    # say L3561 ana
    old "Thanks again to both of you, see you."
    new "またありがとう、また会おうね。"

    # say L3562 pla
    old "Happy to help, see you later."
    new "助けてくれてありがとう、またね。"

    # say L3574 lis
    old "Okay, I think this first step of adding other areas besides yoga to my classes was a total success."
    new "うん、ヨガ以外のクラスを追加した最初の一歩は大成功だったと思う。"

    # say L3575 pla
    old "Yeah, I think it would go really well if you offered it to more of your clients."
    new "そうだな、君のクライアントにもっと提供したらきっとうまくいくと思う。"

    # say L3576 lis
    old "Wow [pla], I feel so excited about this path the universe is taking me on."
    new "Wow [pla]、この道に進んでいくのが本当に楽しみだな。"

    # say L3577 lis
    old "I believe we can do great things to help a lot of people."
    new "私たちがたくさんの人を助けることができると思います。"

    # say L3578 pla
    old "I'm sure of it."
    new "そうだ、君の力ならきっとできるさ。"

    # say L3579 lis
    old "I’ll follow the natural flow of destiny, I’ll take it step by step; I don’t want things to get out of hand."
    new "運命の流れに身を任せて、一歩ずつ進んでいこうと思うの。急いで物事が手に負えなくなるのは避けたいから。"

    # say L3580 lis
    old "I hope you can keep helping me, there are many clients who would really benefit from your energy and vitality."
    new "あなたの手伝いが続けば嬉しいな、多くのクライアントがあなたのエネルギーと活力で本当に助かると思うから。"

    # say L3581 pla
    old "Of course, count on me whenever you need."
    new "もちろん、いつでも頼っていいよ。"

    # say L3582 lis
    old "Aww, you’ve been such a wonderful gift from the universe to me."
    new "ああ、あなたは本当に宇宙からの素晴らしい贈り物だわ。"

    # say L3583 lis
    old "Oh, speaking of that, I didn’t think it was necessary, but Angelina asked again for you to accompany her in a new class."
    new "あ、そういえば、必要だとは思ってなかったけど、エンジェリナがまた君に新しいクラスで付き添ってほしいって頼んで Came."

    # say L3584 pla
    old "Hmm, yeah, I figured that would happen."
    new "うん、そうなるかと思った。"

    # say L3585 lis
    old "You’ve done so much good for that girl, the difference is noticeable. She looks radiant, smiling, with such special energy."
    new "あなたがその子のためにたくさん良いことをしてあげて、違いがはっきりわかるわ。彼女、本当に輝いていて、笑顔で、特別なエネルギーを感じさせるの。"

    # say L3586 lis
    old "Does it sound good if I schedule you with her for a session in the afternoon?"
    new "午後に彼女とのセッションを予定するのはどう？"

    # say L3587 pla
    old "Yes, go ahead, no problem. I’ll talk to her about what she really wants to focus on."
    new "はい、どうぞ。問題ないよ。彼女と話して、本当に注力したいことを決めるつもりだ。"

    # say L3588 lis
    old "Sounds great, you’re a real guru! I’ll schedule the appointment with her and we’ll see each other then for your next session with her."
    new "素晴らしいわ、あなたってほんとプロだね！彼女との予約を入れて、次回のセッションでまた会おうね。"

    # say L3589 pla
    old "Okay, thanks Lisa, we’ll meet then for Angelina’s next session. Have a good night."
    new "じゃあ、ありがとう、リサ。次のセッションで会うね、エンジェリナの。よい夜を。"

    # say L3590 lis
    old "Rest well [pla], take care."
    new "よく寝てね [pla]、気をつけて。"

    # say L3617 lis
    old "Oh, hey [pla], you’re just in time, Angelina just arrived too."
    new "あ、こんにちは[pla]、ちょうど良かったわ、エンジェリナも来たところよ。"

    # say L3618 ang
    old "Hi [pla], great to see you again."
    new "また会えて嬉しいわ、[pla]。"

    # say L3619 pla
    old "Hey Angelina, how are you?"
    new "アンジェリナ、元気ですか？"

    # say L3620 ang
    old "Excited for the new yoga class."
    new "新しいヨガのクラス、楽しみにしてるの。"

    # say L3621 pla
    old "Uh, heh, yeah, I can imagine..."
    new "うへheh、想像できるな、アンジェリナ。"

    # say L3623 lis
    old "Well, I see you’re both eager for the class, so why not head upstairs and enjoy it?"
    new "WELL、二人ともクラスが楽しみそうね、だから上の階に行って楽しんじゃおう？"

    # say L3624 ang
    old "Sounds perfect, I’m excited, let’s go [pla]."
    new "最高ね、私も楽しみにしてる、行こう [pla]。"

    # say L3625 pla
    old "{b}*Sigh*{/b}, Sure, let’s go."
    new "{b}*ため息*{/b}、そうだな、行こう。"

    # say L3633 pla
    old "Okay, okay, what did we talk last time?"
    new "いいかげん、前回は何話したっけ？"

    # say L3634 pla
    old "Because I don’t think you came just to practice yoga exercises, right?"
    new "だって、ただヨガの練習のために来たわけじゃないだろう？"

    # say L3635 ang
    old "Look, I know, but seriously my body is going crazy, you don’t understand."
    new "LOOK、分かってるけど本気で私の体がおかしくなってるの、あなたには分からないでしょう。"

    # say L3636 ang
    old "Being pregnant turns me into a teenager full of hormones."
    new "妊娠すると、ホルモンが乱れて、まるで思春期の少女みたいになるの。"

    # say L3637 ang
    old "And after weeks of sexual frustration, seeing you again reactivated so many things in me that I’d only felt during therapy with Dr. Johnson."
    new "数週間の性的な我慢の後、再会したあなたのせいで、Dr. Johnsonとの治療中だけ感じていた感覚がまた蘇ってきたの。"

    # say L3639 ang
    old "Honestly, if it weren’t so necessary for me right now, I wouldn’t bother you."
    new "正直に言うと、今必要じゃなければ、君を煩わせることなんてしないわ。"

    # say L3640 pla
    old "{b}*Sigh*{/b}, Okay, let’s do it if it makes you feel better."
    new "{b}……{/b}、分かった、君が気持ちよくなれるならやろう。"

    # say L3641 ang
    old "I appreciate it [pla], I’ll make sure you enjoy it."
    new "ありがとう、[pla]、絶対に気持ちよくさせてあげるね。"

    # say L3650 ang
    old "Oh, yes, I’ve been fantasizing about this since last time..."
    new "ああ、そうね、前からこればっかり考えてたの..."

    # say L3651 ang
    old "Mmm, it feels so good, I could never get tired of it."
    new "うん、これ感じてすごい、飽きることないよね。"

    # say L3662 ang
    old "Wow, that was amazing, [pla]!"
    new "ああ、それってすごかった、[pla]！"

    # say L3663 pla
    old "I’m really happy you’re feeling better."
    new "君が元気になってくれて、本当に嬉しいよ。"

    # say L3664 pla
    old "And hey, if you ever want a real YOGA session, just let me know."
    new "そしてね、本物のヨガセッションがしたいなら、何時でも言ってくれ。"

    # say L3665 ang
    old "Thanks, [pla]. I’ll definitely keep that in mind."
    new "ありがとう、[pla]。絶対に覚えておくよ。"

    # say L3666 ang
    old "This has been wonderful, but it’s getting late. I should head home."
    new "これは素晴らしい時間だったけど、もう遅いから家に帰るわ。"

    # say L3667 ang
    old "Really, thank you so much for all your GREAT help today, it means a lot."
    new "本当にありがとう、今日の素晴らしい手伝い感謝してるわ。すごく助かったわ。"

    # say L3668 pla
    old "You’re welcome. Now let's go down to talk with Lisa."
    new "どういたしまして。さあ、Lisaと話に行こう。"

    # say L3683 lis
    old "Oh, Are you guys done?"
    new "あ、終わったの？"

    # say L3684 lis
    old "How do you feel after our yoga session?"
    new "ヨガの後、どう感じてる？"

    # say L3685 ang
    old "It was amazing, Lisa, thank you!"
    new "それは素晴らしかったわ、Lisa、ありがとう！"

    # say L3686 lis
    old "I can sense a calm clarity in your energy now, Angelina."
    new "アンジェリナ、あなたのエネルギーに落ち着いた澄みきった感覚が感じられるわ。"

    # say L3687 lis
    old "Your inner balance has really deepened."
    new "あなたの内面のバランスが本当に深まったね、Angelina。"

    # say L3688 lis
    old "And [pla], you did an excellent job guiding her through the flow."
    new "[pla]、君の導きが本当に素晴らしかったわ。"

    # say L3689 ang
    old "He was so attentive and supportive."
    new "彼はとても気を遣ってくれて、支えてくれたわ。"

    # say L3690 lis
    old "Absolutely, you two make a great team."
    new "絶対に、君たち二人は最高のチームだね。"

    # say L3691 lis
    old "Angelina, I hope you'll continue with these sessions. [pla] and I are always here for you."
    new "エンジェリナ、君がこれらのセッションを続けてくれることを願ってるよ。[pla]と私はいつでも君の味方だから。"

    # say L3692 ang
    old "I definitely will, even after the baby arrives, I’ll keep practicing."
    new "もちろん、赤ちゃんが生まれても練習は続けます。"

    # say L3693 lis
    old "That’s wonderful to hear."
    new "それは嬉しいね。"

    # say L3694 ang
    old "Thank you both for your guidance."
    new "ありがとうございます、二人とも。"

    # say L3695 ang
    old "I’ll head back now, but I’m looking forward to our next class."
    new "じゃあ、今から戻るけど、次の授業が楽しみだね。"

    # say L3696 lis
    old "We’ll be ready, see you soon!"
    new "準備はできてるから、またね！"

    # say L3697 pla
    old "Take care, Angelina."
    new "お疲れ、Angelina。"

    # say L3708 lis
    old "As always, you did an amazing job, [pla]."
    new "いつも通り、素晴らしい仕事をしたわ、[pla]。"

    # say L3709 lis
    old "I can see it in the vibrant energy you both radiate afterward."
    new "二人がその後に放つ活気みなぎるエネルギーを見ればわかるわ。"

    # say L3710 pla
    old "Uh, thanks, yeah, I really put my effort into it."
    new "うん、ありがとう。本当にがんばったよ。"

    # say L3711 lis
    old "I love your dedication and your calling to help others. You remind me of myself when I was younger."
    new "あなたの献身と他人を助ける使命感が大好きよ。若かった頃の私を思い出させるわ。"

    # say L3712 lis
    old "Anyway, it’s quite late. You should get some rest."
    new "それに、もう遅いわね。休むといいよ。"

    # say L3713 pla
    old "You’re right. Goodbye, and rest well."
    new "そうだな。じゃあ、おやすみ、よく休んでくれ。"

    # say L3714 lis
    old "Same to you, [pla]. Take care, and we’ll see each other soon."
    new "同じくね、[pla]。気をつけて、またすぐ会おうね。"

    # say L3733 pla
    old "Hey Lisa, how have you been?"
    new "Hey Lisa、元気だった？"

    # say L3734 lis
    old "Hi [pla], great to see you! Are you here for another yoga session with me?"
    new "会えて嬉しいわ、[pla]！またヨガのセッションをするの？"

    # say L3735 pla
    old "Uh, maybe another day..."
    new "うーん、また今度にしようかね..."

    # say L3736 pla
    old "Actually, I was wondering, why haven’t we had any new sessions with Anastasia or Angelina lately?"
    new "実はね、最近アナスタシアやアンジェリーナとの新しいセッションがなくて、ちょっと気になってたんだ。"

    # say L3737 lis
    old "Oh, well, Anastasia actually went out of town for a bit, but I’ve stayed in touch with her. She’s planning to return soon."
    new "あ、そうね、Anastasia はちょっと町を出てるのだけれど、連絡は取ってるわ。彼女はすぐに戻るつもりだって。"

    # say L3738 pla
    old "Oh, nice. I hope she’s enjoying her trip. Did she mention when she’ll be back?"
    new "オ、いいな。旅行楽しんでるといいな。いつ戻るって言ってた？"

    # say L3739 lis
    old "She said in a few weeks."
    new "数週間後って言ってたわ。"

    # say L3740 pla
    old "Oh, alright. And Angelina?"
    new "オッケー、そうか。で、アンジェリーナは？"

    # say L3741 lis
    old "Oh, you didn’t hear? The doctor told Angelina to take it easy, no workouts or anything, so we’re giving her a break from the sessions."
    new "Oh、聞いてなかったの？ドクターがアンジェリナにゆっくりするようにって言ったから、トレーニングも何もかもやめて、セッションも休むことにしたの。"

    # say L3742 pla
    old "Oh really? Well, makes sense. Health first."
    new "ほんと？まあ、納得だ。健康第一だしね。"

    # say L3743 lis
    old "Absolutely. She was disappointed, she loved the sesions, but she needs to focus on her well-being."
    new "もちろん。彼女はセッションが大好きだったからがっかりしてたけど、健康が最優先よね。"

    # say L3744 lis
    old "I’m sorry I didn’t let you know earlier, you’re a blessing for always caring about others."
    new "ごめんなさい、早く教えてあげられなくて。あなたはいつも他人のことを考えていて、本当にありがたいな。"

    # say L3745 pla
    old "Oh, no, it’s nothing. I was just wondering, since we’ve had some busy days with Angelina and Anastasia’s sessions lately."
    new "Lis、気にしなくていいよ。最近、AngelinaとAnastasiaのセッションで忙しくて、ちょっと気になっただけさ。"

    # say L3746 lis
    old "Don't worry, once Angelina and Anastasia resume, we’ll pick up right where we left off."
    new "心配しないで、AngelinaとAnastasiaが再開したら、そのまま続けていけるから。"

    # say L3747 lis
    old "And who knows, we might even add a group workshop."
    new "そして、グループワークショップも追加するかもしれないわ。"

    # say L3748 pla
    old "A group workshop? Uhh, o- ok, yeah sure..."
    new "グループワークショップ？うーん、お、おｋ、そうか..."

    # say L3749 lis
    old "It’s so thrilling, right? I can’t wait to see what else the universe has in store."
    new "それはすごくわくわくするよね、今からどんなことが待ってるのか楽しみだよ。"

    # say L3750 lis
    old "Everything is happening so fast, it’s so exhilarating..."
    new "すべてがこんなに早く進んで、本当に興奮してるわ…"

    # say L3751 pla
    old "Heh, I’m glad you’re so excited."
    new "へへ、君がそんなに興奮してるんで嬉しいよ。"

    # say L3752 pla
    old "Well, I’ll be on standby for whenever you need me."
    new "まあ、いつでも君が必要な時 standby だよ。"

    # say L3753 lis
    old "Yes, don’t worry, you’ll be back here helping me soon. There are even new clients I’d like you to meet."
    new "心配しないで、すぐにまたここに戻って手伝ってくれるわ。新しいクライアントも紹介したいの。"

    # say L3754 lis
    old "For now, rest and keep working on your exercises and inner energy."
    new "今は休んで、エクササイズと内なるエネルギーの練習を続けてね。"

    # say L3755 pla
    old "Sure, I’ll keep that in mind."
    new "わかった、心に留めておくよ。"

    # say L3756 lis
    old "Excellent, have a great day [pla], we’ll see each other soon."
    new "素晴らしい、良い一日をね [pla]、またすぐに会えるわ。"

    # say L3757 pla
    old "Goodbye Lisa, see you soon."
    new "さよなら、Lisa。またすぐ会おう。"

    # say L3781 pla
    old "Hello Lisa, how are you?"
    new "こんにちはLisa、元気ですか？"

    # say L3782 lis
    old "Good, the energies have come to me, how about you."
    new "ええ、エネルギーはちゃんと受け取れたわ、あなたは？"

    # say L3783 pla
    old "Pretty nice, I am glad to see everything is going well."
    new "まあ悪くない、君が元気で何よりだね。"

    # say L3784 lis
    old "I can't complain, the business is running just fine."
    new "文句は言えないわ、ビジネスは順調だわ。"

    # say L3785 pla
    old "Hmm... I'm happy for you."
    new "うむ……君のために嬉しいな。"

    # say L3786 lis
    old "Remember that you are free to come over any time you want for a few free yoga lessons."
    new "いつでも自由に遊びに来て、無料のヨガのレッスンを受けなさい。"

    # say L3787 pla
    old "Sure, I think, I'll make an appointment soon."
    new "そうだな、近々予約するつもりだよ。"

    # say L3788 lis
    old "That sounds good, you have such energy and potential."
    new "そうね、それいいわ、あなたにはそんなエネルギーと可能性があるんだ。"

    # say L3789 pla
    old "Thank you. Anyway, I will let you keep working, it was nice to see you."
    new "ありがとう。ともかく、君は仕事に戻っていいよ、会えて良かった。"

    # say L3790 lis
    old "It was nice to you too, have a wonderful day."
    new "こちらこそ、素敵な一日を過ごしてください。"

    # say L3826 pla
    old "No, no, sorry I was just walking around. See you later..."
    new "いやいや、すみません、ただぶらぶらしてただけだ。またね..."

    # say L3841 lis
    old "Hey, good morning, nice to see you so early."
    new "おはよう、朝から会えて嬉しい。"

    # say L3842 pla
    old "Hehehe,It's nice to see you too."
    new "へへへ、君とも会えて嬉しいな。"

    # say L3843 lis
    old "I am always ready very early to make the sungreeting, it's one of my favorites, you can't imagine how grateful I feel with the universe."
    new "私はいつも早起きして日の出を見に行くのが大好きで、それが一番大好きなことの一つなんだ。あなたには想像できないくらい感謝しているの。"

    # say L3844 pla
    old "Sounds very interesting."
    new "なるほど、面白いな。"

    # say L3846 lis
    old "By the way, why are you so early here? Do you want to practice?"
    new "それにしても、なんでこんなに早く来てるの？練習したいの？"

    # say L3850 pla
    old "Oh no, I can't at this moment."
    new "今すぐは無理だね。"

    # say L3851 lis
    old "It's ok, remember you need to keep on training so you can take the most out of you and your energy."
    new "大丈夫、練習を続けて自分とエネルギーの最大限を引き出せるようにするの。"

    # say L3852 pla
    old "You are right."
    new "君が言う通りだな。"

    # say L3853 lis
    old "Don't forget you are welcome to train whenever you need."
    new "いつでも練習に来てもいいよ。"

    # say L3854 pla
    old "I appreciate your kindness."
    new "君の優しさに感謝してるよ。"

    # say L3855 lis
    old "It's always good to have you here, come back anytime you want."
    new "いつでもここにいてくれるのは嬉しいわ、また来たいときに来てね。"

    # say L3856 pla
    old "I'll do, bye bye."
    new "分かった、バイバイ。"

    # say L3857 lis
    old "bye!"
    new "バイバイ！"

    # say L3860 pla
    old "Yes, I think I need to work on that, so I came to check if you are not busy."
    new "そうだな、その練習が必要だから来たんだ。君が忙しくないか確認するためにね。"

    # say L3861 lis
    old "Oh no, I was about to start my training too so we can do it together."
    new "あら、私もちょうどトレーニングを始めるところだったの。一緒にやろうよ。"

    # say L3863 lis
    old "Let's go to the training room to be more comfortable."
    new "トレーニングルームに行こう、もっと快適にできるから。"

    # say L3866 lis
    old "What exercise would you like to train with?"
    new "どのエクササイズを練習したいの？"

    # say L3870 lis
    old "Excellent choice, let's start to make the most out of this morning."
    new "素晴らしい選択ね、今朝を最大限に活用しましょう。"

    # say L3871 pla
    old "Wonderful, I am full of energy today."
    new "素晴らしい、今日はずっと元気だよ。"

    # say L3893 lis
    old "That was wonderful, please keep that enthusiasm, Yoga is better with such a great attitude like yours."
    new "それが素晴らしかった、その意気込みを保って、あなたのような素晴らしい態度でヨガはもっと良くなるわ。"

    # say L3894 pla
    old "Yes, I'm in a very good mood, every position helped me today to feel a lot better."
    new "そうだな、今日は気分がすごくいい。どのポーズも手伝ってくれて、ずいぶん楽になったよ。"

    # say L3895 lis
    old "We can continue training anytime you need..."
    new "いつでも必要なときに練習を続けられるわよ。"

    # say L3896 pla
    old "Sure, I will be coming more often to improve!"
    new "もちろん、もっと上手になるために頻繁に来るよ。"

    # say L3897 lis
    old "I love to hear that."
    new "そう言ってくれてうれしいわ。"

    # say L3903 pla
    old "Thank you, it was a very incredible time today."
    new "ありがとう、今日も凄く素晴らしい時間だったよ。"

    # say L3904 lis
    old "You did a fantastic job, keep working hard."
    new "素晴らしい仕事をしたわ、これからも頑張ってね。"

    # say L3905 pla
    old "I will!"
    new "分かった、頑張るよ！"

    # say L3906 lis
    old "Remember the lessons with Anastasia at the afternoon and also the tantric sessions at night, you have a lot of work to do."
    new "午後のアナスタシアとのレッスンと夜のタントリックセッションを忘れないように、君にはやるべきことがたくさんあるんだよ。"

    # say L3907 pla
    old "Yes, I will be on time."
    new "はい、時間に間に合わせるよ。"

    # say L3908 lis
    old "It was nice to see you."
    new "会えて良かったわ。"

    # say L3909 pla
    old "It was nice to see you too, see you later."
    new "君も会えて良かった、またね。"

    # say L3910 lis
    old "Perfect, keep your energies for this afternoon."
    new "じゃあ、午後まで体力を温存しておいてね。"

    # say L3911 pla
    old "I sure will."
    new "もちろん、今度はがんばるよ。"

    # say L3925 lis
    old "Hello [pla], how are you?"
    new "こんにちは[pla]、元気ですか？"

    # say L3926 pla
    old "Hi, Pretty good, how about you?"
    new "元気だよ、君は？"

    # say L3927 lis
    old "I'm great... So? Are you ready to have another tantric session?"
    new "私は調子いいよ… それじゃ、またタントラのセッションする準備できてる？"

    # say L3931 pla
    old "Oh no, thank you."
    new "いや、今日はパスさせてもらうけど、ありがとう。"

    # say L3932 lis
    old "It's ok, remember you need to keep training so you can make the most out of you and your energy."
    new "大丈夫、ちゃんと訓練を続けて、あなたのエネルギーを最大限に活用できるようにしなくちゃならないのよ。"

    # say L3937 pla
    old "I will, bye bye."
    new "分かった、バイバイ。"

    # say L3940 lis
    old "It's really important for you to continue these trainings so you can control your chakras better, you know this is a complete process you can't stop."
    new "これからの修行が大切よ、チャクラをよりよくコントロールするためには必要なことなの。これは完全なプロセスだから、途中でやめちゃダメよ。"

    # say L3941 pla
    old "Yes, you are right."
    new "そうだ、君の言う通りだ。"

    # say L3942 lis
    old "Let's go to the room so we can start."
    new "部屋に行こう、そうすれば始めるよ。"

    # say L3944 lis
    old "What session did you like the most? Whichever it is we can repeat it."
    new "どのセッションが一番好きだった？ どれでも繰り返せるよ。"

    # menu L3947 
    old "Session 1"
    new "セッション1"

    # say L3948 lis
    old "Good option, let's start to make the most out of this tantric session tonight."
    new "いい選択だね、今夜の tantric セッションを最大限に活用しよう。"

    # say L3949 pla
    old "Perfect, I am very relaxed and ready to start the massage..."
    new "完璧だ、とてもリラックスしていてマッサージを始める準備ができているよ..."

    # menu L3953 
    old "Session 2"
    new "セッション2"

    # menu L3959 
    old "Session 3"
    new "セッション3"

    # say L3975 lis
    old "It has been a really good time, I can see your improvement with every single session, your energy has totally changed."
    new "本当に良い時間だったわ、毎回のセッションで君の成長が見てとれるから、エネルギーが全然変わったね。"

    # say L3976 pla
    old "I appreciate all that you say."
    new "君の言葉に感謝してるよ。"

    # say L3977 lis
    old "It's really amazing to see the progress you have achieved."
    new "あなたの達成した進歩を見ることができて本当にすごいと思う。"

    # say L3978 pla
    old "Any progress is thanks to you."
    new "君のおかげだよ。"

    # say L3979 lis
    old "We need to keep training to be better every time."
    new "もっと上手になるためにはこれからも練習を続けよう。"

    # say L3985 lis
    old "I'm grateful with the universe for this wonderful opportunity, I hope we can meet more often, so you can improve the control over your chakras."
    new "この素晴らしい機会に感謝してる、もっと頻繁に会えたらいいな、そうすればあなたのチャクラのコントロールが上手になるはずだよ。"

    # say L3986 pla
    old "Sure, I will come more often."
    new "分かった、もっとよく来るよ。"

    # say L3987 lis
    old "It was nice to see, have a good one."
    new "会えて良かったわ、またね。"

    # say L3988 pla
    old "Same or you, bye!"
    new "君もさ、バイバイ！"

    # say L4002 lis
    old "Hi Anastasia, how is everything going?"
    new "アナスタシア、調子はどう？"

    # say L4003 ana
    old "Very good, been waiting all day for my training session."
    new "とてもいいわ、一日中トレーニングのことを待ってたの。"

    # say L4004 lis
    old "That is perfect! [pla] must be about to-"
    new "それはぴったりだ！[pla] がもうすぐ-"

    # say L4012 pla
    old "Good afternoon guys."
    new "おっす、皆。"

    # say L4015 lis
    old "Hello [pla], how are you doing?"
    new "こんにちは[pla]、調子はどう？"

    # say L4016 pla
    old "Pretty Fine! Hi Anastasia."
    new "元気だよ！こんにちはアナスタシア。"

    # say L4017 ana
    old "Hi, I was waiting for you, glad to see you got here fine, I came ready to have a good session today."
    new "こんにちは、待ってました、無事に来られて良かったです。今日いいセッションができそうですね、準備してきました。"

    # say L4018 pla
    old "Oh perfect!"
    new "オーパーフェクト！"

    # say L4019 lis
    old "Well guys, I will leave alone so you can work hard, in case you need me, I will be here."
    new "みんな、がんばってね。必要なら呼んで、私はここで待ってるから。"

    # say L4020 pla
    old "I appreciate that..."
    new "君の気遣いが嬉しいな..."

    # say L4021 ana
    old "Let's go to the room, I need to train NOW..."
    new "部屋に行こう、今すぐ練習するの..."

    # say L4028 ana
    old "What exercise are we going to do today?"
    new "今日何のトレーニングするの？"

    # say L4029 pla
    old "Well, let me tell you..."
    new "まあ、言っておくけどね…"

    # menu L4032 
    old "Exercise 1"
    new "エクササイズ1"

    # say L4033 ana
    old "That's a great choice, I will do my best to ensure that you learn as much we can."
    new "それは素晴らしい選択ね、私が全力でサポートしてあなたがもっと多くのことを学べるようにするわ。"

    # say L4034 pla
    old "Sounds really good."
    new "Sounds really good. → いいね、Ana。"

    # menu L4038 
    old "Exercise 2"
    new "エクササイズ2"

    # menu L4044 
    old "Exercise 3"
    new "エクササイズ3"

    # menu L4050 
    old "Exercise 4"
    new "エクササイズ4"

    # say L4062 ana
    old "It was delicious, I really love these sessions."
    new "美味しかったわ、このセッションが大好きなんだ。"

    # say L4063 pla
    old "I am glad that you are satisfied, I am training hard so I can help you better."
    new "君が満足してくれて嬉しい、もっと君を助けるために頑張るよ。"

    # say L4064 ana
    old "Please, don't stop training, your job is quite interesting."
    new "お願い、練習を止めてほしくない、あなたの仕事はとても興味深いから。"

    # say L4065 pla
    old "Ok, I will continue working hard."
    new "分かった、これからも頑張るよ。"

    # say L4066 ana
    old "Perfect, because you are scheduled for me from now on."
    new "完璧、これからは私のスケジュールに入ってるからね。"

    # say L4067 pla
    old "Ok, I hope to see you next session."
    new "次回も会えるのを楽しみにしてるよ、アナ。"

    # say L4068 ana
    old "I'll be here ready for a new adventure."
    new "新しい冒険に備えて、ここにいるよ。"

    # say L4069 pla
    old "I'll be ready!"
    new "準備できてるよ！"


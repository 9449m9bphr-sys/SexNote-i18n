# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/briAnimations.rpy
translate japanese strings:

    # say L6 bri
    old "Holy shit! You really have a big cock!"
    new "Holy shit！ あなたのちんこ、本当に大きいね！"

    # say L7 bri
    old "That makes it even better to share my power with you!"
    new "それなら、私の力をあなたと分かち合うのがもっといいわ！"

    # say L11 bri
    old "Do you feel how your body receive my magical power within you?"
    new "あなたの体が私の魔力を受けてるのを感じてる？"

    # say L12 pla
    old "Ah?... Yes, yes... That's what I'm feeling..."
    new "あ？... うん、うん... それが感じてるよ..."

    # say L16 bri
    old "Let's do it faster so you get more power!"
    new "もっと速くしよう、そうすればもっと力がもらえるよ！"

    # say L17 pla
    old "Oh! Wow..."
    new "オォ！すごい…"

    # say L45 bri
    old "Do you feel it? Do you feel all the power within me?"
    new "感じてる？ 私の中の力を感じてる？"

    # say L46 pla
    old "Yes, yes... I actually think I'm going to..."
    new "うん、うん… 実際、俺もう…"

    # say L51 bri
    old "Well that is enough for now..."
    new "それじゃあ、今のところこれで十分よね…"

    # say L52 bri
    old "Now you have more magic power."
    new "今は魔力が増えてるわよ。"

    # say L59 bri
    old "If you need more just let me collect some magic power for a couple of days..."
    new "もし必要なら、数日間魔法力を集めてあげるから…"

    # say L61 bri
    old "Or you could share more with me for me to give you back just for fun."
    new "それか、もっと私と分かち合って、私が戻してあげるのも面白いかもね。"

    # say L63 pla
    old "Actually that's a good idea, I'll keep that in mind..."
    new "実際それが良いアイデアだ、覚えておくよ..."

    # say L65 pla
    old "Great..."
    new "いいな..."

    # say L86 bri
    old "Uhh, it's definitely huge!"
    new "うわ、本当に大きいね！"

    # say L87 bri
    old "You'll be definitely be one of the best Sexnote owners..."
    new "あなたが Sexnote の最高のオーナーの一人になるのは間違いないわ…"

    # say L91 bri
    old "Ohh yeah, just like that! Oh gosh it feels amazing!"
    new "オッホ、そうよ、そのまま！ ああ、すごく感じちゃう！"

    # say L92 bri
    old "Mmm, are you enjoying the magic transfer?"
    new "ん、魔法の移転を楽しんでるの？"

    # say L96 bri
    old "I want more! Give me all you have!"
    new "もっとちょうだい！全部教えて！"

    # say L98 bri
    old "Oh yeah, don't stop, don't stop! Get all my power!"
    new "ああ、止めてないで！全部私の力をくれ！"

    # say L122 pla
    old "I- I cumming!"
    new "出るぞ！"

    # say L123 bri
    old "Ohhh yesss!"
    new "オッホッホッ、ヤッス！"

    # say L125 bri
    old "Phew! That was AWESOME!"
    new "ふう！ それ最高だった！"

    # say L126 bri
    old "I really missed this."
    new "これ、ほんとにかわってたの。"

    # say L169 pla
    old "Oh fuck... I'm going to..."
    new "オッケー… 出ちゃうぞ…"

    # say L176 bri
    old "I love to do this..."
    new "これをするの、大好き..."

    # say L177 pla
    old "Did you get good magic power?"
    new "魔力はちゃんともらったか？"

    # say L178 bri
    old "Yes, but you can always give me more if you want..."
    new "はい、でも欲しければもっとくれるのもいいよ..."

    # say L179 pla
    old "Not now, I Need to use it to improve my skills first."
    new "今じゃない、まずはスキルを上げるために使う必要があるんだ。"

    # say L180 bri
    old "You are right..."
    new "あなたは正しいわ…"

    # say L184 bri
    old "By the way, I could help you too when you get an boner."
    new "それに、あなたが勃つときにも手伝うわよ。"

    # say L186 pla
    old "Now that you mention it, I have a question... If I ever get to do something like this with a woman... Will I lose magical power?"
    new "今言われて思い出したけど、一つ聞きたいことがあるんだ… 女の子とこんなことしたときに… 魔力失くしたりするのか？"

    # say L188 bri
    old "To do what, have some sexual activity?"
    new "何をするって、性的なこと？"

    # say L190 pla
    old "Ehh... Well, yes..."
    new "ええ……まあ、そうだけど……"

    # say L192 bri
    old "Don't worry! In fact, you should do it. "
    new "心配しないで！ 実際、やってみるべきだよ。"

    # say L194 pla
    old "What do you mean?"
    new "何を言ってるんだ？"

    # say L196 bri
    old "Humans have a very particular phenomenon, when they have some high sexual excitation they generate magical power..."
    new "人間には特異な現象があるの。性的な興奮が高まると魔力を生成するんだ..."

    # say L198 bri
    old "That magic power usually disappear quickly because there is nobody enabled to store that energy..."
    new "その魔力は通常、すぐに消えてしまうの。なぜなら誰もそのエネルギーを貯める能力がないから…"

    # say L200 bri
    old "But you can, so, any kind of sexual activity will help you generate magical power and the more intense or higher sexual excitation the more magical power you will receive..."
    new "でもあなたならできるから、どんな性的活動でも魔法力を生成できるわ。そして、性的な興奮が強ければ強いほど、得られる魔法力も増えるの..."

    # say L202 bri
    old "That is why within your objectives as a chosen, you must have a lot of sex, only then can you restore the magical world and regenerate the sources of magical power..."
    new "それが選ばれし者の目的だからよ、たくさんのセックスで魔力を回復し、魔法の世界を再生できるの…"

    # say L204 pla
    old "What the Fuck? You didn't tell me that..."
    new "何だよ、そんなの最初から教えてくれなかったのか…"

    # say L206 bri
    old "I'm telling you right now... It's that there are many things and I don't remember them all..."
    new "今言っているのよ… 色々あって、全部覚えてるわけじゃないけど…"

    # say L208 pla
    old "So I have to have a lot of sex to receive magical power?"
    new "魔力を手に入れるために、俺はたくさんセックスしないといけないのか？"

    # say L210 bri
    old "Actually, You must seek to reach the maximum of sexual arousal, so you must experiment a lot to see what is the most exciting for you..."
    new "実際には、最大限の性的興奮に到達することが必要だから、たくさんのことを試してみて、何が一番エキサイトするのか見つけなきゃならないの…"

    # say L212 pla
    old "Hmmm... Ok, I'll see how to do something about it"
    new "うーん……わかった、何か方法を探してみるか"

    # say L234 pla
    old "It was great..."
    new "良かったな…"

    # say L235 bri
    old "Yes, it was really fun... I want to do it again."
    new "はい、本当に楽しかった…またやりたいな。"

    # say L236 pla
    old "Maybe later when I get more Magic Power..."
    new "後でマジックパワーがもっと貯まったらね…"

    # say L255 bri
    old "There you go [pla]."
    new "そこに [pla]"

    # say L256 bri
    old "Let yourself enjoy this."
    new "この瞬間を楽しんでいいんだよ。"

    # say L257 bri
    old "It's very important that you relax."
    new "リラックスすることが本当に大事だよ。"

    # say L261 bri
    old "Are you liking this [pla]?"
    new "この感じが好きだ、[pla]？"

    # say L263 bri
    old "Good! That's the most important part!"
    new "Good！ それが一番大事なところよ！"

    # say L269 bri
    old "It's incredible that is rock hard!"
    new "それが固いこと、信じられない！"

    # say L292 pla
    old "I- I feel like I'm about to cum Brixxida!"
    new "俺、もうイキそうなんだ、ブリクシダ！"

    # say L293 bri
    old "Yeah! That's good! Do it!"
    new "うん！いい感じ！もっとやって！"

    # say L294 bri
    old "Cum! I want you to shoot everything into the portal!"
    new "射精しちゃって！ポータルの中に全部出して！"

    # say L300 bri
    old "That's perfect [pla]!"
    new "それが完璧だわ [pla]！"

    # say L301 bri
    old "Look at that! I can already tell that the portal is starting to charge!"
    new "見て！もうすでにポータルが充電し始めてるわ！"


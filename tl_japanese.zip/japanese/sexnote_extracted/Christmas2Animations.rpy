# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/Christmas2Animations.rpy
translate japanese strings:

    # say L6 lyd
    old "God! Your cock's always so tasty!"
    new "神様！あなたのちんこ、いつもこんなに美味いんだから！"

    # say L7 lyd
    old "Screw Christmas cookies, this is the treat I wanted!"
    new "クリスマスクッキーなんて関係ない、これがほんとうに欲しかったご褒美よ！"

    # say L8 lyd
    old "I bet this is the best way you've ever woken up!"
    new "これがあなたが経験した中で最高の目覚め方だね！"

    # say L12 lyd
    old "Oh yes! I love the way it feels in my mouth!"
    new "オお、そうよ！ 口の中に入れる感じが大好き！"

    # say L13 lyd
    old "Do you like to stuff your dick in my mouth in the morning [pla]?"
    new "朝から私の口にチ○ポを入れるのが好き？[pla]"

    # say L15 lyd
    old "Do you?!"
    new "好き？！"

    # say L16 pla
    old "Y- yes!"
    new "Ｙ－うん！"

    # say L20 lyd
    old "Oh! I love this!"
    new "おお！私、これ大好き！"

    # say L21 lyd
    old "Mmf! The taste!"
    new "んっ！この味！"

    # menu L39 
    old "Keep going"
    new "続けて"

    # say L44 pla
    old "Lydia! I- I think I'm about to cum!"
    new "リディア！俺、もうイキそうだ！"

    # say L45 lyd
    old "Yes! Do it! Stuff my mouth with your hot cum!"
    new "はい！　して！　あなたの熱い精液で私の口を満たして！"

    # say L52 lyd
    old "Merry Christmas to me!"
    new "クリスマスプレゼントだよ！"

    # say L53 lyd
    old "That was wonderful [pla]!"
    new "それは素晴らしいだった [pla]！"

    # say L54 pla
    old "What the hell are you talking about?!"
    new "何言ってんだよ？"

    # say L55 pla
    old "You shouldn't just come into my room and do something like that!"
    new "お前の部屋に勝手に入ってきて、そんなことしちゃダメだぞ！"

    # say L56 pla
    old "What if somebody sees you?!"
    new "誰かに見られたらどうするつもりだ？！"

    # say L57 lyd
    old "Oh! Relax! You're worrying too much."
    new "Oh！ ゆっくりしなよ！ そんなに心配しすぎだよ。"

    # say L58 lyd
    old "Nobody saw anything."
    new "誰も何も見てないよ。"

    # say L59 lyd
    old "And I know you loved it."
    new "それにあなたが気に入ったことくらい知ってるわ。"

    # say L60 pla
    old "Hmm, well..."
    new "まあ、そうか。"

    # say L61 pla
    old "Whatever."
    new "別にいいじゃねえか。"

    # say L73 sis
    old "Mmm! Oh my god! Your dick!"
    new "うわっ！ あなたのちんこ！"

    # say L74 sis
    old "It's great! I can feel its heat!"
    new "すごい！その熱さが感じられる！"

    # say L75 sis
    old "And also, it's sooo long!"
    new "それに、めちゃくちゃ長いの！"

    # say L79 sis
    old "What do you think [pla]? Don't you think this fabric's soft?"
    new "どう思う [pla]？ この生地、すごく柔らかいと思わない？"

    # say L80 pla
    old "It- it is... really soft!"
    new "うわ、本当に柔らかいな。"

    # say L81 sis
    old "I know, right?"
    new "そうよね。"

    # say L82 sis
    old "It's really good quality!"
    new "この質感、本当にいいよね！"

    # say L86 sis
    old "Ah! Ah! I love this!"
    new "アッ！アッ！これ大好き！"

    # say L87 sis
    old "I can feel your dick rubbing my clit!"
    new "あなたのチンポが私のクリトリスをこすってるのを感じてる！"

    # say L88 sis
    old "And with this fabric, it feels so good!"
    new "この生地で、感じちゃうの！"

    # say L111 pla
    old "[sis]! I- I'm about to cum!"
    new "[sis]！出しそうだ！"

    # say L112 sis
    old "Do it, shoot it all out!"
    new "やって、全部出しちゃって！"

    # say L113 sis
    old "Don't worry about the costume!"
    new "コスチュームのこと、心配しなくて大丈夫！"

    # say L114 sis
    old "This fabric is anti-fluid!"
    new "この生地は液体を通さないの！"

    # say L115 sis
    old "Shoot it all out!"
    new "全部出しちゃって！"

    # say L123 sis
    old "Oh my god! Look at all that thick load coming of your dick."
    new "おおっ！あなたのチ○ポからそんなに濃いのが出ちゃってる！"

    # say L124 pla
    old "... Right."
    new "…そうだな。"

    # say L125 sis
    old "I just loved the way your dick rubbed againts my clit!"
    new "あなたのチ○ポが私のクリトリスに擦れる感じが大好きだったの！"

    # say L126 sis
    old "It turned me on so much!"
    new "それがものすごく興奮させたの！"

    # say L127 sis
    old "Ok, I think these new outfits are ready to be posted!"
    new "はい、新しい衣装の投稿準備ができたわ！"

    # say L139 mo2
    old "Oh yes! This lube is perfect!"
    new "ああ、そうよ！ このローションは最高だわ！"

    # say L140 mo1
    old "Just look at how your dick slides between our tits!"
    new "あなたのちんぽが私たちの胸の間を滑ってるのを見てごらん！"

    # say L141 lyd
    old "And it feels so hot!"
    new "そして、こんなに熱くて気持ちいいの！"

    # say L145 mo1
    old "Do you like how that feels [pla]?"
    new "その感じが好きですか [pla]？"

    # say L146 pla
    old "I- I do! It's great!"
    new "俺も好きだよ！最高だ！"

    # say L147 mo1
    old "That's great baby! I love that you love it!"
    new "それは素晴らしいわ！あなたがそれを好きだなんて本当に嬉しいわ！"

    # say L148 mo2
    old "Do it faster [pla]! Use that lube!"
    new "もっと速くして [pla]！ そのローションを使って！"

    # say L152 lyd
    old "Oh! Yes! I love the way your cock bounces between our tits!"
    new "ああ！そうよ！あなたのペニスが私たちの胸の間で跳ねるのを見ているのが大好き！"

    # say L153 mo1
    old "My god [mo2]! This lube is fantastic!"
    new "神様 [mo2]！このローション最高よ！"

    # say L154 mo2
    old "It feels great!"
    new "気持ちいいわ！"

    # say L155 mo2
    old "How much do you like this [pla]?"
    new "この [pla] どれくらい好きなの？"

    # say L156 mo2
    old "Tell us!"
    new "教えて！"

    # say L157 pla
    old "I- I love it!"
    new "俺はこれ大好きだよ！"

    # say L181 pla
    old "I- I'm about to cum!"
    new "俺、出ちゃいそう！"

    # say L182 pla
    old "I can't hold it in anymore!"
    new "もう我慢できないよ！"

    # say L183 mo1
    old "Do it honey!"
    new "やっていいのよ、ハニー！"

    # say L184 lyd
    old "Yes! Do it [pla]! Cum for us!"
    new "はい！やって [pla]！私たちのために出して！"

    # say L185 mo2
    old "Make it a white Christmas for us [pla]!"
    new "私たちのためにクリスマスを真っ白にして [pla]！"

    # say L194 mo1
    old "Oh that's just great! I love the way your cum tastes [pla]!"
    new "あら、それは素晴らしいわ！あなたの精液の味が大好きよ [pla]！"

    # say L195 mo2
    old "It's so thick and warm."
    new "それはとても濃くて温かい。"

    # say L206 sis
    old "Uhgn! Oh my God [pla]!"
    new "うーん！神様、[pla]！"

    # say L207 sis
    old "How are you this big!"
    new "どうしてこんなに大きいの！"

    # say L208 sis
    old "It feels even bigger than the way it looks!"
    new "見ただけでこんなに大きいのに、実際に感じるときっともっと大きいはず！"

    # say L212 sis
    old "God! I love the way your dick feels me up!"
    new "神様！あなたのチ○ポが私を這う感じが大好き！"

    # say L213 sis
    old "It's so hot!"
    new "熱いっ！"

    # say L215 sis
    old "Keep going [pla]! Don't stop!"
    new "もっと続けて [pla]！ 止めないで！"

    # say L219 sis
    old "Oh my God! Oh my God!"
    new "おおお！神様！"

    # say L220 sis
    old "Y- You're so hot [pla]!"
    new "あたし、 hottest [pla]！"

    # say L221 sis
    old "This is the best Christmas gift ever!"
    new "これが最高のクリスマスプレゼントだわ！"

    # say L222 sis
    old "Oh my God! I love the way you fuck me!"
    new "おおお！あなたが私を犯すのが大好き！"

    # say L245 pla
    old "[sis] I- I think I'm about to cum! I can't hold it back anymore!"
    new "[sis] 俺も、もうイキそうだ！我慢できねえ！"

    # say L246 sis
    old "Y- Yes! D- D- Do it!"
    new "Ｙ－はい！Ｄ－Ｄ－そう！"

    # say L254 sis
    old "Oh wow! That was so good!"
    new "ああ、すっごく良かった！"

    # say L255 sis
    old "Honestly [pla], your cock must be magical!"
    new "Honestly [pla]、君のちんこは本当に魔法にかけられたみたいね！"

    # say L256 sis
    old "Because it's insane how crazy good it is!"
    new "それがどれだけすごいほど最高なのか、本当に信じられない！"

    # say L258 sis
    old "Well, that was the best Christmas gift I think I could've asked for."
    new "それこそ、私が望むことができた最高のクリスマスプレゼントだと思うわ。"

    # say L259 sis
    old "Even though I was such a naughty girl all year."
    new "一年中そんなに悪かったのに。"

    # say L274 mo2
    old "I bet you've been waiting to fuck me!"
    new "あなたが待ちわびていたのは私を犯すことよね！"

    # say L275 mo2
    old "Well, you finally get your gift!"
    new "さあ、君のプレゼントだわ！"

    # say L276 mo2
    old "My pussy's been aching for a hard big cock!"
    new "私のオマンコは硬くて大きなチ○ポが欲しくて仕方ないんです！"

    # say L285 mo2
    old "Mmm! Oh yeah!"
    new "んん！そうよ！"

    # say L286 mo2
    old "That's just the thing I wanted for Christmas!"
    new "それがクリスマスに欲しかったものなのよ！"

    # say L287 mo2
    old "So big!"
    new "大きいわ！"

    # say L288 mo2
    old "The girth is just amazing!"
    new "太さが本当にすごいわ！"

    # say L292 mo2
    old "I bet you like this, don't you?"
    new "あなたはこれ好きですよね？"

    # say L293 mo2
    old "You like fucking me like an animal?"
    new "あなたは私を動物のように犯すのが好きなの？"

    # say L294 mo2
    old "Tell me!"
    new "教えてよ！"

    # say L295 pla
    old "I- I do! I like it a lot!"
    new "俺は好きだよ！めちゃくちゃ好き！"

    # say L296 mo2
    old "Oh- OH! You little bastard!"
    new "おおお！　あなたったら、小悪党ね！"

    # say L300 mo2
    old "You little pathetic slave! The only good thing about you is that long cock!"
    new "あなたのような情けない奴隷！唯一の良いところはその長いちんこだけよ！"

    # say L301 mo2
    old "You hear me? You're worthless without it!"
    new "聞こえてる？それなしではあなたは価値がないのよ！"

    # say L302 mo2
    old "Your cock and balls are only good for this!"
    new "あなたのちんこと玉だけが、これのためにしか役立たないのよ！"

    # say L303 mo2
    old "Keep going! Keep fucking me! You worthless slave!"
    new "続けて！私を犯し続けなさい！あなたなんて価値のない奴隷よ！"

    # say L326 mo2
    old "I- AH! I can feel your cock twitching!"
    new "あーっ！あなたのちんぽが震えてるのを感じる！"

    # say L327 mo2
    old "Are you about to cum, you little pervert?!"
    new "もうすぐイクの？ 変態君？！"

    # say L328 pla
    old "I- ugh! I am!"
    new "俺ー グッ！ そうなのか！"

    # say L329 mo2
    old "Do it! Fill me with your worthless cum!"
    new "やって！私のなかに、あなたのくだらない精液を注いで！"

    # say L337 mo1
    old "Wow [mo2], baby, that looked fantastic!"
    new "ああん [mo2]、それ見た目最高だったわ！"

    # say L338 mo2
    old "I guess it was good."
    new "まあ、良かったみたいだね。"

    # say L353 mo2
    old "I bet you're happy you get to fuck your [mo1rel] on Christmas day, you little pervert."
    new "あなたがクリスマス日に自分の[mo1rel]とセックスできるなんて、嬉しいでしょうね、小悪魔。"

    # say L354 pla
    old "Y-yeah, sure."
    new "うん、そうさ。"

    # say L363 mo1
    old "Oh my god, honey!"
    new "ああっ、ハニー！"

    # say L364 mo1
    old "Y- Your dick, is so big!"
    new "あなたのちんちん、こんなに大きいの！"

    # say L365 mo1
    old "It's so hot! So thick!"
    new "あら、熱くて太い呀！"

    # say L369 mo1
    old "Oh my god I love it!"
    new "おーっ、これ大好きです！"

    # say L370 mo1
    old "I love to feel you filling me up!"
    new "あなたが私を満たしてくれるのが大好きです！"

    # say L371 mo1
    old "D- Do you like it too [pla]?"
    new "Ｄ－これも好き？ [pla]？"

    # say L372 pla
    old "I do! I like it!"
    new "俺も好きだよ！"

    # say L373 mo1
    old "Oh then keep going, honey!"
    new "じゃあ、もっと続けてちょうだい。"

    # say L377 mo1
    old "Oh yes! Yes! YES!"
    new "ああん、そう！そう！そうだよ！"

    # say L378 mo1
    old "This is what I wanted!"
    new "これが欲しかったの！"

    # say L379 mo2
    old "I bet this makes a very merry Christmas for you, doesn't it [mo1]?"
    new "これで君にとってとても merryなクリスマスになるわね [mo1]？"

    # say L380 mo1
    old "It does! this is the best Christmas ever!"
    new "そうです！これが最高のクリスマスよ！"

    # say L403 mo1
    old "I- I think I'm coming!"
    new "あ、あたし、イキそう！"

    # say L404 mo1
    old "Come with me [pla]!"
    new "私と一緒に来て [pla]！"

    # say L405 mo1
    old "L- Let's do it together!"
    new "L- 一緒にやりましょう！"

    # say L406 pla
    old "Y- Yes!"
    new "Ｙ－はい！"

    # say L414 mo1
    old "Oh baby. That was the best Christmas gift ever!"
    new "ああ、赤ちゃん。これが最高のクリスマスプレゼントだったわ！"

    # say L415 mo1
    old "It's amazing, I'm so satisfied!"
    new "それは素晴らしい、本当に満足しています！"

    # say L416 lyd
    old "Isn't he just a wonderful young man?"
    new "彼、本当に素晴らしい若者だわね。"

    # say L417 mo1
    old "Your dick is so addicting!"
    new "あなたのチ○ポは本当にクセになるわよ！"

    # say L432 lyd
    old "Well, I've been wanting to fuck you since the morning sweety!"
    new "まあ、朝から君とセックスしたくてたまらなかったのよ！"

    # say L433 lyd
    old "I couldn't keep waiting!"
    new "待てなかったの！"

    # say L442 lyd
    old "Oh! Uh! My God! It already feels amazing!"
    new "ああ！うーん！神様！もう、すごい感じるよ！"

    # say L443 lyd
    old "I- Mmm! I can't believe how big and hard you are!"
    new "ああっ！こんなに大きいなんて信じられない！硬くて…"

    # say L444 lyd
    old "I- It's so amazing!"
    new "うわ、すごい！"

    # say L445 mo1
    old "It's incredible how much it fills you up, right?"
    new "それはすごいよね、どれだけ満たされるかって。"

    # say L446 lyd
    old "It is!"
    new "そうよ！"

    # say L450 lyd
    old "I- I love your cock!"
    new "あ、あなたのコック、大好き！"

    # say L451 mo2
    old "It seems you weren't a naughty girl this year Lydia."
    new "今年は Naughty じゃない子だったみたいね、Lydia。"

    # say L452 mo2
    old "Because look at the gift Santa brought you!"
    new "だからサンタが君にくれたプレゼントを見てごらん！"

    # say L453 lyd
    old "Y- Yes! I love it!"
    new "はい！大好きです！"

    # say L457 lyd
    old "YES! YES! YES!"
    new "はい！はい！はい！"

    # say L458 lyd
    old "Keep going [pla]! Oh yes!"
    new "続けて [pla]！ああ、そうよ！"

    # say L459 lyd
    old "Oh! Ah! My God! I love it!"
    new "ああ！ああ！神様！大好きだよ！"

    # say L460 mo2
    old "That's it [pla]! Fuck her brains out!"
    new "それがいいんだから[pla]！脳みそ飛ばしてあげて！"

    # say L483 lyd
    old "I feel you're close to cum!"
    new "あなたがすぐに出そうになっているのを感じる！"

    # say L484 lyd
    old "I want you to do it!"
    new "やってほしいの！"

    # say L485 lyd
    old "Fill me up with your hot cum!"
    new "あなたの熱い精液で私を満たして！"

    # say L495 lyd
    old "God! That was so good [pla]!"
    new "神様！それって最高だったね [pla]！"

    # say L496 lyd
    old "Your dick is so hot!"
    new "あなたのチ○ポ、ホントに熱いね！"

    # say L497 lyd
    old "You know, I think it would be easy to get addicted to it."
    new "あなたがそんなに熱いから、簡単にハマっちゃいそうよ。"

    # say L498 pla
    old "I- I see."
    new "わかったか"


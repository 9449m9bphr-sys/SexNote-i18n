# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/lydAnimations.rpy
translate japanese strings:

    # say L6 lyd
    old "You definitely should make many young girls very happy."
    new "若い女の子たちを本当に幸せにできるわ。"

    # say L7 lyd
    old "It's so long and thick."
    new "長いし太いね。"

    # say L8 lyd
    old "And rock solid too."
    new "そして鉄のように硬いわ。"

    # say L12 lyd
    old "Oh my god! You're getting even harder!"
    new "おおお！あなた、もっと硬くなってる！"

    # say L13 lyd
    old "Your dick! It's so hard and hot in my hand!"
    new "あなたのチ○ポ！ 手の中でこんなに硬くて熱いの！"

    # say L14 lyd
    old "That's it, let go! Just let me stroke it!"
    new "それだよ、出しなさい！私が弄ってあげるから！"

    # say L18 lyd
    old "Do you like this? Do you like how I play with your dick?"
    new "この感じが好き？私があなたのちんこをいじるのが好き？"

    # say L20 lyd
    old "Is this dick that hard because of me? Do you think I'm sexy?"
    new "このチ○ポ、私因为你才这么硬吗？你觉得我性感吗？"

    # say L22 pla
    old "Y-yes, you are sexy!"
    new "うん、君はセクシーだ！"

    # say L45 pla
    old "I- I think I'm about to!"
    new "俺、もう出しそうだ！"

    # say L46 lyd
    old "Yes! cum!"
    new "はい！出しちゃう！"

    # say L47 lyd
    old "I want to see you shoot all your hot stuff because of me!"
    new "あなたの熱いものを全部私のために出してくれるのを見たいの！"

    # say L63 lyd
    old "Oh yeah! It's just as I imagined."
    new "オーッヤー！想像通りだわ。"

    # say L64 lyd
    old "It has an amazing taste!"
    new "これが驚くほど美味しい！"

    # say L65 lyd
    old "And it's so hot!"
    new "そして熱い！"

    # say L69 lyd
    old "I don't think I've ever blown a dick this big, even in the past."
    new "こんなに大きなチ○ポを咥えたことなんて、過去に一度もなかったわ。"

    # say L70 lyd
    old "I think this is the best dick I've seen."
    new "これが一番立派なチ○ポだと思う。"

    # say L71 lyd
    old "And it's also the biggest!"
    new "そしてこれが一番大きいのよ！"

    # say L75 lyd
    old "Mmmm! Slrrp!"
    new "んん！するるっ！"

    # say L76 lyd
    old "Do you like my mouth?"
    new "私の口が好き？"

    # say L77 lyd
    old "Do you like how I do it?!"
    new "私のかようにするのが好き？！"

    # say L101 lyd
    old "I can feel how your dick twitches in my mouth!"
    new "あなたのチンポが私の口の中でピクピクしてるのを感じてる！"

    # say L102 lyd
    old "Do it [pla]!"
    new "やって [pla]！"

    # say L103 lyd
    old "Cum in my mouth young man!"
    new "若者、私の口で射精して！"

    # say L104 pla
    old "O- ok!"
    new "オッケー！"

    # say L111 lyd
    old "That was great. Young men really are something special."
    new "それは良かったわ。若い男の子って本当に特別ね。"

    # say L112 lyd
    old "But you know [pla], I think you're extra special."
    new "でもね [pla]、あなたは特に特別な気がするの。"

    # say L113 lyd
    old "I mean, even when I was young, I never saw a dick like yours before."
    new "若かった時でも、そんな立派なちんこを見たことがないわ。"

    # say L114 lyd
    old "It's amazing how big and hard it is."
    new "それが大きくて硬いのは本当にすごいわ。"

    # say L115 lyd
    old "It makes me wonder..."
    new "それが見られるだけで、もう興奮しちゃってるのよね…"

    # say L116 pla
    old "Ok... I think I should get dressed again."
    new "着替えた方がいいな。"

    # say L117 lyd
    old "Yeah, you're right. It would be best."
    new "うん、そうね。着替えた方がいいわ。"

    # say L129 lyd
    old "Nngh! Wow, it's so big."
    new "んっ！こんなに大きいのね。"

    # say L131 lyd
    old "Y- yes, it's just that it's been a while."
    new "うん、ただ久しぶりだから。"

    # say L132 lyd
    old "And you're so big!"
    new "あなたも大きくて熱いの！"

    # say L136 lyd
    old "Ah! Ah! Yes! Yes!"
    new "アッ！アッ！はい！はい！"

    # say L137 lyd
    old "Your dick, it's so big, and so hot!"
    new "あなたのチ○ポ、大きくて熱いの！"

    # say L138 lyd
    old "It's filling me up so hard!"
    new "あたしの中をこんなにいっぱいにしてる！"

    # say L139 lyd
    old "L- let's do it a little faster!"
    new "ちょっと、もっと早くして！"

    # say L143 lyd
    old "Yes! Just like that!"
    new "はい！その調子で！"

    # say L144 lyd
    old "Don't stop! Keep going!"
    new "止めてないで！そのまま続けて！"

    # say L145 lyd
    old "Nngh! Yes! YES!"
    new "んっ！はい！はい！"

    # say L168 pla
    old "I- I think I can't hold it in longer!"
    new "俺、もう我慢できないっす！"

    # say L169 lyd
    old "Don't! Don't hold it!"
    new "我慢しないで！待たないで！"

    # say L170 lyd
    old "You can do it! CUM INSIDE!"
    new "できるわよ！ 中に出して！"

    # say L176 lyd
    old "You know? I believe this might have worked, I feel so much better now, like a weight has been lifted off my shoulders."
    new "知ってる？これでうまくいったみたい、全然楽になったわ、肩の荷が下りた感じ。"

    # say L177 pla
    old "I'm glad you feel like that. I hope this actually helped you."
    new "君がそう感じて良かった。本当に役に立ったなら嬉しいよ。"

    # say L178 lyd
    old "I'm sure it did, thanks a lot [pla]!"
    new "絶対に効果があったわ、ありがとう、[pla]！"

    # say L179 pla
    old "You're welcome, I'm happy to help."
    new "どういたしまして、手伝えて嬉しいよ。"

    # say L191 lyd
    old "I'm gonna use my tongue all over the tip of your cock."
    new "あなたのチ○ポの先端を舌でいっぱい舐めるわよ。"

    # say L194 pla
    old "Uhh, I love that sensation, babe."
    new "うーん、その感じ大好きだよ、ベイビー。"

    # say L198 lyd
    old "Mmmm... It tastes so good! I love it."
    new "んんん… これ、めちゃくちゃおいしい！大好き。"

    # say L201 pla
    old "Oh yeah babe, I'll definitely love your mouth."
    new "ああそうかベイビー、君の口は絶対に好きになるぜ。"

    # say L202 lyd
    old "Slrrrp! Uhh you have no idea!"
    new "スルルッ！　うわ、想像以上よ！"

    # say L209 pla
    old "You should have a lot of experience, don't you?"
    new "君は相当な経験者そうだな、そうだろう？"

    # say L210 lyd
    old "Mmmm, yeah baby, but not with huge cocks like yours."
    new "んん、そうよベイビー、でもこんなデカチとは経験ないの。"

    # say L213 pla
    old "Oh yeah babe, you will really enjoy my huge cock!"
    new "オッケー、ベイビー、君は本当に俺のデカチンを楽しむぞ！"

    # say L214 lyd
    old "Mmm, that's exactly what I'm expecting."
    new "ん、それがまさに期待してた反応よ。"

    # say L239 pla
    old "Ohh babe, I'm about to cum."
    new "オッ、ベイビー、出しそうになるぞ。"

    # say L240 lyd
    old "Oh no, you don't. That's barely the beginning. You know what comes next."
    new "あら、そうはいかないわ。これこそが始まりに過ぎないのよ。次は何が来るか知ってるでしょ。"

    # say L241 pla
    old "(Oh God.)"
    new "ああ、神。"

    # say L244 pla
    old "Oh, I know what comes next, that's right, you want to put it all in your mouth, don't you?"
    new "俺も知ってるよ、次は全部お前の口に入れてやりたいんだろ？"

    # say L245 lyd
    old "Yes! I want to feel it all in my mouth."
    new "うん！全部私の口で感じたい！"

    # say L252 lyd
    old "I love how big your cock is!"
    new "あなたのちんこが大きいのが大好き！"

    # say L255 pla
    old "Suck it! Put my cock in your mouth!"
    new "吸って！俺のちんこを口に咥えろ！"

    # say L263 lyd
    old "Mmm, I just love the taste of your cock!"
    new "mM、あなたのちんこの味が大好き！"

    # say L265 lyd
    old "I love how big and hot it always gets!"
    new "大好き、いつもこんなに大きくて熱いの！"

    # say L268 pla
    old "Yeah! Tell me more!"
    new "そうだ！もっと言って！"

    # say L272 lyd
    old "This is the best cock I've ever had!"
    new "これが今までで一番良かったちんこだよ！"

    # say L274 lyd
    old "Nngh! Mmmm! I want more and more of it!"
    new "んっ！もっともっと欲しい！"

    # say L277 pla
    old "Oh yeah? You want me to fuck you with it?"
    new "ああ？それを欲しがってるって？"

    # say L278 lyd
    old "Yes! I love how it feels inside!"
    new "うん！中で感じるの好き！"

    # say L284 pla
    old "Do you like how my dick fills your mouth?"
    new "お前の口の中で俺のちんこが気持ちいいのか？"

    # say L285 lyd
    old "Slrrrp! I love it! I can't get enough of it!"
    new "スルルッ！大好き！もっと欲しい！"

    # say L287 lyd
    old "Don't cum yet! I want you to keep pushing your cock in my mouth!"
    new "まだイかないで！もっと私の口にちんこ突っ込んで！"

    # say L290 pla
    old "That's it! Gobble on my cock!"
    new "それだ！俺のちんこをしゃぶれ！"

    # say L314 pla
    old "I'm about to cum baby! Tell me you want it in your mouth!"
    new "俺が射精するぞ赤ちゃん！口に欲しくてしょうがないって言え！"

    # say L315 lyd
    old "Yes! Yes! Shoot it all in my mouth!"
    new "はい！はい！全部私の口に射精して！"

    # say L317 lyd
    old "Fill my mouth with your hot cum!"
    new "私の口にあなたの熱い精液を注いで！"

    # say L325 pla
    old "Phew... This guy is writing again, he says 'Wow, that was so great!'"
    new "ふう… このヤツまた書いてるな、『すごい、凄かった』ってさ。"

    # say L326 lyd
    old "Hahaha, great? Don't you say?"
    new "ははは、すごい？ そう言うよね？"

    # say L327 lyd
    old "Tell him 'It really was, I can't wait for what's next.'"
    new "彼に「本当にそうだったよ、次が待ち遠しいわ」って伝えて。"

    # say L331 pla
    old "He answered with 'Yeah, me neither, but that'll have to wait, I have to go work, I'm 30 minutes over my break! Talk to you later, bye!'"
    new "ああ、そうだよ、でもそれには待つしかないな。今仕事に行くから、休憩時間が30分オーバーしてるんだ。後で話すからな、じゃあね！"

    # say L332 pla
    old "'But be sure I'm crazy to see you!'"
    new "でも君に会いたいって気持ちは本気だよ！"

    # say L333 lyd
    old "That's nice, I guess we'll talk later."
    new "それはいいわ、後で話すわね。"

    # say L334 pla
    old "You don't want me to answer anything back?"
    new "何か返事もしないつもりなのか？"

    # say L335 lyd
    old "There's no need, he'll talk to me later anyway."
    new "必要ないわ、後で話してくれるから。"

    # say L349 lyd
    old "Nngh! Oh yes! This is just what I've been wanting!"
    new "んっ！ああ、そう！これこそ私が欲しがっていたものよ！"

    # say L350 lyd
    old "This long, thick hard cock of yours!"
    new "あなたの長い、太くて硬いチ○ポ！"

    # say L351 lyd
    old "There's no other cock like it!"
    new "他のチンポとは全然違うわ！"

    # say L355 lyd
    old "Y- your cock is the best!"
    new "あなたのチ○ポが一番だよ！"

    # say L356 lyd
    old "I've never had any cock like this!"
    new "こんなちんこ、初めてよ！"

    # say L357 lyd
    old "Yes, yes, fuck me more!"
    new "はい、はい、もっと突いて！"

    # say L361 lyd
    old "Ohh! I love how you push into my pussy!"
    new "オッホッホ！あなたが私のまんこに突き入れるの好き！"

    # say L362 lyd
    old "I can't have enough of this hot cock!"
    new "この熱いちんこ、いくらでも欲しいわ！"

    # say L363 lyd
    old "Fuck me! Fuck me more!"
    new "もっと突いて！ もっと突いてよ！"

    # say L386 pla
    old "L- Lydia! I think I'm about to..."
    new "リディア！　俺ももう限界だ…"

    # say L387 lyd
    old "Yes! Let it all out!"
    new "はい！全部出しちゃって！"

    # say L388 lyd
    old "Fill me with your hot cum!"
    new "私をあなたの熱い精液で満たして！"

    # say L394 lyd
    old "That was good!"
    new "それは良かったわね！"

    # say L395 lyd
    old "Just what I was expecting."
    new "期待通りだったわ。"

    # say L397 pla
    old "Listen, I'm glad you're feeling better."
    new "リディア、調子が良くなってくれて嬉しいんだけど、さ。"

    # say L398 pla
    old "But, I think it's better if you just leave. Remember this isn't your house, someone could hear us."
    new "でも、君が帰った方がいいと思う。ここは君の家じゃないし、誰かに聞かれたらどうするんだ。"

    # say L399 lyd
    old "Leave? What are you talking about?"
    new "出て行く？何言ってんの？"

    # say L400 lyd
    old "This is just the beginning!"
    new "これで始まっただけよ！"

    # say L401 pla
    old "W- What? What else do you want to do?"
    new "何？他に何したいの？"

    # say L402 lyd
    old "Ohh, it's something I wanted to try for the longest time."
    new "ああ、これは私が長い間試してみたかったことなの。"

    # say L403 lyd
    old "But my husband was too much of a prude for it."
    new "でも私の夫はそんなことにはあまりにもprüfだったの。"

    # say L404 lyd
    old "Him and his stupid morale, always draggin me back!"
    new "彼とそのくだらない道徳心、いつも私を引き止めてばかりだった！"

    # say L405 lyd
    old "So, now you're going to give me what I want..."
    new "だから、今度は私が欲しくて仕方ないものをくれるのね…"

    # say L407 lyd
    old "Just come here and find out."
    new "ここに来て自分で確かめてみなさい。"

    # say L424 lyd
    old "It's ok if you start sl-"
    new "大丈夫よ、始めるならさ-)"

    # say L425 lyd
    old "AH! AAAH!"
    new "AH！ AAAH！"

    # say L427 lyd
    old "Oh yes! This is what I wanted!"
    new "ああ、そうよ！これが欲しかったの！"

    # say L428 lyd
    old "Mmm, nngh, it hurts a little, but is perfect!"
    new "んん、少し痛いけど、最高だよ！"

    # say L432 lyd
    old "Y- your dick is massive!"
    new "あなたのチ○ポ、デカすぎ！"

    # say L433 lyd
    old "It's stretching my ass so much!"
    new "私の anus がこんなに広がってる！"

    # say L434 pla
    old "S- should I stop?"
    new "止めるか？"

    # say L435 lyd
    old "No! Don't you dare!"
    new "ダメ！やめないで！"

    # say L436 lyd
    old "I'm loving this!"
    new "これ大好きだ！"

    # say L440 lyd
    old "YES! YES! You fucking my ass with that big dick!"
    new "YES！ YES！ その大きなチ○ポでアナルを犯してるの！"

    # say L441 lyd
    old "It's just what I wanted!"
    new "これこそ私が欲しがっていたの！"

    # say L442 lyd
    old "I'll never have enough of this dick!"
    new "このチ○ポにはいつまででも満足しないわ！"

    # say L443 lyd
    old "I love it when you fuck me!"
    new "あなたが私を犯すのが大好き！"

    # say L466 lyd
    old "I can feel your dick twitching in my ass!"
    new "あなたのチ○ポが私のア○コの中でピクピクしてるのを感じてる！"

    # say L467 pla
    old "I- I'm about to finish!"
    new "俺、もう出るよ！"

    # say L468 lyd
    old "Do it! Finish in my ass!"
    new "やって！ 私の中に出して！"


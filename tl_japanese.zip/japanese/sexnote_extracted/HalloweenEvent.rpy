# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/HalloweenEvent.rpy
translate japanese strings:

    # say L10 pla
    old "Uhh, I didn't sleep well last night... I should drink a cup of water... "
    new "うーん、昨夜はよく眠れなかったな... 水を一杯飲もうかな..."

    # say L25 mo1
    old "Oh, hi honey, good morning!"
    new "おはよう、ハニー。お母さんだよ。"

    # say L26 pla
    old "Uhh, good morning..."
    new "うーん、おはよう……"

    # say L27 mo1
    old "Do you have everything ready for tonight?"
    new "tonightの準備はできてる？"

    # say L28 pla
    old "T- onight?"
    new "今夜？"

    # say L29 mo1
    old "The halloween party is tonight... Don't you have your costume already?"
    new "ハロウィンパーティーは今夜よ… コスチュームはもう用意したの？"

    # say L30 pla
    old "Ohh... Right, I completely forget about that... Ehmm no, actually I don't have a costume yet..."
    new "ああ……そうだった、完全に忘れてた…… Actually, まだコスチュームを持ってないんだ……"

    # say L31 mo1
    old "Oh, don't worry, Talk with [sis], she was the one who got us our costumes, she could have one for you too."
    new "あら、心配しないで、[sis]に話してみて。彼女が私たちの衣装を用意してくれたのだから、君の分も用意できるかもしれないわ。"

    # say L32 pla
    old "Oh, great, I'm going to talk with her. Thank you!"
    new "オッケー、彼女に話すね。ありがとう！"

    # say L33 mo1
    old "You are welcome honey."
    new "どういたしまして、ハニー。"

    # say L48 pla
    old "Ohhh... Wow..."
    new "オォ… サンキュー…"

    # say L52 sis
    old "Ohh, hey [pla]! How do I look with this costume?"
    new "オッ、hey [pla]！この衣装、どう思う？"

    # say L54 sis
    old "Where is your [mo1rel]?"
    new "あなたの [mo1rel] はどこ？"

    # say L56 sis
    old "Where is [mo1]?"
    new "どこにあるの、[mo1]？"

    # say L57 pla
    old "Hmm she is in the kitchen... Why?"
    new "キッチンにいるんだ… 何で？"

    # say L58 sis
    old "Perfect. Do you wanna see the fun thing about this costume?"
    new "Perfect. この衣装の面白いところ、見たい？"

    # say L59 pla
    old "The fun... Thing? What do you mean?"
    new "楽しい…こと？どういう意味？"

    # say L60 sis
    old "Hahaha, you are going to love it!"
    new "ははは、あなた絶対気に入るわよ！"

    # say L61 pla
    old "Hmm a- alright..."
    new "うーん、ああ、なるほど…"

    # say L62 sis
    old "Well, I chose this costume for just one reason, it has a tail. Do you see it?"
    new "ええ、このコスチュームを選んだのは一つの理由だけよ。しっぽがあるから。見える？"

    # say L63 pla
    old "Hmm... Yes."
    new "うん… 見えるよ。"

    # say L64 sis
    old "Ok, now I'm going to take it out."
    new "じゃあ、今から出すわ。"

    # say L65 pla
    old "You are going to wha-"
    new "何をするつもりだ…"

    # say L72 sis
    old "I wanted something like this from a long time ago... Did you know I have never try anal sex?"
    new "これずっと欲しく思っていたの… でも知ってる？ 私、アナルセックスまだ経験ないのよ。"

    # say L77 sis
    old "Well I wanna change that today... I want you to fuck my ass..."
    new "今日それを変えてみたいの... あなたのアナルを犯してほしいの..."

    # say L88 sis
    old "Uhhh [pla], do it gently... Is my first time..."
    new "うーん [pla]、優しくして… 初めてだから…"

    # say L102 sis
    old "Wow, it was better than I thought, and your big cock didn't hurt me at all..."
    new "うわ、思ってたより全然良かったし、あなたの大きいのが全然痛くなかったよ…"

    # say L103 pla
    old "I did it gently..."
    new "優しくしたよ..."

    # say L104 sis
    old "Definitely we need to repeat it."
    new "確かにまたやりたいね。"

    # say L105 pla
    old "Uhh... O- ok."
    new "うーん… お、おｋ。"

    # say L106 sis
    old "Anyway, I have work, see you later [pla]."
    new "でも、仕事があるから、後でね [pla]。"

    # say L107 pla
    old "Wait... Hmm I came, because I need a halloween costume."
    new "待って… 俺、来たのはハロウィンのコスチュームが必要だったからだよ。"

    # say L108 sis
    old "Ohh, your costume? Is in your bedroom."
    new "オッ、あなたの衣装？寝室に置いてあるわ。"

    # say L109 pla
    old "Oh really?"
    new "ほんと？"

    # say L110 sis
    old "Yes, I left it there a few minutes ago."
    new "はい、数分前にそこに置いてきたの。"

    # say L111 pla
    old "Ohh, thank you so much."
    new "オッ、ありがとうな。"

    # say L112 sis
    old "You're welcome. You will like that costume, it's perfect for you."
    new "どういたしまして。その衣装、あなたにぴったりだから好きになるわよ。"

    # say L113 pla
    old "Hmm... Alright."
    new "うーん… 分かったよ。"

    # say L126 pla
    old "Uhh, yes."
    new "うーん、そうか。"

    # say L127 mo1
    old "Hmm could you please come for a minute?"
    new "うーん、ちょっと来ていただけますか？"

    # say L137 pla
    old "Ohhh wow!"
    new "オォ、凄い！"

    # say L138 mo1
    old "I'm sorry... Is just that this costume is a bit hard to dress up... Could you please help me with that?"
    new "すみません… この衣装がちょっと着にくいもので… 手伝っていただけますか？"

    # say L139 pla
    old "Uhh... S- sure."
    new "うーん… やりましょう。"

    # say L140 mo1
    old "Thank you. You are a sweetheart!"
    new "ありがとうございます。あなたは優しいですね。"

    # say L141 pla
    old "Ok... Let's see..."
    new "うん… 見てみようか。"

    # say L146 pla
    old "Well, I think is done..."
    new "まあ、これで終わりだな…"

    # say L151 mo1
    old "Oh, it's perfect just like in the box picture!"
    new "あら、箱の写真通りにぴったりですね！"

    # say L152 mo1
    old "Oh, wait... It doesn't cover up my nipples at all..."
    new "待って、全然乳首が隠れてないじゃない…"

    # say L155 mo1
    old "Maybe it is a bit small for me...  What do you think [pla]?"
    new "このサイズだと少し小さめかもしれないわね… あなたの意見はどう？ [pla]"

    # say L161 pla
    old "(Oh God, I just had sex! How can I get this horny again?..."
    new "（神様、さっきセックスしたばかりなのに…またこんなに興奮できるのか…）"

    # say L163 mo1
    old "[pla]? Are you-... Oh, you got hard-"
    new "[pla]？あなたは…あ、硬くなってきたの？"

    # say L164 pla
    old "Sorry... I didn't mean to-"
    new "ごめん... 意図せずに-"

    # say L165 mo1
    old "Oh, honey don't worry... You got hard for my tits?"
    new "あら、心配しないで…私の胸を見て硬くなっちゃったの？"

    # say L168 mo1
    old "Ok, what about if I help you with them?"
    new "それなら私が手伝うわね。"

    # say L170 mo1
    old "Get naked and let me return you the help."
    new "裸になって、私がお返しするからね。"

    # say L178 mo1
    old "Do you like my boobs honey?"
    new "私の胸、好きよね、ハニー？"

    # say L179 pla
    old "Uhh.... Y- yes... I love your boobs."
    new "うーん…… や、yeah… お前の胸大好きだ。"

    # say L180 mo1
    old "Then fuck them!"
    new "じゃあ、私の胸を犯しなさい！"

    # say L196 mo1
    old "Do you feel better now honey?"
    new "今、ハニーは落ち着いた？"

    # say L197 pla
    old "Y- yes... Thank you."
    new "うん…ありがとう。"

    # say L198 mo1
    old "No, thanks to you for your help with this costume. By the way did you talk with [sis]?"
    new "いいえ、この衣装のことで手伝ってくれてありがとう。それに、[sis] とは話したの？"

    # say L199 pla
    old "Uhh... W- with [sis]..."
    new "うーん... [sis] と..."

    # say L200 mo1
    old "Yes, about your costume."
    new "はい、あなたの衣装について話しましたね。"

    # say L201 pla
    old "Ohhh the costume, right... Yes, I have it in my bedroom, I need to try it"
    new "オッケー、衣装ね... うん、寝室に置いてあるから、試してみなくちゃな。"

    # say L202 mo1
    old "Oh great, then go, if you need any help just let me know. Now I'm going to clean this mess."
    new "それなら行ってみて、手伝う必要があったら言ってちょうだい。今、この片づけをしなくちゃ。"

    # say L203 pla
    old "Alright, Thank you."
    new "ありがとう、じゃあ行ってくる。"

    # say L208 pla
    old "(Alright, I should try the costume.)"
    new "よし、じゃあ衣装を試してみるか。"

    # say L213 pla
    old "Hmm, it looks a bit weird... What is this? Maybe I'm doing something wrong, I better ask [sis]."
    new "んー、ちょっと変な感じだな… これって何だ？何か間違ってるのかな、[sis]に聞いてみるか。"

    # say L229 pla
    old "Hey, I was looking for you."
    new "Hey、探してたんだ。"

    # say L230 sis
    old "Oh, you have your costume! You look great!"
    new "お、コスチューム着てる！ かわいそう！"

    # say L231 pla
    old "Thank you, but I was wondering what is t-"
    new "ありがとう、でも何が気になるのかな…"

    # say L232 sis
    old "Hmm your costume is not ready..."
    new "Hmm、コスチュームまだできてないの？"

    # say L234 sis
    old "You need to get hard to fill the snake."
    new "あなた、硬くならないと蛇は膨らまないわよ。"

    # say L235 pla
    old "F- fill the snake? "
    new "F- 蛇を膨らませるって？"

    # say L236 sis
    old "You always have to be that slow?"
    new "いつもそんなに遅いの？"

    # say L238 sis
    old "Alright, let me give you a blowjob to make you hard-"
    new "よし、私がフェラチオして硬くさせてあげるからね"

    # say L245 mo1
    old "Hi guys, what are you doing?"
    new "皆さん、何してんの？"

    # say L247 pla
    old "(Oh shit...)"
    new "“Ohシャイ…"

    # say L248 sis
    old "Well, [pla] needs help with his costume..."
    new "WELL、[pla] は衣装を着るために手伝いが必要みたいです…"

    # say L249 mo1
    old "Oh really, what does he need?"
    new "ほんとうに、何が必要なの？"

    # say L250 sis
    old "He needs to get hard to fill his costume."
    new "彼は衣装を着るために硬くなる必要があるんです。"

    # say L253 mo1
    old "Oh, the snake will become to anaconda?"
    new "Oh、そのへびがアナコンダになるの？"

    # say L255 pla
    old "(What the hell!?)"
    new "何だよ！？"

    # say L256 sis
    old "Exactly! I was thinking in a blowjob. What do you think?"
    new "そうですよ！ フェラを考えてたの。どう思う？"

    # say L258 mo1
    old "What about a double blowjob, I think that would make him hard for all night!"
    new "ダブルフェラはどうですか、そうすれば彼は一晩中元気なままでしょうね。"

    # say L260 pla
    old "(WHAT THE FUCK IS GOING ON?!)"
    new "何が起こってるんだよ！"

    # say L261 sis
    old "Great idea!"
    new "いいアイデアですね！"

    # say L265 pla
    old "Uhh...  W- what is happening?"
    new "うっ… 何が起こってるの？"

    # say L266 mo1
    old "Hahaha, let's show him what is happening [sis]..."
    new "ははは、彼に何が起こってるのか見せてあげましょう [sis]..."

    # say L291 pla
    old "OHHHH SHITT...."
    new "オッシャイ、これって何だよ…"

    # say L293 mo2
    old "I- I REALLY CAN BELIEVE IT..."
    new "信じられないわ、こんなことになっちゃって…"

    # say L294 pla
    old "(OH GOD I'M DEAD.)"
    new "オーマイゴッド、俺死んじゃう。"

    # say L295 mo2
    old "I can't believe all of you started the party without me..."
    new "信じられないわ、みんなでパーティーを始めるなんて私抜きで..."

    # say L297 mo1
    old "There is more for you too..."
    new "あなたにもっとあるのよ..."

    # say L299 sis
    old "We will give you the best spot."
    new "あなたに最高の場所を用意しますよ。"

    # say L301 mo2
    old "And what are we waiting for? Let's enjoy!"
    new "それじゃ、何を待ってるの？ 楽しもうよ！"

    # say L314 mo1
    old "This is just a halloween party..."
    new "これはただのハロウィンパーティーだけど…"

    # say L315 sis
    old "Don't you want to join us?"
    new "参加したくないの？"

    # say L316 mo2
    old "You can't lose this chance..."
    new "このチャンスを逃すわけにはいきませんね…"

    # say L317 pla
    old "... What the hell... Let's do it!"
    new "…何だよ…やるか！"

    # say L326 pla
    old "Oh God... I can't anymore"
    new "神… もう無理だ"

    # say L330 sis
    old "Hey [pla], we want to keep fucking."
    new "Hey [pla]、もっと続けていたいの。"

    # say L331 pla
    old "Hmm... I- I just can't... I'm really tired..."
    new "うーん… 俺… 無理だ… 本当に疲れた…"

    # say L332 mo1
    old "Oh no honey, you don't understand."
    new "Oh no honey、あなたはまだ全然理解してないわ。"

    # say L333 mo2
    old "You fucked us, now is our turn to fuck you."
    new "あなたが私たちを犯したんだから、今度は私たちの番よ。"

    # say L339 sis
    old "We want to fuck you..."
    new "私たちはあなたを犯したいの..."

    # say L340 mo1
    old "Just like you did..."
    new "あなたがしたように…"

    # say L341 mo2
    old "We are going to drill you."
    new "私たちはあなたを貫くつもりです。"

    # say L350 pla
    old "Wow... It was just a nightmare... Thank God."
    new "うわさか… ただの悪夢だった… ありがとう神様。"

    # say L351 pla
    old "Hmm... Actually it wasn't a nightmare at all..."
    new "へえ… 実際は悪夢じゃなかったんだよ…"


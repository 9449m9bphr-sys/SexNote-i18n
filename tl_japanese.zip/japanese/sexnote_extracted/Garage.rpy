# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Garage.rpy
translate japanese strings:

    # say L23 pla
    old "Hello. I just came to know if you need more magic power?"
    new "こんにちは。もっと魔法の力が必要か確認しに来たんだ。"

    # say L25 mil
    old "I think I have enough. Thank you..."
    new "私は十分だと思うよ。ありがとう..."

    # say L27 pla
    old "Oh come on. In our deal you were supposed to receive magical power from me, so don't worry."
    new "おい、心配するな。契約では君が魔力をもらうことになってるんだから。"

    # say L29 mil
    old "Hmm, okay, I'll visit you tonight to get a little more magic."
    new "うん、わかった。今夜また少しだけ魔法の力をもらうために訪ねるね。"

    # say L31 pla
    old "Great, it's good for us to help each other..."
    new "そうだな、お互いに助け合うのはいいな。"

    # say L33 mil
    old "Ok, see you tonight."
    new "じゃあ、今晩ね。"

    # menu L43 
    old "Ask for Magic Power"
    new "魔力を分けてくれないか聞く"

    # say L45 pla
    old "Hello! I wanted to know if you have any magic power to share with me. You know, to keep improving my skills..."
    new "こんにちは！君の魔法力をちょっと分けてくれないかな。スキルをもっと上げたいんだ。"

    # say L49 mil
    old "Well, if you really need it I have some magic power for you."
    new "本当に必要ななら、私の魔法力を使ってもいいよ。"

    # say L51 pla
    old "Thank you. I really appreciate it."
    new "ありがとう。本当に助かるよ。"

    # say L53 mil
    old "Don't mention it. This was part of our deal"
    new "気にしないで。これは私たちの約束の一部だから。"

    # say L57 mil
    old "Ok, I'm ready. Let's do it."
    new "はい、準備できました。始めましょう。"

    # say L59 pla
    old "Alright, alright..."
    new "わかったわかった..."

    # say L68 mil
    old "Sorry, but I don't have enough to share for now..."
    new "今すぐはまだ足りないの..."

    # say L70 pla
    old "Oh ok. No problem. I will come later."
    new "別にいいよ、後で来よう。"

    # say L72 mil
    old "Bye."
    new "バイ👋"

    # say L96 pla
    old "Oh come on. In our deal you were supposed to get magical power from me, I'll take care of you."
    new "おい、ちょっと待て。約束は俺から魔法の力を分けてあげて、俺がお前に面倒を見るってことだったろ？"

    # say L98 gom
    old "Mmm, okay. I'll visit you tonight to get a little more magic."
    new "うん、わかった。今夜また来て、もっと魔法をもらうね。"

    # say L100 pla
    old "Great,I like helping you..."
    new "よし、お前を助けるのは好きだな..."

    # say L114 pla
    old "Hello! I wanted to know if you have any magic power to share with me You know, to keep improving my skills..."
    new "こんにちは！君に魔法の力を分けてくれないかな。俺のスキルをもっと上げるためにね。"

    # say L118 gom
    old "Yes I have some magic power to give you."
    new "うん、ちょっとだけ魔法の力を分けられるね。"

    # say L120 pla
    old "Oh, sweet. Thank you!"
    new "ありがとう、助かるよ。"

    # say L122 gom
    old "No problem, your progress benefits us all"
    new "問題ないよ、あなたの進歩はみんなに役立つんだよ。"

    # say L126 gom
    old "Are you ready?."
    new "準備できてる？"

    # say L128 pla
    old "Yes! Let's get to it..."
    new "はい！さっそく始めよう。"

    # say L140 pla
    old "Oh, ok. No worries. I will come later."
    new "お、そうか。心配しなくていい。後で来よう。"

    # say L142 gom
    old "Buh bye."
    new "バイバイ"

    # say L163 pla
    old "Hi there, I just came to know if you need more magic power?"
    new "嘿、君、魔法の力が必要かどうか見に来たんだ。"

    # say L165 dev
    old "Well, maybe I might need a little..."
    new "まあ、ちょっとは必要かもね..."

    # say L167 pla
    old "Great, in that case visit me tonight so I can give you some magical power..."
    new "じゃあ、その場合は今夜うちに来てくれ 魔力を分けてやるから..."

    # say L169 dev
    old "With pleasure! I'll see you tonight..."
    new "もちろん！今夜会うのを楽しみにしているよ..."

    # say L181 pla
    old "Hey! I wanted to know if you have any magic power to share with me. I want to keep improving my skills..."
    new "Hey！魔法の力を分けてくれないか？スキルをもっと磨きたいんだ..."

    # say L184 dev
    old "Of course! I have plenty to share with you."
    new "もちろん！たくさん分かち合えるわ。"

    # say L188 dev
    old "You can ask me whenever you want. Whenever I have enough I will give it to you..."
    new "いつでも聞いていいわ。持ってる分があれば、あなたにあげるから…"

    # say L190 pla
    old "Nice! Thank you."
    new "ありがとう！助かるよ。"

    # say L198 dev
    old "Hmmm... Unfortunately, I don't have enough right now..."
    new "うーん… 残念だけど、今すぐには足りないのね…"

    # say L200 dev
    old "However, look for me in a couple of days and I will have accumulated more to give you..."
    new "数日後にまた会ってみて、その頃にはもっと貯まってるから..."

    # say L202 dev
    old "Or... You could also share with me and I'll give it back to you, just for the fun of sharing... Hehe"
    new "それか……一緒に分けてくれれば、また返すから、共有するのが楽しくなるわ……へへ"

    # say L204 pla
    old "Oh, don't worry, it's really nothing urgent."
    new "心配しなくていい、全然急いでるわけじゃないよ。"

    # say L206 dev
    old "Oh... Ok then."
    new "うーん…わかった。"

    # menu L226 
    old "Magic Power"
    new "マジックパワー"

    # menu L230 
    old "What is the Magic Power?"
    new "魔法パワーって何？"

    # say L232 bri
    old "Well, Magical power is an energy that was produced naturally in the magical world..."
    new "魔法の力は、魔法の世界で自然に生まれたエネルギーだよ…"

    # say L234 bri
    old "After its destruction all that magical energy ended up in the human world, the problem is that now it does not reproduce anymore..."
    new "その破壊後、その魔力エネルギーはすべて人間界に流れ込んだけど、問題は今それがもう増えなくなってること……"

    # say L236 bri
    old "Only the remains of great magical sources, and all magical beings that once existed will be extinguished forever..."
    new "偉大な魔法の源の残りと、かつて存在したすべての魔法生物が永遠に消えてしまう..."

    # say L238 pla
    old "Ok, I understand it better now."
    new "分かった、今さらだけど。"

    # say L240 bri
    old "Great! What else do you want to know?"
    new "素晴らしい！他に知りたいことはある？"

    # menu L247 
    old "How to get Magic Power?"
    new "魔力をどうやって手に入れるか？"

    # say L249 bri
    old "You have in fact 4 ways..."
    new "実際には4つの方法があるよ。"

    # say L250 bri
    old "1. Picking up in each place with the agamoto's eye."
    new "1. それぞれの場所でアガマトの目を使って集める。"

    # say L251 bri
    old "2. Using Ayax's hand and automatically picking up when moving between locations."
    new "2. アヤックスの手を使って、場所を移動するときに自動的に拾う。"

    # say L252 bri
    old "3. Having high levels of arousal caused by sexual activity with women."
    new "女性との性的活動によって高い興奮状態になる。"

    # say L253 bri
    old "4. Ask me to share you with my magical power!"
    new "私の魔法の力を分かち合ってよ！"

    # say L255 pla
    old "Ok, interesting..."
    new "おっ、面白いね..."

    # say L257 bri
    old "My favorite is the last one, but only when you share with me yours too..."
    new "最後のが好きだけど、あなたも私と分かち合ってくれないとダメね..."

    # say L259 pla
    old "Yes, I know..."
    new "分かってるよ…"

    # say L261 bri
    old "Well, What else do you want to know?"
    new "じゃあ、他に何を知りたいの？"

    # menu L272 
    old "Spells"
    new "呪文"

    # menu L276 
    old "Agamoto's Eye"
    new "アガモトの眼"

    # say L278 bri
    old "Agamoto was one of the most powerful magicians who specialized in ocular power."
    new "アガモトは最も強力な魔術師の一人で、特に目に関する力を専門としていました。"

    # say L280 bri
    old "They say that his power even came to see the soul and thoughts of any being."
    new "彼の力はどんな存在の魂や思考まで見ることができたというよ。"

    # say L282 bri
    old "That is why Agamoto is a power of vision that allows you to see the dimension of the magical world and see beyond the objects of the real world."
    new "それがアガモトの力なんだ。視覚の力を通じて魔界の次元を見ることができ、現実世界の物体を透かすこともできるのよ。"

    # say L284 pla
    old "Wow Really?"
    new "ほんと？"

    # say L286 bri
    old "Yes, you should try it, you could only see through easy things like clothes, try using it on someone to see through their clothes."
    new "はい、試してみるといいわ。服くらいなら簡単に透けて見えるから、誰かの服を透かして見てみるといいよ。"

    # say L288 pla
    old "Ok ok, I'm going to try it..."
    new "分かった分かった、試してみるよ..."

    # menu L297 
    old "Ayax's Hand"
    new "アヤックスの手"

    # say L299 bri
    old "Ayax was one of the greatest thief magicians in history."
    new "アヤックスは歴史上最も偉大な泥棒魔術師の一人だった。"

    # say L301 bri
    old "He reached the point of being able to turn his body into a magnet for valuables."
    new "彼は自分の体を貴重品を引きつける磁石に変えることができるまでになった。"

    # say L303 bri
    old "Ayax's hand is basically this power that he achieved, with which you can automatically attract the magical power of the area where you are."
    new "アヤックスの手は、彼が得た力で、その場所にある魔法の力を自動的に引き寄せるんだ。"

    # say L306 pla
    old "Wow, interesting..."
    new "へえ、面白いな…"

    # say L308 bri
    old "What else do you want to know?"
    new "他に知りたいことある？"

    # menu L316 
    old "Sauron's Mouth"
    new "サウロンの口を使った操りの技"

    # say L318 bri
    old "Sauron was one of the greatest political influencers in the magical world."
    new "サウロンは魔法の世界で最も偉大な政治的インフルエンサーの一人でした。"

    # say L320 bri
    old "He managed to create a manipulative skill with his mouth with which he managed to influence everyone."
    new "彼は自分の口を使って操縦の技を作り出し、誰もが彼の影響下に落ちるようにしたの。"

    # say L322 bri
    old "This is how the Sauron's Mouth was created, with it you can influence all kinds of beings..."
    new "これがソーロンの口の技の由来だわ、これを使えば様々な生命体を影響下に置くことができるの…"

    # say L324 pla
    old "Like some kind of mind control?"
    new "何かの精神制御みたいに？"

    # say L326 bri
    old "What? Of course not, it is more an ability to influence or manipulate at certain levels, not to control the behavior."
    new "何？もちろんそうじゃないわ、これは特定のレベルで影響や操作ができる能力であって、行動を完全にコントロールするものじゃないの。"

    # say L328 bri
    old "In fact, using it does not always work and you should improve it to the fullest and have a good relationship with who you use to increase your chances..."
    new "実際、ただ使うだけでは必ず効果があるわけではないし、もっと上手に使いこなせるようになり、相手との関係をよくすることで成功確率が上がるんだよ。"

    # say L330 pla
    old "Ok, ok, understood."
    new "分かった分かった、わかった。"

    # menu L339 
    old "Jamliz's Heart"
    new "ジャムリズの心"

    # say L341 bri
    old "Jamliz sought for years to make a very powerful spell that he never achieved, since he always needed more magical power."
    new "ジャムリズは、とても強力な魔法を作り出すために長年努力しましたが、常にさらなる魔力を必要としたため、その目標を達成することはできませんでした。"

    # say L343 bri
    old "But, what he achieved was to increase the ability to store magical power in unthinkable amounts."
    new "でも、彼は想像を超える量の魔法力を貯める能力を高めることには成功したの。"

    # say L345 bri
    old "That's why the Jamliz's Heart is a skill that allows you to store more magical power in your body and thus make spells that require greater magical power."
    new "それがジャムリズのハートが、体にたくさんの魔力を貯めることができ、より大きな魔力が必要な呪文を唱えられるスキルだというわけよ。"

    # say L347 pla
    old "Sounds pretty useful..."
    new "役立つな…"

    # menu L361 
    old "What I have to do?"
    new "何をすればいいんだ？"

    # say L363 bri
    old "The first thing you should do is improve your skills to the fullest. So obviously, you must get magical power."
    new "最初にすべきことは、あなたのスキルを最大限に高めることよ。だから当然、魔力を手に入れる必要があるわ。"

    # say L365 bri
    old "But your main mission is to restore the magical world and with this shortage of magical power the only way is for you to generate it for yourself..."
    new "でもあなたの主な任務は魔法の世界を復興することだから、この魔法力の不足状況では、自分で生成するしかないの..."

    # say L367 bri
    old "So you should seek to reach the highest level of sexual arousal. Experimenting with different women and situations to see what is most exciting for you..."
    new "だから、最高の性的興奮状態を目指すべきだわ。異なる女性や状況を試して、自分が最も興奮するものは何か見つけてみて…"

    # say L369 bri
    old "And have a lot of sex with many women to increase your power and gradually restore the power of the magical world!"
    new "たくさんの女性とたくさんセックスして、力を増やして、徐々に魔法の世界の力を回復させていくのよ。"

    # say L371 pla
    old "You do know that is not that easy, right?"
    new "君が思ってるほど簡単じゃないって、分かってるだろ？"

    # say L373 bri
    old "Don't worry. You can gradually acquire more skills that you can use in the real world to make things easier for you..."
    new "心配しないで。徐々に現実世界で使えるスキルを身につけて、物事が楽になるようにできるんだから…"

    # say L375 bri
    old "For now you can progress little by little with some women and see if you can get very horny!"
    new "今は少しずつ女性と関係を深めて、とても興奮できるかどうか見てみようよ。"

    # say L377 pla
    old "Hmmm... Ok, I'll see how to do something about it."
    new "うーん……わかった、どうにかするよ。"

    # say L416 pla
    old "I finally found you!"
    new "やっと見つけたぞ！"

    # say L423 dev
    old "WHAT DO YOU WANT FROM US?"
    new "何欲しそうなの？"

    # say L425 pla
    old "I just want to talk..."
    new "ただ話したいだけだよ…"

    # say L428 gom
    old "Where is your shinigami friend?"
    new "あなたの死神の友達はどこにいるの？"

    # say L430 pla
    old "She is not here, I came alone... I just want to clarify that everything was a misunderstanding..."
    new "彼女はいない、一人で来たんだ... 誤解だったってことを説明したいだけだ..."

    # say L432 pla
    old "I did not destroy the magical world..."
    new "魔界を壊したわけじゃない..."

    # say L434 mil
    old "We know that, you didn't destroy the magical world..."
    new "我们知道的、あなたは魔法世界を壊さなかった……"

    # say L436 pla
    old "That's right!, I didn't..."
    new "そうだよ、俺は破壊なんかしてない…"

    # say L440 pla
    old "What? No... I think you are confused "
    new "何？ないよ…君が誤解してると思うけど"

    # say L442 mil
    old "Kid, we are over 300 years old, and you how many? 18? We know all from the magical and human world. "
    new "子供、私たちは300年以上も生きてるのよ。あなたは18歳よね？魔法界も人間界も全部知ってるわよ。"

    # say L444 pla
    old "But... Brixxida knows nothing about the destruction of the magical world..."
    new "でも... ブリクシダは魔界の破滅について何も知らないって..."

    # say L446 gom
    old "Doesn't know or doesn't want to tell you? Why do you think she needs you? "
    new "知らないのか、言いたくないのか？なぜあなたが必要だって思ってるのかな？"

    # say L448 pla
    old "To restore the magical world?"
    new "魔法の世界を復活させるために？"

    # say L450 dev
    old "And if she wants to restore the magical world why is she alone? Why there are no more shinigamis with her, like us? "
    new "そして、魔法の世界を復活させたいなら、なぜ彼女は一人なのか？ なぜ私たちのような死神がいなくなったのか？"

    # say L452 pla
    old "Well, I don't know..."
    new "まあ、知らないな..."

    # say L454 mil
    old "Who you have by your side is probably one of the most powerful being in the universe and you don't know her real intentions, you must be very careful..."
    new "あなたが側にいるのは、おそらく宇宙で最も強力な存在の一人でしょう。彼女の本当の意図を知らないのに、とても気をつけるべきよ..."

    # say L456 pla
    old "But she has only helped me..."
    new "でも彼女は俺を助けてくれただけだよ…"

    # say L458 dev
    old "We don't know what she may want from you... But she was who destroy the magic world..."
    new "彼女が本当に何を求めているのかわからないわ… でも、魔法の世界を壊したのは彼女なのよ…"

    # say L460 pla
    old "And how do I know that it is not you who want to deceive me?"
    new "どうやって君が私をだますつもりじゃないかってわかるんだ？"

    # say L462 mil
    old "You don't have to believe us, we're not asking you anything, just let us try to survive, that's all..."
    new "信じる必要はないわ、何も求めてないから。ただ生き延びさせてくれればいいの、それだけよ…"

    # say L464 pla
    old "Ok, I want to propose something to you, I will be in charge of sharing magical power to all of you."
    new "よし、一つ提案がある。俺が全員に魔力を分配する役目を担うことにしよう。"

    # say L466 pla
    old "I mean, you can come and collect magic power from me so you won't disappear..."
    new "つまり、君たちは俺から魔力を取りに来れば消えずに済むんだよ..."

    # say L470 mil
    old "Thank you, but we don't need it..."
    new "ありがとう、でも私たちは必要ないの..."

    # say L472 pla
    old "Oh come on, I have the SexNote, I have several skills that have allowed me to collect magical power quickly and efficiently."
    new "おいおい、SexNoteがあるんだ、素早く効率的に魔法力を集めるスキルがいくつかあるんだよ。"

    # say L474 pla
    old "And... I can also generate magical power by myself..."
    new "そして... 僕は自分で魔力を生成することもできるんだ..."

    # say L476 pla
    old "And you have less and less magical power left..."
    new "君の残ってる魔力はどんどん少なくなっていくよ…"

    # say L478 gom
    old "What do you want in return?"
    new "何を代償にしたいの？"

    # say L480 pla
    old "Nothing, I just want to help in whatever I can..."
    new "何もいらない、ただ君を助けることのできる全てをやりたいだけさ..."

    # say L482 mil
    old "Will you still collect magical power from the whole area?"
    new "あなたはまだこの地域全体から魔力を集めるの？"

    # say L484 pla
    old "Well, with Ayax's Hand I automatically gather the magical power where I move..."
    new "まあ、アヤックスの手のおかげで、移動する場所の魔力を自動的に集められるんだよ..."

    # say L486 pla
    old "But that's why whenever you need it you can go at night and suck up magical power from me..."
    new "でもだから、必要になったら夜に来て俺から魔力を吸い取ればいいんだよ..."

    # say L488 dev
    old "Hmmm... Okay, but we'll just take what is necessary..."
    new "うーん……わかったけど、必要な分だけ取るからね。"

    # say L490 mil
    old "And we will return what we do not need, so you can look for us to receive magic power that we don't need..."
    new "そして不要な魔力は返すから、余分な魔力を補充するために私たちを探してね。"

    # say L492 gom
    old "It really suits us that you rebuild the sources of magic power production..."
    new "魔法力を生み出す源を再構築してくれるのが、本当に都合がいいわね。"

    # say L494 mil
    old "And that's why we will help you, so you you can find out about Brixxida's true intentions, and we will help you gather the magic power that remains."
    new "そしてそれが私たちがあなたを助ける理由だよ。Brixxidaの本当の意図を探り、残った魔力を集める手伝いをするためだよ。"

    # say L496 pla
    old "Okay, I'll go as far as I can and find out if Brixxida really has bad intentions or not..."
    new "分かった、できるだけ進んで、Brixxidaが本当に悪意を持っているのか調べるよ..."

    # say L498 gom
    old "You must be careful, she is much smarter and more powerful than she seems..."
    new "気をつけて、彼女は見た目よりもずっと賢く、力も強いわ..."

    # say L500 dev
    old "You must act without raising suspicion..."
    new "疑われずに行動しなきゃね。"

    # say L502 mil
    old "And above all be careful that she does not find out about our deal..."
    new "そして何より、私たちの取引が彼女にばれることのないよう気をつけてね..."

    # say L504 pla
    old "Okay, I'll keep that in mind... But then, where will I find all of you?"
    new "わかった、気をつけるよ…でも、君たちはどこにいるんだ？"

    # say L506 mil
    old "I will continue in the school zone..."
    new "私は学校の区域に留まるわ…"

    # say L508 gom
    old "I'll be in the house, where you found me..."
    new "家で待ってるわ、あなたが見つけてくれたところね..."

    # say L510 dev
    old "And you will find me here, that's how we split this little town..."
    new "そしてあなたはここで私を見つけるわ、それがこの小さな町での役割分担よ。"

    # say L512 pla
    old "Perfect, if you need to collect more magical power, you know where to find me..."
    new "完璧だ、もっと魔力を集める必要があれば、どこで俺を見つけられるか知ってるだろう…"

    # say L514 mil
    old "Okay... I think it's all for now, so we will be leaving..."
    new "じゃあ、これで一通り終わったみたいだから、私たち帰るわ…"

    # say L518 gom
    old "You know where to find me... we'll be seeing each other [pla]"
    new "知ってるでしょ…また会うわ [pla]"

    # say L523 dev
    old "Wait! before you go, I want to start our deal..."
    new "待って！行っちゃう前に、私たちの取引を始めるわ…"

    # say L525 dev
    old "after all, I have collected the most magical power from you and have not returned any of it to you..."
    new "でも、私が君から集めた魔法の力をまだ返してないんだよ..."

    # say L527 pla
    old "No, no, it is not necessary..."
    new "いや、いや、必要ないよ…"

    # say L532 dev
    old "I see it as a way to close the deal and you have already received magical power from all but me..."
    new "そうね、契約を締めくくる方法として考えて、他のみんなからはもらったけど私からはまだもらってないわけだよ…"

    # say L534 pla
    old "Hmm... alright, If it's fine for you."
    new "Hmm... なるほど、君がいいなら。"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/ladAnimations.rpy
translate japanese strings:

    # say L6 lad
    old "I'm stimulating your testicles while I masturbate you so I can get the maximum amount of semen out."
    new "あなたの睾丸を刺激しながら手コキしていますから、精液を最大限に出してもらうためにね。"

    # say L11 lad
    old "How is it? Do you feel ok?"
    new "どうですか？大丈夫ですか？"

    # say L12 pla
    old "Y- yes ma'am"
    new "はい、そうです、マ’am"

    # say L13 lad
    old "Just relax and let me do the job. I promise it won't feel bad."
    new "リラックスして任せてください。約束します、不快な気分にはならないから。"

    # say L17 pla
    old "O- ohhh! I- I think I'm getting close."
    new "オーッ！ もうすぐイキそうになるよ。"

    # say L18 lad
    old "Yes! I can feel your body tensing up."
    new "はい！あなたの体が緊張しているのを感じています。"

    # say L19 lad
    old "Mmmm! It's so hard!"
    new "ＭＭＭ！とてもきついです！"

    # say L42 pla
    old "Ma'am I-I think I'm cumming!"
    new "お姉さん、俺、俺イクッ！"

    # say L43 lad
    old "Yes! I want you to!!"
    new "はい！全部出して！"

    # say L44 lad
    old "Slurrp! That's it, let it all out!"
    new "スルルッ！そう、全部出してちょうだい！"

    # say L50 lad
    old "That was impressive, you came a lot."
    new "それはすごいね、たくさん出たわ。"

    # say L51 lad
    old "This will really help me a lot. I'm already starting to feel it's effects."
    new "これで本当に助かるわ。もうすでに効果を感じ始めているのよ。"

    # say L52 pla
    old "Really? Already? Well, I'm happy it worked."
    new "まあ、効果があったんだな。良かったよ。"

    # say L53 lad
    old "It really did. And I can't believe you came that much."
    new "本当にそうよ。それに、あなたがそんなに来てくれたことに驚いているわ。"

    # say L54 lad
    old "Although we made a bit of a mess."
    new "ちょっと散らかっちゃったけど。"

    # say L55 pla
    old "Sorry, I sometimes can't control myself."
    new "ごめん、時々我慢できない veces"

    # say L56 lad
    old "It's ok, you were helping me anyway. Just wait a second and I'll clean myself."
    new "大丈夫よ、あなたが手伝ってくれていたし。ちょっと待ってて、自分で片付けるから。"

    # say L65 pla
    old "Wow!"
    new "わお！"

    # say L66 lad
    old "Just relax and enjoy it."
    new "リラックスして楽しんでください。"

    # say L67 pla
    old "Y- yes ma'am."
    new "はい、そうですね。"

    # say L71 lad
    old "Ahh! I-I feel like I'm getting better already"
    new "あっ！もう上手くなってきた気がします…"

    # say L73 lad
    old "Oh yes! Just like this..."
    new "はい！この調子で…"

    # say L74 lad
    old "Keep going! Don't stop!"
    new "続けて！止めてないで！"

    # say L78 lad
    old "Yes! Yes! I can feel it!"
    new "はい！はい！感じています！"

    # say L79 lad
    old "This is amazing! Your dick fills me up completely!"
    new "これはすごい！あなたのチ○ポでいっぱいになるのを感じてる！"

    # say L80 lad
    old "Ahhh! Ohhhh!"
    new "アーッ！オーッ！"

    # say L103 lad
    old "Cum, now! I want to feel your cum fill me up."
    new "今、出しな！私のなかで精液を感じたいの。"

    # say L104 pla
    old "Y- yes! I'm about to!"
    new "Ｙ－はい！ 出すよ！"

    # say L105 lad
    old "That's it! Yes!"
    new "そうね！はい！"

    # say L111 lad
    old "Phew! That was impressive [pla]. Not only are you that well endowed, you know how to use your penis."
    new "ふう！それは印象的でした [pla]。あなたの大きさだけでなく、ペニスの使い方にも長けていますね。"

    # say L112 lad
    old "It's fantastic!"
    new "それは素晴らしいですね！"

    # say L113 pla
    old "T- thank you Miss. I'm glad you liked it."
    new "ありがとう、ミス。君が気に入ってくれて嬉しいよ。"

    # say L114 pla
    old "And I hope I was of help."
    new "そして、お力になれたなら幸いです。"

    # say L115 lad
    old "Oh, I'm sure you were."
    new "もちろんです、お力になれたことでしょう。"

    # say L116 lad
    old "You came a great amount. I have no doubt I'll feel better with this."
    new "あなたはとても多く出してくれました。これで私はきっと楽になると思います。"

    # say L117 lad
    old "Now, we better get dressed, it's late and you have to go home."
    new "では、着替えましょう。もう遅いですし、帰らなければなりません。"

    # say L118 pla
    old "Yes ma'am."
    new "はい、そうです。"

    # say L130 lad
    old "Just relax. And Iet us do the work."
    new "リラックスして。私たちがやってみましょう。"

    # say L131 lad
    old "We'll get you off in no time."
    new "すぐに気持ちよくさせてあげますから。"

    # say L133 pla
    old "Y- yes, I am."
    new "はい、そうです。"

    # say L137 lad
    old "Your penis is always so impressive [pla]!"
    new "あなたのペニスはいつもとても立派ですね [pla]！"

    # say L138 lad
    old "Mmm, and it has such a nice taste!"
    new "MMM、そしてとても美味しい味がしますね！"

    # say L139 dan
    old "Slurrp! Your dick... it's so warm, and it feels so nice in my mouth."
    new "スルルッ！あなたのちんこ……温かくて、私の口の中で気持ちいいの。"

    # say L140 bela
    old "I- it's so big..."
    new "あ、こんなに大きいの……"

    # say L144 bela
    old "Your dick it's so amazing! I can feel it throbbing!"
    new "あなたのチ○ポ、すごいわ… 脈打っているのを感じられる…"

    # say L145 lad
    old "Yes! just like this! it's so nice!"
    new "はい！この感じがいいの！すごく気持ちいいよ！"

    # say L146 dan
    old "It's so long! And so thick!"
    new "長いの！そして太いの！"

    # say L147 lad
    old "I can feel it, you're getting close!"
    new "感じてる、もうすぐイキそう！"

    # say L170 pla
    old "I- I think I'm gonna...!"
    new "俺、もう……！"

    # say L171 bela
    old "Mmmm! Yes!"
    new "むmmm！はい！"

    # say L172 lad
    old "It's ok, do it. Cum for us!"
    new "大丈夫、どうぞ。私たちのために精を出してください。"

    # say L177 lad
    old "That was amazing [pla]! How do you feel? I hope you're not too drained."
    new "それは素晴らしかった [pla]！どう感じていますか？あまり疲れていませんよね。"

    # say L178 pla
    old "Not at all, I feel very well... I know I can keep going."
    new "全然疲れてない、調子は最高だ… 続けられる自信がある。"

    # say L179 bela
    old "Wow, Y- you're not tired? Amazing!"
    new "すごい、あなた全然疲れてないの？凄いね！"

    # say L180 dan
    old "Incredible, I'd never met anybody that wouldn't feel tired after getting a blowjob from one of us. Let alone three!"
    new "信じられない、こんなに疲れずにいられる人は初めて見たわ。ましてや、私たち三人からフェラチオを受けた後なんて！"

    # say L181 lad
    old "I told you, this young man is the key for us to get better."
    new "私が言ったでしょう、この若者は私たちが良くなるための鍵になるの。"

    # say L182 lad
    old "And we're just getting started."
    new "まだ始まったばかりだわ。"

    # say L194 lad
    old "My god! Look at this, you just came, and yet your cock is still rock hard."
    new "神様！これを見て、君が来たばかりなのに、まだ全然硬いのね。"

    # say L195 lad
    old "Amazing!"
    new "すごいわ！"

    # say L196 dan
    old "Hurry up mother, I think you're wanting it."
    new "早くしなさい、お母さん、あなたも欲しそうね。"

    # say L197 lad
    old "Mmm, I am darling, I am."
    new "うふふ、私は Darling ですもの。"

    # say L198 lad
    old "Now [pla], let's beginning."
    new "さあ、[pla]、始めましょう。"

    # say L208 lad
    old "Uhhh... Your cock... It's so big!"
    new "うーん… あなたのアレ… すごく大きいのね。"

    # say L209 lad
    old "Mmm! It fills me up completely!"
    new "うふっ！ 完全に満たされてるわ！"

    # say L210 bela
    old "Wow mother, he really is deep into you!"
    new "Wow母さん、彼本当に奥まで入ってるね！"

    # say L214 bela
    old "Mmm, I can see you're enjoying it a lot!"
    new "うん、すごく楽しんでるの、よく見えるよ。"

    # say L215 lad
    old "Ahh! Yes dear, It would be... Ahh! Impossible not to."
    new "アッ！そうよね、これほどまでに…アッ！感じないわけがないわ。"

    # say L216 lad
    old "Oh yeah, just like this..."
    new "ああ、そうね、ちょうどいいわ…"

    # say L220 lad
    old "Ohh! Oh my god!"
    new "オーッ！なんてことだ！"

    # say L221 lad
    old "Ah, it feels so good!"
    new "ああ、気持ちいい！"

    # say L222 lad
    old "Ahhh! I- I'm close! I can feel it!"
    new "アーッ！ もう、近いのを感じてる！"

    # say L223 pla
    old "Uhhhhh!"
    new "うっほっ！"

    # say L246 pla
    old "M- Ma'am! I think I'm cumming!"
    new "あーっ！ 先生！ 出ちゃいます！"

    # say L247 lad
    old "Ah! Do it! I want you to! Cum!"
    new "あっ！していいわよ！私が見たいの、射精して！"

    # say L253 lad
    old "My god! That was impressive, you came so much."
    new "私の神様！そんなに大量にイッちゃうなんて、すごいわ。"

    # say L255 pla
    old "Phew, glad I can help."
    new "ふう、手伝えて良かった。"

    # say L256 lad
    old "But you know, I shouldn't keep you for myself..."
    new "でもね、私だけに独占するのは申し訳ないと思っちゃって…"

    # say L257 lad
    old "It's your turn Daniela..."
    new "あなたの番よ、ダニエラ…"

    # say L270 dan
    old "I hope you're not tired from being with mother, because I've been waiting for this."
    new "母さんと一緒で疲れてないといいけど、ずっと待ってたの。"

    # say L272 lad
    old "Daniela darling, I know our health is a little compromised."
    new "ダニエラ Darling、私たちの健康状態は少し心配よね。"

    # say L273 lad
    old "But there's no need to pressure him that much."
    new "でも、そんなに彼を追い詰める必要はないの。"

    # say L274 bela
    old "Haha, I don't think she meant it that way mother."
    new "ははは、母さん、彼女はそう言いたくなかったんじゃないかしら。"

    # say L287 dan
    old "Ok, here we go."
    new "はい、いきますよ。"

    # say L288 dan
    old "Mmm! This cock, it's reaching all the way!"
    new "うん！このちんこ、奥まで届いてるわ！"

    # say L289 bela
    old "Uhh, it looks amazing!"
    new "うわ、凄いわ！"

    # say L290 dan
    old "And it is! Mmm! So good."
    new "そうよ！　んん！　すごくいいわ。"

    # say L294 lad
    old "I can see that you're enjoying this [pla]."
    new "お楽しみのようですね、[pla]。"

    # say L295 pla
    old "Mmm... Y- yes ma'am"
    new "んん… は、はいさん"

    # say L296 bela
    old "Heh, Daniela is enjoying it too mother."
    new "へへ、ダニエラも楽しんでるみたいです、お母さん。"

    # say L297 dan
    old "I- It's so thick, and I feel so warm inside."
    new "あ、そんなに太くて、中が温かくて気持ちいいです。"

    # say L298 lad
    old "What about if you go a little faster [pla]?."
    new "もっと速くしてみてはどうですか？ [pla]"

    # say L302 dan
    old "Oh, Oh god!"
    new "ああ、神様！"

    # say L303 dan
    old "Yes! Yes! Like that! Pound me more!"
    new "はい！そう！もっと強く突いて！"

    # say L304 pla
    old "Mmm, Ahhh!"
    new "んん、アッ！"

    # say L328 dan
    old "I can feel it! Your body it's tensing up!"
    new "感じてる！あなたの体が緊張してるの！"

    # say L330 dan
    old "Yes! Cum! Cum inside me!"
    new "はい！ 出して！ 私の中に出して！"

    # say L336 dan
    old "Wow, that was amazing."
    new "すごいね、それだけ出しちゃうなんて。"

    # say L337 bela
    old "Look how much you came. I can't believe it."
    new "見なさい、こんなにたくさん出ちゃったの。信じられないわ。"

    # say L338 lad
    old "You never cease to surprise me [pla]."
    new "あなたはいつも私を驚かせてくれるわね [pla]。"

    # say L339 bela
    old "I think it's my turn now mother."
    new "今度は私番だよ、お母さん。"

    # say L351 bela
    old "Be gentle with me, ok?"
    new "優しくしてね。"

    # say L352 bela
    old "I don't like it as rough as my sister."
    new "あたしは姉ほど荒っぽいのは好きじゃないの。"

    # say L363 bela
    old "That's it, slowly. Mmm."
    new "そう、ゆっくりと。んん。"

    # say L364 bela
    old "Ah! I can feel how you stretch me."
    new "あ！　君が私を広げてるのを感じてるの。"

    # say L365 dan
    old "Yes sister, I felt it too. It's unbelievable."
    new "そうだよ、私も感じたの。信じられないくらいだよ。"

    # say L366 bela
    old "Y- You can do it, a little harder"
    new "あ、あんたもできるわ、もうちょっと強く"

    # say L370 dan
    old "You like that big cock sis?"
    new "その大きなちんこ、気に入ったの？"

    # say L371 bela
    old "Ohh, yes, yes, just like that."
    new "ああ、そう、そう、ちょうどいい。"

    # say L372 lad
    old "That's it Bela, enjoy it darling."
    new "そうよベラ、楽しんでちょうだい Darling。"

    # say L373 bela
    old "P- please, go a little faster."
    new "お願い、もう少しだけ速くして。"

    # say L377 bela
    old "Ah, Ahh, Ahhh!"
    new "アッ、アッ、アーン！"

    # say L378 bela
    old "I- It's soooo fucking big!"
    new "これめっちゃでかいよ！"

    # say L379 bela
    old "It's warming me up inside!"
    new "ああ、中から温めてくれてる！"

    # say L403 bela
    old "Yes! Me too!"
    new "はい！私もそう！"

    # say L404 pla
    old "Ughhh!"
    new "うっ！"

    # say L409 lad
    old "Amazing, you have such amazing endurance."
    new "すごいですね、そんなに耐えられるなんて。"

    # say L410 dan
    old "And he still hard... "
    new "まだ硬いのね..."

    # say L411 lad
    old "Hmm, do you think you could give us a little bit more?"
    new "Hmm、もう少し続けてくれないかな？"

    # say L412 pla
    old "Uhhh.... I- I think so."
    new "うーん…… たぶんできると思う。"

    # say L424 lad
    old "Mmmm, that was lovely [pla]."
    new "うーん、それは素敵でした [pla]。"

    # say L425 pla
    old "T- Thanks ma'am."
    new "T- ありがとう、お姉さん。"

    # say L426 lad
    old "You managed to do it with all three of us."
    new "三人ともでできたんですね。"

    # say L427 lad
    old "I think we can give you a little extra."
    new "私たちはあなたから少し余分をもらってもいいと思います。"

    # say L437 dan
    old "God! your cock still so hard."
    new "神様！あなたのチ○ポまだこんなに硬いの。"

    # say L438 lad
    old "I can see you still have some left in the tank. Give it to us."
    new "まだ元気なのが分かりますね。全部私たちにください。"

    # say L442 pla
    old "Ah... Ahh!"
    new "アッ… アッ！"

    # say L443 bela
    old "I love how big you are."
    new "あなたがこんなに大きいのが大好きです。"

    # say L444 lad
    old "It's got such a nice smell."
    new "いい香りがしますね。"

    # say L445 dan
    old "Let's do it a faster mother."
    new "早くしよう、母さん。"

    # say L449 lad
    old "Yes! That's it! I love seeing you enjoy it."
    new "はい！その通り！あなたが楽しんでいるのを見るのは大好き。"

    # say L450 bela
    old "It's so warm, and it's getting harder."
    new "暖かくて、硬くなってきているの。"

    # say L451 bela
    old "I think he's about to cum."
    new "彼、もうすぐイクみたいだよ。"

    # say L474 pla
    old "I- I think I'm cumming!"
    new "俺も、出そう！"

    # say L475 lad
    old "Yes! Let it all out! Cum all over us!"
    new "はい！全部出しなさい！私たちの上に全部出して！"

    # say L482 dan
    old "Wow, that was really intense."
    new "Wow、本当に強烈だったわ。"

    # say L483 pla
    old "Yes, it was. I think I'm finally feeling a little tired."
    new "そうだな、ようやく少し疲れたよ。"

    # say L489 dan
    old "Hah! Just now? I did it only once with you, and I'm already tired!"
    new "はは！ 今さら？ 私はあなたと一度だけしたのに、もう疲れたわ！"

    # say L490 lad
    old "Wow [pla], just wow! You really had sex with all three of us and are ok."
    new "Wow [pla]、ただただすごいですね！ 三人ともとエッチしたのに平気なんですか。"

    # say L491 pla
    old "Well, I wouldn't say I don't feel it. But I wanted to help."
    new "まあ、感じないわけじゃないけど、君たちを助けるためには頑張ったよ。"

    # say L492 lad
    old "And you did. Right girls?"
    new "そして、本当に助けてくれましたね。女の子たち？"

    # say L493 bela
    old "Yes, you really are a lifesaver."
    new "はい、本当に命の恩人ですね。"

    # say L494 dan
    old "That's right, this is great for us."
    new "そうですよね、これで私たちも助かります。"

    # say L495 pla
    old "Thank you very much."
    new "ありがとうございます。"

    # say L496 lad
    old "Well, why don't we get dressed? I think you probably need to rest at home [pla]."
    new "それじゃ、着替えていきましょうか。お家で休んだ方がよさそうですわ [pla]。"

    # say L513 lad
    old "How are you feeling girls?"
    new "女の子たち、具合はどう？"

    # say L514 bela
    old "I feel amazing, that was so good, and I feel myself getting better already!"
    new "私はすっごく感じてるわ、それがあんなに良かったの、もうずいぶん良くなってきた気がする！"

    # say L515 dan
    old "Yeah, me too. The amount of cum we were able to take is amazing."
    new "私もそう思うわ。私たちが受け入れられた精液の量はすごいわ。"

    # say L516 pla
    old "I'm happy I can be of help to you all."
    new "俺がみんなのお役に立てて嬉しいよ。"

    # say L517 pla
    old "I think I should probably go home and rest."
    new "俺は家に帰って休んだ方がいいだろう。"

    # say L518 lad
    old "That's fine. But before you leave, allow us to thank you once again for everything you've done for us."
    new "それは構いません。しかし、お帰りになる前に、改めて私共に向けたご尽力に心から感謝させていただきます。"

    # say L519 bela
    old "T- that's right [pla] thank you very much."
    new "ええ、その通りです [pla] 本当にありがとうございます。"

    # say L521 pla
    old "Sure, you can count on me."
    new "もちろん、君に任せていいです。"

    # say L522 lad
    old "Aww, you're an angel. Thank you so much."
    new "あら、あなたは天使ですね。本当にありがとうございます。"


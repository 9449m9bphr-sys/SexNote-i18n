# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/janAnimations.rpy
translate japanese strings:

    # say L37 pla
    old "(Oh shit, I'm dead.)"
    new "しまった、やばい。死んじゃう。"

    # say L47 pla
    old "Wow! Are they... Having sex?"
    new "Wow！ あの二人… セックスしてるのか？"

    # say L95 pla
    old "I should leave... I don't want to get caught peeping."
    new "俺は出ていくべきだ…… 覗かれて見つかりたくはないな。"

    # say L144 pla
    old "(Damn, she's so tight! Oh shit! I feel like... I am going to...)"
    new "くそ、中がすっごく締まってる！ああ、やばい！出ちゃいそうだ…"

    # say L148 mo2
    old "Fuck, baby. This new strap-on has a good lubrication system. It feels like a real cumshot... And it's so warm."
    new "ファック、ベイビー。この新しいストラップオンの潤滑システムがいいの。本物の射精みたいで……それにこんなに温かいの。"

    # say L149 mo2
    old "Mmm. Let me rest a little..."
    new "んん、ちょっと休ませて…"

    # say L150 pla
    old "(Alright. I should get out of here.)"
    new "（よし、そろそろ出ていくか）"

    # say L165 pla
    old "(She's so tight! Oh shit, I feel like... I am going to...)"
    new "（きつくて……くそ、我慢できそうにない……）"

    # say L169 mo2
    old "Mmm, still so good... Let me rest up, baby..."
    new "mmm、まだこんなに気持ちいいの... ちょっと休ませて、Darling..."

    # say L170 pla
    old "(Ok, I should get out...)"
    new "よし、出るか..."

    # say L188 mo2
    old "So nice to see like a little rat on the floor..."
    new "床にいる小さなネズミを見るのが嬉しいわね…"

    # say L190 mo2
    old "Are getting horny again?"
    new "また興奮しちゃったの？"

    # say L191 mo2
    old "You're so gross... Getting horny just by sucking my foot."
    new "あなたは本当に汚いのね… 足コキだけで興奮しちゃうなんて。"

    # say L195 mo2
    old "Yeah! This is what you like..."
    new "そうですよね！これが好きだってば…"

    # say L197 mo2
    old "I see you want more and more... You are a disgusting needy bastard."
    new "あなたはますます欲しがっているのね… あなたは汚らわしい依存症の男の子だわ。"

    # say L202 mo2
    old "That's what you deserve for being a fucking pervert!"
    new "それが変人のせいで受けるべき罰だわ！"

    # say L204 mo2
    old "I'm going to make you suck my foot! Every day you little rat!"
    new "毎日私の足を舐めさせてあげるわ、あなたのような小鼠よ！"

    # say L228 mo2
    old "That's it. Enough!"
    new "それ以上はダメよ。もう十分だわ。"

    # say L230 mo2
    old "Fuck! This is gross... Now I have my foot full of your disgusting slime."
    new "くそっ！これって汚いわ… 今私の足はあなたの汚らしい粘液でいっぱいよ。"

    # say L231 mo2
    old "I hope you've learned your lesson and don't go back to being perverted with your disgusting hardon."
    new "Lessonを学んだといいわ、また変態なことをするつもりなら、あなたの汚らしい勃起を見たくもないわ。"

    # say L232 mo2
    old "I need to clean myself from all this bullcrap..."
    new "このクソみたいなものから身を清めないとね…"

    # say L245 mo2
    old "Is this what you like, you little pervert? Do you like that your boss treats you like a cockroach?"
    new "これが好きなのか、小汚い変態？ボスにゴキブリ扱いされるのが好きなのか？"

    # say L246 mo2
    old "Does that turn you on, you fucking bastard?"
    new "それが興奮させるの？クソ野郎。"

    # say L253 mo2
    old "I ASKED YOU. ANSWER YOUR BOSS!"
    new "答えなさいあなたのボスに！"

    # say L254 pla
    old "Y- yes."
    new "は、はい。"

    # say L255 mo2
    old "Ohh poor baby, he thinks I'm doing this to please him..."
    new "あらあら、可哀想な赤ちゃん。私がこれをしているのはあなたを喜ばせたいと思ってるのね…"

    # say L259 mo2
    old "I'm doing this to torture you ..."
    new "私がこれをしているのはあなたを苦しめるためよ…"

    # say L260 mo2
    old "Because a pervert like you only thinks with the cock!"
    new "お前のような変態はただその部分でしか考えないのよ！"

    # say L261 mo2
    old "So, I won't make you cum until you get humillied, and accept you are a cockroach and I am your master."
    new "だから、あなたが恥ずかしい思いをして、自分がゴキブリで私がお前の主人だということを認めない限り、イかせないわ。"

    # say L263 mo2
    old "I'm gonna make you my bitch [pla]."
    new "あなたを私の玩具にするわ [pla]。"

    # say L286 mo2
    old "Ohh, are you close?"
    new "オッ、もうすぐイキそう？"

    # say L289 mo2
    old "Well, I'm not gonna let you cum."
    new "WELL、私が許さなきゃあなたはイクことができないわ。"

    # say L293 mo2
    old "If you want to cum, you have to beg for it."
    new "もしイキたいなら、お願いしなきゃダメよ。"

    # say L294 pla
    old "W- What?"
    new "W- 何それ？"

    # say L295 mo2
    old "Yes! Beg for it!"
    new "うん！お願いしてみて！"

    # say L296 pla
    old "P- please... L- let me cum..."
    new "P- お願い… L- 出させて…"

    # say L297 mo2
    old "Do you realize how pathetic that sounds?"
    new "あなたがどれだけ情けないか気づいてるの？"

    # say L298 mo2
    old "You are a cockroach, a disgusting and perverted cockroach ... What are you?"
    new "あなたはゴキブリ、汚らわしくて変態なゴキブリ……あなたは誰？"

    # say L299 pla
    old "I- I am a... D- disgusting and p- perverted... Cockroach."
    new "俺は… 不潔で変態な… ゴキブリだ。"

    # say L303 mo2
    old "And who am I?"
    new "そして私は誰ですか？"

    # say L304 pla
    old "Uhh... Y- you are m- my boss..."
    new "うーん… 君は俺の御主人様か…"

    # say L305 mo2
    old "I AM YOUR MASTER!"
    new "私はあなたの主人です！"

    # say L306 pla
    old "Uhh... My master, y- you are m- my master."
    new "うっ、御主人様、君は俺の御主人様だな。"

    # say L307 mo2
    old "That sounds much better."
    new "そう聞こえますね。"

    # say L311 mo2
    old "I guess you are finally learning."
    new "ようやく学び始めたのね。"

    # say L312 pla
    old "Ahh..."
    new "アッ…"

    # say L313 mo2
    old "Oh, are you close again?"
    new "また近づいてるの？"

    # say L314 mo2
    old "It would be a shame if I stop again, isn't it?"
    new "また止めるのはもったいないですよね。"

    # say L315 pla
    old "No, please... Don't stop... It hurts."
    new "お願い、止めて… 痛いよ。"

    # say L316 mo2
    old "Then beg your master!"
    new "では、ご主人様に頼んでみてください…"

    # say L317 pla
    old "Please, master... Please let me cum... I- I'm your... Slave!"
    new "お願い、ご主人様……お願い、イかせて……あ、私はあなたの……奴隷です！"

    # say L318 mo2
    old "Yes, you are..."
    new "はい、あなたは……"

    # say L319 pla
    old "Ahhhh!"
    new "アーッ！"

    # say L324 mo2
    old "Ughh gross..."
    new "うっぎゃーぐろす..."

    # say L325 mo2
    old "I guess you are learning some respect here, aren't you?"
    new "ここでは少しは敬意を学んでいるわね、そうよ。"

    # say L327 mo2
    old "Now, clean this, it's disgusting."
    new "では、これ掃除しなさい、汚いわ。"

    # say L340 mo2
    old "Ohh yeah, just like that little bitch."
    new "あらそう、その小犬みたいにね。"

    # say L342 mo2
    old "Keep licking it."
    new "舐めて続けてください。"

    # say L346 mo2
    old "Wow, you are not completely useless after all."
    new "あら、案外役立つじゃないの。"

    # say L347 mo2
    old "Ahh, finally you are doing a good job."
    new "ああ、やっとちゃんとしたことをしてくれてるわね。"

    # say L348 mo2
    old "I see you love licking and kissing my pussy..."
    new "あなたが私のオマンコを舐めたりキスしたりするのが好きなのは見えてるわ..."

    # say L353 mo2
    old "Ahh! Wow!"
    new "アッ！すごい！"

    # say L354 mo2
    old "Oh yeah, keep going little bitch!"
    new "あら、そうやって続けてちょうだい、 naughty子。"

    # say L356 mo2
    old "I'm your master and you gotta lick me until I tell you to stop."
    new "私はあなたの主人よ、私が止めるまで舐め続けなさい。"

    # say L379 mo2
    old "Don't stop, don't stop, you fucking bastard..."
    new "止めてほしくない、止めてほしくない、クソ野郎…"

    # say L381 mo2
    old "Oh gosh! Ahhhhh! Fuck!"
    new "あらっ！あぁん！くそっ！"

    # say L390 mo2
    old "Ahh, that wasn't bad, you are finally good at something."
    new "ああ、悪くなかったわ、あなたも上手になってきたね。"

    # say L391 pla
    old "T- Thank-"
    new "ありがとう、上手くなってきたね。"

    # say L392 mo2
    old "Anyway, get out, I have to work."
    new "それじゃ、出ていって。私は仕事があるの。"

    # say L397 mo2
    old "Uhhh, I think you are improving."
    new "うーん、あなたは上達してるみたいね。"

    # say L398 mo2
    old "Maybe I could reward you for doing a good job, maybe that way you will stop being a stupid useless at everything else."
    new "まあ、良い仕事をした報酬としてあなたに何かあげることもできるわ。そうすれば、他のことでは何もできない馬鹿だと思われなくなるかもしれないわね。"

    # say L399 pla
    old "W- what do you mean?"
    new "何を言っているの？"

    # say L400 mo2
    old "I'm tough but fair, and you have pleased me these last two times."
    new "私は厳格だけど公正よ、そしてあなたは最近の2回、私を満足させたわ。"

    # say L401 mo2
    old "Now it's time for a reward for this little pervert. Now take out your pants."
    new "今度はこの小悪魔への報酬の時間よ。さあ、パンツを脱いで。"

    # say L402 pla
    old "Y- yes master."
    new "はい、ご主人様。"

    # say L409 mo2
    old "What are you waiting for? I'm not going to do it for you, if you want to cum you will have to do it yourself, idiot."
    new "何を待ってるの？私がやってあげるわけないでしょう、イクなら自分でしなさい、バカ。"

    # say L410 pla
    old "Uhh... R- right, sorry."
    new "うーん… わかってる、ごめん。"

    # say L422 mo2
    old "Hahaha, you look like a poor animal begging to cum with my foot."
    new "ははは、あなたはまるで私の足でイキたいと懇願する可怜な動物みたいね。"

    # say L427 mo2
    old "Oh, you're getting more excited, just like a bitch in heat."
    new "あなた、ますます興奮してるわね、発情期の雌犬みたい。"

    # say L429 mo2
    old "You are disgusting."
    new "あなたは汚らわしい。"

    # say L433 mo2
    old "I see you're speeding up, Are you getting close?"
    new "あなたが早まってるのね、もうすぐイクの？"

    # say L434 pla
    old "Y- yes..."
    new "Ｙ－はい…"

    # say L435 mo2
    old "Don't you dare come on my foot, because I kill you."
    new "ダメよ、私の足でイクなんて絶対に許さないから。"

    # say L459 mo2
    old "Ohh, your cock is about to explode but you cannot cum because I haven't said you can do so..."
    new "ああ、あなたのチ○ポはもう爆発しそうなのに、私が許可しない限りイクことはできないわ…"

    # say L460 mo2
    old "Poor boy can't cum because I won't let you do it. Unless you beg for it."
    new "可怜な坊や、イクことを許さないからね。お願いしないとダメよ。"

    # say L461 pla
    old "... P- please master... L- let me cum."
    new "マスター、お願いします… 許して、このチンコにイかせてください。"

    # say L462 mo2
    old "Hmm, I'm not sure... you should give it a better try."
    new "うーん、そうね… もう少し上手に頼んでみたらどうかしら。"

    # say L463 pla
    old "I- I- I am your bitch... Just a cockroach, and you are my master, p- please let this cockroach c- cum..."
    new "俺は君の犬だ… ただのゴキブリで、君が俺の主人だ、お願い、このゴキブリにイかせてください…"

    # say L464 mo2
    old "Hmm, why do I have to be so merciful? Alright, stop moving, I'm gonna help you out."
    new "なぜ私がそんなに慈悲深くならなきゃいけないの？いいわ、動かないで、手伝ってあげるから。"

    # say L474 mo2
    old "One more time you see who is the Master..."
    new "もう一回見せてあげるから、誰が主人なのかってば…"

    # say L475 pla
    old "Y- Yes-"
    new "Ｙ－はい－"

    # say L476 mo2
    old "You're shit... Don't talk if I don't tell you so..."
    new "あなたはクソだ… 私が話すまで黙ってなさい…"

    # say L477 pla
    old "S- sorr-"
    new "すみません…"

    # say L478 mo2
    old "Shut up!"
    new "黙ってなさい！"

    # say L482 mo2
    old "Yeahh! I like when you don't talk and only listen to your master."
    new "はい！黙って私のお話を聞いているのが好きよ。"

    # say L484 mo2
    old "Fucking pervert!"
    new "クソ変態！"

    # say L486 mo2
    old "Shut up and follow my words... You won't talk if your master wants silence..."
    new "黙って私の言うことを聞いて… 主人が静かにしたいなら、あなたは絶対に話さないでね…"

    # say L490 mo2
    old "Oh look at you so vulnerable and needy."
    new "あら、そんなに弱々しくて頼りない顔をして。"

    # say L491 mo2
    old "Are you getting close? Because you look awful."
    new "近づいてるの？　だって顔が最悪だよ。"

    # say L492 pla
    old "Y- yes, master."
    new "はい、マスター。"

    # say L493 mo2
    old "Alright, don't cum until I tell you."
    new "大丈夫、私が許可するまでイッちゃだめよ。"

    # say L494 pla
    old "Uhh, Y- yes, m- master."
    new "うーん、はい、マスター。"

    # say L517 mo2
    old "Ask for permission if you want to cum."
    new "イク前に許可を求めてください。"

    # say L519 mo2
    old "Yes! Ask your Master for permission."
    new "はい！マスターに許可を求めてください。"

    # say L520 pla
    old "I need to cum... N- now, please."
    new "俺、イク… 今、お願い。"

    # say L521 pla
    old "M- Maste-"
    new "マスター…お願いいします…"

    # say L522 mo2
    old "You'll come whenever I want, not when you need to..."
    new "あなたが欲しがるときだけイクのよ、必要だからってわけじゃないわ…"

    # say L523 mo2
    old "Say that you're my little bitch... Say it and I'll make you cum, maybe... Who knows if I'll change my mind."
    new "あなたが私の小さなビッチだって言ってみなさい… 言うなら、イかせてあげるかもしれないわ… でも、私が気分を変えるかどうか、誰にもわからないわね。"

    # say L525 pla
    old "I- I'm your L- little B- bitch."
    new "僕は君の小さなビッチだ。"

    # say L526 pla
    old "Let me cum, please..."
    new "お願い、イさせて…"

    # say L532 mo2
    old "Uhh... Gross."
    new "うっ…気持ち悪い。"

    # say L544 mo2
    old "At least you're getting better on this."
    new "せめてこれについては上手になってきたわね。"

    # say L545 mo2
    old "Oh yeah, keep licking it."
    new "あらそう、もっと舐め続けて。"

    # say L547 mo2
    old "Uhh this position is pretty good!"
    new "うーん、この体勢はなかなかいいですね！"

    # say L551 mo2
    old "Do you like it? Having your master pussy on your face?"
    new "好きですか？主人のオマンコを顔に押し付けられて。"

    # say L553 mo2
    old "Good boy, keep doing it, and I might reward you."
    new "良い子ね、そのまま続けてくれたら、ご褒美をあげるかもしれないわよ。"

    # say L557 mo2
    old "Ahh! Yess!"
    new "アッ！ Yes！"

    # say L558 mo2
    old "Oh yeah, keep going, keep going!"
    new "ああん、そう、もっと続けて、続けて！"

    # say L584 mo2
    old "You're my bitch... Keep doing it."
    new "あなたは私のペットよ… 続けなさい。"

    # say L586 mo2
    old "Oh gosh! Ahhhh! Fuck!"
    new "あらっ！あぁぁぁ！くそ！"

    # say L593 mo2
    old "You're a bad employee but since you've done well today, I'm gonna give you something."
    new "あなたは悪い従業員だけど、今日はよく頑張ってくれたから、何かあげるわ。"

    # say L598 mo2
    old "However, you will keep licking and you will make me cum again."
    new "しかし、舌を動かし続けて、また私をイかせないとね。"

    # say L611 mo2
    old "Wow, you are definitely enjoying your master's pussy, right?"
    new "あら、主人のオマ○コを本当に楽しんでるのね、そう？"

    # say L612 pla
    old "Uhh I-"
    new "うっ、僕は-"

    # say L613 mo2
    old "Don't ever stop licking, or I'll rip your cock off!"
    new "絶対に舐め止めてはいけないよ、そうしないとおちんちん取っちゃうからね！"

    # say L618 mo2
    old "Look how much you enjoy it... Uhh? your little bastard."
    new "こんなに楽しんでるのを見て… うっ？ お前のかすり者。"

    # say L619 mo2
    old "You are really a pervert, is this what you wanted? Uh?"
    new "あなたは本当に変態ね、これが欲しかったの？ウッ？"

    # say L621 mo2
    old "Just keep going."
    new "そのまま続けて。"

    # say L625 mo2
    old "Oh yeah, keep going, make me cum again!"
    new "続けて、またイかせてくれ！"

    # say L626 mo2
    old "Don't stop, don't stop, you little bastard."
    new "止めてくれないで、止めてくれないで、悪い子。"

    # say L650 pla
    old "Ohhhh... F- Fuckk!"
    new "オーッ…… フッ、クソ！"

    # say L656 mo2
    old "Okay, I'm done here, I hope you don't screw it up again at work. Otherwise, next time it will be worse."
    new "私はここで終わりにするわ、あなたがまた仕事で失敗しないことを望むわ。そうでなければ、次はもっとひどいことになるわよ。"

    # say L657 mo2
    old "Get dressed and leave, I can't waste any more time with you."
    new "服を着て出て行きなさい、私はもうあなたと時間を無駄にできないわ。"

    # say L665 mo2
    old "Uhh that was good..."
    new "うーん、それは良かった..."

    # say L666 pla
    old "Alright, I'm gonna get dressed."
    new "分かった、着替えるぞ。"

    # say L667 mo2
    old "Oh gosh, I want a little more."
    new "あら、もっと欲しいわ。"

    # say L669 mo2
    old "Shut up and keep licking. I'm going to try something different."
    new "黙って舐め続けなさい。違うことを試してみるから。"

    # say L677 pla
    old "Oh wow! What the fuck!"
    new "おわっ！何だこれは！"

    # say L678 mo2
    old "Don't even think about saying or doing something, keep quiet, and don't stop licking."
    new "何も言ったりしたりしないで、黙って舐め続けてください。"

    # say L687 mo2
    old "This is what you always wanted, isn't it?"
    new "これが君がいつも欲しかったものじゃないの？"

    # say L689 mo2
    old "Getting your naughty and disgusting cock sucked."
    new "あなたのいやらしいコックを吸うのが、これがあなたがいつも欲しかったことでしょう？"

    # say L693 mo2
    old "Do you like it? Uh? Do you like your master sucking your cock?"
    new "好きですか？ええ？主人があなたのちんこをしゃぶってるのが好きですか？"

    # say L695 mo2
    old "Of course you do, look how excited and horny you are."
    new "もちろんそうよ、あなたの興奮と欲しそうな顔を見れば分かるわ。"

    # say L699 mo2
    old "Ohh, yeah, keep going, keep licking my pussy, you little pervert."
    new "ああ、そう、もっと続けて、私のオマンコを舐めて、あなたという小悪魔。"

    # say L700 mo2
    old "Are you going to remain useless, good for nothing? Are you going to keep doing it so that I continue to punish you?"
    new "無能なままなのかしら？ 良くも悪くも、続けば罰を続けるわよ。"

    # say L701 mo2
    old "You're my bitch, [pla] never forget about it."
    new "あなたは私の犬よ、[pla] 忘れないでね。"

    # say L724 mo2
    old "Ohh, yeah, don't stop, don't stop!"
    new "ああ、そう、止めてほしくない、止めてほしくない！"

    # say L725 pla
    old "I- I'm cumming!"
    new "出る、出ちゃう！"

    # say L726 mo2
    old "Ahhh I- I'm cumming to!"
    new "アッ、私、イクっ！"

    # say L733 mo2
    old "Ughhh, gross..."
    new "うっ、汚い..."

    # say L734 mo2
    old "I better go clean this up, it's disgusting... "
    new "あたし、これ片付けないと… 本当に汚いわ…"

    # say L745 mo2
    old "I'm your boss and your Master."
    new "私はあなたのボスで、あなたのマスターです。"

    # say L746 mo2
    old "And you're shit... And you do what I say."
    new "そしてあなたはクソだ… 私の言うことを聞くんだ。"

    # say L747 mo2
    old "Got it?"
    new "わかった？"

    # say L749 mo2
    old "You belong to me and I do whatever I fucking want with you."
    new "あなたは私のもので、私があなたに何をしてもいいんだよ。"

    # say L753 mo2
    old "Yeahh! This is what you like..."
    new "はいっ！これが好きでしょう…"

    # say L755 mo2
    old "Fucking pervert! Fucking slave... Useless bitch."
    new "クソ変態！クソ奴隷… 無能な女だね。"

    # say L757 mo2
    old "Your cock is really hard but I won't make you cum yet... Not if you are so eagered. You don't deserve to cum now."
    new "あなたのチ○ポは本当に硬くなってるけど、まだイかせないわ… そんなに焦ってるんじゃダメよ。今イく資格なんてないわ。"

    # say L761 mo2
    old "You are about to explode! isn't it? Fuck you!"
    new "あなた、もう我慢できないくらいじゃない？クソッ！"

    # say L763 mo2
    old "Say who is your Master?"
    new "誰があなたの主人なのか言っちゃう？"

    # say L765 mo2
    old "Say it out loud NOW!"
    new "今すぐ大声で言うの！"

    # say L766 mo2
    old "If you wanna cum, you'll need to say it!"
    new "もしイクなら、それを言わないとダメよ！"

    # say L767 pla
    old "Y- You... You're my Master."
    new "君……君は俺のマスターだ。"

    # say L768 mo2
    old "You want to cum... Poor boy can't come because I won't let him do it."
    new "あなたがイキたいのね……可怜な子、私が許さないからイけないのよ。"

    # say L791 mo2
    old "If you want to come, you have to beg for it again."
    new "また懇願しなきゃならないわね。"

    # say L792 pla
    old "A- again..."
    new "またか…"

    # say L793 mo2
    old "Yes! Beg for it! You have to learn little bitch."
    new "はい！お願いしなさい！あなたは小さなクソッタレだから学ばなきゃならないの。"

    # say L794 pla
    old "P- please, I- I need to cum... I really need it... N- now."
    new "お願い、出したい……本当に今すぐに出したい……。"

    # say L795 mo2
    old "You'll cum whenever I want not when you need to..."
    new "私が望む時にイかせるわ、あなたが必要とする時じゃないの。"

    # say L796 mo2
    old "Say that you're my bitch... Say it and I'll let you cum."
    new "あなたが私の犬だと言いましょう… 言ってくれればイかせてあげる。"

    # say L798 pla
    old "I'm your b- bitch, master..."
    new "俺は君の犬だ、主人…"

    # say L805 mo2
    old "I didn't expect this to happen but I'll do it..."
    new "こんなことになるとは思わなかったけど、やるわ…"

    # say L806 mo2
    old "I've tried to show you who is the Master here but you still refuse to believe..."
    new "私がここで誰が本当の主人なのかを示そうとしたのに、まだ信じようとしないのね…"

    # say L807 mo2
    old "We cannot keep going in the same way... Now you'll know who is the master and who is the slave."
    new "同じように続けるわけにはいかないわ……これからは誰が主人で誰が奴隷なのか、よくわからせてあげるから。"

    # say L809 mo2
    old "I'm your fucking Master and you're my slave, you listen and do as I say..."
    new "私はお前のマスターで、お前は私の奴隷。言うことを聞いてくれないと困るのよ…"

    # say L810 mo2
    old "This is not a game! I'm gonna fuck you if I want, you do as I tell you..."
    new "これは遊びじゃないわ！私がやりたいときにはあなたを犯す、私が言うことを聞いてくれないと困るわよ…"

    # say L811 pla
    old "W- what-"
    new "W- 何言ってんの…"

    # say L827 mo2
    old "Little bastard, useless and needy..."
    new "小鬼、無能で頼りないくせに…"

    # say L829 mo2
    old "I'm your Master and I want you to say it more often."
    new "私はあなたのマスターだから、もっと頻繁に言ってほしいの。"

    # say L830 pla
    old "M- Mas-"
    new "マ、マスター…"

    # say L831 mo2
    old "I don't hear you!"
    new "聞こえていないわ！"

    # say L832 mo2
    old "Say it! Who is your Master?"
    new "言え！誰があなたの主人なの？"

    # say L833 pla
    old "Y- You..."
    new "君の…マスターは…"

    # say L838 mo2
    old "Seems that the slave is doing okay..."
    new "奴隷は上手くいっているみたいですね…"

    # say L840 mo2
    old "Are you enjoying this? Who told you to enjoy this... You're just a fucking slave..."
    new "楽しんでるの？誰が楽しんでもいいって言ったの？ただのクソ奴隷じゃないの…"

    # say L842 mo2
    old "You're almost nonexistent... Without me, you're nothing. Without your Master, you're nothing."
    new "あなたはほとんど存在しないもの……私なしには、あなたは何もならないわ。マスターなしには、あなたは何もならないわ。"

    # say L843 mo2
    old "I'll make you suffer, motherfucker!"
    new "私が苦しめるわ、クソ野郎！"

    # say L848 mo2
    old "You are about to explode! isn't it? Fucking idiot!"
    new "あなたは今にも爆発しそうじゃない？クソバカ！"

    # say L850 mo2
    old "I'm fucking you, little bastard."
    new "私はあなたを犯しているわ、小鬼。"

    # say L851 mo2
    old "Now you are my bitch, I'm fucking my little bitch."
    new "今では私のビッチね、私の小さなビッチを犯してるのよ。"

    # menu L872 
    old "Change perspective"
    new "視点変更"

    # say L882 mo2
    old "Ohh yeahh, can you feel how hard I'm fucking you?"
    new "ああん、感じる？どれだけ激しく犯してんのかしら？"

    # say L883 pla
    old "Ahhh... I- I-"
    new "アッ……イ、イきそう……"

    # say L884 mo2
    old "Yes, I'm cuming on you fucking bastard"
    new "はい、あなたのクソ野郎、私はあなたの中に出すわ。"

    # say L893 mo2
    old "All right, I already made you my bitch!"
    new "よし、もうあなたのビッチにしちゃったわ！"

    # say L894 mo2
    old "Never ever, try to rebel against me, I am your master."
    new "絶対に私に反抗するなんて考えないで、私はあなたの主人なの。"

    # say L909 mo1
    old "Oh, yes [mo2]! I missed you so much..."
    new "ああ、[mo2]！ あなたを本当に待ち侘びてた..."

    # say L910 mo2
    old "Uhh... You are fucking hot babe..."
    new "うーん… 君は本当にエロいね…"

    # say L911 mo1
    old "This feels so nice... Oh my God!"
    new "この感じがいいの... ああ、神！"

    # say L915 mo2
    old "Ahhh, don't stop baby, don't stop!"
    new "アーン、止めてBaby、止めてないで！"

    # say L916 mo1
    old "Oh yes! I have been waiting a lot for this!"
    new "ああ、そうよ！これのためにずいぶん待ってたのね。"

    # say L917 mo1
    old "I love you [mo2], I love you so much!"
    new "あなたを愛してる[mo2]、本当に愛してるの！"

    # say L918 mo2
    old "I love you too. You are my girl."
    new "私もあなたを愛してるわ。あなたは私の女の子よ。"

    # say L919 pla
    old "(What the fuck, she doesn't sound like the [mo2] I know...)"
    new "何だよ、全然知ってる [mo2] の声じゃないじゃん…"

    # say L923 mo2
    old "Oh yeah, just like that babe, Just like that!"
    new "そうそう、その通り、ベイビー、その通り！"

    # say L924 mo1
    old "Ahhh, Ahhh! I love you."
    new "アッ、アッ！あなたが大好きだわ。"

    # say L925 mo2
    old "Keep going, keep going!"
    new "続けて、続けて！"

    # say L926 mo1
    old "Oh my God, I'm so fucking horny!"
    new "ああん、もう我慢できないくらい興奮してるの！"

    # say L950 mo2
    old "Yes, Yes, cum for me baby!"
    new "はい、はい、私の中に出してちょうだい、ベイビー！"


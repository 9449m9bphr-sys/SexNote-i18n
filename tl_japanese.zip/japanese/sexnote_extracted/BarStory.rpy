# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/BarStory.rpy
translate japanese strings:

    # say L4 bri
    old "Hey [pla], wake up!"
    new "Hey [pla]、起きて！"

    # say L5 pla
    old "Hmm... Just a little longer..."
    new "うーん… もうちょっとだけ…"

    # say L6 bri
    old "I said..."
    new "言ったのに…"

    # say L13 pla
    old "What? What's happening? Is there anything wrong?!"
    new "何？何が起こってる？何か問題でもあるのか？！"

    # say L14 bri
    old "What's wrong is that it's been a while since I created the portal we're going to use to restore the magic world."
    new "何が問題って、魔法の世界を復活させるためのポータルを作ったのが随分前だからよ。"

    # say L16 bri
    old "But I haven't seen you make any progress with our objective ever since."
    new "でも、あなたが私たちの目的に向けて進展しているのを見たことがないの。"

    # say L17 bri
    old "Why is it taking so long for you to get to it?"
    new "何でそんなに時間がかかってるの？"

    # say L19 pla
    old "What?! You woke me up for that? What are you talking about?"
    new "何だよ、そんなことで起こしたのか？何を言ってるんだよ？"

    # say L20 pla
    old "It's not as if it's easy you know?"
    new "簡単なことじゃないって、分かってるだろ？"

    # say L22 pla
    old "Do you want me to just walk around and tell people {i}'Hey! let me get you pregnant'{/i}?"
    new "君が妊娠させてやるって、街中で歩き回って {i}「HEY！ 妊娠させてあげるよ」{/i} って言うわけ？"

    # say L23 pla
    old "I can already imagine the looks I'll get."
    new "俺がどんな目で見られるか、もう想像できるよ。"

    # say L25 bri
    old "That's not what you're going to do! You have to seduce them!"
    new "そんなことするもんじゃないわ！ ちゃんと彼らを誘惑しなきゃならないのよ！"

    # say L27 bri
    old "I thought you were supposed to be charming to human females."
    new "あなたは人間の女性に対して魅力的でいるはずだと思ったわ。"

    # say L29 bri
    old "Try that!"
    new "やってみ！"

    # say L33 pla
    old "Why are you so worried about me doing it quickly anyway?"
    new "なぜそんなに早く終わらせたいのか？"

    # say L35 pla
    old "I thought you had stabilized the portal. So we have time, right?"
    new "君がポータルを安定させたと思ったけど、時間はあるんだろ？"

    # say L36 bri
    old "Yeah, time to do the ritual properly."
    new "ちゃんと儀式をする時間だわ。"

    # say L38 bri
    old "Not to laze around and not get anything done!"
    new "何もしないでダラダラする時間じゃないわ！"

    # say L40 bri
    old "This is urgent business [pla]."
    new "これは緊急の用件よ [pla]。"

    # say L42 bri
    old "The magic world is gone, and this portal might be the only chance we get to save it."
    new "魔法の世界は消えてしまったけど、このポータルが唯一の救いのチャンスかもしれない。"

    # say L44 bri
    old "And the fact that it's stable for now doesn't mean it's going to last forever."
    new "そして、今の安定が永遠続くわけじゃないわ。"

    # say L46 bri
    old "If we want to reform the magic world we need to move fast!"
    new "魔法世界を再構築するなら、早く動かないと！"

    # say L48 bri
    old "There's no time to just lay about doing nothing."
    new "何もしないでいる時間はないわ。"

    # say L49 pla
    old "Ok, I get it I get it! I'll get to it!"
    new "分かった分かった！すぐにやるよ！"

    # say L50 bri
    old "When?"
    new "いつ？"

    # say L51 pla
    old "Soon!"
    new "すぐだよ！"

    # say L53 pla
    old "Jeez! What's gotten into you all of a sudden?!"
    new "ジーゼル！急にどうしたんだよ？！"

    # say L57 bri
    old "I'll remind you that you and your little friend Linnet made a mess out of this entire situation!"
    new "あなたとあなたの小さな友達リンネットが、この状況をめちゃくちゃにしてしまったことを思い出させてあげるわ！"

    # say L58 bri
    old "And I'm the one that's going to have to fix it!"
    new "そしてそれを修復するのは私なんだから！"

    # say L60 bri
    old "So, since the portal won't last forever, and you clearly don't want to re-start the process from the beginning..."
    new "だから、ポータルは永遠に続かないし、君も最初からやり直したいわけじゃないだろう？"

    # say L62 bri
    old "Start looking for the people we need!"
    new "必要な人を探し始めて！"

    # say L63 pla
    old "Ok, ok, I'll do it!... I guess I could start talking to people."
    new "分かった、分かった、やるよ！…とりあえず人とか話してみるか。"

    # say L65 pla
    old "It's just that that's quite difficult to do, you know?"
    new "それがそんなに簡単じゃないんだよ、分かるだろ？"

    # say L66 bri
    old "Oh come on, it won't be that bad."
    new "大丈夫よ、そんなに悪くないわ。"

    # say L68 bri
    old "I bet you'll get to have plenty of fun."
    new "楽しいことたくさんあるわね。"

    # say L76 mo1
    old "Hello [pla], good morning."
    new "こんにちは[pla]、おはようございます。"

    # say L79 pla
    old "H- hi [mo1rel], how are you? Good morning."
    new "おお、[mo1rel]、元気にしてる？おはようございます。"

    # say L80 mo1
    old "Were you talking to someone?"
    new "誰かと話してたの？"

    # say L81 pla
    old "What? No, no, no..."
    new "何？いいえ、いいえ、いいえ…"

    # say L82 pla
    old "Just to myself, you know?"
    new "自分に話しかけてただけだよ、わかってるでしょ？"

    # say L83 mo1
    old "Ohh... Okay."
    new "あっ… 分かったわ。"

    # say L85 mo1
    old "Listen [pla], I need you to do me a favor."
    new "[pla]、ちょっとお願いがあるの。"

    # say L91 mo1
    old "Hmm... [pla]?"
    new "うーん… [pla]？"

    # say L92 pla
    old "Uhh... Sure, what do you need?"
    new "うーん…いいよ、何が必要なんだ？"

    # say L94 mo1
    old "Well, I was wondering if you could please bring some documents to the [mo2]'s office for me."
    new "WELL、あなたが [mo2] のオフィスにいくつかの書類を持って行ってくれるかどうか考えていました。"

    # say L95 mo1
    old "You don't need to go up to her office, just leave them at the reception of the building."
    new "あなたが彼女のオフィスまで行かなくても大丈夫です、建物の受付に置いてきればいいんです。"

    # say L97 pla
    old "Sure, no problem."
    new "もちろんだ、問題ないよ。"

    # say L99 mo1
    old "Thank you so much, honey. You are always so helpful."
    new "ありがとう、亲爱的。いつもこんなに役立つわ。"

    # say L107 bri
    old "Hmm... I suppose you're going to do that for your [mo1rel] now, aren't you?"
    new "うーん……多分、今からあなたの[mo1rel]のためにそれをするつもりなのね？"

    # say L108 pla
    old "Uhh... Yeah, Of course."
    new "うーん… そうだな、もちろん。"

    # say L110 bri
    old "Okay, I'm coming with you. You won't stop our task, so I'll help you look for our first target."
    new "Okay、一起去吧。あなたが任務を止めるわけないんで、最初の目標を探す手伝いをするわ。"

    # say L112 pla
    old "{b}*Sigh*{/b} Alright, let's go."
    new "{b}…ふう {/b} 分かった、行こう。"

    # say L139 bri
    old "So, as I was saying, you should've at least talked to somebody while we were coming here."
    new "だからって、せめて誰かと話す時間作るべきだったわよ。"

    # say L141 bri
    old "At this rate you're never going to end with what we have to do!"
    new "この調子じゃ、やるべきことが終わることなんてないよ！"

    # say L142 bri
    old "You should be putting all your focus on that!"
    new "そのことに集中しなきゃダメよ！"

    # say L149 pla
    old "But I have to do this first! So let me finish here, and then we can start looking for people for your ritual!"
    new "でもまずはこれを終わらせなきゃ！だからここで終わらせてから、君の儀式のために人を探し始めるよ！"

    # say L151 bri
    old "Alright! But as soon as you finish, I'll pester you to get to it!"
    new "分かったわ！でも君が終わったら、すぐにその件を進めさせちゃうからね！"

    # say L152 pla
    old "Yeah, yeah, whatever."
    new "うん、うん、いい啦。修正：うん、うん、何でも。"

    # say L221 pla
    old "Oh... Uhh... Yeah, Hi Barbie, how are you doing?"
    new "オッ… アー… ヤッ、ハイ バービー、元気にしてる？"

    # say L232 pla
    old "Uhh... No, actually, I didn't come to see her."
    new "うーん… いや、実は彼女に会いに来たわけじゃなかった。"

    # say L233 pla
    old "I have something for [mo2], but I was told I could just leave it with you."
    new "俺は[mo2]に渡すものがあるんだが、君に預けても大丈夫って言われたんだ。"

    # say L236 bri
    old "Hey, [pla]!! Did you hear what I told you?!"
    new "HEY、[pla]！！ 私が言ったこと聞いてくれた？"

    # say L244 pla
    old "What? No, no, sorry."
    new "何？いや、いや、悪い。"

    # say L245 pla
    old "I- uhm, I didn't mean to be rude."
    new "うーん、失礼するつもりはなかったんだよ。"

    # say L247 pla
    old "I meant to say, {i}‘ok, alright, that's great'{/i}."
    new "俺は {i}「いいよ、わかった、それならいい」{/i} って言いたかったんだ。"

    # say L250 pla
    old "Right."
    new "分かったな。"

    # say L255 pla
    old "Sure, thank you."
    new "うん、ありがとう。"

    # say L257 pla
    old "Thanks Barbie, I guess I'll see you later."
    new "ありがとう、Barbie。じゃあ、また後でな。"

    # say L273 bri
    old "Great news [pla]! As I told you before, we have the first target to start cultivating power for the spell!"
    new "素晴らしいニュースだわ [pla]！前に言った通り、呪文のために力を育てる最初の対象が決まったの！"

    # say L275 pla
    old "Yeah, I figured..."
    new "うん、予想してたよ…"

    # say L276 pla
    old "Is that why you interrupted me while I was talking to her?"
    new "それであいつと話してた最中に邪魔したのか？"

    # say L278 bri
    old "Well, it was important that you knew..."
    new "大事なことだから知って欲しかったのよ…"

    # say L279 bri
    old "But anyway, that doesn't matter."
    new "でも、それは別にいいわ。"

    # say L281 bri
    old "What's important is that that woman you were talking with will be our first target."
    new "重要なのは、あなたが話していたあの女性が私たちの最初の標的になるってことよ。"

    # say L283 bri
    old "Well, while you two were talking, I was examining her."
    new "二人が話している間に、私は彼女を観察していたの。"

    # say L285 pla
    old "Yeah, I noticed... That was weird, luckily no one else can see you."
    new "ああ、気づいた… ちょっと不気味だったけど、幸い他の誰も君を見ていなかったみたいだ。"

    # say L287 bri
    old "Yeah, yeah, whatever, the point is that she's the first person you have to seduce for our ritual."
    new "まあ、まあ、そんなことはおいておいて、彼女が最初に誘惑しなきゃならない人だってこと。"

    # say L288 pla
    old "Huh?! W- why? Why does it have to be her?"
    new "へっ？！ なんで？ なんで彼女でなきゃならないんだ？"

    # say L290 bri
    old "Because she's the right specimen, she has just the right qualities we need for it."
    new "彼女が適切な標本だからよ、必要な資質を全部持ってるの。"

    # say L292 bri
    old "As far as you humans go, she's the best prospect I could have expected to find to start our ritual."
    new "君たち人間の中では、彼女がこの儀式を始めるのに最適な候補者だよ。"

    # say L294 pla
    old "Why? What's so special about her?"
    new "何がそんなに特別なのか？"

    # say L296 bri
    old "Well, as I said she has the perfect qualities... To- to..."
    new "まあ、言った通り、彼女は完璧な資質を持っていて… ト- ト-"

    # say L298 bri
    old "H- host and... Condense the magic power within her."
    new "ホストとして… 魔力を凝縮できるの。"

    # say L299 bri
    old "Her body composition is just the right one."
    new "彼女の体の構成はちょうどいいの。"

    # say L300 pla
    old "Right..."
    new "そうだな…"

    # say L301 bri
    old "Besides, this should be easy to do, right?"
    new "それに、これくらい簡単だろう？"

    # say L303 bri
    old "Isn't she the type of female you male humans like?"
    new "彼女は男の人が好きそうなタイプの女性だよね？"

    # say L305 bri
    old "Her mammary glands are gigantic, even for the standards of what your species would consider big."
    new "彼女の乳房は、あなたの種族が大きいと感じる基準でも、巨大だよ。"

    # say L307 bri
    old "And I {i}know{/i} you just love that sort of thing."
    new "そして、{i}あなたがその手のことを愛していること{/i}は知ってるよ。"

    # say L309 bri
    old "So don't think too much about it. Just focus on having a good time."
    new "だから深く考えすぎないで。楽しく過ごすことに集中しよう。"

    # say L310 bri
    old "If you seduce her, and implant the magic within her you'll enjoy it, won't you?"
    new "あなたが彼女を誘惑して、魔法を植え付けるなら、きっと楽しむでしょう？"

    # say L311 pla
    old "Ugh, I guess you're right."
    new "うーん、確かにそうだな。"

    # say L313 pla
    old "But I barely know her, we have never exchanged more than a couple of words, how the hell am I going to seduce her?"
    new "でも、彼女のことほとんど知らないし、数回しか会話したことないんだよ、どうやって誘惑するんだよ？"

    # say L314 bri
    old "Don't worry, I'll help you with that."
    new "心配しなくていい、私が手伝うから。"

    # say L315 pla
    old "Hahaha... Really? How?"
    new "ははは…マジで？どうすんの？"

    # say L317 bri
    old "By using magic of course!"
    new "もちろん魔法を使うさ！"

    # say L319 bri
    old "There's a lot of magic you still don't know about, you've barely scratched the surface of what's possible."
    new "まだ知らない魔法がたくさんあるの、あなたは可能性の表面をかすめた程度よ。"

    # say L321 bri
    old "By employing a simple mind reading spell, I can get inside her thoughts and emotions."
    new "単純な思念読み取りの呪文を使えば、彼女の思考や感情を読み取ることができるわ。"

    # say L322 bri
    old "And let you know what she has in her mind while you're speaking to her."
    new "そして、あなたが彼女と話している間、彼女の頭の中身を知ることができる。"

    # say L324 bri
    old "I can even read deep thoughts, and see if anything is influencing her deep mind."
    new "深い思考まで読み取れて、彼女の心に何か影響を与えているものがあれば見つけられるわ。"

    # say L326 pla
    old "I have to say, that sounds amazing."
    new "それはすごいな。"

    # say L328 bri
    old "It is, but it's also inconvinient. Since I'll be reading her mind and telling you what she's thinking."
    new "それはそうだけど、不便な点もあるの。彼女の心を読み取りながらそれをあなたに伝える必要があるから。"

    # say L329 bri
    old "That means that whenever you talk to her I'll have to be with you."
    new "それって、あなたが彼女と話すたびに私が一緒でなきゃならないってことよね。"

    # say L331 bri
    old "Besides, in order to maintain the mind-reading, I have to keep the channel between her mind and mine open."
    new "それに、心読みを続けるためには彼女の心と私の心の間の通路を開けたままにしなきゃならないの。"

    # say L332 bri
    old "That drains the magic power too quickly."
    new "魔力が消耗するのが早すぎるの。"

    # say L333 bri
    old "So you'll have to be sure to make good use of the information I'm able to give you."
    new "だから、私が与えられる情報をうまく活用しなきゃダメよ。"

    # say L335 pla
    old "I get it, but if it's that difficult, why don't you teach me the spell to do it myself?"
    new "分かってるけど、そんなに難しいなら、自分でできる術を教えてくれない？"

    # say L336 pla
    old "That way I can just do the mind reading by myself, and your magic reserves won't have to be drained."
    new "そうすれば俺自身で心を読めるし、君の魔力も消耗しないで済むよ。"

    # say L338 bri
    old "Sadly I can't do that, this spell is a level beyond your current abilities."
    new "残念だけど、その術はあなたの今の力じゃまだ無理よ。"

    # say L339 bri
    old "The complexity is too high for you to handle right now."
    new "今のあなたではその複雑さを扱うのは無理よ。"

    # say L341 bri
    old "Maybe if you had been a bit more diligent with your practices..."
    new "もしかしたら、練習をもっと真面目にやっていれば……"

    # say L342 bri
    old "And had improved your abilities with the Sexnote, you'd be able to do it."
    new "Sexnoteの能力をもっと磨いてたら、君はそれができただろうに。"

    # say L343 bri
    old "But it didn't happen, did it?"
    new "でも、そうなってないよね。"

    # say L345 bri
    old "So, I'll have to do the hard work of reading her mind and telling you what to say."
    new "じゃあ、私が彼女の気持ちを読み取って、あなたに何を言えばいいか教えてあげるしかないね。"

    # say L346 pla
    old "I see, I guess that's how it has to be."
    new "なるほど、そうするしかないのか。"

    # say L348 pla
    old "Oh! I know!"
    new "オッ！分かった！"

    # say L350 pla
    old "What about the {i}Sauron Mouth?{/i} I could use that instead of you having to use your magic, right?"
    new "サウロンマウスはどうだ？{i} お前が魔法を使う必要ないじゃん？ {/i}"

    # say L352 bri
    old "What? What are you talking about? Didn't you pay attention when you learned the spell?!"
    new "何言ってるの？呪文を学んだときちゃんと聞いてなかったの？！"

    # say L354 bri
    old "The {i}Sauron Mouth{/i} doesn't work like that."
    new "{i}サウロンマウス{/i}はそんな風には機能しないわ。"

    # say L355 bri
    old "There are two conditions that prevent anyone from using it to just outright control another person."
    new "二つの条件があって、誰もそれを使って他人をただ単にコントロールすることはできないの。"

    # say L357 bri
    old "First, it's not a mental power; it works by {b}influencing{/b}, not {b}forcing{/b} the will of the target."
    new "まず、これは精神的な力ではなく、対象の意思を{b}影響{/b}するものであって、{b}強制{/b}するものじゃないの。"

    # say L359 bri
    old "So, you can't just make someone do something they don't want to do, you can't go over personal limits."
    new "だから、相手が望んでいないことを強制することはできないし、個人の限界を超えさせることもできない。"

    # say L361 bri
    old "Is not like you can just tell someone to fall in love with you or anything."
    new "そんな風に誰かにあなたを愛してほしいと命令することはできないわ。"

    # say L362 pla
    old "I get it, I can't 'force' anyone with the {i}Sauron Mouth{/i}."
    new "分かってる、{i}Sauron Mouth{/i}で誰かを強制することなんてできない。"

    # say L363 bri
    old "Is not just that, you can't use it on someone if you don't have a connection to them."
    new "ただそれだけじゃなくて、相手とつながりがないと使えないんだよ。"

    # say L365 bri
    old "So, even if you go up to her and tell her to do something, it won't work, since you barely know each other."
    new "だから、彼女に近づいて何かを命令しても、お互いにほとんど知らないから効かないわ。"

    # say L367 bri
    old "There are no shortcuts for this [pla], you have to do it properly."
    new "これには近道がないのよ [pla]、ちゃんとした方法でやらなきゃ。"

    # say L368 pla
    old "I get it, I get it, so that's a no on the {i}Sauron Mouth{/i} then."
    new "分かってる、分かってる、じゃあ {i}Sauron Mouth{/i} は無しだな。"

    # say L369 bri
    old "It is, you see why I keep pestering you to start working on the ritual? It's a lot of work, and we don't have much time."
    new "そうよ、だからあなたに儀式の準備を始めるようしつこく言ってるの。大変な作業だし、時間もあまりないんだから。"

    # say L370 pla
    old "Yeah, yeah I get it."
    new "分かった、分かった。"

    # say L372 bri
    old "Good, now that you understand it, let's go."
    new "分かったわ、それなら今から行こう。"

    # say L374 pla
    old "What?! Now?"
    new "何だよ、今？"

    # say L376 bri
    old "Yes, now! Haven't you understood how urgent this is?"
    new "うん、今だよ！まだこの緊急性が分かっていないの？"

    # say L377 pla
    old "But we just arrived! I was just there a moment ago! If I go back now, it will look weird."
    new "でも刚着いただけだよ！今更戻ったら変に思われるだろ。"

    # say L379 bri
    old "Don't you worry about that, after all, I will be reading her mind and telling you what you need to know to handle the situation."
    new "そんな心配はいらないわ、私が彼女の気持ちを読み取って、状況をうまく処理するために必要なことを教えてあげるから。"

    # say L380 pla
    old "You sound very confident about this."
    new "君はこれに関してかなり自信満々だな。"

    # say L381 bri
    old "Well is not as if it's difficult..."
    new "まあ、難しくはない啦。"

    # say L383 bri
    old "You humans are so easy to manipulate! You just have to say the right thing and you fold!"
    new "あなたたち人間は操作するのが簡単よ！ 正しいことを言えば、すぐに折れちゃうんだから！"

    # say L385 pla
    old "We do? How do you know that?"
    new "俺たちってそんなに簡単に操られるのか？どうしてそう思うんだ？"

    # say L386 bri
    old "I- I mean..."
    new "あっ、あの…"

    # say L388 bri
    old "It's what I've observed in my time here watching you and the other humans."
    new "ここにいる間、あなたと他の人間を見ているうちにそう思ったのよ。"

    # say L390 pla
    old "Hmm... alright."
    new "Hmm... そうだな。"

    # say L391 pla
    old "I guess you're right."
    new "そうだな、君の言う通りかもしれない。"

    # say L393 bri
    old "Of course I am!"
    new "もちろんよ！"

    # say L394 bri
    old "Now, let's go seduce that human with the big mammary glands!"
    new "さあ、その大きな胸を持つ人間を誘惑に行こう！"

    # say L395 pla
    old "{b}*Sigh*{/b} Alright let's go."
    new "{b}*ため息*{/b} さあ、行こう。"

    # say L409 pla
    old "Hi Barbie."
    new "嗨、Barbie。"

    # say L411 pla
    old "... Again."
    new "またか。"

    # say L417 pla
    old "Uhm, no."
    new "うーん、違うよ。"

    # say L419 pla
    old "I actually came to talk with you."
    new "実は君と話すために来たんだ。"

    # say L422 pla
    old "Hmm, yeah..."
    new "うーん、そうだね…"

    # say L424 pla
    old "About what..."
    new "何についての話だよ…"

    # say L425 pla
    old "Hmm, that's... {i}a good question...{/i}"
    new "うーん、それは… {i}いい質問だな…{/i}"

    # say L426 bri
    old "Sigh! Look at you strugling to come up with something."
    new "ため息！　君は何か答えを出そうとして苦労してるんだね。"

    # say L427 bri
    old "Don't worry, I have this."
    new "心配しないで、これなら大丈夫。"

    # say L432 bri
    old "[pla]! She's feeling sad about something."
    new "[pla]！何か悲しいことがあったみたいね。"

    # say L435 pla
    old "Is just that you looked a little sad to me when I saw you."
    new "見かけたとき、君は少し悲しそうだったからさ。"

    # say L436 pla
    old "So I was wondering if there's anything that I could do for you, maybe you would like to talk about it?"
    new "だから何か手伝えることがあったら言ってくれよ。何か話したいことがあったらいつでも聞くよ。"

    # say L447 bri
    old "That's a lie! She's feeling a great sadness!"
    new "それは嘘よ！彼女は本当に深い悲しみを感じているの！"

    # say L448 bri
    old "I don't know yet what it is, but she's definitely sad about something."
    new "まだ何が原因かわからないけど、彼女は何かで落ち込んでいるのは確かだよ。"

    # say L450 pla
    old "Are you sure about it?"
    new "本当にそうなのか？"

    # say L451 pla
    old "I don't want to be annoying or anything, is just that you seem like you have a lot on your mind."
    new "君が何かを抱えてるみたいに見えるんだけど、迷惑になるつもりはないよ。"

    # say L453 pla
    old "And I would like to help you with {i}anything{/i} if possible."
    new "君が何か抱えてるなら、俺が手伝うよ。{i}何でも{/i}。"

    # say L463 bri
    old "Oh! It seems she's feeling frustrated about something!"
    new "あっ！何かでイライラしてるみたいね。"

    # say L464 bri
    old "It's just hard to tell about what... She has a lot of emotions and thoughts going through her..."
    new "何についてなのか、ちょっとわかりにくいの... 彼女は感情や考えがめちゃくちゃ複雑だから..."

    # say L465 bri
    old "Just give me a second."
    new "ちょっと待ってね。"

    # say L467 pla
    old "Really? That's a relief to hear, it's good that you're doing so well."
    new "ほんと？それは安心した、君が調子良さそうで良かったな。"

    # say L468 pla
    old "It just looked for a moment there like you had something in your mind."
    new "ちょっと見ただけで、何か考えてるんじゃないかと思ったけど。"

    # say L470 pla
    old "Kind of as if you were feeling {b}frustrated{/b} about something."
    new "ちょっと、何かで {b}イライラ{/b} してるみたいだったんだよ。"

    # say L471 pla
    old "But you aren't, right?"
    new "でも、そうじゃないよね？"

    # say L484 bri
    old "And it's related to why she's feeling frustrated."
    new "それが彼女がイライラしてる理由なの。"

    # say L485 bri
    old "She recently failed at something..."
    new "彼女は最近何かで失敗したの..."

    # say L487 bri
    old "An audition!"
    new "オーディション！"

    # say L490 bri
    old "What's an audition?"
    new "オーディションって何？"

    # say L491 pla
    old "{i}(I see now!){/i}"
    new "{i}(なるほど！){/i}"

    # say L492 pla
    old "Well, I'm happy you're feeling well."
    new "まあ、君が元気なのは嬉しいけど。"

    # say L494 pla
    old "Maybe I'm just projecting myself."
    new "もしかしたら俺が自分を投影してるだけかもしれないな。"

    # say L496 pla
    old "You see, I recently failed an interview for a job I wanted."
    new "実は最近、欲しかった仕事の面接に落ちたんだ。"

    # say L501 pla
    old "Yeah... I really wanted to get it. And I thought I was the best for it, but the hiring team chose someone else."
    new "ああ…ほんとにかに欲しかったんだ。自分が最適だって思ってたのに、採用チームは他の人を選んだんだ。"

    # say L508 bri
    old "[pla]! Now she's remembering something else!"
    new "[pla]！今何かを思い出したみたいだな。"

    # say L511 bri
    old "What is this feeling?..."
    new "この感じは何？..."

    # say L516 pla
    old "Yeah, it was a huge {b}disappointment{/b} that I wasn't able to get it."
    new "そうだな、{b}期待はずれ{/b}だった。うまくいかなかったけど。"

    # say L518 pla
    old "But I guess I have to let it go."
    new "でも、諦めるしかないみたいだな。"

    # say L520 pla
    old "I think that, sadly, sometimes our projects don't turn out the way we want them to. You know?"
    new "俺も思うけど、残念ながら時々プロジェクトは上手くいかないこともあるんだ。わかるでしょ？"

    # say L523 pla
    old "You do?"
    new "そうか"

    # say L529 pla
    old "Yeah, that's right."
    new "そうだな。"

    # say L530 pla
    old "But you know what? I think I'll give it another go and I'll try to get that job."
    new "でもさ、また挑戦してみるか。その仕事に合格できるように頑張るつもりだ。"

    # say L536 pla
    old "Well, I guess I'll just have to try again, and again until I make it."
    new "まあ、何度も挑戦して、やるまで続けるしかないな。"

    # say L538 pla
    old "After all, this job is sort of a {i}dream{/i} of mine."
    new "この仕事は俺の{i}夢{/i}なんだよ。"

    # say L539 pla
    old "So I wouldn't want to give up on it for nothing."
    new "だから簡単に諦めたくはないんだよ。"

    # say L544 pla
    old "Do you? What do you mean?"
    new "何だよ、どういうこと？"

    # say L547 pla
    old "Is there something you shouldn't give up on?"
    new "何か手放しちゃいけないものでもあるのか？"

    # say L548 bri
    old "Ohh, he is not bad at this..."
    new "あら、彼はこれなかなか上手なのね。"

    # say L551 pla
    old "Come on, I know there's something on your mind that's been making you feel rather bad."
    new "Come on、君の心の中には何か重いものがあるんだろ？それが君を落ち込ませてるってわかるよ。"

    # say L554 pla
    old "If you need to talk about it I'll be more than happy to hear you."
    new "もし話したいことがあるなら、喜んで聞くよ。"

    # say L556 pla
    old "After all... I already told you about my situation."
    new "でも……俺の状況はもう話したんだけど。"

    # say L558 pla
    old "Maybe I could help you with yours."
    new "俺が君の事情を手伝うかもしれない。"

    # say L564 pla
    old "What? What do you mean?"
    new "何？　どういう意味？"

    # say L566 pla
    old "Listen, if this is something you want, and it's important to you, there's no way that it is ridiculous!"
    new "君が本当に欲しくて、それが君にとって重要なら、全然馬鹿げてないよ！"

    # say L574 bri
    old "She's feeling very bad [pla], there's something bothering her deeply."
    new "彼女はすごく落ち込んでる[pla]、何かが深く心を悩ませてるの。"

    # say L575 bri
    old "What she's transmitting more strongly is a very deep feeling of insecurity."
    new "彼女が強く感じてるのは、とても深い不安さだね。"

    # say L578 pla
    old "Listen Barbie."
    new "バービー、聞いてくれ。"

    # say L579 pla
    old "I understand that sometimes things don't go the way we want them to."
    new "分かってる、時々物事が上手くいかないこともあるさ。"

    # say L581 pla
    old "But if it's something that's really important for you, I think it's worth it to give it a shot."
    new "でも、それが君にとって本当に重要なことなら、挑戦する価値があると思うよ。"

    # say L583 pla
    old "Don't you think? Why don't you let me know about it?"
    new "そう思わない？教えてみろ。"

    # say L599 pla
    old "I see, it must be very frustrating to deal with that."
    new "そうか、それ相手にするのは相当つらいだろうな。"

    # say L601 pla
    old "But I'm sure you still can make that dream a reality..."
    new "でもきっとその夢を叶えられるぜ…"

    # say L602 pla
    old "I mean, I'm sure there are a lot of auditions being held every day, aren't there?"
    new "毎日オーディションが行われてるはずだろ？"

    # say L604 pla
    old "You might land a role sooner rather than later, and that could propel you upward, isn't that right?"
    new "君が早くに役をゲットして、それがきっかけで順調に進むかもしれないさ、そうだろう？"

    # say L614 pla
    old "Why would you say that?"
    new "なぜそんなこと言うんだ？"

    # say L626 pla
    old "That's terrible! They have no right to treat you that way!"
    new "それは最悪だな！そんなふうに扱うなんて、彼らには権利がないぞ！"

    # say L627 pla
    old "Besides, it isn't fair to say something like that."
    new "それに、そんなことを言うのはフェアじゃない。"

    # say L630 pla
    old "I'm sorry about that, Barbie."
    new "すまん、Barbie。"

    # say L635 pla
    old "No, they're not."
    new "いや、そうじゃない。"

    # say L637 pla
    old "You don't have to believe that just because they say it to you."
    new "彼らがそう言うからって、信じる必要ないよ。"

    # say L643 bri
    old "[pla]! She's thinking about something!"
    new "[pla]！彼女は何かを考えているみたいだよ。"

    # say L644 bri
    old "But it isn't clear what it is."
    new "でも、それが何なのかはっきりしていないの。"

    # say L646 bri
    old "Keep talking to her, maybe she'll open up more."
    new "彼女に話しかけ続けて、もっと打ち解けてくれるかもしれないよ。"

    # say L648 pla
    old "I mean, I'm sure you've faced some obstacles, right?"
    new "まあ、君も何らかの障害に直面したことがあるだろう？"

    # say L650 bri
    old "Something just came up on her mind!"
    new "何か思いついたみたい！"

    # say L651 bri
    old "Something about..."
    new "何かについて..."

    # say L652 bri
    old "{i}Number of auditions?{/i}"
    new "{i}オーディションの回数？{/i}"

    # say L654 bri
    old "What is that?"
    new "何それ？"

    # say L656 pla
    old "({i}I think I know what she means!{/i})"
    new "{i}俺もその意味わかるよ！{/i}"

    # say L658 pla
    old "Like, have you gotten enough auditions? I bet you haven't been able to attend to many, right?"
    new "オーディション、十分に受けてる？多分、そんなに参加できてないだろうな。"

    # say L664 pla
    old "You see? It isn't your fault."
    new "見ろ？これは君のせいじゃないよ。"

    # say L672 bri
    old "[pla]! Something else just came into her mind!"
    new "[pla]！何か新しいことが頭に浮かんだみたい！"

    # say L674 bri
    old "I'm not sure, her mind's kinda foggy."
    new "うーん、頭がちょっと fuzzy な感じ。"

    # say L681 bri
    old "Practice! She's thinking about not being able to practice!"
    new "練習のことだよ！彼女は練習できないことが気になってるみたい。"

    # say L683 pla
    old "I mean, you are working here full time, I bet it's very difficult to do things like acting if you don't have enough practice time."
    new "君はフルタイムで働いてるんだから、練習時間が足りないと演技するのは難しいだろうな。"

    # say L684 pla
    old "Right?"
    new "そうだろ？"

    # say L692 bri
    old "She's not thinking about time [pla], there's something else there."
    new "時間のことなんて考えてないわ [pla]、他に事情があるのよ。"

    # say L694 bri
    old "Partners?"
    new "パートナー？"

    # say L696 bri
    old "I don't know what she means by that."
    new "彼女の言っている意味がわからないな。"

    # say L697 pla
    old "{i}But I think I do! Thanks Brixxida!{/i}"
    new "{i}でも俺は知ってるよ！ありがとう、ブリクシダ！{/i}"

    # say L699 pla
    old "Yeah, I bet that since you're always working here."
    new "そうだな、君がいつもここに働いてるからね。"

    # say L702 pla
    old "It must be very difficult  to find partners to practice with."
    new "パートナーを見つけるのはとても難しいだろうな。"

    # say L704 pla
    old "And even if you did find them, making the space to practice must be very difficult. Right?"
    new "見つけたとしても、練習する場所を確保するのは大変だろうね。そうだよね？"

    # say L710 pla
    old "But you know, those things can be dealt with."
    new "でもな、そんなの解決できるぜ。"

    # say L712 pla
    old "How about I help you with them?"
    new "じゃあ、手伝おうか？"

    # say L719 pla
    old "Uhm... W- well..."
    new "うーん… ええと…"

    # say L720 pla
    old "S- since you can't practice with other actors, how about I do it with you?"
    new "他の俳優と練習できないなら、俺が一緒にやってみようか。"

    # say L721 pla
    old "I could give you pointers and help you memorize your lines."
    new "俺がアドバイスして、台詞を覚える手伝いをしよう。"

    # say L730 pla
    old "M- maybe I could help you find another audition."
    new "もしかしたら他のオーディションを見つける手伝いができるかもしれないな。"

    # say L731 pla
    old "I understand that you're very busy."
    new "分かってる、君は本当に忙しいんだね。"

    # say L732 pla
    old "So, how about I'm the one that searches around, and helps you find auditions for roles that you may be good at?"
    new "じゃあ、俺が探して、君に合そうな役のオーディション見つけてあげるってのはどう？"

    # say L737 pla
    old "Y- Your agent?"
    new "君のエージェント？"

    # say L742 pla
    old "I- I don't think that's..."
    new "俺は、その役割はちょっと…"

    # say L748 bri
    old "Yes! Say yes! That's exactly what she wants! I can see it in her mind!"
    new "はい！そう言って！それが彼女の望みなんだもん！彼女の心が見えてるよ！"

    # say L749 pla
    old "{i}B- but, being an agent is...{/i}"
    new "{i}ブ- でも、エージェントになるって…{/i}"

    # say L751 bri
    old "What are you so hesitant about? Just say yes or you won't be able to establish a relationship with her!"
    new "何をためらってるの？ただ「はい」って言えばいいんだよ、そうしないと彼女との関係は築けないわ！"

    # say L752 bri
    old "We'll figure out how to do that later!"
    new "後でどうするか考えようね！"

    # say L753 pla
    old "{b}*Sigh*{/b}"
    new "{b}*ため息*{/b}"

    # say L756 pla
    old "Yeah, you're right, I would be acting as your manager."
    new "そうだな、君のマネージャーとして動くよ。"

    # say L757 pla
    old "... I guess."
    new "…そうか。"

    # say L759 pla
    old "Well, I just want to help you."
    new "まあ、君を助けるためさ。"

    # say L761 pla
    old "After all, I told you you shouldn't give up on your dreams."
    new "結局、夢を諦めちゃだめだって言ったろ。"

    # say L763 pla
    old "So... How about I go home for now and start making some calls?"
    new "じゃあ……俺は家に帰って電話でも始めるか"

    # say L765 pla
    old "And if something comes up I'll let you know."
    new "何かあったら知らせるよ。"

    # say L778 pla
    old "Uhm, happy to help..."
    new "うーん、手伝うよ。"

    # say L779 pla
    old "I guess I'll see you later then, Bye."
    new "じゃあまたね、バイ。"

    # say L795 pla
    old "Ok, I think that went well."
    new "うん、うまくいったと思う。"

    # say L797 bri
    old "What are you talking about?! Why didn't you have sex with her?!"
    new "何言ってるの？！ なぜ彼女とセックスしなかったの？！"

    # say L799 bri
    old "I told you, you humans are very easy to manipulate."
    new "前に言ったよね、人間は簡単に操れるって。"

    # say L801 bri
    old "I thought that by helping you talk to her you would already be having sex with her!"
    new "あなたが彼女と話すのを手伝ってあげたのに、もうセックスしてると思ったのに！"

    # say L803 bri
    old "You know we don't have much time!"
    new "時間がないこと知ってるでしょ！"

    # say L805 pla
    old "Well, I'm sorry, I thought you didn't have any spells that would make her have sex with me right away."
    new "まあ、すまない、君がすぐセックスさせてくれる魔法を持ってないと思ったんだ。"

    # say L806 bri
    old "I don't have any, that doesn't exist."
    new "そんなのないの、存在しないのよ。"

    # say L808 pla
    old "Then how about you let me handle this and stop yelling at me about it?"
    new "じゃあ、俺が対処するから、文句を言わないでくれ？"

    # say L810 pla
    old "What you told me about her barely helped me a little to connect with her."
    new "君が教えてくれたこと、彼女とつながるのにほとんど役に立たなかったな。"

    # say L811 pla
    old "Listen, is not as easy to convince humans to have sex just like that."
    new "聞くよ、人間をそんなに簡単には説得できないんだよ。"

    # say L813 pla
    old "You may be able to read minds, but you don't know how human emotions work."
    new "君は心を読めるかもしれないけど、人間の感情のことは知らないんだよ。"

    # say L815 pla
    old "So let me handle this, ok?"
    new "じゃあ、俺がやっておくからな。"

    # say L816 bri
    old "Fine... I'll let you do what you want."
    new "いいわ... したいようにしなさい。"

    # say L818 bri
    old "But be sure to do it quickly!"
    new "でも早くてちゃんとやってね！"

    # say L820 bri
    old "Magic power is not eternal in case you forgot!"
    new "魔法の力は永遠じゃないわよ、忘れてないよね！"

    # say L821 bri
    old "And I already used a lot of it today, so be sure you do this properly."
    new "今日 Already 使っちゃった魔力がたくさんあるから、ちゃんとやってね。"

    # say L822 pla
    old "Yeah, yeah, I'll be sure to do what you need."
    new "分かってるよ、ちゃんとするから心配するな。"

    # say L824 pla
    old "But I'm in a tight spot with this. I know nothing about acting. I'll have to come up with something."
    new "でもこれで困ってるんだ。演技のことは何も知らないし、何か考え出さなきゃいけない。"

    # say L826 pla
    old "But I just don't have any ideas about how..."
    new "でもどうやってって、俺にはアイデアが全然浮かばないんだよ..."

    # say L827 pla
    old "And I don't know anybody that works in acting, how am I going to get her an audition..."
    new "俺は役者関係で知り合いなんていねえし、どうやってオーディションの機会を手に入れるんだよ..."

    # say L828 bri
    old "Well, that was your idea after all..."
    new "まあ、それはあなた自身のアイデアだったわけだよ…"

    # say L829 pla
    old "What? You were the one who told me to accept being your agent. I didn't even..."
    new "何？ 君が俺に自分のエージェントになってくれって言っただろう。俺はただ…"

    # say L833 pla
    old "Belle!"
    new "ベル！"

    # say L834 pla
    old "She's very into content creation and social media."
    new "彼女はコンテンツ作りとソーシャルメディアにとても熱心なんだ。"

    # say L836 pla
    old "It may be a long shot, but maybe she knows somebody who could help us with this."
    new "長くても、彼女が誰か知ってるかもしれないな。"

    # say L838 pla
    old "Right now is a little late, but I'll go talk to her soon to see if she could help me."
    new "今ちょっと遅いけど、近々彼女に話してみるよ。"

    # say L839 bri
    old "Yes, honestly, I need to recharge. I spent a lot of magical power today, so I need to recover, and I won't be able to help you for a few days."
    new "うん、正直に言うと、私も充電が必要なの。今日、かなりの魔力を使ったから、回復するまで数日かかるし、君の手伝いはできないわ。"

    # say L840 pla
    old "Hmm, alright, I can handle it with Belle for now, and what you helped with Barbie was a lot; at least, she trusts me now."
    new "うん、そうだね。ベールと上手くやっていけるし、君がバービーにしてくれたことは大きかった。少なくとも、彼女は俺を信頼してくれるようになったから。"

    # say L841 bri
    old "Ok, then see you tomorrow, [pla]."
    new "じゃあ、明日ね、[pla]。"

    # say L842 pla
    old "Sure, have a good rest."
    new "じゃあ、ゆっくり休んでね。"

    # say L863 pla
    old "Hey Belle! How are you?"
    new "ベール！元気ですか？"

    # say L865 bel
    old "Hey [pla]! Good morning! I'm fine, thank you."
    new "Hey [pla]！おはよう！元気にしてるわ、ありがとう。"

    # say L867 bel
    old "How about you? Are you doing well?"
    new "あなたは？ 元気？"

    # say L869 pla
    old "Well... Yeah, I'm doing well."
    new "まあ……そうさ、調子はいいけど。"

    # say L871 pla
    old "But you see... There's this situation.... It's a little complicated and I was wondering if you could help me with it."
    new "でもね…ちょっとした事情があってさ。複雑なことになっていて、君に相談したいんだ。"

    # say L873 bel
    old "Uhmm... Sure, whatever I can help you with, I'll be happy to do it."
    new "うん、もちろん、手伝えることは何でもするよ。"

    # say L874 bel
    old "What  is it?"
    new "何？"

    # say L876 pla
    old "Well, do you know the business building in the center of town?"
    new "まあ、町の中心にあるオフィスビルのこと知ってる？"

    # say L878 bel
    old "Sure, my mom's previous office was located there. I used to go from time to time."
    new "もちろん、ママの前の職場がそこにあったから、時々行ってたの。"

    # say L880 pla
    old "Oh, nice. Well, the thing is that I sometimes have to go there."
    new "なるほど、そうか。実は俺も時々そこに行くことがあるんだ。"

    # say L881 pla
    old "You know, to bring documents for a family member from time to time, that kind of stuff."
    new "家族の用事で時々書類を持っていくんだ、そんな感じ。"

    # say L885 pla
    old "Well the other day I came there to bring some documents, and I got to talking with the receptionist of the building."
    new "先日、書類を持って行ったんだが、ビルの受付嬢と話す機会があったよ。"

    # say L887 bel
    old "Barbie?"
    new "バービー？"

    # say L889 pla
    old "Yeah, do you know her?"
    new "そうだ、君も彼女知ってるか？"

    # say L891 bel
    old "I do, from when I used to come to my mom's office."
    new "うん、昔ママのオフィスによく来ていたときに知り合ったの。"

    # say L893 bel
    old "We never really talked much, but I remember she's a very nice girl."
    new "あまり話したことはないけど、とても優しい子だとは覚えてる。"

    # say L894 pla
    old "Oh yeah, sure, she's very nice."
    new "そうだ、確かに優しい子だ。"

    # say L896 pla
    old "But you see, when I got there the other day, I saw that she was very sad."
    new "でもね、先日行ったとき、彼女がすごく落ち込んでたんだ。"

    # say L897 bel
    old "Why? Is she okay?"
    new "どうしたの？大丈夫なの？"

    # say L898 pla
    old "Well, nothing bad has happened, but you see..."
    new "まあ、悪いことはないんだけど、ね..."

    # say L900 pla
    old "I asked her what was wrong."
    new "彼女に何が Wrong なのか聞いたらさ。"

    # say L902 pla
    old "And after we got to talking, she told me that she's been feeling very frustrated as of late."
    new "そして話し始めたら、彼女は最近とてもイライラしているって言ってた。"

    # say L904 pla
    old "Because she feels like her life is just coming to a halt, and she doesn't know what to do about it."
    new "彼女は自分の人生が止まってしまったような気がして、どうすればいいのかわからないんだ。"

    # say L905 bel
    old "Why? What's happening?"
    new "なぜ？何が起こってるの？"

    # say L907 pla
    old "Well, as she told me, she originally came to town looking for opportunities to be an actress."
    new "まあ、彼女が話してくれたんだけど、元々はこの町で女優になるチャンスを探しに来たらしい。"

    # say L908 pla
    old "But ever since she arrived, she's been attending one audition after another."
    new "でも彼女が来た後は、オーディションを受け続けているんだ。"

    # say L910 pla
    old "Without ever being selected to any roles."
    new "一度も役に選ばれることなく。"

    # say L911 bel
    old "I understand [pla], that's a very sad thing."
    new "理解してる [pla]、それはとても悲しいことよね。"

    # say L912 bel
    old "The thing you wanted me to help you with is related to that?"
    new "あなたが手伝ってほしいって言ったこと、それに関係あるの？"

    # say L914 pla
    old "It is, at first I only thought that she was just a little frustrated about not being able to book any roles."
    new "そうだ、最初は彼女が役を獲れなくてちょっとイライラしてるだけだと思ったんだ。"

    # say L915 pla
    old "But while we talked I came to realize how important being an actress is to her."
    new "でも話しているうちに、彼女にとって女優であることの重要性に気づいたんだ。"

    # say L916 pla
    old "This is what she wants to do the most in life."
    new "これが彼女が人生で一番やりたいことなんだ。"

    # say L918 pla
    old "To the point where she's feeling depressed for being unable to get any opportunities to act."
    new "機会がなくて演技できないことで落ち込んでいるんだ。"

    # say L919 bel
    old "I get it [pla], I understand that feeling."
    new "分かってる [pla]、その気持ちはよく分かるよ。"

    # say L920 bel
    old "The frustration of not being able to live your dreams."
    new "夢を叶えられないフラストレーションね。"

    # say L921 bel
    old "It's overwhelming..."
    new "それは圧倒的な気持ちだね…"

    # say L922 pla
    old "Yeah it is, but it's not just that."
    new "そうだよ、でもそれだけじゃないんだ。"

    # say L923 pla
    old "She's also feeling bad about not being able to even try."
    new "彼女は自分が試してみることすらできないってことで、落ち込んでるんだ。"

    # say L924 pla
    old "Since she's always so busy working, she can't look for auditions."
    new "彼女はいつも仕事で忙しいから、オーディションを探す時間もないんだ。"

    # say L926 pla
    old "Or attend acting classes whenever she gets a role."
    new "役をもらったとしても演技のクラスに通う時間もないし。"

    # say L928 pla
    old "So, after hearing of all the things she's been going through, I decided to help her."
    new "だから、彼女が経験したことを聞いて、手伝うことに決めたんだ。"

    # say L929 pla
    old "I think that's just the best thing that I could do right now, you know?"
    new "今できる最高のことはこれだよ、分かる？"

    # say L931 bel
    old "Yeah, I understand [pla], and I think that's just a great thing for you to do."
    new "うん、わかる [pla]。それが今あなたができる最高のことだと思うね。"

    # say L932 pla
    old "Thanks Belle!"
    new "ありがとう、ベール！"

    # say L934 pla
    old "And that's more or less what I need your help with."
    new "それで、その辺りが君の手伝いが必要なとこなんだ。"

    # say L936 pla
    old "I ended up promising her that I would help her with the whole process of getting auditions."
    new "結局、彼女にオーディションの手伝いをするって約束しちゃったんだ。"

    # say L937 pla
    old "But truth be told, I don't know how to do that."
    new "でも正直、どうやってやるのかわからないんだ。"

    # say L939 pla
    old "I haven't ever even seen any acting agencies, or anything like that. So I don't know where to start."
    new "俺はまだ一度も演技のエージェンシーを見たことないし、そんなものも知らないから、どこから手をつけていいかさっぱりわからないんだ。"

    # say L941 pla
    old "That's why I thought you might be able to help me with it."
    new "だから君に手伝ってもらおうと思ったんだ。"

    # say L943 pla
    old "I know you're very active on social media and you know a lot of people in the industry."
    new "君がソーシャルメディアで結構活躍してるし、業界の人ともたくさん繋がってるって知ってたからさ。"

    # say L944 pla
    old "And you know, you also work a lot in content creation and that kind of stuff."
    new "それに、君はコンテンツ制作の仕事もたくさんやってるし、その手のことは詳しいだろ。"

    # say L946 pla
    old "So, I was thinking that maybe you knew of a way for me to get an audition for her."
    new "じゃあ、君が何か方法を知ってるかもしれないと思って、俺が彼女のオーディションを受けられるように。"

    # say L947 pla
    old "Or maybe you knew of a studio of something like that..."
    new "あるいは君が知ってるスタジオとかでもいいんじゃないか？"

    # say L948 bel
    old "Hmm, I see what you mean..."
    new "うーん、なるほどね..."

    # say L950 bel
    old "You know, there may be someone that could..."
    new "知ってるかもしれないけど、そんな人がいるかもね…"

    # say L959 luc
    old "[pla], Belle, the class bell already rang."
    new "[pla]、ベール、授業のベルはすでに鳴ってるよ。"

    # say L960 luc
    old "Hurry up and get to the classroom or you'll be late."
    new "早く教室に行かないと遅刻するぞ。"

    # say L994 bel
    old "So, while we were in class I got to thinking, and it came to my mind that I might know of a place where she could go."
    new "クラス中、考えていたら彼女が行けるかもしれない場所を思いついたの。"

    # say L995 pla
    old "You did? Great!"
    new "そうか？良かった！"

    # say L996 bel
    old "Yeah, just let me do a couple of calls and I'll let you know."
    new "うん、ちょっと連絡してくるから、すぐ教えてあげるね。"

    # say L1000 bel
    old "In fact, I'll call right now and I'll let you know right away."
    new "実は今すぐ電話して、すぐに教えてあげるね。"

    # say L1012 bel
    old "Alright, I talked with a couple of my contacts."
    new "よし、いくつかの連絡先と話してみたわ。"

    # say L1014 bel
    old "Great news! They said they would agree to audition her for an upcoming role."
    new "素晴らしいニュース！彼らは彼女を次の役のオーディションに受け入れることに同意してくれたわ。"

    # say L1016 bel
    old "I'll give you their number so you can call and see when she could go there."
    new "彼らの番号をあなたに渡すから、いつ行けるか確認してね。"

    # say L1018 bel
    old "I already gave them your info, so they'll know you're calling on my recommendation."
    new "すでにあなたの情報を渡してあるから、私が推薦したってことを知ってるはずよ。"

    # say L1019 pla
    old "Great! Thanks a lot, Belle!"
    new "ありがとう、ベール！助かるよ。"

    # say L1021 bel
    old "It's fine, I'm happy to be able to help."
    new "大丈夫、手伝えて嬉しいわ。"

    # say L1022 bel
    old "From what you told me about Barbie's story, she needs this opportunity."
    new "あなたが話してくれたバービーの話を聞く限り、彼女はこの機会が必要みたいですね。"

    # say L1023 bel
    old "I know that if it was me I would love to get any help that I could get."
    new "自分でも同じ立場なら、どんな助けも喜んで受け取りたいと思うわ。"

    # say L1024 bel
    old "So I'm very happy to help."
    new "だから私も喜んで手伝います。"

    # say L1026 pla
    old "That's great Belle, and a huge help!"
    new "ベル、ありがとう。大きな助けになるよ。"

    # say L1027 pla
    old "Thank you so much!"
    new "ありがとう、助かるよ！"

    # say L1028 bel
    old "You're welcome, I hope things will go well."
    new "どういたしまして、うまくいくといいですね。"

    # say L1029 bel
    old "Let me know how this turns out."
    new "結果どうなったか教えてね。"

    # say L1031 pla
    old "I'll see you later then, thanks again."
    new "じゃあ後で、またありがとう。"

    # say L1043 pla
    old "Asking Belle about it turned out Better than expected."
    new "ベルに聞いてみたら、思っていたより良かったんだ。"

    # say L1044 pla
    old "Barbie will really like this news."
    new "バービーはこのニュースをきっと喜ぶだろうな。"

    # say L1045 pla
    old "Now is too late for me to go talk to her. But I'll go there soon and let her now."
    new "今さら彼女に話しに行くのは遅いけど、近いうちに行って伝えようと思う。"

    # say L1064 pla
    old "Hey Barbie, how are you doing?"
    new "バービー、元気にしてる？"

    # say L1070 pla
    old "Well, let me tell you that that may be about to change. Because I got you an audition."
    new "まあ、その状況が変わるかもしれない。君のためにオーディションを手配したからな。"

    # say L1073 pla
    old "Yeah, it's a role in an upcoming movie."
    new "そうだ、これから公開される映画の役だ。"

    # say L1075 pla
    old "It’s being produced by an indie studio from outside of town."
    new "町外れのインディースタジオが制作してるんだ。"

    # say L1076 pla
    old "They’re holding some castings here for it."
    new "ここでもいくつかのオーディションをやるんだ。"

    # say L1078 pla
    old "I already booked you a spot in their next auditions block."
    new "次のお試しブロックのオーディションの予約を取っておいたぞ。"

    # say L1079 pla
    old "So you'll have a chance of getting a role."
    new "じゃあ君はその役をゲットするチャンスがあるわけだな。"

    # say L1081 pla
    old "You're welcome, I'm happy to help you. I'm sure you'll do a great job with the role."
    new "どういたしまして、君の役に立ててうれしいよ。きっとその役を素晴らしいように演じられるさ。"

    # say L1084 pla
    old "You'll be auditioning for the role of a rich girl who's in love with a man that her family doesn't approve of."
    new "君は、裕福な娘で、家族に認められていない男に恋している役のオーディションを受けるんだ。"

    # say L1088 pla
    old "It is, you'll be auditioning for the lead role!"
    new "そうだ、君は主役のオーディションを受けるんだ！"

    # say L1090 pla
    old "That's great, isn't it?"
    new "それはいいんじゃない？"

    # say L1093 pla
    old "Is... Is there a problem?"
    new "何か問題があるのか？"

    # say L1096 pla
    old "Why not? Is there something wrong?"
    new "何がいけないって？何か問題でもあるのか？"

    # say L1101 pla
    old "Why do you think that?"
    new "なんでそう思うの？"

    # say L1109 bri
    old "Hey [pla]."
    new "Hey [pla]。"

    # say L1110 pla
    old "{i}What are you doing here?{/i}"
    new "{i}何してるの？{/i}"

    # say L1111 bri
    old "I followed you in case you needed my help. Just because there's no certainty that you will know how to speak to her."
    new "あなたが彼女と話すのが苦手なかもしれないので、手伝いに来たの。"

    # say L1112 bri
    old "So, do you want my help?"
    new "手伝って欲しくない？"

    # say L1113 pla
    old "{i}I think I can convince her on my own.{/i}"
    new "{i}俺が一人で説得できると思うよ{/i}"

    # say L1115 pla
    old "I mean, I'm sure you're more than capable of taking the role, you know?"
    new "つまり、君がその役をこなすのは間違いないよ、わかってるだろ？"

    # say L1116 pla
    old "I know you're very talented."
    new "君の才能は知ってるよ。"

    # say L1117 pla
    old "And sure, there's going to be some competition."
    new "もちろん、競争相手もいるだろうけどね。"

    # say L1118 pla
    old "But you're just as good as any of them, you're more than capable of holding your own in the audion, no doubt."
    new "でも君は彼らに負けてない、オーディションでものすごくやれるぜ、絶対に。"

    # say L1127 pla
    old "B- but you were so excited just a minute ago!"
    new "でも、さっきまでそんなに興奮してたのに！"

    # say L1138 pla
    old "Listen, I understand that you're feeling insecure because of what's happened before."
    new "聞いて、過去のことで不安を感じてるってのはわかるよ。"

    # say L1139 pla
    old "But you'll never know if you don't try it."
    new "でも試さないとわからないよ。"

    # say L1150 bri
    old "So... You don't seem to be {i}'handling'{/i} things too well."
    new "だから… あなたは {i}処理{/i} が上手くいってないみたいね。"

    # say L1151 bri
    old "Will you let me help you now?"
    new "今私に手伝ってもらえる？"

    # say L1152 bri
    old "I also need you to have sex with this human female, so this is also in my best interest."
    new "私にもこの人間の女性とセックスする必要があるから、これも私の利益になるの。"

    # say L1154 pla
    old "{i}Alright, alright! Get in her head and tell me what's really troubling her.{/i}"
    new "{i}分かった、分かった！彼女の心の中に入れて、本当に何が困ってるのか教えてくれ。{/i}"

    # say L1155 bri
    old "Okay!"
    new "分かったわ！"

    # say L1160 pla
    old "I understand that because of what's happened before you feel uncomfortable with the idea of auditioning."
    new "分かってる、前に起きたことでオーディションすることに不安を感じてるんだろう。"

    # say L1161 pla
    old "But you shouldn't let that stop you."
    new "でも、それであなたが止まっちゃうのはもったいないよ。"

    # say L1162 bri
    old "Hold on, I'm starting to get something."
    new "待って、何か感じ始めたの。"

    # say L1163 bri
    old "She feels like she's a failure."
    new "失敗者みたいに感じてるの。"

    # say L1164 pla
    old "{i}Uhhh... {/i}"
    new "{i}うーん…… {/i}"

    # say L1166 bri
    old "No, no, she feels like her life's a failure."
    new "いいえ、いいえ、彼女は自分の人生が失敗だと思ってる。"

    # say L1168 pla
    old "{i}Her life is a failure?{/i}"
    new "{i}彼女の人生が失敗だって？{/i}"

    # say L1170 pla
    old "I- I mean, I understand that you may feel like a failure."
    new "俺が言いたいのは、君が失敗だと思ってるってこと、わかるよ。"

    # say L1172 pla
    old "But the reason I'm helping you is because I believe in you and your talent."
    new "でも、君を助ける理由は君の才能を信じているからだよ。"

    # say L1179 bri
    old "She's afraid of being rejected [pla]!"
    new "彼女は拒絶されるのが怖いのね [pla]！"

    # say L1180 bri
    old "What strong emotions, wow!"
    new "強い感情ね、すごい！"

    # say L1183 pla
    old "You know, I understand that you may feel a fear of being rejected."
    new "君が拒絶されることを恐れているのは分かるよ。"

    # say L1185 pla
    old "But I do believe you're more than capable of getting the role."
    new "でも、君にはその役を手に入れる力があると信じてる。"

    # say L1187 pla
    old "You have been trying for so long to finally get an acting career."
    new "君は長い間、ついに俳優としてのキャリアを手に入れようと頑張ってきたんだ。"

    # say L1189 pla
    old "And you haven't ever given up no matter what."
    new "どんなことがあっても、一度も諦めなかったんだ。"

    # say L1191 pla
    old "I just know that you have an amazing amount of passion for this."
    new "君がこれほど情熱的だということは知ってるよ。"

    # say L1193 pla
    old "With how hard you've worked, I don't think anyone deserves the role any more than you do."
    new "君がこれだけ頑張ってきたんだ、誰よりもこの役にふさわしいと思うよ。"

    # say L1197 pla
    old "Of course I do, I truly believe in what you can do."
    new "もちろんさ、君のできることが本当に信じてるよ。"

    # say L1198 pla
    old "What do you say?"
    new "どう思う？"

    # say L1199 pla
    old "Will you give it a try?"
    new "試してみるか？"

    # say L1210 pla
    old "Of course you should. I know, you'll crush it."
    new "もちろん、君ならできるさ。絶対に見事にこなすよ。"

    # say L1215 pla
    old "You're welcome Barbie, I know you'll do great."
    new "バービー、どういたしまして。君ならきっと大丈夫だよ。"

    # say L1216 pla
    old "Anyway, I have to go home for now."
    new "まあ、一時的に家に帰るけど。"

    # say L1217 pla
    old "But I'll send you the info about the address and date for the audition."
    new "でも、オーディションの場所と日程の情報を送るからね。"

    # say L1221 pla
    old "I'll see you later then, bye."
    new "じゃあ後でな、バイ。"

    # say L1238 pla
    old "Alright, that went well."
    new "そうか、上手くいったみたいだね。"

    # say L1239 pla
    old "Thanks for the help Brixxida."
    new "助けてくれてありがとう、ブリクシダ。"

    # say L1241 bri
    old "Yeah yeah, but why aren't you having sex already with her?"
    new "はいはい、でもなぜまだ彼女とセックスしてないの？"

    # say L1244 bri
    old "I told you how she was feeling so that you could have sex with her right away!"
    new "私が彼女の気持ちを教えてあげたのは、すぐにセックスできるようにするためよ！"

    # say L1245 bri
    old "Two times talking and you still haven't achieved anything."
    new "二回も話して、まだ何も進展ないの？"

    # say L1246 bri
    old "What's taking you so long?"
    new "何そんなに時間がかかるの？"

    # say L1247 pla
    old "I thought I told you."
    new "俺が言っただろ。"

    # say L1248 pla
    old "Is not so simple to get somebody into bed."
    new "そんなに簡単に誰かをベッドに連れてこられるわけないだろ。"

    # say L1250 pla
    old "You can't just say something nice to someone once or twice, and suddenly they'll want to fuck you out of nowhere."
    new "一度や二度いいこと言っても、急に相手が寝たい気にはならねえよ。"

    # say L1251 bri
    old "Ok, then how long will it take?"
    new "じゃあ、どれくらいかかるの？"

    # say L1252 bri
    old "You're not the only one who's making an effort, you know?"
    new "あなただけが努力してるわけじゃないって、知ってるでしょ？"

    # say L1254 bri
    old "I'm using a lot of magical power every time I read her mind, this isn't easy to do."
    new "毎回彼女の心を読むのにたくさんの魔力を使ってるの、これって簡単なことじゃないんだよ。"

    # say L1255 bri
    old "And unlike in my world, magical power isn't infinite here."
    new "そして、私の世界とは違って、魔法の力は無限じゃないの。"

    # say L1256 pla
    old "I know, and I understand that this must be hard for you."
    new "知ってるよ、これが君にとって難しいのは理解してる。"

    # say L1258 pla
    old "But I can't just ask her to have sex with me just because. That's not how it works."
    new "でも、ただそうやって彼女にSEXを求めちゃダメだ。そんな簡単な話じゃないから。"

    # say L1260 bri
    old "You humans are so complicated. When shinigamis have sex is just an energy exchange. Nothing else."
    new "あなたたち人間は複雑ね。死神がセックスをするのはただエネルギーの交換よ。それだけのこと。"

    # say L1261 pla
    old "Listen, I'm doing my best to do what we need. So just trust me on this and let me handle it. Ok?"
    new "君、俺は必要なことやってるんだ。だからこの件は任せてくれ信じてくれ。いいか？"

    # say L1263 bri
    old "Okay,  I'll trust that you know what you're doing."
    new "わかった、あなたが何をしているのも信じるから。"

    # say L1264 bri
    old "But don't take too long, I remind you that this is just the beginning of this process."
    new "でも長引かせないで、これはただのプロセスの始まりだって忘れないでね。"

    # say L1266 pla
    old "Don't worry, I haven't forgotten about that."
    new "心配するな、そのことは忘れてない。"

    # say L1292 pla
    old "I'm ok, I came to check up on you."
    new "大丈夫、君の様子を見に来たよ。"

    # say L1294 pla
    old "I wanted to know how the audition went."
    new "オーディションどうだった？"

    # say L1296 pla
    old "Did it go well? Did you feel alright?"
    new "うまくいったか？調子はどうだった？"

    # say L1310 pla
    old "Alright, that sounds great. When's the next audition?"
    new "そうだな、それは良かった。次のオーディションはいつだ？"

    # say L1319 pla
    old "I see, and how long is it?"
    new "なるほど、どれくらいの時間なんだ？"

    # say L1325 pla
    old "Ohh wow, t- that's a lot."
    new "おお、そうか、それ結構な長さだな。"

    # say L1333 pla
    old "Oh, come on, why not?"
    new "おい、なぜダメなの？"

    # say L1340 pla
    old "{i}Could you please give me a hand...{/i}"
    new "{i}手伝ってくれないか…{/i}"

    # say L1346 bri
    old "Ok, I'm getting some strong emotional waves from her!"
    new "彼女の強烈な感情の波動を感じるわ！"

    # say L1347 bri
    old "She's feeling, very, very insecure."
    new "彼女は、とても不安そうよ。"

    # say L1348 bri
    old "I hadn't seen her like that before."
    new "前にこんな風に見えたことないわ。"

    # say L1350 bri
    old "She's closing her emotions! Just say something to reassure her."
    new "彼女の気持ちが閉ざされてる！何か言って安心させてあげて。"

    # say L1352 pla
    old "I- I understand what you're saying Barbie... I really do."
    new "分かってるよ、バービー… ほんとによく分かってる。"

    # say L1354 pla
    old "But you know... Uhh, I don't think that this is as bad a situation as you think."
    new "でもさ、うーん、これほど悪くないんじゃないかな。"

    # say L1359 bri
    old "Yeah, why not?"
    new "なんでダメなの？"

    # say L1360 pla
    old "Uhh... Well, that's certainly a lot of pages, but I don't think they are expecting you to memorize all of it."
    new "うーん……確かにページ数は多いけど、全部を暗記する必要はないと思うよ。"

    # say L1361 pla
    old "I think it's more about how you say and act with the lines."
    new "台詞の言い方や演技の仕方が重要だと思うよ。"

    # say L1363 pla
    old "Maybe all you have to do is read it ahead of time, and practice it."
    new "多分、事前に読んで練習すればいいだけだよ。"

    # say L1373 pla
    old "Ok, how about you do it with me?"
    new "じゃあ、一緒にやってみようか？"

    # say L1375 pla
    old "Sure, I mean, I don't know anything about acting, but I could still read the dialogues with you."
    new "まあ、俺は演技については何も知らないけど、せめて台詞を一緒に読むくらいはできるよ。"

    # say L1376 pla
    old "And I could give you my opinion about how I think you are doing it."
    new "俺が君の演技についてどう思ってるか意見を言うよ。"

    # say L1380 pla
    old "Well, we don't lose anything by trying, and this way, you could be more prepared for your role."
    new "試してみるだけの話だし、この方法なら君の役の準備もできるだろう。"

    # say L1393 pla
    old "How about you come to my house after you leave work."
    new "仕事終わって俺の家に来ない？"

    # say L1395 pla
    old "And we can start practicing."
    new "そして練習を始めるんだ。"

    # say L1401 pla
    old "So, what do you think if you let me take a look at the script they gave you while I wait for you to finish your shift?"
    new "じゃあ、お前がシフト終わるまで俺が待ってる間に、渡された脚本を見せてもらえないか？"

    # say L1406 pla
    old "Okay, I'll go through them while you finish. I'll be in the hallway."
    new "分かった、お前が終わるまで見とくよ。廊下で待ってるから。"

    # say L1417 pla
    old "Great, let's go."
    new "じゃあ、行こう。"

    # say L1433 pla
    old "So, I checked out the script, and honestly, it's pretty interesting."
    new "んで、台本見させてもらったけど、意外と面白いんだ。"

    # say L1435 pla
    old "Yeah, and I really do think you're not supposed to memorize this. It's rather about you reading it."
    new "そうだな、この台本を丸暗記する必要はないと思う。むしろ読みながらやった方がいいだろう。"

    # say L1436 pla
    old "Otherwise I don't think anybody could learn this entire thing by memory."
    new "それなら誰も全部を覚えるのは無理だよ。"

    # say L1437 pla
    old "Besides, if there are several participants the audition would just take too long."
    new "それに、参加者が複数いるとオーディションが長引くよ。"

    # say L1441 pla
    old "What I think is best is for us to focus on how you can portray the character."
    new "俺が思うに、君がキャラクターをどう演じるかに集中した方がいい。"

    # say L1442 pla
    old "I mean, act as you read, so you can be better prepared tomorrow having practiced your role."
    new "つまり、台本を読みながら演技して、明日は練習した役を演じられるようにしようってことだ。"

    # say L1443 pla
    old "I know a scene with a lot of emotions."
    new "俺は感情豊かなシーンを知ってるよ。"

    # say L1444 pla
    old "Here, take the full script, I got a few copies..."
    new "ここ、台本のフル版を持ってきた、いくつかコピーもあるから..."

    # say L1448 pla
    old "Is in the second act, page 57."
    new "二幕の57ページだ。"

    # say L1449 pla
    old "The two protagonists are fighting, but the scene ends in their reconciliation, I think it would be appropriate."
    new "二人の主人公がけんかしてるけど、最後には和解するんだよ。適切なシーンだと思う。"

    # say L1452 pla
    old "Alright, let's start with the reading, and I'll give you pointers along the way."
    new "よし、読み始めるか。途中でアドバイスもするからな。"

    # say L1459 pla
    old "'Don't leave! Don't turn your back on me now!'"
    new "行かないで！今さら背中向けてくれない！"

    # say L1461 pla
    old "'If you do, what little remains of this heart will disappear!'"
    new "もしもそうしたら、この心に残ってるわずかな部分さえ消えちまうよ！"

    # say L1484 pla
    old "Hmm... Barbie?"
    new "うーん… バービー？"

    # say L1487 pla
    old "I think you're doing it... Well."
    new "お前、上手くやってるみたいだ… けどね。"

    # say L1489 pla
    old "But, the volume of what you're saying is a little high."
    new "でも、君の声の大きさが少し高すぎるな。"

    # say L1491 pla
    old "Also, you're... Yelling some words, and saying others a little low."
    new "それに、君は… いくつかの言葉を叫んで、他の言葉は少し低い声で言ってるな。"

    # say L1494 pla
    old "Hmm, it's okay to add emotion to the lines, but try to keep the volume average, or it might sound a bit odd."
    new "うん、感情を込めるのはいいけど、音量は平均的におこうぜ、さもないとちょっと変な感じになるかもしれん。"

    # say L1497 pla
    old "Great, let's try it again."
    new "じゃあ、もう一回やってみよう。"

    # say L1501 pla
    old "You know what? Maybe it isn't necessary to start over every time."
    new "知ってるか？毎回やり直す必要ないかもしれないよ。"

    # say L1502 pla
    old "How about you just keep reading where you left it?"
    new "前から読み続けたらどう？"

    # say L1512 pla
    old "{i}(Why is she making that accent in those words?){/i}"
    new "{i}彼女、なんでそんなアクセントで言うんだ？{/i}"

    # say L1516 pla
    old "Oh, right, right."
    new "ああ、そうそう。"

    # say L1521 pla
    old "'Why? You ask?'"
    new "なんで？聞くの？"

    # say L1522 pla
    old "'Because it isn't little!'"
    new "だって小さいわけじゃないもん！"

    # say L1523 pla
    old "'What I offer is my heart!'"
    new "俺が提供するのは心だ！"

    # say L1524 pla
    old "'Naked, with no obstructions, just for you!'"
    new "裸で、邪魔なものもなく、君だけのためにさ！"

    # say L1533 pla
    old "{i}(There she goes again making that weird accent in certain words.){/i}"
    new "{i}(また変なアクセントで言葉を強調してるな。){/i}"

    # say L1548 pla
    old "I see..."
    new "なるほどね..."

    # say L1550 pla
    old "But maybe that's not necessary, you know?"
    new "でも必要ないかも知れないね。"

    # say L1551 pla
    old "I think it can be a little distracting."
    new "ちょっと気になって邪魔になるかもね。"

    # say L1553 pla
    old "And people might not understand what you're trying to do."
    new "そして、君が何をしようとしてるのかみんなが理解できないかもしれないね。"

    # say L1559 pla
    old "Hey, that's why we're practicing."
    new "Hey、だから練習してるんだよ。"

    # say L1560 pla
    old "I don't think you need to feel bad about it."
    new "心配するな、大丈夫だよ。"

    # say L1561 pla
    old "Come on, don't let yourself feel down, let's continue."
    new "Come on、落ち込まないで、続けよう。"

    # say L1566 pla
    old "'How can you say that I let you down?'"
    new "どうして俺があなたを落胆させたっていうんだ？"

    # say L1567 pla
    old "'When I gave everything to you?!'"
    new "何言ってんだよ、俺が全部给了你之后！"

    # say L1568 pla
    old "'I left myself change for your sake!'"
    new "俺は君のために自分を変えてきたんだよ！"

    # say L1569 pla
    old "'For our sake!'"
    new "私たちのためだ！"

    # say L1570 pla
    old "'All I've ever wanted in this relationship is to give you happiness!'"
    new "この関係でずっと欲しかったのは、君の幸せだけだよ。"

    # say L1584 pla
    old "'I didn't leave!'"
    new "俺は去らなかった！"

    # say L1585 pla
    old "'I couldn't be here for you!'"
    new "俺が君のそばにいられなかったんだ！"

    # say L1586 pla
    old "'There's no way I wouldn't be here if I could avoid it!'"
    new "俺がいられるなら、絶対にここにいってるよ。"

    # say L1587 pla
    old "'You have to believe.'"
    new "信じてくれないとダメだよ。"

    # say L1588 pla
    old "'You're my life!'"
    new "君が俺の人生だよ！"

    # say L1589 pla
    old "'You're my heart!'"
    new "あなたが俺の心だよ。"

    # say L1600 pla
    old "Uhh... So, there's something else I'd like to tell you."
    new "うーん……でも、まだ言いたいことがあるんだ。"

    # say L1606 pla
    old "Well, is just that..."
    new "まあ、そのことなんだけどね……"

    # say L1607 pla
    old "You keep changing your face while reading the lines."
    new "君の顔がセリフを読むたびに変わってるんだよ。"

    # say L1609 pla
    old "I- uh... No, I wouldn't say is wrong."
    new "うーん……でも、間違いとは言わないけど。"

    # say L1610 pla
    old "Is just that it's a little distracting from the dialogue, that's all."
    new "ただ、せりふに集中するのがちょっと難しくなるだけだよ。"

    # say L1611 pla
    old "I wouldn't say is a bad thing though."
    new "でも、悪いこととは言わないよ。"

    # say L1619 pla
    old "W- what are you talking about?"
    new "何言ってんだ？"

    # say L1620 pla
    old "W- why?"
    new "なんで？"

    # say L1625 pla
    old "B- but that's just me tryting to help you!"
    new "でも、それはただ俺が手伝おうとしてるだけだよ！"

    # say L1626 pla
    old "But I don't think you're bad."
    new "でも君が悪いとは思ってないよ。"

    # say L1628 pla
    old "You just need a little practice."
    new "君はただ少し練習が必要なんだ。"

    # say L1629 pla
    old "You know, to learn the character."
    new "知ってるか、キャラクターを学ぶためにさ。"

    # say L1637 pla
    old "W- what? Are you serious?"
    new "え、マジで？"

    # say L1641 pla
    old "Come on, you can't just give up like this."
    new "Come on、そんな簡単に諦めるなよ。"

    # say L1642 pla
    old "You have to try it."
    new "試してみなきゃダメだよ。"

    # say L1646 pla
    old "It isn't impossible, you don't have to know the script."
    new "無理じゃねえよ、台本を知らなくてもいい。"

    # say L1647 pla
    old "Or even read the whole thing."
    new "全部読む必要ないよ。"

    # say L1648 pla
    old "Let's just keep practicing this part."
    new "この部分だけ練習しよう。"

    # say L1649 pla
    old "And I'm sure you'll be able to use what we practice here today for the audition tomorrow."
    new "今日練習したことを明日のオーディションで活かせるだろうな。"

    # say L1661 bri
    old "[pla], is just the same as earlier, her emotions are all over the place!"
    new "[pla]、先ほどと同じで、彼女の感情がめちゃくちゃ揺れ動いてる！"

    # say L1662 bri
    old "I'm not even reading her mind right now and I can tell."
    new "今頭の中を読んでないのに、わかるよ。"

    # say L1663 pla
    old "{i}Well, can't you read her mind right now and tell me anything useful?{/i}"
    new "{i}まあ、今彼女の心を読めるんだろ？何か役立つこと教えてくれんか？{/i}"

    # say L1664 bri
    old "Let me see."
    new "見せて。"

    # say L1671 bri
    old "Hmm, I don't know."
    new "うーん、よくわからないな。"

    # say L1672 bri
    old "All I can tell is that she's incredibly stressed."
    new "彼女がものすごくストレスを抱えてることはわかるけど、それだけよ。"

    # say L1673 bri
    old "It's amazing [pla], she's under so much tension!"
    new "すごいな、[pla]、彼女はものすごく緊張してるんだ。"

    # say L1674 bri
    old "With the way she's feeling now she won't listen to anything you have to say to her."
    new "今の彼女の状態じゃ、あなたが何を言っても耳に入らないわ。"

    # say L1676 pla
    old "{i}Yeah, I can see that...{i}"
    new "{i}そうだな、わかるよ...{i}"

    # say L1678 pla
    old "{i}What about you? Don't you have something that could be useful?{/i}"
    new "{i}君には何か役立つものないか？{/i}"

    # say L1680 pla
    old "{i}Like a spell to calm her nerves or something?{/i}"
    new "{i}何か彼女の神経を落ち着かせる魔法でもあるのか？{/i}"

    # say L1681 bri
    old "There's nothing like that."
    new "そんなのはないわ。"

    # say L1682 pla
    old "{i}Really?{/i}"
    new "{i}ほんと？{/i}"

    # say L1683 bri
    old "Yeah, all I could do with a spell is try to influence her will, but there's nothing to change emotions into others."
    new "うん、魔法でできることは彼女の意思を少し操ることくらいだけど、感情を別のものに変える方法はないの。"

    # say L1684 pla
    old "{i}Well, then we're in a bad situation here.{/i}"
    new "{i}じゃあ、これは悪い状況だな。{/i}"

    # say L1685 pla
    old "{i}Because she's very certain that she's terrible.{/i}"
    new "{i}彼女は自分が最悪だって、めちゃくちゃ確信してるからな。{/i}"

    # say L1687 bri
    old "Isn't there anything you could use to calm her feelings?"
    new "彼女の気持ちを落ち着かせる何かない？"

    # say L1688 bri
    old "Don't you humans have a substance you ingest in these situations?"
    new "人間にはそんな状況で摂取する物質があるんじゃない？"

    # say L1689 bri
    old "I've seen your [mo1rel] use it before, she seems to calm down with it."
    new "あなたの [mo1rel] が前に使っていたわ、彼女はそれで落ち着いていたみたいよ。"

    # say L1697 pla
    old "What? No, no, nothing like that."
    new "何？いや、そんなのないよ。"

    # say L1698 pla
    old "I'm sure you can do it."
    new "大丈夫だよ、君ならできるさ。"

    # say L1699 pla
    old "Just wait here a second, I know of something that can help."
    new "ちょっと待て、手助けになるものがあるんだ。"

    # say L1710 pla
    old "Alright, I think this is just what we need."
    new "よし、これでいけるはずだ。"

    # say L1712 pla
    old "Well, no, not really."
    new "いや、そうでもないな。"

    # say L1713 pla
    old "But I think that drinking a little might help."
    new "でも、少し飲むと手伝いになるかもしれないな。"

    # say L1716 pla
    old "I can't remember exactly where I read it"
    new "正確にどこで読んだのか覚えてないけど"

    # say L1717 pla
    old "But it was about how some famous actors sometimes drink a little alcohol before shooting some of their scenes."
    new "でも有名な俳優たちが、シーンを撮影する前に少しアルコールを飲むことがあるって書いてあった。"

    # say L1718 pla
    old "This is supposed to help them feel relaxed, and be able to act more naturally."
    new "これは彼らがリラックスして、より自然に演技できるようにするためだよ。"

    # say L1721 pla
    old "I understand that it seems a bit odd, but we could give it a try."
    new "それは少し変に感じるかもしれないけど、試してみるのもいいじゃん。"

    # say L1722 pla
    old "After all, you are feeling a little stressed. Maybe this could help you relax enough for you to recite the lines."
    new "君は少しストレスを感じてるだろ。これでリラックスして台詞を読めるかもしれないな。"

    # say L1726 pla
    old "Oh come on, you can be a little bit more positive than that. I'm sure this is going to help you."
    new "おい、もうちょっと前向きになれないか？絶対に効果あるよ。"

    # say L1750 pla
    old "I'm glad you like it."
    new "嬉しいよ"

    # say L1751 pla
    old "Do you feel better now?"
    new "今の方が調子いいのか？"

    # say L1765 pla
    old "I see you're feeling better. Let's try it."
    new "君が元気になったのが分かるな。やってみよう。"

    # say L1771 pla
    old "I can prove it!'"
    new "証明してやる！"

    # say L1772 pla
    old "'I can tell you!"
    new "俺が証明してやる！"

    # say L1773 pla
    old "'I'm here now! And you didn't call me!'"
    new "俺がここにいるんだよ！それに君は俺を呼んでくれなかった！"

    # say L1774 pla
    old "'I came because you needed me!'"
    new "俺が来たのは君が必要だったからだよ！"

    # say L1781 pla
    old "{i}(Wow! It seems like drinking really helped, she got so good all of a sudden!){/i}"
    new "{i}(おお！アルコールの力か、急に上手くなったな！){/i}"

    # say L1783 pla
    old "{i}(Now it's my line, I better not brake her concentration now that she's finally doing it well.){/i}"
    new "{i}(今度は俺の番だ、彼女の集中を乱すわけにはいかないな、ようやく上手くなってきたんだから。){/i}"

    # say L1788 pla
    old "'Not staying was a mistake!'"
    new "いっつもそばにいてやればよかったな！"

    # say L1789 pla
    old "'I should've stayed by your side, I should've been here when you needed me!'"
    new "俺が君の側にいてあげるべきだった、君が必要な時にここにいなきゃならなかった！"

    # say L1790 pla
    old "'But that's why I'm here now!'"
    new "だから今ここにいるんだよ！"

    # say L1791 pla
    old "'To be your companion!'"
    new "あなたの伴侶になるよ！"

    # say L1792 pla
    old "'Your rock! Your partner!'"
    new "あなたの支え！パートナーだ！"

    # say L1805 pla
    old "'I will be!'"
    new "俺がな！"

    # say L1806 pla
    old "'I promise you!'"
    new "約束するよ！"

    # say L1814 pla
    old "You know what? It was, it really was."
    new "知ってる？それは本当にそうだったんだ。"

    # say L1815 pla
    old "I think the alcohol really helped you. Because that last part was great."
    new "アルコールのおかげで本当に良かったな。最後の部分は最高だったよ。"

    # say L1816 pla
    old "But let's keep going until we finish this part of the dialogue."
    new "でも、この会話を終わるまで続けよう。"

    # say L1822 pla
    old "'So! Do you believe me when I say it?'"
    new "じゃあ！俺が本気だって信じてくれるか？"

    # say L1823 pla
    old "'That I want to be by you!'"
    new "俺が君のそばにいたいって！"

    # say L1824 pla
    old "'That I need to be by your side!'"
    new "君の側にいなきゃならないんだよ！"

    # say L1825 pla
    old "'Nothing would make me happier!'"
    new "何もより幸せなことはないよ！"

    # say L1840 pla
    old "'It means that we love each other!'"
    new "それがお互いを愛してるってことだな！"

    # say L1848 pla
    old "{i}(Wow! She's so much better than she was just a minute ago!){/i}"
    new "{i}(Wow！ さっきよりも全然上手くなったな！){/i}"

    # say L1849 pla
    old "{i}(Hmm, there's a kiss scene coming, and I didn't tell her where the scene would end.){/i}"
    new "{i}(うーん、次はキスシーンだな。でも、どこで終わるか教えてあげてないけど。){/i}"

    # say L1850 pla
    old "{i}(She won't kiss me without talking with me about it, right?){/i}"
    new "{i}(話さずにキスするわけないだろ？){/i}"

    # say L1860 pla
    old "'I can, and I will!'"
    new "俺ができる、そして絶対にするよ！"

    # say L1861 pla
    old "'If you say yes now I promise I'll always be there!'"
    new "今すぐYESって言うなら、絶対にいつでも君の側にいるよ！"

    # say L1862 pla
    old "'I will always be the rock that you need!'"
    new "俺はいつでも君が必要とする岩になるぜ！"

    # say L1863 pla
    old "'No matter what!'"
    new "どんな時でも！"

    # say L1883 pla
    old "{i}(I can't believe it, she actually kissed me!){/i}"
    new "{i}(信じられない、実際にキスしてきたんだな…){/i}"

    # say L1884 pla
    old "{i}(That was unexpected, but I guess she's really into the role.){/i}"
    new "{i}(予想外だったけど、役に入り込んでいるんだな。){/i}"

    # say L1885 pla
    old "{i}(If that's the case then I should just keep going with the script.){/i}"
    new "{i}(そうなら、台本通りに続けていこう。){/i}"

    # say L1897 pla
    old "'I'll gladly take it!'"
    new "喜んで受け取らせてもらうよ！"

    # say L1898 pla
    old "'But in return, I'll let you have mine!'"
    new "でも代わりに、君の分もあげるよ！"

    # say L1899 pla
    old "'Because this is a partnership!'"
    new "これがパートナーシップだからだよ！"

    # say L1900 pla
    old "'We're meant to be together!'"
    new "一緒にいなきゃならないんだ！"

    # say L1901 pla
    old "'I know it!'"
    new "分かってるよ！"

    # say L1924 pla
    old "'Are you sure?'"
    new "本当に？"

    # say L1925 pla
    old "'Does this mean that you'll stay by my side?'"
    new "これって、君が俺の側にいてくれるってことなのか？"

    # say L1960 pla
    old "Uhh... Y- yeah, it was, it really, really was."
    new "うーん… よ、よかった、本当に良かった。"

    # say L1961 pla
    old "I- I mean, your acting was great."
    new "うーん、つまり、君の演技が本当に上だったってことだな。"

    # say L1962 pla
    old "I think you won't have any problems when the audition comes."
    new "オーディションの時も問題ないと思うな。"

    # say L1966 pla
    old "Hmm... Sure."
    new "うん…そうかも。"

    # say L1979 pla
    old "Okay."
    new "オッケー。"

    # say L1980 pla
    old "But maybe we should change the scene because this one ends in a love scene between the leads."
    new "でも、このシーンは主人公同士のラブシーンで終わるから、別のシーンに変更した方がいいかもな。"

    # say L1981 pla
    old "So, we could look for another one."
    new "じゃあ、別のシーンを探すか。"

    # say L1987 pla
    old "U- Uhh, I- I don't know how- ."
    new "うー、あの、どうして…。"

    # say L1998 pla
    old "Don't you think you're drinking a little too much of that?"
    new "お前、それ飲むのちょっと excessな気しない？"

    # say L2015 pla
    old "W- what are you doing Barbie?"
    new "バービー、お前何やってんだよ？"

    # say L2035 pla
    old "Listen... About last night..."
    new "聞いて... 昨晩のことについてさ..."

    # say L2041 pla
    old "Uhh... Yeah, yeah, sure, don't worry about it..."
    new "うーん… ああ、ああ、大丈夫、気にするな…"

    # say L2052 pla
    old "Good luck with the audition, I know you'll do great."
    new "オーディション、頑張ってな。君ならきっと上手くいくよ。"

    # say L2063 bri
    old "That was great [pla]!"
    new "それが良かったね [pla]！"

    # say L2065 bri
    old "You finally did it! Well done!"
    new "やっとできたね！よくやった！"

    # say L2067 bri
    old "Of course you'll have to have more sex with her..."
    new "もちろん、これからも彼女とセックスする機会があるだろうね…"

    # say L2069 bri
    old "But now that you've done it once, you shouldn't have any problems doing it again..."
    new "でも一度やっちゃったんだから、次は問題ないでしょ…"

    # say L2070 bri
    old "Now we can focus on finding the next specimen."
    new "これからは次の標本を探すことに集中できるわ。"

    # say L2073 bri
    old "Well of couse."
    new "もちろんね。"

    # say L2074 bri
    old "Now that you know you're going to have sex with this woman so easily."
    new "今さら簡単にこの女性とセックスできるって知ったから。"

    # say L2075 bri
    old "You can stop wasting time on her and focus on finding the next person we need."
    new "もう彼女に時間を使わなくていいわ、次の人を見つけることに集中しなさい。"

    # say L2076 pla
    old "Hey, hey, stop it right there!"
    new "Hey, hey,止めなよ！"

    # say L2077 pla
    old "I don't know what it is you have in mind."
    new "何考えてるのかさっぱりわからないな。"

    # say L2079 pla
    old "But is not that easy..."
    new "でもそんなに簡単じゃないな..."

    # say L2081 pla
    old "I promised I would help her with this, and I plan to fulfill that promise."
    new "約束したんだ、彼女を助けるって。その約束を守るつもりだ。"

    # say L2083 pla
    old "So I'm sorry to disappoint you, but until she gets an acting job, I won't be looking for another 'specimen'..."
    new "だから残念ながら、彼女が役者としての仕事を手に入れるまで、他の「標本」を探すつもりはないんだ。"

    # say L2085 pla
    old "Besides, I don't think there's going to be a next time having sex with her if I just leave her hanging."
    new "それに、俺が放っておくと次はもう彼女とセックスできないんじゃないか。"

    # say L2086 pla
    old "And you still need me to do it with her more times, isn't it?"
    new "君はまだ俺と彼女が何度もする必要があるって思ってるんでしょ？"

    # say L2088 bri
    old "Ughh! You humans are so complicated!"
    new "うっ！人間ってほんと複雑よね！"

    # say L2090 bri
    old "Fine! Do as you wish!"
    new "いいわ！ どうするのも勝手よ！"

    # say L2092 bri
    old "But do it quickly! We don't have much time to lose!"
    new "早くして！時間ないのよ！"

    # say L2093 pla
    old "Yeah, yeah, you've made that clear."
    new "分かってるよ、分かってる。早くしなさいって言ってるんだから。"

    # say L2117 pla
    old "Hey Barbie, how are you?"
    new "Hey Barbie、今どうしてる？"

    # say L2121 pla
    old "W- what? Why?"
    new "えっ、なんで？"

    # say L2126 pla
    old "It did? You didn't feel comfortable?"
    new "そうか？ 不快に感じたの？"

    # say L2131 pla
    old "I get it, I mean... I guess fear made you forget the dialogue..."
    new "分かってる、つまり… 恐怖が会話を忘れさせてたってことか…"

    # say L2153 pla
    old "Who does he think he is? He has no right to treat you like that!"
    new "誰だと思ってんだ？君をそんなに扱う権利なんてないだろう！"

    # say L2154 pla
    old "I'm sorry Barbie, you didn't deserve him treating you like that."
    new "ごめん、Barbie。君がそんな扱いを受けるなんて、本当はあってはならないことだったね。"

    # say L2160 pla
    old "No you're not, don't make what he told you a law."
    new "そんなことない、彼の言うことを律にしてちゃダメだよ。"

    # say L2161 pla
    old "You're very talented Barbie, I saw it the other day while we were practicing."
    new "バービー、お前は才能があるよ、先日練習してるところ見ただろ。"

    # say L2162 pla
    old "I'm sure it's going to be better in the next audition you go to."
    new "次のオーディションに行くときにはきっともっと良くなるよ。"

    # say L2167 pla
    old "B- but that's your dream, to be part of show business."
    new "でも、それがあなたの夢だろ？ショー業界で活躍することとか。"

    # say L2168 pla
    old "You know, to work in acting and stuff."
    new "演技とかやってみたいって知ってるよ。"

    # say L2180 pla
    old "Wait! Wait!"
    new "待て！待て！"

    # say L2181 pla
    old "Don't think so bad about yourself!"
    new "自分をそんなに悪く思わないでよ。"

    # say L2182 pla
    old "You shouldn't believe that you're not good enough to act!"
    new "君が役者に向いていないなんて思っちゃダメだよ。"

    # say L2183 pla
    old "I know you're more than capable of it."
    new "絶対にできるって信じてるよ。"

    # say L2191 pla
    old "Hey I have an idea!"
    new "おい、アイデアがあるぞ！"

    # say L2192 pla
    old "Listen, I know you're feeling bad."
    new "聞いて、君の気持ちは分かるよ。"

    # say L2193 pla
    old "But I think there's a way so that you don't have to give up on your dream."
    new "でも、君の夢を諦めずに済む方法があると思うんだ。"

    # say L2197 pla
    old "I get it, but listen, your dream is to be famous, right?"
    new "分かってるけど、お前の夢は有名になることだろ？"

    # say L2198 pla
    old "But there's more than one way of achieving it."
    new "でも、それを達成する方法は一つじゃないんだ。"

    # say L2200 pla
    old "For example, have you thought about modeling?"
    new "例えば、モデルになること考えたことある？"

    # say L2204 pla
    old "Sure!  Listen, maybe you're right about not being the best actor right now."
    new "もちろん！　でも、今すぐ最高の俳優になれてないかもしれないな。"

    # say L2205 pla
    old "But that's not the only way to earn fame."
    new "でも、それだけが名声を得る方法じゃないさ。"

    # say L2206 pla
    old "There are several different things that you can do."
    new "いくつかの違うことができるな。"

    # say L2208 pla
    old "And I think you could easily be an amazing model!"
    new "俺は君が簡単に素晴らしいモデルになれると思うよ！"

    # say L2211 pla
    old "Of course I do!"
    new "もちろんだよ！"

    # say L2212 pla
    old "There are several actors that got their start as models, and over time they moved into acting."
    new "モデルから俳優になった人もいるよ。"

    # say L2213 pla
    old "With how beautiful you are. I don't see why you couldn't do the same thing."
    new "君が Gorgeous なのは間違いないし、同じようにできるはずがないとは思えないよ。"

    # say L2217 pla
    old "You have to be kidding me."
    new "冗談だろ。"

    # say L2218 pla
    old "I mean, look at yourself. You're beautiful."
    new "お前、自分を見てみろよ。美しいって。"

    # say L2219 pla
    old "And you have an amazing body!"
    new "そして君の体は最高だよ！"

    # say L2220 pla
    old "Of course you can be a model!"
    new "もちろんモデルになれるよ！"

    # say L2227 pla
    old "How can you say that?"
    new "どうしてそう言えるんだ？"

    # say L2228 pla
    old "Maybe what you're saying about models was true several years ago."
    new "モデルについて言ってることも、数年前なら本当だったかもしれないけど。"

    # say L2230 pla
    old "But there are several different types now. And you are one of the most beautiful women that I've met."
    new "でも今はいくつかのタイプがあって、君は私が会った中で一番美しい女性の一人だ。"

    # say L2231 pla
    old "I'm sure you'll find work in any agency you want in no time."
    new "君が望むどのエージェンシーでも、すぐ仕事見つかるだろうな。"

    # say L2236 pla
    old "Of course I believe it. And I'm sure it's going to go great."
    new "もちろん信じてるよ。きっとうまくいくさ。"

    # say L2240 pla
    old "R- right... Sure."
    new "うーん、そうか"

    # say L2241 pla
    old "I'll get you something as a model."
    new "モデルを用意するよ。"

    # say L2242 pla
    old "So, I'm going to have to make a couple of calls, but I'll let you know later about what I find."
    new "いくつか電話するけど、後で見つかったこと教えてあげるよ。"

    # say L2243 pla
    old "Ok?"
    new "分かった。"

    # say L2246 pla
    old "You're more than welcome."
    new "全然構わないよ。"

    # say L2247 pla
    old "I'm just happy to help."
    new "助けるのが嬉しいだけだよ。"

    # say L2248 pla
    old "I'll go for now, and I'll see you later, alright?"
    new "俺は先に帰るけど、後でまた会おうぜ、いい？"

    # say L2260 pla
    old "Hmm, I guess it's good that Barbie's feeling better now."
    new "うん、バービーが元気になったのは良かったな。"

    # say L2261 pla
    old "But now, how will I get her a modeling casting?"
    new "でも、どうやって彼女をモデルのオーディションに誘うか？"

    # say L2262 pla
    old "I don't know anyone who works as a model or something similar..."
    new "モデルの仕事をしてる人を知らなくて..."

    # say L2263 pla
    old "Hmph, I don't want to bother Belle again to get me an audition..."
    new "ふん、ベールにまた面倒をかけてオーディションの紹介をしてもらうのは嫌だな…"

    # say L2264 pla
    old "Who else could help me with this..."
    new "誰か他に手伝ってくれるやつがいるかな…"

    # say L2268 bri
    old "What are you doing?"
    new "何してるの？"

    # say L2270 bri
    old "When you went looking for her, I thought you would come back together to have sex..."
    new "あなたが彼女を探しに行ったと思ったら、二人で戻ってきてセックスすると思ってたの..."

    # say L2271 pla
    old "Of course not, things don't work like that..."
    new "もちろんそんなことない、そんなに簡単にはいかないよ..."

    # say L2273 pla
    old "Perhaps you should be helping me instead of complaining so much."
    new "文句ばかり言っているより、手伝ってくれた方がいいのに。"

    # say L2274 pla
    old "Maybe this way we can help Barbie more quickly..."
    new "この方法なら、バービーを早く助けることができるかもしれないな。"

    # say L2275 pla
    old "And so we can wrap this up and start looking for the next 'specimen' as you want..."
    new "そしてこれを早く片付けて、次の人形を探すための行動を始めるんだよ…"

    # say L2276 bri
    old "Hmph, I guess you leave me no choice..."
    new "ふん、選択の余地がないみたいね…"

    # say L2278 pla
    old "It's not easy, really, unless you magically know somebody that can get a casting with a modeling agency."
    new "簡単じゃないよ、君がモデルエージェンシーとつながってるわけじゃないし。"

    # say L2280 pla
    old "I need someone who works with models, you know, like these clothes and lingerie brands, or something like that..."
    new "モデルと仕事してる誰かが必要だな、服やランジェリーブランドの人とかさ..."

    # say L2287 pla
    old "Wait! I got it! [sis]!"
    new "待った！ 分かった！ [sis]！"

    # say L2288 pla
    old "Right now it's too late, but tomorrow I'll go talk with my [sisrel]."
    new "今夜は遅いけど、明日は[sisrel]と話すつもりだ。"

    # say L2289 bri
    old "Oh no, why do I get the feeling this is going to take even longer?"
    new "ああ、なんでこんなに長引くような気がするの？"

    # say L2290 pla
    old "Relax, you help me to talk with [sis] tomorrow and we could get Barbie a model job, and that's it."
    new "心配しないで、明日君が俺の[sis]と話す手伝いをしてくれれば、バービーにモデルの仕事を見つけることができて、それで済むんだ。"

    # say L2291 bri
    old "Hmm, if you say so..."
    new "うーん、そうなの？"

    # say L2292 pla
    old "Anyway, I'm a bit tired, so, I'm going to sleep now..."
    new "まあ、ちょっと疲れたから、今就くよ..."

    # say L2294 pla
    old "See you tomorrow Brixxida."
    new "また明日ね、ブリクシダ。"

    # say L2295 bri
    old "See you..."
    new "またね…"

    # say L2318 sis
    old "What brings you here so early?"
    new "早朝に来て何なの？"

    # say L2319 pla
    old "Hey [sis]. Good morning."
    new "Hey [sis]、おはよう。"

    # say L2322 sis
    old "What's up?"
    new "何の用？"

    # say L2323 pla
    old "W- well... Uhmm."
    new "うーん……その……"

    # say L2325 pla
    old "T- the thing is that I kinda need a favor from you."
    new "あのさ、実はちょっと君の手が必要なんだ。"

    # say L2328 pla
    old "But... I don't really know how to ask you..."
    new "でも... どうやって頼めばいいかわかんないんだ..."

    # say L2329 sis
    old "Well just do it."
    new "じゃあ、さっさとやろう。"

    # say L2330 sis
    old "You know I'll help you with anything you want."
    new "何でも手伝うからね。"

    # say L2332 pla
    old "{b}*Sigh*{/b} Well, here it goes..."
    new "{b}*ため息*{/b} じゃあ、始めるか…"

    # say L2334 pla
    old "Do you know Barbie? The receptionist of the building where Jane's office is located?"
    new "バービー知ってる？ジェーンのオフィスがあるビルの受付嬢だよ。"

    # say L2336 sis
    old "Yeah, sure I do. That silicon-filled bimbo."
    new "もちろん知ってるわ。あのシリコン詰めのバimbo。"

    # say L2337 sis
    old "What about her?"
    new "何のこと？"

    # say L2338 pla
    old "Uh... W- well, the thing is that..."
    new "うーん、その、実を言うとね…"

    # say L2339 pla
    old "S- she kind of needs help with something right now, and I promised I would give her that help."
    new "あのう、その子は今ちょっと困ってるんだよね、だから手伝うって約束したんだ。"

    # say L2340 sis
    old "Are you serious right now [pla]?!"
    new "本気で言ってるの？！ [pla]"

    # say L2341 sis
    old "What kind of help? And what favor are you gonna ask me?"
    new "どんな手伝い？　そして、私に何を頼むの？"

    # say L2342 pla
    old "Well, a few days ago I came into the building to bring some documents from [mo1] and...."
    new "まあ、数日前に建物に入った时候、[mo1]からいくつかの書類を持ってきたんだけど、そして……"

    # say L2343 pla
    old "We got to talking and she told me that lately she's been feeling very sad about not being able to..."
    new "話してて、彼女最近モデルになりたいけどそれが叶わないのがすごく悲しいって言ってた。"

    # say L2349 pla
    old "Well, she wants to be a model, so I said that I would help her with that."
    new "彼女はモデルになりたいって言ってたから、手伝うって言ったんだ。"

    # say L2350 pla
    old "But the truth is that I have no contacts in the modeling industry."
    new "でも実際には、モデル業界とのコネクションがないんだ。"

    # say L2351 pla
    old "So, I was wondering if you would consider having her model for your online business."
    new "だからさ、君のオンラインビジネスで彼女がモデルをやってくれないかと考えてたんだ。"

    # say L2353 sis
    old "No I would not accept it!"
    new "そんなの絶対に受け入れないわ！"

    # say L2356 sis
    old "Why would I want that vulgar, plastic bimbo modeling in my clothes?!"
    new "なぜ私がそんな下品で人工的なバimboが私の服を着てモデルをするなんて欲しがるの？！"

    # say L2357 sis
    old "It would ruin the reputation of my brand!"
    new "ブランドの評判を台無しにするわ！"

    # say L2360 sis
    old "Which by the way, I'm surprised you're so interested in her as to come here and ask me if I would let her model my clothes!"
    new "それにしても、あなたがそんなに彼女に興味があるなんて意外だったわ。ここまで来て、私の服を着せる許可を求めるなんて。"

    # say L2361 sis
    old "You know [pla], I thought you had better taste than that."
    new "知ってるでしょ [pla]、あなたはもっと良い趣味だと思ってたの。"

    # say L2362 sis
    old "I mean..."
    new "うーん..."

    # say L2364 sis
    old "All of this just because you want to bang that stupid girl?"
    new "全部これ、そのバカな子とヤりたいだけなのかしら？"

    # say L2367 pla
    old "What? Come on, is not like that."
    new "何？ そんなことないよ。"

    # say L2368 sis
    old "Oh yeah? Then how is it?"
    new "ほんと？じゃあ、どうなの？"

    # say L2371 sis
    old "Because it seems to me that you're more interested in fucking her than anything else."
    new "だって、私にはあなたが彼女とセックスすることしか興味ないみたいに見えるの。"

    # say L2372 sis
    old "You men are so predictable, you see some stupid girl with tits and ass like balloons and you go crazy."
    new "男の人はほんと予測可能ね、バカな胸とお尻が風船みたいのかわいそうな子を見つけると、頭がおかしくなるの。"

    # say L2373 pla
    old "I already told you, is not like that..."
    new "もう言ったけど、そんなわけじゃないよ…"

    # say L2374 bri
    old "Boy, you seem to have a talent for altering people's feelings."
    new "男の子、人の気持ちを変えるのが得意みたいね。"

    # say L2376 bri
    old "Every time I'm with you, you're making some woman angry or cry or just lose her temper."
    new "あなたといると、毎回どことなく女の人が怒ったり泣いたり、我慢できなくなったりするの。"

    # say L2378 pla
    old "Why don't you help me then?"
    new "じゃあ、君が手伝ってくれよ。"

    # say L2380 sis
    old "What? Do you need even more explanations?"
    new "何？もっと説明が必要なの？"

    # say L2381 pla
    old "Uhh? No, no, I- I-... Nevermind..."
    new "うーん？いいえ、いいえ、俺-俺-... いいや、忘れるか。"

    # say L2384 bri
    old "Hahaha, look at you! Grasping for words."
    new "ははは、見てみて！言葉に困ってるのね。"

    # say L2385 bri
    old "I'll help you then."
    new "じゃあ、手伝おうか。"

    # say L2393 bri
    old "Listen [pla]."
    new "聞きなよ [pla]。"

    # say L2395 bri
    old "She's experiencing a very negative emotion. And it's all directed at you."
    new "彼女はとてもネガティブな感情を抱いていて、それが全部君に向かってるの。"

    # say L2397 sis
    old "Anyway, you can leave, I'm busy."
    new "まあ、いい啦。行けばいいわ。私は忙しいから。"

    # say L2399 bri
    old "No wait! It's not directed at you!"
    new "待って！君じゃなくてその子のことだよ！"

    # say L2402 bri
    old "Is about that girl!"
    new "その子のことだよ！"

    # say L2403 bri
    old "She's..."
    new "彼女が"

    # say L2405 bri
    old "Jelaous!"
    new "嫉妬してる！"

    # say L2407 bri
    old "That's it, she's feeling jealous."
    new "そうだよ、嫉妬してるの。"

    # say L2408 sis
    old "No, [pla], I'm not gonna help you to bang that bimbo..."
    new "[pla]、私そんなビッチと寝る手伝いはしないよ。"

    # say L2409 bri
    old "Uhh, you better do something about that or she really won't help you at all."
    new "うーん、それじゃあ彼女は本当に手伝ってくれないわよ。"

    # say L2411 pla
    old "I mean, I think I didn't express explain properly."
    new "つまり、ちゃんと説明してなかったってことだよ。"

    # say L2413 pla
    old "Listen, the reason why I want to help Barbie is not that I want to sleep with her or something like that."
    new "Listen、Barbie、俺が君を助けてほしい理由は、君と寝たいからじゃないんだ。"

    # say L2414 pla
    old "The truth is that I've been thinking that I would like to be a photographer."
    new "実際には、写真家になりたいと思ってるんだ。"

    # say L2417 sis
    old "A photographer?"
    new "フォトグラファー？"

    # say L2419 pla
    old "Yeah, you know I'm good with the camera."
    new "そうだよ、カメラの扱いは上手いし。"

    # say L2420 pla
    old "And that I know how to edit and present pictures."
    new "そして写真を編集してプレゼンテーションする方法も知ってる。"

    # say L2421 pla
    old "So it came to my mind that I could do some work in that field. You know for magazines and stuff."
    new "だから写真関係の仕事、雑誌とかでできるかなって思ったんだ。"

    # say L2422 pla
    old "But getting a job as a photographer is too difficult."
    new "でも写真家として働くのは難しそうだ。"

    # say L2423 pla
    old "But then I talked with Barbie, and it came to my mind that maybe that was it."
    new "でもね、バービーと話してて、それが答えかもしれないって思ったんだ。"

    # say L2424 pla
    old "That if I helped her it could be good for the both of us, and that I could get a job as a photographer like that."
    new "バービーを手伝えば、お互いに良いことになるし、写真家としての仕事も見つかるかもしれないって思ったんだ。"

    # say L2426 sis
    old "Hmm, are you serius?"
    new "へえ、本気なのか？"

    # say L2427 pla
    old "Yeah, that's really all I'm looking for. I don't know where you got the idea about sex..."
    new "そうだよ、それが本当に全部なんだ。君がセックスの話を持ち出したのはどこからかさっぱりわからないけど…"

    # say L2429 sis
    old "Well, that's not such a bad idea [pla]."
    new "まあ、そんな悪くないアイデアだね [pla]。"

    # say L2431 sis
    old "It's actually some good thinking on your part."
    new "それは実際、あなたの良い考えだと思うわ。"

    # say L2432 sis
    old "But why didn't you start with that?"
    new "でも、なんで最初にそれ言ってくれなかったの？"

    # say L2433 pla
    old "W- well you know."
    new "まあ、知ってるよ。"

    # say L2434 pla
    old "I- I didn't think that was that important."
    new "俺はそれがそんなに重要だと思わなかったんだ。"

    # say L2436 sis
    old "You didn't think that was important?"
    new "そんなに重要じゃないと思ったの？"

    # say L2437 sis
    old "But you thought it was more important to just tell me you want to help that plastic bimbo?"
    new "でも、あなたはそのプラチックビッチを助けることの方がもっと重要だと思ったの？"

    # say L2438 sis
    old "Very smart."
    new "へえ、賢いね。"

    # say L2440 sis
    old "But anyway, I think I see your point."
    new "でもまあ、あなたの言っていることも理解できるわ。"

    # say L2441 sis
    old "And you are good with the camera."
    new "カメラの扱いも上手ね。"

    # say L2442 sis
    old "You could be a good photographer."
    new "あなたはいいカメラマンになれるわよ。"

    # say L2443 sis
    old "Now, let me see your portfolio of her pictures."
    new "それじゃ、彼女の写真のポートフォリオを見せて。"

    # say L2444 pla
    old "Portfolio?"
    new "ポートフォリオ？"

    # say L2446 sis
    old "Well of course."
    new "もちろんよ。"

    # say L2447 sis
    old "I mean, you do have a portfolio of pictures right?"
    new "つまり、写真のポートフォリオ持ってるよね？"

    # say L2448 pla
    old "I- I don't..."
    new "俺は…持ってないんだよ…"

    # say L2449 sis
    old "Ugh, be serious [pla]."
    new "うっせぇ、真剣に話してよ [pla]。"

    # say L2450 sis
    old "You say you want to be a photographer, but you don't know anything."
    new "カメラマンになりたいって言うくせに、何も知らないんだね。"

    # say L2451 sis
    old "If you want someone to give you a job in photography you need to have pictures to show."
    new "写真の仕事をもらいたいなら、見せられる写真が必要だよ。"

    # say L2452 sis
    old "Especially with something like pictures of that little plastic dumb."
    new "特にあの小さなプラスチックのおもちゃの写真なんて。"

    # say L2453 sis
    old "How else is someone going to hire her?"
    new "誰が彼女を雇うの？"

    # say L2454 pla
    old "I understand, so you need me to take pictures of her?"
    new "分かってる、だから彼女の写真を撮る必要があるんだな？"

    # say L2455 pla
    old "I think I can do that, and bring some of those for you."
    new "俺が写真撮って、君のために持ってこられると思うよ。"

    # say L2457 sis
    old "Good. Be sure they're good so that I can show them to the people that might hire her."
    new "いいわ、でも写真はちゃんとしていて、彼女を雇うかもしれない人たちに見せられるようにね。"

    # say L2459 sis
    old "By the way, I hope you understand I'm not doing this out of the goodness of my heart, right?"
    new "それにしても、私がこれをするのは親切心からじゃないのよ、分かってるでしょ？"

    # say L2461 sis
    old "If she's going to get money for it, and I got her the job, I want my cut."
    new "もし彼女がお金を稼ぐなら、私が仕事を見つけたんだから、私の分も欲しいわ。"

    # say L2462 pla
    old "Uhh, yeah yeah, sure..."
    new "うーん、そうだな、分かったよ..."

    # say L2463 pla
    old "If you get her a job, then sure, I can give you a commission."
    new "もし君が彼女に仕事を見つけてくれたら、もちろん手数料を払うよ。"

    # say L2465 sis
    old "I want a 10 percent! Is that clear?"
    new "10パーセントちょうだい！分かってるよね？"

    # say L2466 pla
    old "Sure, whatever."
    new "分かったよ、何でもいいな。"

    # say L2467 pla
    old "Hey, thanks a lot [sis]."
    new "Hey、ありがとうな [sis]。"

    # say L2469 sis
    old "Yeah well, I'm not doing it for her."
    new "まあ、彼女のためにやってるわけじゃないけどね。"

    # say L2470 sis
    old "I'm helping you."
    new "私が手伝ってるのよ。"

    # say L2471 pla
    old "Sure, but thanks anyway."
    new "うん、でもありがとうな。"

    # say L2472 sis
    old "You're welcome."
    new "いえいえ"

    # say L2473 pla
    old "I'll talk to Barbie later and let her know about this."
    new "後でバービーに話すから、心配しないで。"

    # say L2475 sis
    old "Listen, I have to leave for now, so I'll send you the info when I get it."
    new "ちょっと待って、今から出かけるから、情報が手に入ったら送るね。"

    # say L2500 pla
    old "I'm doing well, thank you."
    new "元気だよ、ありがとう。"

    # say L2501 pla
    old "Hey listen, I have great news!"
    new "Hey、聞いてくれ、超いいニュースがあるんだ！"

    # say L2503 pla
    old "You could say that."
    new "そう言っても良いかな。"

    # say L2504 pla
    old "Do you remember what we had talked about modeling?"
    new "モデルの話、覚えてるか？"

    # say L2506 pla
    old "Well, after we talked I got in contact with someone I know that has some connections to the modeling business."
    new "話した後、知り合いのモデル業界にコネクションがある奴に連絡取ったんだ。"

    # say L2507 pla
    old "And she told me that she could get you an interview!"
    new "そして彼女は君の面接を手配できるって言ったんだ！"

    # say L2510 pla
    old "Yeah, but you see..."
    new "うん、でもね..."

    # say L2512 pla
    old "She told me that I had to take some pictures of you, to show to the agency."
    new "彼女は俺に君の写真を撮って、エージェンシーに見せるように言ったんだ。"

    # say L2513 pla
    old "Like a portfolio or something."
    new "ポートフォリオみたいなものさ。"

    # say L2515 pla
    old "You know, to see how you look."
    new "君の見た目を確認するためさ。"

    # say L2519 pla
    old "Actually, I can take them myself."
    new "実際に、自分で撮れるよ。"

    # say L2523 pla
    old "Yeah sure, it wouldn't be a problem."
    new "うん、問題ないよ。"

    # say L2524 pla
    old "I have some experience as a photographer."
    new "写真撮影の経験あるんだ。"

    # say L2527 pla
    old "Heh, well thank you."
    new "へへ、ありがとうな。"

    # say L2528 pla
    old "But you see, we have to take the pictures soon."
    new "でもね、写真を早く撮らなきゃならないんだ。"

    # say L2529 pla
    old "She wants to send them as soon as possible."
    new "彼女はすぐに送りたいんだ。"

    # say L2530 pla
    old "So, how about we go to my house after you finish work and take the photos?"
    new "じゃあ、お前が仕事終わってから俺の家に行って写真撮ろうぜ。"

    # say L2534 pla
    old "Come on, you don't have to worry about it."
    new "心配するな、大丈夫だ。"

    # say L2535 pla
    old "What you're wearing is perfect, you don't need to worry about it."
    new "着てる服は完璧だ、心配しなくてもいい。"

    # say L2539 pla
    old "Of course, you look perfect the way you are."
    new "もちろん、君のままで完璧だよ。"

    # say L2544 pla
    old "Great, so I'll wait until your shift is over, and after we can go to my house."
    new "じゃあ、お前のシフトが終わるまで待ってるよ。その後、うちに来よう。"

    # say L2554 pla
    old "Okay, lets go."
    new "じゃあ、行こう。"

    # say L2567 pla
    old "Alright, we can get started then-"
    new "よし、じゃあ始めるか"

    # say L2570 pla
    old "Don't worry about it."
    new "心配するな。"

    # say L2571 pla
    old "I can show you."
    new "俺が見せるよ。"

    # say L2573 pla
    old "Well, I've helped my [sisRel] before with her work."
    new "まあ、俺は[sisRel]の仕事手伝ったことがあるよ。"

    # say L2574 pla
    old "She has an online clothing business."
    new "彼女はオンラインで服を売ってるんだ。"

    # say L2575 pla
    old "And sometimes I'm the one that takes the pictures of her new clothes."
    new "そして時々、新しい服の写真を撮るのが俺なんだ。"

    # say L2578 pla
    old "Heh, thank you."
    new "へへ、ありがとう。"

    # say L2579 pla
    old "Anyway, I guess we can get started then."
    new "まあ、それじゃあ始めるか。"

    # say L2581 pla
    old "Just relax, I'll tell you how you should pose."
    new "リラックスしとけ、ポーズの仕方教えてやるから。"

    # say L2582 pla
    old "So, for the first picture..."
    new "じゃあ、最初の写真は……"

    # say L2583 pla
    old "How about you sit down in the bed with your legs open, looking this way."
    new "ベッドに座って足を開いて、こっちを見てみろ。"

    # say L2584 pla
    old "Put your left arm up behind your head, and bring the right one to your neck."
    new "左腕を頭の後ろに上げて、右腕は首に当てて。"

    # say L2585 pla
    old "Over your right breast."
    new "右の胸の上に置いて。"

    # say L2586 pla
    old "And look straight at the camera, Ok?"
    new "カメラを見据えて、わかった？"

    # say L2598 pla
    old "Alright perfect! "
    new "よし、完璧だ！"

    # say L2599 pla
    old "That way you're more than perfect!"
    new "その角度なら完璧以上だよ！"

    # say L2600 pla
    old "Just stay put and I'll take the first picture."
    new "そのままいて、最初の写真を撮るから。"

    # say L2621 pla
    old "That was perfect Barbie!"
    new "それが完璧だったよ、Barbie！"

    # say L2622 pla
    old "Now, for the second pose."
    new "次は二番目のポーズだな。"

    # say L2624 pla
    old "Hmm, let's see..."
    new "うーん、どうしよう..."

    # say L2625 pla
    old "I think we should show you from all angles."
    new "俺は君を全方位から見せたいな。"

    # say L2626 pla
    old "So, how about you take more of a kneeling position in the bed."
    new "じゃあ、ベッドで膝をついてみない？"

    # say L2627 pla
    old "With your legs towards me."
    new "足をこちらに向けて。"

    # say L2628 pla
    old "And put your weight on your left arm."
    new "そして左腕に体重をかけて。"

    # say L2642 pla
    old "Yes! That's perfect!"
    new "よし！それだ！"

    # say L2643 pla
    old "Great Barbie!"
    new "バービー、それだ！"

    # say L2645 pla
    old "Just stay like that, and I'll take the picture."
    new "そのままの姿势でいて、写真を撮るから。"

    # say L2666 pla
    old "Alright, that's great!"
    new "よし、それだ！"

    # say L2667 pla
    old "Now, I think we can take another picture."
    new "今度はもう一枚写真を撮ろう。"

    # say L2669 pla
    old "Sure, for the third one let's make it a close-up."
    new "じゃあ、三枚目はアップで撮ろう。"

    # say L2670 pla
    old "So, turn to face the camera."
    new "じゃあ、カメラの方を向いてくれ"

    # say L2671 pla
    old "And bring your breasts forward with your hands while you smile."
    new "手で胸を前に出して、笑ってね。"

    # say L2672 pla
    old "Ok, I know what you mean."
    new "分かった、その通りだ。"

    # say L2685 pla
    old "That's right! Perfect!"
    new "そうだな！完璧だ！"

    # say L2686 pla
    old "You're very good at this Barbie!"
    new "お前はこのバービーにとても上手いな！"

    # say L2688 pla
    old "No matter how good I am, it wouldn't be possible without such a beautiful model."
    new "いくら上手くても、こんな美しいモデルがいなければ無理だよ。"

    # say L2709 pla
    old "Alright, that's it, I think that we have enough pictures with those ones."
    new "よし、これで十分だな。これらのポーズの写真はこれくらいでいいだろう。"

    # say L2711 pla
    old "Yeah, I think those are more than enough."
    new "そうだな、十分すぎるほど撮れたと思う。"

    # say L2716 pla
    old "Ok, I think these came out great!"
    new "Ok、これいい感じに撮れたと思うよ！"

    # say L2720 pla
    old "Here, look."
    new "ここ見て"

    # say L2729 pla
    old "I'm sure they will."
    new "きっとそうだよ。"

    # say L2730 pla
    old "Besides, I still have to do a couple of edits on them."
    new "それに、まだいくつか編集しないといけないんだ。"

    # say L2731 pla
    old "When I'm done they're going to look even better."
    new "完成したら、もっとかっこよくなるよ。"

    # say L2735 pla
    old "What? There's no way this is just because of me taking the pictures!"
    new "何？これだけは俺が写真を撮っただけの理由じゃないだろ！"

    # say L2736 pla
    old "These pictures are because of how beautiful you are."
    new "君の美しさだから、こんな写真が撮れるんだ。"

    # say L2737 pla
    old "After all the only thing I'm doing is just taking the pictures."
    new "結局、俺がやってるのってただ写真を撮るだけだよ。"

    # say L2738 pla
    old "You're the one that's posing."
    new "君がポーズを取ってるんだよ。"

    # say L2739 pla
    old "And if they come up any good, is just because of how well you posed."
    new "写真がうまく撮れたなら、それは君のポーズが良かったからだよ。"

    # say L2755 pla
    old "Woah, woah, w- what are you doing Barbie?"
    new "Woah、woah、w- 何やってんだ、Barbie？"

    # say L2758 pla
    old "B- but..."
    new "でも..."

    # say L2771 pla
    old "Alright, so I'll send the pictures to my contact today. And she'll let me know if she can get the interview for you."
    new "よし、今日中に連絡先に写真送る。そして、君のインタビュー取れるか教えてくれるはずだ。"

    # say L2773 pla
    old "It will probably not be something big, at least not to start with."
    new "多分最初はそんなに大きなものじゃないだろうね。"

    # say L2774 pla
    old "But I think that it might be a good starting point for you."
    new "でも、君にとって良い出発点になるかもしれないな。"

    # say L2786 pla
    old "Yeah, I have to get to it now."
    new "そうだな、今から取りかかるよ。"

    # say L2787 pla
    old "But as soon as the pictures are done I'll hand them over to my contact."
    new "写真が終わったらすぐに連絡先に渡すぞ。"

    # say L2788 pla
    old "And when I get an answer I'll let you know."
    new "答えが返ったら教えてやるよ。"

    # say L2852 pla
    old "Hey [sis], good morning, how are you?"
    new "Hey [sis]、おはよう、調子はどう？"

    # say L2854 sis
    old "I'm doing great, and you?"
    new "私は調子いいよ、あなたは？"

    # say L2855 pla
    old "I'm ok, thank you."
    new "俺はまあ、大丈夫だ。ありがとう。"

    # say L2857 pla
    old "Hey, listen, about the favor that I asked you last time."
    new "Hey、聞いてくれ、前にお願いしたことについてさ。"

    # say L2858 sis
    old "Oh yeah, your little plastic girl's pictures."
    new "ああそう、あなたの小さなプラモデルの女の子の写真ね。"

    # say L2859 sis
    old "I send them over to a friend of mine that works for another clothing business."
    new "その子の写真を、別の衣料品会社で働いている友達に送ったの。"

    # say L2860 sis
    old "Their clothes are more like the type of thing that that idiot would wear."
    new "あのバカが着そうな服のタイプだよ。"

    # say L2861 pla
    old "And what did they say?"
    new "で、どんな反応だった？"

    # say L2868 pla
    old "When do they want to meet her?"
    new "いつ会うんだ？"

    # say L2869 sis
    old "In a couple of days."
    new "数日後だよ。"

    # say L2870 sis
    old "I'll send you the info."
    new "情報送るからね。"

    # say L2871 sis
    old "And don't worry, I talked with them."
    new "心配しないで、彼らと話したわ。"

    # say L2872 sis
    old "They said that if they hire her they'll be sure to give us our cut."
    new "彼らは彼女を雇うなら、私たちの分も確実にくれるって言ったわ。"

    # say L2873 pla
    old "I see... That's great."
    new "なるほど…それはいいね。"

    # say L2874 pla
    old "Alright, I'll have to tell her about this."
    new "分かった、彼女に伝えるよ。"

    # say L2875 pla
    old "Thanks a lot [sis]."
    new "ありがとうな、[sis]。"

    # say L2878 sis
    old "Remember to tell your little friend that she has to be there on time."
    new "小っけえ友達にちゃんと時間通りに来ることを伝えてね。"

    # say L2880 sis
    old "I don't want her to make me look bad by getting there late or anything."
    new "遅刻して私が恥をかくのは嫌だからね。"

    # say L2881 sis
    old "Is that clear?"
    new "分かった？"

    # say L2882 pla
    old "Yeah, yeah, it is."
    new "分かったよ、分かったよ。"

    # say L2883 sis
    old "Good."
    new "分かったわ。"

    # say L2884 pla
    old "Yeah.. I'll see you later then."
    new "うん.. じゃあ後でな。"

    # say L2885 pla
    old "Bye [sis], thanks for the help."
    new "バイ [sis]、助けてくれてありがとう。"

    # say L2909 pla
    old "I'm good, and listen I have some great news!"
    new "俺は大丈夫だ、そして聞いてくれ、めちゃくちゃいいニュースがあるんだ！"

    # say L2911 pla
    old "That contact I told you about got an interview for you!"
    new "あの連絡先が君のために面接の機会を手に入れたって！"

    # say L2914 pla
    old "Yeah, it's to apply for a position as a model for a clothing brand that works mainly online."
    new "オンラインで主に活動している服のブランドのモデルの仕事だよ。"

    # say L2915 pla
    old "It's not the biggest job in the world but..."
    new "そんなに大きな仕事じゃないけど..."

    # say L2919 pla
    old "It's my pleasure."
    new "喜んで"

    # say L2920 pla
    old "I'm happy to be able to help you."
    new "君のために手伝えて嬉しいよ。"

    # say L2921 pla
    old "I'll send you the details, don't forget to go, alright?'"
    new "詳細は送るから、忘れないで来るようにね。"

    # say L2923 pla
    old "Hey, don't thank me yet. Let's wait until you get the job."
    new "Hey、まだ感謝するな。君が採用されたら喜ぶよ。"

    # say L2925 pla
    old "I'll come by later to see how everything went, alright?"
    new "後でまた来て、どうなったか見にくるからな。"

    # say L2945 bri
    old "You're taking too long, how many more times are you going to see this woman?"
    new "あなた、遅すぎるよ。この女性に何回会うつもり？"

    # say L2946 pla
    old "I already told you. Until I'm done helping her with everything I promised I would do."
    new "もう言っただろう。約束したことは全部終わるまでさ。"

    # say L2947 pla
    old "What are you doing here anyway?"
    new "何してんだよ、ここにいるって？"

    # say L2948 bri
    old "I thought I told you, you take too long."
    new "もう言ったでしょ、あなたが長すぎるって。"

    # say L2949 bri
    old "So, I came to help you deal with this quickly."
    new "だから、早く片付けられるように手伝いに来たのよ。"

    # say L2950 pla
    old "Ok, thank you I guess."
    new "分かった、ありがとう。"

    # say L2951 pla
    old "But I think everything's going to go well, you know?"
    new "でも、きっと上手くいくよ、分かる？"

    # say L2952 pla
    old "Since I got her the interview, I'm sure that went well, and now she has good news."
    new "面接の手伝いをしたから、うまくいったはずだし、今いい知らせがあるだろう。"

    # say L2953 pla
    old "But let's go and talk to her."
    new "でもさ、行こうぜ、話すか。"

    # say L2963 pla
    old "Hey Barbie, good morning."
    new "Hey Barbie、おはよう。"

    # say L2967 pla
    old "W- what's wrong Barbie?"
    new "バービー、どうしたの？"

    # say L2970 pla
    old "It didn't go well?"
    new "上手くいかなかったのか？"

    # say L2972 pla
    old "What happened?"
    new "何があったんだ？"

    # say L2975 pla
    old "S- sure, no problem."
    new "うん、大丈夫だ。"

    # say L2976 pla
    old "I'll see you later then."
    new "じゃあ後でな。"

    # say L3000 pla
    old "Ok, so now will you tell me about what happened?"
    new "じゃあ、今度は起こったこと教えてくれる？"

    # say L3001 pla
    old "How did the interview go?"
    new "面接はどうだった？"

    # say L3007 pla
    old "Ok, that's good to hear."
    new "そうだな、それは良かったね。"

    # say L3008 pla
    old "But then what went wrong?"
    new "でもその後何が悪くなったんだ？"

    # say L3014 pla
    old "So, did he say anything to you about that?"
    new "じゃあ、彼はそのことについて何か言ったのか？"

    # say L3030 pla
    old "What the hell? Who does he think he is?!"
    new "何だよ、彼は自分が誰だと思ってんだ？！"

    # say L3031 pla
    old "I'm sorry Barbie, I had no idea things would turn out that way."
    new "すみません、バービー。こんなことになるとは思わなかったんだ。"

    # say L3032 pla
    old "I didn't expect that."
    new "そんなことになるとは思わなかった。"

    # say L3033 pla
    old "But I'll get you another interview in a better place."
    new "でも安心しろ、もっといい場所でまた面接のチャンス作るよ。"

    # say L3034 pla
    old "And I'll make sure that this doesn't happen again."
    new "そして、こんなの二度と起こらないようにするよ。"

    # say L3039 pla
    old "W- wait!"
    new "待って！"

    # say L3040 pla
    old "I get it, you've had a bad streak with the auditions and interviews."
    new "分かってる、オーディションと面接で調子が悪かったのか。"

    # say L3041 pla
    old "But that doesn't mean that you should give up."
    new "でも、それが君が諦める理由にはならないよ。"

    # say L3042 pla
    old "Don't let a couple of bad experiences rob you of your dream."
    new "悪い経験が何回かあったって、夢を奪う必要はないんだよ。"

    # say L3046 pla
    old "D- do you want to talk about it?"
    new "話してみる？"

    # say L3050 pla
    old "Listen Barbie, what you have been going through with these... Bad experiences."
    new "バービー、お前が経験した……悪い体験のことだよ。"

    # say L3051 pla
    old "I can't imagine how frustrating it must be."
    new "想像もつかないよ、どれだけストレスフルなことか。"

    # say L3052 pla
    old "Especially if there are things from your past that are related to this. I think that causes you a lot of pain."
    new "特に過去にこれに関連する何かがあるなら、それが君にとってかなりの苦痛になっていると思うよ。"

    # say L3056 pla
    old "I understand, and that's fair."
    new "分かってるよ、それは当然だ。"

    # say L3057 pla
    old "But I also think you still shouldn't give up on your dream of becoming a star Barbie."
    new "でも、お前の夢であるスター・バービーになることだけは諦めちゃダメだよ。"

    # say L3058 pla
    old "I've seen your passion for it. And I know how much of a hard worker you are."
    new "お前の情熱を見てきたし、どれだけ努力家か知ってるよ。"

    # say L3059 pla
    old "If someone deserves a shot at something like that, it's you."
    new "誰かがそんなチャンスを掴むべきなら、それは君だよ。"

    # say L3064 pla
    old "Hmm, I see..."
    new "うーん、なるほど…"

    # say L3065 pla
    old "Listen, you already told me that something's troubling you."
    new "おい、お前はもう俺に何か悩んでることがあるって言ったじゃねえか。"

    # say L3066 pla
    old "But you told me you don't want to talk about it."
    new "でも、お前は話したくないって言ったじゃん。"

    # say L3067 pla
    old "Which I understand."
    new "それが分かってるよ。"

    # say L3068 pla
    old "But I think you should talk about it."
    new "でも、話した方がいいと思うよ。"

    # say L3069 pla
    old "Maybe opening up about it would do you well."
    new "開きやすったらいいかもしれないね。"

    # say L3071 pla
    old "I get it, it must be a painful memory, but you know, there's nothing to be afraid of."
    new "分かってる、辛い思い出だろうけど、何も恐れることはないんだよ。"

    # say L3072 pla
    old "You can trust me with anything you want to share."
    new "何でも話せるさ、俺は君の味方だから。"

    # say L3073 pla
    old "No matter what it is, I want to support you and make sure that you feel safe and happy."
    new "どんなことでも、君を支えて、君が安全で幸せな気持ちになれるようにしたい。"

    # say L3074 pla
    old "I mean it Barbie, whatever it is."
    new "バービー、本気だよ。何でも話して。"

    # say L3076 pla
    old "That makes sense, but I'll be more than happy to listen to what you have to say."
    new "それは分かるけど、君が話したいことを聞いてあげたいよ。"

    # say L3077 pla
    old "To listen to you."
    new "君の話を聞くよ。"

    # say L3078 pla
    old "Maybe talking about it you can get rid of some of that pain, you know?"
    new "話してみて痛みを和らげられるかもしれない、分かるだろ？"

    # say L3099 pla
    old "And... W- what happened?"
    new "そして… 何が起きた？"

    # say L3124 pla
    old "Listen Barbie, I know that what happened in your past was very painful."
    new "バービー、お前の過去がとても辛かったことは知ってるよ。"

    # say L3126 pla
    old "And that we can't go back and changed it."
    new "そして、それを変えることはできないんだ。"

    # say L3128 pla
    old "But I don't think you're wrong for chasing your dreams."
    new "でも、夢を追いかけるのは間違ってないと思う。"

    # say L3130 pla
    old "Or that you have made any mistakes by choosing to chase your dreams."
    new "夢を追うを選んだからといって、間違いを犯したとは思わないよ。"

    # say L3132 pla
    old "Yes it's true that you've been unlucky with how things have gone in the past."
    new "確かに過去には運が悪かったかもしれないけど。"

    # say L3133 pla
    old "But I believe you still have a lot of chances for things to go your way."
    new "でも、君が自分の道を進むチャンスはまだたくさんあると思う。"

    # say L3135 pla
    old "You're a beautiful and hard-working woman."
    new "君は美しいし、一生懸命な女性だよ。"

    # say L3136 pla
    old "I'm sure if you keep trying, sooner or later you'll someday meet someone that will be different from the rest."
    new "君が頑張り続ければ、きっといつか他の誰とも違う誰かと出会えるさ。"

    # say L3139 pla
    old "Of course you will!"
    new "もちろんそうなるよ！"

    # say L3141 pla
    old "You're diligent and capable."
    new "君は勤勉で能力があるな。"

    # say L3142 pla
    old "And I'm completely sure that you will find very good fortune."
    new "そして、君が大いなる幸運を見つけること間違い無しだよ。"

    # say L3144 pla
    old "As I told you, if someone deserves good things coming their way, that is you."
    new "お前が良いことがあって当然だ、って前にも言ったろ。"

    # say L3145 pla
    old "So, if you'll believe me, I would like to help you keep working towards achieving your dream."
    new "じゃあ、信じてもらえるなら、君の夢を叶えるために手伝いたいんだ。"

    # say L3160 pla
    old "I'm just happy that I get to be here for you Barbie."
    new "俺がここにいられて嬉しいよ、Barbie。"

    # say L3161 pla
    old "About the other things, I'm just saying the truth every time we talk."
    new "他のことについては、毎回本当のこと言ってるんだよ。"

    # say L3162 pla
    old "You're a capable and talented person."
    new "君は能力があって才能がある人だよ。"

    # say L3195 pla
    old "I- I'll do my best."
    new "俺、頑張るよ。"

    # say L3197 pla
    old "Really, the next one will be better."
    new "本当に、次はもっと良くなるよ。"

    # say L3199 pla
    old "I'm sure of it Barbie."
    new "俺は確信してる、Barbie。"

    # say L3203 pla
    old "I'm glad you feel that way."
    new "君がそう思ってくれて嬉しいよ。"

    # say L3204 pla
    old "Even though there have been a couple of inconveniences."
    new "確かにいくつかの不便はあったけど。"

    # say L3205 pla
    old "But I'm sure we'll get you a job that's good enough for you."
    new "でも、君に合ったいい仕事を見つけることができると思うよ。"

    # say L3214 pla
    old "U- Uh, I- I mean."
    new "うーん、あの、つまり。"

    # say L3223 pla
    old "Uh, s- sure, see you later."
    new "うーん、そうか、じゃあまたね。"

    # say L3244 sis
    old "Hey [pla], good morning."
    new "Hey [pla]、おはよう。"

    # say L3245 pla
    old "Hey [sis], good morning."
    new "Hey [sis]、おはよう。"

    # say L3246 sis
    old "How are you today?"
    new "今日どうしてる？"

    # say L3248 pla
    old "I'm doing fine, but there's something we have to talk about."
    new "俺は調子いいけど、話さなきゃならないことがあるんだ。"

    # say L3249 sis
    old "What is it?"
    new "何のこと？"

    # say L3250 pla
    old "Well, I don't know the full details."
    new "WELL、詳細は知らないんだけど。"

    # say L3252 pla
    old "But as Barbie told me, the guy who interviewed her for the modeling job tried to sleep with her."
    new "でもバービーが俺に言ったんだ、モデルの仕事の面接をした男が彼女と寝ようとしたって。"

    # say L3255 pla
    old "Yeah, he did. Apparently, he told her that there were a lot of good candidates for that job."
    new "そうだな、彼はその仕事には有力な候補者がたくさんいると言ったらしい。"

    # say L3257 pla
    old "So if she wanted the job, she would have to give him a {i}'payment'{/i} for it."
    new "だからもし彼女がその仕事を欲しければ、あの男に {i}「支払い」{/i} をしなきゃならなかったんだ。"

    # say L3259 sis
    old "That pig!"
    new "あの豚！"

    # say L3261 sis
    old "I mean what the fuck! What's wrong with him?!"
    new "何てことだよ！彼は一体何を考えているの？！"

    # say L3262 sis
    old "What a disgusting thing."
    new "何て汚らしいことよ。"

    # say L3264 sis
    old "Can you believe that bastard was trying to get me to model some clothes for his brand?"
    new "あのバカが、自分のブランドのために服のモデルをやってくれるようにしようとしてたのよ。"

    # say L3265 sis
    old "But I hadn't had the time to do it."
    new "でも、その時間なかったのよ。"

    # say L3267 sis
    old "That means that if I had been available he would probably have tried the same thing with me!"
    new "それって、私が空いてたら同じ手を使おうとしたってことよね！"

    # say L3269 sis
    old "And he had the gall to try and pull that with her?!"
    new "彼女にそんなことしようとする勇気があるの？！"

    # say L3271 sis
    old "Sure, he probably realized that she needed that opportunity and decided to take advantage."
    new "もちろん、彼は彼女がその機会を必要としていることに気づいて、利用しようとしたのだろうね。"

    # say L3273 sis
    old "What a fucking coward!"
    new "何て卑怯者よ！"

    # say L3274 pla
    old "Uhm... Yeah."
    new "うーん… そうか。"

    # say L3276 sis
    old "But don't worry [pla], I'm not going to let things stay like this."
    new "でも心配しなくていいよ [pla]、このままじゃおかないから。"

    # say L3278 sis
    old "I'm actually in contact with a couple of brands that are working with that guy."
    new "実は、その男と仕事をしているブランドと連絡を取っているの。"

    # say L3280 sis
    old "But they won't be after I tell them what happened."
    new "でも私が彼らに起こったことを話したら、そうはいかなくなるわ。"

    # say L3281 sis
    old "I'll make everyone knows what that bastard tried to do."
    new "みんなにあの野郎が何をしようとしたのか教えてやるつもりよ。"

    # say L3282 sis
    old "That way that pig will learn how to treat women!"
    new "そうすれば、あの豚は女をどう扱うべきか学ぶわ！"

    # say L3283 pla
    old "Uh- I- I see."
    new "うん、そうか。"

    # say L3285 sis
    old "Tell Barbie sorry on my behalf."
    new "バービーに代わりに謝ってね。"

    # say L3286 sis
    old "I may not like her too much, but I would have never knowingly sent her to a place like that."
    new "私は彼女がそんなに好きじゃないけど、あんなところにわざと送るつもりはなかったわ。"

    # say L3288 sis
    old "And of course, I'll make her up for it."
    new "もちろん、彼女に补偿するから。"

    # say L3289 sis
    old "So don't worry, I'll get her another interview."
    new "心配しないで、またちゃんとした面接の機会を作るから。"

    # say L3291 sis
    old "And I'll make sure that this time is with a reputable place."
    new "今回は信頼できるところにするからね。"

    # say L3292 pla
    old "That sounds great [sis], thank you!"
    new "それ Sounds great [sis]、ありがとう！"

    # say L3294 sis
    old "Now, I'll talk to you later."
    new "じゃあ、後でね。"

    # say L3295 sis
    old "I have a couple of calls to make."
    new "いくつかの電話をしなきゃならないの。"

    # say L3296 pla
    old "Uh- S- sure, see you later."
    new "うーん、分かった、また後でな。"

    # say L3319 sis
    old "Good news, I brought something for you."
    new "いいニュースよ、あなたのために何か持って来たわ。"

    # say L3320 pla
    old "Oh really? How come?"
    new "ほんと？どうして？"

    # say L3322 sis
    old "Well, I got another interview for Barbie."
    new "まあ、バービーのためにまた面接があったのよ。"

    # say L3324 pla
    old "That's great [sis]! Thank you."
    new "それは最高だ[sis]！ありがとう。"

    # say L3325 sis
    old "Don't worry about it. I'm happy to help her."
    new "心配しないで。彼女を助けるのは嬉しいよ。"

    # say L3326 sis
    old "And this time I made sure that the place where I'm sending her is quite reputable."
    new "今回は彼女を送る先がかなり評判の良いところだと確認したから。"

    # say L3327 sis
    old "So you can be sure that nothing like what happened last time will happen again."
    new "だから安心して。前のようなことは絶対に起こらないから。"

    # say L3328 pla
    old "That's awesome [sis]!"
    new "それは素晴らしいな [sis]！"

    # say L3329 pla
    old "So, what you have in the box is related to that?"
    new "じゃあ、箱の中身はそれに関連してるの？"

    # say L3331 sis
    old "It is."
    new "そうよ。"

    # say L3332 sis
    old "The place where Barbie's going is a lingerie company."
    new "バービーが行くのはランジェリーカンパニーだよ。"

    # say L3333 sis
    old "So, when I send them the pictures you had given me of Barbie, they thought she looked very good."
    new "だから、私がバービーの写真を送ったら、彼女がとてもいいって思ったんだって。"

    # say L3334 sis
    old "But they said they wanted to see her posing in some lingerie or underwear."
    new "でも、バービーが下着やランジェリーを着てポーズを取ってる写真を見たいって言ったの。"

    # say L3335 sis
    old "And I imagine you don't have a portfolio of pictures of her in lingerie, right?"
    new "そして、彼女の下着姿の写真のポートフォリオを持ってないよね？"

    # say L3337 pla
    old "Uh- n- no, I don't"
    new "うーん、ないな"

    # say L3339 sis
    old "Well, that's why I took the liberty of getting some new lingerie that would fit her. You know, for you to take some pictures."
    new "まあ、だから私が彼女に合う新しいランジェリーを用意したの。あなたが写真を撮るためよ。"

    # say L3340 pla
    old "Oh wow [sis], t- that's awesome!"
    new "おわ、[sis]、それめっちゃすごいな！"

    # say L3341 sis
    old "Well, I think it was the least I could do. You know?"
    new "まあ、これくらいは当然だと思うわ。わかるでしょ？"

    # say L3343 sis
    old "So, take this. And talk to her to take the pictures as soon as you can."
    new "じゃあ、これを取って。そして早めに彼女と話して写真を撮ってもらえたらいいな。"

    # say L3349 pla
    old "Alright, I'll talk to her as soon as I can."
    new "分かった、早々に彼女と話すよ。"

    # say L3351 sis
    old "Alright. I'll be waiting for the pictures then."
    new "分かったわ。写真が届いた次第、待ってるからね。"

    # say L3352 sis
    old "By the way, you haven't forgotten about my 10 percent right?"
    new "それに、私の10パーセントのことは忘れてないよね？"

    # say L3353 pla
    old "No, no, I got you."
    new "大丈夫、忘れてないよ。"

    # say L3354 sis
    old "Alright, I'll see you later then."
    new "じゃあ、後でね。"

    # say L3357 pla
    old "Sure, Bye."
    new "うん、じゃあね。"

    # say L3381 pla
    old "I'm fine."
    new "全然大丈夫だよ。"

    # say L3382 pla
    old "Actually I'm more than fine, I just got some good news."
    new "実はね、全然問題ないだけじゃなくて、良い知らせをもらったんだ。"

    # say L3384 pla
    old "That contact I told you about got you an interview!"
    new "あの連絡先から君の面接のチャンスが来たんだ！"

    # say L3385 pla
    old "And don't worry, this time she ensured me that what happened last time wouldn't happen again."
    new "心配するな、今度は彼女が保証してくれた。前回のようなことは二度とないって。"

    # say L3390 pla
    old "Well, that's the thing, before they interview you. They said they would like to see a couple of pictures of you."
    new "まあ、その前に君の写真を見せてほしいってさ。"

    # say L3393 pla
    old "Yeah, and they really liked them."
    new "そうだ、そして彼らはかなり気に入ったみたいだ。"

    # say L3394 pla
    old "But you see, this new place is a lingerie retailer."
    new "でも、この新しい店は下着専門の小売店なんだ。"

    # say L3396 pla
    old "So they said they'd be interested in seeing how you look in lingerie before you go."
    new "じゃあ、君が着替える前に、下着姿を見てみたいって言ってたらしい。"

    # say L3397 pla
    old "So, my contact got some lingerie for you to try."
    new "俺のコネで君用の下着を用意したんだ。"

    # say L3399 pla
    old "I was thinking that maybe after you're done with your shift you'd like to come with me to my house and you can try it on."
    new "仕事が終わったらうちに来て、試着してみない？"

    # say L3404 pla
    old "Great, then I'll wait until your shift is over and then we can come back to my house."
    new "じゃあ、お前のシフトが終わるまで待つよ。その後、うちに帰ろう。"

    # say L3415 pla
    old "Alright, let's go then."
    new "よし、行こうぜ。"

    # say L3428 pla
    old "Alright, this is the lingerie, why don't you change into it? And we'll do the pictures."
    new "よし、これは下着だ、着替えてくれ？写真撮るから。"

    # say L3440 pla
    old "S- sorry, is not that I don't like it, I was just surprised because of how beautiful you look."
    new "す、すみません、好きじゃないわけじゃなくて、めっちゃ綺麗で驚いちゃった。"

    # say L3441 pla
    old "That lingerie looks very good on you."
    new "その下着、君にとても似合ってるな。"

    # say L3445 pla
    old "What? Of course not!"
    new "何言ってんだよ、もちろんそんなことないさ！"

    # say L3446 pla
    old "You look just perfect!"
    new "君は本当に完璧だよ。"

    # say L3447 pla
    old "You look very beautiful, I mean it."
    new "君は本当に美しいよ、本気で。"

    # say L3450 pla
    old "Why? You don't think the same?"
    new "なんで？君はそう思ってないのか？"

    # say L3454 pla
    old "You know, if you don't feel alright about this we don't have to do it."
    new "知ってる、もし気分が悪いならやめてもいいんだ。"

    # say L3461 pla
    old "Come on, no one's going to think that."
    new "Come on,誰もそんなこと思わないよ。"

    # say L3462 pla
    old "You are one of the most beautiful girls I know  Barbie."
    new "君は私が知っている中最も美しい女の子の一人だよ、Barbie。"

    # say L3463 pla
    old "I'm sure that as soon as they see you they'll want to hire you."
    new "もちろん、君が現れたらすぐに採用したいと思うだろう。"

    # say L3465 pla
    old "Of course I do."
    new "もちろんだよ。"

    # say L3480 pla
    old "Ok, the first picture is just going to be you standing there normally."
    new "じゃあ、最初の写真は普通に立ってるところを撮るからね。"

    # say L3481 pla
    old "So don't move while I take the picture."
    new "写真を撮るから動かないでくれ。"

    # say L3502 pla
    old "Alright, that was good."
    new "よし、それ良かった。"

    # say L3503 pla
    old "So, for the second picture, how about you lay on your right side."
    new "じゃあ、二枚目の写真は右側に横になってみよう。"

    # say L3504 pla
    old "Open your body a little bit, and put your left leg up."
    new "体を開いて、左足を上げてみて。"

    # say L3505 pla
    old "Then rest your left hand on your hip, and lift your torso up a little using your right arm."
    new "左の手を腰に置いて、右腕で上半身を少し支えてみて。"

    # say L3518 pla
    old "That's it, perfect!"
    new "それだ、完璧だ！"

    # say L3540 pla
    old "I do, you look wonderful"
    new "そう、君は素晴らしいね"

    # say L3542 pla
    old "Alright, for the next one."
    new "よし、次はこっちで。"

    # say L3543 pla
    old "How about we show a little bit of how you look from behind?"
    new "後ろから見せてくれどうだ？"

    # say L3545 pla
    old "Great, kneel with your back towards  me."
    new "よし、背中を向けて膝をついてくれ。"

    # say L3546 pla
    old "While you rest your forearms on the bed."
    new "ベッドの上で前腕を支えてね。"

    # say L3547 pla
    old "And turn your head over your right shoulder while you look at me."
    new "そして右肩越しに顔を向けて、俺を見てろ。"

    # say L3559 pla
    old "That's it! Perfect!"
    new "それだ！完璧だ！"

    # say L3560 pla
    old "That's great Barbie!"
    new "バービー、それ最高だ！"

    # say L3562 pla
    old "You look great Barbie!"
    new "バービー、君すごくかわいいよ！"

    # say L3563 pla
    old "{i}(Dang, she really does look amazing.){/i}"
    new "{i}(ほんと、めちゃくちゃかわいいな。){/i}"

    # say L3564 pla
    old "{i}(I can't believe she thought she wouldn't look good using the lingerie.){/i}"
    new "{i}(彼女が下着を着てかわいく見えると思ってなかったなんて、信じられないな。){/i}"

    # say L3591 pla
    old "Alright, I think that's it."
    new "よし、これで終わりだな"

    # say L3592 pla
    old "W- why don't you go change while I put the camera away?"
    new "わ- なぜ着替える时候我不把相机收起来呢？"

    # say L3601 pla
    old "Uhh... w- well, y- you know."
    new "うーん… まあ、分かってるでしょ。"

    # say L3614 pla
    old "W- what are you doing?"
    new "ワッ、何やってんの？"

    # say L3627 pla
    old "Uhh, I- I'm glad you liked it."
    new "うーん、喜んでくれて良かったな。"

    # say L3634 pla
    old "I'll let you know what they say about the pictures, alright?"
    new "写真の感想は教えてあげるからな。"

    # say L3659 pla
    old "Why are you waking me up at this time?"
    new "なぜ今こんな時間に起こすんだ？"

    # say L3661 bri
    old "Well, I have something to tell you."
    new "まあ、あなたに伝えたいことがあるの。"

    # say L3664 bri
    old "Great news! The process of implantation of the magic power within Barbie is complete!"
    new "素晴らしいニュースよ！ バービー体内への魔法力のインプラントが完了したの！"

    # say L3666 bri
    old "So we can now move into the next objective!"
    new "じゃあ、次の目標に進めるわ！"

    # say L3667 pla
    old "Implantation of the magic power? What do you mean?"
    new "魔法力をインプラントって？どういう意味だ？"

    # say L3668 bri
    old "Ugh, I see that you forgot about what we were trying to do here."
    new "うーん、ここでの目的を忘れちゃったみたいね。"

    # say L3669 bri
    old "Did you forget that we're trying to get you to implant magic power into different women."
    new "あなたが魔法力を違う女性たちにインプラントすること、忘れちゃったの？"

    # say L3670 bri
    old "So that they can cultivate the magic power within their bodies?"
    new "そうね、体内で魔力を育てられるようにするの？"

    # say L3671 pla
    old "Hmm... Yeah, right."
    new "うーん… そうか。"

    # say L3673 pla
    old "According to what you told me last time."
    new "前回君が話してくれた通りだよ。"

    # say L3674 pla
    old "Does that mean that she's pregnant now?!"
    new "それって、彼女が妊娠してるってことなのか？！"

    # say L3676 bri
    old "Hmph, I guess that from your point of view that's how it looks."
    new "ふん、そう見えるのは君の目から見た感じよね。"

    # say L3677 bri
    old "But not really."
    new "でも実際はそうじゃないんだ。"

    # say L3679 bri
    old "She'll just look and feel as if she is, but she's not pregnant."
    new "彼女はそう見えてそう感じるかもしれないけど、実際には妊娠してないんだ。"

    # say L3680 bri
    old "So you don't have to worry, when we're done with the spell we'll just collect the power."
    new "心配しないで、呪文が終わったら力を収集するだけだから。"

    # say L3682 bri
    old "And she'll just go back to normal."
    new "そして元に戻るだけよ。"

    # say L3684 pla
    old "When we're done with the spell?!"
    new "呪文が終わった後って？！"

    # say L3686 pla
    old "So until we're not done with it she'll be pregnant?"
    new "それまで彼女は妊娠したままだってこと？"

    # say L3687 pla
    old "That's not okay!"
    new "それは許せない！"

    # say L3688 pla
    old "She just barely got a chance to work."
    new "彼女はようやく仕事のチャンスを得たんだ。"

    # say L3690 pla
    old "And if she's pregnant she won't even be able to work."
    new "そして妊娠したら、働けないだろうな。"

    # say L3691 pla
    old "You'll have to reverse it."
    new "君がそれを元に戻さなきゃならない。"

    # say L3692 bri
    old "Reverse it?! Are you crazy?"
    new "逆にするって？！ あなた、馬鹿じゃないの？"

    # say L3693 bri
    old "With all of the time and magic power that has gone into it?!"
    new "そんな時間と魔力を使ってまで？！"

    # say L3694 bri
    old "How can you even say such a thing?"
    new "どうしてそんなこと言えるの？"

    # say L3695 pla
    old "Because, as I told you! She can't be pregnant!"
    new "だって、言ってんだろ！彼女は妊娠できないんだ！"

    # say L3696 pla
    old "I understand that you want me to hurry up with the ritual."
    new "分かってるよ、君が儀式を急いで欲しがってるってことだろ。"

    # say L3697 pla
    old "And I promise you that if you do it I'll make sure to do what you need me to for the ritual to go well."
    new "そして約束するよ、君がやってくれたら、儀式がうまくいくために必要なことは全部やるから。"

    # say L3699 bri
    old "Ugh, you're so difficult to handle [pla]."
    new "うっ、扱いにくいわね [pla]。"

    # say L3701 bri
    old "Fine, I'll do it."
    new "Fine, I'll do it. → 仕方ないわ、やるから。"

    # say L3702 bri
    old "But I want you to start working on the next target right away!"
    new "でもすぐに次のターゲットの仕事に取りかかってよ！"

    # say L3703 pla
    old "Sure... But just let me finish what I have to do with Barbie."
    new "分かったよ…でも、まずはバービーとのことを終わらせてからだ。"

    # say L3706 pla
    old "I just have to finish a couple of things with her, and I'll get into working in the person."
    new "バービーとのことを済ませてから、すぐ次の人の仕事に取りかかるから。"

    # say L3708 bri
    old "{b}*Sigh*{/b}."
    new "{b}*ため息*{/b}。"

    # say L3709 bri
    old "Alright, but remember what you promised me [pla]."
    new "分かったわ、でも約束したことは覚えておいてね [pla]。"

    # say L3710 pla
    old "Sure, sure..."
    new "分かってる、分かってる..."

    # say L3733 pla
    old "I'm okay, but I imagine that not as well as you will."
    new "大丈夫だけど、君が想像するほどじゃないな。"

    # say L3736 pla
    old "You bet!"
    new "断然！"

    # say L3737 pla
    old "I just got a text from the person who got you the interview for the modeling gig."
    new "俺がモデルの面接を紹介してくれた人からメッセージきたんだ。"

    # say L3738 pla
    old "They said that they loved the pictures, and how you look with the lingerie on!"
    new "彼らは写真が気に入ったってさ、それに下着姿も良かったらしい！"

    # say L3740 pla
    old "They said they wanted to meet with you to discuss hiring you as their model!"
    new "彼らは君と会って、モデルとして雇うことを話し合いたいって言ってたよ！"

    # say L3747 pla
    old "Haha, I'm glad this makes you happy."
    new "ははは、それが君を幸せにしてくれて嬉しいな。"

    # say L3751 pla
    old "Oh no, it isn't."
    new "いや、そうじゃないよ。"

    # say L3752 pla
    old "I've only made a couple of phone calls."
    new "俺はただいくつかのスマホの電話をかけただけだよ。"

    # say L3753 pla
    old "This is because of your effort."
    new "それは君の努力のおかげだよ。"

    # say L3754 pla
    old "Although don't forget you still have to go to the interview."
    new "でも面接に行くこと忘れないでね。"

    # say L3755 pla
    old "But I'm sure everything's going to go well."
    new "でもきっと大丈夫だよ。"

    # say L3771 pla
    old "W- w- what are you doing Barbie?"
    new "バービー、な、なにやってるの？"

    # say L3772 pla
    old "Y- you can't do that here!"
    new "ヤ- ここではそんなことできないだろ！"

    # say L3775 pla
    old "B- but, t- there are cameras!"
    new "でも、ここにカメラがあるよ！"

    # say L3776 pla
    old "O- or someone could walk through here!"
    new "誰かが通り抜けちゃうかもしれないぞ！"

    # say L3787 pla
    old "I can't believe you actually did that!"
    new "信じられない、本当にやっちゃったのか？"

    # say L3792 pla
    old "Well... Whatever."
    new "まあ… いい啦。"

    # say L3793 pla
    old "Don't forget that you have to go to the interview, alright?"
    new "面接に行くことを忘れずに、な？"

    # say L3796 pla
    old "It's alright, no problem."
    new "大丈夫、問題ないよ。"

    # say L3798 pla
    old "I'll see you later so you can tell me how the interview went, alright?"
    new "後で会うから、面接の結果教えてね、いいよね？"

    # say L3819 pla
    old "Hmm, who could it be?"
    new "誰だろうな。"

    # say L3820 pla
    old "I better hurry up and open the door..."
    new "早くドアを開けないと…"

    # say L3826 pla
    old "Oh, hi Barbie, nice to see you here."
    new "お、こんにちはバービー、ここにいてくれて嬉しいな。"

    # say L3829 pla
    old "You did?! That's awesome Barbie!"
    new "やったのか！それはすごいな、Barbie！"

    # say L3830 pla
    old "So I take it the interview went well, right?"
    new "じゃあ面接は上手くいったってことだね。"

    # say L3834 pla
    old "That's great, hey, let's come to my room."
    new "それは良かったな、じゃあ部屋に行こうか。"

    # say L3835 pla
    old "That way you can tell me everything."
    new "そうすれば全部話すんだね。"

    # say L3851 pla
    old "That's so awesome Barbie, congrats!"
    new "それはすごいね、バービー、おめでとう！"

    # say L3885 pla
    old "Well, I'm glad you're happy."
    new "まあ、君が幸せなら俺も嬉しいよ。"

    # say L3888 pla
    old "You're still going to work?"
    new "まだ働くんのか？"

    # say L3901 bri
    old "Alright! I hear all of that!"
    new "わかった！全部聞こえたわ！"

    # say L3902 bri
    old "She's happy, and you accomplished what you wanted."
    new "彼女は幸せだし、あなたが欲しかったことも達成できたよね。"

    # say L3903 bri
    old "That means we can get to my thing now, right?"
    new "それって、今から私の番ってことよね？"

    # say L3917 mo1
    old "[pla], wake up!"
    new "[pla]、起きて！"

    # say L3923 pla
    old "[mo1]? What's happening?"
    new "[mo1]？何が起こってるの？"

    # say L3924 mo1
    old "Well, you see, Barbie's in the livingroom, she's waiting there to talk to you."
    new "まあ、ね、バービーがリビングにいるのよ、あなたと話したいみたいだから。"

    # say L3925 pla
    old "Ohh, sure, I'll be downstairs in a minute."
    new "わかった、すぐ下りるよ。"

    # say L3926 mo1
    old "Ok, by the way. she's pregnant..."
    new "そういえば、彼女は妊娠してるのだけど..."

    # say L3927 mo1
    old "Do you know anything about that?"
    new "それについて何か知ってる？"

    # say L3928 pla
    old "Me? No, nothing! I don't know what this is about..."
    new "俺？何も知らないよ！これについて何のことだかさっぱりだ。"

    # say L3929 pla
    old "But I'll go down and talk to her."
    new "でも俺が行って話すね。"

    # say L3930 mo1
    old "Okay honey."
    new "大丈夫よ、ハニー。"

    # say L3936 pla
    old "B- Barbie! H- hi!"
    new "バービー！　あ、こんにちは！"

    # say L3937 pla
    old "W- what's happening?"
    new "何が起こってるんだ？"

    # say L3945 pla
    old "I- I... W- what's this?"
    new "俺、これ…何？"

    # say L3946 pla
    old "Y- you're pregnant!"
    new "お前、妊娠してんの！"

    # say L3954 pla
    old "H- hey, don't worry, we'll figure something out."
    new "大丈夫、心配しなくていい、何か方法を見つけるさ。"

    # say L3958 pla
    old "I know, I know."
    new "分かってる、分かってる。"

    # say L3959 pla
    old "But I'm sure everything will be fine."
    new "でも大丈夫だよ、きっとすべてうまくいくさ。"

    # say L3960 pla
    old "And I can promise you that I'll be here for you, no matter what. Alright?"
    new "大丈夫、どんなことがあっても君の側にいるよ。ね？"

    # say L3962 pla
    old "Let's just wait for now, and give ourselves time to think about this."
    new "今は待って、このことをよく考えてみよう。"

    # say L3969 pla
    old "Of course, I understand."
    new "もちろん、理解してる。"

    # say L3971 pla
    old "But before we make any decision let's just make sure that you check with a doctor to see how you're doing."
    new "でも、決める前にまずは医者に診てもらって、あなたの体調を確認した方がいいよ。"

    # say L3972 pla
    old "You know, you're physical state."
    new "君の体調のことさ。"

    # say L3974 pla
    old "You know, just to make sure everything's fine with you."
    new "まあ、君の体調がちゃんと良いか確認するためさ。"

    # say L3978 pla
    old "I think it is."
    new "俺もそう思うよ。"

    # say L3979 pla
    old "I know a lot is going through your head right now."
    new "今君の頭の中には色々なことが渦巻いているってこと、俺も知ってるよ。"

    # say L3980 pla
    old "But precisely because of that, I think we shouldn't rush into anything."
    new "でも、だからこそ、急いで何かをするべきじゃないと思う。"

    # say L3986 pla
    old "That's a great idea."
    new "それは良いアイデアだね。"

    # say L3987 pla
    old "And keep me informed if you can, I'd like to know how you're doing."
    new "状況を教えてくれたら幸いだ、君のことが気になるからな。"

    # say L3990 pla
    old "Hey, I'm happy to help you."
    new "Hey、手伝うよって。"

    # say L4002 bri
    old "Hey [pla], why the long face?"
    new "Hey [pla]、どうしたの？そんなに深刻な顔して。"

    # say L4003 pla
    old "You ask why?!"
    new "なんでって？！"

    # say L4004 pla
    old "Barbie just came here, she's pregnant!"
    new "バービーが来たんだ、妊娠してるってさ！"

    # say L4005 pla
    old "I thought you had stopped the spell!"
    new "俺は呪文を止めたと思ったんだがな。"

    # say L4006 bri
    old "Well, I did stop it."
    new "まあ、止めたんだけど。"

    # say L4007 bri
    old "But the magic cultivation process had already started."
    new "でも、魔力の培養プロセスはすでに始まっていたの。"

    # say L4008 bri
    old "You should know by now that when it comes to magic, nothing is ever as simple as 'canceling' a spell."
    new "魔法って、一旦始まっちゃったら簡単にキャンセルできるもんじゃないって、もう知ってるでしょ。"

    # say L4009 bri
    old "It's not like flipping a switch."
    new "魔法ってスイッチを切るみたいに簡単じゃないの。"

    # say L4011 bri
    old "The magic power is already in cultivation inside of her."
    new "魔法の力はすでに彼女の体内で培養されているの。"

    # say L4012 bri
    old "Or in human words, she's already pregnant."
    new "人間の言葉で言えば、彼女はもう妊娠しているってこと。"

    # say L4014 bri
    old "Besides, the magic spell to direct the magic you implanted in her."
    new "それに、あなたが彼女に植え込んだ魔力を制御する魔法とは別のことよ。"

    # say L4015 bri
    old "And said magic developing within her are two different things."
    new "そして、その魔法が彼女の中で発展していくのは別の話よ。"

    # say L4017 pla
    old "Then what's the point of even canceling the spell?"
    new "じゃあ、呪文を解いても意味ないじゃん？"

    # say L4019 pla
    old "If she's still going to go through with it. We might as well have let her go through with it."
    new "もし彼女がそれでも続けるなら、最初から放っておけばよかったじゃん。"

    # say L4021 bri
    old "I wasn't finished!"
    new "まだ終わってないわ！"

    # say L4023 bri
    old "If what you're describing was the case, I wouldn't have done anything."
    new "もしあなたが言っている通りなら、私は何もしなかったわ。"

    # say L4024 bri
    old "Yes, she's still condensing magic within her."
    new "はい、彼女はまだ魔法を凝縮しているわ。"

    # say L4026 bri
    old "But that doesn't mean that there's nothing we can do."
    new "でもそれって何もできないって意味じゃないの。"

    # say L4028 bri
    old "Listen, even though this appears to be a normal human pregnancy, you must keep in mind that magic's involved."
    new "ねえ、これは普通の人間の妊娠に見えるけど、魔法が関わっていることを忘れないで。"

    # say L4029 bri
    old "I can't just make her pregnancy go away. But I can make it go a lot faster than it normally would."
    new "私は彼女の妊娠を消すことはできないけど、通常よりもずっと早く進めることが可能よ。"

    # say L4031 pla
    old "W- what? So she'll have a baby soon?!"
    new "え、そうなのか？ つまりすぐに出産ってこと？！"

    # say L4032 bri
    old "Hmph, no, she won't."
    new "ふん、彼女はそうならないわ。"

    # say L4033 pla
    old "Uhh... Alright? I'm a little confused."
    new "うーん… 分かった？ ちょっと困惑してるんだけど。"

    # say L4034 bri
    old "Well... Magic adheres to the natural laws of your world..."
    new "まあ……魔法はあなたの世界の自然法則に従っているから……"

    # say L4035 bri
    old "And that's why, even though it may seem 'pregnant,' what it's actually gestating is magical power..."
    new "だから、魔法の力が『妊娠』したように見えるけど、実際は魔法の力を育ててるんだよ…"

    # say L4037 pla
    old "Ok, so there is not baby?"
    new "じゃあ、実際には赤ちゃんはいないってこと？"

    # say L4038 bri
    old "Well, technically, a baby could be born from this process since it's all magical power..."
    new "まあ、技術的にはこの過程から赤ちゃんが生まれることもあるかもしれないね、全部魔法の力によるものだから…"

    # say L4039 bri
    old "However, that would only happen if we decide that a portion of the magical power she's gestating materializes and develops."
    new "しかし、その魔法の力が胎内に具現化し、発達することを私たちは決めることになるわ。"

    # say L4040 bri
    old "That way, a portion of the magical power would adapt to the woman's womb..."
    new "その方法なら、魔力の一部が女性の子宮に適応して..."

    # say L4041 bri
    old "And, powered by the condensing magical energy, it would develop like a human baby."
    new "そして、凝縮された魔力エネルギーによって、それは人間の赤ちゃんのように発育していくわ。"

    # say L4042 bri
    old "So by the time the magic is fully cultivated they both come out of the body together."
    new "魔法が完全に育つ頃には、二人とも一緒に体から出てきます。"

    # say L4044 bri
    old "But in this case things are going to be very different."
    new "でも今回は全然違うの。"

    # say L4045 bri
    old "Since it's going to be a lot faster than normal, only the magic will develop inside of her."
    new "それだから、普通よりずっと早く、彼女の体内で魔法だけが成長するの。"

    # say L4046 bri
    old "So by the time she gives birth only the magic will be coming out of her."
    new "だから彼女が産む頃には、魔法だけが出ることになるの。"

    # say L4047 pla
    old "Ok, ok... I think I understand."
    new "分かった、分かった… 大体理解したよ。"

    # say L4049 pla
    old "But wait! What's going to happen when she goes to the doctor? Won't they realize there's something weird going on?"
    new "でも待て！彼女が医者にかかるときどうなるんだ？何か変なことに気づかれないか？"

    # say L4050 bri
    old "I can see why you would think that."
    new "そうね、その心配はわかるわ。"

    # say L4052 bri
    old "But in human terms, she's still pregnant, even if it's just with magic."
    new "でも人間の目には、彼女はまだ妊娠しているように見えるわ。魔法の赤ちゃんでも同じよ。"

    # say L4054 bri
    old "When she goes to get checked with doctors and such, everything will appear to be normal."
    new "病院で診察を受けたりすると、すべて普通に見えるはずよ。"

    # say L4056 bri
    old "So everything should be ok."
    new "じゃあ、すべて大丈夫ってことね。"

    # say L4058 pla
    old "Alright, that's good to hear."
    new "そうだな、それは聞いて安心したよ。"

    # say L4060 pla
    old "So everything should be okay from here on out, right?"
    new "じゃあ、これからは大丈夫だよな？"

    # say L4062 bri
    old "Hmm, not entirely."
    new "うーん、完全じゃないな。"

    # say L4063 pla
    old "R- really?"
    new "ほんと？"

    # say L4064 pla
    old "Is there something else?"
    new "他に何かあるのか？"

    # say L4066 bri
    old "Well, what we're doing with this spell is trying to condense the magic energy needed to power up the portal to the magic world."
    new "私たちがこの呪文でやろうとしているのは、魔法世界へのゲートを稼働させるための魔法エネルギーを凝縮することよ。"

    # say L4067 bri
    old "And we're doing it by condensing magic within the bodies of women."
    new "そして、その魔法を女性の体内で凝縮しているのさ。"

    # say L4068 pla
    old "Yeah, I get that."
    new "うん、分かったよ。"

    # say L4070 bri
    old "Well, the thing is that these women aren't natural magic wielders."
    new "問題は、これらの女性が自然の魔法使いではないということよ。"

    # say L4071 bri
    old "Their bodies aren't able to condense magic at the same rate that the spell demands it."
    new "彼女たちの身体は、呪文が要求する速度で魔力を凝縮できないの。"

    # say L4073 bri
    old "They would need your help with providing the magic they can't procure for themselves."
    new "彼女たちにはあなたの手助けが必要で、自分たちで得られない魔力を提供してあげて。"

    # say L4075 bri
    old "So, under normal circumstances, Barbie would need you to help her by giving her magic."
    new "だから、普通の状況なら、バービーはあなたに魔法を分けてもらう必要があるの。"

    # say L4076 bri
    old "But since this pregnancy will be so short, I don't think she'll need you to give her any condensed magic power."
    new "でもこの妊娠はそんなに短いから、凝縮した魔力をあなたに与えてもらう必要はないと思うの。"

    # say L4078 pla
    old "How would that work? The giving her magic part?"
    new "どうやってやるんだ？ 魔力を渡すって部分がさ。"

    # say L4080 bri
    old "Oh, you know full well how that works, the same way you do it for me."
    new "あなたが私にするのと同じように彼女にも与えるのよ。"

    # say L4081 pla
    old "I- I see..."
    new "分かったけど..."

    # say L4083 bri
    old "But as I explained to you, given her particular conditions I can't be sure about what's about to happen with her."
    new "でも私が説明した通り、彼女の特別な状況を考えると、これから何が起こるか確実には言えないの。"

    # say L4084 bri
    old "So just be sure to be vigilant about what can happen to her. Just to make that she's fine."
    new "だから彼女の状態をよく観察して、大丈夫かどうか確認してね。"

    # say L4086 pla
    old "I understand, alright, I'll be sure to do that."
    new "わかった、大丈夫、注意するよ。"

    # say L4087 pla
    old "But thanks anyway Brixxida, this gives me some peace of mind."
    new "でもありがとう、ブリクシダ。これで少し心が落ち着いたよ。"

    # say L4088 bri
    old "Well, I'm just letting you know what happened."
    new "ただ、起こったことを伝えるだけよ。"

    # say L4090 bri
    old "But don't forget that now you have to keep going with our plans."
    new "でもね、これからは私たちの計画を進めていくことになるんだよ。"

    # say L4091 bri
    old "I'm letting you off the hook with this one, but be sure to keep searching the next specimen."
    new "今回は見逃してあげるけど、次の標本を探すのは忘れずにね。"

    # say L4092 pla
    old "Yeah, alright."
    new "分かった、分かった。"

    # say L4122 pla
    old "Oh, Barbie, hi!"
    new "オッ、バービー、こんにちは！"

    # say L4125 pla
    old "Hi, how are you?"
    new "おっ、元気？"

    # say L4126 pla
    old "Is everything alright?"
    new "大丈夫ですか？"

    # say L4132 pla
    old "Uhmm... Are you alright?"
    new "うーん……大丈夫か？"

    # say L4134 pla
    old "Did you go to the doctor? Is everything okay?"
    new "先生に診てもらったか？ 大丈夫なのか？"

    # say L4137 pla
    old "Are you sure?"
    new "本当に大丈夫なのか？"

    # say L4141 pla
    old "Uhm... Sure, I don't see why not."
    new "うーん…問題ないけど。"

    # say L4142 pla
    old "Let's go to my bedroom and we'll talk there."
    new "寝室に行こう、そこで話すよ。"

    # say L4148 pla
    old "Alright, do you want to tell me what's going on?"
    new "よし、何があったんだ？"

    # say L4149 pla
    old "Because I can tell that something's not right."
    new "何かがおかしいってわかるからさ。"

    # say L4158 pla
    old "So what's the problem?"
    new "何が問題なんだ？"

    # say L4162 pla
    old "Fatigue? Like you're tired?"
    new "疲れてる？ 疲れってるってこと？"

    # say L4168 pla
    old "How do you know that?"
    new "どうしてそう思うんだ？"

    # say L4177 pla
    old "Hot?"
    new "熱い？"

    # say L4181 pla
    old "Oh! I- I see."
    new "オッ！そうか。"

    # say L4187 bri
    old "This is it [pla]! This is what I told you about!"
    new "これだよ [pla]！これが私が話していたことなんだよ！"

    # say L4188 bri
    old "This fatigue she's talking about is her body manifesting its need for magic."
    new "この疲労感は、彼女の体が魔法を必要としていることを表しているの。"

    # say L4189 bri
    old "And the feeling of being {i}'horny'{/i} is her body telling her what she has to do to solve it."
    new "そして、{i}‘horny’{/i}な感じは、彼女の体がそれを解消するためになにをすればいいか教えてるの。"

    # say L4190 bri
    old "I wasn't expecting it to go this way, since the spell was canceled and everything."
    new "この流れになるとは思わなかった、呪文が解除されたんだから。"

    # say L4191 bri
    old "But what you have to do now is have sex with her so that she can feed off your magic!"
    new "でも、今あなたがしなきゃならないのは、彼女とセックスして彼女があなたの魔法を吸収できるようにすることよ！"

    # say L4195 pla
    old "W- what? N- no, of course not."
    new "ワッ、何言ってんの？もちろん無理だ。"

    # say L4197 pla
    old "Why would I think that there's anything weird about it?"
    new "何が変だって思うんだ？"

    # say L4199 pla
    old "I think that's very normal."
    new "俺もそう思うな。"

    # say L4200 pla
    old "After all, you're pregnant, I think it's pretty normal that you would have those feelings."
    new "結局、お前は妊娠してるんだ、そんな気持ちになるのは全然普通だと思うけど。"

    # say L4203 pla
    old "What's wrong?"
    new "何が不对の？"

    # say L4213 pla
    old "Ohh, come on, what are you talking about?"
    new "おっ、何言ってんだよ？"

    # say L4215 pla
    old "Yeah, it's true that you don't look like you usually do."
    new "そうだよ、普段と違うのは事実だけど。"

    # say L4216 pla
    old "But that doesn't mean you look bad in any way."
    new "でも、それが全然悪くないってことだよ。"

    # say L4218 pla
    old "I mean, you look just as sexy as you always have."
    new "お前はいつもsexyなままだよ。"

    # say L4221 pla
    old "Of course I would!"
    new "もちろんそう思うぜ！"

    # say L4222 pla
    old "I'm surprised that you even feel like you'd have to ask me."
    new "君がそんな風に聞く必要があるなんて、意外だな。"

    # say L4223 pla
    old "You look just as beautiful as you always have."
    new "君はいつもと変わらず美しいよ。"

    # say L4224 pla
    old "And I'll be more than happy to help you feel better."
    new "もちろん、君が元気になれるように手伝うぜ。"

    # say L4229 pla
    old "Come on, don't say that."
    new "Come on, don't say that. → さあ、そんなこと言わないで。"

    # say L4230 pla
    old "You're just as beautiful as always."
    new "君はいつもの通り美しいよ。"

    # say L4231 pla
    old "Let me show you."
    new "見せてやるよ。"

    # say L4257 pla
    old "I'm glad to be able to help you."
    new "君のために手伝えて嬉しいよ。"

    # say L4258 pla
    old "After all, you didn't get into this situation by yourself."
    new "結局、君は一人でこの状況に陥ったわけじゃないからな。"

    # say L4259 pla
    old "I figure this is the least that I can do."
    new "これくらいは最低限のことでしょ。"

    # say L4260 pla
    old "I'm glad it actually works."
    new "実際役立つんだ、嬉しい。"

    # say L4267 pla
    old "Sure, I'll be seeing you later."
    new "じゃあ、後でな。"

    # say L4274 bri
    old "Well done [pla]!"
    new "よくやった [pla]！"

    # say L4275 bri
    old "With what you just did I'm sure that she'll be alright."
    new "あの子、大丈夫になるわ。心配しなくていい、きっと充分よ。"

    # say L4277 pla
    old "Hmm, I guess that if she's going to be alright with just that, then that's fine."
    new "うん、それだけで大丈夫なら問題ないな。"

    # say L4278 bri
    old "She will be. Don't worry, I'm sure that that's more than enough."
    new "大丈夫よ、きっと十分すぎるわ。"

    # say L4279 bri
    old "Which is great, because now you  can focus on what's next."
    new "それがいいわ、今你可以专注于接下来的事情了。"

    # say L4281 pla
    old "However, this time I'll choose. We were lucky this time, but really 'impregnating' someone is not easy at all..."
    new "でも、今回は俺が選ぶよ。運が良かっただけで、本当に「妊娠させる」のは簡単じゃないんだ…"

    # say L4283 bri
    old "Alright... But you can't take too long; we need to keep incubating more magical power for the portal..."
    new "分かった… でも時間が長くなると駄目よ、もっと魔力を温存しないと…"

    # say L4285 bri
    old "Anyway, I'm gonna rest, I spend too much magic power with Barbie..."
    new "まあ、私は休むわ、バービーに魔力を消費しすぎちゃったから…"

    # say L4286 pla
    old "Ok, see you later."
    new "分かった、また後でな。"


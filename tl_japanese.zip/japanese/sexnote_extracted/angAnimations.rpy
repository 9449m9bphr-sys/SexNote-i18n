# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/angAnimations.rpy
translate japanese strings:

    # say L51 joh
    old "Are you enjoying it, honey?"
    new "ハニー、楽しんでるの？"

    # say L52 ang
    old "Mmm, yes, this one is giving me a pretty warm and wet sensation."
    new "うん、そうね、この感じはとても温かくて濡れているわ。"

    # say L53 joh
    old "Okay, you're doing a great job, now try to do it a little faster."
    new "よろしい、よくできています、もう少し速くしてみてください。"

    # say L59 joh
    old "Oh yeah, just like that honey, don't stop, you are gonna make him cum soon..."
    new "ああ、そう、その調子で続けて、止めて欲しくないわ、もうすぐイかせちゃうわ…"

    # say L61 ang
    old "Slurp, slurp."
    new "す、すすってるだけよ…"

    # say L84 joh
    old "Ok, you've had enough, you can cum now [pla]."
    new "はい、十分でしょう。今すぐイっていいですよ [pla]。"

    # say L85 ang
    old "W- what?"
    new "えっ、なに？"

    # say L86 pla
    old "Ughhh..."
    new "うっ..."

    # say L90 ang
    old "Huh, what is this?"
    new "え、これ何？"

    # say L95 ang
    old "WHAT THE FUCK!"
    new "何てことだよ！"

    # say L96 ang
    old "WHO THE HELL ARE YOU?!!"
    new "誰だか見せろ！！"

    # say L110 joh
    old "Ok [pla], I need you to show her your tricky fingers..."
    new "Ok [pla]、君の器用な指を見せてあげて…"

    # say L111 joh
    old "More speed and a bit of more pressure, she needs to enjoy more, to get hornier."
    new "もっと速く、そして少し強くして、彼女がもっと楽しんで、もっと興奮するように。"

    # say L113 ang
    old "Uhh... It f- feels nice..."
    new "うっ… 感じてる…"

    # say L114 joh
    old "Yes, just like that, [pla]."
    new "はい、その調子で、[pla]。"

    # say L118 joh
    old "[pla], I want you to be tough now, press them hardly, feel them, touch them all."
    new "[pla]、今度は強く押して、感じて、全部触ってください。"

    # say L119 pla
    old "Ok."
    new "分かった。"

    # say L120 joh
    old "Do you like it Angelina?"
    new "アンジェリーナ、気に入っていますか？"

    # say L121 ang
    old "... Y- yes."
    new "はい...好きです。"

    # say L145 joh
    old "Perfect, now that we feel a bit more confident with each other let's move to the other exercise, in this case in the practice bedroom."
    new "パーフェクト、お互いに少し自信が持てたところで、次は練習用の寝室で別のエクササイズをやってみよう。"

    # say L158 joh
    old "Do you like it?"
    new "好きですか？"

    # say L159 ang
    old "Yes, it feels a bit... Nice."
    new "はい、少し……いい感じです。"

    # say L160 joh
    old "You needed a better trained person to start enjoying it, let's make it more interesting, [pla], I want you to do it faster."
    new "君が楽しむためにはもっと上手な人が必要だったね、面白くするために[pla]、もっと速くしてほしいんだ。"

    # say L162 joh
    old "How do you feel now?"
    new "今どう感じてる？"

    # say L163 ang
    old "Ahh! I- I am... Starting to feel... n- nice."
    new "アッ！あ、あたし… 感じ始めて… いい感じになってきちゃう…"

    # say L167 joh
    old "Ok, [pla], I want you to make her cum, do your thing!"
    new "じゃあ、[pla]、君のテクニックを発揮して、彼女をイかせてください。"

    # say L168 ang
    old "Ohhh...  Don't stop, ahh! Nngh!"
    new "オーッ… 止めてないで、あっ！ンん！"

    # say L191 ang
    old "Oh God! OH GOD! I feel like I'm going to... EXPLODE!"
    new "神様！神様！破裂しそう！"

    # say L196 joh
    old "Wonderful!"
    new "素晴らしいですね！"

    # say L197 ang
    old "Oh God... I had never felt this before..."
    new "神様…こんな感じは初めてです…"

    # say L209 joh
    old "So, what do you feel Angelina?"
    new "それじゃ、どんな感じがしますか、エンジェリナ？"

    # say L210 ang
    old "Hmm, It's really hard and tasteful."
    new "ん〜、本当に硬くて美味しくて。"

    # say L211 joh
    old "That's perfect, how are you feeling, [pla]?"
    new "その通りだ、[pla]、君の感じ方は？"

    # say L213 ang
    old "Hmm... Slurp, slurp."
    new "Hmm... すりゅ、すりゅ。"

    # say L214 joh
    old "Right, that's the best answer. Just enjoy it guys."
    new "そうだね、それが最良の答えだ。ただ楽しんでくれればいいさ。"

    # say L218 joh
    old "You think you can hold on a bit more [pla]?"
    new "君、もう少し我慢できるかな [pla]？"

    # say L220 joh
    old "Perfect, now Angelina, I want you to give him all you have, I want you to make him cum."
    new "パーフェクト、それじゃアンジェリナ、君のすべてを彼に与えて、絶対にイかせてくれ。"

    # say L221 ang
    old "Mmm, ok."
    new "うん、わかった。"

    # say L245 joh
    old "Don't stop now, he is almost done, he will cum any time, so, keep moving your head."
    new "止めてはいけない、もうすぐ終わる、すぐにイッてしまうから、頭を動かし続けてください。"

    # say L246 ang
    old "Slurp, slurp...!"
    new "すすりゅ、すすりゅ…！"

    # say L247 pla
    old "Ahh!"
    new "ああっ！"

    # say L253 ang
    old "Wow, that's a lot of cum, I think I did it."
    new "すごい量の精液、私はできたと思います。"

    # say L254 joh
    old "You did amazing!"
    new "素晴らしいですね！"

    # say L265 joh
    old "[pla], since Angelina is not so experienced I need you to be as gentle as you can be, she can't do it like me, so pease start softly."
    new "[pla]、アンジェリナは経験が浅いので、できるだけ優しくしてあげてください。彼女は私みたいにはできないから、まずはゆっくりと始めてあげて。"

    # say L266 pla
    old "Sure, I'll try my best."
    new "分かった、精一杯やるよ。"

    # say L270 ang
    old "Mmm it hurts a bit... But it also feels good..."
    new "んん、少し痛いけど…でも気持ちいい…"

    # say L271 joh
    old "Told you. [pla] please, speed it up a bit, I want you to make her scream a bit, you already know how to do it."
    new "言いましたよね。[pla] ちょっと速くして、彼女をもっと悲鳴を上げさせるように、あなたなら方法を知っているでしょう。"

    # say L276 joh
    old "Are you satisfied Angelina?"
    new "満足したかい、エンジェリナ？"

    # say L277 ang
    old "Ohhh... Yess..."
    new "オーッ…うん…"

    # say L278 joh
    old "And we've got even more to go, so [pla], give her more!"
    new "そしてまだたくさんあるんだから、[pla]、もっと与えてあげなさい！"

    # say L279 pla
    old "Got it."
    new "わかった。"

    # say L281 ang
    old "HOLLY SHIT! AHHH!"
    new "ホーリー・シャイツ！アッ！"

    # say L304 joh
    old "Don't stop, she's about to cum!"
    new "止めてはいけません、もうすぐイキそうです！"

    # say L305 ang
    old "NNGH!"
    new "ンッ！"

    # say L306 joh
    old "[pla], finish with her!"
    new "[pla]、最後まで続けて！"

    # say L307 ang
    old "I feel like an explosion inside just like the other day, I- I... AHH!"
    new "中で爆発してるみたい、あの日と同じで、あ、あ……アッ！"

    # say L321 joh
    old "That's impressive, you are doing it really really good, do you like it [pla]?"
    new "それはすごいですね、あなたは本当に上手ですね、[pla]さん、好きですか？"

    # say L322 pla
    old "Absolutely!"
    new "絶対だ！"

    # say L323 pla
    old "(She's getting really good at it.)"
    new "彼女、上手くなってきたな。"

    # say L325 joh
    old "I'm glad to see you feel more confident with your partner."
    new "あなたがパートナーとより自信を持って接しているのが嬉しいです。"

    # say L328 joh
    old "That's great, don't stop, remember is your husband pleasure what we are talking about."
    new "それは素晴らしいですね、やめないで、夫の快感が重要ですよ。"

    # say L331 joh
    old "Now suck it faster, show me those blowjob skills."
    new "早く吸って、そのフェラテクを見せてください。"

    # say L333 pla
    old "Woow!"
    new "Woow！ すごい、もっと速くして、君が彼をイかせたいんでしょ？"

    # say L337 joh
    old "Wow, I can see it's getting closer, do it faster, you want him to cum, don't you?"
    new "Wow、もうすぐイキそうですね、もっと速くして、彼がイきたいんでしょ？"

    # say L338 ang
    old "Yes!"
    new "はい！"

    # say L339 joh
    old "So, do it as fast as you can... make him cum in your throat!"
    new "それなら、できるだけ早く……喉でイかせて。"

    # say L363 pla
    old "Ahh yes! Take it."
    new "アッ、そう！受け入れて。"

    # say L370 joh
    old "Wonderful, did you like it Angelina?"
    new "素晴らしい、アンジェリナ、気に入ったかい？"

    # say L372 joh
    old "That's my girl."
    new "それが私の娘のやつだね。"

    # say L383 joh
    old "Oh yeah, ride him Angelina, jump on him and fuck him."
    new "オーよ、アンジェリナ、彼の上に乗って、跳ねて、セックスして。"

    # say L384 ang
    old "I didn't know riding was so intense, this is definitely the position I like the most."
    new "乗るってこんなに激しいとは思わなかった、これが一番好きな体位だな。"

    # say L385 pla
    old "(Oh wow, she moves really good, I like it.)"
    new "おわ、動きがいいな、気に入ったよ。"

    # say L388 ang
    old "Oh God! I don't want to stop, we should do this for a week..."
    new "神様！やめたくない、一週間くらい続けてほしいな..."

    # say L389 pla
    old "I like it too."
    new "俺も好きだよ。"

    # say L390 joh
    old "Fuck him Angelina, fuck [pla] hard!"
    new "アンジェリナ、[pla] を犯しなさい、強く犯しなさい！"

    # say L392 ang
    old "Ahhh..."
    new "アッ…"

    # say L396 ang
    old "Ahhh... Your dick is so hard that I want to hit it faster."
    new "アーッ…あなたのチ○ポ、硬くて早く打ちたくなるの。"

    # say L397 joh
    old "Fuck him harder, just as you want!"
    new "もっと激しくして、君が欲するように！"

    # say L422 ang
    old "Ahh! This is really delicious, I don't want to stop."
    new "アッ！これ、本当に美味しそう、止まらないよ。"

    # say L423 ang
    old "I really love this, I want to feel you cuming."
    new "この感じが本当に好き、あなたの中に出してほしいわ。"

    # say L424 pla
    old "I- I can't hold it anymore."
    new "俺、もう我慢できないよ。"

    # say L430 ang
    old "Mmm, I- I want more... May I have another round?"
    new "んん、もっと欲しい… もう一回させてくれない？"

    # say L431 joh
    old "Wow girl, you're insatiable... Well, if [pla] says she can go on, that's fine with me, we still have time."
    new "おお、おわせ-girl、君は欲張りだね… まあ、[pla]が続けられるって言うなら、構わないよ、まだ時間はあるから。"

    # say L432 pla
    old "Uhh... Yes, I guess..."
    new "うーん… そうだな、いいけど…"

    # say L433 ang
    old "Ok, now you fuck me, I want you to make me cum again."
    new "はい、それじゃああなたが私を犯して、またイかせてくれなさい。"

    # say L434 pla
    old "A- Alright..."
    new "あー、分かったよ…"

    # say L452 ang
    old "Oh yes, just like that. I have to say my husband is not as big as you."
    new "ああ、そうよ。私の夫はあなたほど大きくないわ。"

    # say L453 ang
    old "Your huge cock makes me feel so much more!"
    new "あなたの大きなちんこが、私をこんなに感じさせてくれるの！"

    # say L457 ang
    old "Mmmm, it feels really nice, but I want more!"
    new "んん、感じがいいけど、もっと欲しいの！"

    # say L458 ang
    old "Give me more of your cock. I want you to fuck me harder!"
    new "もっとあなたのちんこをちょうだい。強くファックしてほしいの！"

    # say L461 ang
    old "Uhhhh... Holly Shit! This is soo good."
    new "うーん… ホーリー・シット！これ、めっちゃいい！"

    # say L464 ang
    old "Don't stop baby, keep fucking me hard!"
    new "止めてないで、もっと強く突いて！"

    # say L465 ang
    old "I want you to make me cum! Please [pla], make cum!"
    new "イかせてほしいの！お願い、[pla]、イかせて！"

    # say L467 ang
    old "Ahhh! Ahhh! Oh my God!"
    new "アーッ！アーッ！神様！"

    # say L490 pla
    old "(Uhh... Doctor Johnson has been a bit quiet, that's weird)"
    new "うーん……ドクター・ジョンソンが妙に静かだな"

    # say L497 ang
    old "Yes! Yes! I- I cumming again! Ahhh!"
    new "はい！はい！あたし、またイッちゃう！あーっ！"

    # say L501 ang
    old "Mmmm, it was so good."
    new "うーん、すごく良かったわ。"

    # say L502 joh
    old "Great job guys, I can tell you that the sessions have been very efficient..."
    new "皆さん、素晴らしい仕事をしましたね、セッションが非常に効果的だと分かります..."

    # say L503 joh
    old "Angelina as you can see you will be very happy with your husband!"
    new "Angelina、君が見るように、きっとご主人様ととても幸せになれるわね！"

    # say L515 ang
    old "Mmm... Oh God, this feeling..."
    new "んん… ああ、この感じ…"

    # say L516 ang
    old "And the size of your cock!"
    new "そしてあなたのペニスの大きさ！"

    # say L517 ang
    old "It brings so much back!"
    new "これだけの思い出が蘇るのね！"

    # say L521 ang
    old "I haven't felt this way in forever!"
    new "こんな気分になったの、ずいぶん久しぶりだよ。"

    # say L522 ang
    old "I've missed feeling this way!"
    new "この気分を味わうのは随分と久々だわ。"

    # say L523 ang
    old "Slrrp! It's been so long!"
    new "スルルッ！ こんなに久々だったわ！"

    # say L527 ang
    old "This is nothing like my husband!"
    new "これって私の夫とは全然違うの！"

    # say L528 ang
    old "I love how good it tastes!"
    new "この味が大好き！"

    # say L529 ang
    old "Oh it makes me feel so good!"
    new "ああ、気持ちいい！"

    # say L552 pla
    old "Angelina! I-I can't hold it in anymore!"
    new "アンジェリナ！俺、もう我慢できないよ！"

    # say L553 ang
    old "Oh yes! I want you to let it out!"
    new "ああ、そう！ 出してほしいの！"

    # say L554 ang
    old "Let me taste it!"
    new "味わわせて！"

    # say L562 ang
    old "Mmm that felt so good."
    new "うん、それすごく感じたわ。"

    # say L563 ang
    old "It was amazing."
    new "それはすごいだった。"

    # say L564 pla
    old "Uh, yeah, I guess so."
    new "うん、まあそうだろう。"

    # say L565 pla
    old "But hey, let’s get up and clean this up before Lisa walks in and sees us."
    new "でもさ、起きて片付けよう。リサが入ってきて見ちゃう前にね。"

    # say L566 ang
    old "Sure, sure."
    new "うん、そうそう。"

    # say L574 pla
    old "How are you feeling Angelina?"
    new "アンジェリーナ、調子はどう？"

    # say L575 ang
    old "Great! That was fantastic! I want more!"
    new "グレート！それ最高だったわ！もっと欲しい！"

    # say L576 pla
    old "Hmm, yeah sure."
    new "うん、そうだな。"

    # say L582 ang
    old "Mmm! Oh yes!"
    new "んん！ああ、そう！"

    # say L583 ang
    old "Oh God! this feels amazing!"
    new "ああ神！これ、最高だよ！"

    # say L584 ang
    old "Oh [pla], this is just what I wanted!"
    new "ああ、[pla]、これが欲しかったの！"

    # say L596 ang
    old "Oh God [pla] I love it!"
    new "神様、[pla]、これ大好き！"

    # say L597 ang
    old "This is so good!"
    new "これ、最高だよ！"

    # say L601 ang
    old "My God [pla], I love the way you're doing it!"
    new "神様っ [pla]、あなたがしてる感じが大好き！"

    # say L602 ang
    old "This is amazing [pla]!"
    new "これ、最高だよ！ [pla]！"

    # say L606 ang
    old "Oh yes! Ah! AH!"
    new "ああ、そう！あっ！アッ！"

    # say L630 ang
    old "Oh [pla]!"
    new "ああ、[pla]！"

    # say L638 pla
    old "How do you feel?"
    new "どう感じてる？"

    # say L639 ang
    old "I feel amazing [pla]!"
    new "感じがすごいわ [pla]！"

    # say L640 ang
    old "That's the best sex I've ever had!"
    new "これが今までで一番のセックスだったわ！"

    # say L641 pla
    old "Heh, that's good to hear."
    new "へへ、そう言ってくれて嬉しいな。"

    # say L651 ang
    old "Great! That was fantastic! I want more, please!"
    new "すごい！ それ、最高だった！ もっと欲しいな、お願い！"

    # say L652 pla
    old "Yeah, that’s what I thought..."
    new "そう思ったな…"

    # say L671 ang
    old "Ohhh, yeah... it feels so deep..."
    new "オッ、そう……奥が気持ちいい……"

    # say L672 ang
    old "Mmm, this is the best!"
    new "うん、これが最高だね…"

    # say L676 ang
    old "Oh God, oh God! It's amazing."
    new "ああ、神様、ああ、神様！　すっごいよ。"

    # say L677 ang
    old "It feels so good..."
    new "感じがいい..."

    # say L680 ang
    old "Ohh fuck, yes, yes, faster, faster [pla]..."
    new "あぁ、くそ、そう、そう、もっと速く、もっと速く [pla]..."

    # say L682 ang
    old "Mmm, that's right, don't stop [pla], don't stop!"
    new "んん、そう、止まらないで [pla]、止まらないで！"

    # say L706 ang
    old "Oh my God! Yes, yes!"
    new "おおっ、そうだ、そうだ！"

    # say L707 ang
    old "[pla], I'm about to cum, don't stop, give me more, give me more!"
    new "[pla]、もうすぐイクから、止まらないで、もっとやって、もっと！"

    # say L711 ang
    old "Ohhh that was amazing... Oh my God."
    new "あぁ、それって最高だった… よかったわ。"

    # say L712 ang
    old "[pla], you really have no idea how wonderful that was."
    new "[pla]、あなたはどれだけそれが素晴らしいものだったか、本当に知らないのね。"

    # say L713 pla
    old "You're feeling better now, right?"
    new "調子は良くなったよね？"

    # say L714 ang
    old "Ohh, you have no idea."
    new "ああ、あなたにはわからないね。"

    # say L715 pla
    old "I'm glad, but, let’s get up and clean this up before Lisa walks in and sees us."
    new "良かったけど、起き上がってこれ片付けないと、リサが入ってきて見ちゃうぞ。"


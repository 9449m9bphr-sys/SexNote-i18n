# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/ayeAnimations.rpy
translate japanese strings:

    # say L6 aye
    old "My god this dick is so big!"
    new "このチ○ポ、マジでデカいな！"

    # say L7 aye
    old "I noticed it the last time!"
    new "前回も気づいたぞ！"

    # say L8 aye
    old "But having it in my mouth is just something else!"
    new "でも、これを口に入れるのはまた別物だよ！"

    # say L12 aye
    old "I bet you've never gotten head like this before right?"
    new "お前はこんなフェラチオ初めてだな？"

    # say L13 aye
    old "I know I'm so much better than my sister!"
    new "俺のテクニックは姉ちゃんのよりずっと上だろ！"

    # say L14 aye
    old "I'm sure there's no comparison!"
    new "比べ物にならないぜ！"

    # say L18 aye
    old "Is this good [pla]?!"
    new "これいいっすか [pla]？！"

    # say L19 pla
    old "Y- yeah, it is!"
    new "Ｙ－ああ、そうなんだ！"

    # say L20 aye
    old "Slrrp! Mmm!"
    new "スルルッ！ んん！"

    # say L21 aye
    old "Of course it is! I'm so much better than Olivia!"
    new "もちろんだよ！オリアンナよりずっと上手いぞ！"

    # say L44 aye
    old "I- I can feel like you're about to finish!"
    new "あー、もうすぐイきそうって感じがする！"

    # say L45 pla
    old "Y- yeah! I am!"
    new "Ｙ－ｙｅａｈ！　そうだ！"

    # say L46 aye
    old "Do it! I want to get your cum in my mouth!"
    new "やって！俺の口の中に精液出したいんだ！"

    # say L53 aye
    old "Look at how much you came!"
    new "見て、どれだけ出たんだ！"

    # say L54 aye
    old "You see? I told you I was way better than Olivia!"
    new "見てみろ？　オレがオリビアよりずっと上手だって言ったでしょ？"

    # say L55 aye
    old "I bet you've never had anything like that before!"
    new "俺がこんなことさせてあげるのは初めてだろ？"

    # say L56 pla
    old "Yeah, yeah..."
    new "うんうん"

    # say L57 pla
    old "Listen, get up before your mother or your sister come here and see us like this."
    new "おい、起きなよ。母さんや妹に見られる前にさっさと立って。"

    # say L58 aye
    old "Ugh, you're such a prude."
    new "うっせー、お前こそマジで堅苦しいな。"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/LadStory.rpy
translate japanese strings:

    # say L11 mo1
    old "Good morning honey."
    new "おはようございます、亲爱的。"

    # say L12 pla
    old "Oh! good morning [mo1rel]."
    new "お！おはよう [mo1rel]。"

    # say L13 mo1
    old "Did you have a good night?"
    new "よく眠れましたか？"

    # say L14 pla
    old "Yeah, I did. And you?"
    new "うん、良かったよ。君は？"

    # say L16 mo1
    old "I did hun, thank you."
    new "うん、良かったわ、ありがとう。"

    # say L17 pla
    old "Is there anything I can help you with [mo1rel]?"
    new "何か手伝えることがありますか [mo1rel]？"

    # say L18 mo1
    old "Well, not really. I just wanted to see if you're doing anything with your friends for halloween."
    new "まあ、特にないけど。ハロウィンの日に友達と何か予定があるのかなって見に来たの。"

    # say L20 pla
    old "Oh that's right! It's today! I'd totally forgotten about it."
    new "ああそういえば！今日だよ！すっかり忘れてた。"

    # say L21 pla
    old "That reminds me, I need to pick up my costume."
    new "そうだ、Costumeを取りに行くんだ。"

    # say L23 mo1
    old "Are you going to school in a costume?"
    new "コスチュームを着て学校に行くの？"

    # say L24 pla
    old "Yeah, me and my friends are dressing up for Halloween."
    new "ああ、俺と友達がハロウィン用に仮装するんだ。"

    # say L25 mo1
    old "Really? Why? Are you having a party?"
    new "ほんとうに？ なぜなの？ パーティーでもするの？"

    # say L26 pla
    old "No, no, nothing special like that. It's just that the school principal said all students get to wear costumes today."
    new "いや、特別なわけじゃないよ。学校の校長先生が今日だけ全員にコスチュームを着ていいって言ったんだ。"

    # say L27 mo1
    old "Seriously? That's cool."
    new "本気？それはいいね。"

    # say L28 pla
    old "Yeah, it's nice we get to do this once in a while. Everyone's excited about it."
    new "そうだな、たまにはこんなことしてもいいよね。みんな楽しみにしてるみたいだ。"

    # say L29 mo1
    old "Well [pla], that sounds like a lot of fun. I'm happy you get to do that with your friends."
    new "まあ [pla]、それは楽しそうね。友達とそんな風に過ごせるのは嬉しいわ。"

    # say L30 mo1
    old "After all, this is your last Halloween at school, where you still get to dress up, so make sure to enjoy it."
    new "そうですね、学校での最後のハロウィンだし、まだ仮装できるチャンスだから、楽しんでくださいね。"

    # say L31 pla
    old "Yeah, I'll do. We're competing about who has the worst costume."
    new "うん、やるよ。俺たちは誰が一番最悪な衣装か競争してるんだ。"

    # say L32 mo1
    old "And do you have one already?"
    new "もう決まってるの？"

    # say L33 pla
    old "Yeah, I asked Kylee to get one for me. I should ask her if it's already arrived. Bye [mo1rel], see you later."
    new "うん、ケイリーに用意してもらったんだ。届いたかどうか聞いてみよう。じゃあ、[mo1rel]、後でね。"

    # say L34 mo1
    old "Bye honey, have a good day."
    new "バイバイ、いい一日を。"

    # say L52 pla
    old "Hi [sis], good morning."
    new "おはよう、[sis]。"

    # say L53 sis
    old "Hi [pla], good morning. How are you?"
    new "こんにちは、[pla]、おはようございます。元気ですか？"

    # say L54 pla
    old "I'm fine. Hey, I just remembered I asked you to get my costume for Halloween. Did it arrive?"
    new "俺は元気だよ。Hey、思い出したけど、ハロウィン用のコスチュームを頼んでたんだ。届いた？"

    # say L55 sis
    old "Yeah, it did. It came in with the last shipment of clothing for the store."
    new "うん、届いたよ。店の服の最後の荷物と一緒に来たんだ。"

    # say L57 pla
    old "Great! Where is it?"
    new "良かった！どこにあるの？"

    # say L59 sis
    old "Hmm... I haven't unpacked anything yet, so it must be in one of the boxes."
    new "うーん……まだ何も開けてないから、箱の中に入ってるはずだよ。"

    # say L60 sis
    old "Just wait here a minute. I'll go get it for you."
    new "ちょっと待ってて、すぐ取ってくるから。"

    # say L72 sis
    old "Here you go."
    new "ここだよ。"

    # say L75 pla
    old "This is great! Thanks [sis]."
    new "これ最高だな！ありがとう、[sis]。"

    # say L76 sis
    old "Well, you go try it on and let me know if it fits you, and you like it."
    new "じゃあ、试着してみて、フィット感と気に入ったかどうか教えてね。"

    # say L77 pla
    old "Of course, by the way, how much do I owe you?"
    new "もちろん、それと、どれくらい支払うべきか？"

    # say L78 sis
    old "Oh, don't worry about it..."
    new "気にしなくていいの、大丈夫だからね…"

    # say L79 sis
    old "It's on the house."
    new "無料でいいわよ。"

    # say L80 pla
    old "Oh really? Well... Thank you [sis]."
    new "ほんと？じゃあ…ありがとう、[sis]。"

    # say L82 sis
    old "Now leave, I have a lot of work to do."
    new "じゃあ、行って。仕事があるから。"

    # say L83 pla
    old "Ok, I'll go try on the costume then. See you later [sis], thanks again."
    new "分かった、じゃあコスチュームを試着するか。またね[sis]、ありがとう。"

    # say L84 sis
    old "You're welcome and enjoy it."
    new "どういたわって、楽しんでね。"

    # say L102 pla
    old "Wow! This is so cool! [sis] has some really good products."
    new "Wow！ これは最高だな！[sis] の商品は本当に良いな。"

    # say L103 pla
    old "I think I'll definitely blow their minds with this."
    new "これで絶対にみんなの頭から離れなくなるぜ。"

    # say L104 pla
    old "Now I'm ready for Halloween!"
    new "これからハロウィンに向けて準備万端だな！"

    # say L127 pla
    old "Hey guys, what 's up?"
    new "Hey guys, what's up？ → おい、みんな、元気か？"

    # say L129 bel
    old "Whooa [pla]! What a costume!"
    new "ワォ [pla]！その衣装、すごいね！"

    # say L130 pla
    old "Cool, isn't it?"
    new "クールだな"

    # say L131 bel
    old "It looks very good."
    new "いいね、すごく似合ってるよ。"

    # say L132 mik
    old "Yeah dude, really cool."
    new "そうだぜ、本当にクールだぜ。"

    # say L134 mik
    old "But to be honest, not as cool as mine."
    new "でも正直に言うと、俺のはもっとかっこいいよ。"

    # say L135 bel
    old "Really? And why is that?"
    new "ほんと？ なぜそう思うの？"

    # say L136 mik
    old "Because I'm Iron Man, I mean... Come on!"
    new "だって俺はアイアンマンだもん、つまり… 来てみろ！"

    # say L137 mik
    old "I'm the super rich, genius, chick magnet! No way Spiderman beats that."
    new "俺は超金持ちで、天才で、女にモテるんだ！スパイダーマンなんて太刀打ちできないよ。"

    # say L139 pla
    old "It actually is a cool Iron Man costume... Even the goatee."
    new "それはかっこいいアイアンマンのコスチュームだな… ひげまで再現してるとは。"

    # say L141 bel
    old "Hmph, I guess."
    new "ふん、そうかな。"

    # say L143 mik
    old "And you Belle? Are you like a type of rabbit?"
    new "お前はベッキー？ウサギの種類なのか？"

    # say L144 bel
    old "Not a type of rabbit. I'm a bunny, the coolest one, Lola Bunny!"
    new "うーん、ウサギの種類じゃないの。私はバニー、一番 coolest のバニー、ローラ・バニー！"

    # say L145 pla
    old "Ohh right. I get it now."
    new "オッ、そうか。分かったぜ。"

    # say L146 pla
    old "Cool costume, it looks really good on you."
    new "カッコいい衣装だな、君に似合ってるよ。"

    # say L160 rub
    old "Oh my, Olivia, would you look at that? The loser club in their dumb costumes. Aren't they childish?"
    new "あら、オリビア、見てみて？ 捏造クラブのバカな衣装。子供っぽくない？"

    # say L161 oli
    old "Yeah, always acting like little kids. Dumb, poor kids."
    new "そうだね、いつも子供みたいにしてるわ。バカな貧乏な子供たち。"

    # say L162 bel
    old "Don't you two airheads have anything better to do this early in the morning?"
    new "二人とも、朝から何やってんの？もっといいことないの？"

    # say L163 rub
    old "Better than showing you just how much of a dumbass you are? Don't think so."
    new "君がどれだけバカなのか見せつけるよりマシだよ？　そうは思わないけど。"

    # say L164 rub
    old "By the way, are you supposed to be Lola Bunny?"
    new "それにしても、ローラ・バニーって呼ばれていいの？"

    # say L165 bel
    old "Y-yeah, I am. Why?"
    new "はい、そうよ。どうして？"

    # say L166 rub
    old "Dear, you should realize that with those ears, and that pig nose of yours, you're much more of a Piglet."
    new "亲爱的、ああいう耳と豚の鼻じゃ、あなたはむしろピグレットに見えるわよ。"

    # say L167 pla
    old "Hey! Don't you think that's too much?"
    new "おい！それってちょっと過剰じゃない？"

    # say L168 mik
    old "That's right. Shut up!"
    new "そうだよ、黙ってろ！"

    # say L169 rub
    old "Wow Olivia, look who's defending Piglet! Spiderman the scrawny loser, and Iron fat."
    new "オリビア、見て見て、ピグレットを守ってるじゃない！スパイダーマンは細マッチョの負け組で、アイアンマンは太りすぎだよ。"

    # say L170 oli
    old "What's funny is that they're opposites. One is too slim to fill his Spiderman pajamas, and the other's too fat to fit into the costume."
    new "面白いのは、二人が正反対だってこと。一人はスパイダーマンのパジャマが似合わないくらい細くて、もう一人はアイアンマンのコスチュームに入りきれないくらい太ってるの。"

    # say L171 rub
    old "Hey Iron Man, don't you think it's ridiculous that your belly's rounder than your chest?"
    new "アイアンマン、君の腹って胸より丸くない？"

    # say L172 oli
    old "Maybe we should call him barrel man."
    new "Maybe バーレルマンって呼ぼうか。"

    # say L179 hin
    old "Hey guys! What's up? It's everything ok?"
    new "Hey guys！ What's up？ みんな、元気？大丈夫？"

    # say L183 oli
    old "Ohh wow. What a costume..."
    new "オッほー、なんて衣装だ…"

    # say L184 rub
    old "My god! And what the hell are you wearing? You look like a WHORE."
    new "神様！一体何を着てるの？まるでホステスのようじゃない？"

    # say L185 oli
    old "The stupid cow came dressed up like a bat-whore."
    new "あのバカ牛がバットのホステスの格好をしてきたわ。"

    # say L187 hin
    old "Hey! It's not a whore costume. I'm Morrigan from Darkstalkers. And for your information this took a lot of time to make..."
    new "Hey！これはホステスの衣装じゃないよ。私はダークスタalkersのモリガンだよ。それに、これを作るのにすごく時間がかかったんだから…"

    # say L188 rub
    old "Ughh nerd... I don't care..."
    new "うっgh ナerd... 全然興味ないわ..."

    # say L189 rub
    old "I am only surprised that the shy moron I see here every day would bring such a revealing costume."
    new "毎日見る内気なバカが、こんな露出の多い衣装を持ってくることにただ驚いただけよ。"

    # say L190 oli
    old "Which by the way, it's disgusting."
    new "それにしても、汚らわしいね。"

    # say L191 rub
    old "I mean, you couldn't wear ANYTHING more revealing! My god! You should be ashamed!"
    new "君のその格好、もっと露出の高いものなんてありえないよ！神様！恥ずかしくないの？"

    # say L192 hin
    old "W- what are you talking about? Your costume has also a cleavage..."
    new "何言ってるの？あなたの衣装だって谷間見えちゃってるよ…"

    # say L193 rub
    old "WHAT? YOU'VE GOTTA BE KIDDING ME!"
    new "何それ？冗談じゃない！"

    # say L194 rub
    old "We have decent classy costumes, there's nothing wrong with ours."
    new "私たちの衣装は品格があって、何が問題なのかしら？"

    # say L195 rub
    old "In case you haven't noticed, Olivia and I are Disney princesses..."
    new "気づいてないの？オリビアと私はディズニープリンセスの格好をしてるんだよ..."

    # say L196 rub
    old "While you just came in a stupid costume from some nerd stuff."
    new "君が着てるのなんてただの変なコスチューム、オタクのものから来たやつじゃない。"

    # say L197 hin
    old "Well, I don't care, because I really have something to show and I feel comfortable with my body, unlike you two stupid bitches..."
    new "まあ、私は気にしないわ。だって私には見せたいものがあるんだもん。自分の身体に自信があるから、あなたたちみたいな馬鹿な女とは全然違うわよ…"

    # say L198 rub
    old "W- what did you just say to me?! Olivia! Did you hear that?!!"
    new "W- 何てこと言うのよ！オリビア！聞こえたでしょ？！！"

    # say L199 oli
    old "I did Ruby! How dare you talk to us like that? You bat-whore!"
    new "ルビー！どうして私たちをそんな風に扱うの？バットのホウレツ！"

    # say L200 hin
    old "Shut up you two! You envious bitches!"
    new "黙って！あなたたち、嫉妬深いクソ女たち！"

    # say L201 bel
    old "Ohhhh! What's the matter, girls? You can dish it, but you can't take it?"
    new "オーッ！どうしたの、女の子たち？言えることが取れないの？"

    # say L202 pla
    old "H-Hey, Hinn, maybe it's best if we just leave, look, classes are about to start..."
    new "おい、ヒン、さ、もう行こうぜ、授業始まっちゃうし…"

    # say L203 hin
    old "And why do we have to be the ones to leave?! These idiots are the ones who started."
    new "なぜ私たちが去らなきゃならないのよ！？ このバカたちが先に始めたんだから。"

    # say L204 hin
    old "You two better get out here! I've had enough of your bullshit!"
    new "お前たちさっさと出ていけ！もう貴方たちの馬鹿げたことにはウンザリよ！"

    # say L205 rub
    old "Ughh. We're leaving! But it's not because you tell us to, you little whore! I just don't want to keep wasting my time with you, dumbasses."
    new "うっ。行くわよ！でも、君たちが命令したからじゃないわ、ちっさいクソ女！ただ、私の時間を君たちの無駄な会話に費やすのが嫌になっただけよ、バカども。"

    # say L206 rub
    old "Let 's go Olivia."
    new "行こう、オリビア。"

    # say L220 bel
    old "Wow! Hinn, what's happened to you? That was sooo awesome!"
    new "Wow！ Hinn、あなたどうしたの？それがすっごく良かったよ！"

    # say L221 hin
    old "Hehe, you think so?"
    new "へへ、そう思うの？"

    # say L222 bel
    old "Hell yeah! I don't know what you've been doing, but you're so confident now. Just look at how you put those airheads in their place!"
    new "へぇ、本当にそうかな？でも、今のは自信に満ちてたね。さっきの空っぽな連中をちゃんと𠮟りつけてさ！"

    # say L223 hin
    old "And... What do you think [pla]?"
    new "そして… どう思う [pla]？"

    # say L224 pla
    old "I agree with Belle, you were totally awesome Hinn!"
    new "ベールの言う通りだ、君は完全にカッコよかったよ、ヒン！"

    # say L225 hin
    old "Well, it's a relief to hear you guys say that... For a moment there I thought you may have thought ill of me."
    new "皆がそう言ってくれて安心した……一瞬、私に冷たい目で見られているんじゃないかと思ったの。"

    # say L227 pla
    old "Aww, we wouldn't. And hey, for what it's worth, I think your costume is great."
    new "あわ、そんなことないよ。それに君の衣装、かっこいいと思うぞ。"

    # say L228 bel
    old "Yeah Hinn, you look gorgeous, and I'm happy you're finally showing some skin, it was about time!"
    new "ヒン、 gorgeous って言葉はちょっと恥ずかしいけど、本当にかわいいよ。肌見せも勇気出して良かったじゃない、そろそろ見せてもいいと思ってたの。"

    # say L229 hin
    old "Sigh, stop it with that."
    new "ため息、その調子言わないでよ。"

    # say L230 mik
    old "Yeah Hinn, it really, really suits you."
    new "ヒン、本当に似合ってるよ。"

    # say L231 mik
    old "And hey, I support you sharing your natural gifts with us. It's a really nice view."
    new "そして、お前の自然の才能を俺たちと分かち合ってくれるのは応援してるよ。ほんと、いい眺めだ。"

    # say L233 bel
    old "Oh my gosh Mike, couldn't you be a little decent at least once?"
    new "マイク、せめて一度はまともなこと言えないの？"

    # say L234 mik
    old "What? What did I say? I was giving Hinn a compliment!"
    new "何？何を言ったって？ヒンに褒め言葉を言ってただけだよ！"

    # say L235 bel
    old "Yeah right, sure you were..."
    new "うん、そうよね、よく言ったわ..."

    # say L236 bel
    old "Anyway, we better get going. It's almost time for class."
    new "でも、授業が始まる時間差不多だよ。"

    # say L237 mik
    old "Huh? But we still have some time."
    new "へ？　でもまだ時間あるよ。"

    # say L239 bel
    old "I know, but you know Ms. Mia has her eyes on you because you keep skipping. So, let's go, come on!"
    new "知ってるけど、ミア先生が君のことをずっと見張ってるって知ってるでしょ。さっさと行こう、さあ！"

    # say L250 hin
    old "W- was that true [pla]?"
    new "W- それは本当だったの [pla]？"

    # say L253 hin
    old "What you said about my costume, do you really like it?"
    new "あなたが言った私の衣装のこと、ほんとうに気に入ってくれてるの？"

    # say L254 pla
    old "Of course! I like it a lot."
    new "もちろん！君のコスチューム、とても気に入ってるよ。"

    # say L255 pla
    old "And to be honest... I think you're the only student who could pull it off."
    new "そして正直に言うと… 君が一番その衣装を着こなせると思うよ。"

    # say L256 hin
    old "Huh? You mean it?"
    new "へ？本気？"

    # say L257 pla
    old "Yeah! Nobody else could wear that costume that well."
    new "そうだよ！他の誰もそんなコスチュームを着こなせないよ。"

    # say L260 hin
    old "Come with me for a moment [pla]..."
    new "ちょっと来てみろ [pla]..."

    # say L262 pla
    old "Uhh, where are we going?"
    new "うーん、どこに行ってるんだ？"

    # say L263 hin
    old "Just come."
    new "ちょっと来てね。"

    # say L285 pla
    old "Hmm, Hinn, this is the girl's bathroom, I don't think it's ok for me to go in."
    new "ヒン、これは女子トイレだよ、俺が入るのはよくないと思うんだ。"

    # say L286 pla
    old "Maybe it's better if I wait outside."
    new "外で待った方がいいかもな。"

    # say L288 pla
    old "For you to use the bathroom..."
    new "君がトイレを使うために…"

    # say L289 hin
    old "Hahahaha. Don't be silly, I didn't bring you here for that."
    new "ははははは。バカ言わないで、あなたをここに連れてきたのはそんな理由じゃないよ。"

    # say L290 pla
    old "Uhh, you didn't? Then why?"
    new "うーん、そうじゃないの？じゃあ、何のために連れてきたの？"

    # say L292 hin
    old "You see, working with you and Dr. Johnson has really helped me get over my shyness, that's how I was able to stand up to those bullies."
    new "あなたとDr. Johnsonと一緒に仕事をして、ずいぶん恥ずかしがり屋を克服できたの。だから、あのいじめっ子たちにも立ち向かえたのよ。"

    # say L293 hin
    old "So, I thought maybe we could have a little session now. Besides, I want to thank you."
    new "そう、だから今ちょっとセッションできたらいいなと思って。それに、あなたに感謝したいの。"

    # say L294 pla
    old "B- but here? What if someone sees us?"
    new "でもここじゃ？ 誰かに見られたらどうするんだ？"

    # say L295 hin
    old "Ohh, don't worry, I'm sure it's gonna be fine, classes are about to start, so there's nobody around."
    new "大丈夫よ、きっと大丈夫。授業が始まる直前だから、誰もいないわ。"

    # say L296 pla
    old "Well, if you say so... I guess it's ok then."
    new "まあ、君がそう言うなら……大丈夫だろうな。"

    # say L297 hin
    old "Yes, I'm sure nobody will see us."
    new "うん、誰も見つける心配ないわ。"

    # say L298 hin
    old "Come here, pull down your pants."
    new "ここへ来て、ズボンを下ろして。"

    # say L305 hin
    old "It's always amazing how big you are [pla]."
    new "いつもこんなに大きいのは驚くわ [pla]。"

    # say L306 pla
    old "I can believe we're doing it in the bathroom."
    new "信じられないな、トイレでこんなことしてるんだ。"

    # say L308 hin
    old "I'm happy you're this hard because of me."
    new "あなたが私のためにこんなに固くなってくれて、嬉しいわ。"

    # say L317 hin
    old "Look, it's almost time for class."
    new "見ろ、もう授業始まる時間だよ。"

    # say L318 hin
    old "I'll go ahead. Don't be late."
    new "先にいくから、遅れないでね。"

    # say L327 pla
    old "Wow! I don't know what that was, but I sure like this new Hinn."
    new "Wow！ 何だったか知らないけど、この新しいヒンは好きだな。"

    # say L340 pla
    old "Ohh! Wow, Billie! What are you doing here?"
    new "オッホ！Wow、ビリー！ここにいるなんて思わなかったよ。"

    # say L342 bil
    old "Hey! What's up? I just transferred here. Today's my first day."
    new "へー！どうしたの？転校してきたの。今日が初めての日なの。"

    # say L343 pla
    old "Ahh, I see. That's cool, what school did you transfer from?"
    new "ああ、そうか。どの学校から転校してきたんだ？"

    # say L344 bil
    old "From nowhere actually. All my life I've been home schooled, and that's fine, I guess. But you see, this is my last year..."
    new "実際にはどこからも転校してきたわけじゃないの。ずっと家で勉強してきて、それはそれで良かったんだけど、でもね、これが最後の年だから..."

    # say L345 bil
    old "So, I wanted to have the school experience at least for senior year."
    new "だから、高校生活だけでも最後の1年間体験したかったの。"

    # say L346 pla
    old "Well, I think that's a great idea! I'm glad you get to live that at least once. And hey, welcome."
    new "まあ、それは素晴らしいアイデアだな！君がその経験を一度はできるのは嬉しいよ。それに、ようこそ。"

    # say L348 bil
    old "It was a coincidence that my first day was Halloween. So, I had to come in costume. What do you think?"
    new "私の初日がハロウィンだったのは偶然だったの。だから、コスチュームで来なきゃならなかったの。どう思う？"

    # say L349 pla
    old "I think it's great, it's really good. You look just like the real Harley Quinn."
    new "君がハーレイ・クインそのものだな、最高だよ。"

    # say L350 bil
    old "Thanks, and hey, I think you also make for a very good Spiderman."
    new "ありがとう、それにね、君もすごくいいスパイダーマンだよ。"

    # say L352 pla
    old "Thanks!"
    new "ありがとう！"

    # say L353 bil
    old "By the way. Why were you leaving the girls bathroom?"
    new "それにしても、女の子のトイレから出てきたのはなぜ？"

    # say L354 pla
    old "Ohh! Hmm, no reason."
    new "オッ！まあ、特に理由はないな。"

    # say L355 pla
    old "I guess, I- I just got confused."
    new "まあ、俺-俺ちょっと混乱してしまっただけだよ。"

    # say L357 bil
    old "Uhh... Sure..."
    new "うーん…そうですね…"

    # say L358 pla
    old "We better get going, the class has already started."
    new "行こう、授業はすでに始まっている。"

    # say L364 mia
    old "Ok guys, let's start today's lesson. Now who can tell me where we left it last time?"
    new "皆さん、今日の授業を始めましょう。では、前回どこまでやったか覚えている人はいますか？"

    # say L379 pla
    old "Sorry ma'am! We came as quickly as we could."
    new "すみません先生！できるだけ早く来たんです。"

    # say L380 mia
    old "Ugh! It's always the same with you [pla]! Would it kill you to act like a good student at least once?"
    new "うーん！いつも同じことよね [pla]！せめて一度くらいまじめな生徒になってくれないの？"

    # say L381 pla
    old "I- I'm sorry Ms. Mia, it won't happen again, it's just that I met my friend in the hallway."
    new "すみません、ミア先生。またこんなことならないようにします、ただ廊下で友達に会ってちょっと遅れちゃっただけです。"

    # say L382 mia
    old "Yeah right! Always excuses with you. Anyway, go sit down!"
    new "そうですか！いつも言い訳ばかり dear. とにかく、席について！"

    # say L389 mia
    old "Ok guys, before we begin, I have to introduce you to a new student."
    new "皆さん、始める前に新しい生徒を紹介させてください。"

    # say L393 mia
    old "This is Billie, she's going to be accompanying us during this last year. Be sure to be nice to her."
    new "これはビリーです、彼女は今年の残りの期間私たちと一緒に過ごします。みんな優しくしてあげてね。"

    # say L394 bil
    old "Hi."
    new "こんにちは、みなさん。"

    # say L396 mia
    old "Take seat Billie, there's a spot for you there."
    new "ビリー、座って。そこに空いてるところがあるわ。"

    # say L401 mia
    old "Ok guys, as I was saying before being so rudely interrupted by [pla].  Who can tell me what we were talking about last class?"
    new "皆さん、先ほど [pla] に乱暴に中断されましたが、話を続けましょう。誰か、前回の授業で何を話していたか覚えてる？"

    # say L409 mia
    old "Ok, that's it for today, don't forget to read up on the textbook before next class. It's better if you prepare your classes ahead."
    new "では、今日の授業はこれで終わりです。次回の授業まで教科書を予習しておいてくださいね。事前に準備しておくと良いですよ。"

    # say L423 bel
    old "Ok everybody, classes are over, and we have time. Why don't we go ask for some candy?"
    new "みんな、授業は終わったし、時間もあるわ。キャンディを貰いに行かない？"

    # say L424 bil
    old "Ugh, candy? Are you serious? Don't you think we're a little too old for that?"
    new "うーん、キャンディ？ 本気？ そんなのもう私たちにはちょっと大人っぽすぎると思わない？"

    # say L425 bel
    old "Ohh, come on! This is our last year, so we won't be able to do it anymore."
    new "ほら、今年が最後の年だから、これ以上はできないのよ。"

    # say L426 mik
    old "Yeah! Billie, trick or treating is super cool, we'll have a great time."
    new "そうだよ！ビリー、トリックオアトリートは超楽しいんだ、めっちゃ楽しい時間になるぞ。"

    # say L427 bil
    old "I don't think walking around, knocking on front doors is a ‘great time.'"
    new "前門をノックして回るなんて、めっちゃ楽しい時間とは思えないわ。"

    # say L428 bil
    old "But whatever, if you all want to."
    new "でも、みんながやりたいならいいかな。"

    # say L430 pla
    old "I actually want too, it's a good way to spend the afternoon."
    new "俺も行きたいな、午後の過ごし方としては悪くないと思うよ。"

    # say L431 pla
    old "Besides, we get to use the costumes some more."
    new "それに、コスチュームもまた使えるし。"

    # say L432 pla
    old "And what do you think Hinn?"
    new "そして、ヒンはなんて思う？"

    # say L433 hin
    old "I think it's a nice idea. I wanna hang out some more."
    new "いいアイデアだと思うわ。もっと一緒にいたいし。"

    # say L434 hin
    old "And to be honest I also don't want to get out of my costume just yet."
    new "正直、まだこの衣装から出たくないんだよね。"

    # say L435 bil
    old "Oh my god, you guys are so lame."
    new "おっけー、あなたたちホントにダサいね。"

    # say L436 bil
    old "But fine, fine, if you want to do it, I'll do it too. This better be good."
    new "でもいいよ、いいよ、やるなら私もやる。これはちゃんと良いものでないとね。"

    # say L453 mik
    old "That was so awesome! I can't believe they gave us this much candy at our age."
    new "それがすげえな！この年でこんなにキャンディをくれるとは思わなかったぜ。"

    # say L454 pla
    old "Definitely, a real success I'd say."
    new "確かに、大成功だったな。"

    # say L455 bel
    old "You see? It was totally worth it. I knew it was gonna be this much fun. Right Billie?"
    new "見ただろ？ 完全に価値があったよ。私がこれだけ楽しいって分かってたもん。ねえ、ビリー？"

    # say L456 bil
    old "Yeah... I guess. It wasn't so bad after all."
    new "うん……そうかな。結局、悪くなかったわ。"

    # say L457 hin
    old "It's still early, we could keep going if you want to."
    new "まだ早いよ、続けたいなら続けてもいいけど。"

    # say L458 mik
    old "Nah, I don't think so. This is nice and all, but my feet hurt, I'm a little tired of carrying this heavy custume."
    new "Nah、別にいいや。これも悪くないけど、足が痛くて、この重い衣装をずっと持っているのには疲れたんだ。"

    # say L459 pla
    old "Come on man, don't ruin the mood, you're the one who wanted to ask for candy in the first place."
    new "おい、そんなにムードを壊すなよ。最初からキャンディーをもらうために来たのはお前だぞ。"

    # say L460 bel
    old "Actually [pla], it annoys me to say this, but I think Mike may be right. We've been going for a while now, we should rest."
    new "実際 [pla]、言うのが面倒くさいんだけど、マイクの言う通りかもしれない。ずいぶん歩いたし、休憩した方がいいわ。"

    # say L461 bil
    old "Well, if that's the case, we should go to the beach then, it's very nearby and we could sit and rest there."
    new "じゃあ、そうならビーチに行こうよ。すぐ近くだし、そこで休めるし。"

    # say L462 pla
    old "Hmm, and what do you think, Hinn? Do you want to keep going?"
    new "Hmm、ヒン、どう思う？続けたいか？"

    # say L463 hin
    old "Ohh, I'm fine. I only said it because I thought everyone else wanted to do it too, but if everyone it's ok with stopping here I'd agree."
    new "あたしは大丈夫よ。ただ、みんながやりたいと思ってると思ったから言ったの。でも、ここで止めるのがいいってみんなが思ってるなら、あたしも賛成よ。"

    # say L464 bel
    old "That settles it then, let's go to the beach."
    new "それじゃあ、ビーチに行こう。"

    # say L478 pla
    old "Well, this is nice. I thought there were going to be people here."
    new "まあ、これはいいな。誰かがいるかと思ったんだけど。"

    # say L479 hin
    old "Yeah, it's good that it is so quiet, this is a good place to rest."
    new "うん、静かでいいわ、ここで休めるのが良いのね。"

    # say L480 bel
    old "We should find a place to sit down."
    new "座る場所を見つけるよ。"

    # say L481 hin
    old "Can't we just sit here?"
    new "ここに座っても良いじゃない？"

    # say L482 bel
    old "I think we could sit a little bit closer to the sea."
    new "海にちょっと近いところに座ったほうがいいと思う。"

    # say L483 bil
    old "Let's just go to that spot over there"
    new "あの場所に行こうよ。"

    # say L484 pla
    old "Yeah, that seems fine."
    new "そうだな、そうしよう。"

    # say L498 bil
    old "Ok, since we're here. Why don't we make it a little bit more interesting than just sitting down doing nothing? Let's play truth or dare!"
    new "じゃあ、ここまで来たんだし。ただ座って何もしないより、ちょっと面白くしようよ。トゥルーやダーレで遊ぼう！"

    # say L499 hin
    old "Uhh, I'm sorry. Truth or what?"
    new "うーん、すみません。トゥルーやダアって、何ですか？"

    # say L500 bil
    old "What? You don't know what truth or dare is?"
    new "何？真実か挑戦か知らないの？"

    # say L501 mik
    old "Hey! I know what it is."
    new "Hey！ 知ってるよ。"

    # say L502 pla
    old "Uhh, I think I know it, but I haven't played it."
    new "うーん、知ってるつもりだけど、実際にプレイしたことはないな。"

    # say L503 pla
    old "Just so we're all on the same page, could you explain?"
    new "みんなが同じページに立ってるかどうか確認するため、説明してもらえる？"

    # say L505 bil
    old "It's very simple: Each round, one of us chooses someone and asks them 'truth or dare'"
    new "それは簡単よ：各ラウンドで、私たちのうちの誰かが誰かを選んで、‘真実か挑戦か’と聞くの。"

    # say L506 bil
    old "If the person chooses ‘truth' they have to answer whatever the other one asks. If they choose ‘dare', they have to do what the person tells them to."
    new "もし『真実』を選んだら、相手が何を聞いても答えないといけないの。『チャレンジ』を選んだら、相手が何を言ってもそれをやらなければならないの。"

    # say L507 pla
    old "All right..."
    new "わかった…"

    # say L508 bel
    old "You have to be really honest in answering or accomplishing the dare, otherwise, you must go and can't continue playing."
    new "本当のことを答えるか、指令をちゃんとこなさないと、ゲームから脱落しちゃって続けられなくなるんだよ。"

    # say L509 bil
    old "Yeah, just like that, it's really fun. Come on, let's play!"
    new "そうそう、まさにそれ。めっちゃ楽しいよ。さあ、始めよう！"

    # say L511 pla
    old "Hmm, I don't know Billie..."
    new "うーん、BILLIE、ちょっとわからないな…"

    # say L512 mik
    old "Oh no! We're not backing down from this, [pla]. Come on! It sounds like a lot of fun!"
    new "おいお前ら！これくらい楽しもうぜ、[pla]。さあ、やってみよう！"

    # say L513 bel
    old "Yeah guys, let's do it. You never know, you may end up liking it."
    new "みんな、やってみようよ。意外と気に入っちゃうかもね。"

    # say L514 pla
    old "Ok, ok. If you guys really want to, let's do it."
    new "分かった、分かった。みんながやりたいなら、やってみよう。"

    # say L516 mik
    old "Alright! Let's do it!"
    new "よし！やろうぜ！"

    # say L517 bil
    old "Did you get it Hinn?"
    new "ヒン、準備できてる？"

    # say L519 hin
    old "Yeah, it's not that hard."
    new "うん、そんなに難しくないよ。"

    # say L520 bel
    old "Ok, since you say you understood it Hinn. Let's start with you, truth or dare?"
    new "分かったわ、ヒン。あなたから始めるわ、真実か挑戦か？"

    # say L521 hin
    old "Uhmm, truth."
    new "うーん、真実。"

    # say L523 bel
    old "Hmm, are you in love with anybody here?"
    new "Hmm、ここにいる誰かを好きになったの？"

    # say L524 hin
    old "W- what? What kind of question is that?!"
    new "えっ、そんな質問、どういうの？！"

    # say L525 bel
    old "Uhh, it's a valid question, and you have to answer it, those are the rules..."
    new "うーん、正当な質問だし、答えるのがルールだからね…"

    # say L526 bil
    old "That's right, that's the game."
    new "そうだよ、それがゲームさ。"

    # say L528 hin
    old "*Sigh* O- ok. Y- yes, I- I'm in love with someone who's here."
    new "* sigh * お、おｋ。は、はい、ここにいる誰かのことが好きです。"

    # say L531 mik
    old "WHAT?! Who is it? Who is it?"
    new "WHAT？！ 誰だよ？誰だよ？"

    # say L532 pla
    old "Hey, hey! Not fair, dude, she already answered a question. You can't ask her anything else. Right Billie?"
    new "おい、おい！不公平だぜ、彼女はもう質問に答えたんだ。他に何か聞くなよ。ビリー、そうだろ？"

    # say L534 bil
    old "Yeah, if you really wanna know that kind of stuff, you're gonna have to ask better questions."
    new "そうだよ、そんなこと知りたいなら、もっといい質問をしなきゃダメだよ。"

    # say L535 bil
    old "But come on, I think we should go for dares... It makes the game exciting!"
    new "でもさ、挑戦のほうにしてみたらどう？ゲームがもっと盛り上がるよ。"

    # say L536 bil
    old "Anyway, since you already spoke, why don't you ask the next question [pla]?"
    new "まあ、あなたがもう話したんだから、次は質問してみよう [pla]"

    # say L537 pla
    old "Hmm, ok. Well then, Belle, truth or dare?"
    new "うーん、いいか。じゃあ、ベール、真実か挑戦か？"

    # say L538 bel
    old "Truth."
    new "真実だね。"

    # say L539 bil
    old "Oh come on! Don't be pussies! Dares are way more fun!"
    new "ほらほら、そんな臆病なこと言わないでよ！ チャレンジの方が全然面白いじゃん！"

    # say L540 pla
    old "Hmm... H- have you ever kissed a man before?"
    new "うーん… お前は男の人とキスしたことがあるのか？"

    # say L542 bil
    old "What kind of question is that? Are you serious? Oh my god, you're a bunch of wusses."
    new "どんな質問よ？ 本気で？ おわっせ、みんなビビりすぎじゃない。"

    # say L547 bil
    old "I'll ask the question. Belle, have you ever taken naked pics?"
    new "私が質問するわ。ベール、裸の写真撮ったことある？"

    # say L548 bel
    old "W- whoa. Don't you think that's a little too far?"
    new "ちょっと待って、それってちょっと行き過ぎじゃない？"

    # say L550 bil
    old "No it's not and answer the question."
    new "全然そんなことないよ、質問に答えて。"

    # say L551 mik
    old "Yeah Belle, those are the rules. You answer the question or leave!"
    new "そうだよベール、それがルールだ。質問に答えるか、出て行け！"

    # say L555 bel
    old "Ugh! Yeah fine, I've taken naked photos before."
    new "うーん！ああ、分かったわ。裸の写真、撮ったことあるわ。"

    # say L558 mik
    old "Whoa! Really?!"
    new "マジか！本当に？！"

    # say L561 bil
    old "Hehe, ok. Who 's next?"
    new "へへ、わかった。次は誰？"

    # say L562 mik
    old "Me, me, me! I'm next."
    new "俺、俺、俺！次は俺だよ。"

    # say L563 mik
    old "Ok, Billie. Truth or dare?"
    new "オッケー、ビリー。真実か挑戦か？"

    # say L564 bil
    old "Dare! Unlike you guys, I actually have some guts."
    new "挑戦！私には君たちと違って少しは勇気があるのさ。"

    # say L568 mik
    old "Ok... Hmm... I dare you to... kiss Belle!"
    new "オッケー… うーん… お前の挑戦は… ベルとキスすることだ！"

    # say L570 bel
    old "What? But I'm not the one with the dare! It's Billie."
    new "何？でも私は挑戦されてないよ！挑戦するのはビリーじゃないの。"

    # say L571 bil
    old "Well, yeah. But this kind of dares are valid too. After all, I'm the one that has to do it."
    new "まあ、そうだけど。でも、この手の挑戦も有効なんだよ。結局、私がやるんだから。"

    # say L572 mik
    old "Yeah! Remember, you have to do it or you're out!"
    new "そうだよ！覚えてろ、君がやらないと脱落だぞ！"

    # say L573 bil
    old "Yeah whatever, I'll do it, it's no big deal."
    new "まあいい啦、やるわ、別に大したことはないしね。"

    # say L575 bil
    old "Come on, just help me with this... Otherwise I won't be able to continue playing..."
    new "さあ、ちょっと手伝って... そうじゃなきゃ、続けられなくなっちゃうよ..."

    # say L577 bil
    old "Just come here, close your eyes and think of someone you like."
    new "ここに来て目を閉じて好きな人のことを考えて。"

    # say L578 bil
    old "I'm sure we both are gonna enjoy it."
    new "きっと二人とも楽しめるわよ。"

    # say L590 hin
    old "Ok. Now it's my turn to have a go!"
    new "はい、今度は私がやってみる番だよ。"

    # say L592 hin
    old "Mike, truth or dare?"
    new "マイク、真実か挑戦か？"

    # say L593 mik
    old "Of course dare."
    new "もちろん、挑戦だ。"

    # say L594 hin
    old "Well, I dare you to leave and go home."
    new "じゃあ、あなたに家に帰るチャレンジを課すわ。"

    # say L595 mik
    old "Uhh?..."
    new "うっ？..."

    # say L596 bel
    old "Yeah! That's right, we all had to do our dares. You have to do the same."
    new "そうだよ、みんながチャレンジしてるんだから、あなたも同じようにしなきゃ。"

    # say L597 hin
    old "What is it Mike? You can't do it, uhh?"
    new "ミク、何？できないって、うそでしょ？"

    # say L598 mik
    old "Of course I can do it! I'll show you!"
    new "もちろんできるよ！見せてやる！"

    # say L615 bil
    old "Yeah, I didn't think he would do it."
    new "あたしもそう思ってたわ。"

    # say L617 pla
    old "Hahaha, very good trick Hinn, well done."
    new "ははは、いい手だな、ヒン。よくやった。"

    # say L619 bel
    old "Ok, now that he's gone. It's my turn again. [pla] truth or dare?"
    new "じゃあ、彼がいなくなったし。また私の番だよ。[pla] 真実か挑戦か？"

    # say L620 pla
    old "Hmm, truth."
    new "Hmm、真実。"

    # say L627 pla
    old "You know what? I- I choose dare."
    new "知ってる？俺、チャレンジにしようと思う。"

    # say L628 bel
    old "What? No, you've got to answer the question."
    new "何？いや、その質問には答えてもらわないと。"

    # say L629 bil
    old "No, it's fine. In fact, from now on let's play only with 'dares', no more truths."
    new "いいよ、むしろこれからは「チャレンジ」だけにして、質問はなしにしよう。"

    # say L630 bel
    old "Hmm, ok, if that's how it is. Then I dare you to take your penis out."
    new "へえ、そうなのか。なら、あなたのペニスを出せってことにするわ。"

    # say L631 pla
    old "W- what? Why do I have to do that?"
    new "ええと、なんでそんなことしなきゃならないの？"

    # say L632 bel
    old "Well, you can either do that, or answer my question!"
    new "じゃあ、それをするか、私の質問に答えるか、どっちかしなさい！"

    # say L634 pla
    old "Hmm, fine..."
    new "Hmm、わかったよ…"

    # say L643 bel
    old "(What a fucking big cock!)"
    new "なんて大きなの！"

    # say L644 pla
    old "Ok, now it's done."
    new "よし、これで完了だ。"

    # say L651 bil
    old "It's my turn again. And Belle, since you already made [pla] show something..."
    new "また私の番ね。それにベル、もう[pla]が何か見せたんだから…"

    # say L652 bil
    old "Why don't you show something of your own as well? What about if you take your boobs out?"
    new "それなら、自分も何か見せてよ。おっぱい出さない？"

    # say L654 pla
    old "Hey, I already did it. You have to fulfill the dare."
    new "Hey、俺はもうやったんだよ。今度は君の番だな。"

    # say L655 bel
    old "Fine. I'll do it."
    new "いいわ。やるわ。"

    # say L686 bel
    old "Ok, since I've done it... It's my turn, Billie! Show us your breasts too."
    new "よし、私がやったから……ビリー、次はあなただよ。おっぱいも見せて。"

    # say L687 bil
    old "Ughh, so original..."
    new "うっそぉ、そんなありきたりな…"

    # say L715 bil
    old "Then, since there's only one person here that hasn't shown anything. Hinn, I dare you to take your breast out too."
    new "じゃあ、ここにいる中でまだ何も見せてないのは君だけだね。ヒン、おっぱいも見せてみろよ。"

    # say L718 hin
    old "I- I... Uhh... I'm sorry guys, I- I can't do it."
    new "あ、あたし……うーん……ごめんなさい、みんな、あたし、無理だよ。"

    # say L730 pla
    old "Hinn wait!"
    new "ヒン、待て！"

    # say L731 bel
    old "No! [pla], just let her go. I think we went a little too far, right now she's a little nervous. Just leave her alone for now."
    new "ダメよ！[pla]、放っておきなさい。ちょっと行き過ぎたわ、今彼女は緊張してるんだから。今は一人にさせてあげなさい。"

    # say L732 pla
    old "But... I think she needs company."
    new "でも……彼女は誰かと一緒にいた方がいいと思うんだ。"

    # say L733 bel
    old "Not right now, if you go after her you're just going to make her feel worse."
    new "今じゃないよ、追いかけると余計に不安になるだけだよ。"

    # say L736 bel
    old "Trust me, it's better if you just let it be. You can talk to her later. Right Billie?"
    new "信じて、放っておいた方がいいわ。後で話せるじゃない。ねえ、ビリー？"

    # say L737 bil
    old "Yeah, what she said."
    new "うん、そう言ってるよね。"

    # say L740 pla
    old "Hmm, all right."
    new "Hmm、分かった。"

    # say L741 bil
    old "Well, I guess we can continue playing then."
    new "じゃあ、続けましょうか。"

    # say L742 bel
    old "I agree, since we already started playing. I think it's the best we can do."
    new "私もそう思うわ。もう始めてるんだから、これでいいと思うの。"

    # say L743 pla
    old "Yeah fine. Let's do it."
    new "わかったわかった。やろうぜ。"

    # say L744 bel
    old "Now, it's your turn to do a dare again [pla]."
    new "じゃあ、今度はあなたがチャレンジする番よ [pla]。"

    # say L745 bel
    old "Why don't you suck Billie's boobs?"
    new "ビリーの胸を舐めてあげるといいわよ。"

    # say L746 pla
    old "Whoa! Really?"
    new "誰あ！本気で？"

    # say L747 bil
    old "Well, a dare is a dare, so..."
    new "まあ、挑みは挑みだしね..."

    # say L748 pla
    old "A- all right."
    new "よし、分かった。"

    # say L767 bil
    old "Hmm, this isn't going to stay like this."
    new "うーん、このままじゃダメだね。"

    # say L770 bil
    old "Belle, since you like contact that much. Why don't you give [pla] a handjob?"
    new "ベル、そんなにスキンシップが好きなら、[pla]に手コキしてあげれば？"

    # say L771 bel
    old "W- what? For real?!"
    new "えっ、マジで？！"

    # say L773 bil
    old "That's right."
    new "そうだよ。"

    # say L774 bel
    old "Ughh, fine, let's do it."
    new "うーん、仕方ないね、やるわ。"

    # say L780 bel
    old "My god [pla] your dick is huge! I can't believe you carry this around."
    new "神様、[pla] あなたのチ○ポ、デカすぎ！こんなもん持ち歩くの信じられない。"

    # say L782 bil
    old "Come on, quit stalling and do it."
    new "さあ、遠慮しないで早くやろ。"

    # say L783 bel
    old "Yeah, well, here I come."
    new "よし、来ちゃうわ。"

    # say L796 bel
    old "Ok, I did what you dared me too."
    new "よし、あなたが挑戦したとおりにやったわ。"

    # say L797 bel
    old "But since you wanted to see that so badly, why don't you give [pla] a blowjob, Billie?"
    new "でも君がそんなに見たいって言ったんだから、ビリー、[pla]にフェラチオしてあげれば？"

    # say L798 bil
    old "What's this, copying me again?"
    new "何これ、また真似してるの？"

    # say L799 bel
    old "What? After you made me do all of that, you can't do it?"
    new "何？　私がそんなにした後で、君はできないの？"

    # say L800 bil
    old "Tsk, of course I can, come on [pla] let's do it!"
    new "チッ、もちろんできるよ、さあ[pla]、やろう！"

    # say L810 bil
    old "I still can't believe you pack this much."
    new "まだ信じられないくらい大きいんだから。"

    # say L811 bel
    old "Are you nervous?"
    new "緊張してるの？"

    # say L812 bil
    old "Of course not. I was just saying."
    new "もちろんよ。ただ言ってただけさ。"

    # say L828 bil
    old "Ok, this has been fun. But what do you say about taking this to the next level?"
    new "じゃあ、これで楽しかったけど、次のレベルに進んでみない？"

    # say L830 bel
    old "The next level? Hasn't this been enough?"
    new "次のレベル？これで十分じゃないの？"

    # say L831 bil
    old "No, I'm talking about something extreme, How about we go to the haunted house here in town?"
    new "いや、もっと極端なこと。町の心霊スポットに行ってみようよ。"

    # say L832 pla
    old "Haunted house?"
    new "心霊スポットの家？"

    # say L833 bil
    old "Yeah that's right. There's a house in town with vampires. Why don't we go?"
    new "そうよ、その通り。町にある吸血鬼の家に行かない？"

    # say L834 bel
    old "Ohh, you're talking about the old mansion."
    new "ああ、その古い邸宅のことね。"

    # say L836 pla
    old "B- but you said vampires. Which vampires?"
    new "でも、君は吸血鬼だって言ったよね。どの吸血鬼のこと？"

    # say L838 bil
    old "There's a legend about that house, that says there are vampires in there."
    new "その家には吸血鬼がいるという伝説があるの。"

    # say L839 bil
    old "All its inhabitants are women, people say that they have been seen kidnapping men, to then suck all of their blood out."
    new "その家の住人たちは全員女性で、男の人を拉致して、その血を全部吸い取っているって言うの。"

    # say L840 bil
    old "And leave them completely dry."
    new "そして完全に乾かしてしまうの。"

    # say L842 bil
    old "Besides, it is said that they are all very pale, and apparently they only go out at night. Never in the sunlight. Surely to pick up another victim."
    new "それに、みんなとても白いって言うし、夜だけ出歩くらしいよ。日光の下には絶対に出ないんだ。きっとまた新しい獲物を探してるんだよね。"

    # say L843 bel
    old "Yeah, yeah, yeah. It's super creepy and spooky, let's go!"
    new "うん、うん、うん。めちゃくちゃ不気味で怖いけど、行こうよ！"

    # say L844 pla
    old "Uhh... I- I'm not sure I want to go there."
    new "うーん…… 行くのはちょっと不安だな。"

    # say L845 bil
    old "Aww, are you that much of a wuss? Come on, have some guts."
    new "あら、そんなに臆病なの？ 来なよ、胆量出しちゃって。"

    # say L846 pla
    old "I'm not a wuss... Ok, let's do it then."
    new "俺は臆病者じゃないよ… じゃあ、行こうか。"

    # say L855 bel
    old "Wow guys, this really feels sinister. It's quite terrifying."
    new "おお、これ本当に不気味だわ。ものすごく怖い。"

    # say L856 pla
    old "Y-y-yeah, this is very scary. Maybe we should head back."
    new "うーん、これってかなり怖いな。もしかしたら戻った方がいいかもしれないな。"

    # say L857 bil
    old "What? No, we're not doing that. We've gotta keep playing. And it's your turn again [pla]."
    new "何？そうじゃないよ。続きなきゃ。あなたの番だよ [pla]。"

    # say L858 bil
    old "And since you are spiderman... I dare you to climb up to the roof."
    new "そしてスパイダーマンだから……屋根まで登んでみようよ。"

    # say L859 pla
    old "W-what? B-but..."
    new "何？　でも..."

    # say L860 bil
    old "It's a dare, isn't it? We accomplished ours very well."
    new "それは挑戦だよね、私たちのは上手くいったんだから。"

    # say L861 bil
    old "And you seemed to enjoy those a lot. Didn't you? it would be unfair if you chicken out now. Do it!"
    new "あなたも結構楽しんでたじゃない、そうでしょう？ 今さら逃げ出すのは不公平だよ。やってみなさい！"

    # say L862 pla
    old "Hmph, fine. I'll do it."
    new "ふん、仕方ないな。やるよ。"

    # say L863 bil
    old "But use all the suit, even with the mask, just like spiderman."
    new "でもスーツ全部使おう、マスクもつけて、スパイダーマンみたいに。"

    # say L864 pla
    old "Really? Hmm, Alright."
    new "ほんと？ふむ、わかった。"

    # say L870 bel
    old "That's it! Yes, you're doing well!"
    new "それだ！そう、よくやった！"

    # say L873 bil
    old "Keep going! You can't just stop halfway up! You have to make it to the roof!"
    new "頑張って！途中で止まっちゃダメよ！屋上まで行かなきゃ！"

    # say L876 pla
    old "I know, ugh! I know!"
    new "知ってるよ、うっ！知ってるよ！"

    # say L882 pla
    old "Ok! I made it all the way up! Just wait there, I'm gonna go down again!"
    new "分かった！全部登りきったぞ！ちょっと待ってろ、また下りるから！"

    # say L883 bil
    old "Yeah sure! You made it, come down!"
    new "うん、もちろん！ 上まで来たんだね、降りてきて！"

    # say L891 pla
    old "AAAAAAH!!"
    new "AAAAAAAH！！"

    # say L895 bil
    old "[pla]! [pla]! Can you hear us [pla]?! Talk to us!"
    new "[pla]！[pla]！聞こえてるか[pla]？話してみて！"

    # say L896 bel
    old "We're going to get some help! Just hang in there!"
    new "助けが来るから！ちょっとだけ我慢して！"

    # say L909 pla
    old "W- what is this? W- where I-?"
    new "これは一体…？　どこに…？"

    # say L940 pla
    old "Ugh!! My god, what happened? Why does my head hurt so much?"
    new "うげっ！！ 神様、何が起こったんだ？ なんで頭がこんなに痛いんだ？"

    # say L946 lad
    old "Oh, Hello! You're finally awake, I'm glad you woke up. I was thinking that if you didn't, I might have to call an ambulance."
    new "あら、こんにちは！ ようやく目を覚ましたんですね、良かったです。起きてくれて安心しました。もしこのまま起きなかったら、救急車を呼ぶつもりでしたよ。"

    # say L947 pla
    old "Whoa! Ah... W- where am I?"
    new "Whoa！ アッ… ここはどこだ？"

    # say L948 lad
    old "Calm down, this is my house. You fell in here yesterday while you were playing on our roof."
    new "落ち着いて、ここは私の家よ。昨日、屋根で遊んでいたときに落ちてきちゃったの。"

    # say L949 pla
    old "Y- your house?"
    new "君の家？"

    # say L950 lad
    old "Yes, that's right. Maybe you thought you actually were spiderman?"
    new "はい、その通りです。もしかして、自分が本物のスパイダーマンだと思ったの？"

    # say L952 pla
    old "Oh my God! It's morning already?!"
    new "おっと！もう朝だったのか！？"

    # say L953 pla
    old "I- I have to go, [mo1rel] must be worried sick about me."
    new "いっ、行かないと、[mo1rel] が心配してるに違いない。"

    # say L954 lad
    old "Are you already leaving?"
    new "もう帰られるの？"

    # say L955 pla
    old "Y- yes, but don't worry, I promise I'll come back to fix your roof."
    new "うん、でも心配しないで、絶対に屋根の修理のために戻ってくるから。"

    # say L956 lad
    old "Ok, if you say so. Be careful though. You got a big hit there."
    new "はい、そうしましょう。でも気をつけてね。大きな怪我をしたみたいだから。"

    # say L972 mo1
    old "Dear, you're home! Oh my god! You had me so worried. Where were you?!"
    new "亲爱的，你回家了！天啊！我好担心你。你去哪里了？！"

    # say L973 pla
    old "S- sorry [mo1rel]. Me and my friends went trick or treating yesterday after school was over."
    new "すみません、[mo1rel]。昨日学校が終わった後、友達とトリックオアトリートに行ってきたんです。"

    # say L974 pla
    old "And after we were done Mike invited me to stay at his house."
    new "そしてマイクが家に泊まるよう誘ってくれたんだ。"

    # say L975 mo1
    old "That's not a problem. But why didn't you call to let us know where you were?!"
    new "それは問題ないけど、どこにいるのか教えてくれなかったのはなぜ？！"

    # say L976 pla
    old "I- I guess I just lost track of time and then forgot about it. Sorry [mo1rel] I didn't mean to scare you."
    new "時間の流れに気を取られて、すっかり忘れてたんだ。ごめん、[mo1rel] 心配かけちゃって。"

    # say L977 mo1
    old "Well you did! You're an adult, so you can do whatever you want, but at least call to let me know about this sort of thing."
    new "まあ、そうよね！　成人だから自由に行動するのはいいけど、少なくともこんなことなら連絡してほしいわ。"

    # say L978 pla
    old "You're right, my bad."
    new "君の言う通りだ、悪かったな。"

    # say L979 mo1
    old "It's ok honey, I'm just happy to see you're safe."
    new "大丈夫よ亲爱的，看到你平安无事我就很高兴了。"

    # say L980 pla
    old "Thanks [mo1rel]. By the way, I've gotta get ready for school."
    new "ありがとう、[mo1rel]。でも、学校の準備をしないとね。"

    # say L985 pla
    old "Ohh, what a crazy day yesterday was. I can't believe we did all that."
    new "昨日は本当に狂った一日だったな。信じられないくらい色々やったよ。"

    # say L986 pla
    old "I would like to rest a little bit more. But I guess I better get to school. I don't want to give Ms. Mia any more reasons to suspend me."
    new "もう少し休みたいけど、学校に行かなきゃね。ミス・ミアにまた停学の理由を与えたくはないから。"

    # say L1113 pla
    old "Hey girls, how are you?"
    new "女の子たち、元気？"

    # say L1117 bil
    old "Are you really ok? We went asking for assistance but when we came back you weren't there."
    new "大丈夫なのかしら？援助を求めて出かけただけなのに、戻ったらあなたがいなかったの。"

    # say L1118 bil
    old "We were very worried because we didn't know where you went."
    new "心配したの、あなたがどこにいったのか全然わからなかったから。"

    # say L1119 pla
    old "Yeah, sorry about that. But to be honest I don't know what happened either."
    new "ああ、すまない。でも正直、何が起こったのか俺もわからないんだ。"

    # say L1120 pla
    old "All I remember was hitting the ground really hard, and you calling out for me. But then I passed out."
    new "覚えてるのは地面に激しくぶつかったことと、君が俺の名前を呼んでくれたことだけだ。でもその後すぐに気を失った。"

    # say L1121 pla
    old "I imagined it was the lady who moved me."
    new "俺はその女性が俺を運んでくれたと思ったんだ。"

    # say L1123 bil
    old "Lady? You're talking about the vampire?!"
    new "Lady？ 吸血鬼のこと言ってるの？！"

    # say L1124 pla
    old "Uhhh, I- I don't know, I just met her this morning when I woke up, apparently she took care of me."
    new "うーん、知らん、今朝起きたら会っただけだ、どうやら俺の世話をしててくれたらしい。"

    # say L1125 bel
    old "Whoa! And how was it? Weren't you scared?"
    new "Whoa！ それはどうだったの？ 全然怖くなかったの？"

    # say L1126 pla
    old "Me? Not really? I was only surprised, because she wasn't angry. In fact, she was really nice to me."
    new "俺？そんなに怖くなかったよ。むしろ驚いたのは、怒ってないってことだったからさ。実際、めちゃくちゃ優しくしてくれたんだ。"

    # say L1127 pla
    old "I promised to come back later and fix the damage I did to her roof."
    new "俺は後でまた来て、彼女の屋根を直すって約束したんだ。"

    # say L1128 bil
    old "Whoa! Well I guess it's better that way."
    new "へえ！まあ、そうした方がいいかもしれないね。"

    # say L1130 bel
    old "Yeah, after all, you did ruin her roof. So, it's better if you fix it."
    new "そうだね、結局あなたが彼女の屋根を壊したんだから、直した方がいいわね。"

    # say L1132 bil
    old "Yeah, I think I went a little overboard with that last dare."
    new "あたしの最後のチャレンジ、ちょっとやりすぎちゃったね。"

    # say L1133 bil
    old "I promise I'll make it up to you next time we play. Right Belle?"
    new "次プレイするとき、絶対に返すから。ね、ベール？"

    # say L1134 bel
    old "Yeah, for sure."
    new "うん、もちろん。"

    # say L1135 pla
    old "Well, I didn't think I would want to play that again."
    new "WELL、そんなゲームをまたするとは思わなかったな。"

    # say L1136 pla
    old "But if it's going to be like you say, then count me in for next time."
    new "でも君の言う通りなら、次は参加するよ。"

    # say L1138 bel
    old "Well, we have classes now. See you later."
    new "じゃあ、授業があるからね。またね。"

    # say L1139 pla
    old "Alright, see you girls."
    new "よし、またね。"

    # say L1156 hin
    old "G- good morning [pla]. How are you?"
    new "おはよう [pla]、元気？"

    # say L1158 pla
    old "Hey Hinn. I'm fine, thank God I get to see you today."
    new "Hey Hinn、元気だよ。今日会えるのは神様に感謝してる。"

    # say L1159 pla
    old "Hey, listen, I've been thinking, and I'm sorry about the way things ended up yesterday, me and the girls took it a little too far."
    new "Hey、聞いてくれ、考えてたんだけど、昨日のことがさ、女の子たちとちょっとやりすぎちゃって、ごめん。"

    # say L1161 hin
    old "It's ok, actually I wanted to say sorry to you."
    new "大丈夫、実は私が謝りたかったの。"

    # say L1162 hin
    old "To be honest, I'm still not used to being that open. It's ok when I'm with you and Dr. Johnson."
    new "正直に言うと、まだそんなにオープンになるのが慣れてないの。あなたやドクター・ジョンソンと一緒なら大丈夫だけど。"

    # say L1163 hin
    old "But if things turn sexual when there's other people around, and watching me, I just freeze."
    new "でも、他の人がいて見ている場所で性的になったら、固まっちゃうの。"

    # say L1164 hin
    old "And yesterday things got a little too dense for my liking, so I couldn't handle it, and took off."
    new "昨日はちょっと密になりすぎて、耐えられなくなって逃げちゃった。"

    # say L1165 hin
    old "S- sorry for leaving like that, I hope I didn't ruin your night."
    new "すみません、急にいなくなって、あなたの夜を台無しにしてしまったかなって思ったの。"

    # say L1166 pla
    old "No, not at all! You didn't ruin anything."
    new "全然大丈夫、何も台無しじゃないよ。"

    # say L1168 pla
    old "Yes, really. I'm just happy to see you're doing fine."
    new "本当に、心配しなくていい。君が元気でいるだけで嬉しいんだ。"

    # say L1169 hin
    old "Thank you [pla]."
    new "ありがとう、[pla]。"

    # say L1170 hin
    old "But... honestly, I don't think I'm that well..."
    new "でも…正直、そんなに元気じゃないな…"

    # say L1172 hin
    old "Well, I- I've been thinking... maybe I could talk with Dr. Johnson again, take a couple more lessons from her."
    new "まあ、考えていたの……Dr. Johnson先生とまた話して、もう少しレッスンを受けたらどうかなって。"

    # say L1173 pla
    old "Really? Do you feel you need it?"
    new "本当に？それが必要だって感じてるの？"

    # say L1174 hin
    old "I do. I know she's already helped me a lot. But it can't hurt to keep working on things. There's always room for improvement"
    new "そうよ。彼女にはすでにたくさんのことを教えてもらったけど、もっと頑張っても損はないわ。改善の余地はいつもあるから。"

    # say L1176 pla
    old "Hmm, well, if you think it's the best thing for you, I support you completely."
    new "うん、君がそれが一番いいと思ってるなら、全面的に支持するよ。"

    # say L1177 hin
    old "Thank you, your support does mean a lot to me. Also, would you come with me? To the sessions? I think it's easier with you there."
    new "ありがとう、あなたのサポートは私にとって本当に意味があるの。それと、セッションに一緒に来てくれない？あなたがいると楽だなって思うの。"

    # say L1178 pla
    old "Of course I will, if you need me, I'm more than happy to help you."
    new "もちろん、君が必要なら喜んで手伝うよ。"

    # say L1179 hin
    old "Thanks again [pla] I knew I could count on you."
    new "ありがとう [pla] あなたが見放さないと思ってたの。"

    # say L1181 pla
    old "Oh! Look at the time, I think we better get to class."
    new "ああ、時間だな。クラスに行くか。"

    # say L1182 hin
    old "Yeah, if not Ms. Mia will be angry."
    new "うん、そうしないとミス・ミアに怒られるよ。"

    # say L1183 pla
    old "You are right. let's go."
    new "君が言う通りだな。行こう。"

    # say L1198 pla
    old "Good morning ma'am, how are you?"
    new "おはようございます、お嬢さん。お元気ですか？"

    # say L1199 lad
    old "Ohh! This is a surprise... I didn't think you were gonna come back."
    new "あら、これは意外なサプライズですね…戻ってくるとは思わなかったわ。"

    # say L1200 pla
    old "No, I couldn't do that. I said I was gonna fix it, and that's what I'll do."
    new "いや、そうはいかないな。直すって言ったんだから、それが俺の役目だ。"

    # say L1201 lad
    old "Well, isn't that nice?"
    new "まあ、それは良いですね。"

    # say L1202 lad
    old "Truth be told, I had already prepared some tools to fix it myself. But if you're gonna do it I'll lend them to you."
    new "実は、自分で直すために道具を用意してあったの。でも、あなたが直すなら貸してあげるわ。"

    # say L1203 pla
    old "Thank you ma'am. I promised it's going to be as good as new when I'm done."
    new "ありがとうございます、お嬢さん。修理が終わったら新品同様にしますから。"

    # say L1204 lad
    old "That's really nice of you, thank you."
    new "それは本当に親切ですね、ありがとうございます。"

    # say L1205 pla
    old "So, where are the tools and materials?"
    new "じゃあ、道具と材料はどこにある？"

    # say L1206 lad
    old "Oh, they're in the next room, in the garage."
    new "あ、次の部屋のガレージにあります。"

    # say L1207 lad
    old "The damage isn't that small, so it's going to take you a while to finish completely, you may have to come a couple more times."
    new "ダメージがそれほど小さくないから、完全に直すのに時間がかかるわ。何回か来なければならないかもしれないけど。"

    # say L1209 pla
    old "That's fine, it was my fault, so it doesn't matter to me how much time it takes. I'll fix it completely."
    new "それはいいよ、俺のせいだから時間かかるのは気にしない。完全に直すから。"

    # say L1210 pla
    old "And once again ma'am. I'm sorry for doing that."
    new "またしても申し訳ありません、お嬢さん。その行為について謝ります。"

    # say L1211 lad
    old "It's ok, what's important it's that you came back, and by the way, I'm Alcina Dimitrescu."
    new "大丈夫です、何よりもあなたが戻ってきてくれたことが重要です、それにしても私はアルシナ・ディミトレスクです。"

    # say L1212 pla
    old "Ohh sorry... I haven't told you my name. I'm [pla], nice to meet you."
    new "ああ、すみません… 名前を教えてなかったですね。[pla]です、よろしくお願いします。"

    # say L1214 lad
    old "Oh don't worry, nice to meet you too [pla]..."
    new "気にしないでください、[pla]さん、会えて嬉しいです…"

    # say L1215 lad
    old "I'll be in the next room if you need me. I won't take more of your time and let you start your work..."
    new "次の部屋で待っていますので、必要であればどうぞ。あなたの時間を取りすぎてしまったので、お仕事に取り掛かってくださいね。"

    # say L1216 pla
    old "All right, thank you."
    new "じゃあ、ありがとう。"

    # say L1227 lad
    old "Congratulations! You made a lot of progress today."
    new "おめでとうございます！今日、たくさんの進展がありましたね。"

    # say L1228 lad
    old "You're very fast, and it's all very well done."
    new "あなたはとても速くて、しかも非常に上手ですね。"

    # say L1229 pla
    old "Thank you ma'am. I'm glad you like my progress."
    new "ありがとうございます。私の進捗を気に入っていただけて嬉しいです。"

    # say L1230 pla
    old "I'm sure if I keep going at this pace it'll be ready very soon."
    new "この調子で続けば、すぐ完成するだろう。"

    # say L1231 lad
    old "Sure, I have no doubt about it. Very nice."
    new "もちろん、そのペースなら間違いないわ。とても良いわね。"

    # say L1232 pla
    old "Thank you ma'am."
    new "ありがとうございます、お嬢さん。"

    # say L1233 pla
    old "It's a little late, so I think I should be going home. But I'll come back soon."
    new "少し遅いけど、家に帰るかな。でもまたすぐ来るよ。"

    # say L1234 lad
    old "Oh yeah, don't worry, go home, I'll see you later then."
    new "大丈夫ですよ、お帰りください。また後で会いましょう。"

    # say L1247 pla
    old "Hmm, this is harder than I expected."
    new "うーん、これって思ってたより難しかったな。"

    # say L1248 pla
    old "Sorry for doing so little. But I'm sure next time I'll progress a lot more."
    new "ごめん、今日はあまりできなかったけど、次はもっと進める自信があるよ。"

    # say L1249 lad
    old "Well, you didn't do much today, but I understand, it's a big job after all. "
    new "今日はあまり進みませんでしたが、それは大きな仕事だから仕方ないですね。"

    # say L1250 lad
    old "Don't worry about the progress, I know you'll make it."
    new "心配しないでください、あなたの努力は見逃さないわ。"

    # say L1251 pla
    old "Yeah, thank you. I'll come back later and keep working on it."
    new "うん、ありがとう。後でまた来て続きをやろう。"

    # say L1252 lad
    old "Yes, it's a little late, so you should go home and come another time."
    new "はい、少し遅いので、家に帰ってまた別の時間に来ていただければと思います。"

    # say L1253 pla
    old "You are right. Thank you."
    new "そうだな、ありがとう。"

    # say L1263 pla
    old "Hmm, listen, ma'am before I leave, may I ask you something?"
    new "あのう、失礼ですが、帰る前に一つだけ聞きたいことがあります、よろしいですか？"

    # say L1264 lad
    old "And what may that be?"
    new "何でしょうか？"

    # say L1265 pla
    old "Well, I'm a little ashamed to admit this."
    new "まあ、ちょっと恥ずかしいんだけどね。"

    # say L1266 pla
    old "But the reason I crashed into your living room the other day was because a couple of my friends dared me to climb your roof."
    new "でも、先日君のリビングに突っ込んだのは、友達に自分の屋根に登るよう挑戦されたからなんだ。"

    # say L1268 lad
    old "And why did they do that?"
    new "なぜそうしたのかしら？"

    # say L1269 pla
    old "Well... it's because there are some rumors about this house being haunted."
    new "まあ……この家が幽霊が出るとかいう噂があるからな。"

    # say L1271 lad
    old "Haunted you say?"
    new "幽霊が出るというの？"

    # say L1272 pla
    old "Yeah... I mean, I don't believe them now, but that's what they say."
    new "まあ……今となっては信じてないけど、そんなこと言ってるんだ。"

    # say L1273 pla
    old "And, that's not all of it..."
    new "そして、それだけじゃないんだよ。"

    # say L1274 lad
    old "It isn't?"
    new "そうなの？"

    # say L1276 pla
    old "Well, apparently there's a story about a group of vampires living here..."
    new "まあ、どうやらここに吸血鬼のグループが住んでいるという話があるらしいんだ。"

    # say L1277 lad
    old "Is that so? And what do you think? Do I look like a vampire to you?"
    new "そうですの？それなら、私は吸血鬼に見えますか？"

    # say L1278 pla
    old "O- of course not. I just wanted to apologize for the reason I climbed your roof. Because the rumor isn't true, right?"
    new "もちろんそんなことないよ。ただ、君の屋根に上がった理由を謝りたかっただけなんだ。噂は本当じゃないよね？"

    # say L1279 lad
    old "Hehe, of course not. Seriously, kids these days have some imagination."
    new "へへ、もちろんそんなことないわ。本当に、今の子供たちは想像力が豊かね。"

    # say L1280 lad
    old "But now it's not the time for that, it's very late and I think you need to go home."
    new "でも今はその話をする時間じゃないわ、もう遅いしあなたが帰宅するべきだと思うの。"

    # say L1282 pla
    old "You're right, sorry for bothering you with all of this."
    new "君が言う通りだ、すまんな、こんなことで迷惑をかけて。"

    # say L1283 pla
    old "And don't worry, I'll come soon to keep working on the roof."
    new "心配しなくていい、すぐ屋根の修理に戻ってくるから。"

    # say L1284 lad
    old "I really appreciate your help. Have a good night."
    new "あなたの手伝いに本当に感謝しています。おやすみなさい。"

    # say L1301 pla
    old "Hello again lady Dimitrescu. How are you today?"
    new "ディミトレスクさん、またお会いできて嬉しいです。今日もお元気ですか？"

    # say L1302 lad
    old "Hello [pla], I'm fine. You've come to keep working on the roof?"
    new "こんにちは [pla]、元気です。屋根の修理を続けるため来たんですか？"

    # say L1303 pla
    old "Yes ma'am. I'm going to get to it right away. So, I can finish it as soon as I can."
    new "はい、すぐに始めます。できるだけ早く終わらせられるように頑張ります。"

    # say L1304 lad
    old "Oh perfect. Well, I'll leave you to it. If you need me, I'm in the room next door."
    new "あら、ちょうどいいですね。では、お任せします。何か必要でしたら、隣の部屋にいますから。"

    # say L1310 pla
    old "Excuse ma'am, but before I go home, there's something else I'd like to ask you about."
    new "失礼ですが、帰る前に一つだけ聞きたいことがあります。"

    # say L1312 lad
    old "Perhaps another rumor?"
    new "もしかして、また別の噂ですか？"

    # say L1313 pla
    old "No, no. Nothing like that. It's just... After I fell and passed out. I remember waking up for a brief moment. "
    new "いや、違う。そんなことはない。ただ……倒れて意識を失った後、一瞬だけ目が覚めた記憶がある。"

    # say L1314 pla
    old "And I could swear I saw you with someone else, watching me."
    new "そして、君が他の誰かと一緒に、俺を見ていると思ったんだ。"

    # say L1316 lad
    old "S- someone else, heh... What do you mean?"
    new "他の人って、へへ… どういうこと？"

    # say L1317 pla
    old "Well, I saw two young ladies, they kinda looked like you. But I'm not sure..."
    new "まあ、二人の若い女性がいて、君に似てたんだけど、確信は持てないな。"

    # say L1318 lad
    old "Hmm, sorry [pla], but I was alone when I picked you up."
    new "Hmm、ごめんなさい [pla]、でも私が迎えに行ったときは一人でした。"

    # say L1319 lad
    old "I think you must have seen some kind of hallucination or something."
    new "あなたが見たのは、きっと幻覚だったと思います。"

    # say L1320 pla
    old "Are you sure? It felt so real..."
    new "君が見たのは幻覚だったのかな、でも本当のようだったよ…"

    # say L1321 lad
    old "Yes I'm sure. Now, It's getting very late, so you should go home now."
    new "はい、確信しています。もう遅いので、おうちに帰ってください。"

    # say L1322 pla
    old "Hmm, ok. I think you're right. Bye ma'am."
    new "うーん、そうかも。君の言う通りだと思う。じゃあ、おやすみ。"

    # say L1323 lad
    old "Have a good night, [pla]."
    new "おやすみなさい、[pla]。"

    # say L1338 pla
    old "Ok! That's it for today. It's almost done."
    new "Ok！ 今日で終わりだ。もうすぐ完成するよ。"

    # say L1339 lad
    old "Wow! Look at how much you have done already! I think you only need to come back one more time and you will have finished."
    new "Wow！これだけ進んでいるなんてすごいですね！もう一回来ていただければ完成すると思いますよ。"

    # say L1340 pla
    old "Thank you ma'am, I'm happy you like how the repairs are going, I also think I only need to come once more, and it'll be ready."
    new "ありがとうございます、お嬢さん。修理の進み具合に喜んでいただけて嬉しいです。あと一回来れば完成すると思います。"

    # say L1341 lad
    old "I'm astounded at how fast you are, you're a very good worker."
    new "あなたの速さには驚きました、あなたは本当に良い職人さんですね。"

    # say L1342 pla
    old "Thank you very much!"
    new "ありがとうございます！"

    # say L1343 pla
    old "Well, I think I'll head home. I'll be sure to come back and finish."
    new "じゃあ、今日は帰るけど、また続きをやるために戻ってくるよ。"

    # say L1348 lad
    old "Wait! [pla]"
    new "待って！ [pla]"

    # say L1351 pla
    old "Yes? Is there a problem?"
    new "何ですか？何か問題があるの？"

    # say L1352 lad
    old "A problem? No, no, nothing like that, I just wanted to thank you once again for how well the repairs are going."
    new "問題？いいえ、いいえ、そんなことはありません。ただ、修理が順調に進んでいることへの感謝を改めて伝えたくなったのです。"

    # say L1353 lad
    old "Being completely honest, I didn't think you were actually going to do it. But I'm glad I was wrong."
    new "正直に言うと、あなたが本当にやってくれるとは思っていなかったんですが、間違っていたことを喜んでいます。"

    # say L1354 pla
    old "Well, it's not a problem at all. It was my fault that the roof broke in the first place, I feel like it's only fair that I handle the repairs."
    new "まあ、問題じゃないな。屋根が壊れたのは俺のせいだから、修理するのは当然だと思うよ。"

    # say L1356 lad
    old "Well, I'm happy that you're such an upstanding young man."
    new "あなたがそんな立派な青年だとは、とても嬉しいです。"

    # say L1357 lad
    old "And another thing..."
    new "そして、もう一つ。"

    # say L1358 pla
    old "Yes?"
    new "何ですか？"

    # say L1359 lad
    old "It's about those rumors that you mentioned. The truth is I have actually heard of them as well."
    new "あなたが言及した噂についてです。実は私も耳にしたことがあります。"

    # say L1360 pla
    old "You knew about them?"
    new "君も知っていたのか？"

    # say L1361 lad
    old "Of course I did. it's difficult not to notice when people look at me and murmur wherever I go."
    new "もちろん知っています。どこへ行っても、人々が私を見て囁き合うのを見逃すのは難しいんです。"

    # say L1362 lad
    old "But some people are even worse, they come to my house and try to sneak in, or to get pics of the 'vampire lady'."
    new "でも、有些人はもっと悪いわ。私の家に忍び込もうとする人もいれば、「吸血鬼の淑女」の写真を撮ろうとする人もいるの。"

    # say L1363 lad
    old "It's really stressful, so I was a bit cautious of your intentions at first."
    new "本当にストレスフルで、最初はあなたの意図にも少し慎重になりました。"

    # say L1364 pla
    old "Ohh, I- I see, I'm sorry things are like that. It must be so awkward to have to deal with that all the time."
    new "ああ、そうか。すまないな。いつもそんな状況で大変そうだね。"

    # say L1366 lad
    old "Oh yeah, it's tremendously stressful... Actually, there is a reason why those rumours exist."
    new "そうですの、ものすごくストレスFULです…実際、その噂が存在する理由があるんです。"

    # say L1367 pla
    old "Uhh? What do you mean?"
    new "うっ？どういう意味？"

    # say L1368 lad
    old "Well, as I said, I was a bit cautious of you, but I think you've managed to keep your word."
    new "ええ、先に言った通り、あなたに対して少し慎重でしたけど、約束を守ってくれたと思います。"

    # say L1369 lad
    old "And I realize I haven't been completely honest with you..."
    new "そして、私はあなたに対して完全に正直ではなかったことに気づきました…"

    # say L1370 lad
    old "So, let me tell you the truth; it would be good if at least one person in town knows things as they really are."
    new "なので、本当のことをお話ししましょう。この町で少なくとも一人が事実を知っている方が良いと思います。"

    # say L1373 lad
    old "I suffer from a rare condition in which my body is unable to produce a certain type of amino acid."
    new "私は希少な病気を患っており、体が特定のアミノ酸を生成することができません。"

    # say L1374 lad
    old "Not all of them, but this particular one is very important. Do you know what that means [pla]?"
    new "すべてではありませんが、この特定のアミノ酸は非常に重要です。それが何を意味するかご存知ですか [pla]？"

    # say L1375 pla
    old "Hmm, not really."
    new "そうでもないな。"

    # say L1376 lad
    old "Haha, it means that I'm unable to produce and store a type of protein that the body needs to function properly."
    new "ははは、それは私の体が必要とする種類のタンパク質を生成して保存できないということよ。"

    # say L1378 pla
    old "Ohh..."
    new "オッ…"

    # say L1379 lad
    old "As I said, it's not all of them, I'd be dead if it was like that. But this one is crucial nonetheless."
    new "私が言った通り、全部ではないわ。そうだったらもう死んでいたでしょう。でもこのタンパク質はとても重要なの。"

    # say L1380 lad
    old "Nor am I able to absorb it from the usual sources, like meat and vegetables."
    new "通常の肉や野菜からは吸収できないのです。"

    # say L1381 pla
    old "So, does that mean your health is in danger?"
    new "じゃあ、君の健康が危険な状態になるってことか？"

    # say L1382 lad
    old "Hmm kind of. My body it's very delicate to certain things. For example, I'm unable to go directly into the sunlight."
    new "うーん、そうですね。私の体は特定のものに対してとてもデリケートで、例えば、直接日光に当たることはできません。"

    # say L1383 lad
    old "If I did, I would start suffering from strong allergic reactions. So, every time I go outside it has to be during the nighttime."
    new "もし直射日光に当たると、強いアレルギー反応が出てしまいます。なので、外出するときは必ず夜間にしています。"

    # say L1384 pla
    old "Ohh, so, is that why people think you're a vampire?"
    new "オッ、そうか。それが吸血鬼だと思われる理由なのか？"

    # say L1385 lad
    old "Well, that and my appearance, that's also the result of my disease."
    new "そうですね、それと私の外見も病気の結果です。"

    # say L1386 lad
    old "This amino acid helps with the creation of melanin, which is what gives colour to the skin."
    new "このアミノ酸はメラニンの生成を助けて、それが肌の色を決めるんです。"

    # say L1387 lad
    old "So I'm very white, and my eyes are pale."
    new "だから私はとても白くて、目も淡い色をしているんです。"

    # say L1388 pla
    old "Oh, I get it now."
    new "なるほど、今分かったよ。"

    # say L1389 lad
    old "Yeah, and I understand them, if somebody who looks like me it's only seen outside at night. And well... people talk..."
    new "そう、私みたいな人が夜に外に出るしかなくて…それに…人から噂されるのも仕方ないかしら。"

    # say L1391 pla
    old "But, it's not fair, I mean, you can't judge people just because of their appearance."
    new "でも、それは不公平だよ。人の見た目だけで判断するのはよくないよ。"

    # say L1392 lad
    old "Well, is not just that. The thing is, since I'm unable to produce this substance, I have to obtain it from a different source."
    new "そうですね、ただそれだけじゃありません。実のところ、この物質を自分で生産できないので、別の手段で手に入れなければなりません。"

    # say L1393 pla
    old "But you said you couldn't get it from food either..."
    new "でも君は食事からも取れないって言ってたよ..."

    # say L1394 lad
    old "That's right, I can't get it from food. But there's something else that can help me."
    new "そうです、食事からは得られません。でも、別のものがあります。"

    # say L1395 lad
    old "You see, for whatever reason I can actually receive the proteins that I need from semen."
    new "あなたが思う通り、私は食事からは必要なタンパク質を摂取できないんです。でも、精液からなら必要なタンパク質を受け取ることができるんです。"

    # say L1397 lad
    old "So, I made a deal with some men from town that were willing to help me. That sustained me for a while..."
    new "なので、町の男の人たちと取引をしました。それが一時期は私を支えてくれました…"

    # say L1398 pla
    old "Ohh, I see..."
    new "オッ、なるほど…"

    # say L1399 lad
    old "But the problem is that for whatever reason, when I touch a man, it has a very strong effect on them."
    new "でも、問題は、なぜか私が男性に触れるたびに、彼らにとても強い影響が出てしまうことです。"

    # say L1400 pla
    old "They caught the disease too?"
    new "彼らも感染したのか？"

    # say L1401 lad
    old "What? No, no, it's not that."
    new "何ですか、いいえ、そうではありません。"

    # say L1402 lad
    old "What I have is not contagious, but it does cause certain effects on men."
    new "私が持っているものは感染性はありませんが、男性には特定の影響を与えます。"

    # say L1404 lad
    old "So anytime one of them helped me. They would be very drained afterwards."
    new "なので、彼らが私を助けるたびに、その後はとても疲れきってしまうんです。"

    # say L1405 lad
    old "They ended up looking pale and famished. That's probably where the vampire myth mostly comes from."
    new "彼らは結局、顔色が悪く、飢えたような様子になりました。それが吸血鬼の伝説の大部分の由来だと思われます。"

    # say L1406 pla
    old "Oh, I understand..."
    new "なるほど、理解した。"

    # say L1408 lad
    old "And as you know, there is a very large religious community in this town."
    new "そしてご存知の通り、この町には大きな宗教コミュニティがあります。"

    # say L1409 lad
    old "Many women got worried that I would hurt their husbands, and even worse, that I would steal them."
    new "多くの女性が、私が夫を傷つけるだけでなく、さらには奪い取るのではないかと心配しました。"

    # say L1410 lad
    old "And seeing how tired the men were after helping me, the rumors began to circulate."
    new "そして、男の人が私を助けてくれた後で疲れ切っている様子を見た人々が、噂を広め始めたんです。"

    # say L1411 pla
    old "I see, I think I now understand better where the legend comes from."
    new "なるほど、伝説の出所が少しわかったような気がするな。"

    # say L1412 pla
    old "But still, your disease is no reason for them to be talking that way about you."
    new "でも、君の病気があんな風に噂される理由にはならないよ。"

    # say L1413 pla
    old "I'm sorry ma'am, because not only do you have to take care of your condition. You also have to deal with the town's scorn."
    new "すみません、お嬢さん。あなたの病気だけでなく、町の冷たい目も耐えなければならないなんて。"

    # say L1415 lad
    old "It's really nice of you to say that, thank you. But I'm used to it already."
    new "お優しいお言葉をありがとうございます。でも、もう慣れてますから。"

    # say L1416 lad
    old "The only thing that really affects me is that I haven't been able to get the protein I need as of late."
    new "最近、必要なタンパク質が摂取できていないことが、一番影響を受けています。"

    # say L1417 pla
    old "Wait, so does that mean nobody is helping you right now? So, how do you meet your protein needs then?"
    new "待て、つまり今誰も手伝ってくれてないってことなのか？じゃ、タンパク質の摂取はどうしてるんだ？"

    # say L1418 lad
    old "Hmm, not really, it is true that nobody comes here anymore. "
    new "Hmm、確かに最近は誰も来てくれないんです。"

    # say L1419 lad
    old "But I have a deal with the hospital, having a certificate for my condition allows me to receive some semen supplies from them."
    new "でも、私は病院と契約を結んでいます。私の状態の証明書があるおかげで、病院から精液の供給を受けることができます。"

    # say L1420 lad
    old "It all comes from donation to the sperm bank of the hospital. They give them to me because it's for the treatment of a medical condition."
    new "それは病院の精子バンクからの寄付です。医療上の理由での治療に使っているので、彼らはそれを私に提供してくれます。"

    # say L1422 pla
    old "Uhh, I see."
    new "うーん、なるほど。"

    # say L1423 lad
    old "It's not perfect, but it kind of works."
    new "それは完璧じゃないけど、まあ機能してるの。"

    # say L1424 lad
    old "So, you see now? Why do people believe in that legend? And where did those rumours start?"
    new "そう、今ならわかるでしょ？ なぜ人々がその伝説を信じるのか、そしてその噂はどこから始まったのか。"

    # say L1425 pla
    old "Yeah, I can see it now, but I don't think it's fair!"
    new "うん、今なら分かるけど、それって unfair じゃない？"

    # say L1426 lad
    old "You're right, it isn't, but that's how things are."
    new "そうです、不公平だけれど、それが現実のようです。"

    # say L1427 lad
    old "And at least now you know the truth and are willing to talk to me."
    new "少なくとも今では真実を知り、私と話すことをためらわずにくれるわ。"

    # say L1428 pla
    old "Hmm, actually... I don't know if you're ok with me saying this."
    new "Hmm、実際……君がこれを受け入れてくれるかどうか、ちょっとわからないんだ。"

    # say L1429 pla
    old "But I think I could do more than just listen to you."
    new "でも、ただ君の話を聞くだけでなく、もっとできることがあると思うんだ。"

    # say L1430 pla
    old "If you're ok with me doing it, I would like to help you."
    new "君がいいって言うなら、手伝いたいんだ。"

    # say L1432 pla
    old "I mean, you said that what you get from the hospital helps, but is not enough, right?"
    new "君が病院で受け取るものが役立つけど、足りないって言ってたよね？"

    # say L1433 pla
    old "So, I want to help you."
    new "じゃあ、君を助けるよ。"

    # say L1435 lad
    old "That's really nice of you to say, but I don't think you understand."
    new "それはとても優しい言葉だけど、あなたが私の状況を理解していないと思うの。"

    # say L1437 lad
    old "I told you that the men who helped me were very drained after doing it."
    new "あなたに言ったでしょう、私を助けてくれた男の人はその後とても疲れていたと。"

    # say L1438 pla
    old "Uhh... I mean, I could just do it in a cup or something and give it to you, right?"
    new "うーん……つまり、コップに入れて君に渡すって方法もあるのか？"

    # say L1439 lad
    old "Not really, you see, that's the problem with the sperm I get from the hospital."
    new "そうですね、問題なのは病院から得る精子のことです。"

    # say L1440 lad
    old "I don't only get what I need from the semen, but also from the contact with the penis."
    new "私は精液だけでなく、ペニスとの接触からも必要なものを得ているんです。"

    # say L1441 lad
    old "So if I only receive your semen, I won't be able to extract the necessary amount."
    new "だから、あなたの精液だけを受け取ったとしても、必要な量を抽出できないわ。"

    # say L1443 pla
    old "Well, I still think we can maybe do a small test and see how we do."
    new "まあ、小さなテストをしてみてどうなるか見てみようじゃないか。"

    # say L1444 lad
    old "I don't know. Are you sure?"
    new "私は少し不安ですが、本当に大丈夫なのでしょうか？"

    # say L1445 pla
    old "Yeah, I think so. I really want to help you in any way I can."
    new "うん、そう思ってる。君を助けるためなら何でもしたい。"

    # say L1446 lad
    old "Good, then I guess we can try testing how it goes."
    new "じゃあ、試してみましょう。"

    # say L1447 pla
    old "Great, so let's do it."
    new "じゃあ、やろう。"

    # say L1448 lad
    old "All right, then take out your pants."
    new "それじゃ、パンツを脱いで。"

    # say L1457 lad
    old "I must say I'm impressed young man."
    new "若き男、お見事ですね。"

    # say L1458 lad
    old "You got one of the biggest penises I have ever seen."
    new "あなたが持っているのは、私が今まで見た中で最も大きいペニスですね。"

    # say L1459 lad
    old "It's impressive."
    new "それはすごいですね。"

    # say L1460 pla
    old "Uhh... T- thank you ma'am... I guess."
    new "うっ、あの… ありがとう、お姉さん… まあ、そうですね。"

    # say L1472 pla
    old "It's good that you can feel better ma'am. I'll do it again if you need me to."
    new "奥様が気持ち良さそうにしてくださることは良いことです。必要ならまたやってあげますよ。"

    # say L1473 lad
    old "Hmm, you seem to be very fine. Normally when I do this with a man, they look very tired afterwards. I wonder if it's because of your age."
    new "うーん、あなたはとても元気そうね。普段、私が男性とこれをすると、その後とても疲れた顔をするのだけれど。あなたの年齢が関係しているのかしら。"

    # say L1475 pla
    old "I don't know what it may be. But I am a little tired. Maybe I should go home for today. But I'll come back to finish the roof."
    new "何だかわからないけど、ちょっと疲れたな。今日は家に帰るか。でも屋根の工事はまた来るよ。"

    # say L1476 lad
    old "Ok, just remember to drink a lot of water, and eat as much as you can."
    new "大丈夫、水分は十分取って、できるだけたくさん食べるようにしてくださいね。"

    # say L1477 lad
    old "You may not look tired, but I'm sure it must've had some effect on you. Be sure to rest."
    new "疲れはあまり見えないけど、きっと何かの影響があったはずよ。よく休んでね。"

    # say L1478 pla
    old "I'll do, don't worry. See you later Lady Dimitrescu."
    new "心配しないで、大丈夫だよ。後でね、レディ・ディミトリスク。"

    # say L1496 pla
    old "Good morning Lady Dimitrescu! I've come to continue repairing the roof."
    new "おはようございます、レディ・ディミトリスキューよ！ 屋根の修理を続けに来たんだ。"

    # say L1497 lad
    old "Good morning."
    new "おはようございます。"

    # say L1498 lad
    old "You know, I must say, you don't look very tired at all. Even though I'm certain I took a lot from you."
    new "あなたが思っているほど、私は疲れていませんわ。むしろ、あなたからかなりの力を取ったはずなのに、不思議と元気なのです。"

    # say L1500 pla
    old "(Hmm, I wonder if it's because of the magic power. Maybe it protected me from the effects.)"
    new "ん、魔法の力かもしれないな。多分それが影響から守ってくれたんだ。"

    # say L1501 pla
    old "I don't really know what to tell you, I actually don't feel bad at all."
    new "俺もよくわからないんだ、実は全然悪くない感じだよ。"

    # say L1502 lad
    old "This is a surprise. Are you sure you're ok to work on the roof today?"
    new "これは驚きですね。今日屋根で働くのは大丈夫ですか？"

    # say L1504 pla
    old "Yes, don't worry, I feel great, I'm going to get to it right away. So, I can finish it as soon as I can."
    new "心配しなくていい、調子は最高だ。すぐ始めよう。だから、できるだけ早く終わらせられると思う。"

    # say L1517 lad
    old "This is great! You really did it! Thank you so much, it's fantastic that you put in all this effort. "
    new "これは素晴らしいですね！本当にありがとう、こんなに頑張ってくださって。"

    # say L1518 lad
    old "It looks even better than it was before."
    new "それよりも前のはるかに良いわね。"

    # say L1519 pla
    old "I'm happy you like it ma'am. It makes all of that effort worth it."
    new "お嬢さん、喜んでいただけて嬉しいです。この労力も報われますね。"

    # say L1520 lad
    old "I don't know how to repay you."
    new "お礼の言葉を見つけられないわ。"

    # say L1521 pla
    old "Oh no, you don't need to pay me or anything. After all, I did the initial damage."
    new "ああ、そんなに気にするな。君が何か払う必要なんてないよ。結局、最初に壊したのは俺だしね。"

    # say L1522 lad
    old "Well, with this you have more than made up for it. Thanks again [pla]."
    new "まあ、これで十分に償っていただきましたね。またありがとう、[pla]。"

    # say L1523 pla
    old "Once again, I'm sorry for damaging your roof, and thank you for your patience. This took a while, but you never got angry with me."
    new "またしても屋根を壊して申し訳ないけど、我慢してくれてありがとう。時間がかかったけど、君は一度も怒らなかったな。"

    # say L1525 lad
    old "Ohh, I wouldn't get angry."
    new "あら、私は怒るようなことはないわ。"

    # say L1526 lad
    old "As I told you, at this point I'm used to people just trying to take a peek into my house, so I was just annoyed when it happened"
    new "私が言った通り、このあたりでは人が私の家を覗こうとするのは珍しくないから、実際に起こったときは少しイラついただけよ。"

    # say L1527 lad
    old "But you've proven to me that you're a stand up young man. I'm happy I got to meet you."
    new "でも、あなたは立派な若者だと証明してくれました。出会えてうれしいです。"

    # say L1528 pla
    old "Thank you ma'am, if there's anything else I can do for you, please tell me. I'm more than happy to do it."
    new "ありがとうございます、奥さん。他に何かお手伝いできることがありましたら、何でもおっしゃってください。喜んでお手伝いします。"

    # say L1529 lad
    old "Well... Now that you mention it, there might be..."
    new "ええ……そう言われると、何かあるかもしれませんね。"

    # say L1530 pla
    old "Really? If that's the case, please tell me. I'll do my best to help you."
    new "本当に？その場合は教えてくれ。全力で手伝うよ。"

    # say L1531 lad
    old "You see, since you don't seem to be at all affected about the help you already gave me. I was wondering if I can ask for your help again."
    new "実は、あなたがすでに私にくれた手伝いについては全然気にしていないように見えたので、もう一度あなたの手伝いを求めてもよいかと考えていました。"

    # say L1532 lad
    old "But this time it might be a little different."
    new "でも今回は少し違うかもしれません。"

    # say L1534 pla
    old "Different? How?"
    new "違う？どう違うんだ？"

    # say L1535 lad
    old "Let me explain, I can assimilate a lot through my digestive system, but the most efficient way of taking in the protein content is through my uterus."
    new "説明させてください、私の消化システムは多くのものを吸収できますが、タンパク質を最も効率的に摂取する方法は子宮を通じてです。"

    # say L1536 lad
    old "Because that way my body can absorb it better."
    new "その方法だと、体がより効率的に吸収できるからです。"

    # say L1537 pla
    old "Wow, does that mean you have to have sex with me?"
    new "Wow、つまり俺とセックスしないとダメってことなのか？"

    # say L1538 lad
    old "Well, only if you are okay with that, of course."
    new "もちろん、あなたがよろしければですが。"

    # say L1540 pla
    old "Hmm... Well, if that actually helps you, and it's better for you, sure."
    new "うーん……まあ、それが君の役に立つなら、君にとって良いことなら、もちろんいいよ。"

    # say L1541 pla
    old "After all, I did promise I would help you. didn't I?"
    new "結局、君を助けるって約束したじゃないか。"

    # say L1542 lad
    old "Perfect! Thank you so much!"
    new "ありがとうございます！本当に助かりました。"

    # say L1543 lad
    old "Hmm, come with me to the stairs..."
    new "Hmm、階段まで来ましょう..."

    # say L1559 lad
    old "That was fantastic, thank you! You have no idea how much you help me."
    new "それは素晴らしいでした、ありがとうございます！あなたがどれだけ助けてくれているか、私には想像もつきません。"

    # say L1560 pla
    old "I'm happy to help... and to be honest I enjoyed it too."
    new "手伝えて嬉しい…正直、俺も楽しんでるんだ。"

    # say L1561 lad
    old "It's very interesting that you don't get tired at all doing this with me."
    new "あなたとこんなことをしているとき、全然疲れを感じないのがとても興味深いわ。"

    # say L1562 lad
    old "Maybe that could be of help..."
    new "もしかしたら、それが役に立つかもしれないわね。"

    # say L1563 pla
    old "Uhh, what do you mean?"
    new "うーん、何を意味してるの？"

    # say L1564 lad
    old "Well, there's something I must let you know."
    new "まあ、あなたに伝えるべきことがあります。"

    # say L1567 lad
    old "Do you remember what you told me about the night you fell in here? That you saw me with two other girls?"
    new "あなたがここに落ちてきた夜に、私と他の二人の女の子を見たと言ったことを覚えてる？"

    # say L1568 pla
    old "Yeah, the girls from my dream."
    new "そうだ、君が夢で見た女の子たちのことだ。"

    # say L1570 lad
    old "Well, actually they're my daughters. Or at least that's what I call them."
    new "実は彼女たちは私の娘たちなの。少なくともそう呼んでいるの。"

    # say L1571 lad
    old "You see, years ago I found out I'm not the only person with my condition."
    new "実は、何年も前に私のような状態の人々が他にも存在することを知りました。"

    # say L1572 lad
    old "There are some other people, and I decided to help them. That's why I have this mansion, to receive people like me, and give them a hand."
    new "他にも同じような人がいて、私は彼らを助けることに決めました。だからこの屋敷があるんです。私と同じような人を受け入れて、手を差し伸べられるようにしています。"

    # say L1573 pla
    old "Really? So, you live with several people here? I haven't seen them."
    new "本当に？じゃあ、ここには複数の人と暮らしてるんだ？会ったことないんだけど。"

    # say L1574 lad
    old "Right now it's only me and my two daughters. With the years some have come and go."
    new "今は私と娘二人だけです。年月とともに何人かは来たり行ったりしました。"

    # say L1575 lad
    old "We communicate with each other every time anyone finds anything that can help us."
    new "誰かが何か役立つものを見つけたら、お互いに連絡を取り合っています。"

    # say L1576 pla
    old "Oh, it's a very nice gesture of you that you take people in and help them. You really are a good person."
    new "君が人を助けて受け入れる姿勢は本当に素晴らしいね。本当に良い人だな。"

    # say L1578 lad
    old "Thank you, I'm glad you think that about me."
    new "ありがとうございます、そう思っていただけるのはうれしいです。"

    # say L1579 lad
    old "And yeah, we help each other cope with the condition. And since it's such a rare thing, it's really useful that we are all close to each other."
    new "そして、お互いにその状態と上手く付き合っていくために助け合っています。そんなに珍しいことだから、みんなが近くにいられるのは本当に役立ちます。"

    # say L1580 lad
    old "And you see, since you've now been able to help me twice, and don't seem to be affected..."
    new "そして、あなたがすでに二度も私を助けてくれて、影響を受けている様子がないので……"

    # say L1581 lad
    old "I was wondering if you could also help my two daughters."
    new "あなたが私の二人の娘にも手伝ってくださるかどうか、考えていました。"

    # say L1583 pla
    old "Oh! I see."
    new "ああ、わかった。"

    # say L1584 lad
    old "I would love it if you could. They could really use your help to improve their health."
    new "喜んでお手伝いさせていただきます。娘たちの健康のためにも、ぜひお力添えいただきたいです。"

    # say L1585 pla
    old "Well, I think that if I really did help you treat your condition. I don't see why it couldn't do it for you daughters."
    new "まあ、君の病気を治す手伝いをするなら、娘たちにも同じ効果があると思うけど、問題ないよね。"

    # say L1586 lad
    old "You're an angel. Then I'll talk to them, so that you can help them as soon as possible."
    new "あなたは天使ですね。それでは、私が彼女たちと話をして、あなたが彼女たちを手伝うことができるよう arrangements を整えましょう。"

    # say L1587 lad
    old "Is that ok with you?"
    new "それはよろしいでしょうか？"

    # say L1589 lad
    old "All right, have a good night [pla]."
    new "はい、おやすみなさい [pla]。"

    # say L1590 pla
    old "Good night to you too, Lady Dimitrescu."
    new "おやすみなさい、レディ・ディミトリスカ"

    # say L1613 pla
    old "Good morning ma'am, I'm here to help you as we talked before."
    new "おはようございます、ご婦人。先ほど話した通り、お手伝いに参りました。"

    # say L1614 lad
    old "Good morning. I'm happy to see that you actually came."
    new "おはようございます。実際に来てくれて嬉しいです。"

    # say L1615 lad
    old "Allow me to introduce you to my daughters. These are Bela and Daniela."
    new "私の娘たちを紹介させていただきます。こちらがベラとダニエラです。"

    # say L1616 lad
    old "This is [pla] he's the one I've told you about and has come to help us with our condition."
    new "これは [pla] です、私が話していた通りで、私たちの状態を手伝ってくれるために来た方です。"

    # say L1618 bela
    old "H- hi. I'm Bela, nice to meet you."
    new "はーい、こんにちは。ベラです、どうぞよろしく。"

    # say L1620 dan
    old "Hello, I'm Daniela, mother has told us about you, and what you're able to do for us. Thank you very much for coming."
    new "こんにちは、私はダニエラです。母からあなたについて、そして私たちのためにできることが聞きました。来てくださって、本当にありがとうございます。"

    # say L1621 pla
    old "N- nice meeting you. I'm [pla], happy to be of help."
    new "N- はじめまして。俺は[pla]、お力になれてうれしいです。"

    # say L1622 lad
    old "Well, now that the introductions are over, I think it's best if we start."
    new "それでは、挨拶も終わったことだし、早速始めましょう。"

    # say L1623 pla
    old "Uhh... Right now? And just like that?"
    new "うーん… 今すぐ？ そうなのか？"

    # say L1624 lad
    old "Well, have in mind my daughters really needs it, and we use to do it in the past with other guys..."
    new "まあ、私の娘たちは本当に必要としているのよ、かつて他の男性たちと一緒にやっていたこともあるの..."

    # say L1625 lad
    old "So, don't worry, just relax, and let us do all for you."
    new "だから、心配しないで、リラックスして、全部私たちがやってあげるから。"

    # say L1633 lad
    old "Mmmm, look at that, you're already in the mood for it..."
    new "ねぇ、見て、もうそんな気分になっちゃってるのね…"

    # say L1634 dan
    old "Oh wow! Look at what you're packing there."
    new "あら、すごい！そこはそんなに大きいのね。"

    # say L1636 lad
    old "Daniela darling, please, you don't have to be this forward."
    new "ダニエラ darling、お願いだから、そんなに積極的になる必要ないわ。"

    # say L1637 bela
    old "But mother, it is true that's an impressive size."
    new "でも母さん、それは本当に立派なサイズだわ。"

    # say L1638 lad
    old "Hehe, we can't deny that..."
    new "へへ、それは否定できないわね。"

    # say L1639 lad
    old "But remember, we're doing this for a reason, so control yourselves."
    new "でもね、理由があるのだから我慢しようね。"

    # say L1640 dan
    old "Yes, mother."
    new "はい、母さん。"

    # say L1642 lad
    old "Now, I think we've talked enough."
    new "では、話すのは十分だったと思うわ。"

    # say L1643 lad
    old "Are you ready [pla]?"
    new "準備はできましたか、[pla]？"

    # say L1662 lad
    old "By the way, how are you feeling [pla]?"
    new "それともう一つ、[pla]、お体の方はどうですか？"

    # say L1663 pla
    old "Well, to be honest I'm a little tired. But it's nothing a nap and some food won't fix. I'll be ok."
    new "正直ちょっと疲れてるけど、寝て食事を取れば治るよ。大丈夫だ。"

    # say L1664 lad
    old "I must admit your endurance is astounding."
    new "あなたの持久力は本当に驚異的ですね。"

    # say L1665 lad
    old "But I'm happy you're fine."
    new "でも、あなたが大丈夫で安心しました。"

    # say L1666 pla
    old "And I'm happy I can be of help to you all."
    new "みんなのために手伝えるのが嬉しいよ。"

    # say L1670 dan
    old "Honestly, our health had been going down due to not being able to get enough semen for all three of us."
    new "正直に言うと、私たちの健康状態は、三人分の精液を得られずに悪化していました。"

    # say L1671 dan
    old "And even if the hospital donated more, it's not the same thing as receiving it directly from a person."
    new "病院がもっと提供しても、直接人から受け取るのと同じではないです。"

    # say L1672 pla
    old "Hmm, does that mean that if no one else helps you, you'll be in trouble again?"
    new "ん、つまり他の誰も手伝ってくれなければ、また困るってことなのか？"

    # say L1673 lad
    old "Sadly it does."
    new "残念ながらそうです。"

    # say L1674 pla
    old "Then I'll be sure to come back again and help you. I'll do it as many times as you need me to."
    new "じゃあまた戻ってきて手伝うよ。君が必要なだけ、何度でもやってあげる。"

    # say L1676 lad
    old "Hmm are you sure? I understand that one time is something. But if you do too many times it might affect you."
    new "うーん、本当に大丈夫？　一度ならまだしも、何度もやると体に影響が出るかもしれないわ。"

    # say L1677 pla
    old "I think I could keep helping you some more, given that so far I haven't had any negative reaction."
    new "君のために更に手伝い続けるのはできると思うよ、これまで何の悪反応もなかったからね。"

    # say L1678 pla
    old "So you can count on me."
    new "じゃあ、俺に任せとけ。"

    # say L1679 lad
    old "Aww, you're an angel. Well then, when we need it, we'll be sure to call you on."
    new "あら、あなたは天使ですね。それでは、必要になったら、必ずあなたに連絡しますわ。"

    # say L1697 pla
    old "Hi Lady Dimitrescu."
    new "こんにちは、Lady Dimitrescu。"

    # say L1698 lad
    old "Oh, hi [pla], it's always nice to see you."
    new "あら、こんにちは[pla]、会えて嬉しいわ。"

    # say L1699 lad
    old "How can I help you today?"
    new "今日は何をお手伝いしましょうか？"

    # menu L1703 
    old "Help them again"
    new "また手伝おうか"

    # say L1705 pla
    old "Well, I have been thinking about helping you again."
    new "まあ、また君を助けることについて考えていたんだ。"

    # say L1706 lad
    old "Oh, have you come help us with our protein needs?"
    new "おお、私たちのタンパク質の需要を手伝いに来てくれたの？"

    # say L1707 pla
    old "That's right, I thought you might need it."
    new "そうだ、君たちが必要かもしれないと思ったんだ。"

    # say L1708 lad
    old "That's perfect, you came at just the right moment."
    new "それが良かったわ、ちょうど良いタイミングで来てくれました。"

    # say L1709 lad
    old "Let me call the girls."
    new "女の子たちを呼びに行きますね。"

    # say L1728 bela
    old "Hi [pla]! How are you?"
    new "こんにちは、[pla]！元気ですか？"

    # say L1729 pla
    old "I'm fine, thank you, I came to see if you needed my help today."
    new "元気だ、ありがとう。今日手伝う必要があるかどうか見に来たんだ。"

    # say L1730 dan
    old "Yeah, mother told us."
    new "うん、母が教えてくれたって。"

    # say L1764 pla
    old "What?! Oh no, sorry, I was just a little distracted."
    new "何？！ああ、ごめん、ちょっと集中力が途切れてたんだ。"

    # say L1766 lad
    old "Hmm, I see, well, be careful on the way back."
    new "はい、わかりました。お帰りの際は気をつけてくださいね。"

    # say L1767 pla
    old "Yes ma'am, bye."
    new "はい、おばさん、さようなら。"

    # say L1770 pla
    old "Oh, sorry, I was just passing by."
    new "あ、すみません、ただ通りがかりでした。"

    # say L1771 lad
    old "Hmm, I see, well, make sure you come when you have some free time."
    new "なるほど、そうですね。空いているときにはまたお越しくださいね。"

    # say L1772 pla
    old "Yes ma'am, of course. See you later."
    new "はい、もちろんです。またね。"

    # say L1773 lad
    old "Bye, take care."
    new "さよなら、気をつけてね。"


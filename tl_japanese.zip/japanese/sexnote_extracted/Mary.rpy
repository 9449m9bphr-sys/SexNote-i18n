# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Mary.rpy
translate japanese strings:

    # say L40 mar
    old "Oh [pla]! To what do I owe your visit? Are you coming to get a checkup?"
    new "あら [pla]！何の用事で来たの？診察に来たの？"

    # say L45 pla
    old "Well... Yes... You told me that."
    new "まあ……そうだな……君がそう言ったから来たんだ。"

    # say L47 mar
    old "Don't worry, boy. I'm here to take care of your health. As many times as you need... Come on, get on the table."
    new "心配しないで、男の子。あなたの健康のこと、私がちゃんと見守るから。必要なだけ何回でも…さあ、テーブルに上りなさい。"

    # say L60 pla
    old "Oh, no, I was just leaving. I'm sorry ..."
    new "ああ、いや、実は帰ろうとしてたんだ。すみません……"

    # say L62 mar
    old "Okay, if you need a checkup again, you know where to find me..."
    new "また検診が必要になったら、私を訪ねてくださいね..."

    # say L64 pla
    old "Ok, thank you..."
    new "ありがとう、そうさせていただきます..."

    # say L117 mo1
    old "Hello, Nurse Mary. Good morning."
    new "看護師マリー、おはようございます。"

    # say L120 mar
    old "Good morning! How are you today?"
    new "おはようございます！今日はお元気ですか？"

    # say L122 mo1
    old "Very well, thank you..."
    new "ありがとうございます、マリーさん。元気ですよ。"

    # say L124 mar
    old "And what about you, boy?"
    new "あなたは元気ですか、男の子？"

    # say L126 pla
    old "I'm fine, too. Thank you..."
    new "俺も元気だよ。ありがとう..."

    # say L128 mar
    old "He's very quiet, huhm?"
    new "彼はとても静かですね、そう？"

    # say L130 mo1
    old "He's a bit shy..."
    new "彼は少し恥ずかしがり屋さんですね..."

    # say L133 mar
    old "Haha... Well, let's get to the matter at hand... First, take off your clothes."
    new "ははは……それでは、本題に入りましょう……まずは服を脱いで。"

    # say L139 mar
    old "Ok... Ok... I really don't feel much... I think I'm going to need a second opinion..."
    new "うん… うん… 全然感じないわ… 二つ目の意見が必要かもしれないわね…"

    # say L140 mo1
    old "Another practitioner?"
    new "別の専門家？"

    # say L141 mar
    old "Oh, no. That's not necessary... You! Boy. Come here..."
    new "あら、いいのよ。それは必要ないわ… あなた！男の子。ここに来なさい…"

    # say L143 pla
    old "...I... But I..."
    new "...俺...でも...それなら..."

    # say L144 mar
    old "Come on, come here... This is for the health of your [mo1rel]."
    new "さあ、こっちに来て… これはあなたの[mo1rel]の健康のためだよ。"

    # say L146 pla
    old "In that case..."
    new "そのなら"

    # say L147 mar
    old "I know very well that you saw the massage I was giving her... Because you did not take your eyes off of her..."
    new "あなたが彼女にマッサージを受けさせてるのを見てたこと、よくわかってるわ... 目を離さなかったでしょ..."

    # say L149 pla
    old "I... I... Wasn't-"
    new "俺… 俺… 見てなかったよ-"

    # say L150 mar
    old "The idea is to do the same thing I'm doing, but you do it this time, alright?"
    new "同じことをやってみるの、今度はあなたがね、いいわね？"

    # say L152 pla
    old "Oh, ok, I will try..."
    new "オッケー、試してみるよ…"

    # say L153 mo1
    old "But, nurse, is it okay that-"
    new "でも、看護師さん、これで本当に大丈夫でしょうか-"

    # say L154 mar
    old "Don't worry, I know what I'm doing, ok?"
    new "大丈夫、私がちゃんとできるから、心配しないでね。"

    # say L155 mo1
    old "Yes, Nurse Mary..."
    new "はい、マリーさん…"

    # say L162 mar
    old "Let's see... put your hands here, cover her breasts well..."
    new "まずは……手をここに置いて、彼女の胸をしっかり覆うように……"

    # say L163 mar
    old "Very well..."
    new "はい、わかりました…"

    # say L164 mar
    old "Now... Start massaging them gently..."
    new "それじゃあ……優しくマッサージしてあげて……"

    # say L165 pla
    old "(Oh shit!)... Uhh... But..."
    new "（しまった！）…うーん…でも…"

    # say L166 mar
    old "You already have your hands on, just move them a little, kid..."
    new "もう手をつけてるんだから、ちょっと動かしてみて、子供さん…"

    # say L170 mar
    old "How do they feel, huh?"
    new "どう感じる？"

    # say L171 pla
    old "Hmm... Very soft... Warm..."
    new "うーん… とても柔らかい… 温かい…"

    # say L172 mar
    old "Very well... Now, rub a little harder, focus on sensing if you feel anything strange..."
    new "とてもいいわ… それじゃ、もう少し強くこすって、何か変な感じがないか集中してみて…"

    # say L176 pla
    old "Well... I really don't feel anything..."
    new "WELL... 僕は全然何も感じないんだ..."

    # say L177 mar
    old "Well, I think I feel better with that second opinion... However, come for the last appointment on Thursday, do you think that's okay?"
    new "WELL、その二度目の意見で少し楽になったと思います… しかし、木曜日の最後の診察に来ていただけますか？"

    # say L178 mo1
    old "It's fine with me, Nurse Mary."
    new "私にはかまいません、Maryさん。"

    # say L180 mar
    old "...But young man, you can now take your hands off those tits."
    new "でも、若者さん、そのおっぱいから手を離してもいいですよ。"

    # say L187 pla
    old "Sorry... I didn't-"
    new "すみません… 意識しすぎて手が離れなかったです…"

    # say L189 mar
    old "Hahaha, I'm just kidding... I think we have a future doctor standing here..."
    new "ははは、冗談よ……ここに立っているのは将来の医者かもしれないわね……"

    # say L191 mo1
    old "Haha. Yes, [pla] is a very good boy..."
    new "ははは、そうですわ、[pla]はとても良い子ですね…"

    # say L193 mar
    old "Well, until the next appointment, it was nice to see you!"
    new "それじゃ、次回の診察まで、また会えて良かったわ！"

    # say L195 mo1
    old "You too, Nurse Mary."
    new "あなたも、Maryさん。"

    # say L197 mar
    old "See you later, boy..."
    new "またね、坊や…"

    # say L199 pla
    old "See... you... too."
    new "また……ね……君も。"

    # say L211 mo1
    old "Hello, Nurse Mary! Good morning."
    new "こんにちは、ナースマリー！おはようございます。"

    # say L214 mar
    old "Oh, hi, How are you today?"
    new "おはよう、元気ですか？"

    # say L216 mo1
    old "Very well, thank you."
    new "元気ですよ、マリーさん。ありがとうございます。"

    # say L223 mar
    old "Well, let's take the final exam, and if we still can't identify it, I already have a solution planned. So let's start... now, take off your clothes."
    new "WELL、最終試験を受けましょう。それでも特定できないなら、すでに解決策を用意してあるわ。それじゃ、始めましょう… さあ、服を脱いで。"

    # say L228 mar
    old "Hmm... Very well... I think we will definitely need another method..."
    new "うーん… 仕方ない… 確実に別の方法が必要そうね…"

    # say L229 mo1
    old "Are you going to need the help of [pla] again?"
    new "[pla]の助けが必要になるんですか？"

    # say L230 mar
    old "Maybe later... For now, I'm going to need you to take off your bra."
    new "後で必要になるかもしれないけど… 今はブラを外してもらわないといけないの。"

    # say L233 pla
    old "Uh, well... I think I'm gonna go on and head out..."
    new "うーん、まあ……俺は帰るかな……"

    # say L234 mar
    old "Come on... You have already grabbed her tits, what is the problem to see them now without a bra? You have to be more professional, [pla]..."
    new "Come on... あなたはもう胸を触っちゃってるんだから、ブラを外して見せるくらい何の問題があるの？もっとプロらしくなきゃ、[pla]..."

    # say L237 mar
    old "Well, what are you waiting for, take off your bra..."
    new "さあ、何を待っているの、ブラを脱いで..."

    # say L238 mo1
    old "Yes, Nurse..."
    new "はい、看護師さん..."

    # say L241 mar
    old "That's what I'm talking about... much better..."
    new "それが私 Want to say... ずっといい感じだよ..."

    # say L242 mar
    old "Now I can feel every detail better..."
    new "今、細部までよりよく感じられるわ..."

    # say L243 mar
    old "Hmm... I'm going to do it harder..."
    new "うーん……もっと強くするね……"

    # say L246 mar
    old "Well, I really don't feel anything... But I wouldn't want to get carried away. So it's your turn give me your impression, [pla]."
    new "WELL、全然何も感じないわ… でも、やりすぎるのは嫌だから。だから、あなたの感想を聞かせてちょうだい、[pla]。"

    # say L249 mo1
    old "Mary, do you really think it is-"
    new "マリー、本当にそう思うの？"

    # say L250 mar
    old "You guys are so dramatic. Haha. It's just the human body. You have done this before with a bra."
    new "あなたたちって大げさね。ハハ。ただの人間の体よ。ブラジャーつけてたときもやったことあるでしょう。"

    # say L251 mar
    old "There is no big difference now. You do not have to sexualize everything, you know."
    new "今さらそんなに大げさにする必要ないわ。前にブラジャーだってやったことがあるんだから。性欲の対象にしなくてもいいのよ。"

    # say L252 mo1
    old "Ok, ok, Nurse Mary. If you insist..."
    new "はい、はい、メアリーさん。あなたがそう言うなら…"

    # say L253 mar
    old "Let's see now. Do the massages again..."
    new "それじゃ、またマッサージしてみようか…"

    # say L260 mar
    old "That's it, nice... your hands cover her breasts well..."
    new "そう、いいわ… 手で彼女の胸を覆うのが上手ね…"

    # say L263 mar
    old "Start massaging them gently..."
    new "優しくマッサージしてみて…"

    # say L264 mar
    old "Very well... You can feel them better, right?"
    new "よし…もっと感じやすくなるでしょ？"

    # say L265 pla
    old "...Y-Yes ... (Fuck, I'm getting hard)"
    new "…うん…（くそ、硬くなってきちゃってる）"

    # say L266 mar
    old "Very well... Rub a little harder, focus on seeing if you feel anything strange..."
    new "よし…少し強くこすって、何か変な感じがしないかどうか集中してみて。"

    # say L269 pla
    old "Yes, ma'am..."
    new "うん、分かった…"

    # say L270 pla
    old "Well... I don't really feel anything strange..."
    new "WELL... 特に変な感じはしないな..."

    # say L271 mar
    old "Well, I think that's definite. My final medical verdict is that these babies are in perfect condition... Make sure you take care of them, please."
    new "WELL、私はそれが確定だと思います。最終的な診断結果は、これらの赤ちゃんたちが完璧な状態ということです… ちゃんと面倒を見てくださいね。"

    # say L272 mo1
    old "You bet, Nurse Mary..."
    new "はい、マリーさん、ありがとうございます…"

    # say L273 mar
    old "Hey... [pla]... thanks for your commitment, but we're done here..."
    new "へえ… [pla]… ご尽力ありがとうございますけど、ここでは終わりにしましょうね…"

    # say L274 pla
    old "Oh, right, sure... Sorry again..."
    new "ああ、そうか… またすみませんね…"

    # say L284 mar
    old "Well, I think that's it..."
    new "WELL、これで終わりだね…"

    # say L286 mar
    old "Wait a second... What do you have there?"
    new "ちょっと待って… それ何持ってるの？"

    # say L288 pla
    old "(Oh god no...)"
    new "（ああ神、お願い…）"

    # say L291 mar
    old "Oh boy, is that all yours?"
    new "おわ、それ全部あなたのものなの？"

    # say L293 mar
    old "Hmm... I think this is abnormal... Has a doctor checked you out yet?"
    new "へえ……これは異常だと思わない？　まだ医者に診てもらったことないの？"

    # say L295 pla
    old "...Well, umm, no."
    new "うーん、まだだよ。"

    # say L297 mar
    old "Well, it's time to do it, [pla]..."
    new "まあ、そうなるわね、[pla]…"

    # say L300 mar
    old "Take off all your clothes, young man. I'm going to do a full-body exam..."
    new "服全部脱いで、若者。全身チェックするから…"

    # say L302 pla
    old "Now? But... I-"
    new "今？でも…"

    # say L304 mar
    old "But nothing! You don't see that this could be a health problem?... It is always best to examine it to make sure there is no issues."
    new "でも何もかも脱ぐ必要があるわけではないわ。これって健康上の問題かもしれないのに気づいてないの？... ちゃんと調べて、何か問題がないかどうか確認することが一番よかと思います。"

    # say L307 mo1
    old "I  will go out then, Mary..."
    new "では、私は出かけるわ、Mary..."

    # say L310 mar
    old "Really? He got to see your goods and now you are shy to see his?... Again, it's just a medical procedure. There's no need to freak out about it."
    new "本当に？彼のモノを見せてもらったのに、今度は君が見るのが恥ずかしいの？…また、これはただの診察だよ。そんなに緊張する必要はないわ。"

    # say L312 mo1
    old "Ok, nurse..."
    new "わかりました、ナースさん…"

    # say L319 mar
    old "Well... I see your whole body is normal, except your penis."
    new "WELL... 君の体は全部正常ね、ただペニスだけが少し特殊な感じよ。"

    # say L321 mar
    old "I mean, for your age, it is normal to have hard erections. But I think you have a lot of tension built, much more than normal actually."
    new "つまり、あなたの年齢では硬い勃起があるのは普通のことです。でも、あなたは通常よりもずっと多くの緊張を抱えていると思います。"

    # say L323 mar
    old "Also, your size is not at all common... So I need to relax it in order to evaluate it better..."
    new "それに、あなたのサイズは全く普通じゃないですね… なので、リラックスさせてから、より正確に評価する必要があるの…"

    # say L324 pla
    old "...Wha-what do you mean?"
    new "何それ？"

    # say L326 mar
    old "It means I'm going to massage it until it is in a relaxed, flaccid state..."
    new "それは、リラックスした状態、つまりしぼんだ状態になるようにマッサージするってことよ…"

    # say L337 mar
    old "Let's see... I'm going to massage it like this..."
    new "じゃあ、こうやってマッサージしていくわ…"

    # say L338 mar
    old "How does it feel, boy?"
    new "どう感じるの、ボーイ？"

    # say L339 pla
    old "... It feels... really good."
    new "感じが... 本当にいいな。"

    # say L356 mar
    old "Let's do it a little faster..."
    new "もっと速くしてみて"

    # say L365 pla
    old "Nurse... I'm going to..."
    new "看護師…出しちゃうよ…"

    # say L367 mar
    old "That's it... Let it out, [pla]. Relax your body."
    new "そうそう… 出して、[pla]。体をリラックスさせて。"

    # say L369 mar
    old "Wow, that was quite the show... Well, I don't see anything that can affect your overall health..."
    new "すごいわね、その様子... でも、全体的な健康には問題なさそうね..."

    # say L376 mar
    old "However, I am prescribing that you do these massages anytime you feel tension..."
    new "しかし、緊張を感じたらこれらのマッサージをしてくださいね。"

    # say L378 pla
    old "...Ok, Nurse Mary..."
    new "…わかった、Maryさん…"

    # say L381 mo1
    old "Thank you very much, Mary, for helping us both..."
    new "ありがとうございます、Maryさん。私たち二人のために助けてくれて..."

    # say L383 mar
    old "It's a pleasure, Sue. Well, that's it. If you need me again you know where to find me..."
    new "すえさん、喜んでです。それじゃ、また必要になったら連絡してくださいね..."

    # say L385 mo1
    old "Okay, see you later,Mary..."
    new "では、またね、Maryさん。"

    # say L387 pla
    old "See you later..."
    new "また会うな、マリーさん。"

    # say L389 mar
    old "You can bet it."
    new "もちろん、また会うわね。"

    # say L407 mar
    old "Well, I see you're still in perfect health... That was all for now..."
    new "WELL、元気そうで何よりだね… これで今回は終わりだけど…"

    # say L413 mar
    old "If you need a checkup again, you know where to find me..."
    new "また検診が必要になったら、いつでも来てね。"

    # say L415 pla
    old "Ok, thanks..."
    new "分かった、ありがとう…"


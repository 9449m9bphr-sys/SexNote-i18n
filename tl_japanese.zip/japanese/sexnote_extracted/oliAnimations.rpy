# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/oliAnimations.rpy
translate japanese strings:

    # say L6 aye
    old "Oh yeah, sis! Woohoo!"
    new "おっ、姉さん！ワーイ！"

    # say L7 aye
    old "I can tell how good you are at this!"
    new "お前がこれだけ上手いのはわかるよ！"

    # say L8 aye
    old "Look at that huge cock filling your mouth!"
    new "その大きなちんこがあなたの口にいっぱい入ってるのを見てごらん！"

    # say L12 aye
    old "I know you like it, sis!"
    new "お前、気に入ってるだろう、姉さん！"

    # say L13 aye
    old "With how big his cock is, I'd say you chose well!"
    new "そのデカいちんこを見ても、姉さんよく選んだな！"

    # say L14 aye
    old "Look at you go to town on that monster cock!"
    new "お前、そのデカチ○ポに夢中だな！"

    # say L18 aye
    old "How about you, brother-in-law? Do you like it?"
    new "お前はどうだ、義兄さん？気に入ったか？"

    # say L19 aye
    old "Come on, tell me! Don't leave me hanging!"
    new "さあ、教えて！ 待たせないでよ！"

    # say L20 oli
    old "Slrrp, j- just answer her!"
    new "スルッ、じ、答えてよ！"

    # say L22 aye
    old "Haha! Oh yeah!"
    new "ははは！そうだったか！"

    # say L45 pla
    old "O- Olivia! I- I'm about to cum!"
    new "オ- オリビア！俺- 俺、出ちゃうよ！"

    # say L46 aye
    old "Yeah! Cum in her mouth! Come on!"
    new "よし！彼女の口に射精しろ！さあ！"

    # say L47 aye
    old "I want to see that!"
    new "見せてよ！"

    # say L48 oli
    old "I- it's alright, just let it out!"
    new "大丈夫よ、そのまま出しちゃって！"

    # say L55 aye
    old "Oh my gosh look at how much you came!"
    new "おわせえ、これだけ出たか見てみ！"

    # say L56 aye
    old "That's amazing!"
    new "すごいな！"

    # say L57 aye
    old "I have to say, sis, this guy may not look like much."
    new "俺が言うなら、姉さん、この男、見た目以上だよ。"

    # say L58 aye
    old "But he is certainly well gifted."
    new "でも、確かに彼はよく endowed しているよ。"

    # say L59 oli
    old "Oh shut up, just let me clean up and leave us alone."
    new "あら、黙っててよ、掃除した後で私たちを一人にさせてくれればいいのに。"

    # say L71 oli
    old "Oh, wow... Your cock is getting even harder..."
    new "あら、すごい… あなたのち○こ、もっと硬くなってきているのね…"

    # say L72 oli
    old "It feels soft and warm though."
    new "でも柔らかくて温かいわね。"

    # say L73 oli
    old "Does my hand feel good?"
    new "手の感じ、いい？"

    # say L74 pla
    old "Yes, it feels really nice..."
    new "うん、本当に気持ちいい..."

    # say L78 oli
    old "To be honest, it's the biggest I've ever seen..."
    new "正直、見た中で一番大きいわ..."

    # say L80 oli
    old "I mean, it's pretty impresive..."
    new "つまり、かなりすごいよね…"

    # say L83 oli
    old "I'll do it a little faster..."
    new "ちょっと速くしてみるね…"

    # say L84 oli
    old "Is that okay?"
    new "いいの？"

    # say L85 pla
    old "Uhh, s- sure..."
    new "うーん、す、 sûrê..."

    # say L110 oli
    old "Ok, I think that's enough... I don't want you to waste your cum..."
    new "うん、これで十分だと思う… 浪費したくないからね…"

    # say L111 oli
    old "I mean, I need your sperm, you know the idea is to get pregnant..."
    new "あのね、あなたの精子が必要なの、妊娠するためだからね…"

    # say L112 pla
    old "Uhh, yeah, you're right..."
    new "うーん、そうか、君が言う通りだ…"

    # say L113 oli
    old "Alright, I'm going to take off my pants and get on the edge of the bed. I guess you know what to do..."
    new "じゃあ、パンツを脱いでベッドの端に座るから、後は君が分かるよね…"

    # say L119 pla
    old "Uhh, yeah, of course..."
    new "うーん、もちろん、そうだよ…"

    # say L136 oli
    old "Uhh, your cock is so big, so, I'm going to ask you to please be gentle..."
    new "うーん、あなたのチ○ポ这么大、だから、優しくしてほしいな…"

    # say L137 pla
    old "Ohh, s- sure, don't worry."
    new "オッ、そ、そうよ、心配しないで。"

    # say L142 oli
    old "Hngh! Oh God!"
    new "ヒィッ！神様！"

    # say L143 oli
    old "It's even bigger than I thought!"
    new "思ってたよりも大きいわ！"

    # say L144 pla
    old "A- are you alright?"
    new "大丈夫か？"

    # say L145 oli
    old "Y- yes, don't worry, don't stop..."
    new "大丈夫、心配しないで、止めてほしくない…"

    # say L148 oli
    old "Come on, do it a little faster, I want you to cum inside me..."
    new "さあ、もっと早くして、中に出してほしいの..."

    # say L150 oli
    old "Mmm, it feels so deep... I've never felt anything like this before..."
    new "んん、こんなに奥まで感じちゃうの… 今までにない感覚だよ…"

    # say L151 oli
    old "Uhh... T- this is so good!"
    new "うっ… これ… すごくいい…"

    # say L152 pla
    old "Ughh... Yes..."
    new "うっ… うん…"

    # say L175 oli
    old "[pla] I- I'm about to finish!"
    new "[pla] もうすぐイクッ！"

    # say L176 pla
    old "M- me too! I'm about to cum!"
    new "俺も！ 出すぞ！"

    # say L177 oli
    old "Y- yes! Yes! Cum inside me!"
    new "Y- はい！ はい！ 中に出して！"

    # say L183 oli
    old "W- woah!"
    new "W- わお！"

    # say L184 oli
    old "I- I wasn't expecting it to be that way."
    new "あたし、そんな風になると思ってなかったの。"

    # say L185 oli
    old "I was a lot better than I thought!"
    new "全然想像以上だったわ！"

    # say L186 oli
    old "Did you like it too [pla]?"
    new "あなたも気に入ったんだ [pla]？"

    # say L187 pla
    old "Yeah, it was great."
    new "そうだな、最高だったよ。"

    # say L188 oli
    old "Alright, awesome!"
    new "じゃあ、良かったね！"

    # say L189 oli
    old "Now, let's get cleaned before my mom comes back and sees us."
    new "じゃあ、さっさと洗いっこしよう。ママが帰ってきて見つかったらまずいから。"

    # say L201 oli
    old "Ohhh, yeah, I've missed this feeling..."
    new "オーッ、そう、この感覚が本当に懐かしい..."

    # say L202 bri
    old "[pla]! She's really liking this!"
    new "[pla]！彼女、これ本当に気に入ってるみたい！"

    # say L203 bri
    old "I can see her emotions, she wants to get pregnant very badly!"
    new "彼女の気持ちがわかるよ、妊娠したいって本当に望んでるの！"

    # say L207 oli
    old "Oh my God! Your cock is so big!"
    new "おっけー！ あなたのち○こ、めっちゃ大きいわ！"

    # say L209 oli
    old "Yeah, yeah, just don't stop!"
    new "うんうん、止まらないで！"

    # say L212 oli
    old "Oh God yes!"
    new "神様、そう！"

    # say L213 oli
    old "F- fuck me harder! Harder"
    new "もっと強くファックして！ もっと強く！"

    # say L215 oli
    old "Mmm... I love this!"
    new "んん… これ大好き！"

    # say L238 pla
    old "O- Olivia! I think I'm about to cum!"
    new "オ- オリビア！ 出ちゃいそうだ！"

    # say L239 oli
    old "Y- yeah! D- do it!"
    new "や- やっぱり！ しちゃって！"

    # say L240 oli
    old "Fill me up with your cum!"
    new "私をいっぱい射精して！"

    # say L241 oli
    old "Get me pregnant!"
    new "私を妊娠させて！"

    # say L247 oli
    old "God! That was fantastic [pla]!"
    new "神様！それって最高だったね [pla]！"

    # say L248 oli
    old "I can't believe how good it was!"
    new "信じられないくらい良かったわ！"

    # say L249 oli
    old "I'm sure this time I'll be pregnant for real."
    new "今度こそ本当に妊娠するわよ。"

    # say L250 pla
    old "I hope so..."
    new "俺もそう願ってるよ…"

    # say L251 oli
    old "Alright, let's get up and get cleaned before my family comes back."
    new "それじゃ、起きていってつく前にお風呂に入ろう。"

    # say L263 oli
    old "Ah! ah! I'm loving it!"
    new "アッ！アッ！最高だよ！"

    # say L264 oli
    old "I've missed your dick so much [pla]!"
    new "あなたのチ○ポ、这么久没见了 [pla]！"

    # say L265 oli
    old "There's just nothing like it!"
    new "これほど気持ちいいものはないわね！"

    # say L269 oli
    old "D- do you like it [pla]?"
    new "好きだろ [pla]？"

    # say L270 oli
    old "How it feels?"
    new "どう感じるの？"

    # say L275 oli
    old "Oh god yes this is just what I've been missing!"
    new "ああ神、これだわこれずっと欲しかったもの！"

    # say L276 oli
    old "I can already start to feel myself getting better!"
    new "もうすでに体調が良くなってきているのを感じられる！"

    # say L277 oli
    old "This is unbelievable!"
    new "これって信じられない！"

    # say L300 oli
    old "Oh [pla]! I'm about to cum!"
    new "ああっ、[pla]！出ちゃいそう！"

    # say L302 oli
    old "G- great! Let's do it together!"
    new "すごい！一緒にやろう！"

    # say L309 oli
    old "Oh God! That was so great!"
    new "神様！それってめちゃくちゃ良かった！"

    # say L310 oli
    old "I can't believe how good it felt [pla]!"
    new "信じられないくらい気持ちよかった [pla]！"

    # say L311 oli
    old "I think that's just what I needed!"
    new "あれ、それがちょうど必要だったみたい。"

    # say L312 pla
    old "I- I'm glad it helped you."
    new "俺も君の役に立てて嬉しいな。"

    # say L313 oli
    old "Did you like it too?"
    new "あなたも気に入ったの？"

    # say L314 pla
    old "Oh yeah, it was very good."
    new "ああ、本当に良かったよ。"

    # say L315 pla
    old "Now, how about we get up before your Mom comes back."
    new "じゃあ、お母さんが戻る前に起きてみようか、オリ。"

    # say L316 oli
    old "Sure!"
    new "もちろん！"

    # say L328 oli
    old "Oh god! Yes! Yes!"
    new "ああ、神！ はい！ はい！"

    # say L329 oli
    old "Oh yes daddy! Fuck me just like that!"
    new "ああ、そうよパパ！ そのまま突いてくれ！"

    # say L330 oli
    old "This is so amazing [pla]!"
    new "これって最高だよ [pla]！"

    # say L334 bri
    old "That's it [pla]!"
    new "そうだね [pla]！"

    # say L336 bri
    old "Keep going! That's just what's needed for the spell!"
    new "続けて！これが魔法に必要なものだよ！"

    # say L340 oli
    old "Oh God [pla]!"
    new "神様[pla]！"

    # say L341 oli
    old "Y- you're making me go insane!"
    new "君が、私を狂わせちゃうよ！"

    # say L342 oli
    old "This is so great!"
    new "これって最高だよ！"

    # say L367 oli
    old "Oh fuck yes! I want you to fill me up!"
    new "ああ、そうよ！もっと私を満たして！"

    # say L369 bri
    old "You've already extracted the magic power! Let yourself go!"
    new "もう魔法の力を抜いたんだ！そのまま行っちゃえ！"

    # say L375 bri
    old "That was awesome [pla]!"
    new "それが最高だったね [pla]！"

    # say L376 bri
    old "Just what we needed to end the ritual!"
    new "ちょうど必要な儀式の終わりだったわ！"

    # say L377 oli
    old "Oh God [pla] that felt so good!"
    new "神 [pla] そんなに気持ちよかった！"

    # say L389 oli
    old "Oh god [pla]! The taste of your dick!"
    new "神様 [pla]！君のちんこの味が最高！"

    # say L390 oli
    old "This is such an amazing dick!"
    new "これほど素晴らしいちんこだったなんて！"

    # say L391 oli
    old "It never disappoints me!"
    new "これほど素晴らしいものだから、決してがっかりさせないわ！"

    # say L397 oli
    old "I just love feeling it in my mouth!"
    new "このチ○ポを口で感じるのが大好き！"

    # say L401 oli
    old "I love it [pla]!"
    new "大好き [pla]！"

    # say L402 oli
    old "I love this dick!"
    new "このチ○ポ大好き！"

    # say L403 oli
    old "I love it's taste and smell!"
    new "この味と香りが大好き！"

    # say L426 pla
    old "O- Olivia! I- ugh! I can't hold it in anymore!"
    new "オリビア！　うーぐっ！　もう我慢できないよ！"

    # say L427 oli
    old "That's alright! I don't want you to!"
    new "我慢しなくていいのよ！"

    # say L428 oli
    old "You don't need to hold it in!"
    new "我慢しなくていいよ！"

    # say L429 oli
    old "Let go and fill my mouth with your hot cum!"
    new "放って、私の口にあなたの熱い精液を注ぎ込んで！"

    # say L436 oli
    old "Mmm! That's an amazing taste [pla]!"
    new "うんっ！これがすごい味だね [pla]！"

    # say L437 oli
    old "This is just wonderful!"
    new "これ、最高だね！"

    # say L439 pla
    old "I- I'm glad you like it."
    new "俺も君が気に入ってくれて嬉しいよ。"

    # say L440 oli
    old "Oh yeah, I love it!"
    new "ああやつ、大好き！"

    # say L441 oli
    old "Now, I think we should get clean before my mom comes back and finds us like this."
    new "じゃあ、お母さんが帰ってくる前に私たち、ちゃんと洗いっこしようね。"

    # say L442 pla
    old "Sure, sure!"
    new "わかった、わかった！"


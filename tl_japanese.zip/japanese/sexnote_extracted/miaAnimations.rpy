# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/miaAnimations.rpy
translate japanese strings:

    # say L6 devMia
    old "Mmm! Oh wow."
    new "んん！ああ、すごい。"

    # say L7 devMia
    old "This is very different."
    new "これは全然違うな。"

    # say L8 devMia
    old "Don’t stop."
    new "止めてないで。"

    # say L12 devMia
    old "I- I wasn’t expecting this. This sensation."
    new "これは予想外だったな。この感覚。"

    # say L14 devMia
    old "Oh, I’m more than ok."
    new "ああ、全然大丈夫よ。"

    # say L15 devMia
    old "Do it faster."
    new "もっと速くして。"

    # say L19 devMia
    old "AH, yes, like that, keep going!"
    new "AH、そう、その調子で続けて！"

    # say L20 pla
    old "I- feel..."
    new "感じてる…"

    # say L21 devMia
    old "Don’t stop! KEEP GOING!"
    new "止めてないで！そのまま続けて！"

    # say L45 pla
    old "I think I can’t hold it back anymore!"
    new "もう我慢できないよ！"

    # say L46 devMia
    old "Let it go, cum inside me!"
    new "出しちゃって、中に射精して！"

    # say L47 devMia
    old "I want you to give that magic power!"
    new "その魔法の力をちょうだい"

    # say L48 devMia
    old "Oh yes!"
    new "ああ、そうよ！"

    # say L54 dev
    old "Oh my! That was fantastic!"
    new "Oh my！ それは素晴らしい体験だったわ！"

    # say L55 dev
    old "Linnet had told me about it, but this is just another level!"
    new "リンネットから聞いてはいたけど、これはまた別のレベルだね！"

    # say L56 dev
    old "We have to try this again!"
    new "またこれやってみないと！"

    # say L57 pla
    old "Are you insane?"
    new "君は頭がおかしいのか？"

    # say L58 pla
    old "We were already at risk doing it here, in the classroom."
    new "ここだけで危険だったんだよ、教室でやるなんて。"

    # say L59 pla
    old "We need to leave before someone comes... But help me clean her first."
    new "誰かが来る前に出ていこう… でもまずは彼女をきれいにしてあげてくれ"

    # say L71 mia
    old "You say you don’t know what’s happening, yet you still have this boner."
    new "あなたは起こっていることを知らないって言うくせに、まだこんなに Erect してるじゃない。 → あなたは起こっていることを知らないって言うくせに、まだこんなに erect してるじゃない。"

    # say L72 pla
    old "W- well, t- that’s just because..."
    new "まあ、それはただの……"

    # say L73 mia
    old "Spare me, will you?"
    new "お願い、冗談にしてちょうだい。"

    # say L74 mia
    old "I just need you to finish, I’ll go faster."
    new "早く終わらせて、私がもっと速く動きますから。"

    # say L78 mia
    old "You’re fucking disgusting for doing this, you know? To force me this way."
    new "あなたがこれをするのは本当に汚いわ、知ってるでしょ？私をこんな風に強要するなんて。"

    # say L79 pla
    old "I- I already said I don’t know what are you talking abut."
    new "俺はもう言ったじゃないか、何を言ってるのかさっぱりわからないって。"

    # say L80 mia
    old "Sure... I guess this boner is just because I’m pretty, right? You are sick!"
    new "もちろん……私がきれいだからってだけよね？ あなたは変態だわ！"

    # say L81 mia
    old "Will you just finish already?"
    new "早く終わらせてちょうだい。"

    # say L85 mia
    old "I just can’t believe you’d stood up this low."
    new "あなたがこんな低級な態度を取るなんて、信じられないわ。"

    # say L86 mia
    old "I will never forgive this, and I’ll make sure you pay for this."
    new "私は決して許さないわ、そしてあなたがこれに対して支払うことを確実にさせるつもりよ。"

    # say L87 mia
    old "Don’t you think for a single second that you’ll pull this shit again."
    new "一秒たりとも、またこんなことをすると思わないでくださいね。"

    # say L110 pla
    old "M-Miss Mia, if you keep going, I-I’ll...!"
    new "ミス・ミア、もしあなたが続けたら、俺は…！"

    # say L111 mia
    old "Fucking finally!"
    new "やっとか！"

    # say L112 mia
    old "Finish quickly will you? I don’t want to keep touching your dick."
    new "早く終わらせて、あなたのちんこに触れるのを避けたいわ。"

    # say L117 mia
    old "Ughhh... This is so gross..."
    new "うっ……これ、めちゃくちゃ気持ち悪い……"

    # say L118 mia
    old "Anyway, let's finish this shit."
    new "まあ、早く片付けましょうよ。このクソったれなことを。"

    # say L119 pla
    old "W- What? Now what?"
    new "ワッ、今何だ？"

    # say L124 pla
    old "What the hell was that?"
    new "何だったんだよ、それ？"

    # say L125 pla
    old "Why did you suddenly do that?"
    new "急に何したんだよ？"

    # say L126 mia
    old "I see you’re planning on keeping this up, huh?"
    new "あなたはこれ continuare つもりなのかしら？"

    # say L127 mia
    old "You know [pla], I always thought you were an idiot."
    new "あなたが[pla]って、私はいつもあなたはバカだと思っていたのだけど。"

    # say L128 mia
    old "But I never thought you’d be the kind of disgusting cockroach that would do this type of shit."
    new "でも、こんな卑劣なことをするような汚いゴキブリだとは思わなかったわ。"

    # say L140 den
    old "Yeah that’s right, get his dick in your mouth."
    new "そうだよ、お前の口に彼のちんこを入れろ。"

    # say L141 den
    old "Like the whore you are."
    new "お前のような娼婦だからな。"

    # say L142 mia
    old "S- shut up!"
    new "黙ってください！"

    # say L146 den
    old "You must be enjoying this, aren’t you?"
    new "君はこれ楽しんでいるんだろう？"

    # say L147 mia
    old "Pfff..."
    new "ふっふっ…"

    # say L148 den
    old "You little whore, look at how you do that."
    new "お前、そんな風にやってるところを見てみろよ。"

    # say L149 den
    old "It must be your experience from all the cocks you’ve sucked."
    new "君の経験が豊富なのは、今までに吸ってきたたくさんのちんこのおかげだろうな。"

    # say L153 den
    old "Tell me Mia, how much are you enjoying this?"
    new "ミア、これどれだけ楽しんでいるか教えて？"

    # say L154 mia
    old "Glurpp... F- fuck you!"
    new "グルッ……くっ、ふざけるな！"

    # say L155 den
    old "Ha, you’re gagging on cock and you’re telling me to shut up?"
    new "ハ、喉にチンコを詰まらせながら黙れって言うのか？"

    # say L178 den
    old "I see you’re about to finish [pla], that’s good, that’s good."
    new "見せて、もうすぐイクところだね [pla]、いいよ、いいよ。"

    # say L179 den
    old "Why don’t you go ahead and cum in her mouth?"
    new "そのまま彼女の口の中に射精してみ？"

    # say L180 den
    old "Don't worry, she'll swallow it all, that's what she used to do."
    new "心配しなくていい、全部飲み干すさ、昔からそうやってたからな。"

    # say L181 den
    old "You better drink every drop Mia, that’s an order."
    new "ミア、一滴残らず飲むんだ、それが命令だ。"

    # say L187 pla
    old "Are you ok Miss Mia?"
    new "大丈夫ですか、ミアさん？"

    # say L189 mia
    old "Ohh, yes, I’m fine, just let me gather my bearings for a second."
    new "あら、はい、大丈夫です、ちょっとだけ気持ちを落ち着かせさせてください。"

    # say L190 pla
    old "I’m sorry, for finishing in your mout-... I mean for everything."
    new "ごめんなさい、君の口に……って、いや、全部のことだ。"

    # say L193 mia
    old "That asshole is the one who made us do this."
    new "そのクソ野郎が私たちをこんな目に合わせたんですから。"

    # say L211 mia
    old "Oh! Nghn!"
    new "あっ！んん！"

    # say L212 den
    old "Ha, what’s the matter Ms? Is it too big for you?"
    new "ハ、どうしたんだ君。大きいのが苦しいのか？"

    # say L213 den
    old "But you’re so experienced! Come on! I know you can take it all!"
    new "でも君は経験者だろ！さあ、全部受け止めてみろよ！"

    # say L217 den
    old "Hey [pla]! You’re fucking your teacher that always tormented you!"
    new "Hey [pla]！いつも君を苦しめてた先生を今度は自分が犯してるんだぞ！"

    # say L218 den
    old "I bet it must feel really nice, huh?"
    new "きっと気持ちいいだろうな、ねぇ？"

    # say L219 den
    old "I know you wanted to do this bro! She’s been messing with you after all."
    new "知ってるよ、兄貴！彼女は君をいじめてたんだから。"

    # say L220 den
    old "That’s it, fuck her like the whore she is!"
    new "それだ、その淫乱女を犯せ！"

    # say L224 den
    old "How do you feel Ms. Mia?"
    new "ミアさん、どう感じる？"

    # say L225 den
    old "I bet you like having his big cock inside!"
    new "お前、彼の大きなチ○ポが入ってるのが好きだろうな！"

    # say L226 den
    old "Just like the old days, huh?"
    new "昔に戻ったみたいだね。"

    # say L227 mia
    old "S- Mmm! Shut up!"
    new "Ｓ－ん！うるさい！"

    # say L250 pla
    old "M-Miss Mia, I think - I think I’m..."
    new "ミアさん、俺が…思うには…"

    # say L251 den
    old "Yeah! That’s it [pla], fill her up!"
    new "よし！その調子で [pla]、中に出せ！"

    # say L252 den
    old "Fill that pussy up with cum!"
    new "そのオマンコを精液で満たせ！"

    # say L257 pla
    old "A-are you ok Miss Mia?"
    new "ミアさん、大丈夫ですか？"

    # say L258 pla
    old "I’m sorry."
    new "すみません。"

    # say L260 mia
    old "It’s ok, you shouldn’t have to apologize."
    new "大丈夫ですよ、謝る必要はありません。"

    # say L261 mia
    old "You’re also a victim here."
    new "あなたも被害者だからね。"

    # say L262 mia
    old "You’re actually a big help."
    new "あなたは実際には大きな助けになっているんです。"

    # say L282 den
    old "Yeah, you probably missed that dick, didn’t you Mia?"
    new "そうだよ、そのチ○ポ欲しくて仕方なかったんだろ、ミア？"

    # say L284 den
    old "Answer me Mia!"
    new "答えてみ、ミア！"

    # say L285 mia
    old "Y- Nghn! Mmm! Y-Yeah I do!"
    new "や-ン！ムッ！や-はい、そうよ！"

    # say L289 den
    old "I bet you like fucking in the bathroom!"
    new "トイレでセックスするのが好きだろ？"

    # say L290 den
    old "You like that you almost got caught, don’t you Mia?"
    new "君がほぼ捕まってしまったのが好きだろ、ミア？"

    # say L291 den
    old "Is exciting isn’t it?"
    new "興奮するでしょ？"

    # say L292 den
    old "I can’t hear you!"
    new "聞こえないのか？"

    # say L293 mia
    old "Y-yes! Ah! Is... Ah! Very exciting!"
    new "はい！あ、とても…あ、興奮しています！"

    # say L316 den
    old "I see you’re about to finish [pla]."
    new "君がイきそうなんだな [pla]。"

    # say L317 den
    old "It’s ok dude, let it out!"
    new "大丈夫だ、出しちまえ！"

    # say L318 den
    old "I want you to fill her pussy up!"
    new "お前のオシ holesを満たしてやりたい！"

    # say L319 pla
    old "M-Miss Mia, I- I’m about to...!"
    new "ミアさん、俺、もうすぐ…！"

    # say L320 mia
    old "J-just do it!"
    new "早くやってちょうだい！"

    # say L325 den
    old "Well guys, I would say that was perfect! Don’t you agree?"
    new "WELL、皆、それは完璧だったね！ 同意してくれるだろう？"

    # say L326 den
    old "Hahahaha, you can really tell Mia has some experience in front of the camera."
    new "ははは、ミアはカメラの前で経験があるのがよくわかるな。"

    # say L327 den
    old "You too [pla], you’re a natural dude!"
    new "お前もだな[pla]、お前も天然だな！"

    # say L328 den
    old "Well, I think I should just leave you two little lovebirds to comfort each other."
    new "まあ、お前ら若い恋人同士で慰め合ってりゃいいな。"

    # say L329 den
    old "But remember, all of this has been recorded, I don’t have to remind you what that means... Anyway, bye."
    new "でも覚えておけ、全部録画されてるからな、それが何を意味するかは説明しなくてもいいだろう… じゃあな。"

    # say L345 dir
    old "Oh yeah! That’s it!"
    new "ああそうか！それだよ！"

    # say L346 dir
    old "Yes! Yes! It’s so good!"
    new "はい！はい！最高だよ！"

    # say L347 dir
    old "It’s even better than a real dick!"
    new "それは本物のチンコよりもマシだよ！"

    # say L352 dir
    old "Ah! Ah! Yeah!"
    new "アッ！アッ！うん！"

    # say L353 dir
    old "That’s just what I wanted!"
    new "それが欲しかったんだよ！"

    # say L354 dir
    old "YES!"
    new "YES！ を日本語に翻訳すると："

    # say L387 mia
    old "Mmm, it’s so hard"
    new "んん、すごく硬いですねえ"

    # say L388 mia
    old "Oh! Mmm!"
    new "あっ！んん！"

    # say L389 pla
    old "M-Mia, lower your voice."
    new "ミア、声を低くしてくれ。"

    # say L393 dir
    old "Oh, oh fuck yeah!"
    new "ああ、ああ、本当にいいぞ！"

    # say L394 dir
    old "AH! AH! AH!"
    new "ああ！ ああ！ ああ！"

    # say L395 dir
    old "MMMM! FUCK YEAH!"
    new "MMMM！ ああ、よく来たぜ！"

    # say L399 dir
    old "Well, that just cheered me up!"
    new "WELL、それだけで気分が上がったな！"

    # say L400 dir
    old "What a great way to start the day!"
    new "朝から最高の気分だな！"

    # say L412 miavid
    old "Oh fuck, Ah!"
    new "オッ、アッ！"

    # say L413 black1
    old "Yes, oh you look so fucking good."
    new "うん、お前は本当に hottestな感じだな。"

    # say L414 miavid
    old "Mmmm! Ahhh! It's so big..."
    new "んん！ああっ！こんなに大きいの..."

    # say L415 black1
    old "That’s what I wanna hear."
    new "それが聞きたいんだよ。"

    # say L416 black2
    old "Keep sucking bitch."
    new "もっと吸い続けろ、クソッタレ。"

    # say L418 pla
    old "You had to memorize these dialogues or..."
    new "君はこれらの台詞を暗記する必要があったのか…"

    # say L419 mia
    old "Uhh... Something like that... That’s how it usually is in that industry."
    new "うーん… そんな感じですね… その業界では大抵そうなんですよ。"

    # say L420 mia
    old "Also my moans and everything, you have to pretend it all."
    new "それに私の喘ぎ声も全部、演技しなきゃならないんです。"

    # say L424 miavid
    old "Mmm! Slurp! Slurp!"
    new "んっ！啜り！啜り！"

    # say L425 black1
    old "Mmm yeah babe, it feels really nice..."
    new "うん、気持ちいいよ…"

    # say L426 miavid
    old "Oh, yeah!"
    new "ああ、そうだ！"

    # say L428 pla
    old "Did you guys ever improvised the lines or anything?"
    new "君たち、台詞を即興でやってたのか？"

    # say L429 mia
    old "Yeah, the only script we had was for the set ups, but most of the time we were improvising."
    new "はい、セットアップの台詞だけスクリプトがあったけど、ほとんどの時間は即興でやっていました。"

    # say L430 pla
    old "Yeah, I could kinda tell."
    new "そうだな、ちょっとはわかったよ。"

    # say L434 black2
    old "Oh my gosh, I can feel it reaching your throat."
    new "ああっ、喉まで感じられるよ。"

    # say L435 miavid
    old "Mmmm... Yeah baby..."
    new "んん… うん、baby…"

    # say L436 black1
    old "That’s what you wanted bitch!"
    new "それが欲しかったんだろ、クソ女！"

    # say L437 miavid
    old "Yeah! Yeah!"
    new "うん！うん！"

    # say L438 miavid
    old "I love your big black cocks!"
    new "あなたの大きな黒いちんこ、大好き！"

    # say L440 pla
    old "You know... You were very good at this."
    new "君は本当に上手だったよ。"

    # say L441 mia
    old "Ugh! Come on! Really [pla]?"
    new "うっgh！ 来てよ！ ほんと[pla]？"

    # say L442 mia
    old "That’s what you have to say about it?"
    new "それが言えること？"

    # say L443 pla
    old "Sorry, sorry, you’re right, that was out of line, I was just saying."
    new "ごめん、ごめん、君の言う通りだ、言い方悪かったな、ただ言っただけだった。"

    # say L444 mia
    old "Yeah, yeah, I know what you mean..."
    new "うんうん、分かってるの..."

    # menu L465 
    old "Skip"
    new "スキップ"

    # say L466 mia
    old "Ok, that’s enough, there aren’t any more videos or anything else in the folder."
    new "Ok、それだけよ。フォルダには他に動画も何もかもないわ。"

    # say L467 mia
    old "So we don’t need to keep checking this out."
    new "じゃあ、これ以上チェックする必要はないわね。"

    # say L468 pla
    old "Yeah, you’re right."
    new "うん、そうさ。"

    # say L478 miavid
    old "I-It’s so fucking big!"
    new "あ、こんなにデカいのっ！"

    # say L479 miavid
    old "I can’t handle it! AH!"
    new "これ、無理っす！AH！"

    # say L480 black1
    old "That’s right baby, take that big black cock!"
    new "そうだよベイビー、その大きな黒いチ○ポを飲んでみろ！"

    # say L481 miavid
    old "AH! AH! AAAAH!"
    new "AH！ AH！ AAAAH！"

    # say L483 pla
    old "Well, they are very big."
    new "まあ、確かに大きいな。"

    # say L484 mia
    old "Mmm, not the biggest ever."
    new "そうね、でも最大級じゃないわ。"

    # say L503 mia
    old "Just don’t take too much time."
    new "時間だけはかけすぎないでくださいね。"

    # say L504 mia
    old "We’re supposed to already be going to the principal's office."
    new "もうすでに校長先生のところに向かっているはずなのに。"

    # say L505 pla
    old "O-ok!"
    new "オッケー！"

    # say L508 mia
    old "Hurry up!"
    new "急いで！"

    # say L509 pla
    old "I-I’m trying, but I can’t do it if you keep rushing me!"
    new "俺、頑張ってるんだけど、君が急かすとできないんだよ！"

    # say L510 mia
    old "Just let go and enjoy it."
    new "ただリラックスして、楽しんで。"

    # say L511 mia
    old "That way you’ll cum quickly."
    new "その方が早くイクわよ。"

    # say L512 mia
    old "I’ll go faster!"
    new "もっと早くするから！"

    # say L517 mia
    old "That’s it, I can feel you getting harder."
    new "そう、硬くなってるのが感じるわ。"

    # say L518 mia
    old "There you go, just enjoy my mouth!"
    new "そこに吸い付いて、私の口を楽しんでくださいね。"

    # say L519 pla
    old "I-I think it’s working."
    new "効果が出ているみたいだな。"

    # say L520 pla
    old "J-just don’t stop."
    new "止めて欲しくない、ミア。"

    # say L543 pla
    old "M-Mia I think I’m cuming!"
    new "ミア、俺、出しそうだ！"

    # say L544 mia
    old "Do it, quickly!"
    new "早く、やって！"

    # say L545 mia
    old "Finish!"
    new "終わって！"

    # say L551 mia
    old "I mean, did you have to finish all over me?"
    new "つまり、全部私にかけちゃうつもりだったの？"

    # say L552 mia
    old "You covered me in cum!"
    new "あなたが精子で私を覆っちゃったわ！"

    # say L553 pla
    old "S-sorry, I couldn’t really control it."
    new "す、すみません、抑えられなかったんです。"

    # say L554 mia
    old "Whatever, listen, I’ll get clean quickly and we’ll go to the principal’s office."
    new "まあ、いいわ。でも早く洗って、校長先生のところに行きましょう。"


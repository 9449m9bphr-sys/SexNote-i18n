# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Bedroom.rpy
translate japanese strings:

    # say L10 pla
    old "I should go to the garage to talk with Brixxida first..."
    new "まずはブリクシダと話さないとな..."

    # say L22 pla
    old "Ah. I feel rested..."
    new "ああ、すっきりした感じがする..."

    # say L61 pla
    old "I should probably go talk to Billie..."
    new "俺はBILLIEと話すべきだな…"

    # menu L67 
    old "Sleep"
    new "寝る"

    # say L82 pla
    old "It's time to sleep..."
    new "寝る時間だな…"

    # say L321 pla
    old "Ready for a new day!"
    new "新しい日の準備はできてるか？"

    # say L323 pla
    old "Today is [mo1rel]'s medical appointment day, I should talk her."
    new "今日は[mo1rel]の医者の予約の日だ、彼女と話すべきだな。"

    # say L365 pla
    old "Wow... What's going on..."
    new "おう... 何が起こってる..."

    # say L383 pla
    old "Oh shit... Not again..."
    new "オッシャイト…またか…"

    # say L400 pla
    old "What the hell!..."
    new "何だよ！…"

    # say L416 pla
    old "Really? You again!?..."
    new "本当に？またお前か！？"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Mechanics/Navigation.rpy
translate japanese strings:

    # say L361 pla
    old "I shouldn't for now."
    new "今はまだやめとこうかな。"

    # say L372 pla
    old "I shouldn't for now"
    new "今はやめとくべきだな"

    # say L417 pla
    old "I shouldn't now"
    new "今はやめとくべきだな"

    # say L953 pla
    old "The school is closed. I should just go home."
    new "学校は閉まってるし、家に帰るしかないな。"

    # say L1248 pla
    old "I shouldn't enter right now. I don't have any appointments..."
    new "今入るのはよくないな。予定もないし…"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Mike.rpy
translate japanese strings:

    # say L32 whi
    old "Mmm, hi, [pla]. Long time, no see! My, how you've grown!"
    new "あら、こんにちは、[pla]。久しぶりですね！おお、随分と成長したんですね。"

    # say L34 pla
    old "(Gulp) Hello, Mrs. White. Thank you."
    new "（ゴクリ）こんにちは、ホワイトさん。ありがとうございます。"

    # say L37 whi
    old "I guess you came over to see Mike? What are you two planning on doing?"
    new "マイクを見に来たのね？ 二人で何するつもり？"

    # say L39 pla
    old "Uhh... We... Nothing... Hehe."
    new "うっ… 俺たち… 何もしてないよ… へへ。"

    # say L44 mik
    old "Finally! You decided to come! Don't bother us, Mom. We gotta work on that dumb school project."
    new "やっと来たか！ 妹、邪魔しないで。この馬鹿な学校のプロジェクトを進めないと。"

    # say L46 whi
    old "Ok. If you guys need anything, I'll be here."
    new "わかりました。何か必要なことがあれば、いつでも言ってくださいね。"

    # say L52 pla
    old "Alright, man. What's this great thing you just had to show me? "
    new "よし、何を見せてくれようとしてるんだ？"

    # say L54 mik
    old "Well, you came just in time. Every day... at this minute... it begins."
    new "まあ、君が来たのはまさに時機を逸さなかったな。毎日……この時間になると……始まるんだ。"

    # say L56 pla
    old "What begins?"
    new "何が始まるんだ？"

    # say L58 mik
    old "You'll see... Just wait."
    new "待てばわかるよ…。"

    # say L61 pla
    old "The hell you doing, Mike?"
    new "何やってんだ、マイク？"

    # say L62 mik
    old "Let me enjoy for a sec. It'll be your turn in a bit."
    new "ちょっと楽しんでもいいか。すぐ君の番だよ。"

    # say L67 mik
    old "Ok, here. Take this and peep what's out the front window? "
    new "おっ、これ。前窓の外みてみ？"

    # say L74 pla
    old "Oh shit!"
    new "オッシャイト！"

    # say L75 mik
    old "She's hot, isn't she?"
    new "熱いよね、その女。"

    # say L77 pla
    old "Damn. I think... I think, I've seen her before"
    new "damn、俺もそう思う……前に会ったことあるような気がする"

    # say L78 mik
    old "Wait... Do you really know  that lady?"
    new "待て……その女性を知ってるのか？"

    # say L84 pla
    old " I think so but I'm not sure... I'd have to get a closer look."
    new "そう思うけど確信はないな… 近づいてよく見ないと。"

    # say L87 mik
    old "Well ... I know something for sure... she is sexy as fuck! "
    new "WELL ... 確かに何かは知ってる... その女、めちゃくちゃセクシーだな！"

    # say L89 pla
    old "(she really is...)"
    new "（本当にそうなのか…）"

    # say L91 pla
    old "(I think she is my [lisrel]) Mmm... Let me see her again ..."
    new "（俺もそう思ってた [lisrel]）うーん、また見させてくれないか……"

    # say L93 mik
    old "Haha. I knew you would like it."
    new "ははは、そうなると思ってたよ。"

    # say L101 mik
    old "What? Is she getting naked? Give me those binoculars!"
    new "何？裸になるのか？双眼鏡貸せ！"

    # say L107 pla
    old "(Hmm... What am I going to do now? Can't let Mike see me like this.)"
    new "（Hmm... 何しようか。マイクに見られちゃダメだな。）"

    # say L109 pla
    old "(The only solution is to go to the bathroom and try to masturbate.)"
    new "（しょうがない、トイレに行って手コキでもするしかないな）"

    # say L111 pla
    old "Hmm... I need to use your bathroom, man. You keep watching her..."
    new "俺、お前んちのトイレ借りるよ。お前はそのまま見とけ。"

    # say L112 mik
    old "Ok. Suit yourself."
    new "勝手にしなさい。"

    # say L117 pla
    old " Whoops. I'm sorry, ma'am. I thought there was no one-"
    new "すみません、お嬢さん。誰もいないと思ったんですが-"

    # say L118 whi
    old "Ohh, are you [pla]? Don't worry. Go on and use the toilet. I trust that you won't peep, right? "
    new "あら、あなたは[pla]ですか？心配しないでください。トイレを使っていいですよ。覗かないよね？"

    # say L120 pla
    old "No. Of course not, Mrs. White..."
    new "いいえ、もちろんそんなつもりはありません、ホワイトさん..."

    # say L121 whi
    old "Haha! I am just kidding. Do what you need to do, kid. I'll continue taking a shower, deal?"
    new "ははは！冗談よ。必要なことは自分でしてね、子供さん。私はシャワーを続けるから、よろしくね？"

    # say L122 pla
    old "Ok... (Hmm I have no option) "
    new "Ok...（ヒャッ、選択肢がない）"

    # say L129 whi
    old "(What is that noise? ...What is he doing?)"
    new "(その音は何？……彼は何してるの？)"

    # say L133 whi
    old "(My word... He is hung!)"
    new "(まあ……彼は大きいのね)"

    # say L139 whi
    old "(Mmm... I should just take my shower. I don't want him to see me peeping.)"
    new "（うーん……シャワーを浴びた方がいいわ。見つかるのが怖いから。）"

    # say L143 pla
    old "Well, I managed to solve it, but I don't know for how long..."
    new "まあ、何とか解決したけど、どれくらい持つかわからないな..."

    # say L145 pla
    old "I better say goodbye to Mike and go home."
    new "俺はマイクに別れを告げて帰ろうっと。"

    # say L156 pla
    old " Hey, Mike. I have to jet."
    new "Hey、Mike。俺は帰るぞ。"

    # say L157 mik
    old "Oh, ok.  If you want to check her out again, come tomorrow."
    new "お、そうか。また会いたかったら、明日来い。"

    # say L159 pla
    old "W-What?!"
    new "W-何？！"

    # say L160 mik
    old "Yeah. If you want to see my neighbor again, come tomorrow..."
    new "ああ、また会いたかったら、明日来いよ、近所の子を见るために。"

    # say L162 pla
    old " Ohh, right. (Whew.) The neighbor... Ok. See you later, dude."
    new "オッ、そうだった。(ふう。) 隣の子… 分かった。また後でな、兄貴。"

    # say L182 mik
    old "Hey dude, you wanna see her again?"
    new "おい、また会いたいのか？"

    # say L185 pla
    old "Yeah, man. I want to check if I really know her."
    new "ああ、そうだな。本当に知ってるかどうか確かめたいんだ。"

    # say L187 mik
    old "Really? Ok, yeah, sure... Ok, it's your turn then..."
    new "本当に？なら、いいよ… そうだ、次は君の番だな…"

    # say L194 mik
    old "Remember, if she starts to undress you have to tell me..."
    new "覚えておけ、彼女が服を脱ぎ始めるならすぐに教えてくれ……"

    # say L195 pla
    old "Alright..."
    new "よし…"

    # say L197 pla
    old "(Hmm, really? Another hardon?) Mike, I need to use the bathroom. You wanna keep watching?"
    new "（ほんと？また勃ってるのか？）マイク、トイレに行かなきゃ。見守っててくれる？"

    # say L198 mik
    old "Of course!... She's so hot."
    new "もちろん！... 彼女、超 hottest だよ。"

    # say L212 mik
    old "You back, dude?... Check out this other position she's practicing..."
    new "戻ったか、兄貴？... こっちの体位も見てみろよ。"

    # say L215 pla
    old "Really? Let me see. (Maybe now I can see her face and know if I can if i can recognize her.)"
    new "本当に？見せて。（顔が見えるかな。そうすれば彼女を特定できるかもしれない。）"

    # say L217 mik
    old "Yeah, sure... Here you go."
    new "よし、分かった... ここだよ。"

    # say L227 pla
    old "(Hmm, really? An erection again?) Mike, I need to use your bathroom. You can have the binoculars back, bud."
    new "（ほんと？また勃起してるのか？）マイク、俺、お前のトイレ借りるよ。双眼鏡は返すからな、仲間。"

    # say L228 mik
    old "Sweet!"
    new "スイート！"

    # say L241 mik
    old "[pla]! Come look, man! It's gotten sexier than ever!"
    new "[pla]！見てみろよ、マジで！もっとエロくなってるぞ！"

    # say L244 pla
    old "What the fuck..."
    new "何じゃこれ…"

    # say L251 mik
    old "She makes me so fuckin' hard. I really wanna fuck her..."
    new "彼女が俺をこんなに硬くさせるんだ。本当にヤりたくて仕方ない..."

    # say L253 pla
    old "(Aaaand, of course, another erection...) Yeah, Mike... this is awesome... You can keep watching..."
    new "（ああ、もちろん、また勃起して……）うん、マイク……これ最高だ……見続けていいよ……"

    # say L258 mik
    old "Perfect! Ohh man. Tonight, I'm going to jerk off just thinking about her... "
    new "パーフェクト！おお、男。今夜は彼女のこと考えてオナニーするぜ……"

    # say L259 pla
    old "...(This guy...)"
    new "(この野郎…)"

    # say L261 pla
    old "Mike, I need to use your bathroom, man..."
    new "マイク、俺、お前のトイレ借りるぞ、マジで..."

    # say L262 mik
    old "Nice... take your time. My turn to enjoy the view."
    new "いいよ、ゆっくりしろ。俺も景色を楽しむ番だ。"

    # say L275 mik
    old "Hey [pla], you wanna see her again?"
    new "Hey [pla]、また見たくなるか？"

    # say L278 pla
    old "Well... Yes..."
    new "うーん... そうだな..."

    # say L280 mik
    old "Ok, it's your turn then..."
    new "じゃあ、君の番だな。"

    # menu L290 
    old "Position 1"
    new "ポジション 1"

    # menu L295 
    old "Position 2"
    new "ポジション2"

    # menu L300 
    old "Position 3"
    new "ポジション3"

    # menu L305 
    old "Continue"
    new "続ける"

    # say L312 pla
    old "(Aaaand, here it is, another erection...) Mike... I need to use your bathroom.... You can keep watching..."
    new "ああ、これだ、また勃っちゃった……マイク、お前のトイレ借りるぞ……お前は見続けてろ……"

    # say L313 mik
    old "Ok, man. It's my turn again..."
    new "分かった、また俺の番だな。 Bathroom使ってくれ、俺は見続けるから。"

    # menu L324 
    old "Handjob"
    new "手コキ"

    # menu L326 
    old "Blowjob"
    new "フェラチオ"

    # say L342 whi
    old "Hi [pla]. If you're looking for Mike, he's in his room."
    new "こんにちは [pla]。もしマイクを探しているなら、彼は自分の部屋にいますよ。"

    # say L344 pla
    old "Ok, thank you, Mrs. White."
    new "はい、ありがとうございます、ホワイトさん。"

    # say L353 whi
    old "Hey big boy... Don't you want to go to the bathroom again?"
    new "Hey big boy... またお風呂に入りたいんじゃないの？"

    # say L355 pla
    old "...I...Umm... What... do you mean?"
    new "あの…何を言っているんですか？"

    # say L357 whi
    old "I mean don't leave me waiting. I will be in there if you want to go at it again..."
    new "私が待ってるわよ。またやりたいなら中に入ってきなさい。"

    # say L367 whi
    old "Hey, handsome... Are you looking for some help?"
    new "HEY、ハンサム……何か手伝いが必要なのかしら？"

    # say L369 pla
    old "Wh... Huh?... Nah, I was... Looking for Mike..."
    new "Wh... え？... うーん、実は... マイクを探してたんだ..."

    # say L371 whi
    old "Ok, honey. Mmm, I will be in the bathroom waiting for you..."
    new "はい、ハニー。んん、私はお風呂場で待ってるからね…"

    # say L403 pla
    old "...Yeah, I'm looking for Mike, I... I will go to his bedroom, excuse me."
    new "…ああ、マイクを探してるんだ、俺… マイクの寝室に行くから、失礼します。"

    # say L437 pla
    old "(Daaaamn!).... I'm sorry, ma'am. I'm leaving right now."
    new "（ダーマン！）……すみません、お嬢さん。今すぐ行きます。"

    # say L439 whi
    old "Ohh. I'm sorry. Silly me, I forgot to close the curtains... Haha! But don't you worry. I know what you're going to do and maybe I can give you some... inspiration..."
    new "あら、すみません。バカね、カーテンを閉め忘れてたわ… ハハ！でも心配しないで。あなたが何をするつもりなのか知ってるわ。もしかしたら、私が少し… 火をつけられるかもしれないわよ…"

    # say L441 pla
    old "I... don't know... what you're talking about. (Gulp)"
    new "俺… 分かんない… 何言ってるんだ？"

    # say L443 whi
    old "Ohh, come on... you're about to burst in those shorts of yours... Just let it out. Mmm, I wanna see it..."
    new "あら、ほらよ… そのショーツの中で膨らんでるわ… そのまま出しちゃって。んん、見せてほしいの…"

    # say L446 pla
    old "...O-Ok."
    new "...おっけえ。"

    # say L449 whi
    old "That's right... Stroke that big cock for mommy..."
    new "そうですわ… その大きなちんこをママのために撫でて…"

    # say L455 whi
    old "Nice... Mmm, what a good load, [pla]..."
    new "いいわ… ふむ、素晴らしい射精だわ、[pla]…"

    # say L456 pla
    old "...That was intense..."
    new "……それは激しかったな……"

    # say L457 whi
    old "Thank you, honey... I hope we have a bathroom rondevu again."
    new "ありがとう、ハニー… 次もまたお風呂場で会えたらいいですね。"

    # say L459 pla
    old "I... I... have to go, Mrs. White."
    new "俺… 俺… 帰らなきゃ、ホワイト夫人。"

    # say L463 pla
    old "Whoa... That was crazy..."
    new "Whoa... それはマジで頭が混乱したな..."

    # say L465 pla
    old "I better go home."
    new "俺、帰った方がいいな。"

    # say L478 pla
    old "(Oh shit... Again).... I'm sorry, I'm leaving right now."
    new "（しまった…また）…. ごめん、今すぐ帰るよ。"

    # say L480 whi
    old "Mmm, I knew you would come... I was waiting for you, [pla]."
    new "mmm、来ると知ってたわ… 私、待ってたの、[pla]。"

    # say L484 whi
    old "Ohh, come on... Just let it out. I wanna see it again..."
    new "オッホ、来なさいよ… ちょっと出しちゃって。また見せてほしいの…"

    # say L498 whi
    old "Thank you, honey... I hope we have a bathroom rendezvous again."
    new "ありがとう、ハニー… 次もまたお風呂場で会えると嬉しいな。"

    # say L519 whi
    old "Hey handsome, I was waiting for you."
    new "HEYハンサム、待ってたのよ。"

    # say L523 whi
    old "Come on, don't be shy. Take that monster out and get to jerking..."
    new "さあ、遠慮しないで。その怪物を出して、さっさと手コキして..."

    # say L531 whi
    old "Would you mind if I give you a hand?"
    new "手伝わせてあげてもいいかしら？"

    # say L532 pla
    old "(Is this really happening?) W- What?"
    new "（これは本当に起こってるの？）なに？"

    # say L544 whi
    old "You can come whenever you want and, I'll give you a hand, my pleasure, okay?"
    new "いつでも来ていいわよ、手伝うのは私の喜びだわ。いいでしょ？"

    # say L546 pla
    old "Yes, ma'am."
    new "はい、白さん。"

    # say L547 whi
    old "Get out before Mike suspects anything..."
    new "出て行って、マイクに疑われないうちに..."

    # say L549 pla
    old "Ok, Mrs. White... "
    new "はい、ホワイト夫人…"

    # say L552 whi
    old "Hmm, what a big load..."
    new "ふむ、ずいぶん大きい Loadsね… の部分は削除し、以下のように修正します。"

    # say L555 pla
    old "Wow... She jerked me off..."
    new "Wow... 她は俺を手コキしたんだ..."

    # say L556 pla
    old "I should take my ass home."
    new "俺のケツを家に持って帰ろうか"

    # say L581 whi
    old "Come on, Take off your pants. I have a little surprise for you..."
    new "さあ、パンツを脱いで。あなたに小さなサプライズがあるのよ…"

    # say L599 whi
    old "I will be waiting for you handsome..."
    new "私はハンサムさんをお待ちしていますよ…"

    # say L607 whi
    old "Hmm, that tasted so good!"
    new "ん〜、それがとっても美味しかったわ！"

    # say L610 pla
    old "Wow... W- what just happened?"
    new "Wow... W- what just happened？ → うわっ… な、何が起こったんだ？"


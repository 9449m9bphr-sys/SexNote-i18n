# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/HinnStory.rpy
translate japanese strings:

    # say L13 pla
    old "Hey, Hinn! How are you doing?"
    new "Hey、Hinn！元気にしてる？"

    # say L15 hin
    old "H... Hey [pla]! I...I'm fine. Thanks for asking?"
    new "Ｈ…　ヘイ [pla]！あ…あたし、大丈夫。聞いてくれてありがとう？"

    # say L17 pla
    old "Are we a couple?"
    new "俺たち、カップルなのか？"

    # say L19 hin
    old "W... WHAT?... WE... WHAT?"
    new "わ... なに？... うわ... なに？"

    # say L21 pla
    old "Well, we are partners for the class project, right?"
    new "まあ、クラスのプロジェクトのパートナーだよね？"

    # say L23 hin
    old "Ohh... Riiight. Haha. The class project. Yeah, we are. Sorry, I just forgot..."
    new "オッホッホ… リイト。ハハ。授業のプロジェクトね。そうそう、パートナーだもん。ごめん、ちょっと忘れちゃってたの…"

    # say L25 pla
    old "Don't worry. We can meet to work on it. If you prefer, I could go to your house."
    new "心配しないで。一緒に取り組めるよ。君の家の方がいいかなと思ったけど、違う場所でもいいよ。"

    # say L27 hin
    old "W...What? My house? Why? Haha. I mean, why not your place?"
    new "W...What？ うち？ なんで？ ハハ。ええと、あなたのところでもいいんじゃない？"

    # say L29 pla
    old "Well, I just thought it would be more comfortable for you. But if you don't wanna-"
    new "まあ、君の家の方が落ち着くかと思ったんだけど、もし行きたくないなら-"

    # say L31 hin
    old "No! I don't have a problem with that. Hehe. We can meet at my house then. I will wait for you tomorrow after class so we can meet up, ok?"
    new "いいえ！全然問題ないよ。へへ。じゃあ、うちで会おう。明日、授業が終わった後、待ってるからね、OK？"

    # say L33 pla
    old "Sounds good to me!"
    new "そうか、俺も良いと思う。じゃあ、明日クラスが終わった後、君の家で会おう。待ってるよ、ヒン。"

    # say L35 hin
    old "Ok then... I... I have to go, see you tomorrow, [pla]."
    new "じゃあね… 私… 行かなきゃ、明日ね、[pla]。"

    # say L37 pla
    old "See you tomorrow, Hinn!"
    new "明日ね、ヒン！"

    # say L52 pla
    old "Hey Hinn, how are you?"
    new "Hey Hinn、どうしてる？"

    # say L54 hin
    old "Hi [pla], I'm great!, I mean, I'm good, what about you?"
    new "嗨 [pla]、私は元気です！ええと、まあ、大丈夫です、あなたは？"

    # say L56 pla
    old "I'm good too. So, are you ready to start?"
    new "俺も調子いいよ。で、準備できてるか？"

    # say L58 hin
    old "Well yes! I- I think so..."
    new "ううん、はい！私、多分準備できてると思う..."

    # say L60 pla
    old "Ok, then, let's do it!"
    new "じゃあ、始めようか！"

    # say L69 rub
    old "Woah! Look who we have here, it's the girl who dresses as a man."
    new "わお！見ろ、男の格好をしている女の子がいるよ。"

    # say L71 oli
    old "Yes! Perhaps you have nothing but that horrible gigantic sweatshirt."
    new "はい！もしかしてあの大きな汗だくシャツ以外何も着てないの？"

    # say L76 rub
    old "You know what the problem is? the problem is that she is kind of fat and that's why she wears those sweatshirts hahaha."
    new "問題はね、彼女がちょっと太ってるから、あの大きなスウェットを着てるんだよね、ははは。"

    # say L78 hin
    old "No, I'm not-"
    new "いや、そうじゃないよ。"

    # say L80 oli
    old "Hahaha you're a fat woman. Don't you have any sense of style?"
    new "ははは、太ってる女だね。スタイルって何のことか知ってる？"

    # say L82 rub
    old "Style? Hahaha look at her such horrible clothes obviously she doesn't know what that is."
    new "スタイル？ハハハ、見ろよ、あんな最悪な服、明らかにそれが何かも知らないわね。"

    # say L86 pla
    old "Hey, you shouldn't be so bitchy to Hinn..."
    new "おい、ヒンに対してそんなに悪口言うなよ…"

    # say L88 rub
    old "Hahaha check it out Olivia, the loser defends the fatty woman."
    new "ははは、見てみてオルivia、負け犬が太った女を守ってるわ。"

    # say L90 oli
    old "Why don't you go away with your fat girlfriend, loser?"
    new "太った彼女とさっさと消えてくれ、ローラー。"

    # say L92 pla
    old "... Assholes."
    new "...クソ野郎たち。"

    # say L94 rub
    old "Bye Loser!"
    new "バイ、ローザー！"

    # say L113 pla
    old "Wait Hinn..."
    new "待て、ヒン…"

    # say L120 pla
    old "Hmm... some stupid girls were bothering Hinn."
    new "ん……バカな女子たちがヒンを困らせていたんだ。"

    # say L124 pla
    old "Has this happened before?"
    new "前にこんなことがあったの？"

    # say L126 jad
    old "Yes, but she won't let me go talk to the principal, she says that I would only embarrass her even more..."
    new "うん、でも彼女は私に校長先生に話に行くのを許さないの。私が行くとさらに恥ずかしい思いをさせるって言うの..."

    # say L130 jad
    old "By the way, I'm Jade Hinn's mom, are you her friend?"
    new "それにしても、私はジェイド・ヒンの母ですが、あなたは彼女の友達ですか？"

    # say L132 pla
    old "Yes, right, I'm glad to meet you, my name is [pla]."
    new "はい、そうです、会えて嬉しいです、俺の名前は[pla]です。"

    # say L134 jad
    old "Hahaha, Nice to meet you. [pla] please excuse me for a moment. I'm going to talk to Hinn."
    new "ははは、はじめまして。[pla]、ちょっと失礼しますね。ヒンと話してきます。"

    # say L136 pla
    old "Okay, see you later."
    new "じゃあ、また。"

    # say L138 jad
    old "Oh no, don't go wait for me here, get comfortable and I'll be back in a minute."
    new "待ってないで、リビングでくつろいでて。すぐ戻るから。"

    # say L153 jad
    old "All right, I talked to her, everything is fine, she's just a little embarrassed."
    new "分かった、彼女と話したの、全然問題ないわ、ただ少し恥ずかしがってるだけよ。"

    # say L155 jad
    old "I can tell she really appreciates you that's why I want to take the opportunity to ask you a favor."
    new "彼女はあなたを本当に大切にしてるから、ちょっとお願いしたいことがあるの。"

    # say L159 jad
    old "I have encouraged her to seek therapy many times as she has had problems at times."
    new "彼女には何度もカウンセリングを勧めてるの、時々問題があるから。"

    # say L161 pla
    old "To the psychologist?"
    new "心理カウンセラーに？"

    # say L163 jad
    old "Yes, That would be the best option for her to improve her self-esteem, I know it could help her a lot, but she won't listen to me."
    new "うーん、心理カウンセラーに通うのが彼女の自尊心を高めるための最善の方法だと思うの。効果があることはわかってるんだけど、彼女は私の言うことを聞いてくれないの。"

    # say L165 pla
    old "Hmm, I understand."
    new "うん、わかるよ。"

    # say L167 jad
    old "So, I thought you could help me convince her."
    new "じゃあ、あなたに彼女を説得してもらうために協力してほしいな。"

    # say L171 jad
    old "Yes, I'm sure with your help we can convince her that that's the right thing to do."
    new "うん、あなたの手伝いがあればきっと彼女を説得できると思う。"

    # say L173 pla
    old "Alright. But what should I do?"
    new "分かった。けど、俺は何をすればいいんだ？"

    # say L175 jad
    old "First of all, help me find a psychologist, the truth is that I have been looking for one, but I haven't been able to find anyone."
    new "まずは、心理カウンセラーを見つけてくれる？実は探していたんだけど、なかなか見つからなかったんだ。"

    # say L177 pla
    old "Hmm, ok, I can handle it."
    new "うん、わかった、やってみるよ。"

    # say L179 jad
    old "All right, as soon as you find a therapist let me know. You can meet me here in the morning."
    new "分かった、カウンセラー見つかったら教えてね。朝ここであいだよ。"

    # say L188 hin
    old "Hello [pla], sorry for the delay..."
    new "こんにちは[pla]、遅くなってごめんなさい…"

    # say L190 jad
    old "All right guys, I'll leave you, so, you can go on with your work."
    new "じゃあ、みんな、私が行くから、仕事続けてね。"

    # say L196 pla
    old "Don't worry Hinn, do you feel better?"
    new "心配しないで、ヒン、調子は少し良くなった？"

    # say L198 hin
    old "Yes a little, I'm very sorry that-"
    new "うん、少しは、ごめんなさいけど-"

    # say L200 pla
    old "No, you don't have to apologize for anything, they're just bitches."
    new "大丈夫、君に謝らせるつもりはない、ただのクソ女たちさ。"

    # say L202 hin
    old "Hehehe, if you say so."
    new "へへへ、そう言うなら。"

    # say L204 pla
    old "Do you want to work today? We could do it tomorrow if you think thats better."
    new "今日働くか？ 明日の方がいいと思うなら、明日にしてもいいけど。"

    # say L206 hin
    old "No, no, I'm fine, we can start today."
    new "いいのいいの、今日から始めていいよ。"

    # say L208 pla
    old "Ok, let's do it."
    new "じゃあ、始めよう。"

    # say L222 pla
    old "Wow, Hinn! I didn't know you were so good at this!"
    new "Wow、Hinn！君がこれほど上手だとは知らなかったよ！"

    # say L224 hin
    old "Well... It's not as difficult as it seems. Hehe. I just study a little here and there."
    new "WELL... 難しいように見えるけど、そうでもないの。へへ。ちょっとずつ勉強してるだけなの。"

    # say L226 pla
    old "Well, thanks to you, we made a lot of progress. I think we can stop for now."
    new "Thanks to you、俺たちはかなり進んだよ。もう止めていいんじゃないか。"

    # say L228 hin
    old "Yes, it's getting late. We can continue tomorrow!"
    new "はい、もう遅いですね。明日続けましょう！"

    # say L230 pla
    old "Ok. I really enjoyed working with you. I think we make a very good team."
    new "そうだな。君と一緒にやってて楽しかったよ。いいチームだって本当に思う。"

    # say L232 hin
    old "Do... D- do you think that?"
    new "ええ……そう思ってるの？"

    # say L234 pla
    old "Of course! I think we are going to kick some ass together."
    new "もちろん！一緒にいればきっとすごいことができるさ。"

    # say L238 pla
    old "Well, see you tomorrow, Hinn. Have a good night."
    new "じゃあ、また明日な、ヒン。よい夜を。"

    # say L240 hin
    old "You too. By the way, remember to show Mrs. Mia our progress, let her know how far we've come. See you tomorrow."
    new "あなたも。それと、ミア夫人に私たちの進捗を見せてくれ。どれだけ進んだか伝えてね。また明日ね。"

    # say L242 pla
    old "Ok... See you."
    new "オッケー…また明日な。"

    # say L262 jad
    old "You came! I didn't know if you would actually come..."
    new "来たの！本当に来てくれるかどうか分からなかったの..."

    # say L264 pla
    old "Well, I like Hinn and I want to help her anyway I can, I finally found a therapist."
    new "まあ、ヒンのこと好きだから、彼女を助けるために何でもしたいんだ。ついにカウンセラーを見つけたよ。"

    # say L266 jad
    old "That's excellent! What's their name?"
    new "それは素晴らしい！その人の名前は何ですか？"

    # say L268 pla
    old "She is Dr. Johnson, she has her office in the town Business Building."
    new "彼女はドクター・ジョンソンだ、町のビジネスビルにオフィスがあるんだ。"

    # say L270 jad
    old "Great, it's not far from here."
    new "うん、ここからそんなに遠くないね。"

    # say L272 pla
    old "No is not, if you want I can make an appointment to see her."
    new "いや、そうじゃなくて、君が行きたければ予約を入れてあげるよ。"

    # say L274 jad
    old "Oh, don't worry I'll take care of it."
    new "心配しなくていい、私が手配するから。"

    # say L278 jad
    old "However, now comes the toughest part, convincing Hinn to go to therapy."
    new "しかし、これからが一番難しいところよ、ヒンをカウンセリングに連れていくことを説得するの。"

    # say L280 jad
    old "So, I'll talk to her today but you should convince her to agree to do it."
    new "じゃあ、今日私が話すけど、あなたも彼女にやってもらうように説得してね。"

    # say L282 pla
    old "Understood!"
    new "了解！"

    # say L284 jad
    old "Perfect! Now hurry too school. I don't want you to be late because of me."
    new "完璧！さっさと学校へ行こ。私因为你而迟到可不行。"

    # say L286 pla
    old "Alright! Bye."
    new "分かった！じゃ、行こう。"

    # say L302 jad
    old "I only care about you and your well-being, sweetheart..."
    new "あなたとあなたの幸せだけが心配だよ、甘いもの..."

    # say L307 hin
    old "I don't need a psychologist. I'm not crazy!"
    new "私は心理学者なんかいらないわ。私はクレイジーじゃないんだから！"

    # say L309 jad
    old "Oh... Hi [pla]!"
    new "あっ…こんにちは、[pla]！"

    # say L311 hin
    old "(Oh no...)"
    new "あら、やばい..."

    # say L313 pla
    old "Good morning Mr. Jade... Hello there, Hinn."
    new "おはようございます、ジェイド先生… こんにちは、ヒン。"

    # say L315 hin
    old "Sorry, [pla]. My mother now thinks I'm crazy..."
    new "ごめんなさい、[pla]。母は今、私が頭がおかしいと思ってるの…"

    # say L318 jad
    old "I don't think you're crazy honey, I just want you to go to therapy to strengthen your self-esteem."
    new "あなたが crazy だとは思ってないの、ただ自己肯定感を高めるためにカウンセリングに行ってほしいだけよ。"

    # say L320 hin
    old "I have nothing that I need to be strengthened!"
    new "私には強化する必要なんて全然ないよ。"

    # say L322 jad
    old "Honey, I know the reason why you don't want to go, it is because you think they are going to make fun of you even more at school."
    new "ハニー、君が行きたくない理由はわかってるわ。学校でさらにからかわれると思ってるんでしょ。"

    # say L324 jad
    old "But I promise it won't happen, we can do everything without anyone knowing."
    new "でも約束するから、誰にも気づかれないで全部できるよ。"

    # say L326 hin
    old "No, no, I won't do it, and I don't want you to continue embarrassing me."
    new "ううん、やらないわ、それに私を恥ずかしくさせるのをやめてほしいの。"

    # say L328 jad
    old "[pla], would you think Hinn is crazy if she goes to the therapist?"
    new "[pla]、ヒンがカウンセリングに行くって思ったら、彼女を変態だと思ったりするかな？"

    # say L332 pla
    old "Actually, I think it's healthy, and if it's something that will help you feel better, I don't think it matters what others think, right?"
    new "実際、健康的だと思うし、君が気分よくなるなら、他の人の意見なんて気にするなよ。"

    # say L335 jad
    old "You see darling, there is nothing wrong with it, many people attend to therapy and it is completely normal."
    new "亲爱的，那其实没什么问题的呢。很多人去心理咨询，这完全是很正常的事情呢。"

    # say L339 jad
    old "In fact, [pla] would you go with Hinn?"
    new "実際、[pla] 一緒にヒンと行く？"

    # say L344 pla
    old "Sure, I'd love to."
    new "もちろん、喜んで行くよ。"

    # say L346 jad
    old "See honey, don't worry any more, go to a single session and then decide whether to continue or not."
    new "見なさい、心配しなくていいから、一度だけ行ってみてから続けるかどうか決めればいいんだよ。"

    # say L348 hin
    old "Would you really be willing to go with me?"
    new "本当に一緒に来てくれるの？"

    # say L350 pla
    old "Of course, it should be fun."
    new "もちろん、楽しくなるぜ。"

    # say L352 hin
    old "Okay, but don't think I don't realize how you are manipulating me."
    new "分かってるけど、あなたが私を操ろうとしてることには気づいてるのよ。"

    # say L354 jad
    old "Excellent honey, I'm going to make the appointment. So, you can start studying now."
    new "素晴らしいわ、Honey。予約を入れるので、勉強を始めていいわよ。"

    # say L361 hin
    old "She's unbelievable..."
    new "信じられないわ..."

    # say L364 pla
    old "Well, the truth is, I think she's doing the best she can to help you."
    new "まあ、正直なところ、彼女は君を助けるために精一杯やってると思うんだ。"

    # say L366 hin
    old "If you say so... Anyway, let's start to work."
    new "そうね… ともかく、さっさと始めましょう。"

    # say L370 hin
    old "[pla], thank you... seriously. Thanks for having my back."
    new "[pla]、ありがとう…本気で。バックアップしてくれて感謝してる。"

    # say L372 pla
    old "It's nothing..."
    new "全然いいよ..."

    # say L392 pla
    old "Ok, see you tomorrow, Hinn."
    new "じゃあ、また明日な、Hinn。"

    # say L396 pla
    old "Ok. Have a good night."
    new "じゃあ、おやすみ。"

    # say L416 hin
    old "Hello [pla], How are you doing?"
    new "こんにちは[pla]、元気ですか？"

    # say L418 pla
    old "Hey Hinn, I am doing great, you?"
    new "hey Hinn、俺は調子いいよ、君は？"

    # say L420 hin
    old "Fine, thanks for asking. Today is the so-called “therapy session”, are you coming?"
    new "大丈夫、ありがとう。今日がいわゆる「療法セッション」の日だけど、来てくれる？"

    # say L422 pla
    old "Is it today?"
    new "今日なのか？"

    # say L424 hin
    old "Yes... My mother finally managed to schedule an appointment as we agreed."
    new "うん……母がやっと約束通りの予約を入れてくれたよ。"

    # say L426 pla
    old "Sure, I promised that I'll join you."
    new "もちろん、約束したからね。"

    # say L428 hin
    old "Awesome, are you ready?"
    new "すごいね、準備できてる？"

    # say L430 pla
    old "Yes, let's get going."
    new "はい、行こう。"

    # say L432 hin
    old "Very well."
    new "はい、それでは。"

    # say L440 joh
    old "Good afternoon, nice to meet you, you must be Hinn, right?"
    new "お 下午、お会いできて光栄です。あなたがヒンさんですね。"

    # say L442 hin
    old "Yes, Dr. Johnson, nice to meet you too."
    new "はい、ジョンソン博士、こちらこそよろしくお願いします。"

    # say L444 joh
    old "Your mother has already told me a little about you and you are..."
    new "あなたの母親からすでに少し聞いていますが、あなたは…"

    # say L446 pla
    old "My name is [pla], nice to meet you."
    new "俺の名前は[pla]、よろしく。"

    # say L448 joh
    old "Oh, are you her boyfriend?"
    new "あ、彼氏なのでしょうか？"

    # say L453 hin
    old "He's a friend..."
    new "彼は友達ね…"

    # say L455 joh
    old "Oh ok, I understand a friend..."
    new "なるほど、友達ね、わかったわ。"

    # say L457 joh
    old "All right, I think it's time to start therapy. [pla] could you wait for us outside?"
    new "では、治療を始める時間だね。[pla] 外で待っていてくれるかな？"

    # narrator L465 
    old "A few minutes later"
    new "数分後"

    # say L468 joh
    old "[pla] Can you come in for a moment, please?"
    new "[pla] ちょっと中に入っていただけますか、お願いいします。"

    # say L476 joh
    old "Very well, let me explain. With Hinn we have discussed the issue of bullying in the school."
    new "では、説明させていただきます。ヒンと話し合った結果、学校でのいじめの問題について考えました。"

    # say L478 joh
    old "And we have reached to the conclusion that it is best for her to try on other outfits so that she feels more comfortable with her body."
    new "そして、彼女が自分の体により自信を持つために、他の服を試してみることが最善だと結論づけました。"

    # say L480 pla
    old "I understand, I think it's a good idea."
    new "理解しました、良いアイデアだと思います。"

    # say L482 joh
    old "Yes, but to help her to have a better progress with the therapy, we require your help."
    new "はい、しかし彼女の治療の進展をより良くするために、あなたの協力が必要です。"

    # say L484 pla
    old "My help? How so?"
    new "俺の協力が必要だって？どうするんだ？"

    # say L486 joh
    old "We need a male friend opinion for each outfit so Hinn can feel that someone cares for her."
    new "ヒンが誰かが彼女を気にかけてくれていると感じられるように、それぞれの服について男性の友人の意見が必要です。"

    # say L488 pla
    old "Oh, I understand, no problem."
    new "わかった、問題ない。"

    # say L492 pla
    old "Yes, it will be fun."
    new "はい、楽しいだろうね。"

    # say L494 joh
    old "All right, in that case sit on the couch while Hinn takes off that sweatshirt."
    new "それじゃ、その場合、ソファに座っていて Hinn がそのトレーナーを脱ぐのを待ってください。"

    # say L509 joh
    old "Are you ready Hinn?"
    new "準備できましたか、Hinn？"

    # say L511 hin
    old "Hmm, I think so."
    new "うーん、準備できましたね。"

    # say L513 joh
    old "Very well take off that sweatshirt and let us see your body better."
    new "では、そのスウェットを脱いで、体を見せてください。"

    # say L517 joh
    old "Don't worry, you're in a safe place, nobody's going to judge you here."
    new "心配しないで、君は安全な場所にいるんだ、ここでは誰も君を批判したりはしないよ。"

    # say L519 hin
    old "Hmm alright."
    new "うん、わかった。"

    # say L523 joh
    old "But girl you have a great body!"
    new "でもね、君の身体は素晴らしいよ！"

    # say L527 joh
    old "What about you [pla]? Her body shape looks better, right?"
    new "あなたはどう思う、[pla]？彼女の体型の方がいいと思わない？"

    # say L528 pla
    old "Yes, she certainly looks better."
    new "そうだな、確かに彼女の方がいいな。"

    # say L532 joh
    old "Do you think you could survive without your Sweatshirt?"
    new "汗染みのシャツなしで生きていけますか？"

    # say L534 hin
    old "They are going to criticize me at school, because of my... b- breasts."
    new "学校でみんなに私の… 乳房を批判されるわ。"

    # say L536 joh
    old "Hahaha, but how are you going to be embarrassed by those beautiful breasts?"
    new "ははは、でもそんな美しい胸で恥ずかしがるなんてどうするの？"

    # say L537 joh
    old "What do you say [pla], Hinn should be ashamed?"
    new "何だって、Hinnが恥ずかしがるなんて [pla]、そんな美しい胸を持っているのに？"

    # say L538 pla
    old "... Hmm no, really your breasts look great."
    new "んー、でも本当に胸が素晴らしいよ。"

    # say L542 joh
    old "You have a blessing, you have a slim waist and a couple of really nice boobs, with those you might make all the boys crazy over you. "
    new "あなたには祝福されていますね、細いウエストと素晴らしい胸、それだけで男の子たちはあなたに夢中になってしまうかもしれませんよ。"

    # say L546 joh
    old "All right, all right, no problem, I think that's it for today."
    new "今日はこれで終わりにしましょう。"

    # say L554 joh
    old "However, we will have to get some more outfits to continue with your treatment."
    new "しかし、今後の治療を続けるためにはいくつかの新しい服が必要になりますね。"

    # say L556 joh
    old "Hmm, I'd rather it wasn't your own clothes, since from what I've see your clothes cover a lot."
    new "Hmm、できれば君自身の服じゃなくて、私が見た限りでは君の服はかなりカバーしているからね。"

    # say L558 pla
    old "I think I could help, I could get some clothes for Hinn."
    new "俺が手伝うよ、ヒン用の服を用意するから。"

    # say L560 joh
    old "Fantastic! Make sure it's a bit of a daring and revealing outfit."
    new "素晴らしいですね！ただし、少し大胆で露出の多い衣装にしましょう。"

    # say L562 joh
    old "We need to gradually make Hinn feel more secure in her body."
    new "徐々にヒンが自分の体に自信を持つようにしていきましょう。"

    # say L566 joh
    old "Ok, see you in the next session guys!"
    new "では、次回のセッションでお会いしましょう、皆さん！"

    # say L568 hin
    old "Thanks Dr. Johnson, goodbye."
    new "ありがとう、Dr. Johnson、さよなら。"

    # say L570 pla
    old "Goodbye."
    new "じゃあ、またね。"

    # say L577 pla
    old "How did you feel Hinn?"
    new "ヒン、どうだった？"

    # say L579 hin
    old "Actually, it was quite interesting, I felt comfortable in therapy, confronting it a little I think it can help."
    new "実は、けっこう興味深かったの。カウンセリングで落ち着いて過ごせて、少しずつ向き合っていくと役立つと思う。"

    # say L581 pla
    old "Excellent, I think it's great that you feel that way."
    new "素晴らしい、君がそう感じてくれて嬉しいな。"

    # say L583 pla
    old "So, will you continue attending therapy?"
    new "じゃあ、これからもカウンセリングを続けるつもりなのか？"

    # say L585 hin
    old "Hmm... Would you still accompany me?"
    new "うーん… それでも私を伴ってくれる？"

    # say L587 pla
    old "Of course I will."
    new "もちろん、君の傍を離れるつもりはないよ。"

    # say L590 hin
    old "Okay, let's just don't make a fuss in front of my mother, I don't want her to think she was right."
    new "じゃあ、母の前では騒がないでね、私が間違ってると思われたくないから。"

    # say L592 pla
    old "Hahaha, alright."
    new "ははは、わかったよ。"

    # say L594 hin
    old "Thanks again for your support."
    new "またありがとう、支えてくれて本当に感謝してる。"

    # say L596 pla
    old "It's a pleasure, Hinn."
    new "喜んで、ヒン。"

    # say L598 hin
    old "Could you come with me to my house today? I don't want my mother to ask me many questions."
    new "今日、私の家に来てくれない？母に質問されたくないの。"

    # say L610 jad
    old "How did it go guys?"
    new "どうだったの、みんな？"

    # say L612 hin
    old "Hmm... it wasn't a bad idea after all..."
    new "うーん……案外悪くはなかったな。"

    # say L614 jad
    old "You should tell by now that therapy is a very positive thing to do."
    new "もうこの時点で、カウンセリングがとても良いことだってわかるでしょ。"

    # say L616 jad
    old "Then I will immediately schedule the next appointment!"
    new "じゃあ次回の予約をすぐに組んでおくわ！"

    # say L618 hin
    old "No, I'm not going to go to therapy every day mom..."
    new "ううん、毎日通うわけじゃないよ、ママ…"

    # say L620 jad
    old "But... I thought you liked it."
    new "でも……君は楽しかったと思ってたのにな。"

    # say L622 hin
    old "Yes, I will go but remember, I have more responsibilities, like the class project with [pla]."
    new "はい、行くけど、クラスプロジェクトみたいに他の責任もあるのよ、[pla]と。"

    # say L624 jad
    old "Hmm, I understand, So when I should make the next appointment?"
    new "うん、わかった。じゃあ次は何時予約すればいいの？"

    # say L626 hin
    old "No, I will make the appointments myself when I think it is appropriate."
    new "私が適切だと思うタイミングで自分で予約するから安心して。"

    # say L628 hin
    old "Besides, [pla] must also agree when we should go, since he's going to the therapies as well."
    new "それに、[pla]も一緒に治療に行くんだから、彼の同意も必要だよ。"

    # say L630 jad
    old "Okay, you're right, I'll leave that up to you, if you need anything don't hesitate to ask me."
    new "分かった、任せるよ。何か必要な時は遠慮なく言ってね。"

    # say L632 jad
    old "I'll leave you alone, so, you can say goodbye to each other, heh."
    new "じゃあ、二人きりにしてあげるから、さようならを言い合ってね、へへ。"

    # say L647 pla
    old "I'm glad that everything went well with therapy."
    new "治療が上手くいったのが嬉しいな。"

    # say L649 hin
    old "Yes, me too, at least my mom will stop bothering me every day, or I hope so."
    new "うん、私もそう思う、せめて母が毎日うるさくしなくなるといいんだけどね。"

    # say L651 pla
    old "Hahaha I don't think that's going to happen."
    new "ははは、そうはいかないだろうな。"

    # say L653 hin
    old "Hehehe neither do I."
    new "へへへ、私もそうは思わないな。"

    # say L659 pla
    old "Well, well, it's getting late, so I'm going home, see you tomorrow."
    new "まあまあ、時間が遅くなったので、俺は帰るよ、明日ね。"

    # say L661 hin
    old "Yes, thank you so much for what you are doing."
    new "はい、本当にありがとう。"

    # say L663 pla
    old "You are welcome, I enjoyed it as much as you did and I love spending time with you."
    new "全然、君と一緒の時間は俺も楽しんでるし、君と一緒に過ごすのが大好きだよ。"

    # say L667 pla
    old "Well... see you tomorrow."
    new "じゃあ…また明日な。"

    # say L687 pla
    old "Hey Hinn! How are you today?"
    new "Hey Hinn！ 今日どう？"

    # say L689 hin
    old "I'm fine thanks [pla], I was waiting for you, today is the new therapy sesion."
    new "大丈夫、ありがとう [pla]、あなたを待ってたの、今日が新しいセッションの日だから。"

    # say L691 pla
    old "Oh great, let's go then."
    new "じゃあ、行こうか。"

    # say L693 hin
    old "Ok, ok."
    new "はい、はい。"

    # say L701 joh
    old "Hi guys, how are you?"
    new "皆さん、お元気ですか？"

    # say L703 pla
    old "Fine, thanks."
    new "元気です、ありがとう。"

    # say L705 joh
    old "Ready to go on with the treatment?"
    new "治療を続ける準備はできましたか？"

    # say L707 hin
    old "I think so..."
    new "うーん、そうかな…"

    # say L709 joh
    old "Excellent, [pla] you brought the clothes, didn't you?"
    new "素晴らしいですね、[pla] 服は持ってきたんですよね？"

    # say L711 pla
    old "Well, yes although I'm not sure if this will work, the clothes are... a little more revealing than necessary."
    new "まあ、そうだよ。ただこれでうまくいくかどうかはわからないけど、服が……ちょっと露出が多すぎるかもしれないな。"

    # say L713 joh
    old "Hmm, we'll see let's go Hinn, to the changing room."
    new "Hmm、見てみましょうか。ヒン、着替え室に行きましょう。"

    # say L715 hin
    old "Hmm... ok."
    new "はい…わかりました。"

    # say L728 joh
    old "Well, it took me a while to convince her, but finally got her to try on this outfit..."
    new "まあ、説得には時間がかかったけど、ついにこの格好を試着させて成功しました…"

    # say L739 joh
    old "What do you think [pla]?"
    new "どう思いますか [pla]？"

    # say L740 pla
    old "(Oh my God!) Well, I think you look really good, Hinn..."
    new "（オーマイゴッド！）まあ、君は本当にかわいいね、ヒン…"

    # say L742 hin
    old "Do you really think so?"
    new "本当にそう思ってるの？"

    # say L743 pla
    old "Yes, you look great."
    new "うん、君はすごくいいね。"

    # say L745 joh
    old "What did I tell you? You should wear these kinds of clothes every day."
    new "何と言ったか覚えていないのか？このような服を毎日着るべきだと言ったはずだ。"

    # say L747 hin
    old "No way. I'm not going to wear this in public..."
    new "そんなの無理よ。公共の場でこんな服を着るわけないじゃない。"

    # say L749 joh
    old "Well, at least you tried it. We are making progress. However, we need to go further. Next time bring something more revealing, ok [pla]?"
    new "まあ、せめて試してみたんだからね。進歩はあるけど、もっと大胆な服も試してみようじゃないか [pla]？"

    # say L751 hin
    old "More revealing?!"
    new "もっと露出が高いものって？！"

    # say L754 joh
    old "Yeah, honey remember we are going to do it privately and in a safe place, so we can improve."
    new "はい、覚えておいて、これはプライベートで安全な場所でやることだから、もっと上手になることができるんだよ。"

    # say L764 joh
    old "Well, that's it. See you in the next session."
    new "じゃあ、これで終わりだね。次回のセッションでまた会おう。"

    # say L766 hin
    old "Thanks Dr. Johnson."
    new "ありがとうございます、Dr. Johnson。"

    # say L775 hin
    old "Thank you so much for joining me again... I really appreciate it."
    new "ありがとうございます、また参加してくださって... 本当に感謝しています。"

    # say L777 pla
    old "Oh, don't worry, I think it's fun."
    new "心配しなくていい、楽しいよ。"

    # say L779 hin
    old "You're right, it's a bit fun..."
    new "そうね、ちょっと楽しいわ..."

    # say L781 pla
    old "Would you like me to walk you home?"
    new "家まで送ってあげようか？"

    # say L783 hin
    old "Oh no, don't worry my mom will come to pick me up."
    new "大丈夫、母が迎えに来てくれるから。"

    # say L785 pla
    old "Alright, then see you tomorrow?"
    new "じゃあ、また明日な？"

    # say L787 hin
    old "Yes!... I mean, sure."
    new "うん！…って、そうだね。"

    # say L789 pla
    old "Great, see you tomorrow Hinn."
    new "じゃあ、明日ね、ヒン。"

    # say L791 hin
    old "See you tomorrow [pla]."
    new "明日会おうね [pla]。"

    # say L810 hin
    old "I'm fine thanks [pla], I was waiting for you, today is the new therapy session."
    new "大丈夫です、ありがとう [pla]。あなたを待っていたの、今日が新しいセッションの日よ。"

    # say L826 joh
    old "Ready to get started with the treatment?"
    new "治療を始める準備はできていますか、ヒン？"

    # say L830 joh
    old "Excellent, let's go Hinn."
    new "素晴らしい、行こうよ Hinn。"

    # say L844 joh
    old "I love this outfit, I find it fancy and it looks great on you Hinn..."
    new "この衣装、すごく素敵だよ、ヒン。君にとてもよく似合ってる..."

    # say L856 joh
    old "Look at you, wow, you look fantastic."
    new "君を見て、わお、本当にすごいね。"

    # say L858 hin
    old "I think this skirt is too short..."
    new "このスカート、短すぎないかしら…"

    # say L860 joh
    old "That's the idea! To show those pretty legs of yours. Hehe. See how [pla] is drooling over them?"
    new "それが狙いですよ！ その美しい脚を見せるためだよ。へへ。見て、[pla] が涎を垂らしてるだろう？"

    # say L863 pla
    old "Mmm Yes... I mean no... I'm just watching. Nothing more."
    new "うん、そうだけど... いや、そうでもない... ただ見ているだけだよ。それだけさ。"

    # say L865 joh
    old "Sure, you are... Do you think Hinn has pretty legs?"
    new "もちろん、そうですよね… ヒンの足はきれいだと思いますか？"

    # say L866 pla
    old "Uhhh... Well, actually yes, I do..."
    new "うーん… 実際は、そう思うな…"

    # say L869 pla
    old "Yes, you really look nice."
    new "はい、君は本当に良いね。"

    # say L871 joh
    old "And how about that cleavage, aye?"
    new "その谷間もなかなかいいですね。"

    # say L875 pla
    old "Uhh... It looks great, too. Hinn has a really good... Body."
    new "うーん… 確かに素晴らしい… 肩こりがあるね、Hinn。"

    # say L877 joh
    old "She has great boobs, too, doesn't she?"
    new "彼女の乳房も素晴らしいですね、そうでしょう？"

    # say L881 hin
    old "I'm going to change my clothes..."
    new "着替えますね…"

    # say L883 joh
    old "Hehe. I was just kidding..."
    new "へへ、冗談ですよ..."

    # say L891 joh
    old "Well, that's it, [pla] you can surprise me the next session with another beautiful outfit like today."
    new "それじゃ、[pla] 次のセッションではまた素敵な服で驚かせてくださいね。"

    # say L893 pla
    old "I will try."
    new "俺は頑張るよ。"

    # say L895 joh
    old "Great! All right guys, see you in the next session."
    new "では、次回のセッションでまたお会いしましょう。"

    # say L897 hin
    old "Thank you Dr. Johnson."
    new "ありがとうございます、Dr. Johnson。"

    # say L910 hin
    old "You are right, it's a bit fun..."
    new "そうですよね、ちょっと楽しかったです..."

    # say L912 pla
    old "Do you want me to walk you home?"
    new "家まで一緒に歩こうか？"

    # say L939 pla
    old "I talked to Mrs. Mia... Ugh, I think she hates me or something."
    new "ミアさんと話したんだ... うーん、多分俺のこと嫌いなんじゃないかな。"

    # say L941 hin
    old "Why do you say that?"
    new "なぜそう思うの？"

    # say L943 pla
    old "She doesn't think I did anything on our project... And she wants you to talk to her alone."
    new "彼女は俺がプロジェクトで何もしてないって思ってるんだ... それに君ひとりで話してほしいってさ。"

    # say L945 hin
    old "Oh, no problem, [pla]. Don't worry I'll talk to her and let her know the truth."
    new "大丈夫よ、[pla]。心配しないで、私が彼女と話して、本当のことを伝えるから。"

    # say L947 pla
    old "Ok. Thank you, Hinn."
    new "Ok、ありがとう、Hinn。"

    # say L965 hin
    old "Everything is fine. I explained everything to her."
    new "全部説明したから、大丈夫よ。"

    # say L967 pla
    old "Really? Just like that, huh?"
    new "ほんと？そんなに簡単にはいかないだろ？"

    # say L969 hin
    old "Well, I can be very persuasive if I set my mind to it."
    new "まあ、私が本気になればかなり説得力があるのよ。"

    # say L971 pla
    old "Wow, Hinn! You sure have changed. You're way more open and secure..."
    new "Wow、ヒン！君は本当に変わったな。ずいぶんとオープンで自信に満ちてるよ..."

    # say L975 pla
    old "Yes, I really do."
    new "そうだ、本当にそう思う。"

    # say L977 hin
    old "Hahaha. Well, thank you, [pla]. It seems that my mom's crazy ideas really worked somehow."
    new "ははは。ありがとう、[pla]。母の変なアイデアが、案外効いたみたいね。"

    # say L979 pla
    old "Yes. I definitely think so..."
    new "うん。確かにそう思うよ..."

    # say L981 hin
    old "Well, speaking of that, today is the new therapy session."
    new "そういえば、今日が新しいセラピーの日ですね。"

    # say L1011 joh
    old "Great, let's go Hinn."
    new "それでは、行きましょう Hinn。"

    # say L1034 joh
    old "I honestly didn't think that Hinn was going to wear this... But we really are coming a long way..."
    new "正直、ヒンがこれを着るとは思わなかったけど… でも、本当に成長してるね…"

    # say L1037 hin
    old "I don't really feel comfortable..."
    new "私、ちょっと恥ずかしいんです…"

    # say L1039 joh
    old "You look fantastic, girl! With this outfit, you will drive them all crazy!"
    new "君は最高だよ、ヒン！この格好でみんなを狂わせちゃうぞ！"

    # say L1041 hin
    old "What! Who's supposed to wear this in public?"
    new "何！こんな格好を公共の場で誰がするっていうの？"

    # say L1043 joh
    old "Hahaha, I'd be surprised. What do you think, [pla]?"
    new "ハハハ、意外だな。[pla]、どう思う？"

    # say L1046 pla
    old "...(Oh shit! I'm getting hard.)"
    new "(しまった！俺、勃っちゃってる。)"

    # say L1053 joh
    old "Haha! Well, you've already made him get horny."
    new "ははは！でも、もう彼を興奮させちゃってるよ。"

    # say L1057 joh
    old "Can't you see his pants?"
    new "彼のパンツが見えないんですか？"

    # say L1061 joh
    old "That right there, Hinn, is the most honest show of appreciation you can receive from a man..."
    new "その反応こそ、男性が最も素直に感謝を示す方法だよ、ヒンンさん…"

    # say L1064 hin
    old "Oh my..."
    new "そんな反応を引き出しちゃったのね..."

    # say L1065 pla
    old "Sorry... It wasn't... My intention..."
    new "ごめん... 意図したわけじゃなかった..."

    # say L1067 joh
    old "Oh, no. Don't worry, honey. In fact, Hinn, you should feel flattered."
    new "大丈夫です、心配しないでください、ハニィ。実際、ヒン、あなたは誇りに思っていいですよ。"

    # say L1068 joh
    old "Do you know what that erection means? [pla] is sexually attracted to you!"
    new "その勃起の意味を知っていますか？ [pla] はあなたに性的に興奮しているんですよ！"

    # say L1069 pla
    old "(Oh shit!)"
    new "（しまった！）"

    # say L1073 joh
    old "Well, since you are both quite young, I think I could take this chance to give you a little sex education lesson..."
    new "まあ、二人ともまだ若いですから、この機会に少し性教育のお話をさせていただきますね…"

    # say L1077 joh
    old "Hahaha, [pla], you have Hinn speechless... Come here, don't be shy..."
    new "ははは、[pla]、ヒンを言葉も出ない状態にしてしまいましたね… こちらへ来て、恥ずかしがらないで…"

    # say L1083 joh
    old "I have to admit, [pla], I didn't imagine it would be this big... His size is pretty impressive, huh, Hinn?"
    new "[pla]、正直に言うと、これほど大きいとは思っても見なかったんだ… 大きさはかなり印象的だね、Hinn？"

    # say L1084 hin
    old "(It's so big.)"
    new "大きいですね。"

    # say L1085 joh
    old "Haha. This surely is the first time she's seen a real one and seeing one of this size even surprises me."
    new "ははは、君が本物を見るのは初めてだろうし、この大きさにすら驚いてる俺としては納得できるよ。"

    # say L1088 joh
    old "Let me get all this out of here..."
    new "じゃあ、これら全部を片づけよう..."

    # say L1093 joh
    old "Certainly... This is awesome, kid... What a big cock you have down here!"
    new "確かに…凄いね、君…こんなに大きなペニスがあるなんて！"

    # say L1100 joh
    old "Well, Hinn, pay close attention... I'm going to teach you how to please a man with your hands, this will be very useful knowledge..."
    new "WELL、Hinn、よく聞いてください... 手を使って男を喜ばせる方法を教えますから、これはとても役立つ知識になりますよ..."

    # say L1102 joh
    old "You have to take it in your hands and start to massage, from top to bottom very carefully..."
    new "手で握って、上から下へと丁寧にマッサージしていくんです…"

    # say L1115 joh
    old "Well... I hope you learned a little more about your sexuality, kids... If you want me to give you another small lesson, just let me know."
    new "WELL... ある程度自分の性について学べたといいな、子供たち... もう少し小さなレッスンが欲しければ、いつでも言ってください。"

    # say L1117 joh
    old "See you in the next session."
    new "次回のセッションでまた会いましょう。"

    # say L1132 hin
    old "Well..."
    new "まあ..."

    # say L1134 pla
    old "Your mom is coming to pick you up?"
    new "お母さんが迎えに来るの？"

    # say L1136 hin
    old "Yes, yes, she is coming to get me."
    new "うんうん、迎えに来てくれるの。"

    # say L1138 pla
    old "Oh, ok, then see you tomorrow?"
    new "じゃあ、明日見よう？"

    # say L1174 pla
    old "Yes, I love to help. Also, I think your mom did everything to help you."
    new "はい、手伝うよ。それに、お母さんも君のために頑張ってくれたと思うよ。"

    # say L1178 pla
    old "I really think you look good with any clothes you decide to wear, the most important thing is how you feel about yourself."
    new "君が着る服は全部似合ってるよ、一番大事なのは君自身の気分だよ。"

    # say L1180 hin
    old "Thank you, [pla]. I really appreciate it..."
    new "ありがとう、[pla]。本当に感謝してる..."

    # say L1182 pla
    old "My pleasure... So, see you this afternoon?"
    new "俺の pleasure... それじゃ、午後また会おう？"

    # say L1184 hin
    old "For sure, see you in the afternoon."
    new "もちろん、午後ね。"

    # say L1186 pla
    old "Great. Bye."
    new "じゃあ、さようなら。"

    # say L1217 joh
    old "Hi guys! Ready for the last session?"
    new "皆さん、こんにちは！最後のセッションの準備はできましたか？"

    # say L1219 hin
    old "Is this the last session?"
    new "これは最後のセッションですか？"

    # say L1221 joh
    old "Yes, you have advanced very well with the therapy."
    new "はい、君たちは治療でとてもよく進歩したね。"

    # say L1222 joh
    old "And have managed to gain more security in yourself and in your body and that was the objective."
    new "そして、自分自身や自分の体に対する自信をつけることができた。それが目的だったんだよ。"

    # say L1224 hin
    old "But... I- I don't feel... Ready."
    new "でも... 私は... 準備ができてない気がします。"

    # say L1226 joh
    old "Well... We still have this session, right?"
    new "WELL... まだこのセッションはあるよね？"

    # say L1228 hin
    old "Hmm... ok..."
    new "うーん… そうね…"

    # say L1230 joh
    old "All right for this last one I told you that you didn't need to bring any more clothes [pla]."
    new "それじゃ最後のセッションでは、服は持って来なくていいと言ったよね [pla]。"

    # say L1232 joh
    old "And that's because this last session we are going to do an exercise of accepting your own body."
    new "そして、最後のセッションでは自分の身体を受け入れる練習をするんだ。"

    # say L1235 joh
    old "Right, little by little you started to wear clothes that exposed more of your body, this time there will be nothing covering your body..."
    new "そうだね、少しずつ体をさらす服を着るようになったけど、今回は完全に裸になるんだ..."

    # say L1237 hin
    old "So?"
    new "そう？"

    # say L1239 joh
    old "Right, this time you'll be naked."
    new "そうだ、今回は裸になるんだ。"

    # say L1245 joh
    old "Come on girl, that's not much different from what you've already done before."
    new "さあ、それほど変わらないよ、君がこれまでやってきたことと比べて。"

    # say L1250 joh
    old "Just let's go girl, Your body is natural, your body is perfect."
    new "さあ、行こう、君の身体は自然で、君の身体は完璧だ。"

    # say L1265 joh
    old "Well, I think we're ready!"
    new "WELL、私は君が準備OKになっていると思うよ！"

    # say L1268 joh
    old "How are you feeling my dear?"
    new "お前はどう感じてるんだい？"

    # say L1270 hin
    old "I don't feel very good..."
    new "私はあまり調子が良くないんです..."

    # say L1272 joh
    old "But come on it's very natural, that's your body and it's beautiful, right [pla]?"
    new "でもさ、それが自然なことだから、君の体は美しいんだよ、ね [pla]？"

    # say L1275 joh
    old "Hahaha again in silence?"
    new "ハハハ、また沈黙かよ？"

    # say L1277 joh
    old "I guess you guys will have played around a bit since the last lesson I gave you, right?"
    new "君たちは前回のレッスン以来、少しは遊んでみたんだろう？"

    # say L1279 hin
    old "... No, we haven't..."
    new "...いいえ、まだ何もしていませんね..."

    # say L1281 joh
    old "Oh really? That's a shame."
    new "ほんとうに？ それは残念だね。"

    # say L1283 joh
    old "You know what I'll give you another free lesson, would you like to?"
    new "君が欲しがってるから、また無料でレッスンしてあげるよ、どう？"

    # say L1288 joh
    old "Hahaha, what are you trying to hide [pla] and Hinn's embarrassed face says yes."
    new "ははは、何を隠そうとしてるの [pla] Hinnの恥ずかしそうな顔が「はい」と言っているよ。"

    # say L1290 joh
    old "Okay, but only because it's our last session together."
    new "では、これが最後のセッションだから特別に教えてあげるよ。"

    # say L1292 joh
    old "Come here Hinn, I'll teach you how to take the next step in male pleasure."
    new "こちらへ来なさい Hinn、男性の快楽を次のステップへ導く方法を教えましょう。"

    # say L1301 joh
    old "Very well, you take it in your hand and this time you use your mouth."
    new "では、手に持つと、今回は口を使ってください。"

    # say L1302 joh
    old "You must pay close attention to the head, it is the most pleasant area"
    new "頭の部分には特に注意を払う必要があります、それが最も快感を感じる場所だからです。"

    # say L1303 joh
    old "So, you should use your tongue and lips to stimulate that whole area."
    new "舌と唇を使って、その部分全体を刺激してください。"

    # say L1315 joh
    old "Well, you've been naked for over 10 min, in front of us and you look pretty comfortable with that."
    new "君はもう10分以上裸のままだね、私たちの前でずいぶんと落ち着いて見えるよ。"

    # say L1317 joh
    old "That is proof that my work is already done."
    new "それは私の仕事がすでにできている証拠だね。"

    # say L1319 hin
    old "Thank you very much Dr. Johnson."
    new "ありがとうございます、Dr. Johnson。"

    # say L1321 joh
    old "But girl you can get dressed now, you don't have to be naked all the time..."
    new "でも君はもう服を着ていいよ、ずっと裸でいなくてもいいんだよ..."

    # say L1323 hin
    old "... Sorry."
    new "すみません。"

    # say L1325 joh
    old "Hahaha."
    new "ははは。"

    # say L1332 joh
    old "Well this is it, I hope the sessions and the little lessons have helped you, enjoy your sexuality and your youth guys!"
    new "WELL、これで最後ですね、セッションや小さなレッスンが役立ったことを願っています、若さと性を楽しんでくださいね！"

    # say L1336 joh
    old "I hope you do very well."
    new "皆さん、上手くいきますように願っています。"

    # say L1345 pla
    old "How did you feel in today's session?"
    new "今日のセッションはどう感じた？"

    # say L1347 hin
    old "I think it was exciting..."
    new "今日は興奮しましたね……"

    # say L1349 pla
    old "Ehmm, yes, it was exciting, right?"
    new "ええ、そうだったな、ヒン。"

    # say L1351 hin
    old "Did you like it?"
    new "好きだった？"

    # say L1353 pla
    old "Well... Yes."
    new "うーん… そうだな。"

    # say L1355 hin
    old "I liked too."
    new "私も好きだったよ。"

    # say L1359 pla
    old "Ok, then see you tomorrow?"
    new "じゃあ、明日見よう？"

    # say L1398 pla
    old "See you, Hinn."
    new "またね、Hinn。"

    # say L1412 pla
    old "Yes! We finally did it! We finished the project, even Mrs. Mia was happy with it!"
    new "はい！ついに終わったぞ！プロジェクトを完成させたし、ミア先生も満足してくれた！"

    # say L1414 hin
    old "Great, now that we're done, I want to ask you if... Will you continue to accompany me to therapy sessions?"
    new "良かった、これで終わったから、一つ聞きたいことがあるの… これからも私のカウンセリングに付き合ってくれる？"

    # say L1418 hin
    old "FOR REAL?"
    new "マジで？"

    # say L1420 hin
    old "I mean... Seriously?"
    new "本気で？"

    # say L1422 pla
    old "Sure! Well, only if you want too."
    new "もちろん！でも君がそうしたいって言ってくれないとね。"

    # say L1424 hin
    old "Yes, I would like it! You have helped me a lot and I would like to continue hanging out with you."
    new "はい、そうしたいの！あなたがたくさん助けてくれて、これからも一緒に過ごしたいな。"

    # say L1426 pla
    old "You can always count on me, Hinn."
    new "いつでも頼っていいよ、ヒン。"

    # say L1428 hin
    old "...Thank you, [pla]! I really mean it."
    new "ありがとう、[pla]！本気でそう思ってるの。"

    # say L1430 hin
    old "But how are you going to keep the sessions going, Doctor Johnson said we were done."
    new "でも、どうやってセッションを続けられるの？ドクター・ジョンソンはもう終わりだって言ったじゃない。"

    # say L1432 pla
    old "Hmm... Let me talk to her and see what I can do."
    new "うーん…彼女と話してみるか。何とかなるかもしれないから。"

    # say L1434 hin
    old "Great! I hope you can convince her..."
    new "Great！ 私も彼女を説得できると良いな。"

    # say L1436 pla
    old "Yes me too."
    new "うん、俺も。"

    # say L1459 ang
    old "Thank you very much Dr. Johnson, today's session was great."
    new "ありがとうございます、Dr. Johnson。今日のセッションはとても良かったです。"

    # say L1463 joh
    old "I hope these tips help you, in the next session and we will analyze the progress."
    new "これらのアドバイスが役立つことを願っています。次回のセッションでは進捗を分析しましょう。"

    # say L1465 ang
    old "Very well, goodbye doctor."
    new "では、さようなら、先生。"

    # say L1467 joh
    old "Bye bye."
    new "では、またお会いしましょう。"

    # say L1471 joh
    old "Hey, hello [pla] how are you doing?"
    new "こんにちは、[pla]、お元気ですか？"

    # say L1473 pla
    old "I'm doing good Dr. Johnson."
    new "元気です、Dr. Johnson。"

    # say L1475 joh
    old "How can I help you?"
    new "どのようにお手伝いできるかご指定いただけますか？"

    # say L1477 pla
    old "Well... I've been thinking with Hinn... And we wonder if we can continue with the..."
    new "ええと……ヒンと話し合っていまして…… 続けてもいいかどうか……"

    # say L1479 joh
    old "With the?"
    new "続けてのことを言っていますか？"

    # say L1481 pla
    old "If we can continue with the therapy?"
    new "治療を続けられるか？"

    # say L1483 joh
    old "Oh, Hmm... I made an exception with you guys since that kind of session is for couple therapy..."
    new "ああ、うーん… あなたたちには特別な扱いをしたんですが、そのようなセッションは本来カップル療法向けなんですよ…"

    # say L1485 pla
    old "Hmm, could we get some more of those?"
    new "うーん、もう少しそのセッションをさせてもらえませんか？"

    # say L1487 joh
    old "I don't think so, I'm sorry [pla]..."
    new "申し訳ありませんが、もう一度は難しいですね [pla]..."

    # say L1489 pla
    old "(Hmm... I think I should use it this time...)"
    new "うーん… 今回は使ってみようかな…"

    # say L1491 pla
    old "{b}Sauron's mouth:{/b}  Dr. Johnson I think you should make an exception with us..."
    new "{b}ソーアラの口：{/b} ドクター・ジョンソン、私たちには例外を設けてくれませんか…"

    # say L1493 joh
    old "Hmm, you know what, let's make a deal..."
    new "Hmm、そうですね、取引しましょうか…"

    # say L1495 joh
    old "I'll give those therapy sessions if you help me with another patients exercise, I think you could help me with them..."
    new "では、その療法セッションを提供しますが、他の患者さんの運動プログラムを手伝っていただけますか？ 私はあなたが彼らの手助けになると思います..."

    # say L1497 pla
    old "Help with another patients?"
    new "他の患者さんの運動プログラムを手伝うって？"

    # say L1499 joh
    old "Yes, I actually have a case where I think you would be a great help..."
    new "はい、実はある症例があって、あなたが大いに役立つと思うんです..."

    # say L1501 pla
    old "Hmm okay, and will the therapy continue in return?"
    new "うーん、わかった。それなら、見返りとして治療は続けるつもりですか？"

    # say L1503 joh
    old "Yes, I think it is an excellent deal."
    new "はい、これは素晴らしい取引だと思います。"

    # say L1505 pla
    old "Very well then, Hinn will schedule the appointment for the next lesson."
    new "では、次回のレッスンの予約をヒンに依頼します。"

    # say L1507 joh
    old "Perfect, I'll let you know when I need you to work with my patient."
    new "必要な時は患者さんと働くことを教えてください。"

    # say L1509 pla
    old "Understood."
    new "了解しました。"

    # say L1516 hin
    old "Well? What happened?"
    new "WELL？ 何があったの？"

    # say L1518 pla
    old "Everything is settled, you just have to call her to make the next appointment."
    new "全部決まったよ、次はお前が彼女に連絡して予約を入れるだけだ。"

    # say L1520 hin
    old "Really? Excellent! I'll call her right away, thanks [pla]."
    new "ほんとうに？すごいわ！すぐに電話するから、ありがとう[pla]。"

    # say L1522 pla
    old "No problem. Then, see you tomorrow?"
    new "問題ないよ。じゃあ、明日見な。"

    # say L1547 joh
    old "Wow Hinn, you decided to not wear the jacket, I see that the sessions served you well."
    new "Wow Hinn、ジャケットを着ないで来たんだね。セッションが効果的だったみたいですね。"

    # say L1552 joh
    old "Well, you're looking forward to continuing my therapy, uh?"
    new "WELL、君は私のカウンセリングを続けるのが楽しみなんじゃない？"

    # say L1556 pla
    old "Well... "
    new "WELL... ああ..."

    # say L1558 joh
    old "Hahaha I like to give therapy, so, don't worry guys."
    new "ははは、治療をするのが好きなので、安心してくださいね。"

    # say L1560 joh
    old "I think I've already given you a good introduction, what do you say if we go to Hinn's practice?"
    new "すでに十分な自己紹介をしたと思いますが、ヒンの練習場所に行きませんか？"

    # say L1564 joh
    old "Come on girl, don't be shy, after all you guys asked me for more lessons, right?"
    new "さあ、恥ずかしがらないで、君たちはもっとレッスンを頼んだんだからね。"

    # say L1566 hin
    old "Yes, yes, I'm sorry..."
    new "はいはい、すみません..."

    # say L1568 joh
    old "All right, let's go step by step, ok?"
    new "では、一つずつ進んでいきましょう、ね？"

    # say L1572 joh
    old "[pla] take off your shorts and sit on the couch, you come with me Hinn..."
    new "[pla] ショーツを脱いでソファに座って、ヒン、君は私について来なさい..."

    # say L1580 joh
    old "Oh yeah take it like that, fill your hand completely right?"
    new "そう、その感じで手にぎゅっと握って？"

    # say L1582 joh
    old "How does it feel Hinn..."
    new "感じは怎么样、Hinn…"

    # say L1583 hin
    old "Warm and... Hard..."
    new "温かくて…硬くて…"

    # say L1585 joh
    old "Hahaha the advantages of youth."
    new "ははは、若さの特権ですね。"

    # say L1598 joh
    old "All right guys I think that's it for this lesson."
    new "よし、今日のレッスンはこれで終わりだね。"

    # say L1600 joh
    old "I think you both enjoyed it a lot, and you already have some things to practice at home..."
    new "君たちはかなり楽しんでいたようだし、家で練習するところもあるだろうね..."

    # say L1604 joh
    old "It was really a pleasure guys, I'll wait for you for the next lesson..."
    new "それは本当に楽しかったですね、次回のレッスンを皆で楽しみに待っています…"

    # say L1611 hin
    old "That was... Fun."
    new "それは… 楽しかったですね。"

    # say L1613 pla
    old "Yes, I think it was... Very educational."
    new "そうだな、結構勉強になったと思うよ。"

    # say L1615 hin
    old "Hehehe yes it was..."
    new "へへへ、そうだったね..."

    # say L1621 pla
    old "Well, see you tomorrow Hinn."
    new "じゃあ、また明日ね、ヒン。"

    # say L1640 pla
    old "Hi Hinn, how are you?"
    new "嗨ん、元気ですか？"

    # say L1642 hin
    old "I'm great-"
    new "私は元気よ。"

    # say L1650 rub
    old "Wow, did you lose your ugly sweatshirt girl?"
    new "Wow、その丑いトレーナー手放したの？"

    # say L1654 rub
    old "Yes, don't you feel sorry to show that fatness?"
    new "はい、太ってるの見せるの可哀想だと思わない？"

    # say L1656 pla
    old "Really, you aga-"
    new "本当に、お前またこの大きな胸のことを言ってるの？"

    # say L1658 hin
    old "Are you talking about my big boobs? You envious Ruby jerk?"
    new "あなたが私の大きな胸のことを言ってるの？ 羨ましがってるんだね、Rubyちゃん？"

    # say L1660 rub
    old "What ?! I envy? I don't know what-"
    new "何？！羨ましいって？何言ってるのかわからないけど…"

    # say L1662 hin
    old "Ohh sorry, I'm a woman with a really good body and some brain..."
    new "あら、ごめんなさい、ボディも頭も良い女だと思っちゃったの..."

    # say L1664 oli
    old "Ouchh..."
    new "オウチ…"

    # say L1668 hin
    old "Ohh I'm sorry, was it too much for your little head? Maybe tomorrow you will understand it..."
    new "あら、ごめんなさい、あなたの小さな頭には多かったの？ 明日は理解できるかもしれないね…"

    # say L1670 hin
    old "Right now I don't have time to waste with a couple of stupid brainless girls like you. See ya..."
    new "今そんな馬鹿な女の子と時間を使う余裕はないわ。またね…"

    # say L1679 pla
    old "Hehehe see ya..."
    new "へへへ、またね…"

    # say L1681 rub
    old "Oh you shut up, loser!"
    new "あんた黙りな、負け犬！"

    # say L1683 pla
    old "Ugh, sorry..."
    new "ううん、ごめん…"

    # say L1693 pla
    old "Wow Hinn that was great!"
    new "ヒン、それって最高だったよ！"

    # say L1695 hin
    old "It doesn't matter, come sit on the couch."
    new "気にしないで、ソファに座りなさい。"

    # say L1697 pla
    old "What? What for?"
    new "何？何のために？"

    # say L1699 hin
    old "I'm going to suck it you, sit down..."
    new "座って、私が吸うから..."

    # say L1701 pla
    old "(What the...) All right."
    new "(何だよ...) 分かった。"

    # say L1712 pla
    old "Are you sure-"
    new "本当に大丈夫？"

    # say L1715 hin
    old "You just watch and enjoy."
    new "見て楽しめばいい。"

    # say L1729 hin
    old "Sorry, sorry. I was so impulsive... I just felt adrenaline after what happened and I wanted to try-"
    new "ごめんごめん。急に我慢できなくなって……あの後、アドレナリンが出ちゃって、試したくて-"

    # say L1731 pla
    old "No, don't worry, I'm amazed at your progress, you're more confident."
    new "大丈夫、心配しなくていい、君の成長に驚いてるよ、自信がついたね。"

    # say L1733 pla
    old "And I like that."
    new "それが気に入ったよ。"

    # say L1737 pla
    old "Yes, it was exciting."
    new "そうだな、興奮したよ。"

    # say L1739 hin
    old "I think Dr. Johnson has helped a lot."
    new "ドクター・ジョンソンはかなり役立ってくれたと思います。"

    # say L1741 pla
    old "You bet she has..."
    new "そうだね、彼女には本当に助けてもらったよ..."

    # say L1745 hin
    old "Well, I think my mom will be here soon, we can continue tomorrow, what do you think?"
    new "まあ、母がすぐ来ると思うから、明日に continuemos はどうかな？"

    # say L1747 pla
    old "Sure, see you tomorrow Hinn."
    new "そうだね、明日ね、ヒン。"

    # say L1767 pla
    old "I love it."
    new "好きだな。"

    # say L1769 hin
    old "I'm glad you liked."
    new "良かったあ。"

    # say L1771 hin
    old "Whenever you want another one we could practice again."
    new "またやりたいときいつでも言ってね。"

    # say L1775 hin
    old "Great. See you tomorrow."
    new "良かったわ。また明日ね。"

    # say L1777 pla
    old "Good night Hinn."
    new "おやすみ、ヒン。"

    # say L1797 hin
    old "I'm great thanks [pla]. I was waiting for you, today is the new therapy session."
    new "私は元気です、ありがとう [pla]。あなたを待っていたの、今日が新しいセッションだから。"

    # say L1809 joh
    old "Hi guys! Think you're ready to go on with the lessons, uh?"
    new "皆さん、こんにちは！レッスンを続ける準備はできましたか、ねぇ？"

    # say L1811 hin
    old "Yes, but we would like to try something more advanced..."
    new "はい、でももっと高度なことを試してみたいですね..."

    # say L1815 joh
    old "Hahaha, that's what I wanted to hear. And what about you [pla]? Ready for the next level?"
    new "ははは、そう言われてほしかったんだ。それじゃ、[pla]さんはどうですか？次のレベルに挑戦する気がありますか？"

    # say L1817 pla
    old "... Well-"
    new "... まあ、"

    # say L1819 joh
    old "Great, let's not waste any more time..."
    new "それじゃ、時間の無駄にしないようにしましょう..."

    # say L1821 joh
    old "Let's heat the situation up a bit, since you want something more advanced Hinn, let's try a double blowjob."
    new "それじゃ、状況を少し熱くしましょう。もっと高度なことを望んでいるんだから、ヒン、ダブルフェラチオを試してみましょう。"

    # say L1823 joh
    old "I hope it's not too much for you..."
    new "君には大丈夫かな…"

    # say L1825 hin
    old "Okay, let's try it."
    new "はい、やってみましょう。"

    # say L1827 joh
    old "Hahaha who are you and what did you do with Hinn?"
    new "ははは、君はいったい誰だ？ヒンはどこ行った？"

    # say L1829 joh
    old "All right [pla] down your pants and Hinn you bend down with me."
    new "大丈夫 [pla] 下着を下ろして、ヒン、君は私と一緒に屈んで。"

    # say L1836 joh
    old "With your tongue, stimulate the tip of the penis."
    new "舌を使ってペニスの先端を刺激する。"

    # say L1837 joh
    old "This drives any man crazy..."
    new "これでどんな男も狂いますね…"

    # say L1849 joh
    old "Hmm, I think you guys are ready to do it right?"
    new "うーん、君たちはもう本番OKかな？"

    # say L1851 pla
    old "Do... What?"
    new "何…それ？"

    # say L1853 joh
    old "Fuck, let's fuck guys..."
    new "くそ、みんなでやってみようか..."

    # say L1857 joh
    old "Come with me."
    new "一緒に来ましょう。"

    # say L1866 joh
    old "This is a practice room that I use with some patients."
    new "これは私がいくつかの患者と使う実践室です。"

    # say L1868 joh
    old "Come on guys take off your clothes, today you are going to have sex!"
    new "さあ、皆さん、服を脱いで、今日はセックスしましょう！"

    # say L1876 joh
    old "What's up [pla]? Now are you the shy one?"
    new "何があったんだ[pla]？今度はあなたが恥ずかしがり屋なのか？"

    # say L1878 joh
    old "Maybe you need some example..."
    new "もしかしたら、例を見せてあげる必要があるかな..."

    # say L1884 joh
    old "Well? What are you waiting for, you're the only one with clothes, don't you want to fuck this cute Hinn?"
    new "WELL？待ってるだけ？服を着ているのは君だけだよ、このかわいいヒンとセックスしたいんじゃないのか？"

    # say L1894 joh
    old "All right, as I know this is probably your first time, let's go smooth and slow..."
    new "では、これがおそらく初めてだということは承知していますので、ゆっくりと丁寧に進めていきましょうか。"

    # say L1895 joh
    old "Let me lubricate it well before we start."
    new "それじゃ、始める前に十分に潤しておきますね。"

    # say L1907 joh
    old "Well guys, I hope to see you for a lesson soon... You can continue your practices in the meantime."
    new "皆さん、近いうちにまたレッスンを受けに来てほしいですね…その間は練習を続けていてください。"

    # say L1909 hin
    old "Yes, it was a lot of fun."
    new "はい、とても楽しかったです。"

    # say L1911 joh
    old "Great, I think that's it for today let's get dressed and go to the office."
    new "それじゃ、今日の授業はこれで終わりにしよう。服を着替えて、事務所に行こう。"

    # say L1919 joh
    old "Well guys, I hope to see you for a next lesson soon... You can continue your practices in the meantime."
    new "皆さん、次のレッスンにもぜひ来てくださいね… それまで練習を続けてください。"

    # say L1923 joh
    old "Alright, see you in the next lesson."
    new "では、次回の授業でね。"

    # say L1962 hin
    old "I'm great thanks [pla]. I was waiting for you, today is the new therapy sesion."
    new "はい、ありがとうございます [pla] 私、今日の新しいセッションのためにあなたを待っていました。"

    # say L1974 joh
    old "What do we have here? Ready for another hardcore sex lesson?"
    new "何これ、またハードコアなセックスの授業の準備はできてるのか？"

    # say L1980 joh
    old "Haha that's great..."
    new "ははは、それは素晴らしいですね..."

    # say L1982 hin
    old "So, are we going to the couch?"
    new "それじゃ、ソファに行くの？"

    # say L1984 joh
    old "Ohh no, let's not waste time, let's go directly to a more comfortable place..."
    new "オッほん、時間の無駄は省こう、もっと快適な場所に行こうじゃないか…"

    # say L1992 joh
    old "Alright lie down on the bed [pla] and Hinn get on top of him."
    new "ベッドに寝て [pla]、ヒンが上に乗るんだ。"

    # say L1994 joh
    old "We're going to lubricate that cock well while [pla] giving you some pleasure."
    new "そのチンポをよく潤しながら、[pla] に楽しみを与えよう。"

    # say L2010 joh
    old "All right, are you ready for another hardfuck Hinn?"
    new "それじゃ、次のハードなセックスに備えて準備はいいかい、Hinn？"

    # say L2014 joh
    old "I've seen that [pla] has been looking at my big boobs a lot, uh?"
    new "あの [pla] さん、私の大きな胸を見てるのよね、うふ？"

    # say L2016 pla
    old "... No, no, I just-"
    new "... いや、いや、ただ-"

    # say L2018 joh
    old "Hahaha, come on I've already sucked your penis, there's no reason to be ashamed."
    new "ははは、大丈夫よ、もうあなたのペニスを吸ったんだから、恥ずかしがる必要なんてないわ。"

    # say L2020 joh
    old "Actually, today while you fuck Hinn you are going to enjoy my soft and big boobs..."
    new "実はね、今日はヒンを犯しながら私の柔らかくて大きな胸を楽しんでください..."

    # say L2036 joh
    old "Another successful session guys... Let's get dressed."
    new "君たち、また成功したな... 服を着よう。"

    # say L2044 joh
    old "All right that's it for today, I hope to see you soon for a next lesson guys."
    new "それじゃあ今日はこれで終わりです、また近いうちに次のレッスンでお会いできるのを楽しみにしていますね。"

    # say L2046 hin
    old "Of course we will Dr. Johnson."
    new "もちろん、Dr. Johnsonです。"

    # say L2097 joh
    old "Oh, but here are my favorite patients... Hehehe."
    new "じゃあ、私の好きな患者さんたちが来たね…へへへ。"

    # say L2099 hin
    old "Good afternoon Dr. Johnson."
    new "お afternoon、Dr. Johnson。"

    # say L2101 joh
    old "How are you guys? Ready for our last lesson?"
    new "皆さん、元気ですか？ 最後の授業の準備はできていますか？"

    # say L2103 pla
    old "Last lesson?"
    new "最後の授業？"

    # say L2105 joh
    old "Yes, I think you already have the basics, it is important that you now experience for yourselves to discover your own sexuality."
    new "はい、基本はもう身についていると思います。これからは自分で経験して、自分の性を発見することが大切です。"

    # say L2107 hin
    old "But... Can't we go on?"
    new "でも… もう少し続けられないでしょうか。"

    # say L2109 joh
    old "Well, we could repeat some of the lessons we've already done..."
    new "まあ、すでにやった授業を繰り返すこともありかもしれませんけど…"

    # say L2111 hin
    old "Oh great, sounds good..."
    new "あら、そうですね…"

    # say L2113 pla
    old "So, what will we do today?"
    new "じゃあ、今日何をする？"

    # say L2115 joh
    old "Let's go to the room and I'll explain."
    new "部屋に行きましょう、そこで詳しく説明します。"

    # say L2123 joh
    old "All right, let's heat things up a bit by lubricating it well, you know what to do."
    new "では、まずはよく潤滑剤を塗って、少し熱を上げましょう、あなたなら何をするか知っていますよね。"

    # say L2137 joh
    old "Well, that was great, now you [pla] are going to fuck Hinn alone."
    new "では、それは良かったね、これからは [pla] が一人で Hinn を犯すことになるよ。"

    # say L2139 pla
    old "Alone?"
    new "ひとりで？"

    # say L2141 joh
    old "Yes, I will just be watching, the idea is that you can continue to do it yourself so that you can enjoy your sexuality alone."
    new "はい、私はただ見守るだけです。自分で続けてやって、一人で性的な楽しみ方を覚えていってください。"

    # say L2143 pla
    old "Hmm ok."
    new "うん、そうか。"

    # say L2162 joh
    old "Well guys, that was it for today, get dressed."
    new "皆さん、本日はこれで終わりです、服を着てください。"

    # say L2170 joh
    old "I think it's time for you to practice what you learned. Enjoy it guys!"
    new "皆さん、学んだことを実践する時間だと思いますよ。楽しんでくださいね！"

    # say L2172 joh
    old "If you want to repeat one of the lessons, don't hesitate to come back."
    new "もしレッスンを繰り返したいと思ったら、遠慮せずにまた来てください。"

    # say L2212 hin
    old "I'm great, What about you?"
    new "私は元気です、あなたは？"

    # say L2216 hin
    old "So? Would you like to repeat some session with Dr. Johnson?"
    new "じゃあ？Dr. Johnsonとのセッションを繰り返したいですか？"

    # say L2221 pla
    old "Of course! Let's do it."
    new "もちろん！やってみよう。"

    # say L2230 pla
    old "I really would like to... But I can't right now."
    new "本当はやりたいんだが、今は無理だ。"

    # say L2232 hin
    old "Oh don't worry you can look for me if you change your mind."
    new "心配しないで、気分が変わったら探してきてもいいわ。"

    # say L2234 pla
    old "I will do it."
    new "俺がやるよ。"

    # say L2255 joh
    old "I knew it would not take long for you to return from the last session."
    new "前回のセッションから戻ってくるのは時間がかからないと予想していた。"

    # say L2257 joh
    old "So? What do you want to do today guys?"
    new "それじゃ、今日何する気？"

    # say L2269 joh
    old "Oh, you guys want to go from the beginning, right?"
    new "あ、君たちは最初からやりたいんだね？"

    # say L2273 joh
    old "I like it! Let's do it."
    new "いいですね！やりましょう。"

    # say L2283 joh
    old "It always surprises me!"
    new "いつも驚かされますね！"

    # say L2290 joh
    old "Well, let's do it..."
    new "それでは、始めましょう…"

    # say L2304 joh
    old "Do you need another blowjob lesson? Uh? Or just [pla] want a good blowjob from me?"
    new "もう一つのフェラチオのレッスンが必要ですか？ うーん？ それともただ [pla] から良いフェラチオを受けたいだけですか？"

    # say L2308 joh
    old "Anyway... I like it! Let's do it."
    new "とにかく…好きです！やってみましょう。"

    # say L2329 joh
    old "O third lesson, let's team up to give [pla] a great amount of pleasure!"
    new "第3のレッスン、一緒に[pla]にたくさんの快楽を与えましょう！"

    # say L2342 joh
    old "Your cock is in one of biggest I've ever saw."
    new "あなたのペニスは私がこれまでに見た中で最大級のものですね。"

    # say L2355 joh
    old "Double blowjob and Doggystyle? How great does it sounds?"
    new "ダブルフェラとドギースタイル？どれだけ素晴らしいか想像できますか？"

    # say L2367 joh
    old "And you are becoming some kind of expert Hinn!"
    new "そしてあなたはもうヒンのエキスパートになりつつあるんですね！"

    # menu L2372 
    old "Lesson 5"
    new "レッスン5"

    # say L2380 joh
    old "Do you want to have my boobs on your face while you fuck Hinn, uh?"
    new "あなたがヒンを犯している最中に、私の胸をあなたの顔に押し付けてあげるわよ、どう？"

    # menu L2403 
    old "Lesson 6"
    new "レッスン6"

    # say L2411 joh
    old "Oh god, I'm dying to see that pretty face covered with a good facial."
    new "神様、その美しい顔を良いフェイシャルで覆いたいです。"

    # say L2423 joh
    old "Alright lie down on the bed [pla] and your Hinn get on top of him."
    new "ベッドに寝て [pla] そしてヒンが上に乗るんだよ。"

    # say L2440 joh
    old "All right guys, that was fun, but it's all for today."
    new "それじゃあ皆さん、今日は楽しかったけど、これで終わりです。"

    # say L2444 hin
    old "Will come back soon..."
    new "またすぐに来るからね…"

    # say L2446 joh
    old "I will be waiting."
    new "待っていますよ。"

    # say L2448 pla
    old "See you soon Dr Johnson."
    new "また会いましょう、ジョンソン先生。"

    # say L2457 hin
    old "That was hot, right?"
    new "それは熱かったよね？"

    # say L2459 pla
    old "Yes, it was great."
    new "そうだな、最高だったよ。"

    # say L2461 hin
    old "Hehehe do want to repeat it tomorrow?"
    new "へへへ、明日またやりたい？"

    # say L2465 hin
    old "Nice, then see you tomorrow [pla]."
    new "じゃあ、明日ね [pla]。"

    # say L2467 pla
    old "Ok, see you tomorrow Hinn."
    new "わかった、明日またね、Hinn。"


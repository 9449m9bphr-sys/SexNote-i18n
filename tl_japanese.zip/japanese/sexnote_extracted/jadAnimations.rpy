# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/jadAnimations.rpy
translate japanese strings:

    # say L6 milJad
    old "I must say... Mmmm, the size of your dick never stops being surprising."
    new "言わせてもらうけど… うーん、あなたのチ○ポの大きさはいつも驚かされるね。"

    # say L7 milJad
    old "It’s impressive."
    new "それはすごいね。"

    # say L8 milJad
    old "And this scent... I had never perceived it."
    new "そしてこの香り……今まで感じたことがなかった。"

    # say L9 milJad
    old "It’s... nice."
    new "それは…いいね。"

    # say L13 milJad
    old "Are you enjoying this?"
    new "楽しんでるの？"

    # say L14 milJad
    old "I ask because it’s important for you to cum."
    new "あなたがイクことが重要だから聞いているのさ。"

    # say L15 pla
    old "It feels good."
    new "気持ちいい。"

    # say L16 milJad
    old "Mmmmm!"
    new "うん、すごい…"

    # say L20 milJad
    old "This sensation! I’d never felt it before!"
    new "この感覚！前に感じたことないよ！"

    # say L21 milJad
    old "Ughh... It hurts, but it feels so good!"
    new "ううっ… 痛いけど、気持ちいい！"

    # say L22 milJad
    old "I- I’m enjoying it!"
    new "あ、楽しんでる！"

    # say L45 pla
    old "I don’t think I will last longer!"
    new "俺も長くは持たないぞ！"

    # say L46 milJad
    old "It’s ok, cum for me!"
    new "大丈夫、私にかけて！"

    # say L47 milJad
    old "Slurrp!!"
    new "スルルッ！！"

    # say L48 milJad
    old "Cum! Give me the magic!"
    new "出せ！魔法をくれよ！"

    # say L54 mil
    old "That... that was unexpected."
    new "あの… それは予想外だった。"

    # say L55 pla
    old "Are you ok?"
    new "大丈夫か？"

    # say L56 mil
    old "I’m fine."
    new "平気だよ。"

    # say L57 mil
    old "It’s just that I wasn’t expecting that."
    new "ただ、予想外だったのさ。"

    # say L58 mil
    old "The act feels so different with a human body."
    new "人間の体でやると、感じ方が全然違うの。"

    # say L59 mil
    old "And to be able to feel all that. Linett’s spell is very complete!"
    new "そんな感覚を全部味わえるなんて。リネットの魔法は本当に完璧だね。"

    # say L60 pla
    old "Ah... sure. Hey listen, I think we need to get going before we’re discovered here."
    new "ああ…そうだな。でもさ、見つかる前に帰ろうって。"

    # say L61 pla
    old "I’ll clean Mrs. Jade, and then we take off. Ok?"
    new "俺がジェイドさんをきれいにして、それから出発するよ。いいか？"

    # say L75 jad
    old "(Mmm, it feels so nice...)"
    new "（んん、気持ちいい…）"

    # say L76 jad
    old "(Uhh... A- am I moving? God, I- I can't control it... I hope [pla] doesn't notice.)"
    new "（うっ… あ、動いてる？神様、コントロールできない… [pla] に気づかないことを願ってる…）"

    # say L77 pla
    old "(Wait, is she moving? What the-)"
    new "（待て、彼女が動いてる？何だよこれー）"

    # say L81 pla
    old "(Wow... Yeah, she is definitely moving... Geez, and just in front of Hinn...)"
    new "(うわー……ほんと動いてるな……げえず、ヒンの前でこんなことになって……)"

    # say L82 hin
    old "Hey, talking about dad, I saw he deleted the post about his marriage."
    new "ねえ、パパの話題が出たけど、結婚についての投稿を消したのを見たの。"

    # say L83 hin
    old "Kinda late, we already saw it."
    new "ちょっと遅いわ、もう見ちゃったよ。"

    # say L84 jad
    old "Mmm... Yeah, he’s just like that."
    new "うん、そうよね。彼、いつもそんな感じだもん。"

    # say L85 jad
    old "Not surprising..."
    new "驚かないなあ…"

    # say L89 jad
    old "(Oh my God! I can't help myself anymore, this feels so fucking good.)"
    new "ああ、神様！もう我慢できない、これ、めちゃくちゃ気持ちいい！"

    # say L90 jad
    old "Ahh! Ahh!"
    new "アッ！アッ！"

    # say L93 jad
    old "(Holy cow!) U- uh, nothing, I just hurt my toe."
    new "（あらまあ！）うーん、何でもない、ただ足の指をぶつけちゃっただけ。"

    # say L94 jad
    old "A- accidentally."
    new "あ、すみません。"

    # say L95 hin
    old "Oh, you should be more careful."
    new "Jad、もっと気をつけてね。"

    # say L96 jad
    old "Yes honey, hehe, how silly of me..."
    new "うん、 Darling、へへ、私がバカね..."

    # say L121 jad
    old "Are you about to finish?"
    new "もうすぐ終わりそう？"

    # say L122 hin
    old "Yeah, I’m almost done."
    new "うん、もうすぐ終わるね。"

    # say L123 jad
    old "Me too..."
    new "私も..."

    # say L130 hin
    old "Well, that was a relief, I’m sorry I interrupted your shower."
    new "ほっとしたわ、ごめんねシャワーを邪魔しちゃって。"

    # say L132 jad
    old "Don’t worry honey."
    new "心配しないで、 honey。"

    # say L133 hin
    old "I have to get going, gotta get back to school."
    new "行かなきゃ、学校に帰らないと。"

    # say L134 jad
    old "Sure honey."
    new "大丈夫よ、 Honey。"

    # say L137 jad
    old "(Oh my god! What did I just do?)"
    new "あらまあ！今のは一体何したの？"

    # say L138 jad
    old "I- I think we should get out of this tub [pla]."
    new "あの、このバスタブから出た方がいいかもね [pla]。"

    # say L139 pla
    old "Uhh, right, right."
    new "うん、そうだ。"

    # say L152 jad
    old "Oh yeah, this feels so nice.."
    new "ああ、そうね、これすごく気持ちいい.."

    # say L153 jad
    old "Mmm, I want that big hard cock inside of me!"
    new "んん、その大きな硬いチ○ポを私の中に入れてほしい！"

    # say L154 jad
    old "I need it."
    new "私はそれを欲している。"

    # say L158 jad
    old "Uhh, I- it’s the biggest cock I’ve seen!"
    new "うーん、これほど大きなチ○ポは初めて見ました！"

    # say L159 jad
    old "Oh God! I- I want to be fucked by him!"
    new "おおっ！私、彼に犯されたい！"

    # say L160 pla
    old "(She's thinking about someone she knows?)"
    new "彼女は知っている誰かのこと考えてるのか？"

    # say L164 jad
    old "Mmm... I want him to fuck me like he fucks Hinn!"
    new "mmm... 私、ヒンみたいに彼に犯されてWant..."

    # say L165 pla
    old "(Woah! Woah! She's not thinking about me, right?!)"
    new "Woah！ Woah！ まさか僕のこと考えてないよね？！"

    # say L166 jad
    old "Oh yes, yes, yes!!"
    new "オお、はい、はい、はい！！"

    # say L167 jad
    old "I want to feel that hard cock inside me!"
    new "あの硬いチ○ポを中で感じたいの！"

    # say L168 jad
    old "That young, thick, hard, cock!"
    new "その若い、太くて硬いチ○ポ！"

    # say L191 jad
    old "AH! AH! Ohhh I'm cumming, I'm cumming!"
    new "AH！AH！ああっ、イク、イクよ！"

    # say L192 jad
    old "YES! YES! YES! YES!"
    new "やった！やった！やった！やった！"

    # say L198 jad
    old "Phew, that felt so good."
    new "ふう、それ感じたの本当に良かったわ。"

    # say L199 jad
    old "I needed that."
    new "必要だったわ。"

    # say L200 jad
    old "But, it’s still not the same as a dick."
    new "でも、チンポとは違うよね。"

    # say L203 jad
    old "Wait, what was that sound?"
    new "待って、今何の音がしたの？"

    # say L211 jad
    old "Mmmm, that was a huge cock!"
    new "うーん、それってデカいチ○ポだったわ！"

    # say L212 pla
    old "(Is she talking about my...)"
    new "（彼女は俺のことを言ってるのか…）"

    # say L213 jad
    old "Oh god, it barely fit in my mouth, and it tasted so good..."
    new "神様、口に入れるのがやっとだったけど、味が本当に良かった..."

    # say L217 jad
    old "Oh my God! I had never felt this before..."
    new "おおお！ 私、こんな感じは初めてだよ..."

    # say L218 jad
    old "Mmmm, I want that cock so badly..."
    new "んん、そのチ○ポが欲しくて仕方ないの..."

    # say L223 jad
    old "Ahhh! Ahh! Ah!"
    new "アッ！ アッ！ アッ！"

    # say L224 jad
    old "I- I want your big dick inside me [pla]!"
    new "あ、あたしの身体に大きいチ○ポが欲しいの [pla]！"

    # say L225 jad
    old "I love you big cock!"
    new "あなたの大きなチ○ポ、大好き！"

    # say L248 jad
    old "Ahh! Ahhh! I want you to fill me up!"
    new "アッ！アッ！私を満たして！"

    # say L249 jad
    old "Yes! Yes! Oh, this is so good!"
    new "はい！はい！ああ、これ、最高！"

    # say L250 jad
    old "I- I’m cumming!"
    new "あ、あたし、イク！"

    # say L256 jad
    old "Phew... I bet that surprised you."
    new "ふう……びっくりさせちゃったかな。"

    # say L257 pla
    old "(Is she talking to me?)"
    new "（彼女は俺に話しかけてるのか？）"

    # say L258 jad
    old "Sorry I couldn't help it, I've been a bit horny lately."
    new "ごめん、我慢できなかったの。最近ちょっとエッチな気分になってて。"

    # say L265 jad
    old "It’s ok, I knew you were there [pla], it’s just that I needed to loosen up a little bit before."
    new "大丈夫、あなたがそこにいることくらい知ってる [pla]、ただ少しリラックスしたかっただけ。"

    # say L266 pla
    old "Uhh... Before? Before what?"
    new "うーん… それって、どの前のこと？"

    # say L267 jad
    old "Before this."
    new "これの前ね。"

    # say L288 whi
    old "I love how big is his cock, isn't it?"
    new "彼の大きなペニスが好きです、そう思いませんか？"

    # say L289 whi
    old "Are you enjoying the view Jade?"
    new "ジェイド、この景色楽しんでる？"

    # say L294 whi
    old "Mmm, yeah, have you ever seen a deep throat, Jade?"
    new "んん、そうね、ディープスロート見たことある？ジェイド。"

    # say L295 whi
    old "Do you like what I'm doing with my mouth?"
    new "私が口でやってること、気に入ってる？"

    # say L300 whi
    old "What about if I get an oral creampie, would you like to see that jade?"
    new "もし私がオーラルクレampieをしたら、見たいですか？ジェイド。"

    # say L301 jad
    old "Mmmm..."
    new "んん…"

    # say L302 whi
    old "That's all what I need to know."
    new "それが知りたかったのよ。"

    # say L325 pla
    old "Mmmm, I- I think I'm about to-"
    new "ん、俺もうすぐ……"

    # say L326 whi
    old "Yes! Do it! Show Jade what she's been missing!"
    new "はい！やって！ジェイドに見せてあげて、彼女がどんなことを逃してたのか！"

    # say L327 whi
    old "You want it too, don't you Jade?"
    new "あなたも欲しくて仕方ないんでしょ、ジェイド？"

    # say L328 whi
    old "You also want him to push this big hard dick in you mouth?"
    new "あなたもこの大きな硬いチ○ポを口に押し入れて欲しがってるんでしょ？"

    # say L340 whi
    old "Mmm, are you ready for your turn?"
    new "うん、君の番は準備できてる？"

    # say L342 whi
    old "Well? Do you want to try it, isn't it?"
    new "WELL？ 試してみたいんじゃないの？"

    # say L343 jad
    old "Uhh, I- I do."
    new "うーん、はい、そうです。"

    # say L344 whi
    old "Good! I'm glad you're finally admitting it."
    new "良かったわ、君がついに認めてくれたのね。"

    # say L345 whi
    old "Great, now let's do it!"
    new "それじゃ、始めるわ！"

    # say L354 whi
    old "That's it, girl, just relax, don’t think about anything else other than what you have in your mouth right now."
    new "それだわ、リラックスして、今口に入ってるもの以外は何も考えないで。"

    # say L356 whi
    old "He must be enjoying this as hell, two sexy MILFS sucking his dick, that should be like heaven. Isn't it [pla]?"
    new "彼はきっと天国のような気分だろう、二人のセクシーなミルフがチ○ポを咥えているんだから。そうでしょう [pla]？"

    # say L357 pla
    old "Uhh... Mmmm, yeah..."
    new "うっ… うん、そう…"

    # say L358 whi
    old "Hehe, enjoy this huge cock Jade."
    new "へへ、この大きなちんこを楽しんでくださいね、ジェイド。"

    # say L367 whi
    old "I bet you've been wanting to get his hot dick in your mouth for a while, haven't you?"
    new "きっと彼の熱いちんこを口に入れたかったと思ってたんでしょ、そうよね？"

    # say L368 jad
    old "Mmmm!"
    new "んっ！"

    # say L369 whi
    old "Hahaha, that's all the answer I needed."
    new "ははは、それだけの答えが得られたわ。"

    # say L373 whi
    old "I can tell you girl, this is about a hundred times better than your ex-husband's limp dick!"
    new "君の元夫のしおれたチンポより、これの百倍も良いってわかるわ！"

    # say L374 jad
    old "Slrrrrp! Mmmm, yeah!"
    new "スルルルッ！　んん、そうね！"

    # say L375 whi
    old "Mmmm, how sexy you look with a big cock in your mouth."
    new "んん、大きなちんこを咥えている君の姿がとってもセクシーね。"

    # say L379 whi
    old "Oh yeah baby! let's make him cum. You want him to cum in your mouth and taste that big load, right?"
    new "オーやっぱりベイビー！ 来てあげて。君の口の中で大きく出してほしいわ、そうよね？"

    # say L380 jad
    old "...Y- yes, I want it..."
    new "…はい、欲しくて…"

    # say L381 whi
    old "You already heard it please, don't hold back and give us a huge cumshot."
    new "もう聞いてるでしょう、遠慮しないで大きな cumshot をください。"

    # say L405 pla
    old "I- I think I’m about to...!"
    new "俺、もう出そう…！"

    # say L406 whi
    old "That’s it, cum for us baby!"
    new "それだわ、私たちのために射精してちょうだい宝贝！"

    # say L407 whi
    old "I want you to cum in her mouth!"
    new "彼女の口でイッてほしいの！"

    # say L408 whi
    old "You are going to drink every single drop, Jade."
    new "あなたは一滴残らず全部飲むんだよ、ジェイド。"

    # say L415 whi
    old "Ohh yeah, that was a huge load. Did you enjoy it Jade?"
    new "ああ、そうよ、それは大量だったわね。ジェイド、楽しめたかしら？"

    # say L416 jad
    old "Uhh... Y- yes..."
    new "うっ… はい…"

    # say L417 whi
    old "What did I tell you? This is a lot better than masturbating."
    new "何と言ったか覚えてるでしょ？これなら自分でやるよりずっといいわよ。"

    # say L418 whi
    old "And with such a young gifted man, you didn’t know what you were missing on girl."
    new "そんな若い才能のある男の人がいるのに、君は自分が何を逃しているのか気づいていなかったのね。"

    # say L419 jad
    old "I- I suppose you’re right."
    new "うーん、それはそうかも知れませんね。"

    # say L420 whi
    old "You know I’m right. Now let me help you clean up all this mess."
    new "私が正しいことくらいわかるでしょう。さあ、この片付けをお手伝いしましょう。"

    # say L432 pla
    old "Uhh, w- what is happening?"
    new "うーん、これって一体何が起こってるんだ？"

    # say L433 jad
    old "Well, you know what Mrs. White said last time."
    new "まあ、前回ミス・ホワイトが言ったことを覚えてるでしょう。"

    # say L434 jad
    old "Maybe we should try to do some of this on our own."
    new "自分でやってみるのもいいかもしれないね。"

    # say L436 jad
    old "To be honest, I’ve been thinking about this way too much, it’s about time I do something about it."
    new "正直、こればっかり考えてて、そろそろ何かしないとね。"

    # say L440 jad
    old "Hmph! Slrrrp!"
    new "ふん！スルルル！"

    # say L441 jad
    old "I can kind of see why Hinn likes you so much."
    new "KINDA SEE WHY HINN LIKES YOU SO MUCH、ね。"

    # say L442 jad
    old "How could she not? With such an amazing cock!"
    new "どうして好きになれないって？こんなに素晴らしいチ○ポなのに！"

    # say L446 jad
    old "I love how hot your cock is?"
    new "あなたのち○こ、ホントに熱くて好きだよ？"

    # say L447 jad
    old "Are you liking it, honey?"
    new "甘いの、気に入ってる？"

    # say L448 pla
    old "Mmm, yeah..."
    new "うん、そう…"

    # say L449 jad
    old "Me too!"
    new "私も！"

    # say L472 pla
    old "I- I think I’m about to cum!"
    new "俺、もうイキそうだ！"

    # say L473 jad
    old "It’s ok, you can cum in my mouth!"
    new "大丈夫、私の口でイッていいよ！"

    # say L474 jad
    old "I want to taste it again!"
    new "また味わいたいの！"

    # say L481 jad
    old "Phew, that was really good [pla]."
    new "ふう、それって本当に美味かった [pla]。"

    # say L494 jad
    old "OH MY GOD!! Oh wow!"
    new "ああっ、すごかった！！"

    # say L495 whi
    old "Hahaha, he’s huge isn’t he?"
    new "ははは、大きいよね。"

    # say L496 whi
    old "Just relax and enjoy it girl."
    new "リラックスして楽しんでちょうだいね、Jadちゃん。"

    # say L497 whi
    old "Not always can you enjoy something like this."
    new "特別な機会じゃないとこんな風に楽しめないのよ。"

    # say L501 jad
    old "Ah! Ah! I can’t! This is just too good!"
    new "ああ！ああ！もう無理！これ、本当に気持ちよすぎ！"

    # say L502 whi
    old "Yeah that’s right, take it all."
    new "そうだよ、全部受け取っちゃいな。"

    # say L503 whi
    old "Ha! I bet that looser of your ex-husband never fucked you like this!"
    new "ハ！ あの情けない元夫なんて、君をこんなふうにしたことがないだろうね！"

    # say L504 whi
    old "What do you say [pla]? How does it feel to have two MILFS like us just for you?"
    new "何て言うの、[pla]？ 二人の milf が君だけのためにこんなことしてるの、どんな気分？"

    # say L508 whi
    old "Did you ever feel anything like this before, Jade?"
    new "前にこんな感じしたことあるの、ジェイド？"

    # say L509 jad
    old "Ahh! Ahh! O- of course not!"
    new "アッ！アッ！もちろんそんなことないよ！"

    # say L510 whi
    old "Hahaha, I love to see you like this!"
    new "ははは、君がこんな感じになるのを見るのが大好きよ！"

    # say L511 whi
    old "Enjoy it girl, you deserve it!"
    new "楽しんでいいわ、君にそれを受けさせる価値があるのよ。"

    # say L534 whi
    old "Keep going [pla]!"
    new "続けて [pla]！"

    # say L535 whi
    old "You’re about to make her cum!"
    new "君が彼女をイかせそうよ！"

    # say L536 whi
    old "Don’t stop! Don’t stop now!"
    new "止めてほしくない！今こそ止めてほしくない！"

    # say L538 jad
    old "Ahhhh, Ahhhhh!"
    new "アーッ、アーッ！"

    # say L544 jad
    old "Oh my! That was great, really great."
    new "ああ、すごいだった、ほんとにかわいい。"

    # say L545 whi
    old "And look at that, he just came and he’s still hard!"
    new "見てごらん、出しちゃったのにまだ硬いのよ。"

    # say L546 whi
    old "It must be great to be that young!"
    new "若さは素晴らしいわね！"

    # say L547 whi
    old "But now it’s my turn."
    new "でも今は私の番です。"

    # say L548 whi
    old "Come here [pla], I want you to fuck me hard."
    new "こちらに来て [pla]、強く犯してほしいの。"

    # say L565 whi
    old "Nngh! Oh yeah, that’s it!"
    new "ンッ！ああ、そう、その通り！"

    # say L566 whi
    old "That’s just what I have been waiting for."
    new "それが待っていたのよ。"

    # say L567 whi
    old "Uhhh, it just fills me up!"
    new "うーん、これで満足しちゃう！"

    # say L571 whi
    old "Ah! Ah! Ah! It’s so big!"
    new "あっ！あっ！あっ！大きいわ！"

    # say L572 whi
    old "I want to keep being fucked by you everyday!"
    new "毎日あなたに犯されてみたいです！"

    # say L577 whi
    old "I- I never had any sex like this with my ex-husband either!"
    new "私だって、元夫とはこんな風なセックスしたことがないわ！"

    # say L578 whi
    old "It’s unbelievable how good this is!"
    new "これほど気持ちいいなんて、信じられないです！"

    # say L579 whi
    old "Keep going [pla]! Keep pounding my pussy!"
    new "続けて [pla]！ 私のオマンコをガンガン突いて！"

    # say L580 whi
    old "Yes! yes! yes!"
    new "うん！うん！うん！"

    # say L603 pla
    old "Mrs. White, I can’t hold it in any longer!"
    new "白さん、もう我慢できないよ！"

    # say L604 whi
    old "Cum! Cum inside me!"
    new "出して！中に出して！"

    # say L605 whi
    old "Oh my God! I have missed this cock so much!"
    new "ああっ！このペニスがどれだけ恋しかったか！"

    # say L606 whi
    old "I love being fucked by you!"
    new "あなたに犯されて感じるのが大好きです！"

    # say L613 whi
    old "Well, I must say that was wonderful."
    new "まあ、本当に素晴らしい体験だったわ。"

    # say L614 whi
    old "Just look at you Jade! You look so calm and relaxed now!"
    new "ジェイド、見てごらん！ 今、全然落ち着いてリラックスしてるじゃない！"

    # say L615 jad
    old "Yeah, I think you’re absolutely right!"
    new "そうよ、君が言う通りだわ！"

    # say L616 jad
    old "I can’t believe how relaxed I am!"
    new "信じられないほどリラックスしてるわね。"

    # say L617 jad
    old "I must say, I don’t even care about what’s happening with Hiashi right now. I hope he’s very happy with his new wife."
    new "正直、ハイアシのことなんて今は気にもしていないわ。新しい奥さんと幸せになってくれることを願うわ。"

    # say L618 jad
    old "If she doesn’t cheat on him."
    new "もし彼女が浮気しなければね。"

    # say L619 whi
    old "Hahahaha!"
    new "ははははは！"

    # say L620 jad
    old "Hahahaha."
    new "ははははは。"

    # say L621 whi
    old "Well, I think we should better get dressed before your daughter gets home."
    new "まあ、娘が帰ってくる前に服を着た方がいいわね。"

    # say L622 jad
    old "Right, right."
    new "そうだな、そうだな。"

    # say L636 jad
    old "I- it's so big... Oh my God!"
    new "あ、大きくて……神様！"

    # say L637 jad
    old "Mmmm [pla]! I could get addicted to your cock!"
    new "うん [pla]！あなたのち○こにハマっちゃいそう！"

    # say L638 jad
    old "No wonder Hinn always wants to fuck with you!"
    new "なるほど、ヒンはいつもあなたとセックスしたいんだね！"

    # say L643 jad
    old "It’s so hot! So thick and hard!"
    new "熱い！太くて硬い！"

    # say L644 jad
    old "I can’t resist it!"
    new "我慢できない！"

    # say L648 jad
    old "Yes! Yes! Yes! Keep going!"
    new "はい！はい！はい！もっと続けて！"

    # say L649 jad
    old "Just like that!"
    new "その通りに！"

    # say L650 jad
    old "Fuck me, fuck me harder [pla]!"
    new "私を犯して、もっと強く犯して [pla]！"

    # say L651 jad
    old "Ahhh! I love it!"
    new "アッ！大好き！"

    # say L674 jad
    old "I'm about to cum honey!"
    new "もうすぐイクわよ、 Darling！"

    # say L676 jad
    old "L- let's do it!"
    new "*L- 一緒にやろう！"

    # say L677 jad
    old "Let's cum together!!"
    new "一緒にイこう！"

    # say L685 jad
    old "Wow, that was wonderful honey."
    new "Wow、それは素晴らしい経験だったわね、ハニー。"

    # say L686 jad
    old "And the shower it’s also working perfectly."
    new "シャワーもちゃんと動いてるわ。"

    # say L687 jad
    old "Oh my God! It's too late, Come on honey, let’s get dressed."
    new "あら、もう遅いわ！さあ、ハニー、服を着よう。"


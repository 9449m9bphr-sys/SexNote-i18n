# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Dialogos.rpy
translate japanese strings:

    # say L9 pla
    old "Another day..."
    new "また一日が来たな。"

    # say L10 pla
    old "Let’s just get through classes and survive."
    new "授業を乗り切って生き延びよう。"

    # say L11 pla
    old "Hope nothing weird happens today."
    new "今日は何も変なことが起こらないといいな。"

    # say L16 pla
    old "Hmm... What's that sound coming down the hall?"
    new "ん……廊下から何か音が聞こえてくるな。"

    # narrator L17 
    old "{i}Now every step just pulls me down...{/i}"
    new "{i}今、一歩ずつ足が重たくなっていく...{/i}"

    # say L18 pla
    old "({i}Sounds like music, but faint. Someone’s phone playing a song?{/i})"
    new "{i}音楽みたいだけど、薄いな。誰かのスマホで曲が流れてるのか？{/i}"

    # narrator L19 
    old "{i}Everything I wanted slips right through my hands...{/i}"
    new "{i}俺が欲しかったものは全部、手から滑り落ちていく...{/i}"

    # say L20 pla
    old "No way, it’s a voice. Singing softly... from the girls’ bathroom?"
    new "無理、それは声だ。優しく歌ってるのが女子トイレから聞こえる...？"

    # narrator L21 
    old "{i}And I’m still breathing... but I don’t understand...{/i}"
    new "{i}そして、俺はまだ息をしている……でも、理解できない……{/i}"

    # say L22 pla
    old "({i}That melody’s got so much heart. Who’s in there?{/i})"
    new "{i}そのメロディー、心がこもってるな。誰がいるんだ？{/i}"

    # say L26 pla
    old "Hey [bil]... that singing? Was that you?"
    new "Hey [bil]… その歌、君が歌ってたのか？"

    # say L27 bil
    old "Heh, singing? Nah, probably just music from next classroom."
    new "へへ、歌？　多分隣の教室から流れてる音楽だね。"

    # say L28 pla
    old "Uhh, music? It sounded like someone singing, like right here."
    new "うーん、音楽？　誰かがここらへんで歌ってるみたいだったけど。"

    # say L30 bil
    old "Or someone’s phone blasting some old track. This place is a noise fest."
    new "誰かのスマホで古い曲を大音量で流してるだけかも。ここは騒音の宝庫だもん。"

    # say L31 pla
    old "({i}She’s dodging it hard. But that voice was totally hers.{/i})"
    new "{i}彼女はそれを避けようとしてるけど、その声は間違いなく彼女のものだったよ{/i}"

    # say L32 pla
    old "Come on, [bil], it was too good to be just an echo."
    new "Come on、[bil]、それだけはただの反響じゃなかったぜ。"

    # say L33 bil
    old "Too good? Dude, if I was singing, I’d be viral already. Blame the vents."
    new "いい声？冗談よ、もし私が歌っていたら、もうバズってたわ。換気口のせいよ。"

    # say L34 pla
    old "The vents? For real? It had this raw emotion..."
    new "換気口？本気で？それには生々しい感情がこもってたんだよ..."

    # say L35 bil
    old "Emotional vents, then. Case closed. Catch you later, [pla]."
    new "感情的な換気口か、そうなのか。じゃあ、またね、[pla]。"

    # say L37 pla
    old "Whoa, her notebook just dropped."
    new "誰あ、彼女ノートが落ちた。"

    # say L39 pla
    old "What’s this? Doodles, messy scratches... hold up, are these lyrics?"
    new "何これ？落書きと乱雑な線……待て、これは歌詞なのか？"

    # say L40 pla
    old "Music notes scribbled everywhere. ‘Faded echoes, songs we lost...’"
    new "音符がいたるところに書き散らされているな。『褪せたエコー、失われた歌…』"

    # say L41 pla
    old "({i}This matches the melody perfectly. It was definitely her.{/i})"
    new "({i}これ、メロディと完全に一致してるな。間違いなく彼女だ。{/i})"

    # say L42 pla
    old "Why deny it? Someone with this talent..."
    new "なぜ否定する？ この才能があるのに…"

    # say L43 pla
    old "({i}Hiding something this raw doesn’t make sense. I’ll take it to her place.{/i})"
    new "{i}こんな生々しい才能を隠すのは意味がない。彼女のところに持って行こう。{/i}"

    # say L44 pla
    old "Yeah, that’s the right call."
    new "そうだな、その判断は正解だ。"

    # say L50 jon
    old "Oh, [pla]! What a treat to see you, honey!"
    new "Oh、[pla]！お会いできてうれしいわ、ハニー！"

    # say L51 pla
    old "Hey, Mrs. Jones. Sorry for dropping by unannounced."
    new "ジョーンズさん、突然访ねて申し訳ありません。"

    # say L52 jon
    old "Nonsense, you’re always welcome. How’s school going?"
    new "ナンセンス、いつでも歓迎よ。学校はどう？"

    # say L53 pla
    old "It’s alright. Keeps me on my toes."
    new "大丈夫です。気を引き締めるよ。"

    # say L54 jon
    old "Oh, you’re always so busy! [bil]’s out with friends, but what brings you by?"
    new "あら、いつも忙しそうね！[bil]は友達と出かけてるけど、何用でいらっしゃったの？"

    # say L55 pla
    old "Well, she dropped her notebook at school. Figured it’s important."
    new "まあ、彼女は学校でノートを落としたんだ。大事なものかもしれないと思ってね。"

    # say L56 jon
    old "Let me see... Oh, these sketches and notes. Takes me way back."
    new "見せてみましょう……あ、これらのスケッチとノートね。懐かしいわ。"

    # say L57 pla
    old "Way back? To what, if it’s okay to ask?"
    new "WAY BACK？何を指しているのか、もし聞くことがよければ教えてくれ。"

    # say L58 jon
    old "To when she was little. Her parents... they used to sing with her every night."
    new "小さな頃のことね。彼女の両親……毎晩一緒に歌を歌ってくれていたのよ。"

    # say L59 pla
    old "({i}Singing together? That’s so sweet.{/i})"
    new "一緒に歌うの？それってすごく甘いな、{i} {/i}"

    # say L60 pla
    old "I can imagine that. Must’ve been her whole world."
    new "想像できるよ。彼女の世界の全てだったに違いない。"

    # say L61 jon
    old "It was. Her dad with his old guitar, her mom humming along. It lit her up."
    new "そうです。彼女の父親が古いギターを弾き、母親がハーモニーを取っていた。彼女を輝かせていたのね。"

    # say L62 pla
    old "({i}So that’s where her gift comes from.{/i})"
    new "{i}そうか、その才能はそこで生まれたんだな。{/i}"

    # say L63 pla
    old "I heard her today. It really hit me deep."
    new "今日彼女の歌を聞いた。本当に心に響いたよ。"

    # say L64 jon
    old "Oh really? You heard her singing today?"
    new "おお、本当ですか？今日歌を聞きましたか？"

    # say L65 jon
    old "Well, she used to sing all the time. It was such a lovely thing to hear... but after her parents passed, everything changed for her."
    new "彼女は昔、よく歌っていました。聞いていると本当に心が和みました…でも、彼女の両親が亡くなった後、すべてが変わってしまいました。"

    # say L66 pla
    old "Oh, I didn't know? I’m so sorry, Mrs. Jones. That sounds so tough."
    new "ああ、知らなかったな。申し訳ありません、ジョーンズ夫人。そんな辛い経験をされたなんて。"

    # say L67 jon
    old "It was a long time ago... A car accident. Took them both in an instant."
    new "それはもう昔のことです…… 車の事故で二人とも一瞬に命を失いました。"

    # say L68 pla
    old "({i}Gone just like that. No wonder it shook her.{/i})"
    new "{i}そう簡単にいなくなりましたね。彼女がショックを受けたのも無理はありません。{/i}"

    # say L69 pla
    old "That’s so sad. How did [bil] get through it?"
    new "そんなに悲しいのね。[bil]はどのようにそれを乗り越えたの？"

    # say L70 jon
    old "Faith carried us. But for her, singing turned into pain."
    new "信仰が私たちを支えてくれました。でも彼女にとっては、歌うことが痛みに変わってしまったんです。"

    # say L71 jon
    old "Every note brought their voices back. First happy, then just the hurt."
    new "毎つの音が彼らの声を呼び戻したの。最初は幸せだったけど、次第にただの痛みだけが残った。"

    # say L72 pla
    old "So it stopped being joy. More like ripping open old wounds?"
    new "じゃあ、もう喜びじゃなくなったのか。古い傷を抉るようなものになったって感じか？"

    # say L73 jon
    old "Exactly. She shut it down, like flipping a switch."
    new "そうです。彼女はスイッチを切りるようにそれを止めた。"

    # say L74 pla
    old "({i}That cool act she pulls... it’s gotta be shielding all this.{/i})"
    new "{i}彼女のそのクールな態度……全部を隠してるんだよな。{/i}"

    # say L75 pla
    old "I get why she’d hide something tied to them."
    new "彼女がそれを隠す理由は分かるけど。"

    # say L76 jon
    old "You see her heart, [pla]. Not many do."
    new "あなたは彼女の心を見ているのね、[pla]。そんな人は多くないわ。"

    # say L77 pla
    old "Just wish it didn’t weigh her down like that. Feels so unfair."
    new "ただ、それが彼女を重くのしかかっているのが悔しいんだよ。不公平な気がする。"

    # say L78 jon
    old "Life’s not always kind, honey. But you’re sweet to care."
    new "人生はいつも優しくないわ、ハニー。でもあなたが気にかけてくれるのは素敵なことよ。"

    # say L79 pla
    old "I’ll leave the notebook. Tell her I didn’t snoop too much."
    new "ノートを置いていくよ。あまり覗かなかったって伝えてね。"

    # say L80 jon
    old "Of course, dear. Safe walk home now."
    new "もちろん、亲爱的。回家的路上要注意安全哦。"

    # say L81 pla
    old "Thanks, Mrs. Jones. See you soon."
    new "ありがとう、ジョーンズさん。またね。"

    # say L87 pla
    old "Man... what a day."
    new "今日も大変だったな。"

    # say L88 pla
    old "So that’s why she acts like nothing touches her."
    new "そうか、だから彼女は何にも動じないんだな。"

    # say L89 pla
    old "Losing both parents at once... and singing was the last thing connecting her to them."
    new "両親を一度に失って……歌が彼女と彼らをつなぐ最後のものだったんだ。"

    # say L90 pla
    old "Now I get why she kept dodging the whole thing. Every note probably feels like losing them again."
    new "今さらわかるけど、彼女がずっと避け続けてた理由。毎回の音がまた彼らを失うような気分になったんだろう。"

    # say L91 pla
    old "She’s not hiding because she’s shy. She’s hiding because it hurts too much to let it out."
    new "彼女は照れてるわけじゃない。歌うのが痛すぎるから隠してるんだ。"

    # say L92 pla
    old "That cool girl armor isn’t just attitude. It’s survival."
    new "そのクールな少女の鎧はただの態度じゃない、生き残るための手段なんだ。"

    # say L93 pla
    old "But that voice... It’s still in there. And it’s beautiful."
    new "でもその声……まだそこにあるんだ、美しいと。"

    # say L94 pla
    old "If there’s even a tiny chance something could help her feel that joy again... I have to try."
    new "もし少しでも彼女がその喜びを感じられる可能性があるなら…試さなきゃいけない。"

    # say L95 pla
    old "I don’t know how yet, but I’m not letting her carry this alone."
    new "まだどうするかわからないけど、彼女が一人で抱え込まないようにするつもりだ。"

    # say L104 pla
    old "({i}Still can’t get [bil]’s voice out of my head. That song was something else.{/i})"
    new "({i}まだ [bil]の声が頭から離れないな。あの曲は何か特別だったよ。{/i})"

    # say L105 pla
    old "Hold up, what’s this flyer on the wall?"
    new "ちょっと待て、この壁に貼ってあるフライヤーは何？"

    # say L107 pla
    old "School’s doing a music contest? Sign-ups are open..."
    new "学校で音楽コンテストやってるのか？応募受付中だな…"

    # say L108 pla
    old "Wait. This is exactly what [bil] needs right now."
    new "待った。これこそ[bil]が今必要としてるものだ。"

    # say L110 pla
    old "({i}She’s got the talent, she just doesn’t show it. This could pull her out of that shell.{/i})"
    new "{i}彼女には才能があるんだ、ただ見せないだけだ。これで殻から出られるかもしれないな。{/i}"

    # say L111 pla
    old "({i}She’s literally going to murder me for signing her up without asking.{/i})"
    new "（{i}彼女は文字通り、無断で登録した俺を殺すだろうな。{/i}）"

    # say L112 pla
    old "({i}Like, straight-up bury me in the backyard. But it’s worth the risk, right?{/i})"
    new "{i} 直接裏庭に埋めるだろうな。でも、リスクを取る価値があるよね？{/i}"

    # say L113 pla
    old "Gotta do it."
    new "やるしかないな。"

    # say L119 pla
    old "Hi, are you Ms. Beylaine?"
    new "あの、ベイレインさんですか？"

    # say L120 bey
    old "That’s me, honey! Come in, come in."
    new "俺だよ、ハニー！入って、入って。"

    # say L121 pla
    old "I saw the flyer about the music contest. Looks really cool."
    new "コンテストのチラシを見たよ、めっちゃかっこよさそうだな。"

    # say L122 bey
    old "Cool? Baby, it’s about to be everything."
    new "クール？ベイビー、これはすべてを揺るがすぜ。"

    # say L123 pla
    old "I wanna sign up. Me and my friend [bil]."
    new "俺も参加したいな。俺と友達の[bil]で。"

    # say L124 bey
    old "Love the duo energy! Tell me about you two."
    new "二人組のエネルギー、好きだな！二人について教えてくれ。"

    # say L125 pla
    old "Well, she’s got an insane voice, but she keeps it hidden. I thought this might be good for her."
    new "彼女の声は狂気じみてるけど、いつも隠してるんだ。これで彼女にとっていい機会になると思ってさ。"

    # say L126 bey
    old "Hidden talent? That’s my favorite kind."
    new "隠れた才能か、それが一番好きだな。"

    # say L127 bey
    old "What about you, handsome? What do you bring to the stage?"
    new "君は？ハンサムな君は何をステージにもってくるんだ？"

    # say L128 pla
    old "Uhh... honestly? Nothing. I can’t sing, can’t play. Zero."
    new "うーん…正直に言うと、何もできない。歌も楽器もダメだ。ゼロだ。"

    # say L129 bey
    old "Zero today doesn’t mean zero tomorrow."
    new "今日のゼロが明日のゼロじゃねえさ。"

    # say L130 bey
    old "Don't worry, we’re doing practice sessions first. Technique, composition, stage fire. I pull the best out of everybody."
    new "心配するな、まずは練習から始めよう。テクニック、作曲、ステージでのパフォーマンス。みんなの最高を引き出すよ。"

    # say L131 pla
    old "So we get actual coaching before the contest?"
    new "コンテスト前に本格的な指導があるってことか？"

    # say L132 bey
    old "Exactly. I don’t just throw y’all to the wolves. We build it together."
    new "もちろん、ただ狼に放り出すわけじゃない。一緒に作り上げていくんだ。"

    # say L133 pla
    old "Oh, that sounds perfect, actually."
    new "なるほど、それなら最高だ。"

    # say L134 bey
    old "Ok, to start, I just need you to fill out a couple forms for you and your friend. After that, I’ll reach out to schedule the audition."
    new "じゃあ、まずは君と君の友達のためのいくつかの書類を埋めてもらうんだ。その後、オーディションの日程を調整するために連絡するよ。"

    # say L135 pla
    old "Got it, thanks, Ms. Beylaine. This means a lot."
    new "わかった、ありがとう、ベイレイン。これで希望が持てたよ。"

    # say L136 bey
    old "Call me Bey. And tell your friend: when she’s ready to own that stage, I got her."
    new "ベイって呼んでくれ。そして友達にも伝えて：ステージを制覇する気になったら、俺がバックアップするよ。"

    # say L142 pla
    old "({i}Best idea I’ve ever had.{/i})"
    new "（{i}最高のアイデアだったな。{/i}）"

    # say L143 pla
    old "({i}Now I just gotta figure out how to tell [bil] without her breaking my neck.{/i})"
    new "{i}これからは、[bil]にどうやって伝えようか考えないとな。でも首を絞められそうで怖いぞ。{/i}"

    # say L144 pla
    old "({i}She’s scary when she’s mad... but this is for her.{/i})"
    new "{i}彼女が怒ると怖いけど…でもこれは彼女のためだよ。{/i}"

    # say L154 pla
    old "Hey [bil]! You’re not gonna believe what I just did!"
    new "Hey [bil]！これ信じられないんだけど、さっきやったことあるよ！"

    # say L155 bil
    old "Hmm, what now?"
    new "Hmm、何それ？"

    # say L156 pla
    old "I signed us up for the music contest!"
    new "音楽コンテストに俺たちを申し込んだぞ！"

    # say L157 bil
    old "You... did what?"
    new "あなた……何したの？"

    # say L158 pla
    old "Yeah! They’ve got coaching and everything. It’s perfect!"
    new "そうだよ！コーチングもあるし、完璧じゃない？"

    # say L159 bil
    old "You signed me up. Without even asking."
    new "あなたが勝手に申し込んだのね。何も聞かずに。"

    # say L160 pla
    old "I know, I know, it sounds crazy, but just hear me out—"
    new "知ってる、知ってる、めちゃくちゃ聞こえるけど、ちょっとだけ聞いてくれ——"

    # say L161 bil
    old "No. You don’t get to decide that for me, [pla]."
    new "ダメよ。そんなこと私に勝手に決めてはいけないわ、[pla]。"

    # say L162 pla
    old "No, no, it's just that you have this insane voice. Like, people need to hear it."
    new "いやいや、お前の声が凄いってことだよ。みんなに聴かせるべきだろ。"

    # say L163 bil
    old "That’s not the point. It’s my thing, not yours."
    new "それは違うわ。私のことだから、あなたが決めるものじゃない。"

    # say L164 pla
    old "Come on, it’s just a contest! You’d crush everyone."
    new "Come on, it’s just a contest！ You’d crush everyone."

    # say L165 bil
    old "Stop acting like you know what’s best for me."
    new "止めてよ、私が何が一番いいのか分かってるつもりなんだけど。"

    # say L166 pla
    old "I’m not! I just... saw the flyer and thought 'this is made for [bil]'."
    new "俺じゃないよ！ただ…ポスターを見て「これは[bil]のためにあるんだ」と思っただけさ。"

    # say L167 bil
    old "Well, you thought wrong."
    new "そうじゃなかったね。"

    # say L170 pla
    old "Wait, your grandma told me how much you used to love singing with your parents—"
    new "待て、君の祖母が君が昔親と一緒に歌うのが大好きだったって教えてくれたんだよ——"

    # say L174 pla
    old "I- I- I’m sorry!"
    new "すまん、すまん、すまん！"

    # say L175 pla
    old "I- I didn’t mean it l- like that, I- I swear!"
    new "俺ー、違う意味じゃなかった、本当に！"

    # say L176 bil
    old "You have no idea what you’re talking about."
    new "あなたは全然何を言っているのかわかっていないわ。"

    # say L177 pla
    old "I know! I messed up, okay? I’m really sorry."
    new "分かってるよ！ やっちゃったってことだ、許してくれよ。本当にごめん。"

    # say L178 pla
    old "I just... I thought it would help. That’s all."
    new "俺ただ……君を助けると思ってたんだよ。それだけさ。"

    # say L179 bil
    old "You don’t get to dig into my life like that!"
    new "勝手に私の人生を掘り下げるなんてダメよ！"

    # say L180 pla
    old "You’re right. I overstepped. Big time."
    new "君が正しい、俺は線を越えたよ。大いにね。"

    # say L182 pla
    old "I- I’m sorry, [bil]. Seriously."
    new "ごめん、[bil]。本気で。"

    # say L183 bil
    old "Tsk..."
    new "チッ…"

    # say L185 bil
    old "Mind your own business, [pla]. This isn’t your thing to fix."
    new "自分のこと考えな、[pla]。これって君が直すようなことじゃないよ。"

    # say L186 pla
    old "I get it. But your voice... it’s too good to stay hidden."
    new "分かってるけど、君の声…隠すのはもったいないよ。"

    # say L187 bil
    old "Why do you even care?"
    new "何でそんなに気にしてるの？"

    # say L188 pla
    old "Because I hate seeing you hold back something you’re amazing at."
    new "君が凄い才能を隠すのを見るのは嫌なんだよ。"

    # say L189 bil
    old "It’s not that simple."
    new "そう簡単じゃないよ。"

    # say L190 pla
    old "I know it’s not. But just one practice. One."
    new "分かってるけど、ただ一回だけ練習してみてくれ。一回だけさ。"

    # say L191 bil
    old "You’re seriously not dropping this?"
    new "本気で諦めないの？"

    # say L192 pla
    old "I can’t. Not when I know how much talent you have."
    new "俺には無理だ。君の才能を知ってるからな。"

    # say L193 bil
    old "You’re impossible."
    new "あなたはムリゲーね。"

    # say L194 pla
    old "Please. One session. If it sucks, we never talk about it again."
    new "お願い、一回だけだ。もし駄目でも、二度と口に出さねえよ。"

    # say L196 bil
    old "You’re gonna keep bugging me until I say yes, aren’t you?"
    new "あなたが許すまでしつこく言うつもりだよね？"

    # say L197 pla
    old "Uhh... pretty much."
    new "うーん…ほぼその通りだな。"

    # say L198 bil
    old "Ughh... fine. One practice. Just to shut you up."
    new "うーん……いいわ。一回だけ練習するから、文句言わないでね。"

    # say L199 bil
    old "But that’s it. And after that, we’re done talking about it. Got it? End of discussion."
    new "でもそれだけよ。それからはこれ以上話さないわ。分かった？これで終わりよ。"

    # say L200 pla
    old "Deal! Thank you!"
    new "約束だな！ありがとう！"

    # say L201 bil
    old "Don’t thank me yet."
    new "まだ感謝しないで。"

    # say L202 bil
    old "And don’t you ever ever bring up my parents again. You hear me?"
    new "そして二度と私の親のことを言わないこと。わかった？"

    # say L203 pla
    old "Uhh, yeah, got it..."
    new "うーん、そうか、わかった……"

    # say L205 pla
    old "Phew.... Well, she didn’t kill me... I’ll call that a win."
    new "ふう……まあ、殺されなかったし……これで良しとしよう。"

    # say L206 pla
    old "One practice. That’s all I needed."
    new "一回の練習だけだった。それだけで良かった。"

    # say L216 pla
    old "The audition. The contest thing. Oh man, [bil] better not bail on me."
    new "オーディション、コンテストのやつさ。ああ、[bil] が逃げ出さないでくれよ。"

    # say L217 pla
    old "She said she’d show... right?"
    new "彼女は来てくれるって言った……よね？"

    # say L218 pla
    old "I have zero clue what I’m doing up there, but it’s for her. Gotta move."
    new "俺はあがって何するかさっぱりだけど、彼女のためだ。行かなきゃな。"

    # say L224 pla
    old "There you are! Ready for this?"
    new "そこにいるじゃん！準備できてる？"

    # say L225 bil
    old "Ready? I’m here because you wouldn’t shut up about it."
    new "準備できてる？私がここにいるのは、あなたがこれのことばかり言ってたからよ。"

    # say L226 pla
    old "Come on, it’s gonna be fine. Just one showcase."
    new "来いよ、大丈夫だよ。ただ一つのショーだけさ。"

    # say L227 bil
    old "Yeah, yeah. Let’s get this over with so I can go back to my life."
    new "うん、うん。早く終わらせちゃって、また普通の生活に戻りたいんだから。"

    # say L228 pla
    old "You’re gonna kill it, [bil]. I know it."
    new "大丈夫、君なら絶対うまくいくよ、[bil]。俺知ってるから。"

    # say L229 bil
    old "Save the pep talk, [pla]. I’m doing this to make you stop bugging me, remember?"
    new "激励の言葉は省略して、[pla]。私がこれをする理由は、あなたがしつこく言うのをやめてくれるからよ。"

    # say L230 pla
    old "Fair enough."
    new "わかったわね。"

    # say L232 bil
    old "Whatever. Let's go I don't have all day."
    new "行こうよ、時間ないんだから。"

    # say L233 pla
    old "Sure, let's go."
    new "行こうか。"

    # say L240 bey
    old "I’m Beylaine, but you can call me Bey, and I’m the teacher who’s going to get you ready to take this year’s Music Contest crown."
    new "俺はベイレインだけど、ベイって呼んでくれ。今年の音楽コンテストで優勝するため、君たちを準備する先生さ。"

    # say L241 bey
    old "Look around you. Every single person in this room has fire inside them."
    new "周りを見ろ。この部屋にいる誰もが心の中に炎を持っている。"

    # say L242 bey
    old "Some of you know it, some of you are scared of it, some of you are still hiding it. My job? Pull that fire out and turn it into a supernova."
    new "君たちはその炎を知っている者もいれば、怖がっている者もいる、まだ隠している者もいる。俺の仕事は、その炎を引き出し、超新星にすることだ。"

    # say L244 bey
    old "From today until the final I’m your personal mentor, private feedback, whatever each of you needs to bring your absolute best act."
    new "今日から最終日まで、俺が君たちの個人的なメンターだ。必要なフィードバックや、それぞれが最高のパフォーマンスを発揮するために必要なこと全部をサポートする。"

    # say L245 bey
    old "You’ll cry, you’ll laugh, you’ll hate me on Tuesdays and love me on Fridays, but by the final show you’ll thank me when the entire school is screaming your names."
    new "君たちは泣き、笑い、火曜日には俺を憎み、金曜日には愛するだろう。でも最終公演のとき、全校が君たちの名前を叫んでいるのを見て、俺に感謝することになる。"

    # say L246 bey
    old "I'll be here for everything you need, we’re talking vocal technique, stage command, songwriting, harmonies, emotional truth, the whole package."
    new "必要なことは全部サポートするよ、ボーカルテクニックからステージコマンド、作詞、ハーモニー、感情の真実まで、全部ね。"

    # say L248 bey
    old "So breathe, have fun, and remember: the stage is the one place where you’re allowed to be 100 % yourself. Ready? Let’s make magic!"
    new "息を吸って、楽しんで、覚えておきな：ステージは100％の自分を出せる唯一の場所だ。準備できてるか？魔法を起こそうぜ！"

    # say L252 sha
    old "Hit it, darling!"
    new "さあ、いこうよ、 Darling！"

    # say L253 rya
    old "Let’s give them a show they’ll never forget!"
    new "見せてやろう、忘れられないようなショーを！"

    # say L256 sha
    old "{i}We’re the headliners, baby, front page news!{/i}"
    new "{i}私たちはヘッドライナー、赤ちゃん、トップページのニュースになるよ！{/i}"

    # say L257 rya
    old "{i}Spotlights on us, no time to lose!{/i}"
    new "{i}スポットライトは私たちのもの、時間がないよ！{/i}"

    # say L259 rya
    old "{i}We own the stage every single night!{/i}"
    new "{i}毎晩、このステージは私たちのもの！{/i}"

    # say L267 bey
    old "Y’all just brought Broadway to this classroom! Energy off the charts, synchronization tighter than my ponytail, costume game insane."
    new "みんな、さすがだな！ブロードウェイを教室に持ってきたのか。エネルギー満点で、シンクロは俺のポニーテールよりきっちりしてるし、衣装も最高だ。"

    # say L268 bey
    old "My only note: sometimes less is more. When every second is maximum sparkle, there’s nowhere left to go for the big moments. Save some glitter for the finale, babies. Otherwise? Flawless."
    new "俺の唯一のアドバイスは、時々控えめな方がいいってことだ。常に最大の輝きだと、本番でどこまでいけるかわからなくなる。フィナーレのために少しはキラキラを温存しろ、ベイビーズ。それ以外は完璧だ。"

    # say L272 ari
    old "Let’s remind them why we’re here."
    new "ここに来た理由を思い出してあげるね。"

    # say L273 tay
    old "Exactly."
    new "そうだ"

    # say L276 ari
    old "{i}I’m feeling dangerous, feeling so brand new{/i}"
    new "{i}危険な気分、まるで生まれ変わったみたい{/i}"

    # say L277 tay
    old "{i}Shaking off the dust, ready for round two{/i}"
    new "{i}ほこりを振り落として、次のラウンドに備えてる{/i}"

    # say L278 ari
    old "{i}High notes climbing, watch me touch the sky{/i}"
    new "{i}高音を上げて、空に手を伸ばすところ見てよ{/i}"

    # say L279 tay
    old "{i}Beat drops heavy, no more asking why!{/i}"
    new "{i}ビートが重く落ちる、もう理由は聞かない！{/i}"

    # say L287 bey
    old "Lord have mercy on my edges! Ariana, those whistle tones cleaner than my Sunday choir. Taylor, that belt could wake the dead."
    new "神様、私の声の端を救ってください！アリアナ、そのホイッスルトーンは日曜日の合唱よりもずっときれいだな。テイラー、そのベルトは死人を起こすぜ。"

    # say L288 bey
    old "Pitch perfect, breath control insane, harmony game lethal."
    new "ピッチパーフェクト、息遣いのコントロールが尋常じゃねえ、ハーモニーの技も死ぬほど効果的だ。"

    # say L289 bey
    old "My tiny note: sometimes perfection can feel safe. Next time risk a little crack, a little rawness. Vulnerability wins hearts. But technically? Untouchable."
    new "俺の小さなアドバイス：時々、完璧さは安全に感じる。次は少し割れ声や生々しさを試してみろ。脆弱性が心を動かすぜ。でも技術的には？触れられない存在だな。"

    # say L293 pla
    old "Uhh... W- we didn’t really get a chance to rehearse..."
    new "うーん… わ、私たちあまり練習する機会なかったし…"

    # say L294 bil
    old "Ugh, just give me the mic."
    new "うっ、マイク貸して。"

    # say L308 bey
    old "Oh my gosh, Billie... honey. That wasn’t singing. That was bleeding through music."
    new "お gode、ビリー… かわいそうに。それは歌じゃなかったよ。音楽を切り裂いてただけだ。"

    # say L309 bey
    old "Your tone is pure velvet, phrasing is heartbreaking, emotional truth 100%. Volume was whisper quiet, but somehow you filled the entire room."
    new "君のトーンは純粋なベルベットで、フレージングは心を締めつけるほどで、感情的な真実性は100％だ。ボリュームは囁きほど静かだったけど、何故か君は部屋全体を埋めていた。"

    # say L310 bey
    old "Stage presence was nonexistent, lighting was wrong for that mood, and [pla]... sweetheart, you were a potted plant."
    new "ステージ上的存在感はゼロ、照明もそのムードには合ってなかったし、[pla]... 甘い子、君は観葉植物だったな。"

    # say L311 bey
    old "But the voice? The voice is once in a generation. We’re going to protect it, grow it, and teach it to roar when it needs to roar."
    new "でもその声はね、一世代に一度のものさ。俺たちが守り、育て、必要なら咆哮させることを教えてやるよ。"

    # say L312 bey
    old "[pla], next time you move, you breathe with her, you support her. Deal?"
    new "[pla]、次は動くとき、彼女と一緒に息を吸って、支えてあげるんだ。約束だな？"

    # say L313 pla
    old "Uhh... Y- yeah sure."
    new "うーん… よ、よし、わかった。"

    # say L319 bey
    old "Well, I have goosebumps from head to toe. Three completely different universes in one room."
    new "俺は頭から足の先まで鳥肌が立ってるよ。この部屋には全く異なる三つの宇宙があるんだ。"

    # say L320 bey
    old "Sharpay & Ryan: spectacle and precision. Ariana & Taylor: vocal olympics. Billie & [pla]: pure soul."
    new "シャープエイとライアンは見事なパフォーマンスと正確さ、アリアナとテイラーは声のオリンピック、ビリーと[pla]は純粋な魂だね。"

    # say L321 bey
    old "Next sessions we start real work: breathing, dynamics, choreography, song choice, storytellin, everyone gets one-on-one time with me."
    new "次回からは本格的な練習を始めるぞ：呼吸法、ダイナミクス、振り付け、曲選び、ストーリーテリング。全員が一人ずつ俺と時間を過ごす機会がある。"

    # say L322 bey
    old "Because every single one of you can win this thing. I’m not here to pick favorites; I’m here to make favorites out of all of you."
    new "君たち全員がこのコンテストを勝ち取れるんだ。お気に入りを選ぶためにここにいるんじゃない。全員を輝かせるためにここにいるんだ。"

    # say L323 bey
    old "Go home, rest those voices, dream big, and come back hungry. See you at the next session!"
    new "家に帰って声を休め、大きな夢を見て、次回はもっと意欲的に戻ってこい。次回のセッションで会おう。"

    # say L327 pla
    old "Wow, Billie, did you hear everything she was saying about your voice?"
    new "Wow、Billie、彼女が君の声について言ったこと全部聞こえたか？"

    # say L328 bil
    old "Yeah, yeah, Anyway. I did the one practice. We’re done."
    new "うんうん、とにかく。一回だけ練習したけど、これで終わりだよ。"

    # say L329 pla
    old "W- what? Are you serius? You were unbelievable—"
    new "ワッ、マジか？君の声は最悪だったよ——"

    # say L333 sha
    old "Unbelievable is right. Unbelievably depressing."
    new "信じられないほどだね。信じられないくらい暗いよ。"

    # say L335 sha
    old "What was that, a lullaby for the dead?"
    new "何それ、死んだ人のための子守唄か？"

    # say L339 sha
    old "Volume exists for a reason, sweetie. The back row couldn’t hear a thing."
    new "音量ってのは理由があるんだよ、かわいい子。後ろの列は全然聞こえなかったもん。"

    # say L341 ari
    old "Oh, wait, is this the girl who whispered her whole song? Heh"
    new "待って、この子がずっと囁いてたの？へへ"

    # say L343 tay
    old "I thought someone forgot to plug in the mic, hahaha."
    new "マイクをつなぐのを忘れたのかと思ったよ、ははは。"

    # say L344 sha
    old "Exactly. Bedroom sad girl vibes don’t win contests, sweetie."
    new "そうだね。寝室で悲しがってるだけじゃ勝てないよ、かわいこちゃん。"

    # say L345 ari
    old "We’re trying to make people dance, not cry."
    new "踊らせるためにやってるんだよ、泣かせるためじゃないからね。"

    # say L346 tay
    old "Yeah, save the therapy session for TikTok."
    new "そうだね、カウンセリングはティックトックでやってくれよ。"

    # say L347 pla
    old "Hey, that’s enough—"
    new "Hey、それ以上は無しだよ——"

    # say L349 sha
    old "Oh, and her backup tree finally speaks!"
    new "お、彼女のバックアップツリーがついに話しかけたね！"

    # say L351 ari
    old "What did you contribute, [pla]? Standing there like a scared statue?"
    new "お前は何したって？ ただ動かないで立ってるだけじゃないか、[pla]。"

    # say L352 tay
    old "Cute support system. Zero talent, zero movement."
    new "かわいいサポートシステムだな。才能もなくて、動こうとする気もないな。"

    # say L353 sha
    old "Maybe both of you should just quit now."
    new "二人ともさ、もう辞めた方がいいかもね。"

    # say L357 pla
    old "Hey, we are not-"
    new "おい、俺たちはまだ何も-"

    # say L361 bil
    old "You know what’s funny?"
    new "面白いことって知ってる？"

    # say L362 bil
    old "You three spend twenty minutes jumping and screaming so hard nobody can even remember the melody."
    new "あなた三人、二十分間跳ね回って騒いでるから誰もメロディ覚えてないよね。"

    # say L363 bil
    old "But sure, tell me my quiet voice is the problem."
    new "でもね、私の静かな声が問題だって言うなら。"

    # say L364 bil
    old "And [pla] standing still? At least he’s not faking it with glitter and fake smiles."
    new "そして [pla] 動きもしないって？せめて本物の感情を偽ってないだけマシだね。"

    # say L368 bil
    old "It’s kinda cute how you go all out screaming and dancing just to get a little attention."
    new "君が少しの注目を浴びるために全力で叫んだり踊ったりする姿はちょっとかわいいね。"

    # say L369 bil
    old "But volume isn’t talent, sweetie, glitter isn’t personality..."
    new "でもね、音量が才能じゃないのよ、スウィーティー、キラキラが人格じゃないの..."

    # say L370 bil
    old "And sequins don’t hide the fact you’re all noise and no soul."
    new "そして、スパンコールは君が音だけであって魂がないことを隠せないわ。"

    # say L371 bil
    old "See you in the final, girls."
    new "決勝で会おうね、ガールズ。"

    # say L372 bil
    old "Try not to choke when someone actually feels something."
    new "実際に何かを感じる人が現れたら、息を詰まらせないようにね。"

    # say L377 pla
    old "And that's how it's done."
    new "これが本番さ。"

    # say L383 pla
    old "Hey Billie, wait!"
    new "Hey Billie、待って！"

    # say L386 pla
    old "Are you okay?"
    new "大丈夫か、ビリー？"

    # say L387 bil
    old "Yeah, that was nothing. They’re just a bunch of idiots."
    new "大丈夫よ、特に何もなかったわ。ただのバカ者たちよ。"

    # say L388 pla
    old "Yeah, you’re right. But the way you shut them down? Damn, that was epic. I’ll never forget their faces haha."
    new "そうだな、君が言う通りだ。でも、あの連中を黙らせる様子は最高だったよ。絶対忘れない、ハハハ。"

    # say L389 pla
    old "And what was that about seeing them in the finals? I thought you were dropping out after the audition... like you said."
    new "そして、決勝で会うって話はどうなった？ 試験後には辞めるって言ってたじゃないか……忘れちゃったの？"

    # say L390 bil
    old "Drop out?"
    new "ドロップアウト？"

    # say L391 bil
    old "Please. After that little circus?"
    new "Please. あの小さなサーカスの後？"

    # say L392 bil
    old "I’m not giving them the satisfaction."
    new "満足させてやるもんか。"

    # say L393 pla
    old "So you’re staying?"
    new "じゃあ、君は残るんだね？"

    # say L394 bil
    old "Yeah, I’m staying."
    new "うん、残るよ。"

    # say L395 bil
    old "And we’re winning."
    new "そして勝ってるわ。"

    # say L396 pla
    old "Wait, for real?"
    new "待って、マジで？"

    # say L397 bil
    old "Dead serious. You wanted me in this mess? Congratulations."
    new "本気よ。君がこの状況を望んだってこと？おめでとう。"

    # say L398 bil
    old "Now we’re doing it my way. Every day. No excuses."
    new "これからは私のやり方でいくわ。毎日ね。言い訳は無しなの。"

    # say L399 bil
    old "Come to my place so we can start rehearsing and get ready."
    new "うちに来なさい。リハーサル始めて準備しよう。"

    # say L400 pla
    old "Of course I will!"
    new "もちろん行くよ！"

    # say L401 bil
    old "Alright. I’ll see you later, then."
    new "わかった。後でね。"

    # say L402 pla
    old "S- sure, see you later."
    new "うん、じゃあ後でね。"

    # say L404 pla
    old "({i}Holy crap... she’s actually doing it.{/i})"
    new "{i}くそ… 本当にやってくれたな。{/i}"

    # say L405 pla
    old "I seriously did not think she was gonna say yes."
    new "本気で彼女がYESって言うとは思ってなかったよ。"

    # say L406 pla
    old "Like... damn, she walked out of here looking way more motivated than I expected."
    new "… まさか本当にやってくれるとは思ってなかったけど、彼女がここから出て行った時のやる気満々な様子は予想以上だったな。"

    # say L407 pla
    old "Heh, I guess I owe part of that to those bullies running their mouths earlier."
    new "へへ、あの野郎らが口を滑らせたおかげで、彼女も本気になったみたいだな。"

    # say L408 pla
    old "If they hadn’t pushed her buttons, she’d never have agreed that fast."
    new "あの野郎らが彼女のボタンを押さなかったら、そんなに早く同意するわけないだろ。"

    # say L409 pla
    old "Phew... okay... okay, that’s one problem solved."
    new "ふう……よし……よし、一つの問題は解決したか。"

    # say L410 pla
    old "({i}Now there’s the other problem.{/i})"
    new "({i}さて、次に別の問題が出てきたな。{/i})"

    # say L411 pla
    old "What the hell am I supposed to do in a music contest when I know absolutely nothing about music?"
    new "音楽コンテストで音楽について全く知らない俺が、何をすればいいんだよ？"

    # say L412 pla
    old "Oh man... this is gonna be a disaster."
    new "オイ…これじゃあ大失敗だな。"

    # say L413 pla
    old "({i}Yeah... I’m so screwed.{/i})"
    new "({i}そうだな…もう駄目だな。{/i})"

    # say L422 bil
    old "Took you long enough."
    new "ようやく来たのね。"

    # say L423 pla
    old "Hey, sorry. Got caught up with stuff."
    new "Hey、ごめん。色々と手が離せなくて。"

    # say L424 bil
    old "Whatever. Come in, grandma’s out."
    new "まあいいや、入って来い、おばあちゃんは出かけてるから。"

    # say L425 pla
    old "O- ok..."
    new "お、そうか…"

    # say L429 bil
    old "Alright, Before we dive in, what do you know about music?"
    new "それじゃ、まず音楽についてどれくらい知ってる？"

    # say L430 pla
    old "Uhh... I can tell when a song’s good?"
    new "うーん… 良い曲かどうかはわかるかな？"

    # say L431 bil
    old "That’s it? No instruments? No singing lessons?"
    new "それだけ？楽器は？歌のレッスンは？"

    # say L432 pla
    old "Uhh nope. Closest I got was humming in the shower."
    new "うーん、違うな。シャワーで鼻歌を歌うのが精一杯だった。"

    # say L433 bil
    old "Hmph, great start."
    new "ふん、いいスタートね。"

    # say L434 bil
    old "Okay. We’re trying everything today. Voice, rhythm, keys. See what sticks to your zero skills."
    new "Okay. 今日からは全部やってみるわ。声もリズムも鍵盤も。あなたのゼロのスキルに何が合うか見てみる。"

    # say L435 pla
    old "Everything?"
    new "全部か？"

    # say L436 bil
    old "Yes, we’re gonna find something you don’t completely suck at."
    new "うん、君が全然ダメじゃない何かを見つけるんだ。"

    # say L437 bil
    old "I’m your coach now. And it’s gonna be brutal, because we’re winning this thing."
    new "私が君のコーチになるわ。厳しくいくからね、この勝負を絶対に勝つためには。"

    # say L438 bil
    old "No mercy, no excuses. You wanted me in? Now you’re in all the way."
    new "慈悲も言い訳も無しだよ。君が入れてほしいって言ったんだから、今さら引くわけにはいかないでしょ。"

    # say L439 pla
    old "No pressure then."
    new "全然プレッシャーないのかよ。"

    # say L440 bil
    old "All the pressure. We’re winning this, so get ready to sweat."
    new "全プレッシャーあるよ。勝つんだから、汗かく覚悟しといて。"

    # say L441 pla
    old "*Gulp*..."
    new "*ゴクリ*..."

    # say L445 bil
    old "Ok, voice first. Easiest to test."
    new "まずは声ね。テストしやすいから。"

    # say L446 bil
    old "Repeat after me, same melody."
    new "同じメロディで繰り返してみて。"

    # say L451 bil
    old "Your turn."
    new "あなたの番よ。"

    # say L455 bil
    old "Jesus Christ. Were you aiming for every wrong note?"
    new "ジェシス・クリスト、全然外れ目を狙っていたの？"

    # say L456 pla
    old "I told you I can’t sing..."
    new "俺は歌えないって言ったじゃん..."

    # say L460 bil
    old "Hmm, that wasn’t singing, that was a hate crime against music."
    new "うーん、それは歌じゃなくて、音楽に対する憎悪行為だったわね。"

    # say L461 pla
    old "I’ve never had lessons, okay?"
    new "俺はレッスン受けたことないんだよ。"

    # say L462 bil
    old "Noted. Voice is a disaster. Moving on."
    new "了解。声は最悪だわ。次に進もう。"

    # say L466 bil
    old "Keyboard. C major scale. Slow and clean."
    new "キーボード。ハ長調スケール。ゆっくりとクリアに。"

    # say L467 pla
    old "I think I can do piano... kind of."
    new "ピアノなら、ちょっとはできるかな。"

    # say L470 bil
    old "Great! You just played a car alarm."
    new "素晴らしい！車の警報器を弾いたね。"

    # say L471 pla
    old "My fingers won’t cooperate."
    new "指が全然協力してくれない。"

    # say L472 bil
    old "Your fingers have the coordination of drunk spaghetti."
    new "あなたの指は酔っ払ったスパゲッティみたいだね。"

    # say L473 pla
    old "I’ve never touched a piano in my life..."
    new "俺の人生で一度もピアノに触れたことないんだ..."

    # say L474 bil
    old "Clearly, try again."
    new "はっきりしているわ、もう一回試してみて。"

    # say L477 bil
    old "Wrong finger. Index, not pinky."
    new "間違えた指だよ。人差し指で、小指じゃなくて。"

    # say L478 pla
    old "Sorry, I guess I don’t have much finger dexterity."
    new "ごめん、指の器用さが足りないみたいだな。"

    # say L479 bil
    old "Oh? No practice with the fingers, huh?"
    new "Oh？ 指の練習、ほとんどしてないの？"

    # say L480 pla
    old "Hey!"
    new "Hey！"

    # say L481 bil
    old "Just saying. You’ve got zero practice to do... in a lot of areas."
    new "ただ言ってるだけよ。あなたにはまだ練習が必要な場所がたくさんあるわ。"

    # say L482 pla
    old "This is humiliating."
    new "これは屈辱だな。"

    # say L483 bil
    old "You´re right. Keyboard out. Next one."
    new "そうだよ。キーボードはいいわ。次の人ね。"

    # say L487 bil
    old "Ok, let's try with congas. Hands only. Feel the groove."
    new "じゃあ、コンガで試してみよう。手だけ使って、グルーヴを感じて。"

    # say L488 bil
    old "Four simple beats. One-two-three-four. Like a heartbeat."
    new "シンプルな４つのリズム。ワンツースリーフォー。心臓の鼓動みたいに。"

    # say L489 pla
    old "I got this."
    new "大丈夫、できるよ。"

    # say L493 bil
    old "You're rushing a little... No problem. Try again."
    new "ちょっと早すぎるよ… 大丈夫、もう一回試してみて。"

    # say L494 pla
    old "Uhh ok..."
    new "うーん、分かった…"

    # say L497 bil
    old "Hmm, you’re dragging a little now."
    new "うーん、今度は少し遅いかな。"

    # say L498 bil
    old "All good, here we go."
    new "大丈夫、ここから行こ。"

    # say L501 bil
    old "No, not quite my tempo."
    new "ちょっと待って、私のテンポじゃないな。"

    # say L502 pla
    old "What does that even—"
    new "何それ、どういうことだよ——"

    # say L507 pla
    old "Uhh... I... I d- don’t kn-"
    new "うーん… 俺… 俺 わかんないけど…"

    # say L508 bil
    old "Tell me are you a rusher, are you a dragger, or are you going to be ON MY FUCKING TIME!?"
    new "教えて、あなたは早送り？ゆっくり引き伸ばす？それとも私のペースに合わせられるの！？"

    # say L509 pla
    old "W- what?!"
    new "何それ？！"

    # say L510 bil
    old "Ugh... Nevermind. Mostly. Rhythm is dead."
    new "うげっ… 気にしないで。まあほとんどね。リズムなんて死んじゃってるもん。"

    # say L515 pla
    old "This is pointless. I suck at everything."
    new "これやっても無駄だ。俺は何にもうまくいかないんだ。"

    # say L516 pla
    old "I’m just gonna embarrass you in front of the whole school."
    new "全校の生徒の前であなたを恥ずかしくさせるだけだよ。"

    # say L518 pla
    old "I’m dragging you down. You saw those girls. They’re pros."
    new "俺が君を引きずり下げるだけだ。あの娘たちを見ただろ。彼女たちはプロだ。"

    # say L519 pla
    old "I’m the weak link. Maybe you should just go solo."
    new "弱いのは俺だ。一人でやった方がいいかもしれねえ。"

    # say L520 bil
    old "Are you quitting on me right now?"
    new "今私を諦めるの？"

    # say L521 pla
    old "I’m just being realistic."
    new "ただ現実を見ただけだよ。"

    # say L522 pla
    old "I don’t want to be the reason you lose."
    new "君が失う理由になりたくねえんだよ。"

    # say L523 bil
    old "You’re the reason I’m even doing this."
    new "あなたが私があくまでいる理由よ。"

    # say L524 bil
    old "You pushed me. Remember? 'You’ve got talent, don’t hide it.' Ring a bell?"
    new "あなたが私を押したのよ。覚えてる？「才能があるなら、隠すな」って。思い出した？"

    # say L525 bil
    old "So no. You don’t get to bail when it’s your turn."
    new "だからね、あなたの番になったら逃げるんじゃないよ。"

    # say L526 pla
    old "That’s different. You’re actually good."
    new "それは違う。君は本物だ。"

    # say L527 bil
    old "I wasn’t always. And I’m not doing this alone."
    new "そうじゃなかったわ。一人じゃやってないのよ。"

    # say L528 pla
    old "But I’m useless."
    new "でも俺は役立たずだ。"

    # say L529 bil
    old "You’re not useless. You’re untrained. And I’m fixing that."
    new "無能じゃない。未熟なだけだよ。だからそれを直してるの。"

    # say L530 pla
    old "This is gonna be tough... I mean, I basically suck at everything."
    new "これは大変そうだな… 幾乎什麼都做不好嘛。"

    # say L531 bil
    old "Hmm, maybe not at everything. Wait here."
    new "うーん、全部ではないわね。ちょっと待ってて。"

    # say L535 bil
    old "This was my dad’s."
    new "これは私のお父さんのものだったの。"

    # say L536 pla
    old "Whoa..."
    new "おわっ…"

    # say L537 bil
    old "He taught me my first chords on this."
    new "このギターで初めてのコードを教えてくれたんだ。"

    # say L539 bil
    old "Now it’s yours to borrow."
    new "今度は借りていいよ。"

    # say L540 pla
    old "Ohh.. I- I’ll be careful."
    new "オッ、気をつけるぞ。"

    # say L541 bil
    old "You better. If you break it, I break you."
    new "気をつけてね。壊したら、私も容赦しないわよ。"

    # say L542 pla
    old "Noted."
    new "分かった。"

    # say L543 bil
    old "We’ll start with three chords. Easiest thing in the world."
    new "まずは三つのコードから始めるわ。世界で一番簡単なことだから。"

    # say L544 bil
    old "You’re gonna learn them. Even if I have to sit on you."
    new "覚えるまで座らせて教えるわよ。"

    # say L545 pla
    old "That’s... motivational?"
    new "それが…やる気出させるの？"

    # say L546 bil
    old "Damn right it is."
    new "うん、それがやる気出させるもん。"

    # say L548 bil
    old "Alright. Before we even start real lessons, you need to get familiar with that guitar."
    new "まずは本格的なレッスン始める前に、そのギターに慣れておくんだ。"

    # say L549 pla
    old "Yeah, I figured. But, what should I actually do with it?"
    new "そうだな、そう思ってた。でも、実際に何すればいいんだ？"

    # say L550 bil
    old "Well, familiarize yourself with the strings, stop poking the guitar like it’s a wild animal."
    new "まずは弦に慣れて、ギターを野生の動物みたいに突っつくのは止めて。"

    # say L551 bil
    old "And please! Use your fingers. Right now they move like you borrowed them from a mannequin."
    new "そして！指を使って。今のは人形の手を借りたみたいじゃない？"

    # say L553 bil
    old "Relly? You need agility. Flexibility. Some kind of life in those fingers."
    new "ほんと？指に機敏さが必要よ。柔軟性も必要だし、指先に生き生きとした感覚を。"

    # say L554 pla
    old "Okay, so... practice the strings? Just messing around with them?"
    new "じゃあ、弦を触ってみるってことか？ただ弄ってみる感じ？"

    # say L555 bil
    old "Exactly. Touch them, get used to the tension, the spacing, the feel."
    new "そうだよ。触って、張力や間隔、感じになれていくの。"

    # say L556 bil
    old "Learn what each string does when you press it... without crying."
    new "それぞれの弦を押したときの反応を覚えて... 泣かないでね。"

    # say L557 pla
    old "Well, I can do that."
    new "まあ、それならできるな。"

    # say L558 bil
    old "Good. Because in your current state, I can’t teach you anything yet."
    new "うん。今の状態じゃ何も教えてあげられないよ。"

    # say L559 pla
    old "That bad, huh?"
    new "それほどか"

    # say L560 bil
    old "Let’s just say your dexterity is... nonexistent."
    new "手先の器用さが... 全然ないってことね。"

    # say L561 bil
    old "Which tells me you haven’t used those fingers for anything interesting."
    new "それって、その指で面白いことなんて一度もしてないってことね。"

    # say L562 pla
    old "H- hey..."
    new "へっ、ちょっと待って..."

    # say L563 bil
    old "Point is: practice. Move your fingers up and down the strings. Build some coordination."
    new "要点は練習だよ。指を弦の上に上下させて、手の調子をつけて。"

    # say L564 pla
    old "Alright. I’ll work on that."
    new "わかった。それから練習する。"

    # say L565 bil
    old "And once your hands stop embarrassing me, come back."
    new "手が恥ずかしくなくなるまで、また来なさい。"

    # say L566 pla
    old "Ok, ok, got it."
    new "分かった、分かった、わかったよ。"

    # say L567 bil
    old "Good. But for today, we’re done."
    new "分かったわ。でも今日はこれで終わりね。"

    # say L568 pla
    old "Already?"
    new "もう？"

    # say L569 bil
    old "Yeah. You should leave before my grandma shows up."
    new "うん、婆さんが来る前に帰った方がいいよ。"

    # say L570 pla
    old "W-what? Why?"
    new "ええっ？ なんで？"

    # say L571 bil
    old "I don’t want her finding me here with all these instruments and with you."
    new "私、ばあちゃんにこんな楽器だらけの部屋で君といるところ見られたくないの。"

    # say L572 bil
    old "She’ll think I’m getting back into music."
    new "音楽に戻ってると思われちゃうわ。"

    # say L573 pla
    old "But... what’s wrong with that?"
    new "でも... それって何が悪いんだ？"

    # say L574 bil
    old "Not your problem. Don’t dig into it."
    new "それはあなたの問題じゃないわ。深読みしないで。"

    # say L575 pla
    old "Alright... Alright."
    new "分かった… 分かった。"

    # say L576 bil
    old "So practice. When you're actually ready, come find me."
    new "じゃあ練習して。準備できたらまた来找我。"

    # say L577 pla
    old "I will. I’ll get better and I’ll be back soon."
    new "分かった、上手くなるから。すぐに戻ってくるよ。"

    # say L587 pla
    old "It’s really late now, I should leave guitar practice for tomorrow."
    new "もう夜遅いし、ギターの練習は明日にしよう。"

    # say L590 pla
    old "I’d better let my fingers rest a bit, or they’re gonna start bleeding..."
    new "指を休ませた方がいいな、そうしないと血が出ちゃうかもしれないから…"

    # say L594 pla
    old "Okay... here we go. First time ever touching a real guitar."
    new "よし… ここから行こう。初めて本物のギターに触れるんだ。"

    # say L595 pla
    old "This thing’s heavier than it looks."
    new "このギター、見た目よりも重いな。"

    # say L596 pla
    old "And it smells like old wood... it’s nice though."
    new "そして古い木の匂いがする……でもいい匂いだな。"

    # say L597 pla
    old "Alright... let’s see if those YouTube videos helped at all."
    new "よし……ユーチューブの動画が役立つかどうか見てみるか。"

    # say L598 pla
    old "Watched like three tutorials last night. How hard can open chords be?"
    new "昨夜三個のチュートリアルを見た、オープンコードってそんなに難しくないだろう？"

    # say L604 pla
    old "Ow! That buzzed like a dying bee."
    new "オウ！それが死にかけの蜂みたいにブーンってなった。"

    # say L605 pla
    old "Strings hurt more than I expected."
    new "弦が思っていたよりも痛かったな。"

    # say L606 pla
    old "Let’s try again... second fret, second string... mute the others..."
    new "もう一回やってみよう... 二フレット、二弦... 他の弦はミュートにしよう..."

    # say L609 pla
    old "Why do my fingers feel like drunk spaghetti? It´s just like [bil] said."
    new "指が酔っ払ったスパゲッティみたいだな。[bil] の言うとおりだ。"

    # say L610 pla
    old "One chord. ONE chord. Come on, [pla]."
    new "一つのコードだよ。一つのコード。さあ、[pla]。"

    # say L615 pla
    old "I’m literally the worst guitarist in history. Zero dexterity."
    new "俺は文字通り歴史上最も最悪のギタリストだ。ゼロの器用さ。"

    # say L616 pla
    old "She’s gonna murder me if I don’t improve."
    new "彼女が殺すぞ、上達しないと"

    # say L617 pla
    old "({i}But I’m not quitting. Not after she trusted me with this guitar.{/i})"
    new "({i}でも辞めない。彼女がこのギターを任せてくれたんだからな。{/i})"

    # say L618 pla
    old "I have to keep practicing."
    new "練習を続けなくちゃならない。"

    # say L622 pla
    old "Okay... that one almost sounded like an actual chord."
    new "よし…その音はほとんどまともなコードに聞こえたな。"

    # say L623 pla
    old "Progress! Tiny, painful progress."
    new "進歩だ！ 小さくて痛い進歩だけど。"

    # say L624 pla
    old "Enough for today. Fingers are officially dead."
    new "今日の分は済んだ。指は完全に動かなくなったな。"

    # say L625 pla
    old "Tomorrow I’ll be slightly less terrible."
    new "明日は少しマシになるぜ。"

    # say L636 pla
    old "Okay, even if it’s tough, I’ve gotta keep practicing. I need to get better at guitar or Billie’s gonna kill me."
    new "大丈夫、難しくても練習し続けなきゃな。ギターが上手くならないと、Billieに殺されそうだ。"

    # say L637 pla
    old "My fingers are still sore from last time. Awesome."
    new "前回の練習で指がまだ痛いな。最高。"

    # say L638 pla
    old "Sigh... let’s try this again."
    new "ため息…またやってみようか。"

    # say L644 pla
    old "Still buzzing on the high E. Damn it!"
    new "まだ高鳴ってるよ。くそっ！"

    # say L645 pla
    old "Left hand cramps, right hand can’t keep time."
    new "左手がつりそう、右手はリズムを保てないんだ。"

    # say L646 pla
    old "Come on, come on, again."
    new "Come on, come on, again. → 来い、来い、またやってみろ。"

    # say L649 pla
    old "Rhythm’s all over the place. Why can’t I get this?"
    new "リズムが全然まとまらないな。なんで上手くいかないんだ？"

    # say L650 pla
    old "I thought I’d be better by now. This is torture."
    new "もう少し上手になってると思ったのに、これって地獄だな。"

    # say L651 pla
    old "({i}She’s probably nailing everything while I’m stuck here.{/i})"
    new "{i}彼女はきっと全部完璧にやってるだろうな、俺だけがこんなとこで足踏みしてるんだ,{/i}"

    # say L652 pla
    old "Hmm, one more run through. Clean changes or bust."
    new "うん、もう一回やってみるか。ちゃんと変わらないと駄目だな。"

    # say L657 pla
    old "Nope. Still sounds like crap."
    new "ダメだ。まだクソみたいな音だ。"

    # say L658 pla
    old "Fingers raw, brain fried, and zero improvement."
    new "指が疼いて、頭もボロボロ、全然良くならないな。"

    # say L659 pla
    old "That’s it for now. Can’t force it."
    new "それじゃ、今日はここまでだ。無理に進めても仕方ない。"

    # say L660 pla
    old "Tomorrow. Maybe it’ll click tomorrow."
    new "明日だな。もしかしたら明日には何かひらめくかもしれない。"

    # say L671 pla
    old "I’m not getting anywhere on my own. This isn’t working."
    new "俺だけじゃ進展ないな。これじゃあかん。"

    # say L672 pla
    old "({i}I need help. [bil]’s the only one who can teach me.{/i})"
    new "{i}助けてくれないと。[bil]以外誰も教えてくれないんだ。{/i}"

    # say L673 pla
    old "Time to text her. Can’t stay stuck forever."
    new "彼女にメッセージ送る lúcだ。ずっと立ち往生してるわけにはいかない。"

    # say L674 pla
    old "That’s it for today. Tomorrow, I’m going to her."
    new "今日のところはこれで終わりだ。明日は彼女のもとに行く。"

    # say L683 bil
    old "Hey, you look like someone kicked your puppy."
    new "hey、あなた、誰かに愛犬を踏まれたみたいね。"

    # say L685 bil
    old "You texted like the world was ending. What's up?"
    new "世界が終わりそうだってメッセージきたけど、どうしたの？"

    # say L686 pla
    old "It's the guitar. I tried... really tried."
    new "ギターだよ。本当に頑張ったんだけど。"

    # say L687 bil
    old "And?"
    new "で？"

    # say L688 pla
    old "Nothing. Fingers won't move right, everything buzzes. I'm stuck."
    new "何も出ないんだ。指がうまく動かなくて、全部ブンブン鳴る。詰まったままだ。"

    # say L689 bil
    old "Stuck over just a couple of days? That’s dramatic."
    new "数日で詰まっちゃったの？ 大げさだね。"

    # say L690 pla
    old "I'm serious. YouTube videos, hours... still crap."
    new "本気だよ。YouTubeの動画見て、何時間も練習したのに…まだ駄目なんだ。"

    # say L691 bil
    old "Okay, okay. Let's fix it. Room. Now."
    new "わかったわかった。今すぐ部屋に行こう。"

    # say L695 bil
    old "Okay, spill. What exactly did you try?"
    new "じゃあ、詳しく話して。何を試したの？"

    # say L696 pla
    old "Well, I watched videos, did the finger positions, strummed, practiced for hours... and still nothing."
    new "WELL、動画を見て、指の位置も合わせて、ストロークもやって、何時間も練習したんだけど、それでも何も起こらなかったんだ。"

    # say L697 bil
    old "Okay, relax. You’re not hopeless, just untrained."
    new "大丈夫、リラックスして。あなたは無望じゃない、ただ練習が足りないだけだよ。"

    # say L698 pla
    old "Hmm, I feel hopeless."
    new "ん、俺は hopeless だな。"

    # say L699 bil
    old "Well, it does at first. That's normal. We'll figure it out."
    new "最初はそう感じるよね。それは普通だよ。一緒に解決していくから。"

    # say L700 pla
    old "Really?"
    new "ほんと？"

    # say L701 bil
    old "Yeah. I'm your coach. Brutal, but we'll get you there."
    new "うん。私はあなたのコーチだ。厳しくなるけど、絶対に上手くいくから。"

    # say L702 bil
    old "First, let me show you how it's done. Watch."
    new "まずは私がやってみせるから、見てて。"

    # say L709 pla
    old "Holy... you're amazing."
    new "Holy... お前は凄いな。"

    # say L710 pla
    old "It looks so easy when you do it."
    new "君がやると簡単そうに見えるな。"

    # say L711 bil
    old "It’s just practice. Your turn."
    new "ただの練習さ。今度は君の番だ。"

    # say L715 pla
    old "Uhh, like... this?"
    new "うーん、こんな感じ...？"

    # say L718 bil
    old "Buzzing. Press harder on the strings."
    new "ブジーってなるよ。弦をもっと強く押さえなよ。"

    # say L719 pla
    old "Ow... got it."
    new "痛い... 分かった。"

    # say L723 bil
    old "Better. Still ugly, but better."
    new "うーん、まだ汚いけど、ましだね。"

    # say L724 bil
    old "Try shifting your hand a bit. Find a spot that actually sounds alive."
    new "手の位置を少し変えてみて。生き生きとした音がする場所を見つけよう。"

    # say L725 pla
    old "Switching... crap."
    new "手を動かしてる... くそ。"

    # say L729 bil
    old "Slow. Don't rush the change."
    new "ゆっくりと。急ぐな。"

    # say L730 pla
    old "It's like my fingers hate me."
    new "指が俺を嫌ってるみたいだな。"

    # say L731 bil
    old "They're lazy. Make 'em work."
    new "怠け者だね。働かせてあげないと。"

    # say L732 pla
    old "Like this...."
    new "こんな感じで…"

    # say L735 bil
    old "No, you're not covering the strings properly."
    new "いいえ、弦を適切にカバーしていないわ。"

    # say L736 bil
    old "Closer. But your fingers are stiff as boards."
    new "近づいたけど、指が板みたいに固いわ。"

    # say L737 pla
    old "Yeah... no dexterity."
    new "うん…指が器用じゃないね。"

    # say L738 bil
    old "Reset your hand. Try the last position. Light touch, then press."
    new "手をリセットして、最後の位置を試してみて。軽く触れてから押すの。"

    # say L739 pla
    old "Uhh okay..."
    new "うーん、いいのか…"

    # say L743 pla
    old "I- I can't. This is stupid."
    new "俺ー、無理だ。これってば馬鹿らしくなってるけど。"

    # say L747 pla
    old "You're wasting your time with me."
    new "君の時間は無駄になるよ。"

    # say L748 pla
    old "You know what? I should probably go."
    new "知るか、行かなくちゃならないな。"

    # say L751 bil
    old "No."
    new "ダメね。"

    # say L754 pla
    old "B- but-"
    new "でも、完全にダメだ。"

    # say L760 bil
    old "You're frustrated. I get it."
    new "あなたがイライラしてるの、わかるよ。"

    # say L761 pla
    old "I suck. Completely."
    new "俺はダメだ。完全に。"

    # say L762 bil
    old "You don't suck. It's hard. Not everyone even tries."
    new "あなたは全然ダメじゃないよ。難しいんだから。みんなが試すわけじゃないしさ。"

    # say L763 pla
    old "I know... but I’m failing so bad."
    new "知ってる…でも、本当にダメだよ。"

    # say L764 bil
    old "Trying and failing is braver than not trying at all."
    new "挑戦して失敗する方が、何もしないよりは勇敢だよ。"

    # say L765 pla
    old "Feels like I'm just letting you down."
    new "君をがっかりさせている気がする。"

    # say L766 bil
    old "You’re not. You’re working hard, and that means a lot."
    new "あなたはそうじゃないわ。一生懸命やってるのよ、それが大事なの。"

    # say L767 pla
    old "But I have no talents. Zero. I'm good at... existing?"
    new "でも才能なんて一つもないよ。ゼロ。俺は……存在してるだけだな？"

    # say L768 bil
    old "What do you mean you have no talents? Now you’re just being an idiot, you’ve got plenty."
    new "何言ってるの？才能がないなんて、全然違うよ。たくさんあるじゃない。"

    # say L769 bil
    old "You're friendly. Always helping everyone, even when it's inconvenient."
    new "友好的だね。みんなのためにいつも手を貸してるし、面倒でもそうよ。"

    # say L770 pla
    old "I guess..."
    new "まあ、そうかな"

    # say L771 bil
    old "Stubborn too. Look at this, we wouldn’t even be in this mess if you hadn’t pushed and pushed, even when I almost hit you."
    new "頑固だね。これを見ろ。私があなたに近づきすぎた時、あなたが押し通さなければこんなことにはならなかったのに。"

    # say L772 pla
    old "Yeah, but that backfired."
    new "そうだけど、逆効果だったな。"

    # say L773 bil
    old "It didn't. It got us here."
    new "それはそうじゃなくて、ここまできてくれたのは確かよ。"

    # say L774 bil
    old "And you're funny. That dying cat voice? Gold."
    new "あなたって面白いね。あの瀕死の猫の声？最高だったよ。"

    # say L775 pla
    old "Those aren’t really talen-"
    new "それほど才能があるわけじゃないって初めて言ってるんだよ。"

    # say L777 bil
    old "Also... you’re kinda cute, in that awkward, pushy way."
    new "それに……ちょっとぎこちない感じでかわいらしいよね。"

    # say L778 pla
    old "A-are you serious?"
    new "本気で？"

    # say L779 bil
    old "And now that I think about it... you’ve got a huge talent down there, huh..."
    new "それに気づいたら… あなたにはそこがずいぶん才能があるのね…"

    # say L781 bil
    old "Well... I mean, you do have talents after all. You see it now?"
    new "まあ……才能はあるのね。今さら気づいたの？"

    # say L782 pla
    old "Uhh... I guess, but what about the guitar?"
    new "うーん……そうかもしんないけど、ギターはどうするんだ？"

    # say L783 bil
    old "Well, guitar's just one more to unlock. But those fingers... they really need waking up."
    new "ギターはもう一つ解禁されるだけだけど、でもその指……本当に目覚めさせないとね。"

    # say L785 pla
    old "Yeah, I know... but how am I supposed to do that?"
    new "うん、分かってる…でも、どうやってそれをやればいいんだよ？"

    # say L787 bil
    old "You know what, I have an idea."
    new "あなたが思うより、いいアイデアがあるのよ。"

    # say L789 pla
    old "W- whaat a- are you d- doing?"
    new "ワッ、何やってんの？"

    # say L791 bil
    old "Well, I think you need some extra motivation with those sausage fingers, you know?"
    new "WELL、そのソーセージ指にはちょっと追加のモチベーションが必要だと思うの。"

    # say L794 pla
    old "Hey, what the Fuc-!"
    new "Hey、何言ってんだよ！"

    # say L795 bil
    old "Shh. Focus on your fingers. Feel the touch."
    new "シャー。指に集中して。触れを感じて。"

    # say L796 pla
    old "[bil]... this is..."
    new "[bil]... これって..."

    # say L797 bil
    old "Relax... Focus on the task. Circle gently, don't rush it."
    new "リラックス……その作業に集中して。優しく円を描いて、急いだりしないで。"

    # say L799 pla
    old "({i}Oh God...{/i})"
    new "{i}神様…{/i}"

    # say L800 bil
    old "Mmm... that's better. How do they feel to you, [pla]? Soft enough for your liking?"
    new "うん……そうね、それがいいわ。[pla]にはどう感じる？　ソフトさは満足いく？"

    # say L801 pla
    old "They're... so soft, [bil]. It feels amazing."
    new "彼らは... すごく柔らかい、[bil]。最高だ。"

    # say L802 bil
    old "Heh, good answer. Now, add a bit more pressure. Let's see if you can actually handle the real thing."
    new "へへ、いい答えだね。さあ、ちょっと力を加えてみて。本物を扱えるかどうか見せてよ。"

    # say L803 pla
    old "O- okay."
    new "分かった、オッケー。"

    # say L805 pla
    old "Like this? Am I doing it right?"
    new "こんな感じ？ 正しくやってる？"

    # say L806 bil
    old "Nngh—yeah. Exactly like that..."
    new "んん、うん。その通りだね..."

    # say L807 bil
    old "See? you're learning."
    new "見つけてるでしょ？上手くなってきたわね。"

    # say L808 pla
    old "({i}This is insane... and it's working?{/i})"
    new "{i}これって狂ってる…でも効いてるのか？{/i}"

    # say L809 bil
    old "Mmm, nice. Now pick up the pace. Let’s see if you can keep your finesse while speeding up."
    new "うん、いい感じ。次はペースを上げて。速くしても上手さを保てるか見て。"

    # say L811 bil
    old "Tell me how they feel right now."
    new "今どう感じてるの教えて。"

    # say L813 pla
    old "Hot... heavy... and every time I squeeze they bounce a little. It's insane."
    new "熱くて、重くて、毎回絞ると少し跳ねる。信じられないな。"

    # say L814 bil
    old "Good feedback. Noted."
    new "フィードバックありがとう。メモしておいたわ。"

    # say L815 bil
    old "Keep going. Feel the rhythm."
    new "続けて。リズムを感じて。"

    # say L816 pla
    old "I... I feel something."
    new "俺… 何か感じるんだ。"

    # say L817 bil
    old "Yeah, I noticed. Looks like your other talent’s waking up, huh?"
    new "うん、気づいたわ。他の才能が目覚めちゃってるみたいね。"

    # say L819 pla
    old "Oh shit... sorry!"
    new "オッシャイト…ごめん！"

    # say L820 bil
    old "Oh, come on, you're literally groping my tits..."
    new "ほら、本当に胸を触ってるのよ…"

    # say L822 bil
    old "You know what? Come here, let me show you one of my hidden talents too..."
    new "ちょっとこっち来なよ、私の隠し才一つ見せてあげるから…"

    # say L823 bil
    old "This throat does more than just sing, you know?"
    new "この喉は歌うだけじゃないの、知ってる？"

    # say L828 pla
    old "Hooooly shit!"
    new "ホーリーシット！"

    # say L829 bil
    old "So... you like my other talent too, huh?"
    new "そう……私の他の才能も気に入ってくれたのね。"

    # say L830 pla
    old "Oh, yeah, it feels so good..."
    new "ああ、そう感じてるんだ…"

    # say L831 bil
    old "Mmm... I’ve missed this since that stupid spin-the-bottle game."
    new "んん… この感じ、あのバカなスピンザボトルゲーム以来だわ。"

    # say L832 pla
    old "You... you have?"
    new "君までそう思ってるの？"

    # say L833 bil
    old "Shut up. Let me show you my real talent."
    new "黙って。本当の実力を見せなさい。"

    # say L861 bil
    old "So... I guess we made some progress today."
    new "じゃあ……今日は少しは前進できたみたいね。"

    # say L862 pla
    old "Oh yeah, a lot."
    new "ああ、そうさ。"

    # say L864 bil
    old "I meant with the guitar."
    new "ギターのことね。"

    # say L865 pla
    old "Oh, right. Yes. That too."
    new "ああ、そうか。そうだな。ギターもね。"

    # say L866 bil
    old "And from what I see, you definitely have plenty of motivation now."
    new "それに、私が見ている限り、君には充分なやる気があるみたいね。"

    # say L867 pla
    old "Oh, that’s for sure."
    new "そうだな"

    # say L868 bil
    old "Good. Because that whole quit-the-contest nonsense better be gone."
    new "よし、そのコンテストを辞めるなんて話はもう聞きたくないわ。"

    # say L869 pla
    old "Of course. I’m not quitting."
    new "もちろん。辞めるつもりはない。"

    # say L870 bil
    old "Perfect. Then keep practicing at home like you’ve been doing."
    new "完璧だわ。それなら家で練習を続けてね。"

    # say L871 bil
    old "Your fingers still need work... a lot of work."
    new "あなたの指はまだ練習が必要だね…たくさん練習が必要だよ。"

    # say L872 pla
    old "I’ll practice every day. I actually want to improve."
    new "毎日練習するよ。本気で上手くなりたいんだ。"

    # say L873 bil
    old "Hmm. And if you need something, just tell me."
    new "うん、何か必要なことがあったら教えてね。"

    # say L874 pla
    old "I will. Thanks... seriously."
    new "うん、ありがとう…本気で。"

    # say L875 bil
    old "Alright. Let’s leave it here for today."
    new "じゃあ、今日のところはこれで終わりにしよう。"

    # say L876 bil
    old "Go home before my grandma shows up."
    new "家に帰る前に、婆さんが現れないようにね。"

    # say L877 pla
    old "Yeah, I should. I’ll come back soon."
    new "そうだな、帰るか。またすぐ戻ってくるから。"

    # say L878 bil
    old "You better."
    new "あなたがいいな。"

    # say L889 pla
    old "Okay... it’s still hard, but I can’t skip practice now."
    new "そうだな…まだ難しいけど、練習をスキップすることはできないな。"

    # say L890 pla
    old "I’m not great yet, but I’m not totally hopeless either."
    new "まだ上手くないけど、全然ダメってわけでもないよ。"

    # say L891 pla
    old "Alright. Let’s see if I can do this a little better today."
    new "よし、今日こそ少し上手くできるだろう。"

    # say L898 pla
    old "Hey... that one didn’t buzz as bad."
    new "Hey... その音はそんなにブザーじゃなかったな。"

    # say L899 pla
    old "Still not perfect... but it sounded more like a chord this time."
    new "まだ完璧じゃない... でも今回は和音に近かったな。"

    # say L900 pla
    old "Hand’s tired, but it’s moving better."
    new "手が疲れたけど、動きは良くなった。"

    # say L901 pla
    old "Ok, again. Same thing."
    new "じゃあ、また。同じことやってみる。"

    # say L905 pla
    old "Rhythm’s still messy... but I didn’t completely lose it."
    new "リズムがまだ乱れてる…けど、完全に失っちゃわなかった。"

    # say L906 pla
    old "I can actually feel where I mess up now."
    new "今どこで間違ってるか実際に感じるようになった。"

    # say L907 pla
    old "({i}Okay... that’s something. I didn’t feel that before.{/i})"
    new "({i}大丈夫…それだけでも進歩だ。前は感じられなかったからな。{/i})"

    # say L908 pla
    old "One more time. Let’s make it cleaner."
    new "もう一回だ。今度はもっと綺麗にしよう。"

    # say L914 pla
    old "Still rough... but not total garbage."
    new "まだ粗い... でも全然のゴミじゃない。"

    # say L915 pla
    old "That sounded... closer."
    new "それが……近づいたな。"

    # say L916 pla
    old "Yeah. Not there yet, but it’s moving."
    new "そうだな。まだ完全じゃないけど、進んでる。"

    # say L917 pla
    old "Enough for today. Don’t want to ruin what I actually did right."
    new "今日で十分だ。うまくいった部分を台無しにしたくないからな。"

    # say L918 pla
    old "Tomorrow... let’s see if it gets even better."
    new "明日……さらに上手くなるか見てみよう。"

    # say L931 bil
    old "Oh, look who showed up."
    new "あら、来てくれたのね。"

    # say L932 pla
    old "Yeah, I wanted to practice with you again."
    new "そうだな、また君と練習したかったんだ。"

    # say L933 bil
    old "Right, you texted about that. How's it going?"
    new "そうね、そのことについてメッセージくれたわ。調子はどう？"

    # say L934 pla
    old "Uhh, better than before... kinda."
    new "うーん、前よりはましだよ… けどな。"

    # say L935 bil
    old "Oh really? Hah. I need to see that to believe it."
    new "ほんと？はは。見させてもらわないと信じられないよ。"

    # say L936 bil
    old "Come on. Let’s go to my room and talk properly."
    new "さあ、私の部屋に行こう。ちゃんとした話をしよう。"

    # say L939 bil
    old "Okay, spill. What did you do these days?"
    new "じゃあ、話してみて。最近何してたの？"

    # say L940 pla
    old "Honestly... a lot. I practiced every day. My fingers feel way more alive now."
    new "正直... けっこうなことやってた。毎日練習したおかげで、指先がずいぶんと生き生きしてる感じがする。"

    # say L941 bil
    old "Good. About time they woke up from the dead."
    new "いいね。そろそろ生き返ると思っていたんだ。"

    # say L942 pla
    old "Yeah, but... I feel like I hit a wall again."
    new "でも、また壁に当たった感じがする。"

    # say L943 bil
    old "Hmm. Typical. Let me see. Take the guitar."
    new "うーん、典型的だね。見せてみ、ギターを持って来い。"

    # say L949 pla
    old "Alright... here goes."
    new "よし…いくぞ。"

    # say L953 bil
    old "Huh... pressure’s steadier. The tone’s still messy, but at least you’re not fighting the guitar anymore."
    new "へえ……圧は安定してるね。音色はまだ乱れてるけど、少なくともギターと戦ってる感じじゃないから進歩だよ。"

    # say L954 pla
    old "Yeah, I feel more control. I can switch positions smoother now."
    new "うん、もっとコントロールできるようになった感じだ。ポジションチェンジもスムーズになったよ。"

    # say L955 bil
    old "Still too slow. But hey, your hand is finally acting like it belongs to a living person."
    new "まだ遅いけど、手がようやく人間のものみたいに動いてるね。"

    # say L956 bil
    old "Not bad. Your fingers actually woke up this time."
    new "悪くないね。指がちゃんと動いたみたいだ。"

    # say L957 pla
    old "Yeah, but that’s the problem. I think I hit my limit again. I can’t push past this alone."
    new "そうだよ、でもそれが問題なんだ。俺はまた限界にぶち当たったみたいだ。これ以上は一人じゃ進めない。"

    # say L960 pla
    old "Honestly... I was hoping you could help me practice again."
    new "正直...君にまた練習を手伝って欲しかったんだ。"

    # say L961 bil
    old "Huh?"
    new "へ？"

    # say L962 bil
    old "So that’s why you came back. You want more 'practice'."
    new "そうか、だからまた来たのね。もっと練習が欲しそうね。"

    # say L963 pla
    old "Exactly. Something a bit more advanced. Something that forces my fingers to—"
    new "そうだ。ちょっとレベルの高いものさ。指を使わせるような—"

    # say L964 bil
    old "Oh, I see where this is going."
    new "なるほど、そういう展開ね。"

    # say L965 bil
    old "Yeah, sure. More 'advanced practice', right?"
    new "うん、そうね。もっと「上級者向けの練習」ってこと？"

    # say L966 pla
    old "Exactly! I need something beyond the basics. I’m not improving anymore."
    new "そうだよ！基本だけじゃ物足りないんだ。もう成長してないしさ。"

    # say L967 bil
    old "Alright, alright, I get it. No need to act innocent."
    new "分かった、分かった。素直でいなくていいのね。"

    # say L969 bil
    old "Come on, don’t be shy. I know what you’re actually here for."
    new "Come on, 遠慮しないで。本当の目的くらい私には分かってるよ。"

    # say L971 pla
    old "No, no, that’s not—"
    new "いや、そうじゃない—"

    # say L972 bil
    old "Stop overthinking. You came to practice."
    new "考えすぎないで。練習に来たんだよね。"

    # say L973 bil
    old "So let’s practice."
    new "じゃあ、練習しよう。"

    # say L975 pla
    old "({i}Oh God, they feel incredible...{/i})"
    new "({i}神様、最高だな…{/i})"

    # say L976 bil
    old "There. Full palms first. feel how soft they are when you take your time."
    new "そこで、まずは手のひら全体を使って。ゆっくりするとどれだけ柔らかいのか感じるわ。"

    # say L978 bil
    old "Keep that rhythm. Don't rush the ‘practice’."
    new "そのリズムで。練習は急がないで。"

    # say L979 pla
    old "Fuck... [bil], they feel unreal."
    new "くそ… [bil]、本物じゃないみたいだ。"

    # say L980 bil
    old "Limited edition, baby."
    new "限定版だよ、ベイビー。"

    # say L981 bil
    old "Come on, a little more pressure. You know what I like."
    new "もっと力入れて、私が好きなのは知ってるでしょ。"

    # say L983 pla
    old "L-like... this?"
    new "L-like...これ？"

    # say L984 bil
    old "Yes... perfect. You're doing better than I expected."
    new "うん… 完璧。思っていたより上手いね。"

    # say L985 pla
    old "Your nipples... they're getting hard. Does that mean I'm doing good?"
    new "君の乳首……硬くなってきたな。それが俺が上手いってことなのか？"

    # say L986 bil
    old "Means you’re not completely hopeless. Keep going."
    new "それならまだ捨てたもんじゃないわね。続けて。"

    # say L987 bil
    old "Okay, new part. First time for this one."
    new "新しいパートね。これ初めてだよ。"

    # say L988 bil
    old "Nipples only. Start super gentle... just the tips of your fingers."
    new "乳首だけよ。超優しく始めて…指の先だけを使って。"

    # say L990 pla
    old "T-they're so sensitive... I can feel them hardening more."
    new "乳首がめちゃくちゃ敏感だ…硬くなってるのを感じられる。"

    # say L991 bil
    old "Good. Now a little harder. Build it up, don't rush."
    new "いいわ。少し強くして。徐々にエスカレートさせて、急いだらダメよ。"

    # say L992 pla
    old "A-are you sure?"
    new "本当に大丈夫？"

    # say L993 bil
    old "Harder, [pla]. Don’t be scared. Make me feel it."
    new "もっと強く、[pla]。怖がらなくていい。感じさせて。"

    # say L995 pla
    old "L-like this? God, you're starting to breathe heavier..."
    new "こんな感じ？神よ、君の呼吸が早くなってきて…"

    # say L996 bil
    old "Yes—fuck—keep going. Harder now, make it count."
    new "うん—くそ—そのまま続けて。もっと強く、感じさせて。"

    # say L997 bil
    old "({i}Fuck... he’s careful but he’s getting it...{/i})"
    new "({i}くそっ……彼は気をつけてくれてるけど、ちゃんと感じさせてくれてる……{/i})"

    # say L998 pla
    old "I- I don’t want to hurt you..."
    new "俺は君を傷つけたくなくて…"

    # say L999 bil
    old "You won’t. Trust me. Slowly harder each time."
    new "大丈夫、信じて。少しずつ強くしていくから。"

    # say L1001 bil
    old "({i}Shit, for a first-timer...{/i})"
    new "({i}初めてなのに…ズルいな…{/i})"

    # say L1002 pla
    old "I-I can feel you tensing... come for me, [bil]?"
    new "俺、君の緊張を感じてる... 来て、[bil]？"

    # say L1003 bil
    old "Harder—now—ahh—fuck—yes—!"
    new "もっと強く——今——ああ——くっ——そう——！"

    # say L1005 bil
    old "Okay... that was more than enough warm up for your fingers."
    new "大丈夫... あなたの指のウォームアップには十分すぎるくらいだったわ。"

    # say L1006 pla
    old "Y- yeah... definitely intense."
    new "Ｙ－ああ…確かに激しかったな。"

    # say L1008 bil
    old "So? Feeling more agile now?"
    new "じゃあ？　指先がもっと素早く動くようになったでしょ？"

    # say L1009 pla
    old "Honestly... a little. But... I don’t think that alone will fix everything."
    new "正直……少しはな。でも……それだけじゃ全部を直すのは難しいと思う。"

    # say L1010 bil
    old "Oh, really?"
    new "ほんとですか？"

    # say L1011 pla
    old "Yeah. I mean... thanks for the help, seriously, but I don’t think that kind of practice is enough to improve my speed or accuracy."
    new "うん、つまり……本当に助かるけど、その程度の練習じゃ俺の速さや正確さはなかなか上がらないと思うな。"

    # say L1012 bil
    old "Huh."
    new "へえ。"

    # say L1013 bil
    old "So what, now you want something even more advanced?"
    new "じゃあ、今度はもっと高度なものを欲しがっているの？"

    # say L1014 pla
    old "Well— I mean— I just—"
    new "まあー つまりー ただー"

    # say L1015 bil
    old "No. No, no, no. Don’t even think I’m giving you a blowjob every time you struggle with a chord."
    new "いいえ、いいえ、いいえ。ギターのコードに苦しがるたびにフェラチオをさせてくれるなんて思ってもみんないわよ。"

    # say L1016 pla
    old "Wait— what? No! That’s not what I meant!"
    new "待て——何？いや！そんな意味じゃなかったって！"

    # say L1017 bil
    old "Good. Because I’m not doing that every time you show up."
    new "よし。だって毎回来ただけでそんなことするわけないでしょ。"

    # say L1018 pla
    old "N- no! I swear I wasn’t asking for that!"
    new "なっ、ない！本当にそんなつもりじゃなかったんだ！"

    # say L1019 bil
    old "Then what were you asking for?"
    new "じゃあ、何を欲しがってたの？"

    # say L1020 pla
    old "I just... genuinely need help finding a better exercise. Something real. Something useful for my fingers."
    new "ただ... 本気で手助けが必要なんだ。ちゃんとしたものだ。指に効果的なもの。"

    # say L1021 bil
    old "So you’re... actually serious."
    new "そうか、本気で言ってるのね。"

    # say L1022 pla
    old "Yes. I figured you’d know something. A technique, an exercise, something."
    new "そうだ、君が何か知ってると思ったんだ。テクニックや練習法、何かあるだろ。"

    # say L1023 pla
    old "Exactly, that’s what I’m looking for."
    new "そうだ、それが俺が探してるんだ。"

    # say L1024 bil
    old "Okay, okay, Hmm, then let me think."
    new "わかったわ、ちょっと待って、考えてあげるね。"

    # say L1025 bil
    old "Hmm... something advanced for finger dexterity... something that forces your hand to adapt..."
    new "Hmm... 指の器用さを鍛えるものね... 手を適応させないといけないようなもの..."

    # say L1026 pla
    old "Yeah. Exactly."
    new "そうだ。その通りだ。"

    # say L1028 bil
    old "Oh..."
    new "“Oh..."

    # say L1029 bil
    old "...I have an idea."
    new "アイデアがあるのね。"

    # say L1030 pla
    old "You do? What is it?"
    new "何か思いついたの？何だよ？"

    # say L1031 bil
    old "You’ll see. Just stay there."
    new "待ってて、すぐわかるから。"

    # say L1033 pla
    old "So... what do you have in mind?"
    new "じゃあ……何を考えてるんだ？"

    # say L1034 bil
    old "Something advance. Trust me."
    new "ちょっと先手を打つわ。信じて。"

    # say L1036 pla
    old "W- what are you doing?!"
    new "何やってるの？！"

    # say L1037 bil
    old "Relax. This is the training. Just extreme level."
    new "リラックスして。これは訓練さ。ただレベルが極端なだけよ。"

    # say L1040 bil
    old "Now... use those fingers. Start slow."
    new "今... その指を使って。ゆっくりと始めて。"

    # say L1042 bil
    old "Shh. Focus. Circle the clit gently."
    new "しーっ。集中して。クリトリスを優しく円を描くように刺激して。"

    # say L1046 bil
    old "Mmm... good. Now slide one in."
    new "うん…いいわ。それじゃ、一つ指を入れて。"

    # say L1047 pla
    old "Like... this?"
    new "こう... いい？"

    # say L1048 bil
    old "Yes... curl it. Find the spot."
    new "はい…曲げて。その場所を探して。"

    # say L1050 bil
    old "Faster now. Add another finger."
    new "もっと速く。もう一本指を追加して。"

    # say L1052 pla
    old "[bil]... you're squeezing..."
    new "[bil]… お前が締め付けてるな…"

    # say L1053 bil
    old "That's it. Rub harder."
    new "そうよ、もっと強くこすって。"

    # say L1054 pla
    old "Fuck... you're dripping."
    new "くそ……君は濡れってるな。"

    # say L1055 bil
    old "Deeper. Don't stop."
    new "もっと深く。止めてないで。"

    # say L1057 bil
    old "Harder... make me cum."
    new "もっと強く… 私をイカせて。"

    # say L1060 pla
    old "Oh fuck... cum for me."
    new "オッサン、もっと深く、止まらないで。ハードに……俺の為に出せ。"

    # say L1063 pla
    old "Yes... feel it all."
    new "そうだ…全部感じろ。"

    # say L1064 bil
    old "Oh god... that's it."
    new "ああ…そうよ。"

    # say L1072 bil
    old "Alright, THAT was definetly an advance training..."
    new "あのね、それこそ確実に上級の訓練だったわ。"

    # say L1073 pla
    old "Y-yeah... that was... a lot."
    new "うん… それは… かなりのものだったな。"

    # say L1074 bil
    old "But hey, your fingers definitely kept up this time."
    new "でもね、あなたの指はちゃんとついてきたのね。"

    # say L1075 pla
    old "I did feel a big difference. Seriously."
    new "確かに大きな違いを感じたよ。本気で。"

    # say L1076 bil
    old "Good. Then keep practicing at home. Use what you learned today."
    new "Good. それなら家で練習を続けて。今日学んだことを活かしてね。"

    # say L1077 bil
    old "If you get stuck again, come back. We’ll figure something out."
    new "また困ったら戻ってきて。何か考えつくよ。"

    # say L1078 pla
    old "I will. Thanks... for everything."
    new "うん、ありがとう……全てのことで。"

    # say L1079 bil
    old "Alright, event’s over. Go home before my grandma arrives."
    new "イベント終わったし、婆さんが来る前に帰ってね。"

    # say L1091 bil
    old "Finally. Took you long enough."
    new "やっとだ。長く待たせたね。"

    # say L1092 pla
    old "You texted me. Said it was important."
    new "君からメッセージ来たぞ。大事なことだって。"

    # say L1093 bil
    old "Yeah. Because it is. The teacher called me."
    new "うん、だからさ。先生から連絡があったの。"

    # say L1094 pla
    old "Wait... what? Already?"
    new "待った……何？もう？"

    # say L1095 bil
    old "She wants to schedule our supervised practice."
    new "先生が監督付きの練習のスケジュールを組みたいって。"

    # say L1096 pla
    old "Like... with her? Watching me? Listening to me?"
    new "ええ…彼女と？俺を見ながら？聞いてるの？"

    # say L1097 bil
    old "Mhm. Exactly that."
    new "うん、その通りだね。"

    # say L1098 pla
    old "Oh man... I’m not ready for that."
    new "オイ…そんなのまだ準備できとらな。"

    # say L1099 bil
    old "That’s why I told you to come."
    new "だから君に来てもらったんだよ。"

    # say L1100 bil
    old "We need to polish you up before she sees anything."
    new "彼女が何か見る前に、君を磨き上げる必要があるの。"

    # say L1101 pla
    old "I don’t know if I can—"
    new "俺には無理かもしれないけど—"

    # say L1102 bil
    old "Stop. You’re doing it. We’re doing it. End of story."
    new "止めて。あなたがやるの。私たちはやるの。それだけよ。"

    # say L1103 bil
    old "Come on. Room. We’ll talk there."
    new "さあ、部屋に行こう。そこで話すよ。"

    # say L1108 bil
    old "Alright. Tell me. How’ve you been since last time?"
    new "そうね。教えて。前回からどうだったの？"

    # say L1109 pla
    old "Honestly? Way better. After all that... 'advanced practice'... I definitely improved."
    new "正直に言うと、全然マシになったよ。あの... ‘高度な練習’... の後、確実に上達したさ。"

    # say L1110 bil
    old "Oh, I bet you did."
    new "お、そうだろうね。"

    # say L1112 bil
    old "Yeah, yeah. Show me."
    new "うん、うん。見せて。"

    # say L1116 pla
    old "Okay... here goes."
    new "よし…いくぞ。"

    # say L1118 bil
    old "Huh. Look at that."
    new "へぇ、そうね。見てみて。"

    # say L1119 bil
    old "Hand’s lighter. Movement’s cleaner. You’re not strangling the strings anymore."
    new "手が軽くなって、動きも滑らかになったわ。弦を締め付けすぎてるのが解消されたみたい。"

    # say L1120 pla
    old "Yeah, I feel the difference. And switching positions isn’t torture now."
    new "うん、違い感じるよ。ポジション変えるの苦じゃなくなったし。"

    # say L1121 bil
    old "Well, seems last session really loosened you up."
    new "前回のセッションで随分と緩んだみたいね。"

    # say L1122 pla
    old "I... guess so."
    new "俺……そうかもしれないな。"

    # say L1123 bil
    old "Still not perfect. You need a final push if you want to stand in front of a teacher."
    new "まだ完璧じゃないよ。先生の前で立つなら、最後の一押しが必要だよ。"

    # say L1124 pla
    old "You really think I need more?"
    new "本当にそんなに必要なのか？"

    # say L1125 bil
    old "Oh, absolutely. A little more ‘advanced training’ won’t hurt."
    new "もちろんよ。ちょっとだけ「上級トレーニング」は悪くないんじゃない？"

    # say L1126 pla
    old "Billie... I don’t know. I think I’ve improved a lot already."
    new "ビリー… よくわからないんだ。俺はもう相当上達したと思うけど。"

    # say L1127 bil
    old "You did. But if you want her to take you seriously, you need your fingers sharp."
    new "あなたはそうしたわ。でも、彼女に本気で見られたいなら、指先をもっと研がなくちゃならないわ。"

    # say L1128 bil
    old "And we both know exactly what helped last time."
    new "そして、前回何が役立ったか、お互いよく知ってるでしょ。"

    # say L1129 pla
    old "B- Billie, I—"
    new "B- ビリー、俺ー"

    # say L1130 bil
    old "Save it. We’re not wasting time. The supervised practice is soon."
    new "いいのよ。時間は無駄にしたくないの。監督付きの練習がすぐにあるの。"

    # say L1131 bil
    old "So let's get you ready properly."
    new "じゃあ、ちゃんと考えて準備するね。"

    # say L1143 bil
    old "Okay... damn. You’ve definitely improved again."
    new "Okay... だめだ。また上手くなったね。"

    # say L1145 bil
    old "Yeah. I can feel it. Your fingers are way more confident now."
    new "うん、感じる。あなたの指がずいぶんと自信に満ちてるね。"

    # say L1146 pla
    old "I... still don’t know if I’m ready for the teacher, though."
    new "俺……まだ先生にはちょっと早すぎる気がするけど。"

    # say L1147 bil
    old "Relax."
    new "リラックスして"

    # say L1148 bil
    old "You’re not being tested for the contest yet. This is just to show progress."
    new "まだコンテストの審査じゃないよ。進歩を示すだけだから。"

    # say L1149 pla
    old "Right... progress."
    new "そう…進歩か。"

    # say L1150 bil
    old "She’ll give us feedback. Then we adjust. Simple."
    new "彼女がフィードバックをくれる。それをもとに調整するの。簡単だよ。"

    # say L1151 pla
    old "Okay... I guess that makes sense."
    new "うーん…まあ、そうかもな。"

    # say L1152 bil
    old "Good. Then keep practicing at home. A lot."
    new "じゃあ、家でたくさん練習しなさい。"

    # say L1153 bil
    old "Don’t make me regret putting in all this effort."
    new "努力した甲斐がないと思わせないで"

    # say L1154 pla
    old "I won’t. I’ll practice."
    new "分かってる、練習するよ。"

    # say L1155 bil
    old "Alright... I’m done. Literally done. And I’m getting sleepy."
    new "分かった……終わり。本当に終わったの。眠くなってきた。"

    # say L1156 pla
    old "Sleepy?"
    new "眠くなってきたの？"

    # say L1157 bil
    old "Yeah. ‘Advanced training’ is exhausting, in case you didn’t notice."
    new "うん、‘高度なトレーニング’は本当に疲れるわ、気づいてなかった？"

    # say L1158 pla
    old "R-right... sorry."
    new "うーん…ごめんな。"

    # say L1159 bil
    old "Go home. Practice. And don’t come back useless."
    new "家に帰って練習して。無能なまま戻ってくるな。"

    # say L1160 pla
    old "I’ll do my best. I’ll see you soon."
    new "頑張るよ。またすぐ会おう。"


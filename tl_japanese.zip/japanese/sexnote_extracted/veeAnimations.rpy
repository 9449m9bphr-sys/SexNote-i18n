# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/veeAnimations.rpy
translate japanese strings:

    # say L6 vee
    old "Oh yeah! This is just magical!"
    new "ああ、そう！これって魔法みたいだよ！"

    # say L7 vee
    old "I love that you're watching me, Daddy!"
    new "パパが見てくれるのが好きだよ！"

    # say L8 vee
    old "I miss your dick so much!"
    new "あなたのちんこ、本当に懐かしいの！"

    # say L12 vee
    old "Do you like to see me touching my pussy?"
    new "パパ、私のオマンコを触ってるところ見るのが好き？"

    # say L13 vih
    old "Oh yeah baby! I love it!"
    new "オーよっベイビー！大好きだよ！"

    # say L14 vih
    old "I can't wait to fuck your pussy myself!"
    new "待ってられないよ、君のマンコを自分で犯すのを！"

    # say L18 vee
    old "Oh daddy! It feels as if you were here!"
    new "お父さん！　まるであなたがここにいるみたい！"

    # say L19 vee
    old "I can't get enough of this!"
    new "これ、全然足りないよ！"

    # say L20 vee
    old "I want more and more!"
    new "もっともっと欲しいの！"

    # say L43 vee
    old "I- I'm about to cum honey!"
    new "あ、もうイキそうよ、ハニー！"

    # say L44 vih
    old "Do it! I'm about to cum too!"
    new "やって！私ももうすぐイクよ！"

    # say L45 vee
    old "Oh yeah! Let's do it together!"
    new "オーケー！一緒にイこうよ！"

    # say L52 vee
    old "Oh that was magical honey."
    new "ああ、それって魔法みたいだったね。"

    # say L53 vee
    old "I can't wait to see you again to feel you inside me."
    new "また会えるのを楽しみにしてる、あなたが中に入っているのを感じられるのを。"

    # say L54 vih
    old "Oh yeah, I can't wait to fuck you too."
    new "ああ、そういえば、君の中に入りたいって気持ちは同じだよ。"

    # say L56 vee
    old "{i}(I- is that [pla]? What's he doing there?!!){/i}"
    new "{i}(えっ- それって [pla]？彼、何してるの？！！){/i}"

    # say L57 vih
    old "Is everything alright? You just got quiet all of a sudden."
    new "大丈夫？急に静かになっちゃったけど。"

    # say L58 vee
    old "What?! Oh yeah!"
    new "何？！あ、そうね！"

    # say L59 vee
    old "It's just that I think I heard some steps in the hallway."
    new "ただ廊下で足音がしたと思ったの。"

    # say L60 vee
    old "Maybe we should end the call here honey, in case one of the girls comes in."
    new "Honey、女の子たちが入ってくるかもしれないから、ここで通話を終わろうか。"

    # say L61 vih
    old "Hmph, yeah you're right."
    new "ふん、そうだね。"

    # say L62 vih
    old "Talk to you later then."
    new "後で話すね。"

    # say L63 vee
    old "Bye honey, I love you."
    new "バイバイ、亲爱的。我爱你。"

    # say L64 vee
    old "Hey, you! I already saw you there peeping, come in here and close the door behind you!"
    new "ねぇ、あなた！もう見ちゃってるんだから、中に入ってドアを閉めなさい。"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Basement.rpy
translate japanese strings:

    # say L16 mo2
    old "So? Are you ready to do something useful with your life?"
    new "じゃん？人生で何か役立つことを始める気になったの？"

    # say L18 pla
    old "Umm..."
    new "うーん…"

    # say L20 mo2
    old "I don't feel comfortable with a young pervert around me, but your [mo1rel] asked me to do this for you..."
    new "若者の変態が近くにいると落ち着かないけど、あなたの[mo1rel]の頼みだから仕方なく…"

    # say L24 mo2
    old "Which means that this is an opportunity for you to see how to make some money..."
    new "これはあなたがお金を稼ぐチャンスだわ…"

    # say L26 pla
    old "Sweet! You're going to teach me?"
    new "すげえ！教えてくれるんだ？"

    # say L28 mo2
    old "Oh, hell no! I'm not your damn teacher. Just do what I tell you. And watch what I do, then maybe you will learn on your own..."
    new "あら、そんなことないわ！私がお前の先生になるわけないでしょ。私が言うことを聞いて、私がやることを見てな。そうすれば自分で学べるかもしれないわね。"

    # say L30 pla
    old "Ok, ok... So what do you need me to do?"
    new "分かった、分かった… じゃあ、何をすればいいんだ？"

    # say L32 mo2
    old "First of all, I don't need you. I'm letting you work for me and learn."
    new "まずは、私は君が必要としていないの。君が私のために働いて学ぶ機会を与えているのよ。"

    # say L34 mo2
    old "Secondly, if you try to peep on me at work or do something perverted, I will fire your ass. Understood?"
    new "次に、仕事中私を覗こうとするか、変態なことをしようとしたら即座に解雇するわ。分かった？"

    # say L35 pla
    old "(This is going to be harder than I thought.)"
    new "これは思っていたよりも大変そうだな。"

    # say L37 pla
    old "Hey! I'm not a-"
    new "Hey！ 僕はそんなつもりじゃなかったんだよ！"

    # say L39 mo2
    old "Shut up! Pervert!"
    new "黙って！変態！"

    # say L41 pla
    old "...Ok. So, you are my boss now and I will respect you... Is that better?"
    new "分かった。君がボスだということを尊重するよ… それでいいんだ？"

    # say L43 mo2
    old "That's the respect you have to show me all the time, got it?. But enough talk, [pla]. Let's get to work!"
    new "いつも私に対してその態度でいなさい、分かった？でも話すのはこのくらいにして、[pla]。さあ、仕事に取りかかろう。"

    # say L45 pla
    old "Nice. What do you need me to do?"
    new "いいな。何を手伝えばいいんだ？"

    # say L47 mo2
    old "I need you to take these documents to my office and give them to the secretary. Then come back to me."
    new "これらの書類を私のオフィスまで持っていくの。秘書に渡したら戻ってきてちょうだい。"

    # say L49 pla
    old "As you wish."
    new "承知、君の言う通りにするよ。"

    # say L64 pla
    old "Done! I already delivered the documents to Akita."
    new "終わったよ！すでに資料を秋田に渡した。"

    # say L66 mo2
    old "Well, was that very difficult?"
    new "まあ、そんなに難しかったとは思わないけど？"

    # say L68 pla
    old "Hmm, not really..."
    new "Hmm、そんなに難しくなかったな。"

    # say L70 mo2
    old "Alright. Look for me tomorrow to take a new delivery to Akita..."
    new "わかりました。明日、Akitaに新しい荷物を届けに行くのを見てね。"

    # say L124 pla
    old "I must deliver the documents to Akita first."
    new "Akitaに書類を届けないといけないんだ。"

    # say L131 mo2
    old "Are you ready to work today? I don't want any interruptions from you..."
    new "今日仕事の準備はできていますか？邪魔されたくないんですからね。"

    # menu L134 
    old "Ready to work for you"
    new "君のために働く準備はできてるよ"

    # say L138 mo2
    old "Ok then, You know what to do. Take these documents to my secretary, then come back to me..."
    new "では、分かっていますよね。これらの書類を私の秘書に届けて、戻ってきなさい。"

    # say L140 pla
    old "Of course, [mo2]!"
    new "もちろん、[mo2]！"

    # menu L150 
    old "Not now"
    new "今はまだ無理だな"

    # say L152 pla
    old "Actually, I have to do something first... I'll talk to you later."
    new "実は、まずやることがあるんだ... 後で話すよ。"

    # say L154 mo2
    old "Ugh. Ok, [pla]. Don't waste my time. Come talk to me when you're really ready"
    new "うーん、わかったわ、[pla]。時間の無駄にしないでね。本当に準備できたら、また話しかけてちょうだい。"

    # say L185 pla
    old "Uh... Nothing, I was just going to my bedroom, sorry."
    new "うーん… 何でもない、ただ寝室に行こうと思ってた、ごめん。"


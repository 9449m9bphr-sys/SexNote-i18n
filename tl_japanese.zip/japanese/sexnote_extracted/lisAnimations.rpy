# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/lisAnimations.rpy
translate japanese strings:

    # say L6 lis
    old "Just relax and feel all my body, focus on the new sensations."
    new "リラックスして、私の身体を感じてみて、新しい感覚に集中して。"

    # say L10 lis
    old "Can you feel my breast over your back?"
    new "私の胸が君の背中に当たってるの、感じてる？"

    # say L11 pla
    old "Y- yeah..."
    new "Ｙ－うん…"

    # say L15 lis
    old "I'm going to do it faster so you can feel more all my energy."
    new "もっと速くすると、私のエネルギー全部を感じてね。"

    # say L41 lis
    old "You are very connected with the moment and the environment, it means we can go beyond, you are ready for the next step."
    new "あなたは今この瞬間と環境にとてもつながっているわ、それなら私たちはもっと先へ進めるし、あなたは次のステップに備えているのよ。"

    # say L42 pla
    old "... Ok."
    new "分かった。"

    # say L47 lis
    old "Please lie down now on your back so we can expose the parts of your body that we need to balance the energy."
    new "今から仰向けに寝てください、エネルギーを調整するため必要な部分を露出させます。"

    # say L50 lis
    old "We can heal your body together, we can heal each other, please follow my instructions so you can release all these negative experiences..."
    new "一緒にあなたの体を癒しましょう、お互いを癒すために私の指示に従ってこれらのネガティブな経験を解放してください..."

    # say L51 lis
    old "Please lie down on your back, so we can take the negative energy out..."
    new "仰向けに寝てください、そうすればネガティブなエネルギーを取り除くことができます..."

    # say L63 lis
    old "Ok, we are done now, let's do the next exercise..."
    new "はい、次のに移りましょうね。"

    # say L73 lis
    old "Is it pleasant?"
    new "気持ちいいですか？"

    # say L74 pla
    old "Yes..."
    new "うん..."

    # say L78 lis
    old "Keep breathing, that is the key, your muscles must get extremely relaxed, my hands will clean the bad energies, let them do their job."
    new "息を続けて、それが大事よ。あなたの筋肉を極限までリラックスさせて、私の手が悪いエネルギーを取り除くのを手伝って。手に任せて。"

    # say L82 lis
    old "Please let yourself go, do not think about anything else, I will move faster so you can't release the tension, so you can let the chakra muladhara to be cleaned."
    new "力を抜いて、他には何も考えないで。私がもっと速く動くから、緊張が解けないようにするわ。そうすれば、チャクラのムーラダラが浄化されるわ。"

    # say L106 lis
    old "Do you feel the negative chakra leaving?"
    new "負のチャクラが出ていくのを感じてる？"

    # say L108 lis
    old "Let it out... Breath and let it out."
    new "吐き出して…息をついて、吐き出して。"

    # say L113 pla
    old "Phew..."
    new "ふー……"

    # say L114 lis
    old "Wow, that was wonderful, our job had abundant results."
    new "Wow、それって素晴らしかったわ、私たちの仕事は豊かな成果を出したわ。"

    # say L129 lis
    old "Do you feel my boobs?"
    new "私の胸を感じてる？"

    # say L133 lis
    old "Let it move... Feel me, I can see your body is doing it great..."
    new "動かせて……感じて、あなたの体がすごく反応してるの見えるの……"

    # say L137 lis
    old "I can see it's hard to fight with your chakra muladhara but we can try harder than that, stay focused and just release the negative energy..."
    new "見えてるわ、チャクラのムーラダラと戦うのは大変そうだけれど、もっと頑張れるわね、集中して、ネガティブなエネルギーを解放しちゃって…"

    # say L160 lis
    old "Yes, breath, and feel how your energy is moving...  I want you to let it go..."
    new "はい、息をして、あなたのエネルギーが動いているのを感じて…… それを手放してほしいの……"

    # say L166 lis
    old "Do you feel relieved?"
    new "安堵感を感じてる？"

    # say L168 lis
    old "Great, we will need to continue working on it but you are doing amazing."
    new "Great, 継続して練習していく必要があるけど、あなたは凄いわ。"

    # say L233 lis
    old "Oh, yes... Just like that..."
    new "ああ、うん… そうよ…"

    # say L237 lis
    old "You really have a big cock... It feels... Good."
    new "あなたのコック、本当に大きいね… 感じが… よい。"

    # say L241 lis
    old "Wow, uhhh, yes [pla] keep doing it..."
    new "うわ、あぁ、そう [pla] そのまま続けて…"

    # say L264 pla
    old "Lisa, I'm goig to c- cum..."
    new "リサ、俺、出るよ…"

    # say L265 lis
    old "Oh, cum all over me."
    new "あ、全部かけて。"

    # say L289 lis
    old "Feel the fire of the universe with each kiss, you must know the universe is healing your body."
    new "宇宙の炎を感じて、キスごとに宇宙があなたの体を癒していることを知っているわ。"

    # say L290 pla
    old "Yeah, I can feel it."
    new "そうだな、感じてるよ。"

    # say L294 lis
    old "I will do it more intense so you feel the healing power of the universe at its fullest expression."
    new "もっと激しくして、宇宙の治癒力が最大限に感じられるようにするから。"

    # say L298 lis
    old "I will take that energy out."
    new "そのエネルギーを取り出すわ。"

    # say L321 pla
    old "I- I'm goin-"
    new "俺っ、出るっ…"

    # say L322 lis
    old "Let it flow [pla], let it flow."
    new "流すんだ [pla]、流すんだ。"

    # say L340 lis
    old "Oh [pla], what amazing energy you have."
    new "ああ、[pla]、すごいエネルギーを持っているね。"

    # say L344 lis
    old "Oh yes, I'm feeling the universe through you..."
    new "ああ、そう、あなたの通じて宇宙を感じてる..."

    # say L348 lis
    old "OH GOD, I NEED IT HARDER INSIDE OF ME!"
    new "OH GOD、もっと強く私の中に入れて！"

    # say L371 lis
    old "Let all your energy cum inside me, I need to feel it."
    new "あなたのエネルギー全部、私の中に出して、感じさせてほしい。"

    # say L391 mik
    old "Ohh man, look at that, this is so fucking hot!"
    new "おっ、見てこれ、めちゃくちゃエロいぞ！"

    # say L392 pla
    old "Hey, keep it down, they could hear you."
    new "Hey、静かにしろ、聞こえちまうぞ。"

    # say L393 mik
    old "Alright, alright."
    new "分かった、分かった。"

    # say L397 mik
    old "God damn it! This is getting me on!"
    new "くそっ！これじゃ俺、興奮しちゃうじゃねえか！"

    # say L398 pla
    old "Hey! Keep it down!"
    new "おい！静かにしろ！"

    # say L399 mik
    old "Listen, dude, do you think you could leave for a couple of minutes?"
    new "おい、ちょっと外に出てくんないか？"

    # say L400 pla
    old "What? Hell no! What the hell are you thinking?"
    new "何？絶対に嫌だ！何考えてんだよ！"

    # say L404 mik
    old "Oh they're going faster! This is fucking amazing."
    new "オッ、速くなってきた！これ最高だよ。"

    # say L405 pla
    old "I'm glad you like it man, but hey, we gotta go."
    new "お前が気に入ってくれて嬉しいけど、でもさ、行かなきゃな。"

    # say L406 mik
    old "Ohhh no, please just a little more, I think they're about to finish."
    new "オーッ、ちょっとだけ待って、もうすぐ終わると思うんだ。"

    # say L407 pla
    old "Hmm, alright."
    new "うーん、分かった。"

    # say L430 mik
    old "Oh wow, that's the fucking best. I wasn't expecting that today."
    new "おわ、これが最高だ。今日こんなことになるとは思わなかった。"

    # say L431 mik
    old "Thanks man."
    new "ありがとう、お兄ちゃん。"

    # say L432 pla
    old "No problem bro, but let's get out of here before they see us."
    new "問題ないよ、兄貴。でも見られる前にここから出よう。"

    # say L444 lis
    old "Mmm, this is just what I needed."
    new "うん、これが必要だったわ。"

    # say L448 pla
    old "{i}(What a weird position to do that.){/i}"
    new "{i}(そんな体勢でやるの、変だな。){/i}"

    # say L449 pla
    old "{i}(I guess it has to do with her whole yoga thing.){/i}"
    new "{i}(ヨガのことが関係してるのかな。){/i}"

    # say L450 lis
    old "Oh yes! I can sense the energy moving!"
    new "ああ！エネルギーが流れているのを感じるよ！"

    # say L455 lis
    old "Oh! Oh, I can feel the energy flowing."
    new "ああ！ああ、エネルギーが流れているのを感じてる。"

    # say L457 lis
    old "Oh! Oh yeah!"
    new "オッ！オッ！そうね！"

    # say L481 lis
    old "Ah! Ah! That's right!"
    new "アッ！アッ！そうよ！"

    # say L482 lis
    old "I can feel it! My Muladhara chakra is in full harmony!"
    new "感じてる！私のムーラダラチャクラが完全に調和してるの！"

    # say L489 lis
    old "That was absolutely perfect!"
    new "それが完璧だったわ！"

    # say L490 lis
    old "And just what I needed, what a wonderful thing."
    new "そしてまさに必要なもの、素晴らしいことだわ。"

    # say L491 lis
    old "I can feel the energy flowing through my entire body."
    new "全身にエネルギーが流れているのを感じる。"

    # say L492 lis
    old "I'm ready to continue my day now."
    new "今なら一日を続けていけるわ。"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Church.rpy
translate japanese strings:

    # say L44 pla
    old "She is praying, I shouldn't bother her."
    new "彼女は祈ってるんだ、邪魔しちゃダメだな。"

    # say L58 jon
    old "Oh, hi young man, are you the one who accompanied Lydia a few days ago?"
    new "あら、こんにちは若者さん。あなたが数日前にリディアを連れてきた方ですか？"

    # say L60 pla
    old "Yes Mrs. Jones, my name is [pla], nice to meet you."
    new "はい、ジョーンズ夫人、私の名前は[pla]ですが、よろしくお願いします。"

    # say L62 jon
    old "Excellent [pla], I think it's very good that you visit the church."
    new "素晴らしいですね、[pla]さん。教会に来てくれることはとても良いことだと思いますよ。"

    # say L64 jon
    old "Many young people should be like you."
    new "若い人たちはあなたのように振る舞うべきですね。"

    # say L66 pla
    old "Oh no, I just-"
    new "いや、ただの間違いだよ"

    # say L68 jon
    old "Today all young people think about is sex, parties and devil things."
    new "今日の若者はセックスやパーティー、悪魔的なことばかり考えているわ。"

    # say L70 jon
    old "Did you know that sister Grace is organizing the church choir?"
    new "ご存知ですか、グレース姉さんが教会の合唱団を組織しているって。"

    # say L72 jon
    old "If you want I could introduce you, so you could continue on your way to the Lord."
    new "もしよろしければ、あなたを紹介しましょう。そうすれば、主への道を続けることができますよ。"

    # say L74 pla
    old "Well, actually-"
    new "実はね、"

    # say L76 jon
    old "Perfect! I'll talk to sister Grace, she'll be very happy."
    new "パーフェクト！シスター・グレースに話してあげるから、きっと喜んでくれると思います。"

    # say L90 jon
    old "Oh, hi [pla], how are you doing."
    new "あら、こんにちは [pla]、お元気ですか？"

    # say L91 pla
    old "Hi, Mrs. Jones, I'm great thanks, what about you?"
    new "こんにちは、ジョーンズさん、元気ですよ、ありがとうございます。あなたは？"

    # say L92 jon
    old "I'm fine, waiting for the next mass."
    new "私は大丈夫です、次のミサを待っています。"

    # say L93 jon
    old "Do you need something hun?"
    new "何かが必要ですか、ハニー？"

    # say L117 jon
    old "Honey?"
    new "ハニー？"

    # menu L119 
    old "Not now."
    new "今じゃないよ。"

    # say L122 pla
    old "Oh no, don't worry, I just wanted to say hi."
    new "大丈夫、心配しなくていい、ただこんにちはって言いたかっただけだよ。"

    # say L123 jon
    old "Alright, thank you hun, see you later."
    new "はい、ありがとう hun、またね。"

    # say L124 pla
    old "Bye, Mrs. Jones."
    new "じゃあ、また後で、ジョーンズさん。"

    # say L181 pla
    old "(Wow!)"
    new "わお！"

    # say L182 pla
    old "(Sister Grace is really attractive...)"
    new "シスター・グレースは本当に魅力的だな…"

    # say L183 pla
    old "(Should I use the Agamoto eye?)"
    new "アガモトの目を使おうか？"

    # menu L185 
    old "Yes"
    new "はい"

    # say L188 pla
    old "(Oh my...)"
    new "（おっ……）"

    # menu L190 
    old "No"
    new "いいえ"

    # say L193 pla
    old "(I better get back to work.)"
    new "（俺、仕事に戻るかな。）"

    # say L203 pla
    old "(Mrs. Jones's skirt went up quite a bit...)"
    new "（ジョーンズ夫人のスカート、ずいぶん上がっちゃったな…）"

    # say L221 gra
    old "Wow! I knew you would have been fast but I didn't expect that much."
    new "すごいですね！速さは知っていましたが、これほどとは思いませんでした。"

    # say L222 pla
    old "Haha, thanks Sister Grace... I like to do things as fast as possible."
    new "ははは、ありがとう、グレース姉さん…… 僕はできるだけ早くやりたいんだ。"

    # say L223 jon
    old "I wonder if you're that good at everything... Great job!"
    new "あなたがすべてのことにそんなに上手かどうか気になりますね… お見事です！"

    # say L224 jon
    old "Anyway, it's already very late, and I think we should all rest now, see you again tomorrow."
    new "それでは、もう遅いですし、皆様もお休みになった方がよろしいかと存じます、また明日お会いしましょう。"

    # say L225 gra
    old "Thank you, so much for your help Mrs. Jones and [pla]."
    new "ありがとうございます、ジョーンズ夫人と[pla]。"

    # say L226 pla
    old "Alright, see you tomorrow."
    new "じゃあ、また明日な。"

    # say L240 gra
    old "Oh, it's too late and we can't finish cleaning."
    new "もう遅いですね、掃除は今日で終わりにしましょう。"

    # say L241 jon
    old "Well, today was a bit harder than usual..."
    new "今日はちょっといつもより大変でしたね..."

    # say L242 pla
    old "Don't worry, I can stay and finish the cleaning."
    new "心配しなくていい、掃除は俺が残って終わらせるよ。"

    # say L243 jon
    old "Oh no! It's fine, we'll finish tomorrow..."
    new "大丈夫ですよ、明日続きをしましょう..."

    # say L244 gra
    old "It's fine, just hurry a little more next time and we will make it."
    new "大丈夫です、次はちょっとだけ早めに頑張れば間に合いますよ。"

    # say L245 pla
    old "I guess the next time will be better."
    new "次はもっと上手くいくだろうな。"

    # say L246 jon
    old "Sure, it will!, anyway see you again tomorrow."
    new "うん、そうなるわ、ともかくまた明日ね。"


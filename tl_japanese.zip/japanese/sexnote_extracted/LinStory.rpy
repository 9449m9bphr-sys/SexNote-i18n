# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/LinStory.rpy
translate japanese strings:

    # say L6 jon
    old "What was that?!"
    new "何だったの？！"

    # say L7 gra
    old "I have no idea... I'm as surprised as you're right now."
    new "私にもわからないわ… 私も今あなたと同じくらい驚いているの。"

    # say L8 jon
    old "I've been here for many years and it's the first time I hear such strange noise."
    new "私はここに長く住んでいますが、こんな不思議な音を聞いたのは初めてです。"

    # say L15 jon
    old "God! Something strange is happening here... It's not normal for the lights to turn off and on by themselves all the time."
    new "神様！何か変なことが起こってるわ… 電気が勝手に点いたり消えたりするのは普通じゃないわ。"

    # say L16 gra
    old "I know... But... What could it be?"
    new "私もそう思う……でも、いったい何が起こってるのかしら？"

    # say L19 jon
    old "A ghost! An evil presence, what else could it be?!"
    new "幽霊よ！邪悪な存在、他に何があるっていうの？！"

    # say L22 gra
    old "What!? Do you really think so?"
    new "何！？ 本当にそう思うの？"

    # say L23 jon
    old "Of course! I'm not joking... So why do you think this youth is so rotten and lost? It's the devil's work!"
    new "もちろん！冗談じゃないわ… それじゃ、君はこの若者がこんなに腐って迷子になった原因は何だと思う？悪魔の仕業に決まってるでしょう！"

    # say L24 gra
    old "Yes Mrs. Jones, you're right, must be that. I don't think it's an electricity issue."
    new "はい、ジョーンズ夫人、その通りです。電気の問題とは思えませんね。"

    # say L26 gra
    old "We gotta do something! Fuck... Jesus Christ!"
    new "何かしないと！クソ……イエス・キリスト！"

    # say L28 jon
    old "Sister Grace! Watch your mouth, please!"
    new "シスター・グレース！　言葉を慎んでくださいね！"

    # say L30 gra
    old "Sorry Mrs. Jones, but this situation gets on my nerves, it's a ghost or a devil. We must perform an exorcism!."
    new "申し訳ありません、ジョーンズ夫人、この状況は私をイライラさせます、幽霊か悪魔がいるんです。除霊を行う必要があります！"

    # say L31 jon
    old "We need the pries-"
    new "私たちは神父様が必要ですね。"

    # say L32 pla
    old "(I should use the Agamoto's eye and check if I can see something...)"
    new "アガモトの目を使って、何か見えるか確認すべきだな…"

    # say L39 pla
    old "(Oh no! It's not a ghost... It's a shinigami!)"
    new "（しまった！幽霊じゃなかった……死神だった！）"

    # say L40 pla
    old "(But... What happened to her!? Seems she is trapped or...)"
    new "でも……彼女には何が起こったんだ！？ 見る限り、何かに捕らわれてるみたいだな……"

    # say L41 pla
    old "(She looks like she's in pain... And why does she fly like that??!)"
    new "（彼女、痛そうに見えるな… それに、なんでそんな風に飛んでるんだよ？！）"

    # say L42 pla
    old "(I gotta talk to this shinigami... This has something to do with the magic...)"
    new "この死神と話さないと… 魔法に関わってるんだよ…"

    # say L45 pla
    old "Hello, Oh! Sorry... I didn't want to interrupt..."
    new "こんにちは、オッ！すみません... 邪魔したくないと思ってました..."

    # say L50 jon
    old "Oh! Hello [pla] don't worry, we were discussing something important but it's fine..."
    new "Oh！こんにちは、[pla]心配しないでください、大切なことを話し合っていたけど大丈夫です…"

    # say L51 jon
    old "Let me introduce you to our Sister Grace, she is the nun of the church."
    new "こちらを私たちのシスター・グレースにご紹介します、彼女は教会の修道女です。"

    # say L52 pla
    old "Hi, nice to meet you."
    new "こんにちは、会えて嬉しいです。"

    # say L53 gra
    old "Hi [pla], nice to meet you to."
    new "こんにちは [pla]、会えて嬉しいです。"

    # say L54 pla
    old "I was just passing by to say hell-"
    new "通りかかって挨拶しようと思ったんだけど、"

    # say L55 jon
    old "Hun, something terrible is happening here... We might have the presence of a ghost in the church! Can you believe it?"
    new "亲爱的，这里发生了可怕的事情……教堂里可能有鬼魂！你能相信吗？"

    # say L56 gra
    old "Or a devil... Gosh darn I-!"
    new "または悪魔……おやおや、私ったら！"

    # say L58 jon
    old "Sister Grace, please!"
    new "グレース姉さん、お願いします！"

    # say L60 pla
    old "Wait! Why do you think is a ghost?"
    new "待って！なぜ幽霊だと思うんだ？"

    # say L62 jon
    old "There are strange noises, the lights turn off and on by themselves... And I'm a very spiritual person, if I'm telling you this is because it is what it is..."
    new "不思議な音がして、電気が勝手に点いたり消えたりするんです……それに私はとてもスピリチュアルな人で、これが本当のことだと感じているから話しているんです……"

    # say L63 pla
    old "I- I believe you... But what are you gonna do?"
    new "君の言うことは信じてる… でも、どうするつもりなんだ？"

    # say L64 gra
    old "An exorcism!"
    new "祓いの儀式です！"

    # say L66 pla
    old "An exorcism?"
    new "祓いの儀式？"

    # say L67 pla
    old "(I have to talk to the girls... They should know what's happening.)"
    new "女の子たちに話さなきゃな… 何してるか知っておいた方がいい。"

    # say L68 jon
    old "Hun, we don't want to scare you..."
    new "ハニー、怖がらせたくはないんだけど…"

    # say L69 pla
    old "No, I'm not... I gotta go now, I- I have some... Homework to do but I will pass by to see what happens."
    new "いや、大丈夫だ… 行かなきゃならないんだ、宿題があるけど、状況を見てくるよ。"

    # say L70 pla
    old "Perhaps I could help out... Dunno... It's very strange what's happening here."
    new "俺も手伝うか... 分からないけど... ここでの出来事はとても不思議だな。"

    # say L71 jon
    old "Alright, please take care of yourself."
    new "では、お気をつけてね。"

    # say L73 pla
    old "You too Mrs. Jones... Goodbye..."
    new "ジョーンズさんも気をつけて…さようなら…"

    # say L75 gra
    old "Bye [pla], may God take care of your soul."
    new "さようなら[pla]、神様があなたの魂をお守りください。"

    # say L80 pla
    old "(What's happening here, this is weird, I gotta talk to the shinigamis.)"
    new "ここ何が起こってるんだ、変だな、死神たちと話さないと。"

    # say L95 pla
    old "(Alright, I'm here... Fortunately there is no one here, I should use the Agamoto's eye and talk with them before someone comes.)"
    new "(よし、来たぞ… 幸い誰もいないから、アガモトの目を使って話す前に誰かが来ちゃう前に動こう。)"

    # say L112 pla
    old "Hey girls, I gotta tell you something!"
    new "Hey girls、ちょっと話があるんだ！"

    # say L128 mil
    old "Well, hello... We're actually fine and you?"
    new "まあ、こんにちは… 我々は大丈夫よ、あなたは？"

    # say L129 pla
    old "Opss! Sorry... Hi hi..."
    new "オッ-ps！ ごめん... ひひ..."

    # say L130 pla
    old "This is something important... I found a new Shinigami at the church..."
    new "これは大事なことだ... 教会で新しい死神を見つけたんだ..."

    # say L131 pla
    old "I don't know what's happening but she's not fine for sure, she was flying around, looking drowsy..."
    new "何が起こってるのかわからんけど、絶対調子が悪いよ。空を飛んでたけど、眠そうだったんだ..."

    # say L132 gom
    old "A new shinigami? And what do you mean by drowsy?"
    new "新しい死神？そして眠そうってどういう意味？"

    # say L133 pla
    old "Hmm, like very weak... Dunno! Do you guys have any idea of what's happening there?"
    new "うーん、めっちゃ弱そうなんだよな… 分かんねえ！君たち何か知ってんの？"

    # say L135 mil
    old "What? What was she doing in there?"
    new "何？彼女は中で何してたの？"

    # say L136 pla
    old "Well, she was flying but it seemed she was stuck in there..."
    new "WELL、彼女は飛んでたけど、中に閉じ込められてるみたいだな。"

    # say L138 mil
    old "Hmm, alright... I may know what's happening."
    new "うーん、そうね… 何が起こってるのか、少しは分かるわ。"

    # say L139 mil
    old "If what you said is happening, it might be that the shinigami is in trouble with her energy."
    new "あなたが言ったことが起こっているなら、死神がエネルギーで困っているのかもしれないわ。"

    # say L140 mil
    old "I mean, there is no much energy around and she must be stuck in there. When there is not enough energy, we suffer the consequences."
    new "エネルギーがほとんどないから、彼女はそこに閉じ込められてるのかも。エネルギーが足りないと、私たちも影響受けるんだ。"

    # say L141 mil
    old "Most likely she has just a couple of..."
    new "多分、あと数日だけ..."

    # say L143 pla
    old "A couple of? Of what?"
    new "何の数日だよ？"

    # say L144 mil
    old "A couple of days left..."
    new "あと数日しか残ってないみたい…"

    # say L145 gom
    old "This is so sad... We all will die..."
    new "これは悲しいな… 全員が死んじゃうんだから…"

    # say L146 dev
    old "All this is bullshit..."
    new "これ全部、クソだよ…"

    # say L147 mil
    old "Girls! Wait a sec... We can still do something, we have [pla] on our side, he's gonna help us."
    new "女の子たち！ちょっと待って……まだ何かできるわ、[pla]が私たちの味方だから、彼はきっと助けてくれるはずよ。"

    # say L148 gom
    old "But... But how? There is no more magic power around us... Tell me how?"
    new "でも……どうやって？周りにはもう魔法の力がないの……教えて？"

    # say L151 pla
    old "There has to be a way, just tell me what to do and I'll do it, we can't let her die."
    new "方法があるはずだ、何をすればいいか教えてくれ、彼女が死んじゃいけない。"

    # say L153 mil
    old "[pla] just go and check how is her... Try to share some of your magic power with her."
    new "[pla] 行って彼女の様子を見てきて……あなたの魔力の一部を分け与えてみて。"

    # say L155 pla
    old "Sure, I'll... I'm so sorry all this is happening but don't worry, I'll help..."
    new "もちろん、行くよ... こんなことになってごめんな、でも心配しないで、助けるから..."

    # say L156 pla
    old " It's better if I go now... See you!"
    new "今行く方がいいな… またね！"

    # say L159 dev
    old "Good luck... And see you."
    new "頑張って…またね。"

    # say L160 mil
    old "[pla] take care and don't forget we count on you."
    new "[pla] 気をつけて、私たちがあなたに期待してるのを忘れちゃダメね。"

    # say L161 pla
    old "I know... I'll do my best!"
    new "分かってるよ… 頑張るから！"

    # say L181 mor
    old "Alright, we are going to start the exorcism."
    new "では、除霊の始まりです。"

    # say L188 mor
    old "Lord, please protect our church, protect us from these evil presences that surround us."
    new "主よ、私たちの教会を守り、私たちを取り巻く邪悪な存在から守ってください。"

    # say L191 jon
    old "Amen."
    new "アーメン。"

    # say L194 mor
    old "Our Father, who art in Heaven, hallowed be Thy name, Thy kingdom come..."
    new "天にいる父よ、御名が聖とされますように、御国が来ますように…"

    # say L195 mor
    old "Thy will be done, on earth as it is in Heaven. Give us this day our daily bread, and forgive us ou-"
    new "御心のままに、地上でも天でも。今日の糧を私たちに与え、そして私たちの罪を赦し-"

    # say L197 pla
    old "(There she is... Is the shinigami... She'll die if I don't do something!)"
    new "そこにいる… 死神だ… 手を打たないと彼女は死んじゃう！"

    # say L198 pla
    old "Huh,  w- what's happening? "
    new "へえ、これは何が起こってるんだ？"

    # say L203 jon
    old "[pla]! Hi hun, is the ghost... The demon presence... It's taking over the church."
    new "[pla]！ひい、おとうさん。幽霊……悪魔の存在が……教会を支配しようとしてるの。"

    # say L204 gra
    old "Hi [pla], Mrs. Jones is right, the situation is getting worse."
    new "こんにちは[pla]、ジョーンズ夫人が仰る通り、状況は悪化しています。"

    # say L207 pla
    old "What? Why do you think is a demon?"
    new "何？なぜそれが悪魔だと思うんだ？"

    # say L208 gra
    old "Because it is! What else could it be if not a demon, a ghost!?"
    new "だってそうじゃない！悪魔でも幽霊でもないなら、何がそんなことになるっていうの！？"

    # say L209 jon
    old "It is hun... We know that, just look at the lights, everything is a mess here because of that."
    new "それはそうよ… 電灯を見ればわかるわ、ここは全部そのせいで大変なことになっているの。"

    # say L210 pla
    old "(If I don't do something quickly, she will probably die.)"
    new "もし早く行動しなければ、彼女は多分死んでしまうだろう。"

    # say L211 pla
    old "Ehmm... I'm sorry to contradict you but the presence we have right now in this church is not malignant at all, I'm sure of that."
    new "ええっと……申し訳ありませんが、今この教会にいる存在は決して悪意を持っていません、それが確実です。"

    # say L212 gra
    old "What? What are you saying? If you're so sure, prove it!"
    new "何？何言ってるの？もし本当にそうなら、証明してみてよ！"

    # say L213 pla
    old "W- Well... I can do it! Take a look at the lights."
    new "うーん……証明できるよ！灯りを見てごらん。"

    # say L214 pla
    old "I'll tell the spirit to move to the right and the lights on that side will start to fade, if this happens you'll see that this spirit has good intentions."
    new "このスピリットに右に移動するように伝えて、その側のライトが消え始めるのが見れば、このスピリットが好意を持っていることが分かるよ。"

    # say L215 gra
    old "Hmm, let's see."
    new "うーん、見てみましょう。"

    # say L217 pla
    old "Spirit! Listen to me... We know we can help you as you can help us as well, please move to the right side and let us know by using the lights..."
    new "スピリット！聞いてくれ……お互いに助け合えることは分かってるよね、右側に移動してライトを使って教えてくれ……"

    # say L224 gra
    old "My God! He did it! The lights were fading..."
    new "私の神様！彼がやった！光が消え始めてる…"

    # say L225 pla
    old "Spirit! Thanks! We saw it, you may now come back to your place."
    new "スピリット！ありがとう！見えたよ、君はもう元の場所に戻ってもいいぞ。"

    # say L230 jon
    old "[pla]! You were right... But how, how did you know it!?"
    new "[pla]！あなたが正しかったわ…でも、どうして分かったの！？"

    # say L232 pla
    old "I simply knew it, I can feel the creature's energy and I know it's good... There is nothing bad within it."
    new "俺はただ知っていたんだ、この生物のエネルギーを感じ取れるからさ。中には何も悪いものがないってわかるよ。"

    # say L233 jon
    old "I'm surprised..."
    new "驚いています…私"

    # say L234 mor
    old "Son, we see you're right, this spirit actually listens to you and does accordingly but what does it want? What can we do?"
    new "息子よ、君が正しいことはわかった。この霊は実際に君の言うことを聞いて行動しているが、いったい何を欲しているのか？ 我々は何ができるだろうか？"

    # say L235 pla
    old "Well, I thin-"
    new "WELL、この霊が何を欲しているのかはまだよくわからないが、何かできることがあれば教えてほしいな。"

    # say L246 bil
    old "What's the fuss about? Granma what's happening here?"
    new "何の騒ぎ？おばあちゃん、ここでは何が起こってるの？"

    # say L251 jon
    old "Hi darling! It's a ghost-"
    new "こんにちは Darling！幽霊がいるのよ-"

    # say L252 bil
    old "Oh really! Shut up, please! You're talking nonsense."
    new "ほんと！うるさいからやめて！バカなこと言ってるだけじゃない。"

    # say L253 gra
    old "It's true! There is an evil presence here..."
    new "本当よ！ここには邪悪な存在がいるの…"

    # say L255 bil
    old "Sister Grace I wasn't talking to you, please don't be rude... I can't deal with nosy people."
    new "シスター・グレース、私あなたに話しかけてないから、失礼なこと言わないでください… 邪魔されるのは嫌だから。"

    # say L283 jon
    old "What's happening Billie? BILLIE!?"
    new "ビリー、どうしたの？ビリー！？"

    # say L291 jon
    old "Nooo! Billie, wake up!! What's happening!? Someone help me, please!"
    new "ノォー！ビリー、目を覚ませ！！どうしたの！？誰か助けてください！"

    # say L292 gra
    old "Oh God, please help us."
    new "神様、どうか私たちを助けてください。"

    # say L293 mor
    old "Calm down everybody...!"
    new "みんな、落ち着いて……！"

    # say L295 mor
    old "I believe in God, the Father Almighty, Creator of Heaven and earth; and in Jesus Christ, His only Son, Our Lord..."
    new "私は神、全能の父、天地の創造者を信じます。そしてイエス・キリスト、神の唯一の御子、私たちの主を信じます…"

    # say L298 gra
    old "Father Morgan?"
    new "Father Morgan？"

    # say L299 mor
    old "It's important to keep praying for Billie."
    new "ビリーのために祈り続けることが大切だよ、グラシール。"

    # say L300 mor
    old "Let's pra-"
    new "祈り続けよう、ビルリーのために。"

    # say L301 gra
    old "Noo! Father Morgan, take her to the hospital with Mrs. Jones, I'll take care of the church..."
    new "Father Morgan、お願いです、ビルリーをジョーンズ夫人と一緒に病院に連れて行ってください、私は教会のことを任されますから…"

    # say L303 jon
    old "Yes, let's go now... She has to be checked by a doctor."
    new "はい、今すぐ行きましょう… 医者に診てもらう必要がありますから。"

    # say L309 mor
    old "Sister Grace, please take care of the church, call me if anything... Ok?"
    new "グレース姉さん、教会はお願いします、何かあったら連絡を…ね？"

    # say L322 pla
    old "Wow that was... Weird..."
    new "あのね、それって… ちょっと変だったな…"

    # say L323 gra
    old "I hope Mrs. Jones's granddaughter is fine."
    new "ジョーンズさんの孫娘が無事であることを願っています。"

    # say L324 pla
    old "Yeah, me too."
    new "うん、俺も。"

    # say L325 gra
    old "Wait a minute, the lights are not flashing! The ghost is gone!"
    new "ちょっと待って、灯りが点滅していない！幽霊がいなくなった！"

    # say L326 pla
    old "W- what? (Oh shit, what happened with the shinigami?)"
    new "えっ、何？（しまった、死神はどうした？）"

    # say L327 pla
    old "You are right... I can't see anything either"
    new "君が言う通りだ… 僕も何も見えないな"

    # say L328 pla
    old "(Oh no... It means she... d- died.)"
    new "ああ、そうか…… つまり彼女は…… 死んだということか。"

    # say L329 gra
    old "And it was because of you! Thank you for your help."
    new "そしてそれがあなたのせいだったのね！ ありがとう、助けてくれて。"

    # say L330 pla
    old "Yeah... It was because of me... (It was my fault...)"
    new "そうだな… 俺のせいだった…"

    # say L331 gra
    old "I'm really impressed, don't know which kind of spiritual connection you have."
    new "すごいですね、あなたがどんなスピリチュアルなつながりを持っているのか私にはわかりません。"

    # say L332 gra
    old "It was as if you were communicating with something higher... Something that we cannot see, something beyond our comprehension, perhaps divine."
    new "あなたが何か崇高なものと通信しているかのようだったの…… 我々が見ることができない、理解を超えた何か、もしかしたら神聖なものかもしれないわ。"

    # say L333 pla
    old "Hmm yeah... Something like that"
    new "うん、そんな感じだな"

    # say L334 pla
    old "(Argh! I didn't save her... I'm completely useless...) "
    new "（ああ！彼女を救えなかった……俺は全く役立たずだ……）"

    # say L335 gra
    old "You're definitely closer to the divine spirit than even Father Morgan..."
    new "あなたは確かに Father Morgan さまだよりも神聖な霊に近いですね…"

    # say L336 pla
    old "I better go home, goodbye Sister Grace."
    new "家に帰るよ、さようならシスター・グレース"

    # say L343 gra
    old "Wait [pla]!..."
    new "待って [pla]！"

    # say L364 mo1
    old "Good morning darling, someone is looking for you..."
    new "おはよう Darling、誰かが君を探しているのよ…"

    # say L365 pla
    old "Looking for me?... Who's that?"
    new "俺を捜してるって？…誰だよ？"

    # say L366 mo1
    old "Two women... An old lady and a nun, where do you know them from?"
    new "二人の女性… おばさんと修女さん、どこで知り合ったの？"

    # say L367 pla
    old "Ahh ok! Hmm... They're from the church, you know I have been there quite a few times..."
    new "ああそうか！うーん……教会からだ、君がよく行っている場所だからね。"

    # say L368 mo1
    old "I see... Well, they're waiting, go to see what they need, honey."
    new "そうね… でも、彼女たちが待っているわ、何が必要か見てあげてちょうだい、親愛なる子よ。"

    # say L369 pla
    old "Sure! Thanks [mo1]."
    new "分かった！ありがとう[mo1]。"

    # say L376 jon
    old "Hi dear, I'm so sorry to bother you but you're the only one who can help us..."
    new "こんにちは親愛なる方、申し訳ありませんがお手伝いいただけないでしょうか、あなたしか頼りにできませんの…"

    # say L377 pla
    old "Hi Mrs. Jones... Hmm, me? Why? What happened?"
    new "こんにちはジョーンズさん… えっと、俺？なぜですか？何があったんですか？"

    # say L378 gra
    old "Hi [pla], well... As I told you in the church, you were a great help and we think you could do something for Billie."
    new "こんにちは[pla]、ええ…… 教会で言った通り、あなたは大変お力になりましたし、ビリーのために何かしていただけるんじゃないかと思います。"

    # say L381 jon
    old "I'm so worried for my granddaughter, I'm afraid I'll lose her... Please help me!"
    new "私の孫が心配で心配で仕方ありません、彼女を失うのが怖いんです… どうかお力添えをお願いします！"

    # say L382 pla
    old "I'm so sorry to hear she's not ok... But I don't know how could I help... I'm not a doctor."
    new "そんなに心配してらっしゃるのに、申し訳ありません…でも、どうやってお手伝いできるか全然わからないんです…医者じゃないですし。"

    # say L383 gra
    old "Well, we think this case is more related on a spiritual level, and you showed divine talents, so we hope that you could help us."
    new "私たちはこのケースが霊的な面に関連していると考えていますので、あなたが神聖な才能をお持ちだと知り、お力添えをいただけると期待しています。"

    # say L384 pla
    old "And what about the Father Morgan?"
    new "Father Morganは試したけど効果がなかったし、君が最後の希望なんだよ。"

    # say L385 jon
    old "He already tried but didn't work and well... You're our only hope."
    new "彼はもう試しましたが効果がありませんでしたし、まあ…あなたが私たちの最後の希望です。"

    # say L386 pla
    old "Alright, I'll try to help, but I'm not sure if I can-"
    new "わかった、手伝ってみるけど、できるかどうか自信ないな。"

    # say L387 gra
    old "Thank you! We knew we can count on you."
    new "ありがとう！私たちあなたに期待していましたよ。"

    # say L388 jon
    old "Come with us, we have no time to lose. "
    new "一緒に来ましょう、時間がないんです。"

    # say L401 jon
    old "[pla] look at her... She's suffering, please do something!"
    new "[pla] 見てください……彼女が苦しんでいます、何かしてあげてください！"

    # say L402 pla
    old "Hmm let's see..."
    new "うーん、どうしようか…"

    # say L407 pla
    old "(What? The shinigami isn't dead? What's happening here!)"
    new "何？死神がまだ生きてるって？ここでは何が起こってるんだ！"

    # say L410 jon
    old "Oh my God! She is crying black tears..."
    new "ああっ！黒い涙を流しているの…"

    # say L412 gra
    old "Is there any way to help her [pla]?"
    new "彼女を助ける方法はありますか [pla]？"

    # say L413 pla
    old "(What the fuck is this?)"
    new "何これ"

    # say L414 gra
    old "[pla], are you fine? Are you in shock?"
    new "[pla]、大丈夫ですか？ショックを受けているんですか？"

    # say L416 pla
    old "(I don't understand what's happening here. I have to talk with the shinigamis.)"
    new "ここでの状況が理解不能だな。死神たちと話さなきゃならない。"

    # say L417 pla
    old "Hmm... W- Well..."
    new "うーん… あの…"

    # say L418 pla
    old "Hmm... I'll need to see her at night, right now I can't do anything but I'll come back later."
    new "Hmm... 夜に会うしかないな、今は何もできなくて後でまた戻ってくるよ。"

    # say L419 pla
    old "I need to... Prepare myself, if we do everything in the proper way, Billie will be fine soon."
    new "俺は… 準備しないと、すべてを正しく行うなら、ビリーはすぐに大丈夫になるさ。"

    # say L420 jon
    old "I have no words to thank you for everything you have done for us, her life is on your hands [pla]."
    new "私が皆さんのためにした全てに感謝の言葉が見つかりません、彼女の命はあなたの手に委ねられています [pla]。"

    # say L421 pla
    old "(My God! I really gotta do something for her and the shinigami.)"
    new "神様！本当に彼女と死神のために何かしなきゃならないな。"

    # say L422 pla
    old "Don't worry Mrs. Jones, she'll be fine. I better go now but I'll see you later."
    new "心配しないでください、ジョーンズさん。彼女は大丈夫です。今すぐ行かないとですが、また後で会いましょう。"

    # say L423 pla
    old "See you later as well Sister Grace."
    new "また後でね、グレース姉さん。"

    # say L425 gra
    old "Thanks! We'll be waiting for you."
    new "ありがとうございます！またお会いできるのを楽しみにしています。"

    # say L426 jon
    old "Take care hun and thanks again."
    new "お気をつけてね、またありがとう。"

    # say L449 pla
    old "I saw the shinigami! Apparently she's inside Billie's body. I saw her!"
    new "死神を見たぞ！どうやらビリーの体内にいるらしい。見たんだよ！"

    # say L467 mil
    old "I'm surprised with your manners... Hi [pla]!"
    new "あなたのマナーには驚いたわ… こんにちは[pla]！"

    # say L468 pla
    old "Hi hi! I know but this is important, I didn't expect to see her there..."
    new "こんにちは！知ってるけどこれ重要なんだよ。あそこで彼女を見つけるとは思わなかったんだ…"

    # say L469 mil
    old "Wait a sec! Who's Billie? What are you talking about?"
    new "ちょっと待って！ビリーって誰？何を言ってるの？"

    # say L470 pla
    old "Alright! Billie is a girl from the church and it seems the shinigami is inside of her, I have no idea how,.. You tell me!"
    new "分かったよ！ビリーは教会の女の子で、どうやら死神が彼女の中にいるらしいんだ。どうやってそうなったのか、俺にもわからないよ、君が教えてくれよ！"

    # say L472 mil
    old "[pla], this is actually delicate, that shinigami is trapped in Billie's body, that happens when there is a lack of energy in the shinigami's body..."
    new "[pla]、これは実際デリケートな問題だよ。あの死神はビルリーの体内に閉じ込められていて、それは死神の体内にエネルギーが足りないから起こるんだ..."

    # say L475 mil
    old "That shinigami is having serious problems and getting into a human's body was the only option she had..."
    new "その死神は深刻な問題を抱えていて、人間の体内に入るのが唯一の選択肢だったんだ..."

    # say L476 gom
    old "She's struggling right now and the only way to get out of Billie's body is through an energy transfer since the body where she's now doesn't have any energy."
    new "彼女は今苦労していて、ビルリーの体内から出る唯一の方法はエネルギー転送だよ。今の体にはエネルギーがないから。"

    # say L477 pla
    old "What? I thought she did possess her body... This makes more sense, that's why she's still there."
    new "何？体を乗っ取ってると思ったけど…これならまだそこにいる理由が分かるな。"

    # say L478 mil
    old "Yes, she can't get out by herself. Billie's body doesn't have enough energy and as I'm telling you.. The only way to help them is through a powerful load of energy."
    new "はい、彼女は自分で抜け出せないの。ビリーの体にはエネルギーが足りなくて、私が言っている通り……彼らを助ける唯一の方法は、強力なエネルギーを供給することよ。"

    # say L479 gom
    old "Are you willing to do that for them?"
    new "あなたは彼らのためにそれをするつもり？"

    # say L481 pla
    old "Yes, of course... I don't want anybody to die. How can I perform that energy transfer?"
    new "もちろん、誰も死なないようにしたいんだ。エネルギーを移す方法は？"

    # say L483 dev
    old "Come on! You already know how..."
    new "Come on！ あなたもう知ってるでしょ..."

    # say L484 pla
    old "Well, the only way to get energy I know is through s- sex-... A- are you saying that I have to have sex with Billie?"
    new "WELL、 ENERGY TRANSFER の 唯一の 方法って 性行為しか 知らないんだが… B- Billieと セックスしないと ならないって 言ってるのか？"

    # say L485 mil
    old "You just said it... Yeah, it's the only way. Once the shinigami gets your energy, she'll be able to get out of Billie's body. There is no other way."
    new "あなたが先に言ったじゃない… うん、それしかないの。死神があなたのエネルギーを得られれば、ビリーの体から出られるわ。他に方法はないのよ。"

    # say L486 mil
    old "You're a young, strong and virile man. You're the only one able to help her."
    new "あなたは若く、力強く、精力的な男だね。彼女を助けるのはあなたしかいないの。"

    # say L487 pla
    old "I get it, I'll do whatever it takes to help her."
    new "分かった、彼女のために何でもするよ。"

    # say L488 mil
    old "Get ready for it! You'll have to last much longer since it will not be easy but we know you can do it."
    new "準備できてる？　長く我慢しないとダメよ、簡単なことじゃないけど、あなたならできるわ。"

    # say L490 pla
    old "I'll do my best for her to come and come out... See you girls."
    new "彼女がイキまくるまで全力で…またね、みんな。"

    # say L492 mil
    old "See you [pla], we're counting on you."
    new "じゃあね、[pla]、私たちが期待してるわ。"

    # say L494 gom
    old "Please take care, [pla]"
    new "お手伝いよろしくお願いします、[pla]"

    # say L514 pla
    old "Hello Mrs. Jones, Sister Grace..."
    new "こんにちは、ジョーンズさん、シスター・グレース…"

    # say L515 jon
    old "Hi dear, we're so glad you're here... Let's start now. Tell us how to help you."
    new "こんにちは、親愛なるあなたがここにいてくれて本当に嬉しいです…さあ、始めましょう。どのようにお手伝いできるか教えてください。"

    # say L516 gra
    old "Dear [pla], we are at your service, just tell us how we help you."
    new "親愛なる[pla]、私たちはあなたのためここにいます、どうすればお手伝いできるか教えてください。"

    # say L517 jon
    old "We trust you and the gifts that the Lord has given you, please help my Billie."
    new "私たちはあなたと主が与えてくださった才能を信じています、どうか私のビリーを助けてください。"

    # say L518 pla
    old "(They can't be here... I gotta say something for them to go out...)"
    new "彼らはここにいられない……何か言って出て行ってもらうしかない……"

    # say L519 jon
    old "Tell us! Tell us hun!"
    new "教えてちょうだい！お願い！"

    # say L523 jon
    old "Are you ok? What's happening? Why don't we start now?"
    new "大丈夫ですか？何が起こっているんですか？なぜ今から始めないんですか？"

    # say L524 pla
    old "Yes, n- no. I- I mean, I'll start now but you can't be here, this is an important ritual that I must do alone."
    new "はい、いや、今から始めるけど、君たちはここにいちゃダメだ。これは重要な儀式で、一人でやらなきゃならないんだ。"

    # say L525 gra
    old "Alone? Why? We could assist you with our presence and prayers."
    new "一人で？なぜですか？私たちの存在と祈りであなたを支えられるのに。"

    # say L526 pla
    old "Hmm... Because, it's how it should be, could be dangerous for you."
    new "うーん… そうすべきだし、君たちには危険だからね。"

    # say L527 pla
    old "I don't think you're prepared to see what I'll do..."
    new "君が見るのは危険だ、まだ準備できてないと思うから…"

    # say L528 pla
    old "Billie? Billie, do you hear me?"
    new "ビリー？ビリー、俺の声聞こえるか？"

    # say L530 lin
    old "Gulp... is tha-?"
    new "gulp... それって…"

    # say L531 jon
    old "My Godness! Billie spoke! Let's get out of here. He knows what he's doing."
    new "神様！ビリーが話したわ！ここから出ましょう。彼は自分のことを知っていますから。"

    # say L532 pla
    old "Please leave me alone with her, we can't waste more time."
    new "私と二人きりにさせてくれ、時間がないんだ。"

    # say L533 lin
    old "I- I n- need h- help."
    new "私、助けてください。"

    # say L534 gra
    old "Call us if you need anything, [pla]."
    new "何か必要になったら、私たちに連絡してください、[pla]。"

    # say L548 pla
    old "Alright, how I'm gonna do this?"
    new "よし、どうやってこれをやるんだ？"

    # say L549 pla
    old "Shinigami? Billie?"
    new "Billie？"

    # say L551 lin
    old "Y- You're here! P- please help me to get out of her, I- I'm trapped."
    new "あなたがここにいるの！ お願い、助けて、出させてください。閉じ込められてるの。"

    # say L552 pla
    old "I know... You know the only way is through an energy transfer process, right?"
    new "知ってるよ…唯一の方法がエネルギー転送プロセスってことだろ？"

    # say L553 lin
    old "Y- Yes, please hurry up! I- I'll die if we don't do it."
    new "はい、早くして！ やらせてくれないと死んじゃうよ。"

    # say L554 pla
    old "We'll need to have s- sex, well... You know it's how it's called."
    new "俺たちがセックスするしかないんだ、まあ……そう呼ばれるらしいけど。"

    # say L556 lin
    old "Shoot! C- Can you simply do it!? I already know what you're saying. I need you to do it now!"
    new "急いでよ！ お願い、もう我慢できないくらいよ！"

    # say L557 pla
    old "No! No, I was just saying..."
    new "いや！いや、ただ言ってるだけさ…"

    # say L558 pla
    old "But I shouldn't have sex with this girl, I don't even know her."
    new "でも、この子とセックスするのはよくない。俺は彼女のこと何も知らないんだ。"

    # say L564 lin
    old "W- what you are going to do is share a magical power with me the shinigami... Don't overthink it. "
    new "あなたがすべきなのは、私である死神と魔法の力を分かち合うこと……深読みしないで。"

    # say L565 lin
    old "I need you to free me now... Do it..."
    new "今すぐ私を解放して……お願い……"

    # say L595 jon
    old "My God! What's going on here? What did you do to Billie?"
    new "私の神様！ここでは一体何が起こっているの？ビルリーに何をしたの？"

    # say L597 pla
    old "(Oh no! Now what?!)"
    new "ああ、またか！どうするんだ！"

    # say L599 jon
    old "[pla]? Is this part of the ritual you had planned to perform? I don't understand..."
    new "[pla]？これはあなたが行う予定だった儀式の一部ですか？私にはわかりません…"

    # say L600 pla
    old "(Damn it! What should I say?)"
    new "くそっ！何て言えばいいんだ？"

    # say L605 bil
    old "Grandma? Sister Grace? Where am I?... What happened?"
    new "グランマ？シスター・グレース？どこにいるの？…何が起こったの？"

    # say L606 bil
    old "Someone tell me what happened to me? Why am I naked and sweating?"
    new "誰か教えてください、私に何が起こったの？なぜ裸で汗をかいてるの？"

    # say L607 gra
    old "Well! She looks much better now..."
    new "まあ！ ずいぶん元気になったわね…"

    # say L610 jon
    old "My God, thanks! She's back!"
    new "神様、ありがとう！ 彼女が戻ってきた！"

    # say L611 bil
    old "Huhh, what is going on?"
    new "へえ、何が起こってるの？"

    # say L612 gra
    old "We know you must be feeling so confused about everything..."
    new "私たちはあなたがすべてについて混乱していることよくわかります…"

    # say L613 gra
    old "Your body was possessed by a spirit, but [pla] helped us perform a ritual and now you're back, you're fine now... "
    new "あなたの体は霊に取り憑かれていたけど、[pla]が私たちに儀式を教えてくれて、今あなたは大丈夫よ…"

    # say L614 bil
    old "What? My body... Possessed? What the fuck?"
    new "何？私の体……憑かれた？何てことだよ？"

    # say L615 gra
    old "Yes, it happened while we all were at the church, we don't know why but what matters now is that you're fine."
    new "はい、教会にみんながいたときに起こりました。なぜそう became なぜそうなったのかはわかりませんが、今大切なのはあなたが元気なことです。"

    # say L620 pla
    old "It was part of the ritual... It was the only way to help her out."
    new "それは儀式の一部だった… 彼女を助けるためにはそれが唯一の方法だった。"

    # say L621 gra
    old "She seems to be totally fine now, I don't feel the spirit's presence anymore."
    new "彼女はもう全然大丈夫そうですね、霊の気配も感じられなくなりました。"

    # say L622 pla
    old "She's fine now, I've cleaned her body from the spirit's presence... Now she's fine and healthy."
    new "彼女はもう大丈夫だ、俺が霊の影響をきれいにしたから… 今では健康で元気だ。"

    # say L624 jon
    old "Don't worry my love, you're fine now. You just need to rest..."
    new "心配しないで dear、あなたはもう大丈夫よ。ただゆっくり休んでね…"

    # say L627 bil
    old "Huhh could you please let me go? I'm not breathing..."
    new "はーっ、ちょっと離していただけませんか？ 呼吸できないんです…"

    # say L633 gra
    old "Ohh, sorry... It's just that we're so happy you're fine..."
    new "あら、ごめんなさい… ただ、君が無事でいてくれて本当にうれしかったの…"

    # say L634 gra
    old "Thanks [pla], you have been such a great help."
    new "ありがとうございます、[pla]。あなたは本当に大きな助けでした。"

    # say L637 jon
    old "Yeah, thanks hun, I'm so grateful with you, you're a saint. Definitely God is inside of you..."
    new "うん、ありがとう亲爱的，我真的很感激你，你真是个圣人。上帝一定住在你心里..."

    # say L638 pla
    old "Don't worry, I just did what... God told me to do... I'll be here to help."
    new "心配しなくていい、ただ神様が教えてくれたことをしただけさ… いつでも手伝うよ。"

    # say L639 pla
    old "I should be going now... It's been a very demanding ritual and I need to get some rest."
    new "じゃあ、行かないと… 厳しい儀式だったから、少し休む必要があるんだ。"

    # say L641 jon
    old "Sure hun! Take care and thanks again!"
    new "もちろん、気をつけてね。またありがとう！"

    # say L642 pla
    old "Mmm... Thanks, see you Mrs. Jones... Bye Sister Grace."
    new "ありがとう、またねMrs. Jones… さようなら、シスター・グレース。"

    # say L643 gra
    old "Bye dear [pla]"
    new "さよなら dear [pla]"

    # say L655 bil
    old "What was that naked guy doing here?"
    new "あの裸の男の人は何してたの？"

    # say L672 pla
    old "How are you feeling? Are you ok?"
    new "調子はどう？大丈夫か？"

    # say L674 pla
    old "You know what... There are more shinigamis like you, we can help you."
    new "君が知っているだろうけど… 同じような死神は他にもいるんだ、俺たちが君を助けることができるよ。"

    # say L675 lin
    old "Who are you? Why are you helping me?"
    new "誰だ？なぜ私を助けてくれるの？"

    # say L676 pla
    old "Oh yes, sorry! I'm [pla], as I just told you... I know others like you."
    new "ああ、すまない！俺は[pla]だ、さっきも言ったけど…君のような他の連中も知ってる。"

    # say L677 lin
    old "I see... Nice to meet you [pla], I'm Linett and well..."
    new "なるほど… [pla]さん、はじめまして、私はリンnettです、えっと…"

    # say L678 lin
    old "I feel better now but still weak, I don't have enough energy yet."
    new "今は少し楽になったけど、まだ体力が足りなくて。エネルギーが不足してるわ。"

    # say L680 pla
    old "Do you think we should continue with the energy transfer?"
    new "君が元気を取り戻すためなら、エネルギーの移転を続けるべきだと思うけど、どう思う？"

    # say L682 lin
    old "Hmm, we definitely have to continue the energy transfer, everything you shared with me was just to get out of that girl's body."
    new "うーん、エネルギー転送は続けないとね。あなたが私に与えてくれたのは、あの娘の体から出るために必要な分だけだったから。"

    # say L683 pla
    old "Hmm ok, no problem, let's do it."
    new "うん、問題ないよ、やろう。"

    # say L684 lin
    old "Great! It's better if I suck you cock first, that will give me initial energy so that later you continue with the whole transfer."
    new "Great！ まずは私があなたのチ○ポを吸う方がいいわ、そうすれば初期エネルギーが得られて、後はあなたが全体の転送を続けることができるから。"

    # say L685 lin
    old "Are you fine with that?"
    new "大丈夫ですか？"

    # say L686 pla
    old "Yeah, I already told you I'm here to help and if I have to do that... I won't let you down."
    new "うん、既に言った通りだ、手伝うよ。もしやるなら……君を失望させない。"

    # say L690 lin
    old "That's the attitude we need... One more thing, could you please turn on the lights, I prefer to watch what I'm doing..."
    new "その態度が必要だね… あと一つ、照明をつけてくれる？私が何をしているか見たいから…"

    # say L691 pla
    old "Ehmm... Sure."
    new "エヘッ……わかった。"

    # say L704 pla
    old "So how are you now?"
    new "じゃあ、今どう？"

    # say L705 lin
    old "Totally fine... You really did excellent!"
    new "全然大丈夫… 本当に上手かったね！"

    # say L706 pla
    old "I'm glad you're fine now but... Are you gonna tell me what were you doing at the church? What was happening there?"
    new "君が元気で良かったけど… 教会で何してたんだ？ そこで何が起こってたんだ？"

    # say L707 lin
    old "Yes, sure! Well... Hmm."
    new "うん、もちろん！でも…… hmm。"

    # say L708 lin
    old "I was trying to do a small ritual to achieve a reception of energy, for this it was required to deliver a lot of energy and I thought that with me it would have been enough, but it wasn't."
    new "エネルギーの受容を達成するために小さな儀式を試みたの。そのためにはたくさんのエネルギーが必要で、私一人じゃ足りないと思ったんだけど、そうじゃなかった。"

    # say L710 lin
    old "I tried to condense the magic power but since I didn't have enough energy, I got weak and got trapped in the church and later, in Billie's body."
    new "魔力を凝縮しようとしたんだけど、エネルギーが足りなくて弱くなって、教会に閉じ込められちゃって、その後ビリーの体内に取り込まれてしまったの。"

    # say L711 lin
    old "We have to restore the power generator through a magic ritual and we only have one chance."
    new "魔力発生装置を魔法の儀式で復活させなきゃならないの。でもチャンスは一度きりよ。"

    # say L712 pla
    old "So we gotta find the way to do it, tell me what to do and I'll do it... Now it's my responsibility as well."
    new "じゃあ方法を見つけて、何をすればいいか教えてくれ、俺がやるよ… 今となっては俺の責任でもあるからな。"

    # say L714 lin
    old "Are you sure? Are you sure you wanna help? You'll have to do lots of things."
    new "本当に大丈夫？ 助けたいの？ たくさんのことをする羽目になるよ。"

    # say L715 pla
    old "Well, I've done some already and I'm willing to do more."
    new "まあ、すでにいくつかやってるし、もっとやる用意ができてるよ。"

    # say L716 lin
    old "Ok... Well, the church is a special point and has an unique vibration that allows us to collect more energy."
    new "Ok... でも、教会は特別な場所で、独特の振動があるから、もっとエネルギーを収集できるの。"

    # say L717 lin
    old "[pla], you gotta have sex with humans, so you will collect more energy and it should be done soon... We don't have much time."
    new "[pla]、人間とセックスしないとエネルギーをもっと集められないから……早くしないと時間がないわ。"

    # say L718 pla
    old "What? Why do I need to have sex with humans? I mean, I get that it's the way to transfer energy but... Why not with the shinigamis?"
    new "何？なぜ人間とセックスしないといけないんだ？エネルギーを移す方法はわかるけど……なぜ死神じゃ駄目なんだ？"

    # say L719 lin
    old "It's dangerous, the shinigamis could get trapped... And you already know it's not easy to get out of a human's body. It's too risky at this point."
    new "それは危険よ、死神たちが罠にはまっちゃうかもしれないし……それに、人間の体内から出るのは簡単じゃないって、あなたも知ってるでしょう。この段階ではリスクが高すぎるわ。"

    # say L720 lin
    old "And on the other hand, we need people with a great concentration of power. You gotta look for at least two people who have this. Otherwise..."
    new "それに、力が集中している人間が必要なんだ。少なくとも二人は見つけないと、さもないと…"

    # say L721 lin
    old "It won't work..."
    new "うまくいかないわ…"

    # say L722 pla
    old "Hmm... Ok, I get it..."
    new "うーん… 分かったってことだな。"

    # say L723 pla
    old "(Actually I could try it with... The nun and Mrs. Jones would be perfect for that.)"
    new "実際、試してみるなら… 姉さんとミス・ジョーンズがぴったりだな。"

    # say L724 lin
    old "Are you already thinking on someone?"
    new "もう誰かを考えているの？"

    # say L726 pla
    old "Yeah, I do know two women... But It won't be easy... Sister Grace and Mrs. Jones, are part of the church's community and they liked me."
    new "まあ、二人の女性は知ってるよ... でも簡単じゃないだろうな... シスター・グレースとミス・ジョーンズは教会のコミュニティの一部で、俺のこと好きだったみたいだ。"

    # say L727 pla
    old "I'm not sure but I could definitely try..."
    new "俺はまだ確信はないけど、試してみるよ…"

    # say L729 lin
    old "That's great! Do it... We have to try because it's our last chance, otherwise we'll have to wait until next year."
    new "それは素晴らしい！やってみて…これが私たちの最後のチャンスだから、そうしないと来年まで待つことになるわ。"

    # say L730 lin
    old "The energy that will emerge in the church will only increase in this period of the year, that's why it's so important."
    new "この時期になると教会で発生するエネルギーはさらに増えるから、それがとても重要なの。"

    # say L732 lin
    old "Now you know what we've to do... I'll get some rest and you should as well, you'll be very busy the next few days."
    new "それじゃ、私たちがやることも分かったでしょ… 私は少し休むから、あなたも休んだ方がいいわ。次の日は忙しくなるから。"

    # say L733 pla
    old "I can imagine... Ahh... I forgot to tell you, nice to meet you."
    new "想像できるよ…あっ…そういえば、君に会えて良かったって言いたかったんだ。"

    # say L734 lin
    old "After all we've done you say that... Haha, good night [pla]"
    new "今まで一緒にやってきたのにそんなこと言うの… ハハ、おやすみ [pla]"

    # say L735 pla
    old "Good night, Linett."
    new "おやすみ、リンnett。"

    # menu L759 
    old "Ritual"
    new "儀式"

    # say L761 lin
    old "[pla] how's it going? Are you ready for the ritual?"
    new "[pla] どうしてる？ 儀式的準備はできてる？"

    # say L762 pla
    old "I'm... I'm still preparing myself for it..."
    new "俺は…まだ準備中だよ…"

    # say L763 lin
    old "Great! If you need anything, just let me know..."
    new "Great！ If you need anything, just let me know... → 大丈夫！何か必要なことがあったら、言ってね..."

    # say L764 pla
    old "Thanks, I'll... Now I should go..."
    new "ありがとう、じゃあ… 行くとするか…"

    # say L765 lin
    old "Alright, see you!"
    new "じゃあ、またね！"

    # menu L767 
    old "Share your magic power"
    new "魔力を分かち合おうか"

    # say L769 lin
    old "Hey [pla], how are you?"
    new "Hey [pla]、元気？"

    # say L770 pla
    old "I'm totally fine, I was wondering if you need me to share some magic power with you?"
    new "全然大丈夫、君が魔法の力を欲しがってるんじゃないかと思ってた。"

    # say L771 lin
    old "You're such a kind man! Yes, I need some power... Please give it to me!"
    new "あなたって優しい人ね！うん、力が必要だよ…くれてくださいね。"

    # menu L780 
    old "Ask for magic power"
    new "魔法の力を分けてくれないかと頼む"

    # say L782 pla
    old "Hey, how are you?"
    new "Hey、どうしてる？"

    # say L783 lin
    old "Hey [pla], I'm fine... What can I do for you?"
    new "Hey [pla]、元気だよ… 何用？"

    # say L784 pla
    old "I need some magic power... Could you please share some with me?"
    new "魔力が必要なんだ… 少し分けてくれないか？"

    # say L785 lin
    old "I can always share my power with you..."
    new "いつでも私の力を分かち合えるわよ…"

    # say L806 lin
    old "It was good as usual, I'm feeling much more energetic now."
    new "いつもの通り良かったわ、今じゃもっと元気になった感じがするの。"

    # say L807 pla
    old "I'm glad I can always help!"
    new "俺もいつでも君の力になれるんで嬉しいよ！"

    # say L809 lin
    old "See you [pla]"
    new "またね [pla]"

    # say L820 pla
    old "Thanks Linett, that was very energizing!"
    new "ありがとう、リンnett。元気になったよ！"

    # say L821 lin
    old "It was... I'm here whenever you need me"
    new "それは…必要ならいつでもここにいるからね。"

    # say L822 pla
    old "Great! See you!"
    new "グレート！またな！"

    # say L836 lin
    old "Hey [pla]! Long time no see. How are you?"
    new "Hey [pla]！　久しぶりだね。元気にしてる？"

    # say L837 pla
    old "Woah! Linett! You scared me!"
    new "Woah！ リネット！びっくりしたよ！"

    # say L838 pla
    old "What are you doing here?"
    new "何してんだ、リンnett？"

    # say L839 lin
    old "I have to talk with you. It's important."
    new "話さなきゃならないの。大事なことだから。"

    # say L840 lin
    old "So, I was waiting here for you to wake up."
    new "だから、あなたが目覚めるのを待ってたの。"

    # say L842 pla
    old "Yeah well. That's a bit weird."
    new "まあ、ちょっと変だけどね。"

    # say L843 pla
    old "But anyway, what did you wanna tell me?"
    new "でもまあ、何を言いたいんだ？"

    # say L845 lin
    old "It's about the ritual we did in the church, do you remember?"
    new "教会でやった儀式のことよ、覚えてる？"

    # say L846 pla
    old "Yeah I do, what about it?"
    new "うん、覚えてる。それについて何だ？"

    # say L847 lin
    old "Well, it's been a while since we tried it, and I think we should give it another go."
    new "まあ、試してから随分経っちゃったし、またやってみようよ。"

    # say L848 lin
    old "After all, we still need those portals to generate magic again. And we're nearing the time of year to do it."
    new "でも、魔法を再び生成するためにはあのポータルが必要なのよ。それに、その時期が近づいてるの。"

    # say L850 pla
    old "But it didn't work last time, right?"
    new "でも前回はうまくいかなかったよね？"

    # say L851 lin
    old "It didn't."
    new "そう、うまくいかなかった。"

    # say L852 lin
    old "And to be honest. I don't really know why..."
    new "正直、私にも理由がよくわからないの..."

    # say L853 lin
    old "I've been thinking about it, but I can't come up with a full explanation."
    new "考えてはいるけど、ちゃんとした説明が思い浮かばないんだ。"

    # say L855 pla
    old "And you still want to try again? I mean... If we don't know what went wrong last time."
    new "また試してみようって思ってるのに、前回何がうまくいかなかったのかわかんないんだよ。"

    # say L856 pla
    old "How do we know this time it's going to work?"
    new "どうやって今度は上手くいくってわかるんだ？"

    # say L858 lin
    old "About that, I said I didn't know but I do have some ideas as to what could make it work this time."
    new "その点について、知らないって言ったけど、今回はうまくいく可能性のあるアイデアがいくつかあるの。"

    # say L859 lin
    old "An important part of what went wrong, is that we couldn't direct the magic power the way we needed it to go."
    new "大事なのは、魔法の力を必要な方向に導けなかったことだね。"

    # say L861 pla
    old "Direct? What do you mean?"
    new "何をどう制御するって？って意味？"

    # say L862 lin
    old "Well, as you can see when you use the agamoto's eye."
    new "まあ、アガモトの目を使えばわかるよね。"

    # say L863 lin
    old "Magic power is, in essence, a series of particles that human bodies are able to absorb."
    new "魔法は、本質的に人間の体が吸収できる一連の粒子だ。"

    # say L864 lin
    old "However, human bodies are not designed to use and direct these particles into a specific point."
    new "しかし、人間の体はこれらの粒子を特定の一点に集中させるように設計されていないのね。"

    # say L865 lin
    old "So we weren't able to condense the magic in the place we needed to."
    new "だから魔法を必要な場所に凝縮できなかったわけね。"

    # say L867 pla
    old "But we did in the church, you said that was where it had to be."
    new "でも教会ではできたって、君はそう言ってたよね。特定の場所じゃなくていいって。"

    # say L868 lin
    old "Yeah sure, but it couldn't be the whole church, it has to be a specific point where the breach can occur."
    new "そうだよ、でも教会全体じゃなくて、特定の一点で breach が起こせる場所でないとダメなの。"

    # say L869 pla
    old "Hmm, ok. So what do we have to do this time to make it happen?"
    new "うーん、わかった。じゃあ今回は何をすればいいんだ？"

    # say L871 lin
    old "To be honest, I'm not sure yet. I have to figure it out soon."
    new "正直、まだよくわからないんだけど、早く決めなきゃね。"

    # say L873 lin
    old "However, it is true that the magic power is running out."
    new "しかし、魔力が尽きつつあるのは事実だよ。"

    # say L874 lin
    old "That means we definitely have to do it again soon. And it has to be in the church."
    new "それって、近いうちにまた絶対にやらないといけないってことよね。それに教会でやらなきゃならないの。"

    # say L876 lin
    old "So, while I figure it all out, you talk to the church people again, so we have access to it."
    new "それなら、私が全部解決するまでの間、あなたはまた教会の人たちと話をして、教会を使えるようにしてね。"

    # say L877 pla
    old "Oh, damn, do we have to do it again with them?"
    new "おい、またあの連中とやらなきゃならないのか？"

    # say L878 lin
    old "Not necessarily... Let me solve this first."
    new "必ずしもそうじゃない…まずは私が解決するよ。"

    # say L879 lin
    old "For now just try and make sure we can use the church again when the moment comes, ok?"
    new "まずは教会を使えるようにしておくね？"

    # say L881 pla
    old "Sure, no problem, I'll handle it."
    new "わかった、問題ない、俺がやっておくよ。"

    # say L883 lin
    old "Fine, then I'll keep in touch in case we need something else."
    new "それなら、必要が出てきたら連絡を取りましょうね。"

    # say L902 gra
    old "Oh my! What a wonderful surprise! Hello [pla]!"
    new "あらまあ！なんて素敵なサプライズでしょう！こんにちは[pla]！"

    # say L903 pla
    old "Hello Sister Grace, nice seeing you again."
    new "こんにちはシスター・グレース、また会えて嬉しいです。"

    # say L904 gra
    old "And what do I owe this nice surprise?"
    new "そして、この素敵なサプライズは何のためでしょうか？"

    # say L905 pla
    old "I just wanted to say hello. And see if you need help with anything."
    new "ただ挨拶したかっただけだよ。それに何か手伝えることがないかと思ったんだ。"

    # say L906 pla
    old "You know, with decorating and stuff. I have some free time, so I figured I could help you."
    new "君の手伝いが必要だって知ってるよ。暇な時間もあるし、飾り付けの手伝いができるよ。"

    # say L908 gra
    old "Oh lord! You're sent again from the heavens, this is perfect."
    new "おっ！あなたがまた天から送られてきたなんて、これほどぴったりなタイミングはないわ。"

    # say L909 gra
    old "Just today we were going to start with the Christmas decorations. So you came at the right moment."
    new "今日からクリスマス飾りつけを始める予定だったんです。だからあなたが来たのはまさにタイミングがいいですね。"

    # say L910 pla
    old "Oh really? That's perfect, I can help with whatever you need."
    new "本当に？それならぴったりだ、必要なことなら手伝うよ。"

    # say L911 gra
    old "Come with me, I'll show you."
    new "私について来て、お見せします。"

    # say L918 jon
    old "[pla]! what a nice surprise!"
    new "[pla]！何て素敵なサプライズでしょう！"

    # say L919 pla
    old "Hi Mrs. Jones."
    new "こんにちは、ジョーンズ夫人。"

    # say L920 jon
    old "Hello darling, it's good to see you. And may I ask what brings you here?"
    new "こんにちは Darling、お会いできて嬉しいわ。そして、何の用事でいらしたのかな？"

    # say L921 pla
    old "I just came to see if I could help with the Christmas decorations."
    new "ただ見に来たんです、クリスマスの飾りつけ手伝えるかと思ったからです。"

    # say L922 jon
    old "Oh! Well, that's very nice of you. And you came just in time, we were about to start."
    new "あら、それはとても親切な Angebot ですね。そして、ちょうど良いタイミングで来てくれました。"

    # say L923 gra
    old "I was telling him just that, the Lord knew we needed his help and sent him to us."
    new "私はちょうどそう言っていたところです、神様が私たちに彼の助けが必要だと知って、彼を送ってくださったのです。"

    # say L924 jon
    old "Well darling, let's not waste time, come with us, we'll show you what we need."
    new "Darling、時間の無駄にしないで、私たちと一緒に来て、必要なことを見せてあげるわ。"

    # say L926 gra
    old "We need your help with putting up the decorations for Christmas."
    new "クリスマスの飾りつけのお手伝いをお願いします。"

    # say L927 jon
    old "The decorations have to be put on the benches and up in the ceiling."
    new "飾りつけはベンチと天井に付ける必要があります。"

    # say L928 jon
    old "It has to be ready before Christmas eve for the members of the congregation to enjoy."
    new "クリスマスイブまでに完成させておかないと、会衆の皆さんに楽しんでいただけませんから。"

    # say L929 pla
    old "Sure thing, no problem."
    new "了解、問題ないよ。"

    # narrator L936 
    old "Click all the marked spaces in time to decorate the church."
    new "指定された場所をクリックして教会を飾りましょう。"

    # say L952 pla
    old "Good morning Mrs. Jones, Sister Grace."
    new "おはようございます、ジョーンズさん、グレース姉さん。"

    # say L953 gra
    old "Hello [pla], what a blessing from the lord seeing you today."
    new "こんにちは[pla]、今日お会いできて本当に神様の恵みですね。"

    # say L954 jon
    old "Hello darling, how are you?"
    new "こんにちは Darling、元気ですか？"

    # say L955 pla
    old "I'm fine thank you, I came to help you with the decorations again."
    new "元気だよ、ありがとう。また飾りつけのお手伝いに来たんだ。"

    # say L956 gra
    old "Oh thank you so much, you're of such great help."
    new "あたし、本当に感謝しています。本当に助かっていますね。"

    # say L957 jon
    old "Sister Grace is right, it's nice that you came back today. Thank you darling."
    new "シスター・グレースが言う通りですね、今日また来てくれて嬉しいです。ありがとう Darling。"

    # say L958 pla
    old "It's no problem."
    new "全然問題ないね。"

    # say L959 pla
    old "I'll get to it then."
    new "じゃあ、取りかかるよ。"

    # say L978 jon
    old "Oh darling! You're such a good worker."
    new "Darling！あなたは本当に良い働き手ですね。"

    # say L979 gra
    old "I'm sure if you keep going at this pace you'll have it ready in no time."
    new "この調子で続けていれば、すぐに完成できるでしょう。"

    # say L981 jon
    old "Having you do all this work really helps us a lot."
    new "あなたがこんなに頑張ってくれて、本当に助かっていますね。"

    # say L982 gra
    old "I agree, the Lord graced us with this great help of yours."
    new "私もそう思います、あなたの素晴らしい援助は神様からの恵みですね。"

    # say L983 jon
    old "Now, I'm sure you have some other things to do. So we won't keep you here anymore."
    new "では、きっと他にも用事があるでしょう。なのでここでお別れにしましょう。"

    # say L984 jon
    old "But make sure to come back soon."
    new "でもまたすぐに戻ってきてくださいね。"

    # say L986 pla
    old "Sure, I'll be back soon and keep helping you."
    new "またすぐに戻ってくるし、手伝いも続けるよ。"

    # say L1023 jon
    old "Well... You didn't really do much today."
    new "まあ... 今日はあまり何もしなかったわね。"

    # say L1024 jon
    old "But it's ok, it's a delicate thing to do. I'm sure you'll get the hang of it soon."
    new "でも大丈夫ですよ、デリケートなことですからね。きっとすぐに上手になれると思います。"

    # say L1025 gra
    old "That's right, the lord will illuminate you and you'll get better at it. Don't worry."
    new "そうです、主があなたを照らしてくださいますから、上手くなっていくはずです。心配しないで。"

    # say L1026 pla
    old "Yeah... Sure."
    new "うん…そうか。"

    # say L1027 pla
    old "I have a couple of things to do, so I think I'll get going, but I'll come back again and keep working."
    new "俺にはちょっと用事があるから、先に帰るけど、また戻ってきて続けるよ。"

    # say L1028 jon
    old "We know you will, don't worry."
    new "心配しなくていいわ、あなたが戻ってくること我們知道你会回来的。中的日文部分有誤"

    # say L1042 lin
    old "Hey [pla]. I figured out what the problem was."
    new "Hey [pla]、問題の原因を突き止めたわ。"

    # say L1043 pla
    old "Huh? Problem? Good morning by the way."
    new "へ？問題？それに、おはよう。"

    # say L1044 lin
    old "Yeah, the problem we had with the ritual last time, I figured out what it was."
    new "あのね、前回の儀式で起きた問題の原因を突き止めたの。"

    # say L1045 pla
    old "Oh right, right. I remember."
    new "ああ、そうだったな。覚えてるよ。"

    # say L1046 pla
    old "So? What was it?"
    new "じゃあ？何だったんだ？"

    # say L1048 lin
    old "Well, I figured out that the problem last time, was that we did it with human bodies that couldn't retain as much magic power."
    new "あのね、前回の問題は人間の体が魔力を十分に保持できなかったことに気づいたの。"

    # say L1049 lin
    old "Well, two of them couldn't."
    new "まあ、二人はできなかったの。"

    # say L1050 pla
    old "What? What does that mean?"
    new "何？それどういう意味？"

    # say L1051 lin
    old "Unlike us, you humans get old as time passes."
    new "私たちとは違って、あなたたち人間は時間が経つにつれて老化するのよ。"

    # say L1052 lin
    old "This means that the older you get, the less magic power you're able to retain."
    new "これは、年を取るにつれて魔力が保てなくなるということよ。"

    # say L1053 lin
    old "I believe that's the mistake we made last time."
    new "前回はそれが間違いだったと思う。"

    # say L1054 lin
    old "So this time it has to be done with young people. They should be able to retain the amount of magic we need."
    new "だから今回は若い人たちでないと駄目だよ。必要な魔力を保てるはずだよ。"

    # say L1056 pla
    old "Three young girls... I mean, damn, that would be a bit difficult."
    new "三人の若い娘たちか……つまり、ちょっと難しそうだな。"

    # say L1057 pla
    old "Hmm... I suppose Billie would help again... and my only friends are Belle and Hinn..."
    new "うーん……ビリーはまた手伝ってくれるだろうな……でも友達はベールとヒンだけだしな……"

    # say L1058 pla
    old "What should I say? {i}\"Hey, do you want to be in an orgy at the church?\"{/i} "
    new "何て言えばいいんだ？ {i}「ねえ、教会でオルガジーに参加したい？」{/i}"

    # say L1059 lin
    old "Well, you should definetly find a way... And I'm also working on the ritual..."
    new "まあ、ちゃんと方法を見つけ出さないとね… 私も儀式の準備を進めているの。"

    # say L1060 lin
    old "Directing the magic power to a specific point isn't as easy as I thought."
    new "魔法力を特定のポイントに集中させるのは、思ったより難しかった。"

    # say L1061 lin
    old "I still have to run some more tests."
    new "まだいくつかのテストを実施しないといけないんだ。"

    # say L1062 lin
    old "So you have time to figure it out."
    new "じゃあ、時間かけて考えられるよね。"

    # say L1064 pla
    old "Ok, ok, I'll think about it."
    new "分かった、分かった、考えとくよ。"

    # say L1066 lin
    old "Ok, then keep working on the church, I'll contact you as soon as I know exactly what we need."
    new "じゃあ、教会のことは続けてね、決まったらすぐに連絡するから。"

    # say L1067 pla
    old "Ok, see you later then."
    new "じゃあ、またな。"

    # say L1084 pla
    old "Oh, hi [sis], how are you doing?"
    new "おっ、こんにちは [sis]、どうしてる？"

    # say L1092 pla
    old "Oh, hi [sis], what are you doing up so late?"
    new "お、おっ、[sis]、こんな時間に起きてるの？"

    # say L1094 linSis
    old "I did it [pla]! It worked!"
    new "やったよ[pla]！うまくいったんだ！"

    # say L1095 pla
    old "Huh? What do you mean it worked?"
    new "何がうまくいったんだ？"

    # say L1096 pla
    old "Did you sell something expensive online?"
    new "お前、何か高価な物をネットで売ったのか？"

    # say L1098 linSis
    old "No, no, no, it's me Linett. Listen, use agamoto's eye."
    new "いや、いや、いや、私リネットだよ。聞いて、アガモトの目を使って。"

    # say L1100 linSis
    old "Just do it, use the agamoto's eye."
    new "さっさとアガモトの目を使え。"

    # say L1107 pla
    old "Wow! But, what the fuck? You're Linett? But... Why do you look like my [sisrel]?"
    new "Wow！ でも、何だよ？ お前がリンnett？ でも…… なんで俺の[sisrel]の姿になってるんだ？"

    # say L1108 lin
    old "Yeah! Remember that I said I still had to test something? I managed to do again what I did with your friend last time!"
    new "うん！覚えてるでしょ、テストするって言ったよね？前に君の友達の体に入れたのと同じように、またできたの！"

    # say L1109 pla
    old "Wait what? What the fuck? You went into my [sisrel]'s body?"
    new "待て待て、何言ってんの？お前が俺の[sisrel]の体に入っちまったってことか？"

    # say L1110 lin
    old "Yes! Yes! I did it. I managed to get insider her!"
    new "はい！はい！できたの。彼女の体内に入れたの！"

    # say L1111 pla
    old "Woah! That's insane. But wait, come with me for a moment, we can't keep talking here."
    new "Woah！ それってすごいな。でも待って、ちょっとこっちに来い。ここで話すのは危険だ。"

    # say L1117 pla
    old "Now, what the fuck are you doing in [sis]'s body?"
    new "今、[sis]の体で何やってんだよ？"

    # say L1118 linSis
    old "Well, I figured out that doing this would be necessary for the ritual, so I decided to try to do it again."
    new "まあ、この儀式のために必要だって思ったから、またやってみることにしたのさ。"

    # say L1119 linSis
    old "To see if I could do it better this time."
    new "今回は上手くできるかどうか試してみたの。"

    # say L1120 pla
    old "What do you mean to do it better?"
    new "何が上手くやるって意味？"

    # say L1121 linSis
    old "Well, we don't usually get involved with humans."
    new "まあ、人間とは普段関わらないんだよね。"

    # say L1122 linSis
    old "So, doing something like getting inside a person is a bit weird."
    new "だから、人間の中に潜り込むのはちょっと変だよね。"

    # say L1123 linSis
    old "I did it last time because, I was looking trying to survive by taking your friend as my host."
    new "前回は、あなたの友達を宿主にして生き延びようとしたからよ。"

    # say L1124 linSis
    old "So, I was almost dead that time..."
    new "だから、その時は本当に危なかったんだよ…"

    # say L1125 pla
    old "Ok... But why did you do it again?"
    new "分かった… でも、今度は何でまたやったんだ？"

    # say L1127 linSis
    old "Well, I thought that if I did it at will, and at full strength, maybe it would be different."
    new "まあ、自分の意志で、全力でやってみれば、違う結果になるかもと思ったんだ。"

    # say L1128 linSis
    old "That I could do it with a lot more control."
    new "そうすればもっとコントロールできると思ったのさ。"

    # say L1129 linSis
    old "And it worked! See how well I can control her?! There's not even a little bit of interference."
    new "うまくいった！見て、これだけ上手くコントロールできるだろ！干渉もほとんどないしさ。"

    # say L1130 pla
    old "Yeah, yeah, congrats. But you have to get out of [sis]‘s body."
    new "うん、うん、おめでとう。でもさ、[sis]の体から出てくんないと。"

    # say L1131 pla
    old "And you have to do it now!"
    new "今すぐやるんだよ！"

    # say L1132 linSis
    old "Well, you see... We may have a little of a problem there."
    new "あのね… ちょっと問題が発生しちゃったかもしれない。"

    # say L1133 pla
    old "What do you mean a problem?"
    new "何が問題だって？"

    # say L1134 linSis
    old "Remember what you did last time to get me out of your friend's body?"
    new "覚えてる？お前の友達の体から出るために、前に何したか。"

    # say L1136 pla
    old "Hmm, not really...  Why?"
    new "Hmm、そんなに覚えてないな… 何でそんなことになるんだ？"

    # say L1137 linSis
    old "The thing is that to be able to get out of your [sisrel] ‘s body I'm going to need a recharge of magical power."
    new "問題は、あなたの [sisrel] の体から出るために魔力の充電が必要なことだね。"

    # say L1138 linSis
    old "That's the only way to undo my ‘possession'."
    new "その通り、憑依を解くにはこの方法しかないの。"

    # say L1139 pla
    old "Oh fuck, so I have to have sex with you in [sis] ‘s body?"
    new "おい、待てよ。[sis] の体で俺がお前とセックスしないといけないってのか？"

    # say L1140 linSis
    old "Yes, that's right. You got it. Come on, let's do it."
    new "そうだよ、その通りだ。さあ、やろう。"

    # say L1141 pla
    old "W- wait a minute. What about [sis]? Won't she know about it? Isn't she going to feel anything?"
    new "ちょっと待て。[sis] のことはどうなるんだ？彼女は気づかないのか？何も感じないのか？"

    # say L1142 linSis
    old "No, she won't feel or remember anything."
    new "大丈夫、何も感じたり覚えたりしないよ。"

    # say L1143 pla
    old "How do you know?"
    new "どうしてそう言えるんだ？"

    # say L1145 linSis
    old "Well, I did it with a different spell, one that grants me total control of this body."
    new "まあ、違う呪文を使ったんだ。この体を完全に操れるようにね。"

    # say L1146 linSis
    old "The host is unconscious. And she will be until I leave the body."
    new "ホストは無意識状態だよ。そして私がこの体から出るまで、彼女は目覚めない。"

    # say L1147 linSis
    old "Besides, this time I'm at full magic power, so I have no trouble controlling her completely."
    new "それに、今回は魔法力が満タンだから、彼女の身体を完全にコントロールするのは簡単よ。"

    # say L1148 pla
    old "I still don't get why you had to do this. I mean, what is all of this for?"
    new "まだ、なんでこんなことしなきゃならなかったのかさっぱりわからない。つまり、これって何のためにやってるんだ？"

    # say L1149 linSis
    old "This is for the ritual I mean, with all the control this method gives to me, I'll have no trouble directing the magic power."
    new "これで儀式ができるの、この方法なら魔力のコントロールも簡単だからね。"

    # say L1150 pla
    old "Ohhh... I get it."
    new "オォッ……分かった。"

    # say L1151 linSis
    old "Now, give me the magic power I need to get out of this body."
    new "それじゃ、この体から出るために必要な魔力をくれ。"

    # say L1165 pla
    old "Are you sure [sis] won't feel it?"
    new "[sis] が何か感じるかもしれないぞ。"

    # say L1166 pla
    old "What if she wakes up during it?"
    new "もし彼女がその間に目覚めたらどうするんだ？"

    # say L1167 linSis
    old "That's not possible, even after I get out, it's going to take a while before she wakes up."
    new "それは無理だよ、出てもまだしばらくは起きないだろう。"

    # say L1168 pla
    old "Hmmm, ok."
    new "うーん、そうか。"

    # say L1169 linSis
    old "Your cock is impressive, this size and thickness."
    new "あなたのちんこはすごいね、この大きさと太さ。"

    # say L1170 linSis
    old "No wonder you never have trouble supplying me with magic."
    new "そんなに大きいから、魔法の供給に困ることもないわね。"

    # say L1171 pla
    old "We have to do this quick. Someone could hear us."
    new "早くしないと誰かに聞かれるかもしれないからさ。"

    # say L1172 linSis
    old "Oh, relax, remember you have to cum for me to come out of you [sisrel]‘s body."
    new "ほら、リラックスして。出るためになら、[sisrel]の体から出てくればいいのさ。"

    # say L1173 linSis
    old "And you won't if you're not enjoying it."
    new "楽しんでなければ出られないわよ。"

    # say L1174 pla
    old "Ok, ok, I'll do it."
    new "分かった、分かった、やるよ。"

    # say L1184 lin
    old "I might do it again just to experience that."
    new "またやってみるかもしれない、その感覚を味わいたいから。"

    # say L1185 pla
    old "Haha, very funny."
    new "ははは、面白いね。"

    # say L1186 pla
    old "We should go to my bedroom."
    new "俺の寝室に行こう。"

    # say L1187 pla
    old "But first help me clean her and put her in bed."
    new "まずは彼女をきれいにして、ベッドに寝かそう。"

    # say L1188 pla
    old "She's not gonna wake up if we move her. Right?"
    new "彼女は動かしても目覚めないよ。そうだよね？"

    # say L1189 lin
    old "No, she's passed out."
    new "いいえ、彼女は気を失ってるの。"

    # say L1190 lin
    old "And won't wake up for a while, so it's ok."
    new "それからすぐには目覚めないから、大丈夫よ。"

    # say L1196 lin
    old "This is perfect, now we can finally do the whole ritual succesfully!"
    new "これで完璧だわ、ついに儀式を成功させられるね！"

    # say L1197 pla
    old "That's good and all, but that experiment was a little too much."
    new "それはいいけど、その実験はちょっとやりすぎだったな。"

    # say L1198 lin
    old "Well, it worked and that's all that matters."
    new "まあ、上手くいったからそれが一番重要よね。"

    # say L1199 lin
    old "What's most important right now is that there's another problem to solve."
    new "今一番大切なのは、別の問題を解決することよ。"

    # say L1200 pla
    old "What another one? What else do we need?"
    new "またか？他に何が不足してるんだ？"

    # say L1201 lin
    old "Well, we need the actual people."
    new "まあ、実際の人間が必要なんだ。"

    # say L1202 lin
    old "Remember, I did this experiment because we need to control the magic in humans?"
    new "覚えてるでしょ、この実験は人間の魔法を制御するために必要なことだから。"

    # say L1204 pla
    old "Oh, you're right, I forgot."
    new "あ、そうか、忘れてた。"

    # say L1205 lin
    old "The problem is that we need three people, and I can't get inside all three of them."
    new "問題は三人が必要なのに、私一人じゃ三人の体内に入れないことよ。"

    # say L1206 pla
    old "Oh, actually, I hadn't told you, but I know three other shinigamis."
    new "実はな、まだ君に言ってなかったけど、他の死神が三人いるんだ。"

    # say L1207 pla
    old "Maybe we could explain the situation to them, and ask for their help."
    new "じゃあ、状況を説明して協力を頼んでみようか。"

    # say L1208 lin
    old "Hmm... It could be, but I would need to train them to do it."
    new "うーん……それはできるかもしれないけど、彼らを訓練する必要があるな。"

    # say L1209 pla
    old "I think it will be fine if we talk to them."
    new "話せば大丈夫だよ。"

    # say L1210 lin
    old "Ok, so let's go, where are they?"
    new "じゃあ、行こう、どこにいるの？"

    # say L1212 pla
    old "Woah, you wanna go now?"
    new "Woah、今すぐ行くの？"

    # say L1213 pla
    old "Listen, it's pretty late and I haven't slept at all."
    new "ねぇ、もう夜遅いし、全然寝てないんだ。"

    # say L1214 pla
    old "What about if we go tomorrow morning?"
    new "明日の朝にしようか？"

    # say L1216 lin
    old "Hmm, ok, I'll come here tomorrow morning then."
    new "うん、わかった。明日の朝来るね。"

    # say L1217 pla
    old "Ok, see you tomorrow."
    new "じゃあ、明日ね。"

    # say L1233 lin
    old "Hey, are you ready to go talk with the other shinigamies?"
    new "hey、今から死神たちと話に行く準備できてる？"

    # say L1234 pla
    old "What? Now? I just woke up!"
    new "何？今？刚醒來！"

    # say L1235 lin
    old "What!? Remember I have to teach them how to do the spell. It's not as simple as when you use magic."
    new "何！？ 私が彼らに呪文の使い方を教えるのよ。あなたの使う魔法みたいに簡単じゃないわ。"

    # say L1236 lin
    old "It takes time to learn a spell, and we don't even know if they're going to say yes."
    new "呪文を覚えるのに時間がかかるし、彼らが本当にやるかどうかまだわからないんだよ。"

    # say L1237 lin
    old "So we have to go now!"
    new "じゃあ、今すぐ行かなきゃね。"

    # say L1238 pla
    old "Ok, ok, I get it."
    new "分かった、分かった、行こうぜ。"

    # say L1239 pla
    old "Let's go then."
    new "行こうぜ。"

    # say L1262 pla
    old "Hey girls."
    new "女の子たち、こんにちは。"

    # say L1263 mil
    old "Hello."
    new "こんにちは。"

    # say L1264 dev
    old "Oh! [pla] is here! Hiiii, it's been a while since I've seen you!"
    new "あら！[pla] が来たの！ ひー、久しぶりだね！"

    # say L1265 gom
    old "Hello, how have you been?"
    new "こんにちは、元気にしてた？"

    # say L1266 pla
    old "Fine, fine, thank you."
    new "いいよいいよ、ありがとう。"

    # say L1267 pla
    old "Hey, remember that a while ago, I told you about a shinigami that was inside one of my friends?"
    new "Hey、覚えてる？前に友達の中に死神がいるって話したよね。"

    # say L1268 pla
    old "And I asked you for advice about what to do?"
    new "そして、そのことについて君に相談したよね？"

    # say L1270 mil
    old "Indeed, we remember, what about it?"
    new "確かに覚えてるわ、それについて何なの？"

    # say L1271 pla
    old "Well, I wanted to introduce her to you, so I brought her with me."
    new "まあ、君に彼女を紹介したかったから、連れてきたんだ。"

    # say L1280 pla
    old "Everyone, this is Linett."
    new "みんな、これはリンnettだ。"

    # say L1281 lin
    old "Hello, nice meeting you."
    new "こんにちは、お会いできて嬉しいです。"

    # say L1284 gom
    old "Umm... eh, hi."
    new "うーん… こんにちは。"

    # say L1285 lin
    old "I understand your surprise, I didn't expect to see other shinigamis in this town."
    new "あなたの驚きは理解できる、私もこの町で他の死神に会うとは思っていなかった。"

    # say L1286 lin
    old "But I have to talk to you about something important."
    new "でも、大切なことを話さなきゃならないの。"

    # say L1287 pla
    old "I think you should listen to her, it's about the magic power."
    new "君が言うことを聞いとくべきだ、それは魔法の力についての話だからな。"

    # say L1290 mil
    old "The magic power? What about it?"
    new "魔法の力？それについて何のこと？"

    # say L1291 dev
    old "I don't know about you. But if [pla] says it's ok, I'll listen."
    new "あなたがどう思うかは知らないけど、[pla]が大丈夫って言うなら、私は聞くことにする。"

    # say L1292 gom
    old "Hmm, this could be important."
    new "うーん、これは重要なことかもしれないね。"

    # say L1293 lin
    old "Some time ago I discovered that in this town's church used to be a place with a strong connection with the magic world."
    new "少し前にこの町の教会が魔法の世界と強い結びつきがあった場所だと知ったの。"

    # say L1294 mil
    old "So? What does it matter now that the magic world doesn't exist?"
    new "だから？魔法の世界が存在しない今、それが何の意味があるの？"

    # say L1295 lin
    old "Well... That connection remains even if the magic world is gone."
    new "まあ…… 魔法の世界がなくなっても、そのつながりはまだ残ってるんだ。"

    # say L1296 dev
    old "Oh! Really?"
    new "ほんと？"

    # say L1297 gom
    old "And what does it mean?"
    new "それはどういう意味？"

    # say L1298 lin
    old "It means that is a perfect place to set a magic power generating point."
    new "それは魔法力を生成するポイントを設置するのに最適な場所って意味だよ。"

    # say L1299 gom
    old "Wow, really? That's amazing."
    new "本当に？ それはすごいね。"

    # say L1302 lin
    old "That's right, and me, along with [pla], did a ritual to trying to create that magic point."
    new "そうです、そして私と[pla]はその魔法のポイントを作るための儀式を試みたんだけど、"

    # say L1303 lin
    old "But it went wrong. However, I believe I've solved the issue and I would like to try again."
    new "でも失敗しちゃった。でも、問題を解決したと思うから、また試してみたいの。"

    # say L1305 pla
    old "Actually, that's why we came here today. We need your help with the ritual."
    new "実は、今日ここに来たのはそのためさ。儀式の手伝いが必要なんだ。"

    # say L1306 mil
    old "Our help? We don't even know you... or your intentions..."
    new "私たちの手伝い？　あなたたちのことさえ知らないのに……意図もわからないのに……"

    # say L1307 gom
    old "She's right, this is the first time any of us has heard anything like this."
    new "彼女は正しい、これって私たちにとって初めて聞くことだよ。"

    # say L1308 lin
    old "I know it sounds strange, this is actually new for me too."
    new "変な話だね、これも私にとっては初めてのことだよ。"

    # say L1309 lin
    old "But we need to try it because the magic power is running out."
    new "でも試さないと魔法の力が尽きちゃうから。"

    # say L1310 lin
    old "And if we don't do anything we're just going to die. I gain nothing by lying to you."
    new "何もしなければただ死ぬだけだよ。ウソをつくメリットなんてないから。"

    # say L1312 dev
    old "Ok and what do you propose we do?"
    new "じゃあ、君は私たちが何をすべきだと思うの？"

    # say L1313 lin
    old "For starters, we're going to need three young humans. [pla] will handle that."
    new "まずは、三人の若い人間が必要だよ。[pla] がそれに対応する。"

    # say L1314 lin
    old "The idea is that we use them in a ritual in which we will create a breach point, and pour magic into it to force it to open."
    new "そのアイデアは、彼らを使って儀式を行い、ブレイクポイントを作り、そこに魔力を注ぎ込んで強制的に開けさせるの。"

    # say L1316 gom
    old "I see, I get the idea."
    new "なるほど、わかったわ。"

    # say L1317 gom
    old "But I see some difficulties with the plan."
    new "でも、計画にはいくつかの難点があるな。"

    # say L1319 mil
    old "For starters, humans can't control magic. And even if they could, how would we make them do that?"
    new "まずは、人間は魔法をコントロールできないわ。もしそれができても、どうやってそれをさせればいいの？"

    # say L1321 lin
    old "Well, the idea is that we're going to get inside them, and control the magic from within."
    new "ええ、私たちが彼らの中から魔法を制御するってことなの。"

    # say L1325 dev
    old "What? We're going to be trapped!"
    new "何？私たちは閉じ込められちゃうの？"

    # say L1326 mil
    old "That's right, it's pretty weird to think doing that on purpose, is really dangerous."
    new "そうだね、わざとそんなことするなんて、考えただけでも危険だよ。"

    # say L1327 mil
    old "Isn't this just a trap to imprison us in human bodies?"
    new "これって、私たちを人間の体に閉じ込めるための罠じゃないの？"

    # say L1328 lin
    old "What!? What would I get from that?"
    new "何！？ そんなことして私に何の得があるの？"

    # say L1329 pla
    old "A- actually, we discovered that there is a way to do it safely."
    new "あ、 Actually、安全にできる方法を見つけたんだ。"

    # say L1330 lin
    old "Exactly, I've been running some tests, and found a way in which it can be done."
    new "確かに、テストを重ねて安全に行う方法を見つかったの。"

    # say L1331 lin
    old "I've created a spell with which we can get inside a human body and control it at will."
    new "私が作り出した呪文を使えば、人間の体内に入り込んで自由に操ることができます。"

    # say L1332 lin
    old "And we can do it without being on the verge of death."
    new "そして、死にかけているわけではないのにできるの。"

    # say L1333 gom
    old "I had never heard of something like that, are you sure about what you're saying?"
    new "そんなこと聞いたことがないけど、本当にそうなの？"

    # say L1334 pla
    old "She's telling the truth, I helped her."
    new "彼女の言うことは本当だ、俺が手伝ったんだ。"

    # say L1335 lin
    old "If you'll let me show, I can teach you how to do it."
    new "もし見せさせてくれれば、あなたにも教えてあげられるわ。"

    # say L1337 mil
    old "I can't believe you're actually considering listening to this!"
    new "本当になんて信じられない！これに耳を貸すなんてthinkableとして"

    # say L1338 dev
    old "I don't really trust you. But I do [pla], if he says it's ok maybe we should listen."
    new "私はあなたを信用していないわ。でも [pla]、もし彼がいいって言うなら、聞いてみるべきかもしれないわ。"

    # say L1339 gom
    old "Ok, we'll hear what you have to say, but if you don't convince us, we won't follow you."
    new "分かったわ、あなたの言うことを聞くけど、説得力がなければ従わないからね。"

    # say L1340 lin
    old "Ok, I know after listening you will understand."
    new "大丈夫、聞いてくれれば理解してくれると思うわ。"

    # say L1341 lin
    old "But wait, before I start. Don't have to keep working in the church? Let me this to me and you keep working on the church."
    new "でも待って、始める前に。教会で働き続ける必要はないの？私にこれをやらせてくれて、あなたたちは教会の仕事を続けて。"

    # say L1342 lin
    old "We are running out of time and need that place ready for the ritual."
    new "時間がないの、その場所を儀式のためにはやく準備しなきゃならないの。"

    # say L1344 pla
    old "Oh right."
    new "ああ、そうだ。"

    # say L1345 pla
    old "Ok, ok I'll keep working on the church, while you explain everything to them. See you later guys."
    new "分かった分かった、教会の準備を続けるよ、君がみんなに説明する間。後でな。"

    # say L1347 lin
    old "Great, we'll talk later at home."
    new "じゃあ、家で話すね。"

    # say L1348 dev
    old "See you [pla]!"
    new "またね、[pla]！"

    # say L1364 lin
    old "Hey there [pla]!"
    new "あ、こんにちは[pla]！"

    # say L1365 pla
    old "Oh, hey, did you manage to convince them?"
    new "お、嘿、説得はうまくいったか？"

    # say L1366 lin
    old "Yeah, I did, they didn't believe me at first."
    new "うん、できたよ。最初は信じてなかったけどね。"

    # say L1367 lin
    old "Especially that Mildret one. She was a lot of trouble."
    new "特にミルドレットは大変だったの。"

    # say L1368 lin
    old "But once I showed them the spell they understood."
    new "でも私が魔法を見せたら理解してくれたよ。"

    # say L1370 pla
    old "You showed them? But how did you get out of the host?"
    new "君が見せたの？でもホストからどうやって出られたんだ？"

    # say L1372 lin
    old "I didn't perform it. I only told them how it was done."
    new "私は実際にやらなかったの。ただ、どうするのか教えてあげただけ。"

    # say L1373 lin
    old "All shinigami know and understand magic, so they knew I was telling them the truth."
    new "全ての死神は魔法を知っているから、私が本当のことを言っているって分かってくれたの。"

    # say L1375 pla
    old "Oh, I see, nice."
    new "なるほど、良いね。"

    # say L1376 pla
    old "Everything's fine now, right? I mean, now you all know the spell."
    new "今なら大丈夫だろ？みんな呪文を知ってるし。"

    # say L1377 pla
    old "And I'm taking care of the church, so we're almost ready."
    new "教会のことは俺が手伝うから、もうほとんど準備万端だよ。"

    # say L1378 lin
    old "Hmm, not really. It sounds ok, but it's a very complicated spell. And I merely explained it to them...."
    new "うーん、そうでもないの。表面的には大丈夫そうだけど、結構複雑な呪文だから。それに私 merely 説明しただけだから……"

    # say L1379 lin
    old "If we want to make sure that everything goes perfect the day of the ritual, they're going to need practice."
    new "もし儀式の日にすべてが完璧にいくことを確実にしたいなら、練習が必要だよ。"

    # say L1381 pla
    old "Ok, so, what do you need me to do now?"
    new "じゃあ、今俺に何をすればいいんだ？"

    # say L1382 lin
    old "For now it would be really good if you can decide on the three humans we're using for the ritual."
    new "まずは儀式に使う三人の人間を決めてくれると助かるの。"

    # say L1383 lin
    old "You said you had some people in mind."
    new "あなたがすでに何人か思い浮かべてるって言ったわね。"

    # say L1385 pla
    old "Y- yeah I did. But I- I don't know..."
    new "うん、そうだった。でも、まだちょっと迷ってるんだ…"

    # say L1387 lin
    old "I already told you there's no need to worry."
    new "心配しなくていいって、もう说过よ。"

    # say L1388 lin
    old "Remember, they'll be unconscious during the ritual and after."
    new "覚えておきなさい、儀式中とその後は彼らは意識がないのだから。"

    # say L1389 lin
    old "And all the time we'll be controlling them."
    new "そして、その間ずっと彼らをコントロールしているわ。"

    # say L1390 lin
    old "So, you shouldn't be this worried."
    new "だから、そんなに心配しなくてもいいわよ。"

    # say L1391 pla
    old "Hmm ok, if that's how it is. Then, I guess I know who could work..."
    new "うーん、そうなのか。なら、誰が使えるかわかってきたな..."

    # say L1392 lin
    old "Great, then tomorrow morning we'll go see the shinigamis again and would be perfect to test the spell with one of them."
    new "じゃあ、明日の朝また死神たちに会いに行って、その中の誰かと呪文のテストをするのがベストだね。"

    # say L1393 lin
    old "So that they can practice before the ritual."
    new "そうすれば儀式の前に練習できるわ。"

    # say L1394 pla
    old "You mean with a human?"
    new "人間とテストするってこと？"

    # say L1396 lin
    old "Yes [pla], we have to test the spell before the ritual with the girls."
    new "はい [pla]、儀式の前に女の子たちで呪文を試さないと。"

    # say L1397 lin
    old "We need to be sure everything is going to work."
    new "ちゃんと機能することを確認しないとね。"

    # say L1398 pla
    old "Hmm... I guess you are right..."
    new "うーん… そうかもしれないな…"

    # say L1399 lin
    old "All right, everything is done, you better go to sleep because we have a lot to do tomorrow."
    new "大丈夫、全部準備完了したから、早く寝なさい。明日は忙しい日になるよ。"

    # say L1400 pla
    old "Ok, I'll see you tomorrow."
    new "分かった、明日な。"

    # say L1417 lin
    old "Hey [pla], are you ready to go?"
    new "Hey [pla]、準備OK？"

    # say L1418 pla
    old "Oh, good morning, yeah sure, let's go."
    new "おはよう、もちろん、行こうか。"

    # say L1433 pla
    old "Hey girls, good morning."
    new "Hey girls, good morning. → 女の子たち、おはよう。"

    # say L1434 mil
    old "Hello again."
    new "また会ったね。"

    # say L1435 gom
    old "Hi, how are you today?"
    new "こんにちは、今日も元気ですか？"

    # say L1436 dev
    old "Hiii, good seeing you again."
    new "ハイ、また会えて嬉しいわ。"

    # say L1437 lin
    old "Listen, [pla] and I talked last night about the humans that are taking part in the ritual."
    new "ねえ、[pla]と昨夜話したんだけど、儀式に参加する人間のことについてね。"

    # say L1438 lin
    old "And he's told me that he already has three people in mind for it."
    new "彼はすでに三人の候補者を決めてるって言ってたの。"

    # say L1439 lin
    old "So we'll go and find them for you to practice the spell before the ritual."
    new "じゃあ、その三人を連れてきて、儀式の前に呪文の練習をするんだ。"

    # say L1440 lin
    old "Just to make sure that you can handle the spell and control the host body."
    new "ただ確認のために、君が呪文を扱えてホストの体をコントロールできるかどうか練習するんだよ。"

    # say L1442 dev
    old "What? Now?... B- but I'm not ready... What if I can't get out?"
    new "何？今？…でも、まだ準備できていないよ…出られなかったらどうするの？"

    # say L1443 lin
    old "Don't worry Devonne, We may practice more with you."
    new "心配しなくていいよ、Devonne。もっと練習できるから。"

    # say L1444 lin
    old "Actually, I was thinking of starting with Gomory, I think she is ready."
    new "実は、ゴモリーから始めるつもりだったの。彼女はもう準備できてると思うから。"

    # say L1445 mil
    old "Ok, it sounds fine."
    new "うん、それならいいんじゃない？"

    # say L1446 gom
    old "Yeah, it would be good to try it now."
    new "うん、今試してみるのはいいね。"

    # say L1447 lin
    old "[pla], Gomory seemed to be the one that had a better grasp of the spell yesterday."
    new "ゴモリが昨日、魔法の理解が一番良かったみたいね、[pla]。"

    # say L1448 lin
    old "So you and her go find her host, while I keep working with Mildret and Devonne."
    new "あなたと彼女がホストのところに行きなさい、私はミルドレットとデボンヌと続けて作業するわ。"

    # say L1449 pla
    old "Ok, so what's the idea? What should we do?"
    new "分かった、じゃあ何をするんだ？何をすればいい？"

    # say L1450 lin
    old "You just have to take her to where her host is."
    new "彼女をホストのところまで連れて行けばいいの。"

    # say L1451 lin
    old "And see that everything goes well while she performs the spell."
    new "そして、彼女が呪文を唱える間、すべてがうまくいくように見守ってあげて。"

    # say L1452 lin
    old "As long as you're with her there shouldn't be a problem."
    new "あなたがついていけば問題ないでしょう。"

    # say L1453 pla
    old "Hmph, I see..."
    new "ふん、分かった…"

    # say L1454 pla
    old "Ok, I get it. Then let's go to where she is. Come with me Gomory."
    new "分かった、じゃあ彼女がいるところに行こう。ゴモリ、一緒に来てくれ。"

    # say L1463 gom
    old "Who is going to be my host?"
    new "誰が私のホストになるの？"

    # say L1464 pla
    old "She's a friend of mine, her name is Belle, I think we should try with her first."
    new "彼女は俺の友達で、名前はベルだ。まずは彼女と試してみよう。"

    # say L1478 pla
    old "Ok, we found her. What do you need to get in her body?"
    new "Ok、見つけたよ。彼女の体内に入るために何が必要なんだ？"

    # say L1479 gom
    old "Not much really, all we need is for her to be relaxed for a moment, and I'll canalize the spell."
    new "それほど多くは必要ないわ、彼女が一瞬リラックスすれば、私が呪文を導くだけよ。"

    # say L1480 pla
    old "Hmm, ok, so it should be fine if we're just talking, right?"
    new "うん、そうか、じゃあただ話してるだけでいいんだな。"

    # say L1481 gom
    old "That's right, it doesn't take more than a few seconds."
    new "そうよ、数秒あれば十分なの。"

    # say L1482 pla
    old "Ok, I think I got it. I'll go there and talk to her for a moment, you wait here for a minute."
    new "分かった、ちょっと行って話してくる。君はここで待ってな。"

    # say L1483 pla
    old "Then you come close. And the person that you see me talking to it's who you do the spell on, ok?"
    new "じゃあ君が近づいて。そして私が話してる相手に呪文をかけるんだよ、分かった？"

    # say L1485 gom
    old "That's very simple, sounds good, let's do it."
    new "それなら簡単だね、いいわ、やってみようか"

    # say L1486 pla
    old "Ok, I'll there then."
    new "分かった、じゃあ俺が行くよ。"

    # say L1502 bel
    old "Oh! [pla] Hi!"
    new "あ！[pla] こんにちは！"

    # say L1504 pla
    old "I'm ok. Hey listen, I wanted to talk to you about something Miss Mia said in class."
    new "大丈夫だよ。 Hey、聞いてくれ。ミア先生が授業で言ったことについて話したいんだ。"

    # say L1505 bel
    old "Sure, tell me. What is it?"
    new "もちろん、何でも言って。何の話？"

    # say L1515 rub
    old "HA! Who do we have here? Piglet and the loser."
    new "HA！ 誰がいるの？ ピギーと負け犬？"

    # say L1516 rub
    old "What happened to your ears Piglet? Afraid they were talking too much attention from that flat nose?"
    new "何したの、ポーキー？耳をあんなに大きくして、平べったい鼻から目をそらせようとしてるの？"

    # say L1517 bel
    old "Oh for God's sake!"
    new "Oh for God's sake！ → いい加減にしてくれよ！"

    # say L1518 bel
    old "Listen, dumbass, I'm not in the mood for your shit today! So fuck off!"
    new "聞いてよ、バカヤロウ、今日だけはあなたのクソ食らいたくないの！だからさっさと行け！"

    # say L1524 rub
    old "And what crawled up her that she's this angry?"
    new "何が彼女をこんなに怒らせたの？"

    # say L1526 rub
    old "Honestly, you can't say anything to people because they get their panties in a bunch."
    new "正直、人のこと言えないわよ、すぐに機嫌が悪くなっちゃうんだから。"

    # say L1527 pla
    old "What are you talking about? You just insulted her!"
    new "何言ってるの？君こそ剛に言ったことじゃないか。"

    # say L1528 pla
    old "Don't you ever get tired of talking like that to people?"
    new "君はいつまでそんな風に話すつもりなんだよ？"

    # say L1529 rub
    old "What, who do you think you're talking to?"
    new "何、誰にそんなこと言ってるの？"

    # say L1530 rub
    old "Listen loser, I don't care what you have to say, so why don't you get lost?"
    new "聞きなよ、負け犬、私が何を言うかなんて興味ないからさ、さっさと消えてくれればいいのに。"

    # say L1531 pla
    old "Yeah, whatever, who would want to deal with you?"
    new "そうだね、誰が君なんかと関わりたいと思うのか？"

    # say L1538 pla
    old "Oh no!"
    new "おい！待て！待て！止めろ！"

    # say L1539 rub
    old "Yeah! You shouldn't have messed with me you little brat!"
    new "そうだよ！ お前が私をいじめたのが間違いだったわ！"

    # say L1540 pla
    old "Wait! Wait! Stop!"
    new "待て！待て！やめろ！"

    # say L1541 rub
    old "Stop? After you insulted me? You better be ready for what you have coming your way!"
    new "止めるわけないでしょ？ あなたが私をからかったんだから、これから受けるべきことを覚悟しなさい！"

    # say L1542 pla
    old "No, no, no, no, it's not her, it's not her."
    new "いや、いや、いや、いや、それは彼女じゃない、違う。"

    # say L1543 rub
    old "W- What??"
    new "何？？"

    # say L1550 pla
    old "Ooh shit!"
    new "おお、くそ！"

    # say L1551 pla
    old "Damn, what do I do now? This wasn't supposed to happen!"
    new "くそ、どうすんだよ？　こんなことになるはずじゃなかったんだ！"

    # say L1553 gomRub
    old "Hey, I did it! It worked! Linett is a genius!"
    new "Hey、俺がやったぞ！うまくいった！リネットは天才だ！"

    # say L1554 pla
    old "Devonne? Is that you?"
    new "デボンヌ？君か？"

    # say L1555 gomRub
    old "It is! It worked! We did it [pla]!"
    new "そうだよ！うまくいったんだ！俺たちがやったぞ [pla]！"

    # say L1556 pla
    old "No, we didn't! You got the wrong person!"
    new "いや、違う！間違えた人だ！"

    # say L1557 pla
    old "It was supposed to be the other girl I was talking with!"
    new "他の女の子と話してたはずだよ！"

    # say L1558 gomRub
    old "Well, you should have said something, I did what you told me to."
    new "まあ、何か言ってくれればよかったのに、君の言葉通りにしたまでさ。"

    # say L1559 gomRub
    old "I waited for a minute and get into the person I saw you talking with."
    new "待ってたら、あなたが話してた人の体に入っちゃった。"

    # say L1561 pla
    old "Well, the point is you're in the wrong body. You're gonna have to get out of there."
    new "まあ、問題はお前が間違った体に入っちまったんだ。そこから出なきゃならないんだ。"

    # say L1562 gomRub
    old "Ok, but you know what's the only possible one way."
    new "分かってるけど、唯一の方法ってのはね。"

    # say L1563 pla
    old "Ohhh right... Oh my God... I have to do it with Ruby... Fuck!"
    new "ああそうか… よし、神様… ルビーとやらなきゃならないのか… クソ！"

    # say L1564 gomRub
    old "Well, it could be just a blowjob... it works too..."
    new "それならただのフェラでもいいけど… それでも効果的だよ…"

    # say L1565 pla
    old "I know, I know. Look, we can't do that here. So let's go somewhere else before anyone notices us speaking."
    new "知ってる、知ってる。ここじゃ無理だから、誰かに気づかれる前に別の場所に行こう。"

    # say L1574 oli
    old "Hey Ruby, so here this is where you've been. Hey listen, I've been thinking about our..."
    new "Hey Ruby、ここにいたのね。ねえ聞いて、私たちについて考えてたの…"

    # say L1576 oli
    old "And what do we have here? If it is the captain of the nerd club."
    new "何これ、オタク部の部長じゃないの。"

    # say L1577 oli
    old "What are you doing here nerd? Looking for better company than your loser friends"
    new "何してんの、オタク？負け組の友達より良い相手を探してるの？"

    # say L1579 pla
    old "Yeah, sure... That's right, I'm trying to become friends with Ruby. Right, Ruby?"
    new "そうだよ… そうさ、Rubyと友達になりたいと思ってるんだ。そうだろ、Ruby？"

    # say L1586 gomRub
    old "Ohh... Yeah, that's right, he and I are very good friends heh."
    new "オッ… そうだよ、俺たちは仲がいいんだよな、へへ。"

    # say L1587 pla
    old "(Oh my God...)"
    new "オーマイゴッド…"

    # say L1588 oli
    old "W- what? What are you saying ruby?"
    new "えっ、何言ってるのルビー？"

    # say L1589 oli
    old "Do you feel ok? Did this nerd do anything to you?"
    new "大丈夫？このオタクが何かしたの？"

    # say L1590 pla
    old "Hey, I haven't done anything."
    new "Hey、何もしてないぞ。"

    # say L1591 pla
    old "We're just talking about homework... S- she wants me to do her homework..."
    new "俺たちはただ宿題の話をしてるだけだ… あの、彼女は俺に宿題をやってほしいって…"

    # say L1592 oli
    old "Is that true Ruby?"
    new "それは本当なのか、ルビー？"

    # say L1594 gomRub
    old "Uhh, yes, yes! It's true, he's helping me with... Something."
    new "うん、そう！彼が手伝ってくれてるの…何かを。さあ行こう。"

    # say L1595 pla
    old "Anyway, I think we need to go look for some books. You know, for that homework... We better leave."
    new "まあ、宿題のために本を探しに行かないといけないな。さっさと行こう。"

    # say L1596 gomRub
    old "Yeah! I think we need to leave."
    new "そうだ！さっさと帰った方がいいね。"

    # say L1601 gomRub
    old "Goodbye human friend! It was good to talk to you, I'll see you later."
    new "さようなら、人間の友達！話せて楽しかった、またね。"

    # say L1622 pla
    old "Ok, I think we'll be safe here. It's almost class time, nobody's going to come."
    new "大丈夫、ここなら安全だよ。授業始まる時間だから、誰も来ないさ。"

    # say L1623 gomRub
    old "It's incredible, I have soo much control, I didn't know this was possible."
    new "信じられない、これほどコントロールできるなんて、知らなかったよ。"

    # say L1624 pla
    old "So, you're feeling ok?"
    new "じゃあ、具合はいいか？"

    # say L1625 gomRub
    old "That's right! I feel in complete control, it's almost as if this was my real body."
    new "そうだよ！完全にコントロールできてる感じがする、まるでこれが自分の本物の体みたいだ。"

    # say L1626 pla
    old "Ok, that's good. At least you didn't start twitching in the middle of the hallway, that would have given us up."
    new "そうだな、それは良かった。少なくとも廊下で突然ピクピクし始めるってわけじゃなかったから、バレずに済んだ。"

    # say L1627 pla
    old "Which, by the way, you almost did when Olivia got there. Thank God she's not very smart."
    new "それにしても、オリビアが来たとき、差点你开始抽搐了。谢天谢地她不太聪明。"

    # say L1628 gomRub
    old "Oh yes, who was that girl? She was friendly!"
    new "あの子誰？ 友好そうだったね！"

    # say L1629 pla
    old "Hmm, that's the last thing I would call her. She's the best friend of Ruby, the... Uhhh, owner of this body."
    new "うん、彼女をそう呼ぶのは最後の手段だな。ルビーの……うーん、この体の持ち主の親友さ。"

    # say L1631 gomRub
    old "So that could have been a lot closer..."
    new "そう言えば、もっと近くになれたのに…"

    # say L1632 pla
    old "Well, this is the problem with using the wrong body."
    new "この体を使ってる問題だな。"

    # say L1633 pla
    old "But anyway, can you leave that body before someone else notices how weird you're acting?"
    new "でもさ、誰かが君の変な行動に気づく前にその体から出られる？"

    # say L1635 gomRub
    old "I want to get out, but I'm going to need your help."
    new "出ていきたいんだけど、君の手が必要だ。"

    # say L1637 pla
    old "Yeah, right, I remember..."
    new "そうだな、覚えてるよ…"

    # say L1638 pla
    old "We need to do this quick."
    new "早くしないとダメだな。"

    # say L1647 gomRub
    old "Ok, I've been waiting for this since I took over this body"
    new "分かってる、この体を手に入れてからずっと待ってたよ"

    # say L1649 gomRub
    old "Well, I knew we had to do this for me to leave my host's body."
    new "まあ、これしないと俺の宿主の体から出られないってのは分かってたけどね。"

    # say L1650 gomRub
    old "And I've been wanting to taste this cock for a while."
    new "このチ○ポを味わいたかったんだ、ずいぶん長い間さ。"

    # say L1651 pla
    old "Uh... yeah, sure, remember we can't take much time."
    new "うーん……そうそう、時間が限られてるってこと。"

    # say L1652 gomRub
    old "I know, I know, this will be quick."
    new "分かってる、分かってる、すぐ終わらせるから。"

    # say L1662 pla
    old "Are you ok? Did everything work?"
    new "大丈夫？全部上手くいった？"

    # say L1663 gom
    old "Oh yeah, I'm perfect, and she didn't feel anything."
    new "ああ、うん、私は完璧よ。彼女は何も感じてないわ。"

    # say L1664 pla
    old "Oh shit! That's right, if we don't clean her up, she's gonna wake up and realize what happened."
    new "おい！そうだった、掃除しないと目覚めたら気づいちゃうぞ。"

    # say L1665 pla
    old "Come, help me clean her up, bring her to the toilet and get out of here."
    new "おい、手伝って掃除しよう。彼女をトイレに連れて行って、ここから出よう。"

    # say L1677 pla
    old "Ok, now let's go. We have to tell the others about how this went."
    new "分かった、じゃあ行こう。他のみんなにも何が起きたか伝える必要があるな。"

    # say L1695 rub
    old "Ugh, what happened?"
    new "うーん、何が起きたの？"

    # say L1696 rub
    old "I can't remember anything. Why am I in the school bathroom?"
    new "何も覚えてないの。なんで私が学校のトイレにいるの？"

    # say L1697 rub
    old "Ugh, did I fall asleep in the toilet?"
    new "うーん、トイレで寝ちゃったのかな？"

    # say L1698 rub
    old "And what is this taste in my mouth?"
    new "口の中のこの味は何？"

    # say L1699 rub
    old "It's like a salty smoothie. Ughh, disgusting."
    new "塩味のスムージーみたい。うっ、気持ち悪い。"

    # say L1700 rub
    old "And what is that smell? It smells like... dick?"
    new "何この臭い？ まるで…ちんこみたいな臭い？"

    # say L1701 rub
    old "I bet some loser was jerking off in the women's bathroom!"
    new "ああ、きっとどっかの負け组が女子トイレでオナニーしてたに决まってる！"

    # say L1702 rub
    old "Pathetic, I bet it was one of those losers that hangs out with Piglet."
    new "情けないわ、きっとピグレットの仲間の誰かだよ。"

    # say L1703 rub
    old "I'll give them a piece of my mind next time I see them."
    new "次に会ったら頭に来ちゃうわ。"

    # say L1737 lin
    old "Hey guys, how did it go?"
    new "ねぇ、みんな、どうだった？"

    # say L1738 pla
    old "Terrible! Gomory got in the wrong body, so we don't know if it's going to work with Belle."
    new "最悪だよ！ゴモリが間違った体に入っちまったから、ベールには効果があるかどうかわからないんだ。"

    # say L1739 lin
    old "What? What happened?"
    new "何？どうしたの？"

    # say L1740 gom
    old "There was a confusion when I was about to perform the spell, and I accidentally jumped in the wrong person."
    new "呪文を唱える直前に混乱して、間違った人の体内に入っちゃったの。"

    # say L1741 gom
    old "So I ended up controlling her instead."
    new "だから結局、彼女を操ることになっちゃったの。"

    # say L1742 dev
    old "But did it work? I mean controling that body?"
    new "でも本当にうまくいったの？つまりその体を操ることができたの？"

    # say L1743 gom
    old "It did! Perfectly! I had no trouble getting inside her. And once I did I had total control over her body."
    new "できたよ！完璧に！彼女の体内に入るのは簡単だったし、一度入ったら彼女の体を完全にコントロールできちゃった。"

    # say L1744 lin
    old "That's great! So we know you can do it too!"
    new "それは良かった！あなたもできることが分かったのね！"

    # say L1745 pla
    old "Yeah well, we almost got caught though."
    new "まあ、でもほぼ見つかるところだったな。"

    # say L1746 lin
    old "Oh, I think you're making too much fuzz."
    new "あたしはあなたが大袈裟にしてるんじゃない？"

    # say L1747 lin
    old "What's important is that it can be replicated."
    new "大事なのは再現可能かどうかよ。"

    # say L1748 pla
    old "Hmm I think so..."
    new "うーん、そうかもね…"

    # say L1749 lin
    old "Ok, we can say that was a success."
    new "じゃあ、成功だったって言えるわね。"

    # say L1750 lin
    old "All right, then, we should keep training the spell with Devonne and Mildret, so they get ready for her practice."
    new "それなら、デボンヌとミルドレットと一緒に魔法の練習を続けよう。そうすれば彼女たちも準備が整うだろう。"

    # say L1751 lin
    old "You can go and keep working on the church meanwhile [pla]."
    new "教会での作業を続けていてくれればいいの [pla]。"

    # say L1753 pla
    old "Alright, I'll keep working there."
    new "わかった、そこで頑張るよ。"

    # say L1754 lin
    old "Perfect, go do that, and I'll meet you whenever they are ready."
    new "じゃあ、その通りにやって。私は準備が整ったら会いに行くから。"

    # say L1756 pla
    old "Bye girls, good luck with the training."
    new "じゃあね、訓練がんばってな。"

    # say L1757 dev
    old "Thank you, see you later."
    new "ありがとう、また後でね。"

    # say L1773 lin
    old "Hey [pla], good morning. Ready for the next practice with the shinigamis?"
    new "Hey [pla]、おはよう。死神たちとの次の練習、準備できてる？"

    # say L1774 pla
    old "Hey Linet, yeah sure, I was thinking about what went wrong with Devonne."
    new "Hey Linet、うん、Devonneのことを考えてた。"

    # say L1775 pla
    old "This time I have an idea to ensure it's done with the right person."
    new "今回は正しい相手とやるためのアイデアがあるんだ。"

    # say L1776 lin
    old "Sure, whatever you need. Let's go."
    new "もちろん、何でも言って。行こう。"

    # say L1803 dev
    old "Hii."
    new "ひい。"

    # say L1804 gom
    old "Hi, good morning."
    new "おはよう。"

    # say L1805 lin
    old "Ok, given the advances she made yesterday, I think Gomory is the one that should go with you today."
    new "ゴモリが昨日のことを考えると、今日は彼女が一緒に行くべきだと思うわ。"

    # say L1806 lin
    old "I still have a couple of things to train with Mildret, but you two go ahead and practice."
    new "まだミルドレットと練習することがいくつかあるけど、あなたたちは先に練習に行って。"

    # say L1807 lin
    old "And this time please try and do it in the right body [pla]. We don't want to call attention to ourselves."
    new "今回はちゃんと正しい体でやってね [pla]。目立たないようにしたいから。"

    # say L1808 pla
    old "Yeah, sure, I'll be more careful."
    new "うん、気をつけよう。"

    # say L1809 pla
    old "Are you ready Devonne?"
    new "準備できてるか、デボンヌ？"

    # say L1810 dev
    old "I am."
    new "はい、準備できました。"

    # say L1811 pla
    old "Ok, then let's go."
    new "分かったなら、行こう。"

    # say L1826 pla
    old "Ok, so, are you sure you're clear on the process?"
    new "分かってるよ、じゃあプロセスは確実だな？"

    # say L1827 dev
    old "I am, I know it completely."
    new "全然分かってるよ。"

    # say L1828 pla
    old "Ok then, come on, let's find Billie."
    new "じゃあ、行こう、ビリーを探しに行こう。"

    # say L1842 pla
    old "Ok, we found her."
    new "分かった、見つけた。"

    # say L1843 pla
    old "Listen, to avoid confusion like what happened with Gomory."
    new "听着、为了避免像戈摩里那样的混乱。"

    # say L1844 pla
    old "I'll go and talk to her, and convince her to go with me to the classroom."
    new "俺が行って彼女と話して、教室に連れていくように説得するよ。"

    # say L1845 pla
    old "You wait here and when you see me going inside, you can go and get inside the body the girl who is with me at that moment."
    new "ここで待ってて、俺が入っていくのを見たら、その時一緒にいる女の子の体内に入ってくれ。"

    # say L1846 pla
    old "Is everything clear?"
    new "分かってるか？"

    # say L1847 dev
    old "Yes, don't worry, that's very simple actually."
    new "うん、心配しなくていい、実際簡単なことだよ。"

    # say L1848 pla
    old "Ok, glad to hear that, let's do it then."
    new "分かった、じゃあやろうぜ。"

    # say L1859 pla
    old "Hey Billie, how are you?"
    new "Hey Billie、元気？"

    # say L1860 bil
    old "Hey [pla], what's up?"
    new "Hey [pla]、何してんの？"

    # say L1861 pla
    old "Not much, I just wanted to ask you something."
    new "そんなにないけど、君に聞きたいことがあってね。"

    # say L1862 bil
    old "Oh yeah? What is it?"
    new "そうなの？何のこと？"

    # say L1873 mia
    old "Honestly, you're such a bad student already and you still take the luxury of skipping classes."
    new "正直、あなたはもう成績が悪いのに、授業をさぼる余裕まであるのね。"

    # say L1874 pla
    old "Uh, Miss Mia, I- I can explain..."
    new "ミア先生、あの、説明させてくださいけど…"

    # say L1876 mia
    old "I don't need you to explain anything!"
    new "説明する必要なんてありませんわ。"

    # say L1877 mia
    old "A bad student is a bad student. That's it, but not only do you skip classes."
    new "悪い生徒は悪い生徒です。それだけではなく、授業をさぼっているのですから。"

    # say L1878 mia
    old "You're also here being a bad influence for Billie."
    new "あなたはここでもビリーに悪影響を与えています。"

    # say L1879 mia
    old "I won't let you do that."
    new "そんなことさせません。"

    # say L1880 mia
    old "Come with me to the classroom!"
    new "教室に連れて行くから、一緒に来なさい！"

    # say L1881 pla
    old "W- Wha-?"
    new "わっ、何？"

    # say L1882 pla
    old "B- but, I'm talking with Billie."
    new "でも、ボリーと話してたんだよ。"

    # say L1885 pla
    old "I- it's important..."
    new "重要なんだよ…"

    # say L1886 mia
    old "Please, what could someone like you to tell her that's important."
    new "どうぞ、あなたのような人が彼女に話す重要なこととは一体何なのでしょうか。"

    # say L1887 mia
    old "Now, don't make me repeat myself again, GO TO THE CLASSROOM NOW!"
    new "今さら言わせてあげないわよ、今すぐ教室へ行きなさい！"

    # say L1894 bil
    old "Don't worry, we can talk later [pla]."
    new "心配しないで、後で話しましょう [pla]。"

    # say L1895 pla
    old "{alpha=0.8}{i}*Sigh*{/i}{/alpha} Oh fuck..."
    new "{alpha=0.8}{i}*ため息*{/i}{/alpha} くそっ…"

    # say L1914 mia
    old "Listen, I don't want you contaminating the minds of other students with your bad behaviour."
    new "聞きなさい、あなたの悪い態度で他の生徒たちの心を汚すのは望みません。"

    # say L1915 mia
    old "Especially someone that just arrived at the school like Miss Billie."
    new "特に新入生のビリーさんには影響を与えないようにしてください。"

    # say L1916 mia
    old "So you better stay away from here."
    new "だからあなたはここから離れた方がいいです。"

    # say L1923 pla
    old "No no no! Wait!"
    new "待って待って待って！"

    # say L1924 mia
    old "What did you just say to me?"
    new "何を言っているの？私に？"

    # say L1926 mia
    old "Does that mean you're going to ignore what I told you?"
    new "それって、私が言ったことを無視するってこと？"

    # say L1928 pla
    old "No! she is not the girl!"
    new "いや！彼女じゃないんだ！"

    # say L1929 mia
    old "DON'T THINK YOU CAN JUST DO WHAT YOU WANT!"
    new "そんな勝手なことさせてあげないわよ！"

    # say L1935 pla
    old "Oh fuck!"
    new "ああっ！"

    # say L1937 devMia
    old "Wow! That was a lot easier than I thought it would be!"
    new "Wow！思ったよりずっと簡単だった！"

    # say L1938 devMia
    old "The sensations... are so weird! I feel... Heavy."
    new "感覚……変だな！重い感じがする……。"

    # say L1939 devMia
    old "But not in a bad way. You know?"
    new "でも悪いわけじゃないよ。わかる？"

    # say L1942 pla
    old "Yeah ok, cool."
    new "うん、分かった。"

    # say L1943 pla
    old "But listen, this wasn't supposed to happen."
    new "でも聞いて、これは起こるはずじゃなかったんだ。"

    # say L1945 devMia
    old "It wasn't?"
    new "そうじゃないの？"

    # say L1946 pla
    old "No, not at all. This is not the person that's going to be your host for the ritual."
    new "いや、全然違う。この人には儀式のホストになってほしくない。"

    # say L1947 devMia
    old "Well, I did what you told me to. You're not very good at doing these plans you know?"
    new "君の言う通りにしたのに、君の計画は上手くいかないね。"

    # say L1949 pla
    old "God, why does this keep happening to me?!"
    new "神様、なんでまたこんなことになるんだよ！"

    # say L1950 pla
    old "Anyway, you have to get out of that body."
    new "とにかく、その体から出なきゃならないな。"

    # say L1951 devMia
    old "I'll do it gladly."
    new "喜んでやるよ。"

    # say L1952 devMia
    old "But, I would need your help..."
    new "でも、あなたの手助けが必要だよ..."

    # say L1953 pla
    old "Yeah, yeah I know..."
    new "分かってるよ…"

    # say L1959 devMia
    old "Linett said that receiving magic feels a lot different in a human body."
    new "リネットは、魔法を受け取る感じが人間の体では全然違うって言ってた。"

    # say L1960 devMia
    old "Let's see if it's true."
    new "確かめてみようか。"

    # say L1961 pla
    old "Sure, but we better be quick."
    new "そうだな、でも早めに済ませよう。"

    # say L1962 devMia
    old "Yeah, yeah."
    new "うん、うん。"

    # say L1963 devMia
    old "Doing it with a human body, so exciting!"
    new "人間の体でやるんだ、すごく興奮するな！"

    # say L1964 devMia
    old "And i bet it's even going to be better with that big cock of yours."
    new "それに、君の大きなちんこでやったら、もっと気持ちいいに違いない。"

    # say L1965 devMia
    old "Now... let's try this."
    new "それじゃあ……これで試してみよう。"

    # say L1980 pla
    old "Now let's get out of here."
    new "じゃあ、ここから出よう。"

    # say L1981 pla
    old "We need to report back to Linett and the others."
    new "リンnettと他のみんなに報告しないとね。"

    # say L1982 dev
    old "Sure, right behind you."
    new "はい、あなたの直後を追っています。"

    # say L1999 mia
    old "Why was I on the floor?"
    new "なぜ私が床にいたのかな？"

    # say L2000 mia
    old "All I can remember is that I was talking and everything went black."
    new "覚えているのは、話していたら急に暗闇に包まれたことだけ。"

    # say L2001 mia
    old "Ugh! Who was I talking with?"
    new "うっ！誰と話してたのかな？"

    # say L2032 lin
    old "Hey guys! How did it go?"
    new "Hey guys！ どうだったの？"

    # say L2033 lin
    old "Did you manage to do it right this time?"
    new "今度はうまくいったの？"

    # say L2034 pla
    old "Hmm, not exactly."
    new "うーん、そうでもないな。"

    # say L2035 lin
    old "What do you mean, the spell didn't work?"
    new "何がうまくいかなかったの？って、呪文が効かなかったの？"

    # say L2036 dev
    old "Oh, not that, it worked perfectly."
    new "ああ、そうじゃなくて、ちゃんと効いたのよ。"

    # say L2037 pla
    old "It's just that she didn't go into the right body."
    new "ただ、彼女が正しい体に入らなかったんだよ。"

    # say L2038 lin
    old "Oh, again? You know [pla] you should really work on your plans."
    new "またか？ [pla] ちゃんとした計画を立てないと駄目よ。"

    # say L2039 lin
    old "We don't want you to ruin it on the big day."
    new "大きな日に台無しじゃない？"

    # say L2040 pla
    old "Yeah, sure."
    new "うん、分かってる。"

    # say L2042 lin
    old "But other than that, how did it go? How did you feel?"
    new "でもそれ以外は、どうだった？感じはどうだった？"

    # say L2044 dev
    old "It was amazing! You had told me it worked, but this was unexpected."
    new "それは驚くほど良かったわ！あなたが効果があるって言ってくれたけど、これほどまでとは思わなかった。"

    # say L2045 dev
    old "Human bodies feel so different!"
    new "人間の体って、思っていたよりも全然違うの！"

    # say L2046 lin
    old "Well, if everything goes well, you'll have a chance soon."
    new "もしすべてがうまくいけば、君はすぐにまたチャンスがあるわ。"

    # say L2047 lin
    old "As for you [pla], I still have some things to work out with Mildret, why don't you keep working on the church?"
    new "あなたは [pla]、ミルドレットとのことはまだ解決してないから、教会の仕事は続けてくれない？"

    # say L2048 lin
    old "And I'll contact you when it's time for the next practice."
    new "時間になったら連絡するからね。"

    # say L2050 pla
    old "Sure, then I'll see you later."
    new "分かった、じゃあとりあえず。"

    # say L2066 lin
    old "Hey [pla], today's the last practice day. I hope you're ready."
    new "Hey [pla]、今日が最後の練習日だよ。準備できてるよね。"

    # say L2067 pla
    old "Good morning Linett; yeah sure, I'm ready to do this."
    new "朝だねリンnett、ああもちろん、準備はできてるよ。"

    # say L2068 lin
    old "Ok, let's go see the girls then..."
    new "じゃあ、女の子たちに会いに行こうか…"

    # say L2096 dev
    old "Hii, we're fine, how are you?"
    new "ハイ、私たちは大丈夫、お前はどう？"

    # say L2097 pla
    old "I'm ok, thanks."
    new "俺は大丈夫だ、ありがとう。"

    # say L2098 lin
    old "Today is the last practice day."
    new "今日が最後の練習の日だよ。"

    # say L2099 lin
    old "[pla] I've been working with Mildret on perfecting the spell, and she finally learned it."
    new "[pla] ミルドレットと魔法の完成に取り組んでいて、ついに覚えさせることができたの。"

    # say L2100 lin
    old "So take her with you to where her host is and try it."
    new "それじゃ、ミルドレットを連れて彼女のホストがいるところに行って、試してみて。"

    # say L2102 pla
    old "Sure, no problem, are you ready Mildret?"
    new "わかった、問題ない、ミルドレット、準備はできてるか？"

    # say L2104 lin
    old "Great, do ahead and let me know how everything goes."
    new "じゃあ、行ってみて、その後の結果を教えてね。"

    # say L2117 pla
    old "Ok, so the last two previous attempts have failed because of confusion and bad timing."
    new "じゃあ、前の二回は混乱とタイミングの悪さで失敗したんだ。"

    # say L2118 pla
    old "So this time, I brought a picture with me."
    new "じゃあ、今回は写真を持ってきたよ。"

    # say L2122 pla
    old "This is the person that you're gonna get inside."
    new "これは君が中に入らなきゃならない人だ。"

    # say L2123 pla
    old "Make sure you memorize her face, so this time won't happen as before."
    new "顔を覚えておけ、前みたいにはならないように。"

    # say L2128 mil
    old "Ok, I'll make sure to remember this face, where can we find her?"
    new "わかった、この顔を覚えておくから。彼女はどこにいるの？"

    # say L2129 pla
    old "She should be at her house, let's go."
    new "彼女は家にいるはずだ、行こう。"

    # say L2141 jad
    old "Oh, hello [pla]. It's been quite a while, how are you?"
    new "あら、こんにちは [pla]。随分と久しぶりね、元気にしてた？"

    # say L2142 pla
    old "I'm fine Mrs. Jade, thank you."
    new "俺は元気です、ジェイドさん、ありがとう。"

    # say L2143 jad
    old "Are you here looking for Hinn?"
    new "あなたはヒンを探しに来たの？"

    # say L2144 pla
    old "I am, I have to talk to her about our school project."
    new "はい、ヒンに学校のプロジェクトについて話さなきゃならないんだ。"

    # say L2145 jad
    old "Oh, but you see, she's not in at the moment."
    new "あ、でもね、彼女は今いないのよ。"

    # say L2146 jad
    old "I think she went out with your friend Belle."
    new "彼女はあなたの友達のベールと出かけたみたいよ。"

    # say L2147 jad
    old "If you want to, you can come back later when she arrives."
    new "もしよかったら、後でまた来てみてください。"

    # say L2148 pla
    old "I guess I'll have to..."
    new "また後で来るのが仕方ないな…"

    # say L2162 pla
    old "Nooo, not again! Damn it!"
    new "ダメだ、またか！くそ！"

    # say L2163 milJad
    old "It worked! I can't believe Linett was right."
    new "うまくいった！リネットが正しかったとは思えない。"

    # say L2164 pla
    old "Hmph, yeah fine, that's very good and all. But you're in the wrong body!"
    new "ふん、そうか。それは良いんだけど、でもお前は間違った体に入っちまったな！"

    # say L2165 milJad
    old "But I got in the body you told me to, I even had the picture and all."
    new "でも、君が指定した体に入れたよ、写真まで見ながらさ。"

    # say L2166 pla
    old "Well, that's not her. The body you got into it's her mother."
    new "まあ、それは彼女じゃないな。お前が入った体は彼女の母親だ。"

    # say L2167 milJad
    old "Well that's not my fault, they look identical!"
    new "それは私のせいじゃないよ、二人そっくりだもん！"

    # say L2168 milJad
    old "I mean, all you humans are very similar to begin with, how was I supposed to know which is which?"
    new "君たち人間って元から似てるんだよ、どっちがどっちか区別する方が無理だよ。"

    # say L2169 pla
    old "I can't believe this is happening again."
    new "またこんなことになるなんて、信じられないな。"

    # say L2170 pla
    old "Well anyway, let's get you out of that body quickly, I don't know when Hinn could come back home."
    new "まあ、とにかく早くその体から出よう。ヒンがいつ帰ってくるかわからないしな。"

    # say L2172 milJad
    old "Sure, we already tested that I can do the spell, and it works how intended, let's not delay this any longer."
    new "もちろん、その呪文もちゃんと試してみたし、これ以上待つのはやめようぜ。"

    # say L2177 pla
    old "Uhh, A- Are you ok?"
    new "うーん、大丈夫か？"

    # say L2178 pla
    old "You seem a little weird."
    new "お前、ちょっと変だな。"

    # say L2179 milJad
    old "Me? Weird? Don't be foolish."
    new "俺？変？バカ言わないで。"

    # say L2180 milJad
    old "We do this often, why would I be weird about receiving magic in a human body?"
    new "俺たち、これよくやってるしさ。人間の体で魔力を受けるのが変なわけないだろ？"

    # say L2182 pla
    old "Eh, well... I didn't say anything about that."
    new "ええ、まあ……何も言ってないけど。"

    # say L2183 pla
    old "But sure."
    new "でもまあ、そうかな。"

    # say L2184 milJad
    old "You're talking too much."
    new "話が多すぎだよ。"

    # say L2185 milJad
    old "Remember we can't waste any time on this."
    new "時間無駄にすんじゃねえぞ。覚えてろ。"

    # say L2186 milJad
    old "Or the daughter of this body could come back and see us."
    new "この体の娘が戻ってきて見つけるかもしれないよ。"

    # say L2187 pla
    old "You're right."
    new "そうだな。"

    # say L2200 pla
    old "Ok, we are done here, let's go."
    new "じゃあ、ここは終わりだな。行こう。"

    # say L2218 jad
    old "How did I fall asleep?"
    new "どうして寝ちゃったのかな。"

    # say L2219 jad
    old "I can't even remember what I was doing..."
    new "何してたのかさえ覚えてない…"

    # say L2220 jad
    old "All I remember is I was talking to someone and then nothing."
    new "覚えてるのは、誰かと話してて、その後何も覚えてないってだけ。"

    # say L2221 jad
    old "Who was I talking to?"
    new "誰と話してたのかな？"

    # say L2254 lin
    old "Well? How did it go? Did you manage to do it?"
    new "じゃあ？どうだったの？できたの？"

    # say L2255 pla
    old "You could say that..."
    new "まあ、そう言うこともできるけどね…"

    # say L2256 pla
    old "But... you see, something happened."
    new "でもね、実はちょっとしたことになっちゃってさ。"

    # say L2257 pla
    old "And Mildret ended up in the wrong body again."
    new "ミルドレットはまた間違った体に入っちまったんだ。"

    # say L2259 lin
    old "Amazing, you officially suck at this."
    new "すごいな、これに関して本当にダメなんだね。"

    # say L2260 pla
    old "Hey! Those were accidents, it wasn't my fault."
    new "Hey！あれは事故だ、俺のせいじゃないぞ。"

    # say L2262 lin
    old "It's ok, your ineptitude hasn't cost us anything."
    new "大丈夫よ、あなたの不器用さで何も失ってないわ。"

    # say L2263 lin
    old "But enough about you [pla]."
    new "でもあなたについての話はこれくらいにしておきましょう [pla]。"

    # say L2264 lin
    old "I want to know how you felt, Mildret. What did you think of the spell?"
    new "ミルドレット、その呪文をどう思った？感想を聞かせて。"

    # say L2265 lin
    old "Was it too difficult?"
    new "難しすぎた？"

    # say L2266 mil
    old "No, no, no, the opposite actually, it was very easy."
    new "いいえ、いいえ、全然逆で、とても簡単だったの。"

    # say L2267 mil
    old "I must say I'm amazed at how good your spell is. The connection to the body is complete."
    new "SPELLsが素晴らしいことに驚いているわ。体とのつながりは完全だわ。"

    # say L2269 dev
    old "Oh, it feels delicious, doesn't it?"
    new "オお、気持ちいいわね、そうでしょう？"

    # say L2270 mil
    old "Hmph, I wouldn't say that."
    new "ふん、そうは言えないわ。"

    # say L2271 mil
    old "But it is true that the sensory experience is... Interesting."
    new "でも、感覚的な体験は……興味深いってことは確かよ。"

    # say L2272 lin
    old "Well, what's important is that now all of you have gotten to test the spell and see that it works."
    new "大事なのは、みんなが呪文を試して効果があることを確認できたことだよ。"

    # say L2273 lin
    old "That will make things easier to handle the day of the ritual."
    new "それがあれば、儀式の日にスムーズに対応できるわ。"

    # say L2274 lin
    old "That makes me feel sure that there won't be any problem the day of the ritual."
    new "それなら、儀式の日には問題ないだろうって、自信が持てるわ。"

    # say L2275 lin
    old "But we're not done. Now that you know how to control bodies, we have to work on directing magic power."
    new "でもまだ終わっちゃいないの。からだを操る方法を知った今、次は魔力をどう使うかを練習しないとね。"

    # say L2276 pla
    old "Hey, does that mean that my work here is done?"
    new "おい、それって俺の仕事が終わったってことか？"

    # say L2277 lin
    old "It is, now we need you to focus on securing both the church and making sure the hosts are ready for the day of the ritual."
    new "それなら、教会の警備とホストたちが儀式の日に準備できているか確認するのよ。"

    # say L2278 lin
    old "Make sure everything's in place for that day."
    new "その日のためにすべてを整えてください。"

    # say L2279 pla
    old "Sure, no problem, I'll go then."
    new "わかった、問題ない、行こう。"

    # say L2302 jon
    old "Oh darling! I knew you'd do it."
    new "Darling！私はあなたがやると思っていたわ。"

    # say L2303 gra
    old "Just look at how beautiful the church looks! What a miracle!"
    new "教会の美しさを見てみて！本当に奇跡的ね。"

    # say L2304 pla
    old "Thank you, I'm glad you like it."
    new "ありがとう、君が気に入ってくれて嬉しいよ。"

    # say L2305 jon
    old "Oh darling, we don't like it, we love it!"
    new "Darling、私たちが好きじゃないのよ、愛してるのよ！"

    # say L2306 jon
    old "Who knows how much time it would've taken Sister Grace and I to finish it by ourselves."
    new "誰が知るでしょう、シスター・グレースと私が二人で完成させるのにどれほどの時間がかかったか。"

    # say L2307 gra
    old "That's right. You made it possible for this to be ready."
    new "そうですわ。あなたがいなければ、これほど早く完成することはできなかったわ。"

    # say L2308 jon
    old "Well darling, I'm sure you must be very busy."
    new "Darling、あなたはきっととても忙しいでしょうね。"

    # say L2309 jon
    old "And I'm sure you don't want to spend even one more hour of your time here."
    new "そして、あなたはここにさらに一時間も時間を費やすのは望んでいないでしょう。"

    # say L2311 pla
    old "Actually, I wanted to ask you something."
    new "実はね、君に聞きたいことがあるんだ。"

    # say L2313 gra
    old "What would you like to know?"
    new "何を知りたいのですか？"

    # say L2314 pla
    old "Well, the thing is that I'm doing this... Hmm, religious thing with a couple of my friends from school."
    new "実はね、学校の友達とやってるこの… 宗教的なことなんだけど。"

    # say L2315 pla
    old "And I would like to know if I can use the church one of these days to have a little ritual."
    new "そして、この先の何日かで教会を使ってちょっとした儀式ができるかどうか知りたいんだ。"

    # say L2317 jon
    old "Ritual?"
    new "儀式？"

    # say L2318 pla
    old "Nothing bad."
    new "大丈夫だよ。"

    # say L2319 pla
    old "Just something like what happened last time, you know, to bring them to the lord."
    new "前回みたいにさ、君を神様のもとへ導くためのものだよ。"

    # say L2321 gra
    old "Oh my god! That sounds wonderful!"
    new "ああっ！ それは素晴らしいですね！"

    # say L2322 jon
    old "I agree. It's so inspiring to see young people acting in such a way, looking for a connection with the lord. Simply great!"
    new "私もそう思います。若者がそんなふうに行動し、主とのつながりを求める姿はとても感動的です。素晴らしいですね。"

    # say L2323 gra
    old "Say [pla], could we participate? Just like last time? I would like you to bring me closer to heaven again!"
    new "SAY [pla]、参加させていただけますか？ 前回と同じように……また私を神様に近づけてくれませんか？"

    # say L2324 pla
    old "Uhh, I think not."
    new "うーん、多分無理そうだな。"

    # say L2325 pla
    old "You see, you've already been blessed, the idea is to bring in new people, to receive the blessing."
    new "君はすでに祝福を受けているから、新しい人を連れてきて祝福を受けるのが目的なんだ。"

    # say L2327 gra
    old "Oh, really? I must say that's a little disappointing."
    new "あら、そうなんですか？それはちょっと残念ですね。"

    # say L2329 jon
    old "No, no, sister, what [pla] says it's true."
    new "いいえ、いいえ、お姉さん、[pla]さんが言っていることが本当です。"

    # say L2330 jon
    old "We must allow for other people to receive such a special blessing and be brought over to the community."
    new "私たちは他の人々にもその特別な祝福を受け、コミュニティに迎え入れられるべきだと思います。"

    # say L2331 pla
    old "It's great that you understand."
    new "君が理解してくれて嬉しいな。"

    # say L2332 pla
    old "So, I think we'll need the church for some days, so that the ritual can be properly done."
    new "じゃあ、儀式をきちんと行うために、教会を数日間使う必要があると思うんだ。"

    # say L2333 pla
    old "I would love it if nobody came here, just so that we're not interrupted."
    new "誰も来ない方がいいな、そうすれば邪魔されなくて済むから。"

    # say L2335 jon
    old "Oh sure, no problem. We'll see to that, right Sister Grace?"
    new "もちろん、問題ありません。シスター・グレース、そうしましょうね。"

    # say L2336 gra
    old "There will be no issue."
    new "問題はありません。"

    # say L2337 gra
    old "We trust you completely, so we'll do as you ask us."
    new "私たちはあなたを完全に信頼していますので、あなたの求めることをしますね。"

    # say L2338 pla
    old "Thank you very much! You're of great help."
    new "ありがとうございます！君の助けが大きいよ。"

    # say L2339 jon
    old "Not at all darling, you're the one who is of great help, bringing people over to the community. What a good young man."
    new "全然ですよ Darling、あなたがコミュニティに人々を連れてきてくれたことが本当に助けになっています。立派な若い人ね。"

    # say L2340 gra
    old "It's true, you are a true blessing from the lord."
    new "それは本当ですね、あなたは神様からの恵みそのものです。"

    # say L2341 pla
    old "Thank you, very much for saying that."
    new "ありがとうございます、そんな風に言ってくれて。"

    # say L2342 pla
    old "I think I better get going then."
    new "じゃあ、そろそろ行こうかな。"

    # say L2343 jon
    old "Good night [pla], and thanks again for all your help."
    new "おやすみなさい [pla]、そして本当にありがとうございました。"

    # say L2344 gra
    old "Yes, thank you so much, God bless you."
    new "はい、本当にありがとうございました。神様がお守りください。"

    # say L2363 pla
    old "Oh, hi, what's up?"
    new "あ、こんにちは、どうした？"

    # say L2364 lin
    old "Nothing much, I just wanted to let you know that I talked to the girls."
    new "特に何もしてないの、 juste 女の子たちと話したことを伝えたくて。"

    # say L2365 lin
    old "And I'm very happy with the results of the training, they're now ready to do the ritual."
    new "そしてトレーニングの結果にとても満足してるの、今她们现在已经准备好进行仪式了。应该改为：今、儀式を行う準備ができてるの。"

    # say L2367 lin
    old "It is, that's why I wanted to ask you, how are things going with the church?"
    new "それが理由で、教会のほうはどうなってるか聞きたかったの。"

    # say L2368 pla
    old "It's great, I asked them to let me use it, and they said it was ok, so we're all set."
    new "良かったよ、教会に使わせてって頼んだらOKだって言ってくれたから準備万端だよ。"

    # say L2369 lin
    old "Fantastic, and how are things going with the three humans we need? Did you convince them already?"
    new "素晴らしい、でも三人の人間のことはどうなってる？もう説得できたの？"

    # say L2371 pla
    old "Uhh, not really, but I think I can convince them of it pretty soon."
    new "うーん、そうでもないけど、近いうちに説得できると思う。"

    # say L2372 lin
    old "Please do it and remember, they won't notice the ritual at all, so you don't need to worry."
    new "お願いだから、覚えておいて。儀式に気づくことは絶対にないから、心配しなくていいよ。"

    # say L2373 pla
    old "Ok, I'll keep that in mind. And will talk to them as soon as I can."
    new "分かった、頭に入れておくよ。できるだけ早く話すから。"

    # say L2375 lin
    old "I'll leave it in your hands then."
    new "じゃあ、あなたに任せるわね。"

    # say L2384 pla
    old "Hmm, the day for the ritual is coming. I better hurry up and talk to the girls soon."
    new "うん、儀式の日が近づいてるしな。女の子たちと早めに話さなきゃ。"

    # say L2400 bel
    old "Hi [pla]! It's good to see you."
    new "Hi [pla]！会えて嬉しいわ。"

    # say L2401 bel
    old "Hey, listen, I'm glad we can talk. I wanted to tell you something."
    new "ねぇ、聞いて。話ができて嬉しいの。伝えたいことがあったの。"

    # say L2402 pla
    old "Sure, is everything ok?"
    new "大丈夫、何かあったのか？"

    # say L2403 bel
    old "Yeah, yeah, everything's fine, it's nothing bad."
    new "うん、うん、大丈夫、悪いことじゃないの。"

    # say L2405 pla
    old "Oh, ok, what is it then?"
    new "お、そうか、じゃあ何なんだ？"

    # say L2407 bel
    old "Well, it's about what happened the other day with that dumbass bimbo."
    new "あの日、そのバカビッチとのことが気になってるの。"

    # say L2408 bel
    old "She made me angry and I took off and left you alone with her. So I wanted to say sorry."
    new "彼女が私を怒らせたから、一人で出て行っちゃって、あなたを彼女と二人きりにしてしまったの。だから謝りたいな。"

    # say L2410 pla
    old "That's all? Don't worry about it. I understand how irritating her comments can be."
    new "それだけ？気にするな。彼女の言葉がどれだけイラつくか、わかるよ。"

    # say L2411 bel
    old "They really are and she just makes me so mad."
    new "本当にそうよね、彼女は私をめちゃくちゃ怒らせちゃう。"

    # say L2412 bel
    old "I hope nothing bad happened with her when I left."
    new "私がいなくなった後、彼女に何か悪いことが起こらなかったか心配だよ。"

    # say L2413 pla
    old "Bad? Haha, no, of course not, what could happen between us? Nothing happened at all."
    new "悪いこと？ははは、もちろんないよ、俺たちの間に何が起こるっていうの？何も起こってないさ。"

    # say L2414 bel
    old "Hmm, Okay..."
    new "うーん、そうね..."

    # say L2415 pla
    old "Well anyway, leaving that aside, there's something that I wanted to talk to you about."
    new "まあ、それとは別に、君に話したいことがあったんだ。"

    # say L2419 pla
    old "Well, these past few days I've been helping decorate the church, for the holidays and stuff."
    new "まあ、最近の数日は教会の飾りつけを手伝ってたんだ。"

    # say L2420 pla
    old "And the church actually looks really cool."
    new "教会は実際にかなりカッコよく変身したんだ。"

    # say L2421 pla
    old "And it came to me that since we have some free time, why don't we have a little christmas celebration?"
    new "それで、ちょっと時間があるし、クリスマスのパーティーをしようと思いたったんだ。"

    # say L2422 pla
    old "I thought it could be really cool if we played truth or dare like last time."
    new "前回みたいにトゥルーオアダーチャレンジをやってみたら面白いと思ったんだ。"

    # say L2423 pla
    old "With me, Billie and Hinn by the way."
    new "俺、ビリーとヒンもいるよ。"

    # say L2424 pla
    old "Not Mike, I know he can be a little annoying."
    new "マイクは別だな、彼はちょっと面倒くさいからさ。"

    # say L2425 bel
    old "Hmm, that sounds like fun. And I do like that Mike won't be there..."
    new "そうね、それなら楽しそうだわ。それにマイクがいないのはちょっと嬉しいかな…"

    # say L2426 pla
    old "Oh, by the way, I think it would be cool if we dressed up for christmas."
    new "あ、そういえばクリスマスに仮装しようかって思ったけど。"

    # say L2428 bel
    old "That's actually nice."
    new "それは Actually 優しいな。"

    # say L2429 bel
    old "Sure, why not? Count me in."
    new "もちろん、いいわよ。私も参加するよ。"

    # say L2430 pla
    old "That's great Belle! So, how about we tomorrow night on the beach? Same spot as last time."
    new "ベル、それはいいね！じゃあ、明日の夜ビーチで会おう。前と同じ場所だよ。"

    # say L2431 pla
    old "And from there we can go to the church."
    new "そしてそこから教会に行こう。"

    # say L2451 pla
    old "Hey Billie, how are you doing?"
    new "Hey Billie、調子どう？"

    # say L2452 bil
    old "Hey dude, what's up?"
    new "hey Dude、どうしたの？"

    # say L2453 pla
    old "Hey, I wanted to talk to you about something."
    new "Hey、実は君に話したいことがあってさ。"

    # say L2454 bil
    old "Sure, is it the same thing you wanted to say to me when Miss Mia dragged you away the other day?"
    new "もちろん、前回ミア先生に引きずられて行かれたときの同じことかな？"

    # say L2455 pla
    old "Oh, yeah, actually it is. But thanks for reminding me that Miss Mia hates me."
    new "ああ、そうだった。でも、ミア先生が俺を嫌ってるって思い出させてくれてありがとう。"

    # say L2456 bil
    old "Hahahaha, dude, she really does. I don't know what you did to get on her bad side. But she has it in for you."
    new "ははは、そうね、彼女本当にそうよ。あなたが何をしたのか知らないけど、彼女はあなたのこと嫌ってるわ。"

    # say L2457 pla
    old "She does, she really does."
    new "そうだ、本当にそうだ。"

    # say L2458 pla
    old "But anyway, that's not what I wanted to say."
    new "でもまあ、それじゃなくて言いたかったことがあるんだ。"

    # say L2459 pla
    old "Listen, I've been thinking, and that game of truth or dare was actually pretty fun."
    new "俺も考えてたけど、その真偽ゲームって意外と楽しかったな。"

    # say L2460 pla
    old "So I thought that since we're gonna have some free time soon. Maybe we could go for another round."
    new "じゃあ、近々暇な時間ができそうなんで、またやってみない？"

    # say L2461 bil
    old "Oh, I wasn't expecting you to say that."
    new "あら、そんなこと言われるとは思わなかった。"

    # say L2462 bil
    old "I mean, sure, it could be fun, but I don't know."
    new "まあ、楽しくはあるんだけど、ちょっと迷ってるな。"

    # say L2463 bil
    old "Sounds a little boring now."
    new "ちょっと退屈そうね。"

    # say L2465 pla
    old "Oh, come on. Let's do it. Besides, I've been helping your grandma decorate the church."
    new "おい、来いよ。やってみようよ。それに、おばあちゃんの教会の飾りつけ手伝ったし。"

    # say L2467 bil
    old "Yeah, she mentioned it."
    new "うん、そう言ってたよ。"

    # say L2468 pla
    old "Yeah and it actually looks great, so it came to my mind that we could have a little celebration there."
    new "まあ、実際にすごくいい感じになってるから、そこでちょっとした祝いをしようと思ったんだ。"

    # say L2469 pla
    old "And we can even wear holiday outfits."
    new "そして休日用の衣装を着ることもできるんだよ。"

    # say L2471 bil
    old "When you say that we celebrate there."
    new "そこで祝うって言うとね。"

    # say L2472 bil
    old "I hope that doesn't means my grandma and the nun will be there. Right?"
    new "その言葉じゃ、婆さんと修女も来るのかと思ったの。そうじゃないわね？"

    # say L2473 pla
    old "No, not at all."
    new "いや、全然。"

    # say L2474 pla
    old "I talked to them and I got them to lend me the place for the night. So it will just be us."
    new "彼らと話して、夜だけ場所を貸してもらったんだ。だから俺たちだけだよ。"

    # say L2476 bil
    old "Even with that, it doesn't sound like the coolest thing."
    new "それでも、そんなにクールな感じじゃないな。"

    # say L2477 pla
    old "It will be cool. And you kind of owe for what happened last time."
    new "それはクールだ。それに、前回のことは君もまだ返してないだろう？"

    # say L2478 pla
    old "Remember whose idea it was that I climbed that roof?"
    new "覚えてるだろ、屋根に登るってアイデアを出したのは誰だ？"

    # say L2479 bil
    old "Ugh, dude, come on! Don't bring that up now, lame."
    new "うっせー、今さらそんなこと言わなきゃいいのに、ダサい。"

    # say L2481 bil
    old "But it's true, I do owe you. And what the hell, it could be fun."
    new "でも本当よ、あなたに借りがあるわ。それにさ、面白いかもね。"

    # say L2482 bil
    old "But no Mike, ok? He's annoying."
    new "でもマイクはダメよ、Ok？彼はうざいんだもん。"

    # say L2483 pla
    old "Thanks Billie! I'm sure we'll have a great time. Ok, so tomorrow night at the beach? We can go from there."
    new "ありがとう、ビリー！きっと楽しい夜になるよ。じゃあ、明日の夜にビーチで会うね？そこから先は決めていこう。"

    # say L2484 bil
    old "Yeah, whatever."
    new "うん、いい啦。"

    # say L2486 pla
    old "Alright, see you tomorrow then."
    new "じゃあ、明日見かけ。"

    # say L2513 hin
    old "[pla] Hi! How are you?"
    new "[pla] こんにちは！元気ですか？"

    # say L2515 hin
    old "I'm glad. My mother told me you came home the other day looking for me. I'm sorry we couldn't talk."
    new "うれしいな。母が言ってたけど、先日うちに来たとき会えなくてごめんなさい。"

    # say L2516 pla
    old "Don't worry, it happens."
    new "心配しなくていい、そんなこともあるさ。"

    # say L2517 hin
    old "Yeah, by the way, my mom wanted me to ask you if you remember anything strange happening."
    new "そういえば、ママが言ってたんだけど、何か変なこと覚えてる？"

    # say L2518 pla
    old "Strange? Heh, Me? N- no, no, why?"
    new "変なこと？へへ、俺？うーん、ない、ない、なんでそんなこと？"

    # say L2519 hin
    old "Well, she says that she remembers talking to you, but then she just woke up, apparently she fell asleep without knowing."
    new "まあ、お母さんによると、あなたと話した記憶があるんだけど、その後急に寝ちゃったみたいね。"

    # say L2520 hin
    old "So she wanted me to ask you if you know anything about that."
    new "だから彼女が私にあなたに聞いてほしいって言ったの。"

    # say L2521 pla
    old "Hmm, not really, after she told me you weren't there I just left."
    new "うーん、そう言われてもな、彼女が君がいなかったって言ってから、俺はただ帰っただけだよ。"

    # say L2522 pla
    old "Maybe she was tired and doesn't remember falling asleep."
    new "彼女は疲れてて、自分が寝たのを覚えてないのかもしれないね。"

    # say L2523 hin
    old "Yeah, that's what I told her."
    new "そう、それが私が彼女に言ったの。"

    # say L2524 hin
    old "But anyway, what did you want to talk to me about?"
    new "でも、何話したいの？"

    # say L2526 pla
    old "Oh right, I forgot."
    new "ああ、そういえば忘れてた。"

    # say L2527 pla
    old "Well, you see. I've been thinking that maybe we could get together with Billie and Belle."
    new "まあね、実はさ。ビリーとベールとまた一緒に集まろうと思ってさ。"

    # say L2528 pla
    old "And play another round of truth or dare with them. It was very fun last time and maybe it would be good to do it again."
    new "そしてまた真実か挑戦かをやろうと思って。前は楽しかったし、またやってみるのもいいかもしれないな。"

    # say L2529 pla
    old "Especially since we have some free time coming up."
    new "特にこれから空き時間が増えるし。"

    # say L2532 hin
    old "I don't know [pla]. I mean, it is fun. But you know how nervous I get in those kind situations."
    new "わからん [pla]。確かに楽しいんだけど、ああいう状況で緊張しちゃうのよね。"

    # say L2533 pla
    old "I know, I know. But that's in part why I propose it, I think it could be very helpful with your anxiety."
    new "知ってるよ、知ってる。でもそれが提案する理由の一つなんだ。君の不安を和らげる手助けになると思う。"

    # say L2534 pla
    old "I mean, you can practice a bit and of course stay with me and your friends in a safe place."
    new "まあ、ちょっと練習してみればいいし、もちろん安全な場所で君や友達と一緒にいられるだろ。"

    # say L2536 hin
    old "You know what? You might be right. And I think I could also use the experience to deal with my anxiety."
    new "あなたが正しいかもね。それに、この経験で私の不安と向き合う手伝いにもなると思う。"

    # say L2537 hin
    old "I- I'll do it."
    new "ううん、やってみるか。"

    # say L2539 pla
    old "That's cool Hinn. I'm sure we'll have a good time."
    new "ヒン、それはいいじゃん。きっと楽しい時間を過ごせるよ。"

    # say L2540 pla
    old "Oh, and I was thinking, maybe we could take the chance and dress up christmas themed, what do you think?."
    new "ヒン、あとさ、クリスマス themed で着飾るチャンスだと思わない？どう思う？"

    # say L2541 pla
    old "You know, because it's the holidays."
    new "知ってる、今がホリデイだからさ。"

    # say L2542 hin
    old "That sounds great! Count me in."
    new "それはいいね！私もやるよ。"

    # say L2543 pla
    old "I was thinking that we could meet at the beach tomorrow night."
    new "明日の夜、ビーチで会おうと思ってさ。"

    # say L2544 hin
    old "That sounds ok."
    new "それならいいかな。"

    # say L2545 pla
    old "See you later then."
    new "じゃあ、後でな。"

    # say L2546 hin
    old "Sure, goodbye."
    new "じゃあ、またね。"

    # say L2569 pla
    old "Hi, you were waiting for me?"
    new "嘿、君は俺を待ってたのか？"

    # say L2570 lin
    old "I was, I wanted to tell the other three shinigami are ready for the ritual."
    new "待ってたの、他の三人の死神が儀式の準備ができてるって伝えたかったの。"

    # say L2571 pla
    old "I already spoke with my friends, they all said yes."
    new "友達にはもう話した、みんなOKしてくれた。"

    # say L2572 lin
    old "That's perfect! Ok, so we're all set now."
    new "それなら完璧！みんな準備万端ね！"

    # say L2573 lin
    old "Get ready, we'll have a lot of work to do tomorrow. Be sure you get enough rest."
    new "準備して、明日はたくさんやることがあるからね。十分な休憩取ってるか確認して。"

    # say L2574 pla
    old "I'll make sure to get enough rest."
    new "心配しなくていい、十分休むから。"

    # say L2575 lin
    old "Ok then, I'll see you tomorrow."
    new "じゃあ、明日ね。"

    # say L2593 pla
    old "Hey Linett, good morning."
    new "Hey Linett、おはよう。"

    # say L2594 lin
    old "Are you ready for today?"
    new "今日の準備はできてる？"

    # say L2595 pla
    old "Yeah sure, I'm ready."
    new "よし、準備はできてるよ。"

    # say L2596 lin
    old "Ok then, so let's go talk to the others."
    new "じゃあ、他のみんなと話に行こう。"

    # say L2629 lin
    old "Good morning, I hope you're all ready for the ritual today."
    new "おはよう、今日の儀式の準備はできてるかな？"

    # say L2630 gom
    old "Hello, yes, we are. We've been practicing so we're confident it's going to go well."
    new "はい、準備できていますよ。練習も重ねたから、うまくいく自信があります。"

    # say L2631 mil
    old "Hello, I agree."
    new "はい、私もそう思います。"

    # say L2632 dev
    old "Sure, we feel like we won't have any issues. Good morning [pla]."
    new "もちろん、問題ないと思うわ。おはよう [pla]。"

    # say L2634 lin
    old "Ok, it's good to hear you're confident. So, before we leave for the church, we should go over the plan."
    new "そうだね、自信があるって聞いて安心した。それじゃ、教会に行く前に計画を確認しよう。"

    # say L2635 lin
    old "[pla] has been working to have the place ready for us to use. So that won't be an issue."
    new "[pla] が場所を準備してくれてるから、それには問題ないわ。"

    # say L2636 dev
    old "That's great."
    new "それは良いね。"

    # say L2637 lin
    old "It is. The idea is that we'll go to the church and wait there."
    new "そうよ。教会に行ってそこで待つことにするの。"

    # say L2638 lin
    old "In the meantime [pla] will meet with the people that will be our hosts somewhere else and bring them over."
    new "その間、[pla]は別の場所で私たちのホストとなる人たちと会って、連れてくる予定だよ。"

    # say L2639 lin
    old "When they get to the church they'll come and you'll get inside them."
    new "教会に着いたときに来てくれて、中に入らせてもらうわ。"

    # say L2640 gom
    old "How will we know who's getting inside who?"
    new "誰が誰に入ることになるのか、どうやってわかるの？"

    # say L2641 pla
    old "I was thinking about that, but honestly it doesn't really makes much of a difference."
    new "考えてはいたけど、正直そんなに差はないと思うよ。"

    # say L2642 lin
    old "It would if you had run the practice with your actual hosts. But since you didn't, you can just get inside anybody."
    new "実際にホストを使って練習していれば違いが出たかもしれないけど、あなたたちが使ってないから、誰の中に入ろうが自由よ。"

    # say L2644 mil
    old "Ok, It sounds fairly easy."
    new "そうね、わりと簡単そうね。"

    # say L2645 lin
    old "It will be, after you get them we can start the ritual."
    new "大丈夫よ、君が彼らを連れてくれば、儀式を始められるわ。"

    # say L2646 lin
    old "So while you channel magic power, I'll handle the union of all three sources into the breach point."
    new "魔法力をチャネリングしている間、私は三つの源を結びつけてブレイクポイントに統合するわ。"

    # say L2647 lin
    old "If everything goes well, we should be able to create a magic generator point."
    new "うまくいけば、魔法の発生点を作れるはずよ。"

    # say L2650 lin
    old "So, we better get to it. [pla] go ahead, and we'll meet back at the church."
    new "それじゃ、始めましょう。[pla] 先に行って、教会で合流するわ。"

    # say L2651 pla
    old "Ok, see you then."
    new "分かった、後でな。"

    # narrator L2654 
    old "Several hours later..."
    new "数時間後……"

    # say L2669 pla
    old "Hey girls! Wow... You look stunning!"
    new "HEY girls！ すげえ… みんなめっちゃきれいだな！"

    # say L2670 hin
    old "Y- You think so?"
    new "ええ、そう思っていいの？"

    # say L2671 pla
    old "I do. For starters, you look great as a reindeer."
    new "そうだよ。まずは、ヒン、トナカイの格好が本当に似合ってる。"

    # say L2672 pla
    old "And you Belle, that santa claus outfit really fits you. You look amazing."
    new "ベル、そのサンタクロースの衣装真的很 suits you、君は素晴らしい看起來。"

    # say L2673 pla
    old "And Billie, green really is your colour, I think it goes really well with your hair."
    new "ビリー、緑って本当に似合うな。髪の色ともよく合ってると思う。"

    # say L2674 bil
    old "Well and where is this coming from?"
    new "どこからそんなことを言うの？"

    # say L2675 bil
    old "It's odd to hear you being so flattering."
    new "そんなに褒められると、少し変な感じがするな。"

    # say L2677 bel
    old "But he's right, we look great. Hahaha."
    new "でも彼の言う通り、私たちカッコいいよね。ハハハ。"

    # say L2679 bil
    old "And what about you? What happended with your outfit?"
    new "あなたは？ 服装はどうしたの？"

    # say L2680 pla
    old "Oh crap! I completely forgot… I was a bit busy with all the preparations"
    new "ああ、しまった！完全に忘れてた… 準備に追われてさ。"

    # say L2682 bel
    old "That's not fair..."
    new "それはちょっと..."

    # say L2683 bil
    old "Yeah, yeah whatever..."
    new "うんうん、いい啦...じゃあ、始めようか！"

    # say L2684 bil
    old "Ok dude, let's start this!"
    new "じゃあ、始めようか！"

    # say L2697 bel
    old "Wow! [pla] look at this place! It's amazing!"
    new "おわ！ [pla] ここ見て！すごいわ！"

    # say L2698 hin
    old "They're right, it looks very beautiful [pla]."
    new "そうよ、本当に美しいわ [pla]。"

    # say L2699 pla
    old "Well thank you, I'm glad you girls like it."
    new "ありがとう、君たちが気に入ってくれて嬉しいよ。"

    # say L2700 bil
    old "Ok, we should start playing, don't we."
    new "じゃあ、遊び始めるべきよね。"

    # say L2719 pla
    old "Yeah, it's time! Let's start."
    new "よし、始めるぞ！"

    # say L2736 devBel
    old "Woah!"
    new "Woah！"

    # say L2737 milBil
    old "That sensation, it's so strong."
    new "その感覚、すごく強いな。"

    # say L2738 pla
    old "Did it work?"
    new "効果あったか？"

    # say L2740 gomHin
    old "It did, the spell went well."
    new "うまくいったよ、呪文は上手くかかった。"

    # say L2755 lin
    old "Great, that was very good."
    new "良かった、上手くいったね。"

    # say L2756 devBel
    old "Well, I wouldn't say it went that well. I mean, look at me! This body is so small."
    new "まあ、それほど上手くいったとは言えないな。見ろよ、この体！全然小さすぎるんだよ。"

    # say L2757 devBel
    old "I don't have any more curves! This isn't fair!"
    new "曲線が全然ないんだ！これって不公平だよ！"

    # say L2758 gomHin
    old "I actually gained size. This girl has way more curves than I do."
    new "俺はサイズが増えたけど、この子の曲線の多さにはかなわないな。"

    # say L2759 gomHin
    old "I think that the one that came up the better in that sense was Mildret."
    new "あの子の方がよくなったね、ミルドレットの方が。"

    # say L2760 gomHin
    old "Your host has some real curves, it's amazing!"
    new "ホストの子はほんと曲線美があるな、すごいよ。"

    # say L2761 milBil
    old "I suppose you could say that. She is really big."
    new "そう言うことだろうな。彼女は本当に大きい。"

    # say L2762 milBil
    old "I must say I'm surprised she can move around with these things. Specially since humans can't fly."
    new "正直、このサイズじゃ動けるのかって驚くよ。特に人間は飛べないんだからね。"

    # say L2763 gomHin
    old "They can't fly, but they have some sensory capabilities that are unique to them."
    new "飛べないけど、彼らには私たちにはない独特の感覚能力があるんだ。"

    # say L2764 gomHin
    old "They have access to sensations that we don't."
    new "彼らには私たちが経験できない感覚があるんだ。"

    # say L2765 devBel
    old "Oh, you don't have to tell me that. I've had it in my mind since before we made the spell."
    new "オーケー、それくらい前から頭の中にあるよ。呪文を作った前からだ。"

    # say L2766 lin
    old "I know what you mean, but please remember that's not the reason why we're doing this."
    new "分かってるけど、それが私たちがこれをする理由じゃないってこと覚えておいてよね。"

    # say L2767 gomHin
    old "I know, I know... But still, you can't deny that it's a very interesting experience."
    new "知ってる、知ってる… でも、それがとても興味深い体験だって否定できないよね。"

    # say L2768 gomHin
    old "I mean, even Mildret's waiting for it. Right?"
    new "つまり、ミルドレットも待ってるんだよ。そうだよね？"

    # say L2770 milBil
    old "Hmph, the only thing I'm waiting for is the magic we'll get once the ritual is over. Nothing else."
    new "ふん、私が待ってるのは儀式が終わった後の魔法だけよ。他には何もね。"

    # say L2772 devBel
    old "Ha! Yeah right. I know you enjoyed your practice the other day."
    new "ハ！そうか。あの日の練習を楽しんでたのは君じゃないの？"

    # say L2773 milBil
    old "Oh, shut up!"
    new "ふん、黙ってろ！"

    # say L2774 lin
    old "Enough of that, remember we're doing a ritual. And it's better if we begin."
    new "もうそれくらいにして、儀式のことを覚えてるでしょ。始めるのがいいわ。"

    # say L2775 lin
    old "[pla] are you ready?"
    new "[pla] 準備できてる？"

    # say L2776 pla
    old "I am, what do I have to do? How is the process?"
    new "俺は準備できてる、何をすればいいんだ？手順はどうなってる？"

    # say L2777 lin
    old "You just have to supply them with magic power so that they can  leave your friends bodies."
    new "あなたが FRIENDS の体から出られるように魔力を供給するだけよ。"

    # say L2778 lin
    old "The amount of magic that's actually needed to break the possession is really small."
    new "必要な魔力は実際にはそんなに少なくて済むの。"

    # say L2780 pla
    old "I'm not sure I follow."
    new "俺、まだよく分かんないけど。"

    # say L2781 gomHin
    old "What she means is that in the process of pushing us out of these bodies."
    new "彼女が言っているのは、私たちをこれらの体から追い出す過程で。"

    # say L2782 gomHin
    old "There's going to be an excess of magic that's being produced."
    new "生み出される魔法が余剰になるんだ。"

    # say L2784 lin
    old "And that extra magic is the one I'll take and divert to the point where I'll open a breach."
    new "その余分な魔力を私が取り、突破口を開く場所に導くわ。"

    # say L2785 lin
    old "That will transform into the magic generation point."
    new "それが魔法の生成点になるわ。"

    # say L2787 gomHin
    old "Well, if you do then we better not delay this any longer."
    new "じゃあ、それならもう待ってられないね。"

    # say L2788 lin
    old "She's right. We better get started."
    new "彼女は正しいわ。さっさと始めましょう。"

    # say L2790 devBel
    old "Yay!"
    new "やった！"

    # say L2796 shiBel
    old "Alright, now it's time to you to give us that big cock!"
    new "よし、今度は君にその大きなちんこを見せてもらうぞ！"

    # say L2797 shiHin
    old "My god, this cock of yours, I’ve always thought it’s very big for a human."
    new "神様、君のちんこ、人間としてずいぶん大きいと思ってたけど。"

    # say L2798 shiHin
    old "But seeing it with human eyes... It’s something else."
    new "でも人間の目で見ると…別物だね。"

    # say L2799 shiBel
    old "It’s true, I never thought I’d care about the size and girth."
    new "本当だ、サイズや太さなんて気にしたことはなかったけど。"

    # say L2800 shiBel
    old "But with this body..."
    new "でもこの体で…"

    # say L2801 shiBel
    old "And I never noticed it before, but it has an amazing smell too."
    new "それに今まで気づかなかったんだけど、凄くいい香りがするんだ。"

    # say L2802 shiBil
    old "I must admit that it is quite... Enticing."
    new "正直、かなり… 誘惑的だよ。"

    # say L2803 shiBel
    old "Mmm! I bet you can’t wait either [pla]."
    new "うん！君も待ちきれないだろうね [pla]。"

    # say L2805 shiHin
    old "Oh, don’t worry, we’ll make sure you enjoy the process."
    new "心配しなくていい、君が楽しむようにするから。"

    # say L2826 gom
    old "It really was, I could feel the magic flowing through me, incredible!"
    new "本当にそうだった、魔法が体の中を流れているのを感じて、信じられないくらいだった！"

    # say L2827 lin
    old "That's because there was a lot of magic in the room."
    new "その通り、部屋にはたくさんの魔力があったからね。"

    # say L2828 lin
    old "Enough to make the breach and create the portal."
    new "魔法が十分にあったから、結界を突破してゲートを作ることができたの。"

    # say L2829 mil
    old "Does that mean that it worked?"
    new "それって、成功したってこと？"

    # say L2830 lin
    old "Well, we did everything right. And I made sure to siphon the magic to where we needed it."
    new "私たちが全てを正しくやって、魔法を必要なところにうまく導いたわ。"

    # say L2831 lin
    old "But the portal takes some time to form."
    new "でも、ポータルが形成されるのに時間がかかるの。"

    # say L2832 lin
    old "So, we won't know for a while."
    new "だから、しばらくはわからないわ。"

    # say L2833 mil
    old "Then, there's a chance we may have failed."
    new "それなら、失敗した可能性もあるわね。"

    # say L2834 gom
    old "Well, if it did all we have to do is repeat the ritual."
    new "まあ、もし失敗したとしても儀式を繰り返せばいいだけさ。"

    # say L2835 dev
    old "That's not a problem, if anything happens it would be a good idea."
    new "それほど心配しなくてもいいわ、何か起こっても再度儀式をすれば良いんじゃないかしら。"

    # say L2836 lin
    old "I'm glad you're positive about it."
    new "あなたが前向きなのは嬉しいね。"

    # say L2837 lin
    old "For now let's just wait and see."
    new "今は様子見ましょう。"

    # say L2838 pla
    old "Girls, I'm sorry to interrupt, but maybe you could help me clean up my friends."
    new "女の子たち、すみませんけど、友達を片付ける手伝ってくれないかね。"

    # say L2839 pla
    old "We have to make it look as if they were sleeping."
    new "俺たちが寝ているように見せなきゃならないんだ。"

    # say L2841 dev
    old "Sure, let's do that."
    new "もちろん、そうするね。"

    # say L2858 mil
    old "Done, now your friends are clean."
    new "はい、今あなたの友達はきれいになったわ。"

    # say L2859 pla
    old "Thank you for your help girls."
    new "ありがとう、助かったよ、みんな。"

    # say L2860 lin
    old "Listen, [pla] since the ritual is done, we have nothing else to do here tonight."
    new "[pla]、儀式が終わったから、今夜ここにいる理由はないわ。"

    # say L2861 lin
    old "We'll leave and pay attention to see if we feel any changes in the magic concentration in the air."
    new "私たちが帰って、空気中の魔法の濃度に変化を感じるかどうか注意深く見守るわ。"

    # say L2862 lin
    old "You make sure there's no problem here."
    new "ここに問題がないかどうか確認してね。"

    # say L2863 pla
    old "Alright, I'm gonna wait for my friends to wake up."
    new "よし、友達が目覚めるのを待つぞ。"

    # say L2864 lin
    old "Hmm, given all the power that went through them, they won't wake up until the morning."
    new "うーん、あの電撃の量じゃ、朝まで起きないだろうな。"

    # say L2865 pla
    old "Ohh man... Really?"
    new "オーマン… ほんと？"

    # say L2866 lin
    old "Yeap, I guess so."
    new "うん、そうかもね。"

    # say L2867 pla
    old "Well, I have no option... Otherwise, it would be really weird for them to wake up without me around."
    new "WELL、選択肢がないよ... さもないと、俺がいないまま起きたら、めちゃくちゃ変だろ。"

    # say L2868 mil
    old "Yeah, you are right."
    new "うん、そうね。"

    # say L2869 lin
    old "Alright, that's all, it's time for us to leave. Let's go."
    new "それじゃあ、これで終わりね、そろそろ帰ろうか。行こう。"

    # say L2871 mil
    old "Thanks for... Everything."
    new "ありがとう、すべてのことについて。"

    # say L2872 gom
    old "Good bye [pla]."
    new "さようなら [pla]。"

    # say L3005 bel
    old "[pla]? What happened?"
    new "[pla]？何があったの？"

    # say L3006 hin
    old "I can't remember anything."
    new "何も覚えてないの。"

    # say L3007 bil
    old "What the hell? We fell asleep?"
    new "何てことよ？ 寝ちゃったの？"

    # say L3008 pla
    old "I think we just fell asleep after playing."
    new "俺もただ遊び終わって寝ちゃったみたいだな。"

    # say L3009 pla
    old "I also just woke up."
    new "俺もさっき起きたところだ。"

    # say L3010 bil
    old "We just fell asleep?"
    new "えっ、寝ちゃったの？"

    # say L3012 pla
    old "Uhh yeah, you know, it was pretty late."
    new "うん、結構遅かったな。"

    # say L3013 bel
    old "Hmm, I guess that makes sense. "
    new "うーん、そうかもね。"

    # say L3014 pla
    old "Hey, I think it's better if we just go home, it's already morning, and someone may come."
    new "Hey、もう朝だし誰か来るかもしんないから、家に帰ろうぜ。"

    # say L3016 hin
    old "You're right, we shouldn't worry our parents."
    new "ううん、親を心配させるのはよくないね。"

    # say L3017 bel
    old "That's true, see you later then."
    new "そうね、じゃあまたね。"

    # say L3019 bil
    old "I still don't get why I can't remember anything, but anyway, I guess I'll go home, later."
    new "まだ思い出せないのはわからないけど、まあ、家に帰るわ、またね。"

    # say L3020 hin
    old "I think I'll also be on my way, bye [pla]."
    new "私も帰るわ、バイバイ [pla]。"

    # say L3021 pla
    old "Bye girls."
    new "さよなら、みんな。"

    # say L3027 lin
    old "Oh, you're finnally here."
    new "あ、ようやく来たのね。"

    # say L3029 lin
    old "Good morning, I'm glad you are fine. I just wanted to thank you for everything you did."
    new "おはよう、元気で何よりだわ。あなたがしてくれたこと、本当に感謝してるの。"

    # say L3030 pla
    old "Oh, you don't have to thank me, I'm a Sexnote owner, that's my mission."
    new "お前が感謝する必要はないよ、俺はセックスノートのオーナーだから、それが俺の使命だ。"

    # say L3031 lin
    old "That's right, however you have done a lot you didn't have to."
    new "そうだよ、でもあなたはしなくてもいいことをたくさんしてくれた。"

    # say L3032 lin
    old "And everything was for us, to save and protect us."
    new "すべては私たちのために、私たちを守るためにだったの。"

    # say L3034 lin
    old "All right. Now we just have to wait to see if everything worked..."
    new "今からただすべてがうまくいったかどうか待つだけよ…"

    # say L3035 pla
    old "How much would it takes?"
    new "どれくらいかかるのかな？"

    # say L3036 lin
    old "To be honest I don't know... It's the first time someone tries to create a magic generation point."
    new "正直、わからないの... これは初めての魔法の生成ポイントを作ろうとする試みだから。"

    # say L3037 lin
    old "It could take, hours, days, weeks or months, the only thing we can do now is wait.."
    new "時間はかかるかもしれないわ… 数時間、数日、数週間、あるいは数ヶ月かかるかもしれない。今はただ待つしかないの。"

    # say L3039 pla
    old "Oh, man... I was expecting a faster result."
    new "オイ…もっと早く結果が出ると思ってたんだよ。"

    # say L3040 lin
    old "Actually, I'm pretty sure, that is everthing worked, we could notice a change in the whole area, and it won't take long for sure."
    new "実際、うまくいけばこの地域全体で変化がすぐ分かるわ。絶対にそうなるよ。"

    # say L3042 lin
    old "Yeah, don't worry, this time we did it right. And all of this thanks to you."
    new "大丈夫、今度はちゃんとやれたよ。これ全部あなたの力のおかげだよ。"

    # say L3043 pla
    old "I'm glad to had helped."
    new "助けてできて良かった。"

    # say L3044 lin
    old "All right, I think you should rest. I can see you pretty tired."
    new "大丈夫、休んだ方がいいわ。疲れてるのがわかるから。"

    # say L3045 pla
    old "You're right, I did slept well last night... Thank you and see you later."
    new "君が言う通りだ、昨夜はよく寝られたな… ありがとう、またね。"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/linAnimations.rpy
translate japanese strings:

    # say L6 lin
    old "You're definitely very good at this, I can start to feel much more energy inside of me..."
    new "あなたは本当に上手だね、中からエネルギーが溢れ出しそう..."

    # say L7 pla
    old "Hmm... T- Thanks."
    new "うーん… ありがとう、リン…"

    # say L11 lin
    old "Does it feels good, Huhh?"
    new "感じてるでしょ、ねぇ？"

    # say L12 pla
    old "Y- yes... It feels great..."
    new "Ｙ－ うん… 本当に気持ちいい…"

    # say L16 lin
    old "Come one, I want to suck every drop that comes out of you."
    new "さあ、全部吸い取っちゃうから。"

    # say L17 pla
    old "Oh God..."
    new "オー、神様…"

    # say L41 lin
    old "Yes, yes! Give it to me!"
    new "うん、うん！私にくれて！"

    # say L50 lin
    old "Alright, it's my time to ride you..."
    new "よし、今度は私が乗る番だわ…"

    # say L51 lin
    old "I want you to drill me, like you did with that girl."
    new "あなたが先ほどその子にしたように、私を突いてください。"

    # say L67 lin
    old "Wow... You're so good at this."
    new "Wow... あなた、これ本当に上手だね。"

    # say L69 lin
    old "I love it! Don't stop... Don't Stop..."
    new "大好き！やめてほしい... やめてほしい..."

    # say L73 lin
    old "Ahhh.... Ahhh...."
    new "アhhh.... アhhh...."

    # say L74 lin
    old "I can feel all your energy entering my body..."
    new "あなたのエネルギーが全部私の体に入っているのを感じてる…"

    # say L79 lin
    old "Ahhhhh... I want more."
    new "アーッ……もっと欲しいの……"

    # say L80 lin
    old "More give me more! Harder! HARDER!"
    new "もっとちょうだい！強く！もっと強く！"

    # say L104 lin
    old "Oh yeahh cum inside me! Give me all your load!"
    new "ああ、そうよっ 中に出して！全部私の中に出して！"

    # say L122 pla
    old "Wow... What are you doing? Why are you tying me up?"
    new "Wow... 何やってるの？ なんで僕を縛るんだ？"

    # say L123 lin
    old "I like to play a little while I share my energy with you."
    new "一緒にいながらエネルギーを分かち合うのが好きなの。"

    # say L128 lin
    old "Ohhh, It's great to feel so much energy when I'm with you."
    new "あぁ、あなたと一緒にいるとこんなにエネルギーを感じられるのが最高よ。"

    # say L133 lin
    old "Yes! Yes! I can feel all your energy inside me!"
    new "はい！はい！あなたのエネルギーが全部感じられる！"

    # say L134 lin
    old "Don't stop, don't stop!"
    new "止めてないで、止めてないで！"

    # say L162 lin
    old "Oh, that was fun, isn't?"
    new "ああ、それ楽しかったわ、ねぇ？"


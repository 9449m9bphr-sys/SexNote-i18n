# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/HomeVar.rpy
translate japanese strings:

    # say L116 sis
    old "What do you want? I'm busy with the website..."
    new "何？ウェブサイトのことで忙しいんだよ..."

    # say L117 pla
    old "Do you need some help?"
    new "手伝うの手伝わないの？"

    # say L118 sis
    old "No, I need to be alone..."
    new "いいえ、一人になりたいの..."

    # say L119 pla
    old "Ok... (What is wrong with her?)"
    new "分かった…（何があったんだ？）"

    # say L147 pla
    old "Hey [sis], I was thinking about repeat a photoshoot."
    new "Hey [sis]、写真撮影をまたやってみようかと思ってさ。"

    # say L148 sis
    old "Do you want to repeat a photoshoot?"
    new "写真撮影またやりたい？"

    # say L149 pla
    old "Right, I think it would be useful to have more photos even with the same outfits..."
    new "そうだな、同じ衣装でももっと写真があった方がいいと思うけど..."

    # say L150 sis
    old "Alright, you are the nerd here."
    new "分かった、 nerd は君だな。"

    # say L151 sis
    old "Which photoshoot should we repeat?"
    new "どの撮影を繰り返す？"

    # menu L154 
    old "The first one"
    new "最初のやつだな"

    # say L155 sis
    old "Good choice..."
    new "いい選択ね..."

    # menu L161 
    old "The second one"
    new "二つ目だな"

    # say L162 sis
    old "Hmm I really like that one..."
    new "うん、この子本当に好き..."

    # menu L167 
    old "The third one"
    new "三つ目だな"

    # say L168 sis
    old "Great, let's go to the pool..."
    new "あたし、プールに行きたいな..."

    # menu L174 
    old "The fourth one"
    new "四つ目だな"

    # say L175 sis
    old "Oh, I love this photoshoot..."
    new "この撮影、大好き…"

    # say L190 sis
    old "Are you ready to work on the website?"
    new "ウェブサイトの作業、準備できてる？"

    # say L191 pla
    old "Yeah, I think so."
    new "うん、そう思う。"

    # say L192 sis
    old "So, what are we waiting for? Let's work!"
    new "それじゃ、何を待ってるの？さあ、始めよう！"

    # say L215 sis
    old "Mmm, what do we have here?"
    new "ん〜、これは何かな？"

    # say L216 pla
    old "(Gulp) Well..."
    new "（ゴクリ）まあ…"

    # say L217 sis
    old "I already know... You want my help, right?"
    new "もう知ってるよ… おねえさんの手伝いが必要でしょ？"

    # say L219 sis
    old "With all my pleasure! Hehe."
    new "喜んで！へへ。"

    # say L253 sis
    old "Glad that you came, quite on time for applying the sunscreen, would you help me again?"
    new "来たのが良かったわ、日焼け止めを塗るのにちょうどいいタイミングね、また手伝ってくれる？"

    # say L257 pla
    old "Hmm, Sure."
    new "うん、いいよ。"

    # say L260 pla
    old "I can't right now..."
    new "今ちょっと無理だな..."

    # say L261 sis
    old "Oh, it's a shame, I was expecting a new skin care therapy..."
    new "あら、残念、新しいスキンケアの治療を期待してたのに…"

    # say L263 sis
    old "Alright, I will be here taking a sunbath if you change your mind..."
    new "分かった、もし気持ちが変わったら、日向ぼっこしてるからね。"

    # say L274 sis
    old "Great, I wanted to have some fun today..."
    new "じゃあ、今日楽しく過ごせると思ってたのに…"

    # say L285 sis
    old "So, what do you want to do today?"
    new "じゃあ、今日何するの？"

    # menu L288 
    old "Boobs"
    new "ボッブス"

    # say L289 pla
    old "Hmm I think would be great for the next photoshoot, to focus on your boobs..."
    new "うん、次は写真撮影で君の胸にフォーカスしたらいいと思うよ…"

    # say L290 sis
    old "I like that too... Al right, let's do it..."
    new "私もその案いいな… じゃあ、やってみよう…"

    # say L302 sis
    old "Ready to fuck them?"
    new "準備できてるよ？"

    # say L320 sis
    old "Uhhh, that's it. I love how much it is, let me spread it all over, I am ready to take a sunbath."
    new "うーん、それだ。これだけあるのが好き、全部広げて日向ぼっこする準備ができてるわ。"

    # say L321 sis
    old "Thanks for your help again, [pla]"
    new "またありがとう、[pla]"

    # say L322 pla
    old "You are welcome, always trying to help."
    new "全然、いつでも手伝うよ。"

    # say L323 sis
    old "Hahaha Sure."
    new "ははは、もちろんよ。"

    # menu L333 
    old "Ass"
    new "俺のアス"

    # say L334 pla
    old "Hmm I think would be great for the next photoshoot, to focus on your ass..."
    new "うん、次は君の尻にフォーカスして撮影するといいかもね…"

    # say L335 sis
    old "Oh yeah, let's focus on my ass..."
    new "ああ、そうね、私の尻に焦点を当ててみましょう..."

    # say L342 sis
    old "You can touch all you want! I love it."
    new "触りたいだけ触って！大好きよ。"

    # say L349 sis
    old "Alright, now let's fuck!"
    new "さあ、今度は本気でヤろう！"

    # say L369 sis
    old "Uhhh, it was delicious..."
    new "うーん、美味しかった…"


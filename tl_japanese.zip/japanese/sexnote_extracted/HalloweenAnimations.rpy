# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/HalloweenAnimations.rpy
translate japanese strings:

    # say L5 sis
    old "I'm ready... Do your thing and put it in..."
    new "準備できてる… あなたのテクを使って、入れて…"

    # say L6 pla
    old "Alright."
    new "分かった。"

    # say L12 sis
    old "Oh God... It feels really nice... Your cock feels really nice in my ass..."
    new "ああ、神様… すごく気持ちいい… あなたのチ○ポが私のアナルの中ですごく気持ちいい…"

    # say L13 pla
    old "Uhh it feels.... Tight..."
    new "うっ すげえきついな…"

    # say L18 sis
    old "Ohh yesss... Keep doing it... Fuck my ass [pla]... Fuck my ass!"
    new "オッほーい… 続けて… 私のアナルを突いて [pla]… 私のアナルを突いて！"

    # say L19 pla
    old "Ahhh... Ahhhh..."
    new "アーッ… アーッ…"

    # say L43 sis
    old "Ohh God! I'm coming... I'm coming!!!"
    new "ああ神！イクッ…イクッ…！！"

    # say L44 pla
    old "Ahhh...."
    new "アッ……アッ……"

    # say L59 mo1
    old "Does it feel nice baby?"
    new "感じがいいわね、ベイビー？"

    # say L60 pla
    old "It feels amazing, please don't stop!"
    new "感じが最高だ、止まらないでくれ！"

    # say L65 mo1
    old "Oh yes! Oh yes! Fuck my tits baby!"
    new "ああ、そう！ ああ、そう！ 胸をもっと犯してちょうだい、ベイビー！"

    # say L66 pla
    old "Ahh... Ahhh"
    new "アッ… アアッ"

    # say L70 mo1
    old "Fuck my tits harder [pla]! I want you to cum on my tits baby."
    new "もっと強く私の胸を犯して [pla]！ 私の胸でイってほしいの。"

    # say L71 pla
    old "Uhhhh..."
    new "うっ……"

    # say L95 pla
    old "I- I am going to... Ahhh"
    new "俺、もう……アHHH"

    # say L96 mo1
    old "Cum on my tits honey!"
    new "胸にかけていいわよ、ダーリング！"

    # say L111 sis
    old "Did you have a double blowjob before [pla]?"
    new "前にこんなことしたことがあるの？ [pla]"

    # say L113 mo1
    old "Enjoy it baby!"
    new "楽しんでね、赤ちゃん。"

    # say L118 mo1
    old "What does it feel like to have your [mo1rel] and [sisrel] sucking your dick?"
    new "あなたの[mo1rel]と[sisrel]がチ○ポを吸っている感じはどんな感じですか？"

    # say L119 pla
    old "(OH MY GOD I CAN'T BELIEVE IT.)"
    new "信じられない…これは…"

    # say L120 sis
    old "It's probably his darkest fantasy..."
    new "それは多分彼の最も暗い妄想なんでしょう…"

    # say L125 mo1
    old "And what about if you cum for us?"
    new "そして、あなたが私たちのためにイクのはどうでしょう？"

    # say L127 sis
    old "Yes! Let's make him cum!"
    new "はい！彼をイかせましょう！"

    # say L151 pla
    old "Oh my... I- I am going to... "
    new "ああ…… もう…… イっちゃいそう……"

    # say L152 mo1
    old "Don't stop [sis]."
    new "止めてほしくない [sis]。"

    # say L167 mo2
    old "What a HUGE cock [pla]!"
    new "なんてデカいチ○ポね [pla]！"

    # say L169 mo1
    old "Does it taste great, isn't?"
    new "美味しいでしょう、そうよ？"

    # say L170 mo2
    old "Oh yeah..."
    new "うん、そうね..."

    # say L174 mo2
    old "Oh god I can't ever think about being fucked by this cock..."
    new "神様、このちんこで犯されるだけでも頭が混乱しちゃう..."

    # say L175 sis
    old "Is fucking amazing... You should try it."
    new "超素晴らしいよ… 君も試してみるべきだね。"

    # say L176 mo2
    old "Definetely I will..."
    new "絶対に試してみるわ…"

    # say L182 mo2
    old "Enought waste of time, I want to fuck! Let's make him cum."
    new "十分に時間は浪費したわ、セックスしたいの！早く射精させてあげるわ。"

    # say L184 sis
    old "Yes! Let's make him cum again!"
    new "はい！またイかせましょう！"

    # say L209 mo2
    old "Yeesss..."
    new "はい…"

    # say L213 pla
    old "Alright... What the fuck is happening here?"
    new "よし… ここに何が起こってるんだ？"

    # say L224 mo2
    old "Oh God! It's fucking huge..."
    new "ああ神様！ それは本当に大きいの..."

    # say L225 mo1
    old "Does it hurt [mo2]?"
    new "痛いですか [mo2]？"

    # say L226 mo2
    old "A little bit, but it feels so good..."
    new "少し痛いけど、感じちゃってる..."

    # say L231 mo2
    old "Oh my fucking God, he is drilling me!"
    new "おおおっ、神様！彼は私を掘りまくってる！"

    # say L232 mo2
    old "Don't stop, fuck me harder [pla]!"
    new "止めてほしくない、もっと強く突いて [pla]！"

    # say L237 mo2
    old "Oh yessss! Harder, Fuck me harder baby!"
    new "ああぁぁぁ！もっと強く、もっと強く突いて Baby！"

    # say L261 mo2
    old "Ahhhhh Ahhh, I'm cumming!"
    new "ア─────ッ、イクッ！"

    # say L265 mo1
    old "Well, it's my turn now..."
    new "まあ、今度は私の番だわ…"

    # say L267 mo2
    old "I will bring one of our toys..."
    new "私はおもちゃを一つ持ってくるわ…"

    # say L283 mo2
    old "We haven't tried anal sex in a long time... How does it feel to be completely filled?"
    new "久しぶりにアナルセックスしてみよう… 完全に満たされる感じはどう？"

    # say L284 mo1
    old "Ohhhhh God, this is like a double penetration! It's to much..."
    new "ああぁぁぁぁ、これって二重挿入みたい！　もう、多くて堪らない…"

    # say L289 mo1
    old "OHHH WOW! I can't handle this!"
    new "オッホッホッホッホ！これには耐えられないわ！"

    # say L290 mo1
    old "Ahhh Ahhhh!"
    new "アッ アッ！"

    # say L294 mo2
    old "Let's fuck her harder [pla], let's fuck your [mo1rel] hard!"
    new "もっと激しく彼女を犯そう [pla]、君の [mo1rel] を激しく犯してあげよう！"

    # say L298 mo1
    old "Oh oh yeeesss! I have never feel something like this!"
    new "あああ、はい、はい、はい！こんな感じは初めてだわ！"

    # say L321 mo1
    old "I- I... Ahhhhh I- am... Cumming!"
    new "ああっ、ああっ、イキそう… イクゥ！"

    # say L326 pla
    old "Holy shit... I'm fucking dry."
    new "Holy shit... I'm fucking dry. → ホーリー・シット… 僕、全然濡れてない。"

    # say L327 sis
    old "Oh no... I have been waiting my turn."
    new "あら、私の番を待っていたのに…。"

    # say L345 mo1
    old "Honey, let him rest a bit, I'm going to help him get ready to fuck you too."
    new "honey、ちょっと休ませてあげて。私が手伝って、あなたと一緒になる準備をさせてあげるから。"

    # say L346 sis
    old "Hmmm Alright."
    new "うーん、分かった。"

    # say L350 sis
    old "Now! I want it now!"
    new "今！今すぐ欲しいの！"

    # say L351 mo1
    old "Oh, honey just let me enjoy it a little bit more..."
    new "ねぇ、もう少しだけ楽しませて…"

    # say L352 sis
    old "Hmmm..."
    new "うーん…"

    # say L377 sis
    old "NOW!"
    new "Kylee、もう少しだけ楽しんでいいよ…"

    # say L378 mo2
    old "Let her fuck [pla], she wants to enjoy too, don't be selfish..."
    new "彼女も[pla]と楽しむさせてあげて、彼女も楽しみたいんだから、そんなに独占欲を出さないで…"

    # say L379 mo1
    old "Alright... It's your turn [sis], enjoy it "
    new "よし… あなたの番よ [sis]、楽しんでみてね"

    # say L391 sis
    old "Ohhhh yeahh, this is what I'm talking about..."
    new "ああっ、これが欲しかったの…"

    # say L392 mo1
    old "Does it feel good honey?"
    new "感じがいいわ、はoney？"

    # say L393 sis
    old "It feels great, I never get tired of this..."
    new "感じがいいわ、これにはぜったい飽きないわ..."

    # say L397 sis
    old "Fuck me harder! I want you to make me cum like you did with [mo1rel]..."
    new "もっと激しくして！ もう一度 [mo1rel] のときみたいにイかせたいの…"

    # say L400 sis
    old "Ohh yeah, just like that, don't stop baby."
    new "ああ、そう、その調子で、止めてないで、ベイビー。"

    # say L404 mo2
    old "You are definetly a little pervert [pla], aren't you? You already fucked me, your [mo1rel] and now you are fucking your [sisrel]."
    new "あなたは本当に小さな変態だね [pla]、そうでしょう？もう私とあなたの [mo1rel] とふたりを犯したくせに、今度は [sisrel] を犯そうとしてるんだから。"

    # say L405 mo1
    old "Oh god, but it feels really good."
    new "ああ、でも本当に気持ちいいの。"

    # say L406 sis
    old "Yes! He is making me cum!"
    new "はい！彼は私をイカせているの！"

    # say L430 sis
    old "Yesss Yesss... I'm cumming!!!"
    new "イエスッ イエスッ… 私、イクッ！！！"

    # say L431 sis
    old "Ahhhhhh..."
    new "アァァァァァ..."

    # say L432 mo1
    old "I want it on my mouth."
    new "口に欲しがっているの。"


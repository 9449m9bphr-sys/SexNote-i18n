# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Eventos Default.rpy
translate japanese strings:

    # say L9 pla
    old "Alright… time for some practice."
    new "よし…練習の時間だな。"

    # say L10 pla
    old "Feels good to just sit down and play now."
    new "座ってプレイできるのは良い感じだな。"

    # say L11 pla
    old "It’s becoming part of the routine… and I actually look forward to it."
    new "習慣になってきて、実際に楽しみにしているんだ。"

    # say L17 pla
    old "That one came out clean."
    new "その曲はきれいに弾けたな。"

    # say L18 pla
    old "The chords are flowing better every day."
    new "毎日コードがよりスムーズに弾けるようになってきた。"

    # say L19 pla
    old "Hand still gets tired, but it doesn’t fight me anymore."
    new "手はまだ疲れるけど、もう抵抗しないよ。"

    # say L20 pla
    old "Feels natural now… like the guitar is actually listening."
    new "自然になったな…ギターが実際に聴いてるみたいだ。"

    # say L23 pla
    old "Rhythm’s locking in nicely."
    new "リズムがうまく合ってるな。"

    # say L24 pla
    old "I can feel the music instead of just chasing the notes."
    new "音楽を感じてる、ただ音を追いかけてるわけじゃない。"

    # say L25 pla
    old "({i}This is actually fun… who would’ve thought?{/i})"
    new "{i}これって意外と楽しいな… 誰が思ったかよ？{/i}"

    # say L26 pla
    old "One more run-through. Let’s make it feel even smoother."
    new "もう一回やってみよう。もっと滑らかにできるさ。"

    # say L30 pla
    old "Still a couple of rough spots… but overall it sounded solid."
    new "まだいくつかぎこちなさがあるけど… 全体的にはしっかりしてた。"

    # say L31 pla
    old "I’m really starting to enjoy this."
    new "俺もだんだんと楽しんできてるな。"

    # say L32 pla
    old "It doesn’t feel like a chore anymore. It feels… right."
    new "もう面倒じゃない。なんか…自然と感じるんだ。"

    # say L33 pla
    old "Who knew picking up the guitar would end up being something I actually look forward to?"
    new "誰が思っただろう、ギターを始めるのがこんなに楽しみになるなんて。"

    # say L34 pla
    old "That’s enough for today. Fingers are happy."
    new "今日はこれで十分だな。指も喜んでるよ。"

    # say L35 pla
    old "Tomorrow I’ll pick it up again… no pressure, just playing."
    new "明日また弾こう…プレッシャーなし、ただ楽しむだけさ。"

    # say L44 bil
    old "There you are."
    new "そこにいたのね。"

    # say L45 pla
    old "Hey Billie."
    new "Hey Billie。"

    # say L46 bil
    old "Heh. Back again already?"
    new "へへ、また来ちゃったの？"

    # say L47 bil
    old "The guitar at home not doing it for you anymore?"
    new "家でギター弾いても物足りないの？"

    # say L48 pla
    old "Yeah… I’ve been practicing a lot by myself, but I feel like I improve faster when I’m with you."
    new "そうだな… 自分で練習してるけど、君と一緒にいると成長が早い気がする。"

    # say L49 bil
    old "Of course you do."
    new "もちろんそうだね。"

    # say L50 bil
    old "Heh. Come on. Let’s take this to my room."
    new "へへ、さあ、私の部屋に行こう。"

    # say L54 bil
    old "Alright, we're here."
    new "よし、ここだね。"

    # say L55 bil
    old "So... what are we practicing today?"
    new "じゃあ……今日は何を練習するの？"

    # say L66 pla
    old "Uhh, I would say let’s just rehearse the song together today."
    new "うーん、今日は曲を一緒に練習しようって感じだな。"

    # say L67 pla
    old "I want to polish the chords even more, youb know..."
    new "もっとコードを磨きたいんだ、わかってるだろ..."

    # say L68 bil
    old "Heh. Going for the safe route first? Fine by me… for now."
    new "へへ、まずは安全策ね？今のところはいいけど…"

    # say L69 bil
    old "Grab the guitar. Show me what you’ve been working on."
    new "ギターを取って、練習したところを見せてよ。"

    # say L74 bil
    old "{i}I used to float above the ground…{/i}"
    new "{i}私が地面から浮いていたんだよ…{/i}"

    # say L75 pla
    old "{i}Now every step just pulls me down…{/i}"
    new "{i}今では一歩一歩が重たく感じる……{/i}"

    # say L79 bil
    old "Hmm… your changes are actually smooth now. You’ve been practicing."
    new "うん…変化がスムーズになったね。練習してたの？"

    # say L80 bil
    old "We’re starting to sound like we really belong together on stage."
    new "私たち、ステージ上で本当のパートナーみたいになってきたね。"

    # say L81 bil
    old "Not bad at all. You’re actually carrying your part."
    new "全然悪くないわ。ちゃんと自分のパートをこなしてるのね。"

    # say L82 pla
    old "Yeah, it feels good."
    new "そうだな、いい感じだ。"

    # say L83 bil
    old "See? When we rehearse like this, we both get better together."
    new "見？？？ね？こうやって練習すると、二人とも上手くなっていけるんだよ。"

    # say L84 bil
    old "Still… I wouldn’t mind if you picked something a little more fun next time."
    new "でもね、次はちょっと楽しくて面白いもの選んでもいいよ。"

    # say L87 pla
    old "Uhh, I- I think my fingers could use some... practice."
    new "うーん、俺の指はもう少しだけ... 練習が必要そうだな。"

    # say L88 pla
    old "You know what I mean?"
    new "分かってるだろ？"

    # say L89 bil
    old "Heh. There it is. I was hoping you’d go for this."
    new "へへ、それね。これならって思ってたの。"

    # say L90 bil
    old "Good choice. I like when you get straight to it."
    new "いい選択ね。ストレートに来るのが好きよ。"

    # say L92 bil
    old "Come here, let’s make ourselves comfortable."
    new "ここに来て、くつろごうか。"

    # say L94 bil
    old "This is what you wanted, huh?"
    new "これが欲しかったんでしょ？"

    # say L95 pla
    old "*Gulp*"
    new "*ゴクリ*"

    # say L96 bil
    old "They’re all yours today."
    new "今日一日は全部あなたのものよ。"

    # say L98 bil
    old "Hands on them. You already know exactly how I like it."
    new "手をのせなさい。もうどうしたいかわかってるでしょう。"

    # say L102 pla
    old "They’re… so soft every time. I can feel them filling my hands."
    new "彼女たち… 毎回こんなに柔らかいんだ。手の中で膨らむのを感じるよ。"

    # say L103 bil
    old "Mmm… squeeze them slowly. Open and close your hands… just like that."
    new "んん…ゆっくりと握って。手を開いたり閉じたり…そう、その通り。"

    # say L105 bil
    old "Nngh— yeah… a little harder now. Grip them properly."
    new "んん——そう、今度は少し強く。しっかり握って。"

    # say L107 bil
    old "Fuck… keep that pace. Squeeze them like you mean it."
    new "ファック…そのペースでいいわ。本気で握ってよ。"

    # say L110 bil
    old "Now the nipples… grab them and pull… slow at first."
    new "乳首を……つかんで引いて……最初はゆっくりと。"

    # say L112 bil
    old "That’s it… stretch them gently."
    new "そうそう…優しく伸ばして。"

    # say L114 bil
    old "Mmm—harder. Tug them a little more. You’re getting really good at this."
    new "んん—もっと強く。少し強く引っ張って。上手くなってきたね。"

    # say L116 bil
    old "Fuck… faster. Pull them nice and firm. I love how confident your hands feel now."
    new "ファック…もっと速く。しっかり引きなさい。あなたの手の自信、大好き。"

    # say L118 bil
    old "Mmm… your touch is way more precise lately. You’ve improved a lot."
    new "mmm… 最近あなたのタッチがずいぶん正確になったね。ずいぶん上達したわ。"

    # say L119 bil
    old "Your fingers are definitely improving. They feel so much more alive and sure of themselves."
    new "あなたの指は確実に上達してるね。ずいぶんと生き生きとして、自信に満ちてる感じがする。"

    # say L120 bil
    old "Keep practicing that rhythm at home… or just come back whenever you want more of... this."
    new "家でそのリズムを練習してね… または、もっとこれが欲しくなったらいつでも戻ってきて。"

    # say L124 pla
    old "Uhh, actually I was wondering if we could try the... 'advanced practice' today..."
    new "うーん、実は今日、‘上級練習’をやってみようかと思ったんだけど…"

    # say L125 bil
    old "Heh. Straight to my favorite part. I was really hoping you’d pick this one."
    new "へへ、私の好きな部分ね。これ選んでくれると思ってたの。"

    # say L126 bil
    old "You know I like when you get straight to the fun stuff."
    new "あなたがすぐに楽しいことに移るのを好きだって知ってるよ。"

    # say L128 bil
    old "Get ready. I’m getting on top."
    new "準備できてる？ 上に乗っちゃうからね。"

    # say L130 bil
    old "I know how much you like to see them, so why don’t we make it more enjoyable for both of us?"
    new "あなたが見るのが好きだって知ってるから、お互いに楽しみましょうか。"

    # say L133 bil
    old "Now use those fingers right. Show me what you’ve learned."
    new "指の使い方を見せて。教えてもらったことを思い出しちゃいな。"

    # say L135 bil
    old "Mmm… circle my clit first. Gentle, like I showed you."
    new "んん…まずはクリトリスを円を描くように撫でて。優しく、私が教えた通りに。"

    # say L145 bil
    old "Shit… your fingers really kept perfect rhythm this time."
    new "くそ…指のリズム、今回は本当に完璧だったね。"

    # say L147 bil
    old "This is exactly the kind of dexterity we need… both on stage and off it."
    new "これこそが舞台上でもベッドでも必要な器用さよ…。"

    # say L151 pla
    old "Uhh… I’ve been practicing the guitar a lot by myself lately."
    new "うーん… 最近ギターの練習を一人でよくしてたんだ。"

    # say L152 pla
    old "And I was thinking… maybe it would be good if I helped you with your practice too, you know?"
    new "そしてさ、君の練習にも手伝うのがいいかもしれないと思ったんだけど、わかってる？"

    # say L153 pla
    old "Like… helping you stay steady under pressure… like last time…"
    new "うん、プレッシャーに耐えてもらう手伝いをしたいんだ… 前みたいにさ。"

    # say L154 bil
    old "Heh… look at you trying to be all subtle."
    new "へへ… ずいぶん subtleness を意識してるね。"

    # say L155 bil
    old "You’ve been practicing hard, huh? And now you want to 'help' me with my vocal training."
    new "練習がんばってるんだね？今度はボイストレーニングの手伝いがしたいのかな。"

    # say L156 bil
    old "Cute. Real cute."
    new "かわいいわ。ほんと可愛いわ。"

    # say L157 bil
    old "I know exactly what you mean, dummy."
    new "分かってるわ、バカね。"

    # say L158 bil
    old "Lie down. Time to put that tongue to good use."
    new "寝て。舌を活用するときだね。"

    # say L161 bil
    old "Tongue out. Keep me steady while I lose it."
    new "舌出して。私がイキそうになった時に支えて。"

    # say L164 pla
    old "You’re already dripping…"
    new "もう漏らしてるぞ…"

    # say L172 bil
    old "Nngh… your tongue is getting way too good at this."
    new "んっ… あなたの舌がこれほど上手いのは unfair すぎるよ。"

    # say L174 bil
    old "Every time you do this my voice gets stronger under pressure… and I get to enjoy that mouth of yours."
    new "毎回あなたがこれをするたびに、私の声はプレッシャーで強くなって……そして、あなたのその口を楽しむことができるの。"

    # say L178 pla
    old "And sometimes I feel like I still need… a little extra motivation to keep improving."
    new "そして時々、まだ少し追加のモチベーションが必要だなって思うんだ。"

    # say L179 bil
    old "Heh… so that’s what this is really about."
    new "へへ… そうか、これが本質だったのか。"

    # say L180 bil
    old "All that solo practice and you still need me to give you a little push, huh?"
    new "それだけの個人練習をしていても、まだ私がちょっと背中押しなきゃダメなのか？"

    # say L182 bil
    old "Would this be enough motivation for you?"
    new "これで十分な動機になるかな？"

    # say L183 bil
    old "Just looking at them… does that help?"
    new "見ているだけで… それって役立つ？"

    # say L185 pla
    old "Y-yeah… they look amazing but… I was thinking maybe something more… direct?"
    new "うん…確かに見るのはいいけど…もっと直接的な何かを考えてたんだ。"

    # say L186 bil
    old "Oh? Not satisfied with just the view?"
    new "おお？ただ見ているだけじゃ満足できないの？"

    # say L187 bil
    old "Greedy today, aren’t you?"
    new "今日のは欲張りさんね。"

    # say L188 bil
    old "Heh… fine. I know exactly how to motivate you properly."
    new "へへ… 分かったわ。私が Proper なモチベーションの仕方を教えてあげるからね。"

    # say L191 bil
    old "Let me take care of that motivation the right way."
    new "私が正しいモチベーションの仕方を教えてあげるからね。"

    # say L192 bil
    old "Eyes on me the whole time."
    new "目を離さないで。"

    # say L194 bil
    old "Mmm… look at you. Already so hard just from asking."
    new "うん… 你看て。もうこんなに硬くなってるの、ただ聞いてるだけで。"

    # say L195 pla
    old "Billie… that feels so good…"
    new "ビリー… それが気持ちいいよ…"

    # say L197 bil
    old "Deeper now… I want to feel every throb."
    new "もっと深く……すべての脈動を感じたいの。"

    # say L198 pla
    old "Fuck… you’re way too good at this."
    new "くそ… お前はこれ本当に上手いな。"

    # say L201 pla
    old "I’m— I’m close…!"
    new "俺——もうすぐ……！"

    # say L204 bil
    old "Mmm… every drop. Good boy."
    new "mmm… すべての滴ね。いい子だね。"

    # say L206 bil
    old "Heh… feeling more motivated already?"
    new "へへ… もうずいぶん興奮してきた？"

    # say L208 bil
    old "Come back whenever you need some real motivation again… I’ll be waiting."
    new "また本物のモチベーションが必要になったら戻ってきてね… 私は待ってるから。"

    # say L212 bil
    old "Phew, well, that’s enough for today."
    new "ふう、まあ今日分はこれで充分かな。"

    # say L213 bil
    old "You can come back whenever you need more 'practice'."
    new "いつでも練習が必要になったら戻ってきていいわ。"

    # say L214 bil
    old "Just text me. I’ll always make time… especially if you want the fun version."
    new "ただメッセージくれればいいわ。いつでも時間作るから…特に楽しい方をしたいならね。"

    # say L215 pla
    old "I’ll be back soon."
    new "すぐ戻るよ。"

    # say L216 bil
    old "You better. Now get out before grandma walks in."
    new "ちゃんとね、ばあちゃんが入ってくる前に出て行って。"

    # say L223 bil
    old "Phew… that’s enough for today."
    new "ふう……今日分はこれで十分だね。"

    # say L224 bil
    old "Not bad. You’re actually starting to sound like you belong up there with me."
    new "悪くないね。君も実際に私と肩を並べられるようになってきたわ。"

    # say L225 bil
    old "Oh, by the way…"
    new "そういえば、あとでね…"

    # say L226 bil
    old "Tomorrow we have a practice with Bey. Don’t slack off tonight."
    new "明日ベイと練習があるんだよ。今夜は怠けないでね。"

    # say L227 bil
    old "Get some rest, warm up your fingers, and meet me at school. We’re doing a full run-through with her watching."
    new "休んで、指を温めて、学校で会おう。彼女が見守る中、フルでやってみよう。"

    # say L228 pla
    old "Got it. I’ll be there."
    new "分かった、いるよ。"

    # say L229 bil
    old "You better. Don’t make me drag you out of bed."
    new "分かったわ。ベッドから引きずり出すのは面倒だよ。"

    # say L236 bil
    old "You’re getting better every time. I can feel it."
    new "あなたが毎回上手くなってるの、感じてるわ。"

    # say L237 bil
    old "Hey… before you go."
    new "Hey… 行く前よ。"

    # say L238 bil
    old "I need a favor. Free up your afternoon tomorrow and come over."
    new "明日の午後、空けておいて。来てくれない？"

    # say L239 pla
    old "Sure, what for?"
    new "もちろん、何のために？"

    # say L240 bil
    old "Just come. I need you to accompany me somewhere. No questions."
    new "来なさい。私と一緒にどこかに行ってくれるの。質問は無しね。"

    # say L241 bil
    old "It’s important… and I don’t want to go alone."
    new "大事な用事だから… 一人で行くのは嫌なの。"

    # say L242 pla
    old "A- alright. I’ll be here."
    new "わかったよ。待ってるから。"

    # say L243 bil
    old "Good. Don’t be late. Now get out before grandma walks in."
    new "分かったわ。遅れないで。さあ、出てって、ばあちゃんが来る前に。"


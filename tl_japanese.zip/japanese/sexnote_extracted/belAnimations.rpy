# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/belAnimations.rpy
translate japanese strings:

    # say L7 pla
    old "Ohh yeah it feels really nice."
    new "オッ、本当に気持ちいいな。"

    # say L12 bil
    old "Ugh! That's really a big dick... Have you seen one like that before Belle?"
    new "うっ！それって本当に大きいね… こんなに大きいの見たことある？ベル。"

    # say L13 bel
    old "N- no, I had never seen a cock this big."
    new "あ、あんなに大きいの見たことないわ…"

    # say L14 bil
    old "He seems to like it like that, keep going."
    new "彼はそんなふうにされて好きみたいだよ、続けて。"

    # say L18 bil
    old "Keep going Belle! Don't stop."
    new "ベル、続けて！止まないで。"

    # say L19 bil
    old "Do you like that [pla]?"
    new "好きだよ [pla]？"

    # say L20 pla
    old "Mmmm... Y- yeah."
    new "うん… やっぱりそう思ってる。"

    # say L21 bel
    old "It's soo hard in my hand, right now!"
    new "手の中こんなに硬いよね、今！"

    # say L44 pla
    old "I-I think I'm cuming!"
    new "出ちゃいそうだよ！"

    # say L45 bel
    old "Uhh?"
    new "うっ？"

    # say L46 bil
    old "Yes! Cum [pla]!"
    new "はい！出しなさい [pla]！"

    # say L47 bil
    old "Cum in her face!"
    new "顔にかけてあげなさい！"

    # say L48 pla
    old "Ughhhh!"
    new "うっぐhhh！"

    # say L54 bel
    old "Ughh... You gotta be more careful [pla], I'm all covered with cum now."
    new "うっ……もっと気をつけて [pla]、今全部精子で汚れてるよ。"

    # say L55 pla
    old "S- sorry, I couldn't really help it."
    new "す、すまん、我慢できなかったんだ。"

    # say L56 bil
    old "Hah! What's the matter Belle?"
    new "ハハ！どうしたのベル？"

    # say L57 bil
    old "Aren't you happy you gave him a good time."
    new "あなたが彼と良い時間を過ごせたんじゃない、幸せじゃない？"

    # say L58 bel
    old "Phew, yeah right! As if I wanted this sticky thing on me."
    new "ふう、そうよ！ 私がこんなベトベトしたものを身体につけたいわけないでしょう。"

    # say L59 bel
    old "Wait a minute, I'll clean myself."
    new "ちょっと待って、自分で綺麗にするから。"

    # say L71 sis2
    old "Oh! Oh my gosh!"
    new "あら！あらあら！"

    # say L72 sis2
    old "This cock!"
    new "このちんぽ！"

    # say L73 sis2
    old "It's so good!"
    new "これ、最高！"

    # say L77 sis2
    old "I love how deep into my throat it's going!"
    new "このチンポ、喉の奥まで入ってくるのが好き！"

    # say L78 sis2
    old "Oh! Yeah! Do you guys like this?"
    new "オッ！ヤッ！これみんな好き？"

    # say L79 sis2
    old "Seeing this huge cock fill my mouth up?!"
    new "この大きなちんこが口いっぱいに入ってるのを見て！"

    # say L83 sis2
    old "Yes! Yes! Yes!"
    new "はい！はい！はい！"

    # say L84 sis2
    old "Oh my gosh this is the best taste ever!"
    new "うわーこれ最っ最爱的味道！"

    # say L85 sis2
    old "I can't get enough of this taste!"
    new "この味がやめられない！"

    # say L108 sis2
    old "Oh my gosh!"
    new "あらまあ！"

    # say L109 sis2
    old "He's about to fill my mouth with his cum!"
    new "もうすぐ私の口の中に精液を注ぎ込んじゃう！"

    # say L110 sis2
    old "Do you want to see it?"
    new "見たい？"

    # say L117 sis2
    old "That was fantastic guys!"
    new "それは最高だったわ、みんな！"

    # say L118 sis2
    old "And it's all thanks to your tips!"
    new "それ全部君たちのアドバイスのおかげだよ！"

    # say L119 sis2
    old "If you want to see me getting fucked in the future remember to subscribe to premium and keep tipping."
    new "将来も私がセックスするところを見たいなら、プレミアムに登録してチップをくれることを忘れずにね。"

    # say L120 sis2
    old "And of course, join my fan club so you can download the video of this streaming."
    new "もちろん、私のファンクラブに入ってくれたら、このストリーミングの動画をダウンロードできるよ。"

    # say L132 bel
    old "What great dick this is"
    new "このチンポ、最高ね"

    # say L133 bel
    old "I love the way it feels in my hand!"
    new "手に感じるこの感覚が大好き！"

    # say L134 bel
    old "It's so big and so nice!"
    new "大きいし、気持ちいい！"

    # say L138 bel
    old "Do you like how I stroke it?"
    new "私がこれをおさえるのが好き？"

    # say L139 bel
    old "Do you like how I grab your big dick in my hand?"
    new "あなたの大きなちんこを手で握るの、好き？"

    # say L140 bel
    old "It's such a nice big cock!"
    new "こんなに大きい素敵なちんこだ！"

    # say L144 bel
    old "Oh my god!"
    new "おおっ！"

    # say L146 bel
    old "So big and hot!"
    new "こんなに大きくて熱い！"

    # say L169 bel
    old "I can feel you're about to cum!"
    new "出そうになっているの、感じてる！"

    # say L170 bel
    old "Your dick is twitching so hard in my hand!"
    new "あなたのチ○ポ、私の手の中でギュンギュン震えてる！"

    # say L171 bel
    old "Come! I want you to see you do it!"
    new "出しなさい！見せてくれたいの！"

    # say L177 bel
    old "That was sooo good!"
    new "それがすごいいいだった！"

    # say L178 bel
    old "But that's not all we're doing today guys!"
    new "でも今日はそれだけじゃないわよ！"

    # say L179 bel
    old "Why don't I show you what I have next for you?"
    new "次に何を用意したか見せてあげる？"

    # say L194 bel
    old "Mmm! The taste of this big cock!"
    new "んっ！この大きなちんこのお味！"

    # say L195 bel
    old "It's so hot and thick!"
    new "熱くて太いんだ！"

    # say L196 bel
    old "You guys wanted this, didn't you?"
    new "あなたたち、これ欲しかったんでしょ？"

    # say L206 bel
    old "Do you like how I stuff my mouth with your dick?"
    new "あなたたち、私の口にあなたのちんこを詰め込むのが好き？"

    # say L207 bel
    old "I love it!"
    new "大好き！"

    # say L211 bel
    old "I love how you're filling my mouth with your big cock!!"
    new "あなたの大きなちんこで私の口がいっぱいになるのを大好き！"

    # say L212 bel
    old "I can't get enough of it!"
    new "これ、全然足りないよ！"

    # say L213 bel
    old "I love how it tastes!"
    new "この味が大好きだよ！"

    # say L217 bel
    old "My god! This taste is so good!"
    new "神様！この味、めっちゃいいよ！"

    # say L218 bel
    old "I love how you're ravishing my mouth!"
    new "あなたが私の口を荒々しく愛撫するの、大好き！"

    # say L219 bel
    old "I can't get enough of your dick guys!"
    new "あなたたちのちんこ、いくらでも吸いちゃうよ！"

    # say L242 bel
    old "You guys want to cum in my mouth?"
    new "あなたたち、私の口でイクの？"

    # say L244 bel
    old "I want you to fill my throat with your hot load!"
    new "あなたたちの熱いザーメンで喉を満たしてほしいの！"

    # say L250 bel
    old "That was so good guys!"
    new "それが良かったわね、みんな！"

    # say L251 bel
    old "This cum is so good!"
    new "この精液、最高だわ！"

    # say L252 bel
    old "It's just the best taste in the world!"
    new "これが世界一の味だわ！"

    # say L273 bel
    old "Mmm! oh my god! I can never get enough of this dick!"
    new "うん！神様！このちんこ、いくらでも吸いたいわ！"

    # say L274 bel
    old "This has to be the most amazing dick in the world!"
    new "これほど素晴らしいちんこは世界中を探しても見つからないわ！"

    # say L275 bel
    old "I love how much it's filling my mouth!"
    new "このチ○ポが私の口いっぱいに広がるのが大好き！"

    # say L281 bel
    old "Do you guys like seeing me like this? Who would want to have me right in front of you like this?"
    new "あなたたち、こんな私を見て好き？ 誰か前にいてくれたらいいのに、こんな風にね。"

    # say L282 bel
    old "Do you like the way this cock is filling in my entire mouth?!"
    new "このチンポが私の口いっぱいに広がってるの好き？"

    # say L283 bel
    old "Oh yes! I can feel it pushing all the way to my throat!"
    new "オお、はい！喉まで押しつぶされるのを感じてるわ！"

    # say L290 bel
    old "Mmm! Oh my god guys look at this!"
    new "ん！皆見てこの凄さ！"

    # say L291 bel
    old "This cock is just as hard as it was a minute ago!"
    new "このチ○ポ、さっきと同じくらい硬いよ！"

    # say L292 bel
    old "My god! It's so good!"
    new "神様！これ、めちゃくちゃいいよ！"

    # say L293 bel
    old "It doesn't matter what happens, it's always so great!!"
    new "何が起こっても、いつもこんなに素晴らしいんだよ！"

    # say L294 bel
    old "I- Slrrp! I bet you guys like this don't you?"
    new "イーっ！スルルッ！あなたたち、これ好きだよね？"

    # say L295 bel
    old "I- Mmm! I love it!"
    new "イー、ムム！大好き！"

    # say L300 bel
    old "OH! Yes! This cock tastes so great!"
    new "OH！ そうよ！ このちんこ、めちゃくちゃおいしい！"

    # say L301 bel
    old "Slrrrp! Mmmm! I can't get enough of it!"
    new "スルルッ！　んん！　これ、もう止まらない！"

    # say L302 bel
    old "Oh God I love the way you're fucking my mouth!"
    new "神様！あなたが私の口を犯すのが大好きだ！"

    # say L326 bel
    old "Oh god! I can feel you getting tense!"
    new "神様！あなたが緊張してるのを感じてる！"

    # say L327 bel
    old "You're about to cum, right guys?!"
    new "もうすぐイクんでしょ、みんな？！"

    # say L328 bel
    old "Do it! Don't hold it back!"
    new "やって！我慢しないで！"

    # say L329 bel
    old "Throw your cum in my throat!"
    new "私の喉に精液吐いて！"

    # say L336 bel
    old "I'm so happy you liked it too!"
    new "私も好きだったってことが嬉しいの！"

    # say L337 bel
    old "Especially because we've managed to get to the goal!"
    new "特に目標に到達できたから！"

    # say L338 bel
    old "So now we can go ahead and I can show you!"
    new "じゃあ、次に進んで、あなたに見せることができるわ！"

    # say L339 bel
    old "Just give me a couple of minutes, we're going to get ready for what comes next."
    new "ちょっと待って、次の準備をするだけだから。"

    # say L340 bel
    old "Don't go anywhere because I know you're going to love it!"
    new "どこにも行かないで、絶対に気に入ってくれるから！"

    # say L349 bel
    old "Oh! Yeah!"
    new "オッ！そうよ！"

    # say L350 bel
    old "The feeling in my throath is so great!"
    new "喉の感じがすごいよ！"

    # say L355 bel
    old "I like it so much!"
    new "私、超好き！"

    # say L356 bel
    old "Do you like to see me sucking cock guys?!"
    new "あなたたち、私がチ○ポを吸っているのを見るのは好き？！"

    # say L361 bel
    old "Oh, yeah! Yeah!"
    new "オッ、そう！ やっぱり！"

    # say L362 bel
    old "Oh my god! This is so good!"
    new "おおっ！これ、超いい！"

    # say L363 bel
    old "I can't imagine a better tasting dick than this!"
    new "こんなに美味しいチンコは想像できないわ！"

    # say L386 bel
    old "Oh yeah!"
    new "ああ、そうね！"

    # say L387 bel
    old "I can feel your dick twitching."
    new "あなたのちんぽがぴくぴくしてるの感じる。"

    # say L388 bel
    old "I know you're about to come!"
    new "もうすぐイクんでしょ！"

    # say L389 bel
    old "Do it guys! Cum in my mouth!"
    new "やってみ、みんな！ 私の口にぶっかけろ！"

    # say L394 bel
    old "That was lovely guys!"
    new "それは良かったわね、皆さん！"

    # say L395 bel
    old "But we're not stopping here!"
    new "でも、ここで止まらないわよ！"

    # say L396 bel
    old "Let's get to what you really want to see!"
    new "それじゃ、本当は見たいところに行こう！"

    # say L410 bel
    old "Hngh!"
    new "んっ！"

    # say L411 bel
    old "Oh god! This is so amazing!"
    new "神様！これ、めっちゃすごい！"

    # say L412 bel
    old "My god! This sensation is so good!"
    new "神様！この感覚、最高だよ！"

    # say L421 bel
    old "Oh my god! Oh my god!"
    new "おおお！神様！おおお！神様！"

    # say L423 bel
    old "I love the way you're making me feel!"
    new "あなたが私にさせてくれる感じが大好き！"

    # say L427 bel
    old "I can't get enough of this dick!"
    new "このチ○ポが手放せない！"

    # say L428 bel
    old "My pussy feels so good!"
    new "私のオマンコが気持ちいい！"

    # say L429 bel
    old "This dick is so hot! It's so good!"
    new "このちんこ、ホントに熱い！すごくいいよ！"

    # say L433 bel
    old "Ugh! Oh yes! yes!"
    new "うーん！ああ、そう！そう！"

    # say L434 bel
    old "I love the way this feels!"
    new "この感じが大好き！"

    # say L436 bel
    old "My pussy feels so great!"
    new "オマンコの感じがすごいの！"

    # say L459 bel
    old "I know you guys want to come inside of me!"
    new "みんなも私のなかでイキたいんだよね！"

    # say L460 bel
    old "Do it! Fill my pussy again with your hot load!"
    new "やって！ 私のオマンコをまたあなたの熱い精液で満たして！"

    # say L461 bel
    old "I want to feel that cum inside me!"
    new "私の中であの快感を感じたい！"

    # say L468 bel
    old "I knew you would like it!"
    new "分かっていたわ、あなたが気に入るって！"

    # say L480 bel
    old "Oh god!"
    new "ああっ！"

    # say L481 bel
    old "This cock was so impressive before"
    new "このチ○ポ、前から凄かったけどね"

    # say L482 bel
    old "But now that I have it on my ass!"
    new "でも今、お尻に這いつくさってるから！"

    # say L483 bel
    old "It's even better!"
    new "もっと良い！"

    # say L487 bel
    old "God! It's so good!"
    new "神様！気持ちいいよ！"

    # say L488 bel
    old "I love how hard you're fucking my ass guys!"
    new "皆さん、私のアナルをこんなに激しく犯してくれるのは大好き！"

    # say L489 bel
    old "Mmm! Do you like the way you're stretching me?!"
    new "んん！あなたたちが私を広げてる感じ、好き？！"

    # say L493 bel
    old "Oh! Oh! Yes!"
    new "オッ！オッ！そう！"

    # say L494 bel
    old "Yes! Keep fucking me like that!"
    new "はい！その調子で犯し続けて！"

    # say L495 bel
    old "I love the way it's filling me!"
    new "私、中に満たされる感じが大好き！"

    # say L496 bel
    old "It's just stretching my ass!"
    new "ただ私のアナルを広げてるだけ！"

    # say L519 bel
    old "OH yes! I can feel it!"
    new "ああん yes！ 感じてる！"

    # say L520 bel
    old "You're about to cum aren't you?"
    new "もうすぐイクんでしょ？"

    # say L521 bel
    old "Do it! Cum!"
    new "やって！ 出して！"

    # say L522 bel
    old "Fill my ass with your hot cum!"
    new "私のアナルに熱い精液を注ぎ込んで！"

    # say L529 bel
    old "That was so awesome guys!"
    new "それが凄かったわ、みんな！"

    # say L530 bel
    old "I knew you guys would do great today!"
    new "今日もみんな最高だったって知ってたよ！"

    # say L531 bel
    old "And you didn't disappoint!"
    new "期待した通り、がっかりさせなかったわ！"

    # say L543 amo
    old "Slrrp! Oh my god!"
    new "スルルッ！神がかん！"

    # say L544 amo
    old "What a great taste this dick has!"
    new "このチ○ポの味が最高だな！"

    # say L545 amo
    old "Mmm! It feels so amazing in my mouth!"
    new "んっ！口の中でこんなに気持ちいいなんて！"

    # say L549 bel
    old "Do you like seeing us taste dick guys?"
    new "男の子たち、私たちがチ○ポを味わってるのを見て好き？"

    # say L550 bel
    old "It's so amazing to lick it!"
    new "舌で舐めるのが凄く気持ちいいよ！"

    # say L551 bel
    old "I love how hot it is!"
    new "この熱さが大好き！"

    # say L555 amo
    old "Slrrp! Mmmm!"
    new "スルル！　んん！"

    # say L556 amo
    old "This dick is so hard!"
    new "このチ○ポ、めちゃくちゃ硬いぞ！"

    # say L557 amo
    old "And the taste! So amazing!"
    new "味も最高だ！"

    # say L580 bel
    old "I can feel this dick twitching!"
    new "このちんこがぴくぴくしてるの感じてる！"

    # say L581 bel
    old "You want to see him cum because of our tongues don't you?!"
    new "私たちの舌で彼が出るのを見たいんでしょ？！"

    # say L582 amo
    old "Oh yes! I want to see that!"
    new "ああんyeah！見せて欲しんだ！"

    # say L589 bel
    old "Oh my God guys! You're amazing!"
    new "おー！あなたたちスゴい！"

    # say L590 bel
    old "You actually did it!"
    new "本当にやっちゃったのね！"

    # say L591 bel
    old "You reached the goal!"
    new "目標に到達したわ！"

    # say L592 bel
    old "And you know what that means."
    new "それってつまり、あなたが待っていたものが手に入ったってことよね。"

    # say L594 amo
    old "This is what I was waiting for!"
    new "これだよ！待ってたんだ！"

    # say L608 amo
    old "Mmm! Oh God yes! This is what I had been waiting for!"
    new "うむ！神様、本当にありがとう！これが待ってたものだよ！"

    # say L609 amo
    old "What an amazing cock!"
    new "なんて素晴らしいちんこだ！"

    # say L618 amo
    old "Oh yeah [pla]!"
    new "ああ、そうさ [pla]！"

    # say L619 bel
    old "Do you like how he's stretching her pussy?"
    new "彼が彼女のマ○コを広げてるの、好き？"

    # say L620 amo
    old "I love the way it feels!"
    new "俺、この感じが大好きだよ！"

    # say L624 bel
    old "Do you like how he's fucking her guys?"
    new "君たちは彼が彼女を犯してるの、好き？"

    # say L625 bel
    old "It's amazing isn't it?"
    new "すごいわね？"

    # say L626 amo
    old "Oh my God! This cock is so amazing!"
    new "オーマイゴッド！このちんこ、最高だよ！"

    # say L630 amo
    old "Oh God! Oh yes!"
    new "オーマイゴッド！ああ、そうよ！"

    # say L631 amo
    old "Yes! Yes! Keep stretching my pussy!"
    new "はい！はい！もっと私のオマンコを広げて！"

    # say L632 amo
    old "What a great cock! It's so hard! And so big!"
    new "すげえちんこだな！硬くて、デカいぞ！"

    # say L655 amo
    old "I- Ah! I can feel his dick twitching!"
    new "あー！チ○ポが震えてるのを感じてる！"

    # say L656 bel
    old "Are you about to cum?! Do it!"
    new "出そうなの！？ 出しちゃう！"

    # say L657 bel
    old "Fill her up with your cum!"
    new "彼女の中に出して！"

    # say L658 amo
    old "Yes! Oh yes! I want to feel it inside!"
    new "うん！ああ、うん！中で感じたい！"

    # say L665 amo
    old "That was wonderful guys!"
    new "それは素晴らしいね、みんな！"

    # say L666 amo
    old "I felt so amazing!"
    new "感じたことが最高だった！"

    # say L667 amo
    old "To have my pussy stretched like that!"
    new "そんなにオマエが広がるなんて、最高だったよ！"

    # say L668 amo
    old "But now it's time for Belle's turn."
    new "でも今はベールの番だな。"

    # say L669 bel
    old "Alright! I was waiting for this too."
    new "よし！私もこれ待ってたの。"

    # say L682 amo
    old "Oh! That's fucking hot to see!"
    new "オォ！見させてもらうだけでも興奮するな！"

    # say L683 amo
    old "How does it feel Belle?"
    new "ベール、どう感じる？"

    # say L692 bel
    old "Hmm! I love it!"
    new "うふん！大好き！"

    # say L693 bel
    old "I can never get enough of this dick!"
    new "このチ○ポ、何度でも欲しくなるの！"

    # say L694 bel
    old "No matter how many times I have it!"
    new "何度やっても満足できないわ！"

    # say L698 amo
    old "God that's just so good to see!"
    new "神、それ見るだけで最高だ！"

    # say L699 amo
    old "Look at how that dick comes in and out of your pussy!"
    new "見てごらん、そのチ○ポがおま○こ进出してるところ！"

    # say L704 bel
    old "OH! OH! God!"
    new "OH！ OH！ 神様！"

    # say L705 bel
    old "This dick! Is so good!"
    new "このちんこ！めっちゃいいよ！"

    # say L706 bel
    old "I love it! It's so hot!"
    new "大好きだよ！熱くて気持ちいい！"

    # say L707 bel
    old "Do you like fucking me guys?"
    new "あなたたち、私を犯すのが好きよね？"

    # say L730 bel
    old "I- Oh! I can feel his dick twitching!"
    new "ああ！感じちゃう！彼のちんぽがぴくぴくしてるの！"

    # say L731 bel
    old "I feel it coming!"
    new "感じてる！来てる！"

    # say L732 amo
    old "Do it! Cum inside her! Fill her pussy!"
    new "やってくれ！ 中に出せ！ おまえのオマ○コを満たせ！"

    # say L740 bel
    old "I'm so happy you reached the goal!"
    new "目標達成して本当に嬉しい！"

    # say L741 bel
    old "You never disappoint me!"
    new "あなたは本当にがっかりさせないわね。"

    # say L742 amo
    old "It really was great!"
    new "本当に良かったよ！"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/JonStory.rpy
translate japanese strings:

    # say L6 bil
    old "Oh... hey."
    new "あっ… おひさしぶり。"

    # say L7 pla
    old "... Uhh hi."
    new "うーん、ちょっとぎこちないね。こんにちは。"

    # say L8 bil
    old "This is a bit awkward... Do you need something?"
    new "これはちょっとぎこちないね…何か用？"

    # say L33 bil
    old "Weird."
    new "変な感じだね。"

    # say L39 pla
    old "Oh, no, no sorry, I was just looking for Mrs. Jones."
    new "あ、いや、すみません、ただジョーンズ夫人を探してたんだ。"

    # say L41 pla
    old "... Alright, see you."
    new "じゃあ、またね。"

    # say L53 pla
    old "Hi everybody, how are you doing?"
    new "みんな、元気してる？"

    # say L54 gra
    old "Hi [pla], God be with you!"
    new "こんにちは[pla]、神様が一緒にお伴してください。"

    # say L55 jon
    old "Hi [pla] so happy to see you! We were talking about you..."
    new "こんにちは [pla]、お会いできてうれしいです！あなたのこと話していたところでしたよ…"

    # say L56 gra
    old "In fact, we were talking about you with Father Morgan as well."
    new "実際、Father Morganさんともあなたのことを話していたんです。"

    # say L57 pla
    old "Oh! Really? What were you saying about me? Am I in trouble?"
    new "ほんと？何を言ってたの？俺、何かしたのか？"

    # say L58 jon
    old "Noo! It's the opposite, we are so grateful for what you've done for us."
    new "いいえ！全然逆ですよ、あなたが私たちのためにしてくださったことに本当に感謝しています。"

    # say L59 jon
    old "Billie is feeling good now and we can feel our church is a peaceful place again, all thanks to you."
    new "ビリーが元気になりましたし、私たちの教会がまた平和な場所に戻りました、すべてあなたのおかげです。"

    # say L60 pla
    old "Well... I-I just did what God told me to do... It was actually him, not me."
    new "まあ…… 僕はただ神様が言われたことをしただけさ…… 実際には神様がしてくれたことだから、僕じゃないんだ。"

    # say L62 gra
    old "And that's why we want you to be part of our community, we want you to join our activities."
    new "そして、それが私たちがあなたをコミュニティの一員として迎えたいと思う理由です。私たちの活動に参加してほしいんです。"

    # say L63 jon
    old "We saw how God works through your hands, you've shown us that you're like a saint."
    new "あなたの手を通じて神様が働いているのを見てきました、あなたはまるで聖人のような方ですね。"

    # say L64 gra
    old "Join us, please! It would be our pleasure to have you here."
    new "ぜひ私たちと一緒にいてください！あなたがここにいてくれることを心から歓迎します。"

    # say L65 pla
    old "(Yes! This is the perfect chance to get closer to them...)"
    new "はい！これで彼らとより近づける絶好の機会だな。"

    # say L66 pla
    old "I'm so glad to hear that, of course I will be more than happy to be here helping and being part of the community."
    new "もちろん喜んで、ここにいて手伝います。コミュニティの一員になれて嬉しいよ。"

    # say L67 pla
    old "I can start whenever you want... Just tell me what to do."
    new "いつでも始めるよ... 何をすればいいか教えて。"

    # say L69 jon
    old "Oh really hun, that's great!"
    new "本当呀、それは素晴らしいわ！"

    # say L70 gra
    old "Well, our main interest is to attract more young people to the community."
    new "私たちの主な関心は、コミュニティに若い人々をより多く引きつけることです。"

    # say L72 jon
    old "That's why we believe that you are the best to help us and with your example and attitude we believe that we will be able to attract many young people."
    new "それが私たちがあなたに協力してほしいと思っている理由です。あなたの姿勢や態度を模範として、多くの若い人を引きつけることができると信じています。"

    # say L73 gra
    old "Even get to have altar girls in the church!"
    new "教会でさえ女の子たちが聖壇奉仕を行うことができるようになるかもしれないわ！"

    # say L74 pla
    old "Wow, that's sounds good, so what do you want me to do?"
    new "Wow、それはいいね。じゃあ、俺に何をやってほしいんだ？"

    # say L75 gra
    old "Well, we have to wait a bit for that. Father Morgan is a bit busy these days and we can't start without him."
    new "まあ、それには少し待つ必要がありますね。Father Morganは最近忙しくて、彼がいなければ始めることができません。"

    # say L76 jon
    old "However, we still need help in other activities. And a young hand would be very useful."
    new "しかし、他の活動でも手助けが必要です。若い手がとても役立つでしょう。"

    # say L77 jon
    old "For example, cleaning the church after every mass is very tiring for just the two of us."
    new "例えば、毎回のミサ後に教会を掃除するのは、私たち二人だけではとても疲れます。"

    # say L80 gra
    old "Perfect! So, you can come every afternoon to help us with the cleaning, the three of us can finish in a jiffy."
    new "Perfect！ それなら、あなたは毎日の午後に来て掃除を手伝っていただけますね。三人でやればすぐに終わりますよ。"

    # say L82 jon
    old "Great, then why don't we start tomorrow, okay?"
    new "いいですね、じゃあ明日から始めましょう、どうしましょう？"

    # say L83 pla
    old "Alright! So I'll be back tomorrow."
    new "わかった！じゃあ、明日また来るよ。"

    # say L84 jon
    old "Thank you so much hun, see you tomorrow!"
    new "ありがとうね、明日会えるの楽しみにしてるよ！"

    # say L85 gra
    old "Bye [pla]"
    new "バイバイ、[pla]"

    # say L86 pla
    old "S-see you Mrs. Jones and sister Grace."
    new "さようなら、ジョーンズさん、そしてグレースさん。"

    # say L102 gra
    old "Oh, hi [pla], you came just in time!"
    new "あら、こんにちは [pla]、ちょうどよかったわね。"

    # say L103 pla
    old "Hi, well, I don't want to leave all the work to just the two of you."
    new "まあ、二人だけにすべての仕事を任せるのはよくないな。"

    # say L104 jon
    old "Oh thank you honey, you are so kind."
    new "あら、ありがとう honey、あなたはとても優しいわ。"

    # say L105 gra
    old "Ok, let me explain you, it's simple, we just have to clean up the church a bit... As you can see, it's a mess!"
    new "では、説明させていただきますね、簡単ですよ。教会をちょっと片付けさえすればいいんです… ご覧の通り、散らかっていますから。"

    # say L106 gra
    old "[pla], pick up papers if you see them on the floor... You know, make the place pretty."
    new "[pla]、床に落ちている紙を拾って……きれいにしようよ。"

    # say L108 jon
    old "And pick up what shouldn't be in the church right now... All those stuff."
    new "そして、教会に今あるべきでないものは片付けてください… そんなもの全部です。"

    # say L110 jon
    old "This will be too easy for you, cleaning won't be an issue..."
    new "これはあなたにとって簡単すぎるわ、掃除なんて問題にならないでしょう…"

    # say L111 pla
    old "Don't worry, I wanna be as quick as possible."
    new "心配しなくていい、できるだけ早くやるから。"

    # say L112 gra
    old "So, hurry up hun, hahaha."
    new "はやくしてね、ははは。"

    # say L124 gra
    old "Oh, hi [pla], How are you today?"
    new "お、こんにちは [pla]、今日怎么样ですか？"

    # say L125 pla
    old "Hi sister Grace, I'm pretty good, thanks for asking."
    new "こんにちは、グレース姉さん、元気だよ、ありがとう。"

    # say L126 jon
    old "Great Hun, are you ready to start with cleaning?"
    new "Great Hun、掃除を始める準備はできていますか？"

    # say L127 pla
    old "Sure, I'm ready to start."
    new "もちろん、始められるよ。"

    # say L128 gra
    old "Perfect, let's start to clean the church."
    new "Perfect、教会の掃除を始めましょう。"

    # say L139 jon
    old "Hi [pla], you came early, I'm waiting for sister Grace, she is with Father Morgan."
    new "こんにちは[pla]、早めに来てくれたんですね。グレースが来るのを待ってるんです、彼女はファーザー・モーガンと一緒にいます。"

    # say L140 pla
    old "Oh, don't worry. I can accompany you in the meantime."
    new "心配しなくていい、その間一緒にいられるよ。"

    # say L141 jon
    old "Oh, thanks hun... I really appreciate your help on this."
    new "あら、ありがとう亲爱的… 早めに来てくれて本当に助かるわ。"

    # say L142 jon
    old "I'm old and you know... I'm not as flexible as I was before."
    new "私は年を取って、もう以前ほど柔軟じゃなくなったのよね。"

    # say L143 pla
    old "Hmm... I'm sorry to hear that... I think you're still young, though."
    new "うーん…それは残念だね…でも、君はまだ若いと思うよ。"

    # say L144 jon
    old "You know, when I look at you... I see a very kind person, you're really nice, dear."
    new "あなたを見ていると、とても優しい人だなって思うの、親愛なる方。"

    # say L145 pla
    old "Haha, thanks Mrs. Jones!"
    new "ははは、ありがとう、ジョーンズ夫人！"

    # say L146 jon
    old "You're like an angel... Sent by God!"
    new "あなたは天使のよう……神様が送ってくださったのね！"

    # say L148 pla
    old "That's very nice of you but I'm just a normal guy..."
    new "そんなに言ってくれて嬉しいけど、ただの普通の男の子さ…"

    # say L149 jon
    old "You know dear... It's like destiny, I think you're here for a reason.."
    new "あなたがここにいるのは運命のような気がするの、親愛なる人… 特別な理由があると思うの。"

    # say L150 pla
    old "Ehm... Really?"
    new "ええ……本当に？"

    # say L152 jon
    old "I've seen what you've done and well... Yeah! I think so..."
    new "あなたがしてきたことを見て、そう思うの… はい！そう思うよ…"

    # say L153 jon
    old "You're very spiritual and you remind me of..."
    new "あなたはとても精神的で、私の夫を思い出させます。"

    # say L154 pla
    old "Remind you of? W- Who?"
    new "誰に似てるって？ W- 誰？"

    # say L156 jon
    old "You remind me of my husband. When he was alive, he was so kind and strong, just like you."
    new "あなたは私の夫を思い出させます。彼が生きていた時、とても優しくて強く、あなたと同じでした。"

    # say L157 jon
    old "He was amazing, I truly miss him."
    new "彼は素晴らしい人でした、本当に彼を懐かしく思います。"

    # say L165 gra
    old "Hey [pla], I didn't know you were here... I see you're very committed to our community. How are you?"
    new "Hey [pla]、ここにいらっさるのを知りませんでした…… コミュニティへのご尽力、ありがとうございます。お元気ですか？"

    # say L166 pla
    old "I'm fine... And you?"
    new "俺は元気だよ… お前は？"

    # say L168 gra
    old "All good!"
    new "全然問題ありません！"

    # say L169 gra
    old "Great! Mrs. Jones? We need to start cleaning, this is really a mess!"
    new "素晴らしい！ジョーンズ夫人？掃除を始めましょう、本当に散らかっていますから！"

    # say L170 jon
    old "Yeah, sure sister Grace..."
    new "はい、そうですね、グレースさん…"

    # say L171 gra
    old "Let's get this done! We have many things to do."
    new "さあ、やってみましょう！やることは山ほどありますから。"

    # say L172 pla
    old "(I have to find the way to get closer to Mrs. Jones...)"
    new "ジョーンズさんに近づく方法を見つけないと……"

    # say L173 gra
    old "[pla]? Are you with us?"
    new "[pla]？一緒にいますか？"

    # say L174 pla
    old "Yeah... Yeah, sure... Let's do it."
    new "うん… うん、そうしよう… 行こう。"

    # say L188 jon
    old "Wow! That was a hard job! I'm exhausted..."
    new "すごい！本当に大変な仕事でした…疲れたわ…"

    # say L189 gra
    old "It was a lot, yeah... "
    new "たくさんありましたね、そうですね…"

    # say L191 jon
    old "sister Grace, I'm gonna go now..."
    new "グラス、今帰るわ…"

    # say L192 gra
    old "Oh, do you have to leave early today?"
    new "あ、今日早々に帰るの？"

    # say L193 jon
    old "Yes, I think it would be nice to spend some time with Billie too, I'll go to see her."
    new "はい、ビリーと過ごす時間も大切だと思ったの。行ってきます。"

    # say L194 gra
    old "Ahh! Of course, Mrs. Jones... Have fun with your granddaughter. I'll be in good hands with [pla] here."
    new "ああ！もちろん、ジョーンズ夫人…。孫娘と楽しんでくださいね。ここに[pla]がいるので安心です。"

    # say L195 jon
    old "You'll, see you sister Grace..."
    new "またね、グレース…"

    # say L197 jon
    old "See you [pla]."
    new "またね、[pla]。"

    # say L198 pla
    old "Bye Mrs. Jones, take care."
    new "さよなら、ジョーンズさん、お元気で。"

    # say L204 gra
    old "You did a great job today [pla]."
    new "今日はよく頑張ったね [pla]。"

    # say L205 pla
    old "Thanks, we all worked really hard."
    new "ありがとう、みんなで本当に頑張ったね。"

    # say L207 gra
    old "I've noticed how spiritual and good you're... I'm a bit embarrased to ask you this but..."
    new "あなたの精神的な姿勢や優しさに気づいています… 少しだけ恥ずかしいのですが、"

    # say L208 gra
    old "But... I would like to ask for your help."
    new "でも…あなたの手伝いが必要なんです。"

    # say L210 pla
    old "My help? Sure, tell me sister Grace. What can I do for you?"
    new "手伝い？もちろんだ、何でも言ってくれ、グレース。君のために何ができるかな？"

    # say L211 gra
    old "W- well... I wanna clean my spirit and my soul... I've been working on this with Father Morgan..."
    new "あのう……私、自分の精神と魂を浄化したいんです……それをファーザー・モーガンと取り組んでいますが……"

    # say L212 gra
    old "But to be honest I think you're much more spiritual than him, perhaps you could help me more..."
    new "でも正直に言うと、あなたは彼よりもずっと霊的な方だと思います。もしかしたら、あなたに助けてもらった方がいいのかもしれませんね…"

    # say L214 pla
    old "(I think see where this is going...)"
    new "なるほど、これの行方を見抜いたような気がする…"

    # say L215 gra
    old "I mean, you did the exorcism... You helped Billie and you're nice with everyone. I can feel your energy is different."
    new "あなたが除霊をしたじゃないですか……ビリーさんを助けてくれて、誰に対しても優しい。あなたのエネルギーが違うと感じます。"

    # say L216 gra
    old "It's divine and sacred."
    new "それは神聖で崇高なものだと思います。"

    # say L217 pla
    old "I'm glad you think that of me and if you truly believe I could help you out, I'll do it..."
    new "君がそう思ってくれて嬉しいし、本当に俺が君を助けることができるって信じてるなら、やってみるよ…"

    # say L218 gra
    old "I feel a bit embarrassed, I'll do what I believe is good and saint, and I'm thinking of you as a blessed man..."
    new "少し恥ずかしいですが、私が良いと思うことをします。そしてあなたを祝福された方として思っています…"

    # say L219 gra
    old "I'll be honest with you... Since I saw you performing the ritual with Billie, I have been constantly thinking of you."
    new "正直に言うと……ビリーとの儀式を見た後から、あなたのことばかり考えています。"

    # say L223 gra
    old "I feel like you can help me as you helped her. You saved her and you could save me too."
    new "あなたが彼女を助けてくれたように、私を助けてくれると思います。あなたが彼女を救ったように、私を救うこともできるでしょう。"

    # say L224 pla
    old "(Wow) O- ok..."
    new "お、そうか…"

    # say L225 gra
    old "I need to cleanse my soul."
    new "私の魂を浄化する必要があります。"

    # say L226 gra
    old "I would need to go down on you."
    new "私があなたの下にしゃがんで舌を進めなければなりません。"

    # say L228 pla
    old "W-What? D-down?"
    new "W-何？ D-下って？"

    # say L229 gra
    old "I have to pray in a different way."
    new "私は別の方法で祈らなければなりません。"

    # say L231 pla
    old "A- Are y- you s- sure about that?"
    new "A- 本当にそれでいいのか？"

    # say L232 gra
    old "You helped Billie and everytime I'm next to you, I can feel your divine and strong energy."
    new "あなたがビリーを助けてくれて、そして私が近くにいるたびに、あなたの神聖で力強いエネルギーを感じることができます。"

    # say L233 gra
    old "W- Would you please... L- let me suck your... D- dick?"
    new "グレイス：あのう、もしよろしければ…… あなたの…… その、ちんちんを、吸わせていただけますか？"

    # say L235 pla
    old "(This is really in line with the plan, I should do whatever it takes.)"
    new "これは計画通りだ、何が必要でもするつもりだ。"

    # say L236 pla
    old "S- sister Grace... I'll always do what is required to help you and to help the church's community."
    new "姉Grace… 私はいつでもあなたと教会のコミュニティを助けるために必要なことをするよ。"

    # say L237 gra
    old "I will really appreciate your help."
    new "あなたの助けが本当にありがたいです。"

    # say L251 gra
    old "Wow, I do feel much better now, kinda renewed. I'm your faithful devotee."
    new "Wow、本当に元気になりました。まるで生まれ変わったみたい。私はあなたの忠実な信者です。"

    # say L252 gra
    old "I would do everything for you as you have done everything for our community."
    new "あなたがコミュニティのために尽くしてくださったように、私はあなたのために何でもします。"

    # say L253 pla
    old "(Oh hell! She really liked it.)"
    new "おっ！本気で気に入ったみたいだな。"

    # say L254 pla
    old "You don't have to... I'm glad to help sister Grace..."
    new "君がそんなにしてくれなくても… 姉さんグレースのために手伝うのは嬉しいよ…"

    # say L256 gra
    old "And you're so humble..."
    new "そしてあなたはとても謙虚で…"

    # say L257 gra
    old "I feel a bit embarrassed now, I've kept you here for quite a long time. I'm sure you have to rest."
    new "今さら少し恥ずかしいですが、長時間お付き合いしてしまって。きっとお休みになりたいでしょうね。"

    # say L259 pla
    old "Actually, yes, I do but it's fine."
    new "実際、そうだけど大丈夫だよ。"

    # say L260 gra
    old "Thank you so much."
    new "ありがとうございます。"

    # say L261 pla
    old "Hmm ok... I- I think should go..."
    new "うん、そうだな… 行くべきだな…"

    # say L262 gra
    old "Yeah, of course, I have to go as well, see you [pla]."
    new "はい、そうですよね。私も行かないとね、また会おう [pla]。"

    # say L263 pla
    old "See you sister Grace."
    new "またね、グレース姐さん。"

    # say L280 jon
    old "I'm more tired than last time... And my back is killing me."
    new "私は前よりも疲れていて……腰が痛くてたまらないんです。"

    # say L281 gra
    old "Ohh, I'm so sorry Mrs. Jones... [pla] could you please take Mrs. Jones to her house?"
    new "あら、すみません、ジョーンズ夫人… [pla] ジョーンズ夫人を家までお送りいただけますか？"

    # say L282 pla
    old "Of course, I'll be happy to do it."
    new "もちろんです、喜んでやりますよ。"

    # say L283 jon
    old "Oh no, it's not necessary, don't worry..."
    new "いえいえ、そんなに気を遣わなくてもいいんです、心配しないでください…"

    # say L284 gra
    old "Mrs Jones, I inssist... [pla], she lives pretty close to the church."
    new "Mrs Jones、私が行く insistence... [pla]、彼女は教会から近いところに住んでいますので。"

    # say L285 pla
    old "Alright, I will go with you Mrs. Jones, it's not a problem."
    new "分かりました、Mrs. Jones、一緒に参りますね。問題ありませんよ。"

    # say L286 jon
    old "Hmm alright, but just this time."
    new "はmmm、いいわ、でも今回はだけね。"

    # say L287 pla
    old "Sure, don't worry."
    new "大丈夫、心配しないで。"

    # say L288 gra
    old "Ok guys, see you tomorrow. Hope you get better, Mrs. Jones."
    new "皆さん、また明日ね。ジョーンズ夫人、お大事に。"

    # say L289 jon
    old "Thank you honey."
    new "ありがとう、ハニー。"

    # say L295 jon
    old "I'm so glad you could come with me."
    new "あなたが来てくれて本当に嬉しいです。"

    # say L296 pla
    old "My pleasure Mrs. Jones."
    new "喜んでいただきます、Mrs. Jones。"

    # say L297 jon
    old "Come inside with me... Let me give you something to drink."
    new "中に入ってください… 私が何か飲み物をご用意しますね。"

    # say L298 pla
    old "Hmm... Yes, why not?"
    new "うーん… そうか、なぜしないだろう？"

    # say L304 jon
    old "By the way, I'm still surprised at how similar you're to my husband when he was young."
    new "それにしても、あなたが私の若い頃の夫に似ているのは驚いています。"

    # say L305 pla
    old "Oh, really? I imagine how great he was."
    new "ほんと？俺も彼がどれだけカッコよかったか想像できるよ。"

    # say L306 jon
    old "He was... So strong and manly."
    new "彼は……とても強く、男らしかったです。"

    # say L307 jon
    old "Just like you..."
    new "あなたみたいでしたね…"

    # say L310 jon
    old "Hmm... I don't wanna put you in an uncomfortable position... Tell me more about yourself, we haven't talked about your spiritual development."
    new "うーん……あなたを不快な立場に追いやりたくありません……もっと自己紹介を聞かせてください、あなたの精神的な成長についてまだ話していないですね。"

    # say L311 pla
    old "(Actually, there is no a spiritual development...)"
    new "実際には、霊的な成長なんてないんだよ..."

    # say L312 pla
    old "Ahhh! Well... It started- hmm, one day when I was walking and... Suddenly I felt the light, like a warm light all around my arms... Yeah, it was something like that."
    new "あー！ええと... ある日歩いているときに... 突然周りが暖かい光で包まれたんだ... うん、そんな感じだった。"

    # say L315 jon
    old "I asked because I want you to be my spiritual guide, I want to feel the grace of God within me. "
    new "私はあなたの霊的なガイドになってほしいんです、神様の恵みを感じたいから。"

    # say L316 pla
    old "Your spiritual guide? Ok, but how do you think I could help you?"
    new "君のスピリチュアルガイドか？　いいけど、どうやって手伝えると思う？"

    # say L318 jon
    old "Well... The first time I saw you, I felt really impressed by your beauty. You're extremely handsome."
    new "ええ……初めてあなたを見たとき、あなたの美しさに本当に感動しました。あなたはとてもハンサムですね。"

    # say L319 jon
    old "And as I told you the other day... You remind me of my great husband."
    new "そして先日もお話しした通り……あなたは私の素晴らしい夫を思い出させます。"

    # say L322 jon
    old "You know, when I look at you... I see that you could be my savior as he was years ago."
    new "あなたを見ていると、彼が昔私を救ってくれたように、あなたも私を救う存在になるのかもしれないと思うの。"

    # say L323 pla
    old "Y- your savior? What do you mean Mrs. Jones?"
    new "あなたの救世主ってどういう意味ですか、Mrs. Jones？"

    # say L324 jon
    old "Well, I know I look old but I have the needs of a young woman."
    new "まあ、見た目は年取って見えますが、若い女性のような欲求はありますよ。"

    # say L325 pla
    old "Needs? Which type of needs?"
    new "ニーズ？どんな種類のニーズ？"

    # say L326 jon
    old "Don't you imagine which needs I have? It's really easy to guess, I'm a widow."
    new "私のニーズを想像できないの？当てはまるのは簡単よ、私は未亡人だから。"

    # say L327 pla
    old "I- I... Don't k- know if I- I am thinking wrong..."
    new "俺、俺が……君がどんなニーズを持ってるのか、正直、間違ってるんじゃないかと……"

    # say L328 jon
    old "I need a man in my life, I need to feel some adrenaline and you're like send by God... You're beautiful on the inside and outside."
    new "私の人生に男性が必要なの、アドレナリンを感じたいのよ、あなたは神様が送ってくれたみたい……内も外も美しいわ。"

    # say L330 jon
    old "You're like a saint man and I believe in you since you helped Billie... I truly believe you can guide my spiritual journey."
    new "あなたは聖人のような方で、ビリーを助けてくれたからあなたを信じています…… 私の精神的な旅を導いてくれると本気で信じています。"

    # say L331 pla
    old "What? Me?"
    new "何？僕？"

    # say L332 jon
    old "Yes, you! I saw how you cured my granddaughter and I am not planning to let you go."
    new "はい、あなたよ！孫娘を治したあなたの姿を見て、あなたから離れるつもりはありません。"

    # say L333 jon
    old "Not without a taste of what is divine... I want you to be my holy savior until I feel what Billie felt."
    new "それなしではダメよ……私はあなたに、ビリーが感じたものを味わうまで、私の聖なる救世主であってほしいの。"

    # say L335 pla
    old "I- I don't know what to say... I mean, you're such a beautiful woman but... I don't know..."
    new "い、いきなり何て言ったらいいかわからない…… 僕は、あなたがとても美しい女性だとは思うけど…… でも、正直なところ、わからない……"

    # say L336 jon
    old "You already have the answer... Follow the will of God, you know this is the right thing to do, handsome."
    new "あなたには答えが Already あるわ… 神の意志に従うべきだと思うわ、これが正しいことだって、ハンサム。"

    # say L337 pla
    old "(Ok, I think this can help me to do the ritual.)"
    new "分かった、これなら儀式をうまく行えそうだ。"

    # say L338 pla
    old "Yes, if that is what you need, I'll do what is required. I'll follow God's will."
    new "そうだ、それが君が必要なら、必要なことをするよ。神の意志に従うさ。"

    # say L339 jon
    old "I have no doubts... You were sent to clean my sins like I used to do with my husband..."
    new "私は疑いありません…あなたは私の罪を清めるために送られてきたのね、私が以前に夫に対してしていたように…"

    # say L340 pla
    old "What would you like to do that reminds you of him?"
    new "何をすればいいのかな、彼のことを思い出させてくれるようなことをしてあげるよ。"

    # say L341 jon
    old "Well, I would love to start by putting your dick inside my mouth and then brushing it with my sinful lips..."
    new "WELL、あなたのペニスを私の口に入れて、罪深い唇で磨くのはどうかしら…"

    # say L342 pla
    old "... I guess God will be happy with that..."
    new "... 神様も喜ぶだろうな..."

    # say L344 jon
    old "I want to have your sacred presence on my lips and keep the taste on my tongue..."
    new "あなたの聖なる存在を私の唇に感じて、その味を舌に残したいんです…"

    # say L345 pla
    old "(Maybe this is getting a bit out of hand?)"
    new "（もしかして、これはちょっと手が滑って…"

    # say L360 jon
    old "That was incredible, you're a divine presence in my life and well..."
    new "それは素晴らしい体験でした、あなたは私の人生における神のような存在ですね……"

    # say L361 jon
    old "I do feel so renewed and younger now."
    new "私、本当に若返ったような気がします。"

    # say L362 pla
    old "Hmm... I just did what God told me to do... It was my pleasure to help you."
    new "うーん……神様が教えてくれたことをしただけさ……君を助けるのは pleasure だったよ。"

    # say L363 jon
    old "Did you enjoy it? Isn't?"
    new "楽しんだでしょう？"

    # say L365 jon
    old "Oh no hun! I'm sorry, I know this is just part of your holy duty... I shouldn't ask those things."
    new "ああ、ごめんなさい hun。これはあなたの聖なる務めの一部だと知っているから… 私がそんなこと聞くべきじゃなかったわ。"

    # say L366 pla
    old "Y- Yes Mrs. Jones, it's m- my d- duty."
    new "はい、ジョーンズ夫人、それは私の務めです。"

    # say L367 pla
    old "I should go now... It's getting late."
    new "行かないと……時間が遅くなってきた。"

    # say L369 jon
    old "Go with God, handsome... And thanks again. I'll be eager for more."
    new "神様と一緒にお行きなさい、ハンサムさん… またありがとう。次も楽しみに待ってるわ。"

    # say L370 pla
    old "S- sure, goodbye Mrs. Jones."
    new "はい、じゃあさよなら、ジョーンズ夫人。"

    # say L386 gra
    old "It was nice, now the church looks much better."
    new "きれいになりましたね、教会もずいぶん良くなりました。"

    # say L387 pla
    old "It looks better now..."
    new "今ではよくなりましたね…"

    # say L389 jon
    old "It's tiring to clean... "
    new "掃除するのは疲れるわね…"

    # say L390 jon
    old "I'll see tomorrow... I gotta go now."
    new "明日見ることに… 今から行かないと。"

    # say L391 pla
    old "See you Mrs. Jones..."
    new "またね、ジョーンズさん…"

    # say L392 gra
    old "Take care, dear."
    new "お元気で、親愛なるあなたに。"

    # say L399 gra
    old "I'm glad it's just the two of us now."
    new "二人きりになれて嬉しいです。"

    # say L400 pla
    old "Hmm... Yeah, it's nice."
    new "うん… そうですね。"

    # say L401 gra
    old "[pla] I have to tell you something."
    new "[pla] 私に言わなければならないことがあります。"

    # say L403 gra
    old "I think shouldn't feel so good when I'm with you... I should pay with pain, I should suffer..."
    new "あなたと一緒にいるのがこんなに気持ちよくてはいけないと思うの… 痛みで償って、苦しむべきなのに…"

    # say L406 gra
    old "I have never felt so much grace within me, my body feels renewed."
    new "私はこれまでにこんなに恵まれた気持ちになったことはありません、私の体が再生されたように感じます。"

    # say L407 gra
    old "But I'm not sure if that is ok... A spiritual journey requires suffering and I do not feel that it's fair just to feel pleasure and purification through you."
    new "でもそれがいいのかどうかわからないの…… 精神的な旅には苦しみが必要なのに、あなたを通じてただ喜びと浄化を感じるのは公平じゃないわ。"

    # say L408 gra
    old "I need you to punish me, I have to do penance..."
    new "あなたに罰してほしいの、贖罪しなきゃいけないの…"

    # say L409 pla
    old "W-what?"
    new "何言ってるんだ、グラ？"

    # say L410 gra
    old "Yes, I know is what God wants and I know that with pain I will purify my soul..."
    new "はい、神様が望んでいることを知っていますし、痛みで魂を浄化できると信じています…"

    # say L412 gra
    old "But I need you to guide and help me... Since you have given me so much purification, you should be the one punishing and showing me the way..."
    new "でも、あなたに導いてもらって、助けてもらいたいんです… あなたが私にそんなに浄化を与えてくれたのだから、罰を与え、道を示してくださるべきだと思います…"

    # say L414 pla
    old "A- alright... B- but, h- how?"
    new "あー、わかった……けど、どうやって？"

    # say L415 gra
    old "You're like my master. I need you to see me as your sinful slave who needs to come out of the dark side."
    new "あなたは私のような存在です。罪深い奴隷としての私が必要とするように、暗闇から這い出すための私の姿を見つめてほしいんです。"

    # say L417 gra
    old "As I get naked, I know that God will enlighten you and act through you for your guidance."
    new "裸になることで、神様があなたを啓示し、あなたの手を借りて導いてくださることを感じます。"

    # say L419 gra
    old "He'll tell you what to do..."
    new "彼はあなたに何をすべきか教えてくれるでしょう…"

    # say L420 gra
    old "Please! The pain and pleasure will go away but my submission and loyalty to you will remain eternally in my soul... I need it."
    new "お願いします！痛みも快感も消えますが、私の魂には永遠にあなたのための従順と忠誠が残ります…必要なんです。"

    # say L421 pla
    old "If that's what you need, I'll do it."
    new "もし君が必要なら、やってあげるよ。"

    # say L435 gra
    old "I would like to thank you... You can't imagine how important this was to me."
    new "感謝したいと思います……これがあなたにとってどれほど重要だったか、想像もつきません。"

    # say L436 pla
    old "I- I am glad, sister Grace."
    new "嬉しく思うよ、グレース姉さん。"

    # say L437 pla
    old "I should go now, I have to be home soon..."
    new "今すぐ帰らないとダメだな。"

    # say L439 gra
    old "Alright! I have to go as well. I'll be thinking of your great and massive..."
    new "わかった！私も帰らないと。あなたの偉大で壮大な…"

    # say L440 gra
    old "... Spirit and soul."
    new "あなたの素晴らしい精神と魂を思いつつ。"

    # say L456 lin
    old "hi [pla], how are you?"
    new "元気ですか、[pla]？"

    # say L457 pla
    old "Hey! I'm fine... What about you?"
    new "おう！ 元気だよ… お前は？"

    # say L459 pla
    old "I'm working on it, you don't need to worry about it, I'll do it and everything will be fine."
    new "心配するな、ちゃんとやって大丈夫だよ。"

    # say L460 lin
    old "Alright! I just wanna make sure you have everything ready because we're running out of time..."
    new "分かった！ただ、時間がないからちゃんと準備できてるか確認したいだけよ…"

    # say L462 pla
    old "Hmm, okay, I'll have to rush the plans ... "
    new "うーん、そうか、計画を急ぐしかないな……"

    # say L463 lin
    old "Great, and who will be with you in the ritual? Which humans?"
    new "Great、そして儀式に誰が一緒に行くの？どの人間たち？"

    # say L464 pla
    old "Mrs. Jones and the sister Grace, they both have a lot of accumulated energy."
    new "ジョーンズ夫人とグレースだ、二人ともかなりのエネルギーを蓄積してる。"

    # say L465 lin
    old "Do they know what they have to do?"
    new "彼らは自分が何をしなければならないか知っているのか？"

    # say L467 pla
    old "Well, not yet... But they'll do it, I have been working on getting closer to them and it's going better than I expected."
    new "まだ気づいてないけど…でも大丈夫、俺は彼女たちとの距離を縮めるために頑張ってて、思ってたより上手くいってる。"

    # say L468 lin
    old "Ok, I don't wanna put more pressure on you but we have to... We do need that energy to perform the ritual."
    new "分かってる、でも君に余計なプレッシャーをかけたくはないけど、そのエネルギーは必要なんだ。儀式のためにね。"

    # say L470 pla
    old "I know! In fact, I'm going to talk to them and get everything ready..."
    new "分かってる！実際、話して準備を整えるつもりだ..."

    # say L472 lin
    old "Ok, since you have everything almost ready for the ritual... I wanna share some energy with you."
    new "それなら、儀式の準備もほぼできてるみたいだから……エネルギーを分かち合いたいの。"

    # say L474 pla
    old "S- Sure... Let's do it!"
    new "わかった… 行こう！"

    # say L475 lin
    old "All right, get naked and lie on the bed... "
    new "じゃあ、裸になってベッドに寝て……"

    # say L489 lin
    old "It's done, go and prepare everything for the ritual! "
    new "準備はできてるから、儀式のためのものは全部用意してきな！"

    # say L490 pla
    old "Got it, thanks, see you!"
    new "分かった、ありがとう、またね！"

    # say L491 lin
    old "See ya..."
    new "じゃあね..."

    # say L492 lin
    old "The best of luck!!! I'm so excited for you..."
    new "頑張ってね！！！ 私、めっちゃ楽しみにしてるよ..."

    # say L507 pla
    old "Hi sister Grace, I'm ready to start cleaning..."
    new "こんにちは、グレース姉さん、掃除の準備ができました…"

    # say L508 gra
    old "It's so nice to see you, hi [pla]... Actually we don't have to clean today..."
    new "お久しぶりですね、こんにちは [pla]… 実は今日の掃除は不要なんです…"

    # say L510 gra
    old "We have some issues now..."
    new "今いくつかの問題が起こっていますね…"

    # say L511 gra
    old "[pla]... Your help it's been exceptional, I'm so grateful with you."
    new "[pla]… あなたの助けは本当に素晴らしいです、感謝しています。"

    # say L513 pla
    old "It's what God wants me to do... I could help even more if needed."
    new "神様が僕にそうしたいって思ってるんだ… 必要ならもっと手伝えるよ。"

    # say L515 gra
    old "Well... Now that you mentioned it, I need you to do something..."
    new "ええ……そう言われて思い出したわ、あなたに頼みたいことがあるの……"

    # say L516 pla
    old "(Not punishment, please!)"
    new "罰じゃなくて、お願い！"

    # say L517 pla
    old "Hmm, tell me sister Grace, what can I do for you?"
    new "うーん、グレース姉さん、何をお手伝いできるのか教えて？"

    # say L518 gra
    old "Mrs. Jones is feeling a bit sick but I can't go to see her...  I can't leave the church right now. Would you please stop by her house to see how she's doing?"
    new "ジョーンズ夫人が少し具合が悪そうなのですが、私が行けないんです… 教会を離れられない状況でして。もし可能であれば、彼女の家に寄って様子を見てあげられますか？"

    # say L519 pla
    old "I'm so sorry she's sick... I'll go right now."
    new "すみません、具合が悪いなんて…今すぐ行きます。"

    # say L520 gra
    old "Thanks dear [pla]... Call me if you need anything, alright!"
    new "ありがとう、親愛なる[pla]… 必要なことがあったら私に連絡してね、いいわよ？"

    # say L524 pla
    old "(I hope she's not that sick... I'll need her for the ritual)"
    new "彼女がそんなに具合が悪いとは思えないな…でも儀式には必要なんだ。"

    # say L525 pla
    old "(Hmm... Actually, before I go... I should definitely talk to the nun about the ritual...)"
    new "（うーん……実は、行く前に……修道女と儀式について話すべきだな……）"

    # say L529 pla
    old "Sister Grace? Sorry! Hmm... I wanna tell you something before I go..."
    new "グレース姉さん？すみません！あのさ、行かなきゃなんだけど、それ前にちょっと話しておきたいことがあるんだ…"

    # say L530 gra
    old "Yeah? Tell me [pla]... What's that?"
    new "はい？[pla]... 何をお話ししたいんですか？"

    # say L531 pla
    old "You said you were my faithful devotee and you would always be loyal to me, right?"
    new "君が俺の忠実な信者だと言ってくれたよね？そして、俺に常に忠誠を尽くすって約束してくれたんだよな？"

    # say L532 gra
    old "Yes, of course. After all you've done to me and for me, I would do anything for you."
    new "はい、もちろんです。あなたが私にしてくださったこと、私のためにしてくださったことを思うと、何でもします。"

    # say L533 pla
    old "Well... I have to do a spiritual ritual, it's very important and it has to be done here at the church... And I would like you to help me to perform it."
    new "WELL... 精神的な儀式をしなきゃならないんだ、すごく重要で、それを教会でやらなきゃいけないんだ... それに君の手伝いが必要なんだ。"

    # say L534 gra
    old "Yes, I'm not even gonna question you about it, as a submissive being to your will, I will always be at your service."
    new "はい、あなたが何をしようとしているのかは問いただしません。あなたの意志に従う存在として、私はいつでもあなたの役に立つつもりです。"

    # say L535 pla
    old "Well! That's great, thanks! I knew I could count on you."
    new "よし！ありがとう！君の協力が頼りだったよ。"

    # say L536 pla
    old "I need you to make sure the church is empty at night, we can't allow sinful people to be here..."
    new "教会が夜に空いていることを確認してくれ、罪深い人がここにいるのは許さないんだ。"

    # say L538 gra
    old "I'm always obedient to God and to you."
    new "私は常に神様とあなたに従います。"

    # say L539 pla
    old "Hmm by the way... We won't be alone, one more person will join us, you already know her and I'm sure you'll do great during the ritual."
    new "まあそういえば… 君と僕以外にもう一人参加するんだ、君も知ってる人で、儀式ではきっと上手くいくよ。"

    # say L540 gra
    old "One more person? Who?"
    new "もう一人？誰ですか？"

    # say L541 pla
    old "Trust me... You know I'm the hand of God."
    new "信じろ……神の手だということは知ってるだろう？"

    # say L542 gra
    old "I'm so sorry!"
    new "申し訳ありません…"

    # say L543 pla
    old "Just make sure the place is ready..."
    new "ただ場所の準備をしておいてくれよ…"

    # say L545 gra
    old "I'll do everything to please you."
    new "私が喜ばせるために何でもします。"

    # say L547 pla
    old "You're great! I'll go now since we need to know how Mrs. Jones is..."
    new "君が凄いな！俺は行ってくるよ、Mrs. Jonesの状態を確認しないと..."

    # say L548 gra
    old "Go with God..."
    new "神に導かれろ..."

    # say L553 pla
    old "Hello? Mrs. Jones? "
    new "こんにちは？ ジョーンズ夫人？"

    # say L555 pla
    old "Are you here?"
    new "ここにいるの？"

    # say L556 jon
    old "Dear? [pla]?"
    new "亲爱的、[pla]？"

    # say L557 jon
    old "Come here, handsome..."
    new "来てちょうだい、ハンサムさん..."

    # say L565 jon
    old "Hi dear, I was waiting for you..."
    new "こんにちは親愛なる方、あなたを待っていましたよ…"

    # say L567 pla
    old "Wow! Mrs. Jones what are you wearing?"
    new "Wow！ ジョーンズさん、その格好は…？"

    # say L576 jon
    old "I'm so happy you're here... How are you, handsome?"
    new "あなたがここにいてくれて嬉しいの... 元気ですか、ハンサム？"

    # say L577 pla
    old "H- hi Mrs. Jones, I'm fine... But tell me how are you feeling?"
    new "こんにちは、ジョーンズさん、元気です…でも、具合はどうですか？"

    # say L578 pla
    old "The sister Grace told me you have been quite sick..."
    new "グレースの妹によると、あなたはかなり具合が悪かったそうですね…"

    # say L579 pla
    old "But you look d- different..."
    new "でも君は違うみたいだね…"

    # say L581 jon
    old "I'm fine as you can see... Maybe a bit hot ..."
    new "大丈夫ですよ、見ての通りです…少し熱いかもしれませんけど…"

    # say L583 jon
    old "You should enjoy what you're seeing right now... As much as I'm enjoying having you here."
    new "あなたが今見ているこの姿を楽しんでください…… 私もあなたがここにいてくれることをとても楽しんでいますから。"

    # say L585 pla
    old "M- mrs. Jones, why are you wearing that?"
    new "ジョーンズ夫人、なぜそんな格好をしてるの？"

    # say L586 jon
    old "Well, You were the one bringing me this dress time ago... You made me remember my younger years with my husband..."
    new "あのね、このドレスをくれたのはあなたよ... 若い頃の主人との思い出が蘇ってきて..."

    # say L587 jon
    old "I used to wear a similar dress to this one and my husband used to devore me with his hands..."
    new "このようなドレスを着ていたとき、夫は私を手で貪るように愛したのを思い出したの..."

    # say L588 jon
    old "We liked rough sex... You know..."
    new "荒いセックスが好きだったの……知ってるでしょ……"

    # say L589 pla
    old "(W- What?)"
    new "（え、何を言ってる？）"

    # say L590 jon
    old "I forgot you're a bit shy sometimes... But perhaps you forgot I'm not and I want to have you now!"
    new "あなたが時々恥ずかしがることを忘れてたの…でも私が遠慮しないことと、今すぐあなたがほしいことも忘れちゃった？"

    # say L593 jon
    old "I'll take the initiative... I know you like when your cock is between my lips."
    new "私が先に動くわ… あなたのコックが私の唇の間にあって、それが好きだって知ってるわ。"

    # say L594 jon
    old "And I know you're getting hard as fuck right now... Just let me take off your pants, handsome."
    new "そして今、あなたはもうフル勃起してるってことも知ってるわ… ただパンツを脱がせて、ハンサム。"

    # say L608 jon
    old "I'm feeling much better now... I should say thank you..."
    new "ずいぶんよくなったわ... ありがとうと言わなくちゃね..."

    # say L609 pla
    old "(Hmm sure...) I hope you're much better now."
    new "うん、そうだろうな… ずいぶん元気になったらいいんだけど。"

    # say L610 jon
    old "Totally hun... Thanks for passing by..."
    new "全然啦、 honey... ありがとうね、通りがかったおかげで..."

    # say L611 pla
    old "Hmm... Mrs. Jones, I actually wanted to ask you a favor..."
    new "ジョーンズさん、実はお願いがあって..."

    # say L613 jon
    old "A favor? Sure, anything for you, love..."
    new "お願いですか？もちろん、何でもしますよ、 Darling..."

    # say L614 pla
    old "I'll have to perform a ritual at the church to clean the energies..."
    new "教会でエネルギーを浄化する儀式を行わなきゃならないんだ…"

    # say L615 pla
    old "And since we're closer now and you know that I've such a spiritual development, I would like you to be part of that ritual."
    new "それから、今さら言うまでもないけど、君が私の精神的な成長を知ってくれてるし、その儀式に君も参加してほしいんだ。"

    # say L616 pla
    old "Sister Grace would be there, you and me... Would you help me? "
    new "グレース姉さんもいるし、君と二人で……手伝ってくれるかな？"

    # say L618 jon
    old "You've done so much for me, hun... I already told you, I would do whatever you ask me to do. You can count on me for it."
    new "あなたがこんなにたくさんしてくれて、ありがとう、 honey… すでに言ったでしょ、あなたが頼むことなら何でもするわ。それを絶対に手伝うから。"

    # say L619 pla
    old "Thanks Mrs. Jones, I didn't expect less from you..."
    new "ありがとうございます、ジョーンズさん。君ならそうしてくれると思ったよ。"

    # say L620 pla
    old "I'll see at the church, now I should go..."
    new "教会で会おう、今行くべきだね..."

    # say L621 jon
    old "See you there, handsome."
    new "教会でまた会いましょう、ハンサムさん。"

    # say L637 pla
    old "Ok... Today is the ritual day!"
    new "今日が儀式の日だな..."

    # say L638 lin
    old "And you'll be great, we count on you..."
    new "あなたが素晴らしいことを知っています、私たちはみんなあなたに期待していますよ…"

    # say L639 pla
    old "I know Linett, I've everything ready and well... It'll be fine."
    new "知ってるよリネット、全部準備できてるし…大丈夫だよ。"

    # say L640 lin
    old "[pla] make sure you have sex with both, the nun and the older woman, it's extremely important to get energy from both. I'll be there with you..."
    new "[pla] 二人ともとセックスしてね、修道女と年上の女性からエネルギーをもらうことがとても重要なんだよ。私が一緒にいるから安心して。"

    # say L641 pla
    old "Great! I didn't know you were coming with me..."
    new "グレート！君が来るとは知らなかったんだ..."

    # say L643 pla
    old "Ohh! Ok..."
    new "オッ！わかった…"

    # say L644 lin
    old "So are you ready... We gotta start the ritual now."
    new "準備できてる？　今から儀式を始めるんだよ。"

    # say L645 pla
    old "Yeah... Let's do it!"
    new "よし…やろう！"

    # say L651 pla
    old "Oh, they are back there..."
    new "ああ、彼らもいたのか…"

    # say L652 pla
    old "Great! It's time to start the ritual."
    new "よし！儀式を始める時が来たな。"

    # say L662 pla
    old "Mrs. Jones, sister Grace... Hi, I'm glad you both are here..."
    new "ジョーンズさん、グレースさん… こんにちは、二人とも来てくれて嬉しいです。"

    # say L663 jon
    old "Good night hun."
    new "おやすみなさい、ハニー。"

    # say L664 gra
    old "Hi [pla], it's a pleasure to be here with you."
    new "こんにちは[pla]、あなたと一緒にいられて光栄です。"

    # say L671 pla
    old "Billie? W- What are you doing here?"
    new "ビリー？　ワ、何してるのここに？"

    # say L672 jon
    old "Oh, I invited her... As you said you are going to clean the bad energies I thought it would be a great idea to invite Billie..."
    new "Oh、私が彼女を招待したの…… 先生が悪いエネルギーを浄化するとおっしゃったので、ビリーを連れてくるのがいいアイデアだと思ったんです……"

    # say L673 pla
    old "W- what? B- but she doesn't know what we are going to have se- ... An important ritual..."
    new "ワッ、何だよ？でも彼女は私たちがセ-… 重要な儀式をするって知らないじゃん。"

    # say L674 jon
    old "Oh, don't worry hun, I already explained it to her, she was really worried about her sexorcis-... I mean exorcism."
    new "あら、心配しないで親愛、もう説明してあげたから。彼女も自分のセクソルシズム…って言いたかったの、心配してたのよ。"

    # say L675 bil
    old "I wanted to come... I never thought that I could be religious having sex."
    new "来たいと思ったの... 性行為をしながら宗教的になれるとは思わなかったわ。"

    # say L676 bil
    old "And I wanna thank you for what you did for me as well..."
    new "そして、私にもしてくださったこと、感謝しています…"

    # say L677 pla
    old "Hmm alright... I- I see..."
    new "うん、そうか… 分かった…"

    # say L678 lin
    old "{i}Pstt... [pla], we are running out of time... Start now!{/i}"
    new "{i}pstt… [pla]、時間がないわ… さっさと始めるの！{/i}"

    # say L679 pla
    old "(Oh shit, she is right.)"
    new "おっ、彼女は正しいんだ。"

    # say L680 pla
    old "Well ladies, this is a spiritual ritual in which we all will do a transfer of spirituality among us..."
    new "WELL LADIES、これはみんなで互いにスピリチュアルなものをやりとりする儀式なんだ…"

    # say L681 pla
    old "I've noticed how spiritual you all are and that's why I've chosen you for this."
    new "君たちのスピリチュアルさに気づいて、だから君たちを選んだんだ。"

    # say L682 pla
    old "We'll have to open our hearts to God and give to each other what's required..."
    new "神に心を開いて、必要なものを互いに与え合うんだよ…"

    # say L683 jon
    old "I can't wait to do it... You have all of me for this..."
    new "待ち遠しいです……これに全てを捧げます……"

    # say L684 gra
    old "I agree with Mrs. Jones..."
    new "私もジョーンズさんと同じ意見です…"

    # say L685 pla
    old "The better we do it, the better our lives will be in the eyes of God..."
    new "俺たちが上手くやれば、神様の目から見ても俺たちの人生はより良くなるだろう…"

    # say L686 pla
    old "Put all your faith on me and I'll guide through the ritual, it's all about spirituality and love."
    new "君の神への信仰を俺に委ねて、儀式を導いてあげる。これはすべて精神と愛についてだ。"

    # say L687 bil
    old "Can't we just start?"
    new "始めてみない？"

    # say L688 pla
    old "Right, can you turn on the lights before we start?"
    new "そうだな、始める前に灯りをつけてくれるか？"

    # say L696 bil
    old "Let's start with the sex!"
    new "セックスから始めるよ！"

    # say L697 gra
    old "Ahhh."
    new "あーっ。"

    # say L698 jon
    old "Oh dear please calm down..."
    new "あら、落ち着いてください…"

    # say L711 lin
    old "Good job! Now it's my turn!"
    new "よくやった！次は私の番ね！"

    # say L734 pla
    old "W- Well... Thank you... It was an excellent ritual, you all did good and I'm very thankful..."
    new "うーん… ありがとう… 素晴らしい儀式だったね、みんなよくやってくれて感謝してる…"

    # say L735 jon
    old "I'm happy we got to help you and you helped us during this ritual..."
    new "私たちがお互いに助け合えてうれしいです。この儀式で力を貸していただいて、本当に感謝しています。"

    # say L736 bil
    old "It was cool..."
    new "それは良かったわ..."

    # say L737 gra
    old "I feel totally new... Totally different, thanks so much [pla]..."
    new "全く新しい気分です… 全然違う感じがして、本当にありがとう [pla]…"

    # say L738 pla
    old "I'm glad..."
    new "嬉しいよ、グラ..."

    # say L739 pla
    old "I have to go now... "
    new "行かないと…"

    # say L741 gra
    old "See you [pla], I need some rest after this..."
    new "またね[pla]、今日は疲れたから休むわ…"

    # say L742 jon
    old "Goodbye, dear... See you!"
    new "さようなら、親愛なる… また会うわね。"

    # say L748 pla
    old "Linett!?..."
    new "リネット！？…"

    # say L749 lin
    old "Hi... How are you feeling?"
    new "こんにちは… お元気ですか？"

    # say L750 pla
    old "I'm happy, we did it!"
    new "幸せだよ、やったぞ！"

    # say L751 lin
    old "Well... It didn't work..."
    new "ええ……うまくいかなかったの……"

    # say L752 pla
    old "What? Why? What happened?"
    new "何？どうして？何が起きたんだ？"

    # say L753 lin
    old "It simply didn't work... It happens sometimes, it's a complex ritual and well... This time it didn't work..."
    new "うまくいかなかったの…… ときどきあることなの、複雑な儀式だから…… 今回は上手くいかなかったの……"

    # say L754 pla
    old "Really? Now what?"
    new "本当に？じゃあ次はどうすりゃいいんだ？"

    # say L755 lin
    old "There is nothing we can do now... We have to wait until christmas, there is no other way..."
    new "今更何もできないわ… クリスマスまで待つしかないの、他の方法はないから…"

    # say L756 lin
    old "During christmas there is a load of human energy all around and that's the only chance we will have..."
    new "クリスマスには人間のエネルギーが溢れていて、それが唯一のチャンスだから…"

    # say L757 lin
    old "For now there is nothing we can do..."
    new "今は何もできないわね…"

    # say L759 pla
    old "I see... We'll try for Christmas..."
    new "分かった…クリスマスに挑戦するか…"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/BriStory.rpy
translate japanese strings:

    # say L11 pla
    old "I can't believe they were getting freaky in the living room."
    new "リビングでそんなことしてたなんて、信じられない。"

    # say L13 pla
    old "I know they are married but... they should do that in their room..."
    new "結婚してるけど… そんなの部屋でやってくれればいいのに…"

    # say L15 pla
    old "Anyway... let's take a look at this weird book."
    new "まあ……この変な本を見てみようか。"

    # say L17 pla
    old "Let's see what it says..."
    new "見てみようか…"

    # say L19 pla
    old "Expergiscimini defensoris librum... The hell does that mean? Did that airplane came from China?"
    new "エクスペルギスミニ デフェンソリス リブルム… これって何なんだ？ 飛行機が中国から来たのか？"

    # say L26 sap
    old "A TUTELA EXPERGISCIMINI!!!"
    new "ア・タテラ・エクスペルギスミニ！！！"

    # say L28 pla
    old "What the fuck! What is this?!"
    new "何だよ！これは一体何だ？！"

    # say L29 sap
    old "Qui audet excitare me!"
    new "誰が俺を起こすなんて！"

    # say L30 pla
    old "Oh my God! Please don't hurt me. I'm too young to die."
    new "神様！殺さないでくれ。まだ死ぬのには早いよ。"

    # say L31 sap
    old "Latina loqui tibi."
    new "ラテン語で話すって？"

    # say L32 pla
    old "What?  I- I don't understand. Just please don't kill me... I didn't do anything... This thing just fell from an airplane..."
    new "何？　俺、理解不能……ただ殺さないでくれ……何もしてないよ……この本は飛行機から落ちてきたんだ……"

    # say L33 sap
    old "Huh? What fell from an airplane?"
    new "何が飛行機から落ちたって？"

    # say L34 pla
    old "What? Oh, um, yeah! The book... This book fell from an airplane."
    new "何？あ、うん、そう！この本… この本が飛行機から落ちてきたんだ。"

    # say L35 sap
    old "Oooh, hehe. Let's start from the beginning, shall we?"
    new "へへ、じゃあ最初から始めるか？"

    # say L36 sap
    old "Nice to meet you!  My name is Brixxida."
    new "はじめまして！ 私の名前はブリクシダです。"

    # say L42 pla
    old "Bri... xxi... da? Da fuck? Do you speak English?"
    new "ブリ... クシ... ダ？ 何だよ？ 英語話せるのか？"

    # say L43 bri
    old "Well, yes! I'm speaking it now. Hehe. I can actually speak all human languages..."
    new "ええ、そうよ！ 今英語で話してるわ。へへ。実際、すべての人間の言葉を話せるの…"

    # say L45 pla
    old "Human languages? That's a weird way to say it. What exactly are you?"
    new "人間の言葉？変な言い方だな。君は一体何者なんだ？"

    # say L46 bri
    old "I'm the protective shinigami of the book you have there."
    new "私はあなたが持ってるその本の守護死神だよ。"

    # say L49 pla
    old "OH FUCK! A shinigami? Oh my God..."
    new "OH SHIT！ 死神？冗談じゃないよ..."

    # say L50 pla
    old "I'm so sorry, miss shinigami lady. I just found this on the ground and I picked it up. Brought it home. It looked cool."
    new "すみません、死神さん。これ、道端で見つけて拾いました。家に持って帰ったんだけど、かっこよかったから。"

    # say L52 pla
    old "I didn't mean to-"
    new "俺は故意にはしなかったんだけど、死神さん。"

    # say L53 bri
    old "Calm down, human. Hehe. If you were the one who found and opened the book, it means that you are the 'chosen One'."
    new "落ち着いて、人間。へへ。あなたがこの本を見つけ開いたということは、あなたが『選ばれし者』ということよ。"

    # say L55 pla
    old "Cho-sen-one?"
    new "選ばれし者？"

    # say L56 bri
    old "That's right!  And now the book belongs to you. And that also means I now belong to you. Hehe"
    new "そうだよ！ そして今からはこの本はあなたのもの。それもつまり、私はあなたに属することになるの。へへ"

    # say L58 pla
    old "What? You belong to me?  That means you are not going to kill me?"
    new "何？君が俺のものだって？　それじゃあ殺されないってことか？"

    # say L59 bri
    old "No, of course not. Why would you think that?"
    new "もちろんそうじゃないわ。どうしてそんなこと思うの？"

    # say L61 pla
    old "Because you look like a monster about to devour me."
    new "君がモンスターみたいで、俺を食べちゃいそうに見えたからさ。"

    # say L62 bri
    old "Oh? Sorry about that."
    new "あら？ごめんなさい。"

    # say L68 bri
    old "...Is this form better? Hehe."
    new "この姿のほうがいいの？へへ。"

    # say L77 mo2
    old "Why are you making that face, [pla]?"
    new "なぜそんな顔をしてるの、[pla]？"

    # say L79 pla
    old "[mo2]... It is not what it looks like… I can explain... she is... naked... but she is... a shinigami-"
    new "[mo2]… これは見た目通りのものじゃない…説明できるから…彼女は…裸だけど…でも彼女は…死神なんだ-"

    # say L81 mo2
    old "What?! What are you talking about? Were you watching porn again?"
    new "何？！何を言っているの？またエロ動画を見てたの？"

    # say L83 pla
    old "What? Porn... No. I was just-"
    new "何？ポルノ…違う。ただ-"

    # say L85 mo2
    old "Hmm... probably were. You fucking pervert... I'll just have your [mo1rel] talk to you about this."
    new "へぇ……多分そうね。お前、またエロサイト見てたんでしょ……変態。あなたの[mo1rel]にこの話をさせるわ。"

    # say L87 mo2
    old "Finish whatever you were doing."
    new "やってたこと、終わらせて。"

    # say L94 pla
    old "What the hell? Didn't she see you?"
    new "何だよ？彼女はお前を見なかったのか？"

    # say L104 bri
    old "Only you can see or hear me... And she called you [pla]? Is that your name?"
    new "あなただけが私を見たり聞いたりできるのね… それに、彼女はあなたを[pla]って呼んでたの？ それがあなたの名前？"

    # say L105 pla
    old "Yes, that's my name. And-um, why are you naked???"
    new "うん、それが俺の名前だ。で、あの、なんで裸なん？"

    # say L107 bri
    old "Oh, I'm sorry! Hehe. I took human form to be more familiar to you, but I forgot that humans cover their bodies with 'clothing'."
    new "あら、ごめんなさい！へへ。人間の姿を取って親しみやすくしたかったんだけど、人間が体を服で覆うことに慣れてなかったの。"

    # say L113 pla
    old "Couldn't find anything that covers you a little bit more, huh? But at least nobody can see you. Now tell me again, who are you exactly?"
    new "少しでも隠せるものを見つけられなかったのか？でも少なくとも誰も見てないから安心して。改めて言うけど、君は一体誰なんだ？"

    # say L115 bri
    old "I am Brixxida! A shinigami. I can shift and adapt to the form of any species, although my true form is this... "
    new "私はブリクシダ！死神よ。どんな種族の姿にも変化できるけど、本当の姿はこれ……"

    # say L120 bri
    old "...I am now much smaller, but I like being this size. Much more comfortable. Hehe"
    new "小さくなったけど、このサイズが好き。ずっと楽だよ。へへ"

    # say L128 pla
    old "Ok, ok. I get it now. I'm going crazy. This isn't real. It's a dream! Yeah, that's it! It's a dream..."
    new "分かった、分かった。俺は頭がおかしくなってるんだ。これは現実じゃない。夢だ！そうだ、夢なんだ！"

    # say L130 pla
    old "I fell asleep in class and soon I'm going to wake up... hmmm... I am going to wake up now.... hmmm."
    new "授業中につい眠っちゃって、すぐに目が覚めるはず……うーん……今すぐ目が覚めるんだ……うーん。"

    # say L134 pla
    old "I'm trying to wake up from this dream."
    new "この夢から醒めようとしてるんだ。"

    # say L136 bri
    old "You look wide awake to me, [pla]."
    new "あなた、もう全然眠そうじゃないね、[pla]。"

    # say L138 pla
    old "That's right!  I'm too tired, so I should rest. And tomorrow I will be back to normal."
    new "そうだよ！ 僕は疲れてるから休むべきだ。明日にはまた元に戻ってるさ。"

    # say L140 pla
    old "Yes, yes. I'm going to sleep... "
    new "うん、うん。寝るよ…"

    # say L142 bri
    old "Ok! Goodnight. Hehe."
    new "Ok！ おやすみなさい。へへ。"

    # say L148 pla
    old "Hmm... what a weird ass dream. I gotta lay off playing so many weird visual novels..."
    new "ん〜…変な夢だな。変なビジュアルノベルばっかりやってるからかな…"

    # say L153 bri
    old "What are visual novels?"
    new "ビジュアルノベルって何？"

    # say L156 pla
    old "Oh shit!  You... and you're naked again!"
    new "オッシャイ！　お前……また裸じゃないか！"

    # say L158 bri
    old "Oh, my mistake.  I'm sorry. You humans are very dramatic about this... "
    new "あ、私の間違い。ごめんなさい。あなたたち人間はこれについてすごくドラマティックになるよね…"

    # say L164 pla
    old "Ok, ok. Just explain to me, Brixxida, why did the book fall from the sky?"
    new "よし、よし。ブリクシダ、説明してくれ。なぜその本が空から落ちてきたんだ？"

    # say L166 bri
    old "The book chooses you! Now you are part of a tradition of sorcerers that can use the book's magical powers."
    new "その本はあなたを選んだのです！これからあなたは、その本の魔法の力を扱える魔法使いの伝統の一員になります。"

    # say L168 pla
    old "Magic powers, you say?...  The hell-?"
    new "魔法の力って？… 何言ってんだよ？"

    # say L172 mo1
    old "[pla]?  Are you awake?  Who were you talking to?"
    new "[pla]？起きてるの？誰と話してたの？"

    # say L181 pla
    old "Me? Oh, hmmm, nobody... I'm, uhh... preparing a speech for a class project..."
    new "俺？ああ、うーん、誰とも話してないよ… 今、クラスのプロジェクトのスピー�チの準備をしてるんだ。"

    # say L183 mo1
    old "Very good, [pla]!"
    new "とてもいいですね、[pla]！"

    # say L185 mo1
    old "Listen, I want to talk to you about yesterday... About the living room."
    new "Listen、昨日のリビングでのことについて話したいの……"

    # say L187 pla
    old "Oh, [mo1], I understand. You are a couple I think is perfectly normal... And you are my [mo1rel], you don't have to give me explanations."
    new "オッ、[mo1]、わかったよ。君たちが恋人同士だってことは全然普通だと思ってるし… それに君は私の[mo1rel]だから、説明する必要はないよ。"

    # say L189 mo1
    old "I'm glad to hear that. But... I do want to apologize. We were a bit careless getting... Intimate in the living room."
    new "そう言ってくれて嬉しいです。でも… 謝りたいんです。リビングでちょっと気を許してしまって… すみません。"

    # say L191 pla
    old "Don't worry about it. I actually think it's good that you keep the flame alive in your relationship over all these years."
    new "心配しないで。君たちが長い年月ずっと関係を温め続けているのは、実際よく思ってるよ。"

    # say L193 mo1
    old "Do you really think that? Thank you so much for being so understanding, [pla]!"
    new "本当にそう思ってくれてるの？ ありがとう、理解してくれるなんて。[pla]！"

    # say L195 mo1
    old "Well, I won't bother you anymore. Please keep studying hard, honey, if you need me I will be in kitchen."
    new "それじゃ、邪魔しないわ。がんばって勉強しなさい、ハニー。必要ならキッチンにいるからね。"

    # say L204 pla
    old "Didn't you say they can't hear you?"
    new "君が言ったよね、彼らには聞こえないって。"

    # say L206 bri
    old "Nope! But they can hear you! Hehe."
    new "ダメじゃない！でもあなたが聞こえるのよ！へへ。"

    # say L208 pla
    old "Oh... Ok, that makes sense... but explain everything to me again."
    new "オッケー、それなら納得できるけど、また全部説明してくれよ。"

    # say L210 bri
    old "What do you want to know, [pla]?"
    new "何を知りたいの、[pla]？"

    # menu L220 
    old "Who are you?"
    new "誰だよ？"

    # say L222 bri
    old "Again, I'm Brixxida, a shinigami. I am the protector of the book you found. Hehe."
    new "また言いますが、私はブリクシダ、死神です。あなたが見つけた本の守護者よ。へへ。"

    # say L224 pla
    old "Ok. Now, where did you come from?"
    new "分かった。じゃあ、君はどこから来た？"

    # say L226 bri
    old "I come from another dimension. There, magic and power were natural, but that world has been destroyed."
    new "私は別の次元から来たの。そこでは魔法や力が自然だったけど、その世界はもう滅んでしまったの。"

    # say L228 pla
    old "So... you are a time traveler?"
    new "そうか……君はタイムトラベラーなのか？"

    # say L230 bri
    old "What? No, no... I have been asleep for hundreds of years with a spell. But when you opened and read the book, I woke up."
    new "何？違うよ……魔法で何百年も眠ってたの。でもあなたが本を開いて読んだとき、目覚めたの。"

    # say L232 pla
    old "Ok, I think I'm starting to understand."
    new "分かったような気になってきたよ。"

    # menu L239 
    old "What's this book about?"
    new "この本はいったい何について書いてあるんだ？"

    # say L241 bri
    old "Well... this book contains all the knowledge of that magical world..."
    new "ええと……この本にはその魔法の世界のすべての知識が詰まってるの……"

    # say L243 pla
    old "Eww. So, it's like a history book?"
    new "うわ。じゃあ、歴史の本みたいなもんか？"

    # say L245 bri
    old "No, silly. This book contains specific spells and mantras that enable impressive magic powers beyond human understanding."
    new "違うわ、バカ。この本には特定の呪文やマントラが載っていて、人間の理解を超えたすごい魔法の力を発揮できるのよ。"

    # say L247 pla
    old "Ok, I get that part."
    new "その部分は分かった。"

    # menu L254 
    old "Magic, you say?"
    new "魔法か？"

    # say L256 bri
    old "Yes! The magic is a natural power that was lost, but you can get it and actually improve it..."
    new "はい！魔法は失われた自然の力だけど、それを手に入れたら実際に向上させることもできるの..."

    # say L258 pla
    old "Yeah, yeah. But... what can I do with magic?"
    new "うん、うん。でも…俺に魔法で何ができるんだ？"

    # say L260 bri
    old "Actually, there are no limits with magic! It is the most powerful force in the known universe..."
    new "実は魔法には限界がないの！これは知られている宇宙で最も強力な力なんだよ..."

    # say L262 pla
    old "Really? Interesting..."
    new "ほんと？面白いな…"

    # say L264 bri
    old "What else do you want to know, [pla]?"
    new "他にも知りたいことはあるの、[pla]？"

    # menu L269 
    old "What do I have to do?"
    new "何をすればいいんだ？"

    # say L271 bri
    old "Well... you have to learn different spells and mantras to achieve powerful skills but... you will find everything in the book."
    new "ええと……異なる呪文やマントラを学んで強力なスキルを得られるんだけど……すべて本に書いてあるよ。"

    # say L273 pla
    old "Imperium mens et feminam. What is that? Russian or some shit?"
    new "イマーリウム・メンス・エト・フェミニアム。何それ？ロシア語か何か？"

    # say L275 bri
    old "Actually, Latin is the language in which it was written... But don't worry, my job is to help the Chosen One translate..."
    new "実は、ラテン語で書かれているのよ…でも安心して、選ばれし者の翻訳を手伝うのが私の役目だから…"

    # say L277 pla
    old "Do I have to learn a lot of information about spells and mantras?"
    new "Spellsとmantrasについての情報をたくさん学ばなきゃならないのか？"

    # say L279 bri
    old "That's right! Hehe. And gaining a lot of power!"
    new "その通り！へへ。そしてたくさんの力を得られるんだよ！"

    # say L281 pla
    old "Ok, I hope this is all worth it."
    new "分かった、これがあいつるといいな。"

    # say L283 bri
    old "Alright, [pla]. What else do you want to know?"
    new "じゃあ、[pla]、他に知りたいことはある？"

    # say L290 bri
    old "That's the spirit!  So, look at the beginning of the book for an easy spell..."
    new "その調子！　本の最初の方を見てみるわ。"

    # say L292 pla
    old "Let's see here..."
    new "見よう見よう"

    # say L295 pla
    old "Damn, forgot. Everyone can hear me in this room. I gotta look for a better place to do this..."
    new "くそ、忘れてた。この部屋じゃ誰もが聞こえちまうな。もっといい場所探さないと..."

    # say L297 pla
    old "Hmm, probably the garage. Noone can hear me in there. Could you go there with me, Brixxida?"
    new "うん、多分ガレージだな。誰も聞こえないから。ブリクシダ、一緒に来てくれる？"

    # say L299 bri
    old "I will follow you wherever you tell me."
    new "どこへ行こうって言われても、ついていくわ。"

    # say L301 pla
    old "Perfect! Let's do this in the garage."
    new "完璧だ！ガレージでやろう。"

    # say L316 bri
    old "So? Are you ready to start?"
    new "じゃあ？ 準備はいい？"

    # say L318 pla
    old "I should talk with my [mo1rel] before we begin."
    new "始める前に俺は[mo1rel]と話すべきだな。"

    # say L331 pla
    old "Alright, I spoke to my [mo1rel] and explained to her that I will be in here preparing my project."
    new "よし、俺は[mo1rel]に話して、プロジェクトの準備をするって説明したよ。"

    # say L333 pla
    old "So, how does all this work, Brixxida?"
    new "じゃあ、これってどうやって動くんだ、Brixxida？"

    # say L338 bri
    old "Well, first you must understand the magical power..."
    new "まずは魔法の力を理解するところからね…"

    # say L340 pla
    old "Magical power?"
    new "魔力って？"

    # say L342 bri
    old "Yes, you must have the magical power to be able to do any spell..."
    new "はい、魔法の力をもっていないとどんな呪文も使えませんよ。"

    # say L344 pla
    old "I understand, but then how do I generate that magical power?"
    new "分かったけど、じゃあその魔力をどうやって生成するんだ？"

    # say L346 bri
    old "Well, magical power is an energy that was produced naturally in the magical world..."
    new "魔法の力は、魔法の世界で自然に生成されるエネルギーさ……"

    # say L352 pla
    old "Even you?"
    new "お前まで？"

    # say L354 bri
    old "Yes... We feed on magical energy, when in the real world all the remaining energy has been used up, I will disappear..."
    new "うん……現実世界で残されたエネルギーが尽きると、私は消えちゃうの……"

    # say L356 pla
    old "Wow... And how do we prevent magic energy from running out?"
    new "Wow... どうやって魔法のエネルギーが尽きるのを防げばいいんだ？"

    # say L358 bri
    old "The magical energy will continue to run out until there be a new being so powerful that it can restore the magical world and return everything to its natural balance..."
    new "魔法エネルギーは、新たな力を持つ存在が現れ、魔法の世界を復活させ、すべてを自然のバランスに戻すまで枯渇し続けるわ…"

    # say L360 pla
    old "That powerful being is supposed to be... me?..."
    new "その強大な存在って……俺のことなのか？……"

    # say L362 bri
    old "Yes.. You are the chosen one."
    new "うん…あなたが選ばれた人ね。"

    # say L364 pla
    old "Hmm, it's a lot of responsibility..."
    new "うーん、責任重大だな…"

    # say L366 bri
    old "Don't worry. I know we will make it!"
    new "心配しないで。私たちはきっと大丈夫だよ。"

    # say L368 pla
    old "Okay, but then how can I make spells if I don't have magic energy?"
    new "分かってるけど、魔法エネルギーがないんだよ。じゃあ、どうやって SPELL を作ればいいんだ？"

    # say L369 bri
    old "Well, let me think... It's really not difficult, The magic energy is in the air."
    new "まあ、考えさせて… 実際、そんなに難しくないの。魔法エネルギーは空気中に含まれてるのよ。"

    # say L370 bri
    old "I can see it. What you need to do is acquire a certain skill that allows you to see it too..."
    new "見えるわ。あなたが必要なのは、それを見えるようにする特定のスキルを身につけることよ…"

    # say L373 bri
    old "Agamoto's eye! With it, you can see all the particles of magical power and collect them..."
    new "アガモトの目！これを使えば、魔法の力を構成する粒子を見つけ出して集めることができるわ…"

    # say L375 pla
    old "Whose eye?"
    new "誰の目？"

    # say L377 bri
    old "Agamoto's eye, is a special ability of vision. It will allow you to see many things of the magical world and expand your vision in a way never seen before by humans..."
    new "アガモトの目は、特別な視覚能力よ。これがあれば、魔法の世界のたくさんのものを見えさせることができ、人間がこれまで見たことのないような視野を広げることができるわ…"

    # say L379 pla
    old "Great. How do I get that ability then?"
    new "なるほど。じゃあ、その能力を得るにはどうするんだ？"

    # say L381 bri
    old "Ohhh... Well, heh... You'll need magical power... Hahaha."
    new "オーッ… まあ、へへ… 魔力が必要になるのね… ハハハ。"

    # say L383 pla
    old "Really?... So how can I get magic power? If I need magic power to get magic power..."
    new "ほんと？……じゃあ、魔法の力をどうやって手に入れるんだ？ 魔法の力が必要だって……"

    # say L385 bri
    old "Well, I think the easiest way is that I share you magic power!"
    new "じゃあ、私が魔法力をあなたと分かち合うのが一番簡単な方法だと思うの！"

    # say L387 pla
    old "You share magic power with me?"
    new "君が魔法力を俺と分かち合うって？"

    # say L389 bri
    old "Yes! As I explained to you, all magical beings are constituted of magical power."
    new "はい！私が説明した通り、すべての魔法生物は魔法の力で構成されているの。"

    # say L390 bri
    old "In fact, we are like little magnets that we are gathering magical power constantly to live."
    new "実際、私たちは小さな磁石のようなもので、生きるために常に魔力を集めています。"

    # say L392 bri
    old "In the magical world it was totally normal to share our magical energy with others because there were lots..."
    new "魔法の世界では、私たちが魔力を他の人と分かち合うのは全く普通のことだったの。だって、魔力はたくさんあったから…"

    # say L394 bri
    old "The problem is that in this world there is less and less, so if I share more than necessary, it could disappear forever."
    new "問題は、この世界ではそのエネルギーがますます少なくなってきていること。必要以上に分け与えすぎると、永久に消えてしまうかもしれないから。"

    # say L396 pla
    old "Wow, it looks dangerous... So what will we do?"
    new "Wow、危険そうだな… じゃあ、どうするんだ？"

    # say L398 bri
    old "Bah, I'm going to share enough, and then you can return me some magical power so that nothing happens to me."
    new "バ、適量だけ分け合って、その後あなたが私に魔法の力を返してくれれば、私には何事も起きないわ。"

    # say L400 pla
    old "Okay, how do you share me then?"
    new "じゃあ、どうやって俺と分かち合うんだ？"

    # say L402 bri
    old "Hmm, let's see. Take off your pants and lie on the floor..."
    new "うーん、そうね。パンツを脱いで床に横になって…"

    # say L404 pla
    old "What... Why do I have to take off my pants?"
    new "何……なぜパンツを脱がなきゃならないんだ？"

    # say L407 bri
    old "Oh, of course... You humans treat nudity as a taboo. Even though it's something natural..."
    new "もちろん……あなた方には裸になることがタブーみたいね。でも、それは自然なことなのに……"

    # say L408 bri
    old "Besides what we're going to do... How do you call it?... Uhh, sex!"
    new "それに私たちがするのよ... えっと、セックスって言うの？"

    # say L410 pla
    old "What the fuck!? Are we going to have sex?"
    new "何だと！？ セックスするってことか？"

    # say L412 bri
    old "Yes, it's super fun... I understand that you see it in a different way. But for us, this is simply a form of common energy exchange..."
    new "うん、めちゃくちゃ楽しいの… あなたの見方は違うかもしれないけど、私たちにとっては単純なエネルギーの交換なんだ…"

    # say L414 pla
    old "Are you saying that this is how you are going to share magical power?"
    new "君が魔法の力をこうやって分かち合うって言ってるのか？"

    # say L416 bri
    old "Exactly, the magic power resides in an inner gland, and the only way to transfer it is to excite it..."
    new "そう、魔力は体内の腺に宿っており、それを移す唯一の方法は興奮させるだけなんだ…"

    # say L418 bri
    old "In my case, you must be inside me and you will receive my magic power!"
    new "私の場合は、あなたが中に入らないとダメで、そうすることで私の魔力を受けてもらうの！"

    # say L420 pla
    old "... And there is no other way. I'm not sure if it's a good idea..."
    new "他に方法はないんだ。これがいいアイデアかどうかは正直自信ないけど…"

    # say L422 bri
    old "Oh come on! You humans are very complicated, but you have to see it as a magical being..."
    new "ほらほら！あなたたち人間はとても複雑だけど、魔法の存在としてこれを受け入れなきゃいけないのよ…"

    # say L424 bri
    old "Think of sex as a way to feed yourself with magical energy... Is very natural."
    new "セックスを魔法のエネルギーを補充する方法と考えてみて… とても自然なことだよ。"

    # say L426 pla
    old "Alright, let's do it then..."
    new "よし、じゃあやるか…"

    # say L429 bri
    old "Excellent! Take off your pants and get on the floor!"
    new "素晴らしい！パンツを脱いで床に這うの！"

    # say L434 bri
    old "Wow, this is very good! I haven't done it for a long time..."
    new "Wow、これはとてもいいわ！長い間やってなかったわ…"

    # say L442 pla
    old "Do you have some magic power to share with me?"
    new "君に何か魔法のような力があるのか？シェアしてくれないか？"

    # say L444 bri
    old "Do you need more from me?"
    new "もっと必要？"

    # say L446 pla
    old "Well, only if you have some to share..."
    new "WELL、君にも何かシェアできるものがあればな。"

    # say L448 bri
    old "Ok, but just because is really fun... hahaha"
    new "分かったわ、でも本当に楽しいからね…ははは"

    # say L452 bri
    old "Take off your pants and lie on the floor..."
    new "パンツを脱いで床に横になって..."

    # say L478 pla
    old "Wow, I've never slept that well."
    new "Wow、こんなに熟睡したのは初めてだな。"

    # say L480 bri
    old "I see that your body was able to completely assimilate magic. How do you feel?"
    new "魔法を完全に同化できてるみたいね。どう感じてる？"

    # say L482 pla
    old "I don't feel any different..."
    new "別に変わった感じはないな..."

    # say L484 bri
    old "Well, the best thing to do is to use the magic energy that I gave you to acquire Agamoto's Eye before it runs out..."
    new "じゃあ、私が渡した魔力を使ってアガモトの目を手に入れるのが最善だわ。魔力が尽きる前にね。"

    # say L486 pla
    old "Does that mean that if I don't use the magic power it will run out?"
    new "魔力を使わないとなくなるってことなのか？"

    # say L488 bri
    old "Yes, indeed. Every day you will have less magical power, which is why it is urgent that you acquire the skill."
    new "そうよ、毎日魔法の力が少なくなっていくから、スキルを手に入れるのが急いでるの。"

    # say L490 pla
    old "Perfect, let's go to the garage to do it then..."
    new "完璧だ、それじゃあガレージに行こうぜ..."

    # say L496 pla
    old "So, what should I do?"
    new "じゃあ、具体的に何すればいいんだ？"

    # say L497 bri
    old "Well, actually, yesterday we couldn't finish our magic transfer..."
    new "実はね、昨日は魔法の転送が完結しなかったから…"

    # say L498 bri
    old "So, we should do it again, in order to you get completly charged with magic power."
    new "それなら、あなたが完全に魔法の力で充電できるようにまたやってみようよ。"

    # say L499 pla
    old "Hmm alright, but I'm not going to lay on the floor like last time, I don't want someone else to see me in that weird position..."
    new "うん、わかったけど、今度は床に寝るのやめよう。変な格好で誰かに見られたくないからな。"

    # say L500 bri
    old "All right!"
    new "わかった！"

    # say L513 pla
    old "All right. Now what should I do?"
    new "よし、次は何すればいい？"

    # say L515 bri
    old "First open your SexNote"
    new "まずはSexNoteを開いてね。"

    # say L525 bri
    old "Now check the first spell named 'Agamoto's eye' and activate it."
    new "まずは「アガモトの目」って呪文を確認して、それを活性化してね。"

    # say L526 pla
    old "Understood..."
    new "わかった…"

    # say L539 pla
    old "I think it's done... But I don't feel anything different..."
    new "俺の思うに、できてるんだけど……何か変わった感じがしないな……"

    # say L541 bri
    old "You must activate it, click on ability and look at the magic dimension!"
    new "活性化しないとダメよ、アビリティをクリックして魔法の次元を見てみるの！"

    # say L568 pla
    old "Wow... It looks so... Magical?..."
    new "Wow... これって... 魔法みたいだな..."

    # say L569 bri
    old "Do you see those little colored spheres? That is magic power, it has become particles, you just have to pick it all up..."
    new "あの小さな色つきの球体が見える？ それが魔法の力で、粒子になったんだよ。全部集めればいいの…"

    # say L570 bri
    old "And when you do it, just click the Agamoto's Eye to desactivate it and see the real world."
    new "そしてそれをやるときは、アガモトの目をクリックして無効化して、現実の世界を見るのよ。"

    # say L581 bri
    old "Of course, what did you expect? Having to memorize and recite strange meaningless words or make puzzles that never fit in  corners?"
    new "もちろん、何を期待してたの？ 奇妙で意味のない言葉を覚えたり、ぴったり合わないパズルを解く必要があると思ってたの？"

    # say L583 pla
    old "What?..."
    new "何？…"

    # say L585 bri
    old "Nevermind... It's simple, you just have to look for the spheres of magic power and that's it..."
    new "気にしないで… 簡単よ、魔力の球を探すだけだよ…"

    # say L587 bri
    old "In fact... There is a spell you can use called Ayax's Hand"
    new "実は……アヤックスの手って呪文があるのよ"

    # say L589 bri
    old "With this one your body will automatically begin to collect magic power everywhere you move, it's sorta like a magnet.."
    new "この呪文を使えば、あなたの体が自動的に魔法力を集め始めるの。動くだけで、まるで磁石みたいにね。"

    # say L591 pla
    old "Yes, you're right, there are several more spells I saw in the SexNote, how can I activate them?"
    new "そうだな、君が言う通りだ。SexNoteに載ってる魔法は他にもいくつかあるんだが、どうやってそれらを活性化すればいいんだ？"

    # say L593 bri
    old "Very easy you only spend the magic power you have in them and so you can activate those spells, each one has three different levels of power."
    new "とても簡単よ、あなたが持っている魔力を使えば、その呪文を活性化できるわ。それぞれの呪文には三つの異なるパワーのレベルがあるの。"

    # say L595 bri
    old "For example, the higher the level of power you have with Agamoto's eye, the more spheres you will see and so you can collect more magical power!"
    new "例えば、アガモトの目で持っている力のレベルが高いほど、見えるスフィアも増えて、より多くの魔力を集められるよ！"

    # say L597 pla
    old "Ohhh understood, and when I have collected all the magical power from a place?"
    new "オッ、わかった。で、場所からすべての魔力を集めたらどうなるんだ？"

    # say L599 bri
    old "Check this out, power spheres group everyday so keep an eye out and collect more magical power!"
    new "これ見て、パワーの球は毎日集まるから、見逃さずにもっと魔力を集めよう！"

    # say L602 bri
    old "Something important is that your body cannot store much magical power..."
    new "大事なのは、あなたの体にはそんなにたくさんの魔力を貯められないということよ..."

    # say L603 bri
    old "For that you must use a spell, and thus increase the amount of power that you can store within yourself."
    new "そのために呪文を使わないと、自分の体内に貯められる魔力の量が増えないんだ。"

    # say L605 pla
    old "Excellent, so I'm going to devote myself to collecting some magical power in the meantime..."
    new "優秀だな、じゃあ俺は魔法力を溜めるために頑張るよ…"

    # say L607 bri
    old "Perfect, now that you can do it... You could give me a little, remember that I need it to exist."
    new "完璧、それができるようになったら… 少し分けてくれるよね、存在するために必要なんだもん。"

    # say L609 pla
    old "Ohh yes, I'm sorry, let me pick up some more magical power and I will give you later..."
    new "おお、そうか、すまない、もっと魔力を集めてから、後で君にあげるね…"

    # say L611 bri
    old "Oh, by the way! Keep in mind that using your Agamotto Eye spends some magical power and time."
    new "そうそう、アガモットの目を使うと魔力と時間が少しずつ消費されるんだよ。"

    # say L615 bri
    old "Well, all magical skills, requires some magical power to be used..."
    new "魔法スキルを使うには、ある程度の魔力が必要だよ…"

    # say L618 bri
    old "And when you are in the magic dimension time passes a little faster too."
    new "魔法の次元にいると、時間の流れも少し速くなるわ。"

    # say L620 bri
    old "If you use only a couple of times, you will not see much difference but if you use them alot you will end the day very quickly."
    new "数回使うならそれほど違いは感じないけど、頻繁に使っていると一日が早く過ぎちゃうわ。"

    # say L622 pla
    old "Ohh ok, understood..."
    new "オッケー、わかった…"

    # say L624 bri
    old "It is indeed a good way to kill time if you have nothing to do at some point."
    new "確かに、やることがないときに時間潰しにはいいわね。"

    # say L626 pla
    old "I guess you are right..."
    new "君の言うとおりだな…"

    # say L628 bri
    old "Ok, I'll be here if you need me."
    new "分かった、必要ならいつでもここにいってるから。"

    # say L701 pla
    old "Hey Brixxida... I think I was visited by another shinigami, like you, yesterday."
    new "ブリクシダ……昨日、君みたいな死神がまた訪ねてきてくれたんだ。"

    # say L705 pla
    old "You are the only shinigami alive in the human world?"
    new "君が人間界で生きている唯一の死神なのか？"

    # say L707 bri
    old "I'm not sure, there are likely to be more, the magical world was very big..."
    new "確かに、もっといるかもしれないわ。魔法の世界は広大だから..."

    # say L709 pla
    old "Well, one of them visited me last night and she was sucking my... She was stealing my magic power..."
    new "まあ、昨夜一人が訪ねてきてさ、彼女は俺の... 魔力を奪っていったんだよ..."

    # say L711 bri
    old "Wow... Really?"
    new "ほんとうに？"

    # say L713 pla
    old "Who is she and why did she steal my magic power?"
    new "誰だよ、なんで俺の魔力を奪ったんだ？"

    # say L715 bri
    old "I don't know, it's not like I knew all the magical beings..."
    new "知らないわ、全ての魔法生物を知ってるわけじゃないし…"

    # say L717 pla
    old "So what can we do?"
    new "じゃあ、どうすればいいんだ？"

    # say L719 bri
    old "I don't think it will happen again, it's best we wait. If she steals from you again we'll have to defend ourselves..."
    new "また起こらないと思うけど、待つのが一番だよ。もしまた盗まれたら、自分たちを守らなくちゃならないから…"

    # say L721 pla
    old "What do you mean defend ourselves?"
    new "自分たちを守るってどういう意味？"

    # say L723 bri
    old "Well, we would have to hunt her and take away her magical power instead..."
    new "まあ、彼女を追跡して、魔法の力を奪うしかないのかな…"

    # say L725 pla
    old "All her magical power? That would make her disappear... wouldn't it?"
    new "彼女の魔法力を全部奪う？それじゃあ彼女は消えちゃうよ…そうだろう？"

    # say L727 bri
    old "Well if she attack you again, we can't sit by while she keeps stealing our magical power! We must stop her somehow..."
    new "もしまた攻撃してきたら、私たちの魔力を奪い続けるわけにはいかないわ！ 何とかして止めなきゃ……"

    # say L729 pla
    old "Hmmm... Ok, just let's wait and hopefully she won't  show up again."
    new "うーん……分かった、とりあえず様子見よう。多分また現れないだろう。"

    # say L731 bri
    old "Right... Don't worry, thought. Just keep improving with your skills..."
    new "そうだね… 心配しないでね。ただ、スキルを磨き続けていれば大丈夫だから…"

    # say L745 pla
    old "Brixxida, last night another shinigami visited me!"
    new "ブリクシダ、昨晚にもう一人の死神が来たんだ！"

    # say L747 bri
    old "Another? And did she steal more magic power from you?"
    new "また？そして彼女はあなたの魔力をさらに奪ったの？"

    # say L749 pla
    old "Well... yes."
    new "まあ…そうさ。"

    # say L751 bri
    old "Damn! That can't keep happening! We must recover my magical power... I mean, our magical power..."
    new "ダメよ！そんなこと続けてたら駄目よ！魔法力を取り戻さないと…私たちの魔法力をね…"

    # say L753 pla
    old "And how do we do it?"
    new "じゃあ、どうやってするんだ？"

    # say L755 bri
    old "We must go on the hunt... We will attack them so they don't bother us again..."
    new "私たちは狩りに出る必要がある…… そして彼らがまた邪魔しないように攻撃するの……"

    # say L757 pla
    old "No, no, this time I was able to talk with her a little more..."
    new "いやいや、今回は少し長く話すことができたんだ..."

    # say L758 pla
    old "In fact she didn't steal much magic from me... and I would like to understand the situation better..."
    new "実際彼女はそんなに多くの魔法を奪っていかなかった... それに状況をもっと理解したいんだ..."

    # say L760 bri
    old "They have stolen magical power. If it continues, we will be wasting valuable time that we must use to collect more magical power..."
    new "魔力を奪われたわ。続けば貴重な時間を無駄にしてしまうわ。魔力を集めるために使うべき時間なのに…"

    # say L762 pla
    old "Let me try one more time. When they return I will try to find out more and see if we can calm them down..."
    new "もう一回試させてくれ。戻ってきたらもっと詳しく聞いてみて、落ち着かせられるか見てみる。"

    # say L764 bri
    old "Hmm, if they steal your magic power again, we will have to defend ourselves, okay?"
    new "もしまた魔法力を奪われたら、私たちも自分たちを守らないとね。大丈夫？"

    # say L766 pla
    old "Okay. I will try to use Sauron's Mouth to find out more next time..."
    new "分かった。次はサウロンの口を使って更多信息を手に入れるようにするよ。"

    # say L768 bri
    old "Well, make sure you have the skill at the highest level to get as much information as possible."
    new "スキルを最高レベルに上げて、できるだけ多くの情報を手に入れるようにしてね。"

    # say L770 pla
    old "For sure..."
    new "わかったよ、ブリ..."

    # say L782 pla
    old "Well, things will be fine ..."
    new "まあ、問題ないだろう ..."

    # say L784 bri
    old "You put a stop to the night robberies?"
    new "夜の強盗を止めたの？"

    # say L786 pla
    old "Well, Not really..."
    new "まあ、そうでもないけど..."

    # say L788 bri
    old "Then we will have to fight back now..."
    new "なら、今度は私達が反撃するしかないわね。"

    # say L790 pla
    old "No, wait! The problem is that I have taken magical energy that they need to live..."
    new "待って、待って！問題は、俺が彼らが生きるために必要な魔力を取ってしまったことなんだ…"

    # say L792 bri
    old "You have taken magical energy that is scattered throughout the world. You have never attacked any of them..."
    new "あなたが取り込んだのは、世界中に散らばっている魔力だよ。一度も彼らを攻撃したことはないの..."

    # say L794 pla
    old "But... I can generate magical power in other ways..."
    new "でも... 別の方法で魔力を生成できるんだ..."

    # say L796 bri
    old "You still don't have enough sexual activity with other women, to guarantee a constant production of magical energy."
    new "他の女性との性的活動が足りないから、魔法のエネルギーを安定して生み出せないわ。"

    # say L798 pla
    old "I can do it and not affect them..."
    new "俺がやっても、彼女たちに影響は与えないよ..."

    # say L800 bri
    old "You must think about the main goal and it is to be able to rebuild the magical world."
    new "目的を考えて、魔法の世界を再建することが大事なのよ。"

    # say L802 bri
    old "There are many magical beings that will disappear..."
    new "多くの魔法の存在が消えてしまうわ…"

    # say L803 bri
    old "And we can do nothing but work harder to rebuild everything as quickly as possible..."
    new "そして、できるだけ早くすべてを再建するために一生懸命働くしかない……"

    # say L805 pla
    old "Hmm... I guess you're right, but we don't have to attack them."
    new "うーん…君の言う通りかもしれないけど、攻撃する必要はないな。"

    # say L806 pla
    old "I will try to produce our own energy and little by little we can move forward with the spells..."
    new "自分でエネルギーを作り出そう。少しずつ進めていけばいいだろう..."

    # say L808 bri
    old "They will continue stealing your magical power if we do nothing."
    new "何もしないと、彼らはあなたの魔力をずっと奪い続けるわ。"

    # say L809 bri
    old "We don't have to take away all the magical power, just enough to scare them and they won't look for you again..."
    new "魔法の力を全部奪う必要はないわ、ただ彼らを怖がらせる程度で十分よ。そうすればまたあなたを探しに来ることもないだろうね..."

    # say L811 pla
    old "Hmm that's fine... How do we do it?"
    new "うん、それはいいけど…どうするの？"

    # say L813 bri
    old "I'll take care of tracking them and you'll do the attacking..."
    new "私が追跡するから、あなたは攻撃するの…"

    # say L815 pla
    old "Attack them?"
    new "攻撃するか？"

    # say L817 bri
    old "Yes, you will have to fuck them..."
    new "はい、あなたが彼らを犯さないといけない…"

    # say L819 pla
    old "Hmmm... Ok."
    new "うーん… 分かったよ。"

    # say L821 bri
    old "Ok, give me a second. I'm going to use a special spell to detect nearby magical beings..."
    new "ちょっと待ってね。特別な魔法を使って近くにいる魔法生物を検出するから…"

    # say L825 bri
    old "{b} Radar calidus morollo! {/b}"
    new "{b} レーダー・カリドゥス・モロロ！ {/b}"

    # say L829 bri
    old "Done... I already identified where one of them are! She is in your classroom at school! Go there and fuck her..."
    new "Done... すでに一人の場所を特定したわ！ 学校の教室にいるの！ 行ってヤっちゃえ..."

    # say L831 pla
    old "But... What if other people are there?"
    new "でも... 他の人がいたらどうする？"

    # say L833 bri
    old "Don't worry! When you are in the magical dimension with Agamoto's Eye nobody can see you..."
    new "心配しないで！アガモトの瞳の魔法次元では誰も君を見えないから..."

    # say L835 pla
    old "Ok, I'm going there then..."
    new "分かった、行ってみるよ。"

    # say L837 bri
    old "Good luck! See you later..."
    new "頑張ってね！また後でね..."

    # say L843 pla
    old "(Well, she is supposed to be here...)"
    new "（まあ、彼女はここに来るのが当然だしな…）"

    # say L845 pla
    old "(Let's use the Agamoto's Eye.)"
    new "（アガモトの目を使おう。）"

    # say L852 mil
    old "What the fuck are you doing here?"
    new "何ここでやってんの？"

    # say L860 bri
    old "So, how did it go? Did you get magic power back?"
    new "じゃあ、どうだった？魔法の力は戻ったの？"

    # say L862 pla
    old "Yes, I already recovered my magic power..."
    new "うん、魔法の力はもう取り戻したよ..."

    # say L864 bri
    old "Great... I don't think they will bother again after that..."
    new "Great... あの後、彼らはもう来ないと思うけど..."

    # say L866 pla
    old "Hmm I don't know... We shall see."
    new "うーん、わからないな… まだ様子を見よう。"

    # say L878 pla
    old "Again, problems with these shinigamis, I think they've gone crazy..."
    new "またか、これらの死神たちはもう頭がおかしくなったんじゃないかと思うよ…"

    # say L880 bri
    old "AGAIN? Okay let's finish them..."
    new "また？いいわ、片づけちゃう..."

    # say L882 pla
    old "No, no... It's very strange. The one who I talked to yesterday was very kind and friendly after having accused me of destroying the magical world..."
    new "いや、いや… これは本当に奇妙だ。昨日話した死神は、魔法の世界を破壊したって責めてから、とても優しくなったんだ…"

    # say L884 bri
    old "What?... Ehh... They are totally crazy... It's best to make them disappear. We don't want to deal with them later..."
    new "何？…えっ…全然変だよ…さっさと消した方がいいわ。後で面倒くさいから…"

    # say L886 pla
    old "We'll let's try this... I will try to find the next shinigami and I will see what's happening..."
    new "じゃあ、これで試してみるか… 次の死神を見つけ出して、状況を見てくるつもりだ…"

    # say L888 bri
    old "But you should kill them! We've had enough..."
    new "でも彼らを殺すべきよ！もう十分なわけじゃない？"

    # say L890 pla
    old "No, no. Let me handle this. I have an idea..."
    new "いや、待て。俺がこの件を処理する。アイデアがあるんだ..."

    # say L892 bri
    old "Hmmm ok. I'm gonna use the spell again and I'll tell you where to find the next shinigami..."
    new "うん、わかった。また SPELL を使うから、次の死神がどこにいるか教えてあげるね..."

    # say L900 bri
    old "Well, she is in fact in your friend Hinn's living room."
    new "WELL、彼女は実際あなたの友達ヒンのリビングルームにいるの。"

    # say L902 pla
    old "Hmmm, alright... No problem."
    new "うん、わかった… 問題ないな。"

    # say L904 bri
    old "But you should consider killing them. It can't waste more time..."
    new "でも、彼らを殺した方がいいかも。時間の無駄にはならないから。"

    # say L906 pla
    old "I know what to do..."
    new "分かってるよ…"

    # say L908 bri
    old "Hmm, Ok."
    new "うん、わかった。"

    # say L914 pla
    old "(Great, no one is in the livingroom...)"
    new "よし、リビングには誰もいないな…"

    # say L919 pla
    old "Excellent! Just what I wanted..."
    new "最高！ ちょうど欲しかったんだ..."

    # say L930 mil
    old "What? What are you doing?"
    new "何？何してるの？"

    # say L939 pla
    old "I have some questions to ask you..."
    new "お前、いくつか聞きたいことがあってな…"

    # say L941 bri
    old "Sure! Do you want to know more about spells?"
    new "もちろん！魔法についてもっと知りたいの？"

    # say L943 pla
    old "No, in fact, I want you to tell me who destroyed the magical world..."
    new "実は、魔法の世界を破壊したのは誰か教えてほしいんだ。"

    # say L946 bri
    old "Of course, the magical world was a wonderful place. Everyone lived in harmony..."
    new "もちろん、魔法の世界は素晴らしい場所でした。みんなが調和よく暮らしていました…"

    # say L948 bri
    old "But a dark being, for unknown reasons, destroyed everything with a spell. When started to act it was too late because the being had too much power..."
    new "でも、理由は不明だけど、暗黒の存在が呪文で全てを破壊しました。動き出したらもう手遅れで、その存在の力が強すぎたから…"

    # say L950 pla
    old "And why did the shinigami tell me the person who destroyed the magical world was the SexNote owner?"
    new "そしてなぜ死神は魔法の世界を破壊したのがSexNoteの持ち主だって教えてくれたんだ？"

    # say L952 bri
    old "I don't know... It could have been the former owner of the SexNote or it could have been another SexNote..."
    new "知りません… 前の SexNote の持ち主かもしれないし、別の SexNote かもしれません…"

    # say L954 pla
    old "Is there more than one SexNote?"
    new "SexNoteって複数あるのか？"

    # say L957 bri
    old "It is not known for sure. Nobody knows. In fact, many ignore the real existence of a SexNote. It is something very secret because of the power it has..."
    new "確実なことは誰も知らないの。実際、多くの人はSexNoteの存在そのものを無視してるわ。それが持つ力のせいで、とても秘密のことだから..."

    # say L959 bri
    old "That's why you're the Chosen One to use it to repair all the damage..."
    new "それが、あなたが選ばれた人で、それを用いて全てのダメージを修復するためなのよ…"

    # say L961 pla
    old "I understand... Still, you don't know anything about the previous owner of the SexNote or who destroyed the magical world?"
    new "分かってるよ…でも、SexNoteの前の持ち主や、魔法の世界を壊したやつについて何も知らないのか？"

    # say L963 bri
    old "Correct, My mission was entrusted after the destruction of the magical world, to find a way to preserve the remaining magic of the universe..."
    new "その通り、私の使命は魔法の世界が破壊された後、宇宙に残された魔法を守る方法を見つけることでした…"

    # say L965 pla
    old "Got cha. Then everything is a silly misunderstanding... Help me look again for the shinigami to talk to them..."
    new "分かった。じゃあ全部誤解だったってわけか…また死神を探して話そうぜ…"

    # say L967 bri
    old "I don't think that is for the best. After what happened, it could be dangerous. It is best to leave it be as I doubt they'll look for you again..."
    new "それは最善の策とは思えないわ。起こったことを考えると、危険かもしれないから。もう放っておいた方がいいわ、きっとまたあなたを探そうとはしないだろうね…"

    # say L969 pla
    old "But you heard them, they are running out of magic power..."
    new "でも君も聞いたよね、彼らは魔法の力が尽きかけてるって…"

    # say L971 bri
    old "The magic power is scattered throughout the world, they just have to go to other places to collect. It is not as serious as they want you to think..."
    new "魔法の力は世界中に散らばってるの、他の場所に行けば集められるわ。彼らが思ってるほど深刻じゃないと思うの…"

    # say L973 pla
    old "Hmmm... Ok... I guess you're right"
    new "うーん……そうか……君の言う通りかもしれないな"

    # say L975 pla
    old "Well, I'm going to keep improving my skills and collecting magical power."
    new "まあ、俺はスキルを磨きつつ魔力を集め続けるよ。"

    # say L977 bri
    old "Great! See you later."
    new "グレート！またね。"

    # say L983 pla
    old "(I still think there is something up with Brixxida. I should try to talk with those shinigamis again)"
    new "ブリクシダには何かおかしな気がするな。またあの死神たちと話してみるべきだ。"

    # say L985 pla
    old "(But, I can't ask Brixxida to look for them...)"
    new "（でも、ブリクシダには探してもらうわけにはいかないな…）"

    # say L987 pla
    old "(I will have to look for them by myself)"
    new "自分で探さなきゃな"

    # say L989 pla
    old "Ok, I should look around to find them..."
    new "よし、探してみるか"

    # menu L996 
    old "Talk with her"
    new "彼女と話す"

    # say L1010 pla
    old "Well, I already collected enough magic power, I think I can share some with you..."
    new "まあ、すでに十分な魔力は集まったから、君と分かち合えると思うけど…"

    # say L1013 bri
    old "Yummy. I love to share the magic power. It's very fun!"
    new "うんめえ〜 私も魔力分かち合うの大好き〜 楽しいわ！"

    # menu L1022 
    old "Repeat"
    new "受け取るよ。"

    # say L1033 pla
    old "Wait... What are you doing..."
    new "待って……何やってんの……"

    # say L1034 bri
    old "Duh. Receiving your magical power, this is how it is done..."
    new "杜々。あなたの魔力を受けるには、これが正しい方法だから…"

    # say L1035 pla
    old "But..."
    new "でも..."

    # say L1036 bri
    old "You must stop being so dramatic with this. You have to be more professional and understand that this is the way it is done. So stop being so... Human..."
    new "あなたはもっとプロフェッショナルにこのことを受け止めるべきよ。これが正しいやり方なんだから。だから、そんなに……人間らしい反応をやめて。"


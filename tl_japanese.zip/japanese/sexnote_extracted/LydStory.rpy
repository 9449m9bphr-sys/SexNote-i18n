# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/LydStory.rpy
translate japanese strings:

    # say L11 ann
    old "I mean mom, online dating?!! What the fuck?!!!"
    new "ママ、オンラインデートって？！！ 何言ってんのこれ？！！"

    # say L12 ann
    old "You couldn't think about anything else?"
    new "他に何も考えられなかったの？"

    # say L13 ann
    old "Why don't you just join a knitting group? Or play bingo like any other widow?"
    new "なぜニットのグループに入らないの？ それとも他の寡婦みたいにビンゴでもやればいいのに。"

    # say L14 lyd
    old "What's so bad about what I said?"
    new "何がそんなに悪いの？"

    # say L15 lyd
    old "I don't think there's anything wrong with a single woman thinking about meeting new people."
    new "私は独身の女性が新しい人との出会いを考えることに問題はないと思うわ。"

    # say L16 lyd
    old "Now that your father's not here I'd like to make some new friends, and..."
    new "父親がいなくなってから、新しい友達を作りたいと思っていて…"

    # say L17 ann
    old "Do you think you're at the age where you should be meeting people through a dating app?"
    new "君が出会い系アプリを使って新しい人と出会う年齢だとは思う？"

    # say L18 ann
    old "Besides, who the hell is going to talk to you? To a widowed grandmother?"
    new "それに、誰が君と話すっていうの？ 未亡人のおばあさんなんて。"

    # say L19 ann
    old "If you want to meet new people why don't you just go to an elderly home?"
    new "新しい人に会いたいなら、老人ホームに行ってみたら？"

    # say L20 ann
    old "Maybe there you'll find some people your age."
    new "そこで君の年齢の人が見つかるかもしれないよ。"

    # say L21 lyd
    old "It's that way to talk to your mother?"
    new "そんなふうに母親に話すの？"

    # say L22 lyd
    old "Are you listening to yourself?"
    new "自分で言ってること聞いてるの？"

    # say L23 ann
    old "I don't care!"
    new "私はどうでもいい！"

    # say L24 ann
    old "You should be the one thinking about what you're saying! Dad's not even been dead for a year!"
    new "自分が何言ってるか考えてみなさいよ！父さんが死んできてまだ一年も経ってないのに！"

    # say L25 ann
    old "And here you are thinking about picking guys up like you're some... Ugh!"
    new "そして、あなたは男の子を拾いに行くことまで考えているのね…うっ！"

    # say L26 ann
    old "I don't want my mother to go around giving herself up to some randoms on the internet."
    new "母がインターネットで知らない人と寝て回ることはないわ。"

    # say L27 ann
    old "Listen, you can do what you want, but don't expect me to help you with anything..."
    new "聞くよ、あなたが何をしようと勝手だけど、私には何も期待しないでね。"

    # say L28 ann
    old "Ugh! I don't even want to keep talking to you!"
    new "うっ！もうあなたと話すの嫌いだよ！"

    # say L42 pla
    old "Uh, hi..."
    new "うーん、ひさしぶり"

    # say L43 lyd
    old "[pla]! H- hi!"
    new "[pla]！　ひ、こんにちは！"

    # say L44 lyd
    old "I hope you didn't see much of what just happened..."
    new "見られちゃうと困るんだけど…"

    # say L46 pla
    old "Uhhh... Just the last bit of it, I think..."
    new "うーん… 最後の方しか見なかったけど…"

    # say L47 pla
    old "All I heard was Anna being as annoying as always."
    new "俺が聞いたのは、アンナがいつものようにうざかったことだけだ。"

    # say L48 pla
    old "What's the matter? Why is she acting up now?"
    new "どうしたんだ？今更何を騒いでるんだよ？"

    # say L50 lyd
    old "Well... How can I put it?"
    new "えっと……どう表現すればいいのかな。"

    # say L51 lyd
    old "Do you remember the other day when you went with me to church?"
    new "あの日、私を教会に連れてってくれたよね？"

    # say L52 pla
    old "Hmmm, yeah."
    new "うーん、そうか。"

    # say L53 lyd
    old "The thing is, ever since we ran into Mrs. Jones, I've been thinking and..."
    new "実はね、Mrs. Jones に会ってからずっと考えているのだけど..."

    # say L54 lyd
    old "I don't want to be like that [pla]. Her husband died five years ago, and she's been unable to move on from that."
    new "あのね、[pla] みたいにはなりたくないの。彼女の夫は五年前に亡くなったんだけど、まだそのことから立ち直れてないの。"

    # say L55 pla
    old "She hasn't moved on? What do you mean?"
    new "前に進めないの？どういうこと？"

    # say L56 lyd
    old "You know, all she ever does is talk about God and faith. Frankly, it's pitying."
    new "知ってるでしょ、彼女はいつも神様や信仰の話ばっかりするの。正直、哀れみの対象だよ。"

    # say L57 lyd
    old "I decided I don't want that to happen to me too."
    new "私はそんなふうにはなりたくなかったから。"

    # say L60 lyd
    old "So, I've been trying to get myself out there, I've gone to a couple of bars, and clubs."
    new "だから、自分をもっと外にアピールしようと、いくつかのバーとクラブにも行ったの。"

    # say L61 lyd
    old "Trying to meet new people, you know?"
    new "新しい人に会おうとしてるの、わかってるでしょ？"

    # say L62 lyd
    old "But, it's been to no avail. It turns out people don't really go to bars or clubs to meet new people anymore."
    new "でも、効果はなかったわ。結局、バーやクラブで新しい人と出会おうと思ってる人はそんなにいないみたい。"

    # say L64 lyd
    old "It's not as common to go out to meet new people. Nowadays, if someone goes out it's because they already have plans with someone else."
    new "今は新しい人と出会うために外出することがそんなに一般的じゃないの。出かけるって言っても、だいたい誰かと予定があるからよね。"

    # say L65 lyd
    old "So, I thought maybe I should do what I heard young people are doing these days, and try online dating."
    new "じゃあ、若者が最近やってるって聞いたオンラインデートを試してみようと思ったの。"

    # say L66 pla
    old "Well, that sounds like a good idea."
    new "そうか、それならいいアイデアみたいだな。"

    # say L68 lyd
    old "I guess so, but the whole internet thing just flies over my head. It's so complicated."
    new "そうね、でもインターネットのことは全然わからなくて。複雑すぎるの。"

    # say L69 lyd
    old "Given that I can't really do it myself I asked Anna to help me out."
    new "自分でやる自信がなかったので、Annaに手伝ってもらったの。"

    # say L70 lyd
    old "But, you already saw how that turned out."
    new "でも、その結果はもう見ちゃったでしょ。"

    # say L71 pla
    old "Hmph, I did..."
    new "ふん、やっちゃったな…"

    # say L72 lyd
    old "Although maybe she's right. Maybe I'm just too old to be thinking about doing things like online dating and such."
    new "でも、もしかしたら彼女が正しいのかもしれない。もしかしたら、私はもうオンラインデートなんてするには年寄りになったのかもしれない。"

    # say L73 lyd
    old "I'm just an old, lonely widow after all... So I'll just give up."
    new "私はただ年を取った孤独な未亡人だから… もう諦めるわ。"

    # say L74 pla
    old "Woah, woah, wait a minute."
    new "Woah、woah、ちょっと待って。"

    # say L75 pla
    old "Listen, you don't have to say all those bad things about you, and you also shouldn't say that you're going to give up."
    new "待って、そんな自分を貶めることないし、諦めるなんて言わないで。"

    # say L76 pla
    old "I actually agree with you, you have every right to live your life any way you want to."
    new "実際、お前の言うことに同意するよ。お前は自分の人生を好きなように生きるべきだ。"

    # say L77 pla
    old "Anna's just jealous because you're her mother. And she's always very possessive."
    new "アンナはただ嫉妬してるだけだよ、お前が母親だからさ。それに彼女はいつも占有欲が強いんだ。"

    # say L78 pla
    old "But you're free to do whatever you want. And I'm totally sure you can be with anyone you want to."
    new "でも君は自由に何をしてもいいんだ。誰といても全然問題ないって、俺は確信してる。"

    # say L82 pla
    old "Of course I do! Anyone would be lucky to meet you. I'm sure of it."
    new "もちろんだよ！誰もが君と出会えてラッキーだと思う、俺は確信してるよ。"

    # say L83 pla
    old "In fact, if Anna won't do it. Let me help you, I'll set up your profile for you."
    new "実際、もしアンナがやらないなら、俺が手伝うよ。プロフィール作成してあげる。"

    # say L86 pla
    old "Of course, I'll do it right now."
    new "もちろん、今すぐやるよ。"

    # say L87 lyd
    old "Ohh! That's so nice of you! Thank you [pla]!"
    new "あらっ！そんなに優しいのね！ありがとう[pla]！"

    # say L88 lyd
    old "Let's go to my room, my computer's there."
    new "私の部屋に行こう、パソコンがあるから。"

    # say L89 pla
    old "Oh no, there's no need. These days the best and easiest ways to meet people online are dating apps."
    new "いや、そんな必要ないよ。最近はオンラインで出会う最善で簡単な方法は出会い系アプリだよ。"

    # say L90 pla
    old "You know, on the phone. Have you ever heard of Tinder?"
    new "スマホでさ、ティンダーって知ってる？"

    # say L91 lyd
    old "Tinder? No, no idea what it is."
    new "ティンダー？ Nope、それが何か知らないわ。"

    # say L92 pla
    old "Well, it's this new dating app, in which you create a profile with your information on it."
    new "まあ、新しい出会い系アプリさ。プロフィールを作って、自分の情報を載せるんだ。"

    # say L93 pla
    old "The profile is public, so anyone can see it, and decide if they would like to talk to you or not."
    new "プロフィールは公開だから、誰でも見れて、あなたと話したいかどうか決められるんだ。"

    # say L94 lyd
    old "I see, what kind of information should go in there?"
    new "なるほど、どんな情報を入れればいいの？"

    # say L95 pla
    old "Nothing private, just the type of person you are, what you like and dislike."
    new "プライベートな情報じゃなくて、君の性格や趣味、好き嫌いを書いておこう。"

    # say L96 pla
    old "And a couple of pictures of you, so they know how you look."
    new "君の写真もいくつか載せるといいよ、そうすれば君の見た目がわかるから。"

    # say L97 pla
    old "You can also write what you want to find in a partner, so they know if you'll like them."
    new "君が求めるパートナーのタイプも書けるよ、そうすれば相性が合うかどうかわかるから。"

    # say L98 lyd
    old "That sounds interesting. How does it work?"
    new "それは興味深いね。どうやって使うの？"

    # say L99 pla
    old "It's very simple, once your profile is on the app it will be visible to people in it."
    new "それは簡単だ、君のプロフィールがアプリに上がれば、その中の人たちに見えるようになるんだ。"

    # say L100 pla
    old "And they get to decide if they would like to meet you."
    new "そして、他们会員は君と会うかどうかを決めるんだ。"

    # say L101 pla
    old "If they do, all they have to do is swipe your profile to the right, if they don't they swipe left."
    new "もし気に入ったら右にスワイプ、気に入らなければ左にスワイプするだけだ。"

    # say L102 pla
    old "And it's the same with you, if you see a profile you swipe either right or left, depending on if you like them or not."
    new "君も同じだよ、プロフィールを見て気に入ったら右に、気に入らなければ左にスワイプするんだ。"

    # say L103 pla
    old "If both of you swipe right, that means it's a match, and you can both start talking."
    new "お互いに右にスワイプすればマッチで、話しあえるようになるんだ。"

    # say L104 lyd
    old "Hmm, that sounds very simple and practical."
    new "そうね、それはとてもシンプルで実用的なシステムのようね。"

    # say L105 pla
    old "It is, come on, I'll help you set your profile."
    new "簡単だよ、さあ、プロフィール設定手伝うから。"

    # say L112 pla
    old "Ok, so, first of all, is setting up your bio, it's just a small description of you and the things you like and your interests."
    new "まずはプロフィールの紹介文を設定するぞ。君のことや好きなこと、興味があることを簡潔に書いてみろ。"

    # say L113 lyd
    old "Ok, so let me see, hmm... I got it!"
    new "わかったわ、ちょっと待って、うん… 分かったわ！"

    # say L114 lyd
    old "I'm a single woman who enjoys the simple things in life. I love long walks, enjoying nature and talking."
    new "私は独身の女性で、シンプルなことに癒されるのが好きです。長く散歩をしたり、自然を楽しんだり、会話することも好きです。"

    # say L115 lyd
    old "My perfect evening is a summer afternoon enjoying a glass of merlot and reading a good book."
    new "私のパーフェクトな夜は、夏の午後にメルロのグラスを楽しみながら良い本を読むこと。"

    # say L124 pla
    old "Ok, so that's your profile all set."
    new "じゃあ、これで君のプロフィールは完成だね。"

    # say L125 lyd
    old "Oh wow, that took no time, and it looks great!"
    new "わぁ、そんなに早くできて、しかもすごくいい感じだね！"

    # say L127 lyd
    old "So? What do I do now?"
    new "じゃあ、次は何すればいいの？"

    # say L128 pla
    old "Well, now that you have your own profile, what you have to do is look at other people's profiles."
    new "じゃあ、自分のプロフィールができたんだから、他の人のプロフィールを見てみよう。"

    # say L129 pla
    old "And see if you like any of them. You do this by swiping right or left..."
    new "そして、気に入った人を見つけてみろ。右か左にスワイプするんだ…"

    # say L130 lyd
    old "Woah, woah, that's a little too fast for me, and it sounds a bit complicated."
    new "Woah、woah、ちょっと早すぎるわ、それに少し複雑そうね。"

    # say L131 lyd
    old "Hmm, why don't you do it for me?"
    new "Hmm、私がやってあげよう？"

    # say L133 pla
    old "Hmm... ok sure, no problem, it's not hard, once you get it, it will be really easy."
    new "Hmm... そうか、問題ないぜ、難しくないから、一度慣れるまでは簡単になるよ。"

    # say L134 pla
    old "Alright, let's start, but, if I'm the one doing it, I won't know what kind of guy you're into."
    new "よし、始めるけど、俺がやるなら、君がどんな男のタイプか知らないよ。"

    # say L135 pla
    old "Why don't you tell me what you're looking for in a man?"
    new "君がどんな男の人が好きか教えてくれないか？"

    # say L136 pla
    old "That way I'll know who to select."
    new "そうすれば選ぶ相手が分かるよ。"

    # say L137 lyd
    old "What I'm looking for? Hmm, let's see..."
    new "何を探しているの？うーん、考えてみよう..."

    # say L138 lyd
    old "Well, I tend to like guys with beards, I think they look very manly, but it's not a requirement."
    new "うーん、私は髭のある男性が好きね、男らしく見えるから。でも絶対条件じゃないわ。"

    # say L139 pla
    old "Hmm, ok, I'll keep that in mind."
    new "うん、覚えておくよ。"

    # say L140 lyd
    old "But, be sure that it's a beard, not a mustache, I hate mustaches."
    new "でも、ちゃんとひげであって、ヒゲだけは本当に嫌いだからね。"

    # say L141 lyd
    old "My husband used to have one and I was never able to get him to shave it."
    new "私の夫も昔はヒゲを生やしてて、なかなか剃ってくれなかったの。"

    # say L142 pla
    old "Sure, that's an important detail."
    new "分かった、それは重要なポイントだね。"

    # say L143 pla
    old "Anything else?"
    new "他に何か？"

    # say L145 lyd
    old "I don't like bald men, I prefer a nice head of hair, but no white hair, not even at the sides."
    new "私はハゲた男性は好きじゃないの、ちゃんとした髪の毛がいいわ、でも白髪はダメ、サイドの白髪も含めてね。"

    # say L146 pla
    old "Alright, no bald men or white hair."
    new "分かった、ハゲや白髪は無しだな。"

    # say L147 lyd
    old "Well, to be honest, I'm looking for a young guy, so I'd rather he didn't look old, like wrinkles and stuff..."
    new "正直に言うと、若い男性がいいの、だから年老いた感じはちょっと...しわとかさ..."

    # say L148 pla
    old "Got it. Something else?"
    new "分かった。他に何かある？"

    # say L149 lyd
    old "Oh right, I don't know why but I have never been into gingers... So, no red hair, nothing personal..."
    new "ああそう、理由はわからないけどジンジャーってタイプじゃないの… 赤髪はなしで、悪気はないけどね…"

    # say L150 pla
    old "Hmm, Ok, I think I got everything. I'll try my best to find you someone like that."
    new "うん、わかった。君が求めているような人を見つけてみるよ。"

    # say L152 lyd
    old "Woah, thank you pumpkin, this is exciting!"
    new "わお、ありがとうかぼちゃ、これって楽しみだね！"

    # say L167 pla
    old "Ok Lydia, here you go, I think I got just what you wanted."
    new "Ok Lydia、これだよ。君が欲しかったものだと思ってるよ。"

    # say L168 pla
    old "And look at that, you already matched with a couple of them!"
    new "そして見て、もう何人かとマッチングしてるぞ！"

    # say L169 pla
    old "If you want to you can start talking with them."
    new "もしよければ、彼らと話してみるといいよ。"

    # say L170 lyd
    old "That's wonderful pumpkin!"
    new "それは素晴らしいね、かぼちゃ！"

    # say L171 lyd
    old "Oh, they all look very interesting indeed!"
    new "あら、みんなとても興味深そうね。"

    # say L172 lyd
    old "This is great, I'll start talking to them."
    new "これは素晴らしい、早速話しかけてみるわ。"

    # say L173 pla
    old "I'm glad you think they're good picks."
    new "君が良い選択だと思ってくれて嬉しいよ。"

    # say L174 lyd
    old "I do, they look great."
    new "そう思う、みんなすごくいい。"

    # say L175 lyd
    old "Now listen [pla], I'm very happy and thankful that you're helping me with this."
    new "それじゃ聞いて [pla]、あなたが手伝ってくれて本当に嬉しいし感謝してるの。"

    # say L176 lyd
    old "But, Anna might come back soon, and I fear what she'll say if she sees us doing this."
    new "でも、アンナが很快就いてくるかもしれないし、私たちがこんなことしてるのを見つかったら、何言うか怖いんだ。"

    # say L177 lyd
    old "I think it would be better if you leave before she comes back."
    new "あたしはアナが戻る前に帰った方がいいと思うの。"

    # say L181 pla
    old "Oh, sure, you're right! I'd forgotten about Anna."
    new "ああ、そうだね、君が正しいよ！アンナのことを忘れてた。"

    # say L182 pla
    old "I'll come back later to see how it went with the guys, ok?"
    new "後でまた来て、男の子たちとどうなったか教えて、いいな？"

    # say L184 lyd
    old "Sure, but please come in the afternoon, when Anna is usually out."
    new "もちろん、でも午後に来てね、アンナがいない時間に。"

    # say L185 pla
    old "Alright, I will come in the afternoon."
    new "わかった、午後に来るよ。"

    # say L186 lyd
    old "Thank you so much pumpkin, I really appreciate your help."
    new "ありがとう、本当に助かるわ、かぼちゃ。"

    # say L187 pla
    old "No biggie, I'm happy to help, bye!"
    new "大したことないよ、手伝えてうれしいし、じゃあな。"

    # say L203 pla
    old "Damn, I think I didn't do a good job with this Lydia, sorry."
    new "damn、リディア、俺がちゃんとやれなかったみたいで、ごめん。"

    # say L204 lyd
    old "Really? Did the phone fail?"
    new "本当に？スマホが故障したの？"

    # say L205 pla
    old "No, no, it's just that I think I selected some profiles wrong. So you may not like them too much."
    new "いや、違うよ。選んだプロフィールが間違えてるんじゃないかと思って。だから君にはあまり気に入らないかもしれないな。"

    # say L206 lyd
    old "Aw, that's ok, you don't need to stress too much about it."
    new "大丈夫よ、そんなに気にしないで。"

    # say L207 lyd
    old "We're both learning about this kind of thing. It's ok, really."
    new "お互いにこの手のことを学んでるんだから、大丈夫よ、ほんと。"

    # say L208 pla
    old "Thanks... Well, I think there's still a couple of matches, so you may talk to a couple of them, if you want to of course."
    new "ありがとう… でもまだいくつかマッチがいるみたいだから、君が話したいなら話してみるといいよ。"

    # say L209 lyd
    old "I'll do it, maybe they're not that bad. But for now, I think it would be better if you left."
    new "やってみる、もしかしたら悪くないかもしれないけど、今はあなたがいなさる方がいいと思う。"

    # say L210 lyd
    old "Anna has been out for a little while now, so she could come back at any moment."
    new "アンナはもう少しで帰ってきそうだから、いつ戻ってきてもおかしくないよ。"

    # say L211 lyd
    old "I don't even know what she would say if she finds out about this."
    new "彼女がこれを見つけたら何言うか全然わからないよ。"

    # say L212 lyd
    old "I don't want any more trouble with her. So it's best if you leave."
    new "もう面倒なことには巻き込まれたくないから、早く帰った方がいいよ。"

    # say L214 pla
    old "Yeah, you're right. I'll come back later to help again, bye Lydia."
    new "そうだね、君が正しい。また後で手伝いに来るよ、さようならリディア。"

    # say L235 lyd
    old "Hi pumpkin! How are you?"
    new "おひさしぶり、かぼちゃ！元気？"

    # say L237 pla
    old "Hey, it's Anna around?"
    new "Hey、アンナはいるか？"

    # say L238 lyd
    old "She isn't, why?"
    new "いないの、どうして？"

    # say L243 pla
    old "Well, I thought I could help you again with the app."
    new "まあ、アプリのことでまた手伝えるかと思ったんだけど。"

    # say L244 pla
    old "How has it been going since the last time? Have you talked to anybody?"
    new "最近どうだった？誰かと話した？"

    # say L245 lyd
    old "Oh, not really, I've had a couple of conversations with some people, but nothing interesting."
    new "ああ、そうね。いくつかの人と話はしたけど、特に面白いことはなかったわ。"

    # say L248 pla
    old "Well, that's why I'm here, to help you out. So let's see the app."
    new "まあ、それが俺がここに来た理由だ。手伝うためさ。じゃあ、アプリ見せて。"

    # say L262 pla
    old "Ok, here you go, I think I got just what you wanted."
    new "じゃあ、これだよ。君が欲しかったものだと思うけどね。"

    # say L270 pla
    old "With that done, I think it's better if I leave."
    new "それじゃ、俺は帰った方がいいかな。"

    # say L272 pla
    old "We wouldn't want Anna to get here and catch us."
    new "俺たち、アンナに見つかる前に帰ろう。"

    # say L273 lyd
    old "Sure, thanks again [pla], I really appreciate your help."
    new "もちろんだ、またありがとう[pla]、本当に助かったわ。"

    # say L319 lyd
    old "Hmm, I guess that's ok, you don't need to stress too much about it."
    new "うーん、そうね、それほど心配しなくてもいいわ。"

    # say L321 pla
    old "Thanks... Well, I think there's still a couple of them you could talk to if you want to of course."
    new "ありがとう… けど、まだ話せる人がいると思うよ、もちろん君が話したいならね。"

    # say L347 pla
    old "Hi Lydia, how are you?"
    new "嗨、リディア、元気ですか？"

    # say L348 lyd
    old "Hmm, hello [pla] I'm ok, I guess..."
    new "うーん、こんにちは [pla] 大丈夫かな、多分…"

    # say L349 pla
    old "What? Did something happen? Why do you look so sad?"
    new "何？何かあったのか？どうしてそんなに悲しそうな顔をしてるんだよ？"

    # say L350 lyd
    old "Well... the thing is..."
    new "えっと… そのことなんだけど…"

    # say L351 lyd
    old "Ugh, I've been talking with a couple of men on tinder, and..."
    new "うーん、Tinderで何人かの男性と話してるんだけど…"

    # say L352 pla
    old "Oh, did I make a mistake choosing their profiles? Is there something wrong with them?"
    new "俺が選んだプロフィールに何か問題でもあるのか？それとも彼らに何か不満があるのか？"

    # say L354 lyd
    old "Hmm, their perfectly nice gentlemen, very smart and all."
    new "うーん、彼らはとても紳士的で、頭も良いのよ。"

    # say L355 lyd
    old "But, they're very old! As old as my ex husband was! And I don't want that!"
    new "でも、彼らはとても年上よ！元夫と同じくらいの年齢よ！そんなの欲しくないわ！"

    # say L356 lyd
    old "I mean, I just widowed a man that age."
    new "つまり、その年齢の男性と Widowed になっちゃったのよ。"

    # say L357 lyd
    old "When I talked about dating again I was thinking more along the lines of young, energetic men, full of vitality... You know?"
    new "再婚について話すとき、私は若い、活力に満ちた男性を想像していたの……分かる？"

    # say L359 pla
    old "I- I guess I do."
    new "俺ー、そうかもしれないな。"

    # say L360 lyd
    old "Why is the app only pairing me with these old guys?"
    new "なんでこのアプリはいつも年取った男の人としかマッチングしないの？"

    # say L361 pla
    old "Uhh, I don't really know why."
    new "うーん、なんでなのかよく知らないけど。"

    # say L362 pla
    old "Maybe it's the algorithm putting you with people your age."
    new "アルゴリズムが君の年齢に近い人を紹介してるのかもしれないね。"

    # say L363 pla
    old "But, I think there might be something we can do about that."
    new "でも、何か手を打てるかもしれないな。"

    # say L364 lyd
    old "Yeah? What is it?"
    new "へえ？何それ？"

    # say L365 pla
    old "Well, we could 'fix' your profile. Improve it a little."
    new "俺たち、君のプロフィールを‘修正’できるよ。ちょっと改善してさ。"

    # say L366 lyd
    old "What do you mean by 'fix'?"
    new "何を『修正』するの？"

    # say L367 pla
    old "We could, for example, put a better picture of you. Or maybe another description of you in the bio."
    new "例えば、君のもっと良い写真を載せたり、プロフィールの説明をちょっと変えてみたりできるよ。"

    # say L368 pla
    old "Something that will be more attractive to younger men."
    new "若者の目に魅力的に映るようなものさ。"

    # say L370 lyd
    old "That sounds like a great idea!"
    new "それは素晴らしいアイデアね！"

    # say L371 pla
    old "Yeah, keeping in mind that those are the things that people will see when they go to your profile."
    new "そうだ、それらのことを考えて、プロフィールを見たときに目につくようにしよう。"

    # say L372 pla
    old "We could work on them to get more young people to swipe right instead of left on your profile."
    new "若者に右にスワイプしてもらうため、プロフィールをもっと魅力的に手伝うよ。"

    # say L373 lyd
    old "That'd be perfect, let's do it."
    new "それが完璧ね、やろうよ。"

    # say L382 pla
    old "The first thing is the picture, do you have any picture in which you look a little more casual?"
    new "まずは写真だな、君のちょっとカジュアルな写真ってある？"

    # say L383 lyd
    old "I think I do, yeah, there must be a couple of some trips and excursions there in the phone."
    new "あたしのスマホには、ちょっとカジュアルな写真がいくつかあると思うわ。旅行や遠足の時のものね。"

    # say L388 pla
    old "Ok, that's perfect, now for the bio."
    new "じゃあ、それが完璧だな、次はプロフィールの文言を考えよう。"

    # say L389 pla
    old "I think we could maybe change it for either something more casual or a little bit more... Uhh, seductive."
    new "俺はちょっとカジュアルな感じか、もう少し……うーん、セクシーな感じに変えるのはどうだろう。"

    # say L390 pla
    old "What do you think?"
    new "どう思う？"

    # say L392 lyd
    old "Well, if that helps, I think we should give it a try."
    new "まあ、それが役立つなら、試してみるべきだと思うわ。"

    # say L393 pla
    old "Alright, let me think in something."
    new "よし、考えてみるか。"

    # say L398 pla
    old "Ok, it's ready, what do you think?"
    new "よし、準備はできた、どう思う？"

    # say L399 lyd
    old "It looks great! And I think I get what you were saying, this one definitely sounds and looks a lot more attractive."
    new "すごいね！あなたが言いたかったことも理解できたわ。これなら確かに魅力的に見えるし、聞こえるわ。"

    # say L402 pla
    old "I'm glad you like it. I'm sure this time we'll attract some younger men."
    new "君が気に入ってくれて嬉しいな。今度は若い男の子たちを引きつける自信があるよ。"

    # say L404 pla
    old "Do you want to try now? I could get on the app and see if you can make a match with some new people."
    new "今試してみる？アプリを開いて、新しい人とマッチングできるか見てみようか。"

    # say L405 lyd
    old "Sure, just one little thing pumpkin. What does that GILF thing mean? Is it some kind of world play?"
    new "もちろん、一つだけ聞きたいの、かぼちゃ。そのGILFって何の意味？言葉遊びかな？"

    # say L406 pla
    old "Uhh, t-that... yeah."
    new "うーん、その…そうだね。"

    # say L407 pla
    old "It's actually an acronym."
    new "実際には頭文字の略称なんだ。"

    # say L409 lyd
    old "It is? What does it stand for?"
    new "そうなの？　何の略称か教えて？"

    # say L410 pla
    old "Hmm, it stands for... Great... I- Intelligent, L- Loving... Friend."
    new "ん、それは…… G- Great… I- Intelligent, L- Loving… Friendってことだよ。"

    # say L411 pla
    old "It's something that people my age understand, don't worry."
    new "俺たちの世代が理解できるものだよ、心配しないで。"

    # say L413 lyd
    old "Ohh, I see! That's great! Thank you."
    new "オッ、わかった！ありがとう。"

    # say L414 lyd
    old "Well, I guess we can start looking for some profiles now."
    new "じゃあ、プロフィール探すところから始めようか。"

    # say L433 lyd
    old "Hi pumpkin!"
    new "おひさしぶり、かぼちゃ！"

    # say L434 lyd
    old "I'm very fine, thank you."
    new "私はとっても元気よ、ありがとう。"

    # say L435 pla
    old "Oh yeah? Has anything good happened on tinder?"
    new "オーよ？ティンダーで何かいいことあった？"

    # say L436 lyd
    old "Well, you could say that. Ever since we changed my profile the number of young men talking to me has increased. It's been very exciting."
    new "まあ、そう言えるわね。プロフィールを変更してから、若い男性からの連絡が増え、とても興奮してるの。"

    # say L437 pla
    old "That's good to hear. So, it worked! it's what you expected, right?"
    new "それは良かったな。うまくいったんだ！君が期待した通りだよな？"

    # say L438 lyd
    old "Hmm, it kinda is but..."
    new "うーん、そうかもしれないけど…"

    # say L439 pla
    old "What? Anything wrong with anyone?"
    new "何？誰かに問題でもあるの？"

    # say L440 lyd
    old "No, nothing wrong per se with the people I'm speaking to or the app."
    new "いいえ、話してる人たちはともかく、アプリ自体には問題ないの。"

    # say L442 pla
    old "Then what is it?"
    new "じゃあ、何が問題なのか？"

    # say L444 lyd
    old "Well, it's more to do with their language."
    new "まあ、それは彼らの言葉遣いの方が問題なんだ。"

    # say L445 lyd
    old "To be honest I don't understand a lot of what they say. There is this one guy I was talking to."
    new "正直、彼らの言うことがよくわからないの。この間、ある男の人に話しかけたのけど。"

    # say L446 lyd
    old "And he suddenly began writing things like, lmao, brb, tbh."
    new "そして急に lmao、brb、tbh って書くようになったの。"

    # say L448 lyd
    old "And when asked him what he meant."
    new "そして彼に何を意味しているのか聞いたの。"

    # say L449 lyd
    old "And he answered saying: 'lol, Idk wdym?"
    new "そして彼は答えた、「lol、Idk wdym？」"

    # say L450 lyd
    old "What?! What does that even mean?!"
    new "何？それってどういう意味よ？！"

    # say L453 lyd
    old "Yeah, how am I even supposed to talk to these people?"
    new "この人たちとどうやって話せばいいの？"

    # say L455 lyd
    old "Don't laugh, this isn't funny."
    new "笑わないで、これは面白くないんだから。"

    # say L456 pla
    old "Y-you're right, sorry."
    new "君が言う通りだ、ごめん。"

    # say L457 pla
    old "It's just that I wasn't expecting that. But, I get what you mean, I guess young people talk in a confusing way."
    new "ただ、予想外だったんだけど、若者の言葉って分かりにくいんだな。"

    # say L458 pla
    old "Don't worry, they're not saying anything weird, they're just abbreviations, so you don't have to write the whole thing."
    new "心配しなくていい、weirdなわけじゃなくて、略してるだけだから全部書かなくてもいいんだよ。"

    # say L459 pla
    old "I'll teach you how to use them."
    new "教えてやるよ。"

    # say L460 lyd
    old "Well, I thank you, but I don't think that's going to do much for me. Because I've got another problem with the app."
    new "まあ、ありがとうけど、それだけじゃ私の問題は解決しないわ。アプリ自体に別の問題があるのね。"

    # say L461 lyd
    old "And is that damned keyboard, it's so small! I have no idea how you can write so fast on those little keyboards; you can't even see them!"
    new "その邪魔な小さいキーボードが問題なの！こんな小さなキーでどうやってそんなに早く打てるのか全然わからないよ、ほとんど見えないんだから！"

    # say L462 pla
    old "Come on, come on, don't stress too much about it."
    new "心配するな、そんなに気にするな。"

    # say L463 pla
    old "Let's just work on it and in no time you'll master them. You'll see."
    new "さ、やってみよう。すぐになれるよ。見なさい。"

    # say L464 lyd
    old "If you say so. I guess I can try to learn..."
    new "言われてみれば、試してみるしかないかな。"

    # say L470 lyd
    old "What a coincidence, this is the guy I was talking with yesterday night."
    new "何だか偶然ね、この人とは昨日の夜話したばかりだったの。"

    # say L471 lyd
    old "I know! Why don't we try speaking to him now? You could write for me!"
    new "知ってる！今すぐ彼と話してみようよ。あなたが代わりに書いてくれたら、もっと楽だよ！"

    # say L472 pla
    old "Hmm, I don't know, I mean, it's your conversation."
    new "うーん、よくわかんないけど、それは君の会話だよ。"

    # say L473 lyd
    old "Oh please, since you'll actually understand if he uses those abbreviations, and you can use the keyboard."
    new "お願い、あなたが略語を理解できるから、キーボードも使えるよね。"

    # say L474 lyd
    old "Why don't you just tell me what he's saying and I'll tell you what to answer?"
    new "私が彼の言っていることを教えて、あなたにどう答えるべきか教えてあげようと思わない？"

    # say L475 pla
    old "Hahaha, that sounds odd."
    new "ははは、それは変な感じだね。"

    # say L476 pla
    old "But I guess we can try."
    new "でも、試してみるか。"

    # say L477 pla
    old "So, you see that it's not that difficult."
    new "だから、そんなに難しくないってわかるだろ。"

    # say L491 lyd
    old "What did he say?"
    new "何って言ったの？"

    # say L492 pla
    old "He's just saying hello, and asking how you are today."
    new "彼はただ挨拶して、今日の調子はどうかって聞いているだけだよ。"

    # say L493 lyd
    old "Well, don't keep him waiting! Say hello back!"
    new "じゃあ、待たせないで！挨拶返しちゃおう！"

    # say L497 lyd
    old "What did he say now?"
    new "何言ってるの？"

    # say L498 pla
    old "He said..."
    new "彼は言った..."

    # say L499 lyd
    old "Here, let me see!"
    new "ここ、見せてよ！"

    # say L500 lyd
    old "Hmm, 'hbu'? What is that supposed to mean?"
    new "へえ、『ｈｂｕ』？それってどういう意味？"

    # say L501 pla
    old "It means 'How about you?'"
    new "それは「君はどう？」って意味だよ。"

    # say L502 lyd
    old "Jesus, and he couldn't write that? How lazy are young people these days?"
    new "Jesus、そんなの書けないの？若者は本当に.lazyだな。"

    # say L503 pla
    old "It's not about being lazy, just answering fast."
    new "それは怠けじゃない、ただ早く答えるだけだよ。"

    # say L504 pla
    old "Which by the way, he's waiting for us to answer him."
    new "それに言って、彼は俺たちの返事を待ってるんだ。"

    # say L505 lyd
    old "Oh shoot, right!"
    new "あっ、そうだった！"

    # say L506 lyd
    old "Tell him: 'Oh, it's so good that you exercise, that's very good for the joints and muscles."
    new "彼に伝えて、「あ、運動してるのね。関節や筋肉にはとても良いわよ。」"

    # say L507 lyd
    old "Be sure to hydrate and rest properly."
    new "水分補給と十分な休息を忘れずにね。"

    # say L508 pla
    old "Wait, what?!"
    new "待て、何だよ？！"

    # say L509 pla
    old "Hahahahaha."
    new "ははははは。"

    # say L510 lyd
    old "Now what's so funny?"
    new "何がそんなに面白いの？"

    # say L511 pla
    old "Hahaha, well, we can't tell him that. You'd sound like a P.E. teacher. You have to be a little more playful."
    new "ははは、でもそれ言ったら君、体育の先生みたいになっちゃうよ。もっと遊び心を出さないとね。"

    # say L513 lyd
    old "Playful?"
    new "遊び心？"

    # say L514 pla
    old "Yeah you know, something about how attractive that is to you and stuff."
    new "俺がそれをどれだけ魅力的だと思うか話すような感じだな。"

    # say L515 lyd
    old "I see, well..."
    new "なるほど、まあ..."

    # say L516 lyd
    old "How about this?"
    new "これならどう？"

    # say L517 lyd
    old "I love that you exercise, you must be in great shape then."
    new "運動してるの好きだね、きっと体も引き締まってるだろうね。"

    # say L518 pla
    old "Hmm, not really playful, but it could work."
    new "うーん、それほど遊び心はないけど、まあいけそうかな。"

    # say L519 pla
    old "Let's see how it goes."
    new "じゃあ、どうなるか見てみようか。"

    # say L523 pla
    old "He said 'Oh yeah, maybe if you're lucky I'll let you take a peek later.'"
    new "オーケー、もしかしたら運が良ければ後で見せてくれるかもしれないと言ったんだ。"

    # say L524 lyd
    old "Oh, hahaha, that's so cute. Then tell him that..."
    new "ははは、かわいいわね。それじゃ、彼に言ってあげて…"

    # say L525 pla
    old "Wait, there's more."
    new "待て、まだあるんだ。"

    # say L527 pla
    old "Hmm, he says 'Judging from your pictures you must be super hot too.'"
    new "ん、彼は「君の写真から見ると、君も相当 hottest だろうな」って言ってるよ。"

    # say L528 lyd
    old "Oh, really? That's so nice!"
    new "ほんと？ そんなに sweetness なのね。"

    # say L529 lyd
    old "Hmm... Tell him 'You're joking, right? I'm just an old woman.'"
    new "へえ……彼に「冗談でしょう？私はただのおばさんですよ」と伝えて。"

    # say L530 pla
    old "Really? Hmm alright..."
    new "ほんと？ふむ、わかった…"

    # say L534 pla
    old "He says 'Come on! Don't say that, I'm sure you're beautiful.'"
    new "Come on！そんなこと言わないで、君は絶対に美しいよ。"

    # say L535 pla
    old "And then he says 'Also, I wouldn't call you 'old'. On the contrary, I think you're very experienced, and experience is sexy.'"
    new "それに、君を『古い』とは呼ばないよ。むしろ、君はとても経験豊富で、その経験がセクシーなんだ。"

    # say L536 lyd
    old "Hahaha, what a cute guy."
    new "ハハハ、かわいい男の子ね。"

    # say L537 lyd
    old "Tell him 'Well it seems you know how to compliment a lady.'"
    new "じゃあ、あなたにはレディを褒める方法もあるみたいね。"

    # say L542 pla
    old "He says 'That's not the only thing I know how to do with a lady.'"
    new "それはレディとやることの一つじゃないよ。"

    # say L545 pla
    old "And now he adds 'Why don't we go out for dinner and you let me show you?'"
    new "それじゃ、ディナーに行かない？君に見せてあげるよ。"

    # say L546 lyd
    old "Well isn't he brave? He just invited me to date out of the blue!"
    new "まあ、ずいぶんと勇気があるわね。いきなりデートに誘っちゃった。"

    # say L547 lyd
    old "But I don't think I should accept just like that, I don't want him to think that I'm desperate."
    new "でも、そんなに簡単には受け入れたくないわ。彼に私が必死だって思われたくないから。"

    # say L548 pla
    old "Then what should I tell him?"
    new "じゃあ、俺は何て言えばいいんだ？"

    # say L549 lyd
    old "Hmm, let me think..."
    new "うーん、考え中..."

    # say L550 lyd
    old "I got it."
    new "わかったわ。"

    # say L551 lyd
    old "Tell him 'Ohh, I don't know, I think you'll be bored if you go out with an old woman like me.'"
    new "ああ、そうね、私みたいな年寄りと出かけるなんて、退屈しちゃうわよ。"

    # say L553 lyd
    old "Why did you write 'idk' what does that mean?"
    new "なんで『idk』って書いたの？それって何の略？"

    # say L554 pla
    old "I mean 'I don't know' it's just so that he doesn't think you're super formal."
    new "俺は「知らない」って意味さ。ただ、彼があなたが超フォーマルだと思わないように、ってだけだよ。"

    # say L555 lyd
    old "Ohh, I see."
    new "オッ、そうだったの。"

    # say L557 lyd
    old "Hmm, isn't he something?"
    new "Hmm、彼って何か特別だね。"

    # say L558 lyd
    old "Write 'Oh really? Are you sure you're not just saying that to try and get in my pants?'"
    new "ほんとう？本当に私に惚れってるだけでないの？"

    # say L563 pla
    old "He's saying 'Of course not, I honestly think you're super interesting.'"
    new "もちろん違うよ、君のこと本当に興味深いと思うんだ。"

    # say L564 pla
    old "And also 'But hey, for what it's worth, I do like my women a little older ;)'"
    new "でもね、君の年上さが気に入ってるんだよ ;)"

    # say L567 lyd
    old "Hahahaha, tell him 'Well, aren't you something?'"
    new "ははは、そう言っときなさい。「まあ、あなたってのは珍しいわね」"

    # say L571 pla
    old "Uhh... Now he's saying 'Baby I'm a little more than just something'"
    new "うーん… 今度は「ベイビー、俺はただの何かよりちょっと多いってことだよ」って言ってるんだ"

    # say L572 pla
    old "And he is asking if you want to... Uhh, see."
    new "君が見たいかどうか聞いてるんだよ。"

    # say L573 lyd
    old "See? See what?"
    new "見せる？何を見せるの？"

    # say L574 pla
    old "Well... you know."
    new "まあ……分かってるよね。"

    # say L575 lyd
    old "Know what? Ask him, 'see what?'"
    new "知ってるでしょ？彼に「何見てるの？」って聞いとけばいいじゃん。"

    # say L580 pla
    old "He replied 'lol, you bad girl, you know what I mean...'"
    new "彼は「lol、悪い子ね、何言ってるか分かってるでしょ」って言ったよ…"

    # say L581 lyd
    old "Lol? What's that?"
    new "ロル？それって何？"

    # say L582 pla
    old "It means: 'Laughing out loud'."
    new "それは「大声で笑っている」って意味だよ。"

    # say L584 lyd
    old "So, something that I said was funny?"
    new "じゃあ、私が何か面白いことを言ったってこと？"

    # say L586 lyd
    old "But what? And what's he talking about me knowing what he means?"
    new "でも何？彼が何を意味しているのを私が知っているって？"

    # say L589 lyd
    old "Oh wow! I wasn't expecting that!"
    new "おわ！そんなことになるとは思わなかった！"

    # say L590 pla
    old "Hmm, me neither..."
    new "俺もな..."

    # say L591 lyd
    old "What do I answer now?"
    new "今何答えるべき？"

    # say L593 pla
    old "Hmm, I- I guess you can tell him how surprised you are."
    new "うーん、君がどれだけ驚いたか伝えてあげたらどうかな。"

    # say L594 lyd
    old "Sure, tell him that I wasn't expecting that picture."
    new "うん、彼に私がその写真を予想していなかったって伝えて。"

    # say L598 pla
    old "He replied: 'Hahaha, well, you know... yolo, right?'"
    new "ははは、まあ、君も知ってるだろ…yoloってさ。"

    # say L600 lyd
    old "Yolo?"
    new "ヨロ？"

    # say L602 pla
    old "You only live once."
    new "生きてる間は一度きりだな。"

    # say L603 lyd
    old "You young people, honestly..."
    new "あなた方若い連中、ほんとね..."

    # say L605 pla
    old "He wants to know what you thought about the picture."
    new "彼が写真についてどう思ってるか知りたいんだ。"

    # say L606 lyd
    old "Really? W- what should I tell him?"
    new "ほんと？ ええと、何て言えばいいの？"

    # say L608 pla
    old "Just tell him what you think."
    new "思ってることをそのまま伝えてくれ。"

    # say L609 lyd
    old "Well, let me see it again..."
    new "WELL、もう一度見てみよう..."

    # say L616 lyd
    old "Well, I wasn't expecting him to just send it. That was very unexpected."
    new "ええっと、彼がただ送ってくるとは思わなかったわ。それは本当に意外だった。"

    # say L617 lyd
    old "But if I'm honest, it's very... impressive. Also, he's rock hard, do you think that's for me?"
    new "でも正直に言うと、とても…凄いわ。それに彼は全然硬くなってるし、これは私へのメッセージかな？"

    # say L619 pla
    old "Do I tell him that?"
    new "言っちゃうか？"

    # say L620 lyd
    old "Well, that's what I think about that pic."
    new "まあ、その写真についてはそう思ってるわ。"

    # say L621 pla
    old "Alright, I'll tell him that."
    new "分かった、伝えるよ。"

    # say L628 pla
    old "Of course it is, to be honest, you're super hot, so hot that you make me hard just thinking about being with you."
    new "もちろんさ、正直に言うと君は超sexyだ、それほどまでにsexyだから、君と一緒にいるだけでも俺のちんこが固くなるよ。"

    # say L630 lyd
    old "That that's very sweet, thank you."
    new "それはとても優しいわ、ありがとう。"

    # say L633 lyd
    old "And to be honest, seeing your hard dick also turns on a little."
    new "正直に言うと、あなたの硬くなったチ○ポを見るだけで少し興奮しちゃうの。"

    # say L636 pla
    old "Oh yeah? Tell me how much."
    new "オーよ？どれくらい興奮してるか教えて。"

    # say L637 lyd
    old "Mmm, just seeing your hard dick is making me horny."
    new "見ただけで、もう私、欲しくなっちゃってるの。"

    # say L640 pla
    old "That's it baby and thinking about your wet pussy makes me even harder."
    new "そうだよベイビー、君の濡れたマンコを想像するとさらに Erect になるんだ。"

    # say L648 lyd
    old "Yes, my pussy is dripping just thinking about your cock."
    new "うん、あなたのチ○ポを想像するだけで、私のマ○コはもうびしょびしょなの。"

    # say L652 pla
    old "Oh baby, I want to fuck you with this big cock."
    new "オーベイビー、この大きなちんこで犯したいんだ。"

    # say L653 lyd
    old "Oh yes, I want you to come over and put that hard cock in me."
    new "ああ、そうしてほしいの。その硬いチ○ポを私の中に入れてください。"

    # say L656 pla
    old "Do you really want that baby?"
    new "本当にそれが必要だよ？"

    # say L657 lyd
    old "Oh yes! I want it so bad!"
    new "ああん！そんなに欲しくて仕方ないの！"

    # say L662 pla
    old "Tell me, what else do you want me to do to you?"
    new "教えて、他に何をしたいのか？"

    # say L663 lyd
    old "I want you to come over and pull my hair while you fuck me!"
    new "あなたが来て、私の髪を引っ張りながらセックスしてほしいの！"

    # say L666 pla
    old "Yes! I'll pull your hair while I fuck you from behind!"
    new "うん！後ろから突きながら髪を引っ張るよ！"

    # say L669 lyd
    old "Yes! Yes! I want you to pull my hair and slap my ass!"
    new "はい！はい！髪を引っ張って、お尻を叩いて！"

    # say L672 pla
    old "I'll pull your hair and call you my little slut!"
    new "髪を引っ張って、君を小さなスレートと呼ぶよ！"

    # say L673 lyd
    old "Oh yeah! I'm your little slut!"
    new "オーキャー！私はあなたの小さなスレートよ！"

    # say L681 lyd
    old "Mmmm... Phew..."
    new "うん…… ああ……"

    # say L682 lyd
    old "Wow, that was fun."
    new "わー、楽しかったね。"

    # say L688 pla
    old "He says he has to go now, he is late for his work."
    new "俺今仕事に遅刻するから行かなきゃいけないんだ。"

    # say L689 lyd
    old "Ohh... hmm, sure."
    new "オッ……そうね。"

    # say L693 pla
    old "He says 'It was awesome, you really are cool. I can't wait to meet you in person.'"
    new "君は本当にクールだな、最高だったよ。また会えるのを楽しみにしてる。"

    # say L695 lyd
    old "Uhh t- thanks... see you later."
    new "うーん、ありがとう…　またね。"

    # say L697 pla
    old "Ok, I think it's done, so I'm going home."
    new "じゃあ、これで終わりだな。家に帰るぞ。"

    # say L707 lyd
    old "Uhh... Listen [pla]. I- I'm sorry. I didn't mean it for things to turn this way."
    new "うーん… 聞いて [pla]。ごめん。こんな風になるつもりじゃなかったの。"

    # say L708 lyd
    old "I'm sorry, I don't know what happened."
    new "ごめんなさい、何が起こったのかわからないの。"

    # say L709 lyd
    old "It's just that it's been so long since any kind of you know... Release."
    new "ただ、ずいぶん長い間、あの、解放感がなかったからさ。"

    # say L710 lyd
    old "I wasn't expecting the conversation to take a turn that way."
    new "そんな風に話が進むとは思ってなかったの。"

    # say L711 lyd
    old "But please believe me that I didn't plan any of this, I just couldn't help it."
    new "でも信じてほしいの、これ全部計画したわけじゃなくて、我慢できなかっただけ。"

    # say L712 pla
    old "Hey, hey, it's ok. Don't worry."
    new "Hey, hey,大丈夫だよ。心配するな。"

    # say L713 pla
    old "I understand, and I'm not angry."
    new "分かってるよ、怒ってないさ。"

    # say L714 pla
    old "I won't lie, I'm a little surprised."
    new "驚きは隠せないけど、怒ってるわけじゃないよ。"

    # say L715 pla
    old "But, I understand. After all, the whole point of doing this was for you to let loose and meet new people."
    new "でも、分かってるよ。結局のところ、君がリラックスして新しい人と出会うためだったんだろ。"

    # say L716 lyd
    old "Thank you so much [pla]. You're an angel for understanding."
    new "ありがとう、[pla]。理解してくれて本当に感謝してる。"

    # say L717 pla
    old "No biggie, but maybe I should go now."
    new "大丈夫だけど、俺はもう帰るかな。"

    # say L718 lyd
    old "Yeah, you're right. Anna might come back any minute."
    new "うん、そうだね。アンナがいつ戻ってきてもおかしくないから。"

    # say L719 pla
    old "Yeah, however, I'm glad to see that you're making progress with your online app."
    new "そうだ、でも君がオンラインアプリの開発で進展を遂げているのは嬉しいよ。"

    # say L721 lyd
    old "But being honest it's all thanks to your help."
    new "でも正直、あなたの助けがあったからこそだね。"

    # say L722 pla
    old "It's nothing, I'm glad I can be of help to you."
    new "全然いい、君の役に立てて嬉しいよ。"

    # say L723 pla
    old "Keep chatting and I'll be back soon to keep helping you."
    new "話しっぱなしだと、すぐ戻ってまた手伝うからな。"

    # say L724 lyd
    old "All right, Thank you!"
    new "わかった、ありがとう！"

    # say L746 pla
    old "Hi, how a..."
    new "お、どうしてる？"

    # say L748 pla
    old "Is everything alright? Did anything happen?"
    new "大丈夫か？何かあったのか？"

    # say L750 lyd
    old "Hi [pla] how are you?"
    new "元気か [pla]？"

    # say L751 lyd
    old "I guess everything's right. I'm just not feeling well right now."
    new "多分大丈夫だけど、今ちょっと具合が悪いの。"

    # say L753 lyd
    old "Hmm, well, it's not much."
    new "うーん、まあ、そんなに良いわけじゃない。"

    # say L754 lyd
    old "It's just that I went out with that guy you were helping me chat with."
    new "その男の人のこと、あなたが手伝ってくれたあの人と出かけただけなの。"

    # say L756 lyd
    old "And it didn't go well, it was actually kinda bad."
    new "でもうまくいかなかったの、実際にはちょっと悪かったの。"

    # say L759 pla
    old "Did he say anything bad to you?"
    new "何か悪いこと言われたのか？"

    # say L761 lyd
    old "No, no. The problem is that it didn't feel good."
    new "いいえ、いいえ。問題は、それが全然気持ち良くなかったことよ。"

    # say L763 lyd
    old "We only talked about everyday stuff and the conversation didn't go anywhere from there. Is just as if he had lost all interest."
    new "私たちはただ日常のことを話しただけだし、会話が全然進展しなかったの。まるで彼が一切の興味を失ったみたい。"

    # say L764 lyd
    old "I swear to god he wasn't even looking at me!"
    new "神に誓って、彼は私を見てさえいなかったわ！"

    # say L765 lyd
    old "And after saying all that stuff on our chat."
    new "そのチャットの後ね。"

    # say L766 lyd
    old "It's extremely disappointing."
    new "すごくがっかりしてるの。"

    # say L767 pla
    old "I see, I'm sorry that happened."
    new "そうか、すまんね。"

    # say L769 lyd
    old "But to be honest [pla]. This date got me thinking."
    new "でも正直に言うと [pla]、このデートでいろいろ考えちゃったの。"

    # say L770 lyd
    old "And I don't think this whole thing of looking for younger men is for me."
    new "でも正直に言うと、若い男の子を探してるってのは私には合ってないみたい。"

    # say L772 lyd
    old "Think about it, I don't even understand what they're saying when they write with those strange words they make up."
    new "考えてみれば、彼らが創作した奇妙な言葉の意味さえ理解できないわ。"

    # say L773 lyd
    old "And when I got a date with a guy that seemingly wanted to have something with me."
    new "そして、私が何かを求めていた男の子とデートしたとき。"

    # say L774 lyd
    old "He just lost all interest and began treating me all cordial and distant."
    new "彼は興味を失って、急に丁寧で冷たい態度になった。"

    # say L777 lyd
    old "I didn't like that at all. I'm not doing this to be looked at as if I was their grandma."
    new "全然好きじゃなかったわ。私はおばあさんみたいに見られたくなんてないの。"

    # say L778 lyd
    old "So it's better if we just look for older men that are my age, I think I can date then."
    new "だから、年上の人だけど私の年齢くらいの人と付き合った方がいいんじゃないかと思う。"

    # say L780 pla
    old "Well, I get what you mean."
    new "まあ、君の気持ちはわかるけど。"

    # say L781 pla
    old "But I don't actually think that's what you want Lydia."
    new "でも、実際にはそれが君が本当に欲していることじゃないと思うんだ、Lydia。"

    # say L782 pla
    old "Listen, that guy was an idiot. You shouldn't let his attitude bring you down."
    new "聞いて、その男はただのアホだ。彼の態度で君の気分を下げちゃいけない。"

    # say L783 lyd
    old "Hmm, you say that but..."
    new "うーん、そう言うけど…"

    # say L784 pla
    old "Listen, you went on a date, and it didn't go great because the guy turned out to be an asshole."
    new "君がデートしたのは事実だけど、うまくいかなかったのは相手のクソ野郎が原因だよ。"

    # say L785 pla
    old "I get it sucks, but that stuff happens."
    new "分かってる、つらいことはつらいけど、そういうこともあるさ。"

    # say L786 pla
    old "Believe me, if it didn't go well it's because of him. You didn't have anything to do with that."
    new "信じろ、上手くいかなかったらそれは彼のせいだ。君には何の問題もないんだ。"

    # say L790 pla
    old "Of course! I mean, look at you. You are beautiful, and you're great to hang around. Any guy would be lucky to be with you."
    new "もちろん！君を見ろよ。君は美しいし、一緒にいても楽しい。どんな男も君と一緒にいられるだけでラッキーだよ。"

    # say L791 lyd
    old "Hmph, you're sweet, but I know you're only saying that to cheer me up. I know you don't mean it."
    new "ふん、甘いこと言うけど、慰めるためだけだってのはわかってるわ。本気でそう思ってないってことね。"

    # say L792 pla
    old "Swear to god that I do."
    new "神にかけて本当のことだよ。"

    # say L793 lyd
    old "Well then you're the only one!"
    new "じゃああなただけよ！"

    # say L794 lyd
    old "I mean let's just face it [pla]. I'm an old lonely widow with nothing to offer to any guy."
    new "つまり認めるけど [pla]、私はただの老いた孤独な未亡人で、男の人には何も提供できないの。"

    # say L795 lyd
    old "Besides, I can't compete with the girls young men go around with. With their perfect toned bodies."
    new "それに、若い男の子たちが付き合う女の子たちには太刀打ちできないわ。あの完璧なボディに比べたら。"

    # say L796 lyd
    old "I'm old, any sex appeal that I had I lost a long time ago."
    new "私は年取っちゃったから、セクシーさも昔とは全然違うわ。"

    # say L797 pla
    old "W- What?! What are you saying? You can't be serious."
    new "何言ってんだ、リディ？本気で言ってるわけないだろ。"

    # say L798 lyd
    old "Well, I am!"
    new "だって、本当よ！"

    # say L799 lyd
    old "It's just true, I'm no longer pretty."
    new "ただの真実よ、もう可愛いと思われないの。"

    # say L800 pla
    old "What are you talking about, you're so beautiful."
    new "何言ってるの、君はすごく綺麗だよ。"

    # say L801 pla
    old "You're still a very sexy woman, your face, your body, everything about you is perfect."
    new "君はまだとてもセクシーな女だ、顔も身体も全部パーフェクトだよ。"

    # say L802 lyd
    old "Yeah right..."
    new "そうよね..."

    # say L803 pla
    old "I mean it, any man would find you to be incredibly sexy."
    new "本気で言ってる、君のことを超セクシーだと思う男は絶対いるさ。"

    # say L808 lyd
    old "Any man?"
    new "どんな男も？"

    # say L809 pla
    old "All of them?"
    new "全員？"

    # say L811 lyd
    old "... Even you?"
    new "あなたも...？"

    # say L814 lyd
    old "Yeah, you, you said any man would think I'm sexy."
    new "うん、あなたもそう言ったわね。私がセクシーだって誰でも思うって。"

    # say L815 lyd
    old "How about you? Do you really think I'm sexy?"
    new "あなたは？ ほんとうに私がセクシーだと思ってるの？"

    # say L817 pla
    old "Uhh, w- well, yeah, I mean..."
    new "うーん、えーと、まあ、そうだけどね..."

    # say L818 lyd
    old "You mean what?"
    new "何を言っているの？"

    # say L819 lyd
    old "I knew it! You also just think I'm old!"
    new "分かっていたわ！あなたもただ私が年取ってると思ってるだけじゃない！"

    # say L820 pla
    old "No, no, not at all."
    new "いや、全然違うよ。"

    # say L821 pla
    old "It's just that I wasn't expecting you to ask me that."
    new "ただ、君がそんなこと聞いてくるとは思ってなかったんだ。"

    # say L822 pla
    old "But I mean, of course, I also think you're sexy."
    new "でもさ、もちろん君のことセクシーだと思ってるよ。"

    # say L824 lyd
    old "Really? And you actually mean it? You're not just saying that to please me?"
    new "本当に？本気でそう思ってるの？ただ私が喜ぶための言葉じゃないよね？"

    # say L826 pla
    old "For real, I mean it 100."
    new "本気だよ、100％Seriously、本気だよ。"

    # say L828 lyd
    old "Well, I don't know if you're lying, but just you saying I'm sexy is not enough."
    new "あなたがウソをついているかどうかは知らないけど、ただ私がセクシーだと言われただけじゃ足りないわ。"

    # say L829 lyd
    old "But there's one way to know for certain... Your cock."
    new "でも、確実にわかる方法があるの……あなたのチ○ポ。"

    # say L830 pla
    old "My cock? W- what do you mean?"
    new "俺のちんこ？　ワ、何のことだよ？"

    # say L831 lyd
    old "To know if you're lying, you may say I'm sexy, but if you don't have an erection I won't believe you."
    new "嘘をついているかどうか、あなたが私をセクシーだと言っても、もし勃起していなかったら信じないわ。"

    # say L832 lyd
    old "It's the same with all men, the penis never lies."
    new "男の人はみんな同じよ、ペニスは決してうそをつかないわ。"

    # say L833 lyd
    old "So..."
    new "じゃあ……"

    # say L837 pla
    old "W- whoa! What are you doing?"
    new "わお！何やってんの？"

    # say L841 lyd
    old "Well, I wanted to know what you think about my breasts."
    new "WELL、私の胸についてどう思ってるか知りたかったの。"

    # say L842 lyd
    old "How about now? Do you still think I'm sexy?"
    new "今はどう？ まだ私をセクシーだと思う？"

    # say L843 pla
    old "Y- yeah, of course."
    new "うん、もちろんさ。"

    # say L844 lyd
    old "So, look at them, and let's see if your cock thinks the same."
    new "じゃあ、見てみなさい。あなたのちんこが同じように思うかどうか試してみよう。"

    # say L845 pla
    old "I don't think that's a good idea. After all..."
    new "そんなのはいいアイデアじゃないと思うよ。結局..."

    # say L846 lyd
    old "Stop putting up excuses and see my tit!"
    new "言い訳はやめて、私の胸を見てみなさい！"

    # say L847 lyd
    old "Or I'll know you're lying to me."
    new "それじゃあ、あなたが私をだましてるってことね。"

    # say L854 lyd
    old "Oh wow, this is impressive."
    new "おわ、これはすごいわ。"

    # say L855 lyd
    old "Ok, I believe you, if you're this hard you must be telling the truth."
    new "うん、信じるわ。これだけ硬くなってるんだから、本当のこと言ってるに違いない。"

    # say L856 pla
    old "Yeah, well, I do believe you're very beautiful."
    new "そうだよ、君は本当に美しい。"

    # say L857 lyd
    old "Well, I have no doubt about that now."
    new "そうね、それについては今さら疑う余地もないわ。"

    # say L858 lyd
    old "I must say [pla] your cock is something else."
    new "[pla] あなたのチ○ポは本当に特別だね。"

    # say L859 lyd
    old "It's so... big."
    new "それは… 大きいね。"

    # say L860 lyd
    old "I- I can believe that it is because of me."
    new "私、それが私のせいだって信じられないわ。"

    # say L862 lyd
    old "It's really flattering that such a young man like you can feel that way about a woman my age."
    new "そんな若い男性が、私みたいな年齢の女性に対してこんなに感じてくれるなんて、本当に嬉しいわ。"

    # say L868 lyd
    old "I- I just want to see it closer..."
    new "私、もっと近くで見たいの…"

    # say L869 lyd
    old "It's been a long time since I've seen one so close."
    new "長い間、こんなに近くで見る機会なかったわ。"

    # say L873 lyd
    old "And, it wasn't that big... Not at all..."
    new "それに、そんなに大きくないの… 全然…"

    # say L874 lyd
    old "Knowing this is caused by me really makes me tingle."
    new "このことが私によって起こっていると思うと、ゾクゾクするの。"

    # say L875 lyd
    old "I'm sorry to ask but, may I see it... I mean, out of your pants?"
    new "申し訳ないんだけど、見せてもらえるかな… つまり、パンツから出してるところをね。"

    # say L876 lyd
    old "To be honest, is the first time I have seen one that big, and really makes me curious..."
    new "正直、こんなに大きいのを見るのは初めてで、本当に興味がわくの..."

    # say L877 pla
    old "... Hmm o- ok."
    new "……うーん、おk。"

    # say L881 lyd
    old "Oh wow! It's even bigger than I thought it was..."
    new "おわ！ 本当にこれ以上ないくらい大きいの..."

    # say L882 lyd
    old "I have never thought you were this... gifted."
    new "こんなに... ギフトが豊富だとは思わなかった。"

    # say L884 lyd
    old "And it's so hard... really seen just this old boob make you so hard?"
    new "それにこんなに硬いの…本当にこのオッパイだけでこんなに興奮するの？"

    # say L885 pla
    old "It was something instinctive, you know a natural reaction..."
    new "本能的な反応だ、自然な反応って感じだね..."

    # say L886 lyd
    old "That is the most honest answer a woman can get from a man..."
    new "それは男から女が受け取れる最も正直な答えね..."

    # say L887 lyd
    old "Thanks [pla], you really made me regain some self-esteem after the bad date I had with the other guy..."
    new "ありがとう、[pla]。あなたのせいで、前の彼とのデートで傷ついた自尊心が少し取り戻せたわ。"

    # say L888 pla
    old "You have to know you are really beautiful and sexy, any man can see that, really."
    new "君は本当にセクシーで美しい、どんな男でもわかるさ。"

    # say L889 lyd
    old "Yeah, now I can see it..."
    new "うん、今ならそれがわかるよ…"

    # say L891 lyd
    old "Uhh... C- can I touch it?"
    new "うーん… ちょっと触ってもいい？"

    # say L893 lyd
    old "I mean, I just want to see how hard you are, if you're really excited or if it's just barely."
    new "つまり、どれだけ硬いのか、本当に興奮してるのか、それともちょっとだけなのか、見てみたいだけってこと？"

    # say L894 pla
    old "And you can't tell just from seeing it?"
    new "見ただけじゃわからないのか？"

    # say L895 lyd
    old "You can't always know that from just looking."
    new "見ただけじゃ、必ずわかるわけじゃないよ。"

    # say L896 lyd
    old "It's always better to check with my own hands."
    new "自分で確かめた方がいいわ。"

    # say L904 lyd
    old "Woah, you're really hard!"
    new "わお、ずいぶん硬くなってるね！"

    # say L905 lyd
    old "And you're so big! This is impressive!"
    new "大きいわ！これほんとすごい！"

    # say L915 lyd
    old "L-listen [pla]. I'm sorry. I didn't mean to do that when you got here."
    new "L-listen [pla]、ごめん。あなたが来た時にそんな風になるつもりじゃなかったの。"

    # say L916 lyd
    old "It's just that you've been so good to me, and I was feeling rather vulnerable."
    new "あなたが私に優しくしてくれて、私はすごく弱っていたの。"

    # say L917 lyd
    old "And seeing how hard you got because of me."
    new "そして、私がいるだけでそんなに興奮してしまったのを見て。"

    # say L918 lyd
    old "But, I swear to God I didn't mean to..."
    new "でも、神様にかけて、故意に这么做することはなかったの..."

    # say L919 pla
    old "Hey, hey, it's ok."
    new "Hey, hey,大丈夫だ。"

    # say L920 pla
    old "No need for you to stress over this."
    new "心配するな、大丈夫だ。"

    # say L921 pla
    old "I'm not angry with you. I understand."
    new "俺は君に怒ってないよ。分かってるから。"

    # say L923 pla
    old "Yeah, I do, it's ok."
    new "うん、分かってるよ。"

    # say L925 lyd
    old "Hmm, but maybe we should clean this up before we keep talking."
    new "うーん、でも話す前に片付けておいた方がいいかもね。"

    # say L931 lyd
    old "Thanks a lot for your help [pla]."
    new "ありがとう、助かったわ [pla]。"

    # say L932 lyd
    old "The truth is that what happened with that guy really affected me. I was feeling really down."
    new "正直、あの男のことがかなり影響しちゃったの。すごく落ち込んでたの。"

    # say L933 lyd
    old "Thanks for helping me feel better."
    new "ありがとう、助けてくれて。気分が良くなったわ。"

    # say L934 pla
    old "No problem, I understand, that kind of thing can make you feel really bad."
    new "大丈夫だよ、分かるよ。ああいうことって、本当に落ち込むもんさ。"

    # say L935 pla
    old "I'm glad you're ok now."
    new "君が元気になったんで良かったな。"

    # say L936 pla
    old "Now that I see you feel better, I think I should go home."
    new "今は君が元気になったみたいだから、俺は帰るよ。"

    # say L937 lyd
    old "Sure, no problem. Bye."
    new "もちろん、問題ないわ。バイバイ。"

    # say L955 pla
    old "Hey Lydia. How are you today?"
    new "Hey Lydia. 今日どう？"

    # say L956 lyd
    old "Hi [pla]! Nice seeing you. You arrive just at the perfect time."
    new "こんにちは [pla]！会えて嬉しいわ。ちょうどいいタイミングで来たね。"

    # say L957 pla
    old "The perfect time? For what?"
    new "完璧なタイミング？何のために？"

    # say L958 lyd
    old "You see, I've been talking to this new guy on Tinder, and the conversations have been going pretty well."
    new "ね、Tinder でこの新しい男の人と話してて、会話が結構うまくいってるの。"

    # say L960 lyd
    old "Yeah, it is."
    new "うん、そうよ。"

    # say L961 lyd
    old "The thing is that he has been asking to see some pictures of me for a while..."
    new "問題は、彼がずいぶん前から私の写真を見せてほしいって言ってきてるの..."

    # say L962 lyd
    old "And he has sent me a lot of pics, and the conversation is going really well, so, I want to send them to him a few ones."
    new "彼はたくさんの写真を送ってくれて、会話もすごくいい感じだから、いくつかの写真を送りたいの。"

    # say L963 lyd
    old "But, to be honest, I don't really know what to send him."
    new "でも、正直に言うと、何を送ったらいいのかわからないの。"

    # say L964 lyd
    old "So, I think you could take some pictures of me so I can send him some good ones."
    new "じゃあ、あなたが私を撮影して、いい写真を送れるようにしてくれる？"

    # say L966 lyd
    old "So, what do you say? Do you think you can do it?"
    new "じゃあ、どうする？ できるかな？"

    # say L967 pla
    old "Hmm, sure, I guess I can."
    new "うん、そうだな、できると思う。"

    # say L975 lyd
    old "Ok, I think something casual, like this, what do you think?"
    new "じゃあ、カジュアルな感じで、こんな感じはどう？"

    # say L976 pla
    old "It looks great!"
    new "いいね！"

    # say L987 lyd
    old "But it's ok, take it, if you like it I think he will too."
    new "でも大丈夫、気に入ったら取って、きっと彼も喜ぶと思う。"

    # say L997 lyd
    old "Is it ok? Do you like it?"
    new "大丈夫？気に入った？"

    # say L998 pla
    old "Yeah, I think it looks very good."
    new "うん、結構いいと思う。"

    # say L999 lyd
    old "Great! So, next one."
    new "グレート！じゃあ、次はちょっと熱いのを試してみよう。"

    # say L1006 lyd
    old "Ok, for this one I want to try something a little hotter."
    new "この次はちょっと熱いものに挑戦したいの。"

    # say L1007 lyd
    old "Does my ass look good enough?"
    new "私の尻、十分にいいかな？"

    # say L1008 pla
    old "Sure, I think it looks great."
    new "もちろん、君の尻は最高だね。"

    # say L1026 lyd
    old "Do I look fat? What do you think? Do you like that one?"
    new "太って見える？どう思う？このスタイル気に入ってる？"

    # say L1027 pla
    old "Don't worry, I think you look just perfect."
    new "心配しなくていい、君は完璧だよ。"

    # say L1028 lyd
    old "Great, I've got an idea for the next one."
    new "じゃあ、次のアイデアが浮かんだわ。"

    # say L1036 lyd
    old "Ha! I knew it, you men and breasts, I don't know why you're so crazy about them."
    new "ははん、やっぱりね。男の人は胸にめっちゃ興奮するんだもん。何がそんなに気に入ってるのか私には全然わからないけどね。"

    # say L1039 lyd
    old "The truth is, he's already sent me a couple of pictures of himself."
    new "実際には、彼はすでに自分の写真をいくつか送ってくれてるの。"

    # say L1040 lyd
    old "And some of those are actually very spicy."
    new "そしてその中には結構エッチな写真もあったのよ。"

    # say L1041 lyd
    old "So, I thought that maybe I could send him some like that too."
    new "じゃあ、私もそんな感じの写真を送ってみようかなって思ってるの。"

    # say L1043 pla
    old "I- I think it's great."
    new "俺もそう思うよ。"

    # say L1044 lyd
    old "Yeah, I can see that. Fufu."
    new "うん、わかるわ。ふふ。"

    # say L1046 lyd
    old "Anyway, take the picture."
    new "じゃあ、写真を撮って。"

    # say L1052 lyd
    old "So how does the picture look?"
    new "写真どう？"

    # say L1053 pla
    old "Very well I think."
    new "まあ、悪くないな。"

    # say L1054 lyd
    old "And my breasts? They don't look soggy or wrinkled?"
    new "そして私の胸は？にじんで啦啦啦わrinkledなってない？"

    # say L1055 pla
    old "No, no, they look great as well."
    new "全然大丈夫、君の胸もめっちゃいいぞ。"

    # say L1056 lyd
    old "That's great, I'm glad that's how it is."
    new "そう言ってもらえると嬉しいわ。"

    # say L1063 lyd
    old "That was very good [pla], thank you."
    new "それはとても良かった[pla]、ありがとう。"

    # say L1064 pla
    old "It's ok, happy to help."
    new "大丈夫だよ、喜んで手伝うよ。"

    # say L1065 lyd
    old "I hope he likes the pictures."
    new "彼が写真気に入ってくれるといいな。"

    # say L1066 pla
    old "I'm sure he will, you look great, don't worry."
    new "大丈夫だよ、君はすごくかわいいから、きっと気に入ってくれるさ。"

    # say L1067 lyd
    old "Well thank you, that's very sweet of you."
    new "ありがとう、そんな優しいこと言ってくれて。"

    # say L1068 lyd
    old "I believe you this time."
    new "今回は信じるわ。"

    # say L1069 lyd
    old "After all, I can see it this time."
    new "今回は見えてきたのよ。"

    # say L1071 pla
    old "Sorry, it's just that you took your shirt off all of a sudden."
    new "ごめん、急にシャツを脱いだからさ。"

    # say L1073 lyd
    old "It's ok, don't worry, I actually like to see that reaction."
    new "大丈夫、気にしないで、その反応見るのが Actually like という部分が自然でないため修正しました。"

    # say L1074 lyd
    old "I think it's very flattering."
    new "そんな反応を見られるのはとても名誉なことだと思うわ。"

    # say L1075 lyd
    old "To see such a young man get so hard because of me, I can never get tired of it."
    new "そんな若い男の人が私のためにこんなに固くなるのを見ると、飽きることはないわ。"

    # say L1076 lyd
    old "In fact, how about I help you with that? I know it can take a while for your dick to calm down."
    new "実際、手伝ってあげる？ あなたのチンポが落ち着くまでには時間がかかるからね。"

    # say L1077 pla
    old "You don't really have to do it."
    new "君がしなくてもいいんだよ。"

    # say L1078 lyd
    old "Well, you helped me with the pictures, it's fine if I help you back. Don't you think?"
    new "あなたが写真の手伝いをしてくれたんだから、私がお返しをするのは当然じゃない？"

    # say L1079 lyd
    old "And to be honest, doing these photos made me a bit horny..."
    new "正直、これらの写真を撮っているうちにちょっと興奮しちゃったの..."

    # say L1081 lyd
    old "Now come, let me help you."
    new "今度は私に手伝ってあげていいよ、来なさい。"

    # say L1088 lyd
    old "I didn't notice last time, but your dick has a great smell."
    new "前回は気づかなかったけど、あなたのチ○ポの匂いがいいの。"

    # say L1089 lyd
    old "And I can't believe how hard you get."
    new "信じられないくらい硬くなってるね。"

    # say L1090 lyd
    old "Young men are amazing."
    new "若い男の人は本当にすごいね。"

    # say L1091 lyd
    old "It's sooo big too."
    new "全然でかすぎるし。"

    # say L1092 lyd
    old "Honestly I'm not sure it will fill all in my mouth."
    new "正直、全部を私の口に入れる自信ないな。"

    # say L1093 lyd
    old "But don't worry, I'll make sure you finish in a moment."
    new "でも安心して、すぐ終わらせてあげるから。"

    # say L1104 pla
    old "Well, I think I should go home."
    new "まあ、帰るか。"

    # say L1105 lyd
    old "Sure thing, thanks again for the pictures. I'll let you know if he likes them."
    new "もちろん、写真ありがとう。彼が気に入ったかどうか報告するね。"

    # say L1126 ann
    old "I mean, what the fuck mom?! What the actual fuck?!"
    new "何てことなの、ママ？！ 何てことなの？！"

    # say L1127 ann
    old "Now you're coming home late? JESUS!"
    new "今更遅くに帰ってくるの？イエスッ！"

    # say L1128 ann
    old "After all those times you scolded me for doing it when I was a teenager. And not only that, but I'm sure you were on a date with someone."
    new "若いうちに私がやってたことを、今更文句言うの？それに、きっとデートしてきたんでしょ。"

    # say L1129 ann
    old "I imagine it was some guy you must've met there. What's wrong with you?"
    new "そこで誰かと会った男の人なんじゃないの？一体何考えてるの？"

    # say L1130 ann
    old "Don't you realize you're too old to be going out with guys like those?"
    new "君がそんな男の子と遊んでいるのは、もう年齢的に無理だって気づいてないの？"

    # say L1131 ann
    old "Honestly..."
    new "正直に说くと..."

    # say L1132 lyd
    old "Why are you so angry?"
    new "なんでそんなに怒ってるの？"

    # say L1133 lyd
    old "I get that I forgot to tell you I was going out last night, but that's no reason to be acting like this."
    new "昨夜の外出のこと、君に伝えるのを忘れちゃったのは認めるけど、だからってこんな態度取る必要ないでしょ。"

    # say L1134 lyd
    old "Listen, your mother is a mature woman, and I have every right to go out and date anyone I want to."
    new "君の母親は大人の女性だし、私が誰と出かけるにせよデートにせよ自由だよ。"

    # say L1136 ann
    old "I DON'T GIVE A FUCK!"
    new "私は関係ないわ！"

    # say L1137 ann
    old "I just don't want to go around picking up random dudes that you find on the street!"
    new "ただ、路上で見つけたような男の人と気軽に付き合うのは嫌だよ！"

    # say L1138 ann
    old "I mean, what's everyone going to think? That you're just some whore looking for dick!"
    new "みんなはどう思うか考えたことある？ ただのスケベ女だって思われるわよ！"

    # say L1139 ann
    old "They would be right by the way! Because that's what you're acting like!!!"
    new "そうよ！みんなそう思って当然だよ！だってあなた、そんなふうに振舞ってるんだから！"

    # say L1142 ann
    old "Ugh! I'm so mad mom! I swear to god!"
    new "うっ！母さん、本当に腹立つ！神にかけても！"

    # say L1143 ann
    old "You know what? I won't keep talking about this!"
    new "知ってる？これ以上話さないよ！"

    # say L1144 ann
    old "I'm out of here!"
    new "もう行っちゃう！"

    # say L1158 lyd
    old "Oh [pla], hi. How are you?"
    new "あ、[pla]、こんにちは。どう？"

    # say L1159 pla
    old "Never mind me, how about you? What was Anna mad about this time?"
    new "俺のことなんて気にしないで、君はどう？今度はアンナが何に怒ってたの？"

    # say L1160 lyd
    old "Well, remember the guy that we took the pictures for?"
    new "あの人のこと覚えてる？"

    # say L1163 lyd
    old "Well, we went out on a date, and we ended up staying out until very late, and Anna noticed it."
    new "あの人のこと覚えてるでしょ？デートに行って、夜遅くまで帰ってこなかったの。アンナが気づいたのよ。"

    # say L1164 lyd
    old "As you can see, she's not too thrilled about it."
    new "見ての通り、彼女はそれほど喜んでないみたい。"

    # say L1165 pla
    old "Yeah, I caught that she's not too happy about the situation."
    new "そうだな、彼女が状況に満足してないのはわかったよ。"

    # say L1166 pla
    old "But so what? You're a grown woman, and she can't be telling you what to do or not."
    new "でもさ、君は大人だろ。彼女が君に何をすべきじゃなく、何をすべきじゃないって命令する権利はないだろ。"

    # say L1167 lyd
    old "I don't know, lately I've been thinking that she may be right and that I'm actually acting like a whore."
    new "最近、彼女が言ってる通りで、自分がホステスのように振舞ってるんじゃないかって思っちゃうの。"

    # say L1168 pla
    old "Whoah, whoah, whoah."
    new "誰あ、誰あ、誰あ。はい、待て、待て。"

    # say L1169 pla
    old "No, no, let's not go there."
    new "いや、そこまで行かないで。"

    # say L1170 pla
    old "Listen, Anna's just angry, and since she's such a hothead she doesn't know how to deal with it."
    new "待て、待て、待て。 アンナはただ怒ってるだけだ、彼女は短気だから上手く対処できないんだ。"

    # say L1171 pla
    old "All she knows is how to get angry, scream and be cruel. Don't pay any attention to what she says, ok?"
    new "彼女はただ怒って、叫んで、残酷なことしか知らない。彼女の言うことは無視していいぞ。"

    # say L1173 lyd
    old "Ok, I guess you have a point."
    new "うん、確かにそうね。"

    # say L1175 pla
    old "Now, tell me how your night went."
    new "じゃあ、君の夜の出来事を聞かせてよ。"

    # say L1176 pla
    old "It sounds like it was a very good time."
    new "そうか、結構いい夜だったみたいだね。"

    # say L1177 lyd
    old "Hmm, yeah, I guess so..."
    new "うーん、そうかな、多分そうね…"

    # say L1178 pla
    old "Yeah? Because you don't look very excited about it."
    new "そうか？でも君はそんなに興奮してないみたいだけど。"

    # say L1179 lyd
    old "Well... you see."
    new "まあね、そのことについてだけど。"

    # say L1180 lyd
    old "The date went well, he was a perfect gentleman, and I think we had a lot of chemistry. He actually said he wanted to see me again soon."
    new "デートはうまくいって、彼は紳士的で、私たちには化学反応があったと思うの。実際、また近いうちに会いたいって言ったの。"

    # say L1181 lyd
    old "But that got me thinking, with the way things are going, that we could end up having sex next time."
    new "でも考えてみると、今のままなら次はセックスしちゃうかもしれないなと思ったの。"

    # say L1182 pla
    old "Well, yeah, that's usually how those things go."
    new "まあ、そうなるよね。"

    # say L1183 pla
    old "You don't want to?"
    new "君が欲しくない？"

    # say L1184 lyd
    old "It's not that, I obviously want to."
    new "そうじゃないの、もちろんしたいと思っているの。"

    # say L1185 lyd
    old "The problem is that it's been a while since I had sex for the last time."
    new "問題は、最後にセックスをしたのがずいぶん前だからよ。"

    # say L1186 lyd
    old "Even with my deceased husband, the last few years of our relationship we barely had any contact."
    new "亡くなった夫との最後の数年もほとんど連絡がなかったの。"

    # say L1187 lyd
    old "I'm afraid that I'm not gonna be good enough or that I'll end up disappointing him."
    new "心配で仕方ないの。上手くいかなそうだし、がっかりさせちゃうかもしれない。"

    # say L1188 lyd
    old "After all this time it's a lot of pressure you know?"
    new "長い間会っていなかったから、プレッシャーがすごいよね。"

    # say L1189 lyd
    old "Especially since I'm not sure he'll like my body."
    new "特に、彼が私の体を気に入るかどうか自信がないから。"

    # say L1190 lyd
    old "What if he thinks that I'm too old? or that I'm not hot enough?"
    new "もし彼が私を年取りすぎだって思ったらどうしよう？ あるいは、魅力的じゃないって思ったら？"

    # say L1191 pla
    old "What? Not at all!"
    new "何言ってんだよ、全然そんなことないだろ。"

    # say L1192 pla
    old "Don't even think about it. That guy has already seen pictures of you, and if he says that you're hot, you should believe him."
    new "そんなこと考えないで。あの男は君の写真見てるし、君が可愛いって言ってるんだから、信じていいだろ。"

    # say L1193 pla
    old "Everything is gonna be fine, believe me."
    new "大丈夫、信じててくれ。"

    # say L1194 lyd
    old "Ok, I'll stop worrying about it. Thanks again [pla], I don't know what I would do without all your help."
    new "大丈夫、心配しなくていいよ。またありがとう、[pla]。あなたの助けがなかったら、どうなっていたかわからないよ。"

    # say L1196 pla
    old "Don't even mention it."
    new "全然、そんなの。"

    # say L1197 pla
    old "Hmmm."
    new "うーん。"

    # say L1198 pla
    old "So, since I'm already here, do you want us to browse through some tinder profiles?"
    new "じゃあ、ここにいる間にティンダーのプロフィール見ようか？"

    # say L1200 lyd
    old "I don't really feel like doing that right now, besides, since Anna is in her room she could come down any second."
    new "今すぐそんな気分じゃないし、アンナが部屋にいるからいつ下りてきてもおかしくないよ。"

    # say L1201 lyd
    old "I don't want to have to deal with her temper again today."
    new "今日また彼女の機嫌を損ねたくないの。"

    # say L1202 pla
    old "I understand, then I guess it's better if I leave."
    new "分かった、じゃあ俺が帰った方がいいな。"

    # say L1203 pla
    old "But before I go, remember what I told you."
    new "でも行く前に、俺が言ったことを覚えておいてくれ。"

    # say L1204 pla
    old "You're a beautiful woman, and you're in your right to be or date anyone."
    new "君は美しい女性だよ、そして誰と付き合うか選ぶ権利があるんだ。"

    # say L1205 pla
    old "No matter what Anna thinks about that. She can keep her opinions to herself."
    new "アンナの意見なんて気にしないで。彼女は自分の意見を胸にしまっておけばいい。"

    # say L1206 lyd
    old "Thank you [pla] I'll be sure to remember that."
    new "ありがとう、[pla]。覚えておきます。"

    # say L1207 pla
    old "That's cool, goodbye then."
    new "じゃあ、さよなら。"

    # say L1226 lyd
    old "Hi [pla], I guess I'm fine, thank you."
    new "こんにちは [pla]、多分大丈夫だね、ありがとう。"

    # say L1227 pla
    old "You guess? What happened?"
    new "君がそう思う？何が起きた？"

    # say L1228 lyd
    old "Oh [pla], it's just so bad..."
    new "ああ [pla]、ほんとにつらいの…"

    # say L1229 pla
    old "What's bad? You're worrying me now, tell me."
    new "何が悪いんだ？心配になってきたよ、教えて。"

    # say L1231 lyd
    old "Well, the thing is that I did go on that date with the guy I told you about."
    new "まあ、その男の人のことね。デートにいったのよ。"

    # say L1232 lyd
    old "I suppose it went well, just like last time he was a gentleman, the conversation was good and we had a good time."
    new "まあ、うまくいったわ、前回と同じように彼は紳士的で、会話も楽しくて、良い時間を過ごせたの。"

    # say L1233 lyd
    old "The problem came later... when we were about to have sex."
    new "問題はその後に起きたの... 性行為をする直前だったの。"

    # say L1234 pla
    old "Ohh... Why?"
    new "オッ… なぜ？"

    # say L1235 lyd
    old "Well, after dinner he asked me if I wanted to continue the evening at his house, I said yes and we went there."
    new "まあ、夕食後、彼は私に家で夜を続けるかどうか聞いてきたの。私は「はい」と答えて、その家に行ったわ。"

    # say L1236 lyd
    old "I really wanted to do it, and things were going so well..."
    new "本当にやりたかったし、雰囲気も良かったんだけど…"

    # say L1237 lyd
    old "But, I just couldn't do it... I got nervous and uncomfortable."
    new "でも、どうしてもできなかったの... 緊張してしまって、落ち着かなかったから。"

    # say L1239 pla
    old "Was it something he did?"
    new "彼が何かした？"

    # say L1241 lyd
    old "Oh no, nothing like that, he was actually very nice, as I said, a perfect gentleman."
    new "あら、そんなことじゃないの、彼は本当に優しくて、紳士的だったわ。"

    # say L1242 lyd
    old "I was the one with the problem, no matter what we tried all I could think was about my husband, and Anna's words."
    new "問題は私の方だったの。どんなことをしても、頭の中は夫のことと、アンナの言葉でいっぱいだったの。"

    # say L1243 lyd
    old "Telling me that I was ugly and undesirable, that what I was doing was wrong."
    new "私が醜くて望まれない人間だとか、私がしていることが間違っているって、Annaが言ってたことばかり考えちゃって。"

    # say L1244 lyd
    old "After a while, I just backed out and asked him to drive me home."
    new "しばらくして、私は諦めて彼に家まで送ってもらうように頼んだ。"

    # say L1245 lyd
    old "After all I think Mrs. Jones was right, at my age it's just impossible for me to form a connection with another person."
    new "結局、ジョーンズ夫人が正しいと思うの。私の年齢じゃ、もう他の人とつながることは無理だと思うの。"

    # say L1246 lyd
    old "I think I should just give up and become a church lady like her."
    new "私はもう諦めて、彼女みたいに教会の ladies になるべきだな。"

    # say L1247 pla
    old "Wait, wait, don't say that."
    new "待って待って、そんなこと言わないで。"

    # say L1248 pla
    old "Listen, what you went through is perfectly normal, you don't need to beat yourself over it."
    new "聞いて、君が経験したことは普通だ、自分を責める必要はない。"

    # say L1249 pla
    old "Sure it would be good if you could have sex with the guy."
    new "もちろん、君がその男とセックスできればいいけど。"

    # say L1250 pla
    old "But think about it, you were out of the dating game for a long time, it's ok to feel insecure."
    new "でも考えてみろ、君は長い間恋愛から遠ざかってたんだ、不安を感じるのは当然だよ。"

    # say L1251 pla
    old "There's no need for you to feel that you're going to become someone like Mrs. Jones."
    new "君がジョーンズ夫人みたいになる必要はないよ。"

    # say L1252 lyd
    old "That's very cute of you, but [pla] I don't know, it's just too difficult."
    new "それはとてもかわいいけど、[pla] でもやっぱり難しいな。"

    # say L1254 pla
    old "It is, but that doesn't mean you should give up, or pay any attention to what Anna says."
    new "それはそうかもしれないけど、だからといって諦める必要はないし、Annaの言うことに耳を貸す必要もないよ。"

    # say L1255 pla
    old "Listen, you're doing this for yourself, not for Anna, or your husband or anyone else, just for you."
    new "君がやってることは自分自身のために、Annaのためでも夫のためでも誰か他の人のためでもなく、ただ君自身のためにだ。"

    # say L1256 pla
    old "You have every right to be happy and to search for that happiness."
    new "君は幸せになる権利があるんだ、そしてその幸せを探すことだって全然OKだよ。"

    # say L1257 pla
    old "So, there's no need for you to feel guilty about living your life."
    new "だから、自分の人生を生きることで罪悪感を感じる必要はないんだよ。"

    # say L1258 lyd
    old "I understand what you're saying, but I don't know how to do it."
    new "あなたの言うことは理解してるけど、どうやってそれを実践すればいいのかわからないの。"

    # say L1259 lyd
    old "How do I manage to do it when I feel so uncomfortable?"
    new "どうやってこんなに居心地が悪いのにやっていけるの？"

    # say L1260 lyd
    old "I wasn't able to even get naked!"
    new "全裸になることさえできなかったの。"

    # say L1261 lyd
    old "I can't imagine even trying to be even more intimate in a physical way."
    new "物理的にもっと密着するなんて、想像もできないわ。"

    # say L1263 pla
    old "Hmm... It's just you haven't done it in a long time, you're a bit... Rusty..."
    new "Hmm... ただ君が長い間やってなかったから、ちょっと... 锈びちゃってるだけだよ..."

    # say L1264 lyd
    old "But how do I fix it? How can I ever be able to have some sexual contact again?"
    new "でもどうやって直せばいいの？また性的な接触ができるようになるの？"

    # say L1266 pla
    old "Wait... What about me?"
    new "待て……俺のことはどうするんだ？"

    # say L1269 pla
    old "Well, you say that, but you've been able to do a few sexual things with... me."
    new "まあ、君がそう言うけど、俺と……一緒にしたときには、性行為できたんじゃないか。"

    # say L1270 lyd
    old "Oh... Yeah well, that's different."
    new "ああ… でも、それはちょっと違うわ。"

    # say L1273 lyd
    old "I don't know... with you it doesn't feel like I'm doing some weird thing with a stranger, you just feel... safer."
    new "あたしもよくわからないけど… あなたといると、 stranger みたいな変な気分にならないの。ただ、もっと安心できる感じがするの。"

    # say L1274 lyd
    old "With this other guy I felt very awkward like we didn't have a bond, or anything connecting us."
    new "あの他の男の人は、なんだかぎこちなくて、私たちには絆も何もないように感じた。"

    # say L1275 pla
    old "Hmph, I think I get what you're saying."
    new "ふん、君の言いたいことがわかったような気がする。"

    # say L1277 lyd
    old "Oh, I have an idea."
    new "あ、いいアイデアが出た。"

    # say L1280 lyd
    old "I think that my problem might be taking that first step to physical intimacy. That's what's holding me back."
    new "私が進むべき一歩が、身体的な親密さの第一歩かもしれないと感じる。それが私を躊躇らせているんだ。"

    # say L1281 lyd
    old "It's just as you said, I'm rusty, so, maybe I just need a bit of practice?"
    new "そうね、あなたが言った通り、私は生疏だから、ちょっと練習が必要かもしれないわ。"

    # say L1282 pla
    old "Practice?"
    new "練習？"

    # say L1283 lyd
    old "I think that if I do it with someone at least once, from there on it should be a lot easier with other guys."
    new "一度誰かとやってみれば、その後他の男の人たちとはずっと楽になると思うの。"

    # say L1285 pla
    old "Ohh, I get it... Well, that makes a lot of sense. I think you're right."
    new "オッ、分かった… まあ、それも納得だな。君の言う通りだと思う。"

    # say L1286 pla
    old "But who are you gonna do it with first?"
    new "でも、最初に誰とやるつもりなんだ？"

    # say L1287 lyd
    old "Well... so far there's only one man I think I feel comfortable enough to do it with."
    new "まあ……今のところ、心地よく感じられるのはただ一人の男の人のことだけよ。"

    # say L1288 pla
    old "And who is it?"
    new "誰だよ？"

    # say L1289 pla
    old "Oh wait, you don't mean... me?!"
    new "おい、まさか…俺のこと？！"

    # say L1290 lyd
    old "What can I tell you? As you've seen you're the only one with which I've been able to do anything without feeling weird."
    new "何を言えばいいの？ あなたが見ている通り、変な気分にならずに何かできるのはあなただけなんだよ。"

    # say L1291 pla
    old "B- but you know."
    new "でも、君は知ってるだろ。"

    # say L1293 lyd
    old "I know, it sounds crazy, and maybe I'm just saying this impulsively, but this wouldn't be the first time we do something of the sort."
    new "知ってる、変なこと言ってるって分かってる。でも、これも初めてじゃないかもしれないし。"

    # say L1294 lyd
    old "And I think that I wouldn't have any problem if it were you, I'm clearly comfortable with you...."
    new "でも、あなたなら問題ないと思うの、私、あなたとなら明らかにリラックスできるから..."

    # say L1295 pla
    old "B- but, that would be way too far over the line!"
    new "でも、それってちょっと線越えすぎな気がするけど！"

    # say L1296 lyd
    old "You are right... I better stop this and settle down."
    new "あなたが正しい……これ以上はやめて、落ち着くべきね。"

    # say L1297 pla
    old "No, no, it's not about that."
    new "いや、それとは違うんだ。"

    # say L1298 pla
    old "It's just that the solution sounds way too drastic."
    new "ただ、その解決策はちょっと極端すぎるだろ。"

    # say L1299 pla
    old "Why don't you try other solutions first? Going to therapy, or maybe trying with some other dude..."
    new "他の方法を試してみないか？カウンセリングに行ってみたり、他の男とやってみるのもいいかもしれないけど…"

    # say L1300 lyd
    old "Oh please, you know that's not going to help me!"
    new "お願い、そんなの全然役に立たないって分かってるでしょ！"

    # say L1301 lyd
    old "Besides, this isn't easy for me either."
    new "それに、これだって私にとって簡単なことじゃないの。"

    # say L1302 lyd
    old "Just imagine how embarrassing it would be to keep trying with one and another person without managing to do anything."
    new "一人ひとりと試してみるけど、何もできずに恥ずかしい思いをするって想像してみてよ。"

    # say L1304 lyd
    old "It's not like I want my life to be in shambles like this, you know [pla]?"
    new "こんな状況になるのは私にとっても簡単じゃないの、知ってるでしょ [pla]？"

    # say L1305 lyd
    old "All I'm telling you is that I'm trying to put my life back together so that I don't end up like Mrs. Jones."
    new "私が言いたいのは、自分の人生を立て直して、ジョーンズ夫人みたいにならないようにするのよ。"

    # say L1306 lyd
    old "Won't you help me with that?"
    new "手伝ってくれない？"

    # say L1307 lyd
    old "After all, it would just be this one time, just so that I get used to it again."
    new "でも、これだけ一度やって、また慣れるためよ。"

    # say L1308 pla
    old "Hmm, I suppose what you're saying makes sense."
    new "うーん、君の言うことも一理あるな。"

    # say L1309 pla
    old "I'm not sure I like this, but ok, I suppose we can do it."
    new "俺はあまり気に入らないけど、まあいいか、やってみるよ。"

    # say L1310 lyd
    old "Really? Thank you so much [pla]!"
    new "本当に？ありがとう [pla]！"

    # say L1312 lyd
    old "Don't worry just lie on the couch and leave everything to me!"
    new "心配しないで、ソファーに横になっていてくれればいいから！"

    # say L1327 pla
    old "I think the best thing is that I go for today."
    new "今日は俺が帰った方がいいな。"

    # say L1328 pla
    old "Are you going to keep talking with the guy?"
    new "君はこれからもその男のと話すつもりなのか？"

    # say L1329 lyd
    old "I will, I really like him, so, I hope we can have another date."
    new "私はそうするわ、彼のこと本当に好きだから、また会えることを願ってるの。"

    # say L1330 lyd
    old "And this time I'm sure everything will go well."
    new "今回はきっとうまくいくわ。"

    # say L1331 pla
    old "I'm sure it will, good luck."
    new "大丈夫だよ、頑張ってね。"

    # say L1350 lyd
    old "Oh hi [pla]! It's good seeing you."
    new "あ、こんにちは [pla]！会えて嬉しいわ。"

    # say L1352 lyd
    old "I'm fine thanks for asking!"
    new "大丈夫よ、ありがとう！"

    # say L1353 pla
    old "Great, so tell me, everything went well on your date, right?"
    new "そうだな、じゃあ教えてくれ、デートは上手くいったんだよな？"

    # say L1354 lyd
    old "Oh, that? Not at all!"
    new "ああ、それ？全然そうじゃないよ。"

    # say L1355 pla
    old "What's with that face?"
    new "その顔は何だ？"

    # say L1356 pla
    old "Don't tell me things went wrong again on your date."
    new "またデートが上手く行かなかったのか"

    # say L1357 lyd
    old "Ugh. Then I don't know what else to tell you."
    new "うーん、じゃあ何を言えばいいのかわからない。"

    # say L1360 lyd
    old "Nothing happened, that's the problem."
    new "何も起こらなかったのが問題なの。"

    # say L1361 pla
    old "Nothing? Nothing at all?"
    new "何も？全然何も起こらなかったってことか？"

    # say L1362 lyd
    old "Well, yes..."
    new "うーん、そうね…"

    # say L1363 lyd
    old "Oh [pla], that was so frustrating"
    new "ああ [pla]、それがものすごくイライラしたわ"

    # say L1364 pla
    old "But why?"
    new "でも、なぜ？"

    # say L1366 lyd
    old "I don't know, the date went well, he was as well behaved as always, but when the moment came I just felt that I couldn't do it."
    new "わからないの、デートはうまくいったし、彼はいつも通り紳士的だったのに、その瞬間になって突然できなくなっちゃったの。"

    # say L1368 pla
    old "But, I thought you had gotten over your intimacy problem, that's why we did what we did, right?"
    new "でも、君の距離感の問題は克服したと思ってたんだよ。だからこそ、あの時あんなことしたんだろ？"

    # say L1369 lyd
    old "Yeah, yeah, and I think it did help. After all, this time I wasn't scared or feeling bad or anything."
    new "うん、うん、確かに役立ったと思う。今回は怖くなかったし、気分が悪くなることもなかったし。"

    # say L1370 lyd
    old "I just didn't want him to put his hands on me, I don't know, I guess we just didn't have any sexual attraction."
    new "ただ、彼に手を触れられたくなかったんだよね、性吸引力も感じなかったみたいだね。"

    # say L1371 lyd
    old "You have no idea how annoyed I am because of that."
    new "あなたがどれだけイライラしてるか、全然想像できないわ。"

    # say L1372 pla
    old "Hmm, well, if you say that you didn't feel bad or scared, I guess that's a good thing."
    new "うーん、君が嫌な気分や怖さを感じなかったって言うなら、それは良いことだね。"

    # say L1373 pla
    old "Those things happen."
    new "そんなこともあるさ。"

    # say L1374 lyd
    old "I'm still very frustrated though."
    new "まだかなりイライラしてるけど。"

    # say L1375 lyd
    old "But I understand that the problem wasn't me, I think the problem was that I didn't like him enough."
    new "でも、問題は私じゃなくて、彼のことが十分に好きじゃなかったんだと思う。"

    # say L1377 pla
    old "Hmph, if you say so."
    new "ふん、君がそう言うならね。"

    # say L1378 lyd
    old "Oh, don't be mad, at least I'm not feeling bad about it."
    new "怒らないで、少なくとも私は気にしてないから。"

    # say L1379 lyd
    old "Just a little bit annoyed."
    new "ちょっとイライラしてるだけよ。"

    # say L1380 pla
    old "I guess we can call that a silver lining..."
    new "まあ、それなら救いっていうか。"

    # say L1381 pla
    old "But if that's not the thing that has you in a good mood, what is it?"
    new "でもそれが気分を良くしてる理由じゃないなら、何が気分を良くしてるんだ？"

    # say L1382 lyd
    old "Right, that!"
    new "そうだよ、それ！"

    # say L1383 lyd
    old "I've been talking to another guy, and actually, things seem to be going well."
    new "他の男の子と話してて、実は上手くいってそう。"

    # say L1384 lyd
    old "We haven't met, but I really like his personality."
    new "まだ会ってないけど、彼の性格が本当に好き。"

    # say L1385 pla
    old "That's cool."
    new "それはいいね。"

    # say L1387 lyd
    old "Hmm, in fact, I think you could help me out with that."
    new "実はね、あなたが手伝ってくれたらいいなって思ってるの。"

    # say L1388 pla
    old "Help you?"
    new "手伝う？"

    # say L1389 lyd
    old "Yeah, to talk to him, just before you arrived we were in the middle of a conversation."
    new "うん、彼と話すの、あなたが来た直前まで私たちが会話の真っ最中だったんだ。"

    # say L1390 lyd
    old "I think you could help me chat with him."
    new "あなたが手伝ってくれたら、彼との会話がもっと楽しくなると思うの。"

    # say L1391 pla
    old "Hmm, I don't know... I mean, if you've been talking with these guys I think you can keep up the conversation without my help."
    new "Hmm、そうか……でも君が話してたんだろ？多分一人で頑張れるんじゃないかな。"

    # say L1392 lyd
    old "Oh, don't say that, you are really a great help to me."
    new "あ、そんなことは言わないで、私にとっては本当に大きな助けなの。"

    # say L1393 lyd
    old "But you know I have some problems with the keyboard and his expressions."
    new "でもね、キーボードの操作や表情の表現でちょっと苦手なところがあるの。"

    # say L1394 pla
    old "I guess you're right. I suppose it would do no harm to give you a hand."
    new "そうだな、手伝うのも悪くないだろう。"

    # say L1396 lyd
    old "Great, then, let's go to the sofa to chat more comfortably."
    new "じゃあ、ソファで楽しく話しましょう。"

    # say L1411 lyd
    old "This is where we were in the conversation a little before you arrived."
    new "これが私たちが話していたところよ、あなたが来る少し前までね。"

    # say L1412 pla
    old "I see, things seem to be going well."
    new "なるほど、話は上手くいってそうだな。"

    # say L1413 lyd
    old "I guess they are... so what do I tell him now?"
    new "そうね…じゃあ、今は何を言えばいいのかな？"

    # say L1414 pla
    old "Well, as I told you last time, you have to be playful, but a little suggestive."
    new "前回言った通り、君は軽く冗談を交えて、でも少し誘惑的な感じで接すればいいんだよ。"

    # say L1415 lyd
    old "I was​​ thinking of telling him something about my clothes, about how sexy they would be."
    new "服についてsexyなことを言うつもりだったの。例えば、「最初はトレンチコートを着て行くわ」って。"

    # say L1416 pla
    old "That sounds good, how do you want me to say it?"
    new "それいいね、どうやって言うのがいいかな？"

    # say L1417 lyd
    old "Like this 'To start, I would get there wearing a trench coat'."
    new "まずはトレンチコートを着て行くわ"

    # say L1419 pla
    old "What? That's not sexy at all!"
    new "何？全然セクシーじゃないじゃん！"

    # say L1420 lyd
    old "Of course it isn't, it's something I read in a magazine a long time ago, just write it."
    new "もちろんセクシーじゃないわ、これは昔雑誌で読んだことだから、書いてよ。"

    # say L1424 pla
    old "He answered 'a trench coat?' See? That's not sexy."
    new "「トレンチコート？」って答えたんだよ。見ろ？全然セクシーじゃないだろ。"

    # say L1426 lyd
    old "Fufu, what's sexy is what I would bring underneath."
    new "フフ、セクシーなのは私が下に着てるものよ。"

    # say L1427 lyd
    old "Write 'Then I would take it off, to let you see the black lingerie that I'm wearing underneath.'"
    new "じゃあ、それを脱いで、下に着ている黒いランジェリーを見せてあげる。"

    # say L1429 pla
    old "Oh! I see what you mean."
    new "オォ！なるほどか。"

    # say L1432 pla
    old "He really seemed to like that, now he's asking 'Then what else?'"
    new "彼はそれが気に入ったみたいで、「それ以外には？」って聞いてる。"

    # say L1434 lyd
    old "I would take you by the hand and bring you to the couch, where I would want you to lay down."
    new "手を取ってソファまで連れて行き、そこで横になって欲しがるわ。"

    # say L1438 pla
    old "He says 'Oh yeah? And what would you do once I'm laying down on the couch baby?'"
    new "オーケー？　じゃあ、ソファに寝かせたら、次は何するつもりだよ、ベイビー？"

    # say L1439 lyd
    old "I would lay down on top of you, and I would take those lips of yours on a hot, rough kiss."
    new "上に乗ってあなたの唇を熱く荒々しくキスをするわ。"

    # say L1442 pla
    old "He wrote 'I like that! But that's all you'd want?'"
    new "俺はそれが好きだ！でもそれだけが欲しければいいけど？"

    # say L1444 lyd
    old "Haha, so cute, tell him 'Well, aren't we a little impatient tonight?'"
    new "へへ、かわいいね、彼に「今夜はちょっと急いでるみたいじゃない？」と伝えてあげな。"

    # say L1447 pla
    old "Hmm, he says 'I'm sorry baby, it's just that I can't resist you.'"
    new "すみません、ベイビー、ただ君に我慢できないだけなんだよ。"

    # say L1448 lyd
    old "That's very cute of him."
    new "彼は本当にかわいいね。"

    # say L1449 lyd
    old "Write 'It's ok, I can't resist you either.'"
    new "大丈夫、私もあなたに我慢できないわ。"

    # say L1451 lyd
    old "So while we're kissing, I slowly bring my hand down your chest, pass your abs... and over that big bulging dick under your pants."
    new "キスしながら、ゆっくりと私の手があなたの胸から腹を通り越して、パンツの下にある大きな膨らみへと滑っていくの。"

    # say L1462 pla
    old "That's it baby! Yeah, you know just what I want."
    new "そうだよベイビー！ああ、君はちゃんとわかってんだな。"

    # say L1463 lyd
    old "Fufu, and you haven't seen anything yet..."
    new "ふふ、まだ見ぬものがあるわ…"

    # say L1466 pla
    old "Tell me more!"
    new "もっと言って！"

    # say L1467 lyd
    old "I'll feel your big hard cock with my hand, and that is gonna make me horny..."
    new "手であなたの大きな硬いチンポを感じて、それが私を horny にするわ... -> 手であなたの大きな硬いチンポを感じて、それが私を興奮させるわ..."

    # say L1478 lyd
    old "And I'm going to rub it over your pants, feeling how big it is..."
    new "そしてあなたのジーンズの上からこすりつけて、どれだけ大きいのか感じさせてあげる..."

    # say L1481 pla
    old "Ohh, you'll love to feel every inch of me..."
    new "オッ、君は俺の全部を感じて好きになるよ…"

    # say L1482 lyd
    old "I already love it... But you'll love what I'm going to do next..."
    new "もう大好きだよ… でも次にすること、もっと気に入ってくれると思う…"

    # say L1485 pla
    old "Ohh yes babe, what are you gonna do next?"
    new "オッ、そうかベイビー、次に何するんだ？"

    # say L1486 lyd
    old "Well, I'm going to kneel in front of you and I'm going to take out that huge cock."
    new "じゃあ、私が前に跪いて、その大きなちんこを取り出すわ。"

    # say L1495 lyd
    old "Then, I'll bring my head down and kiss and lick the tip of your cock."
    new "それから、私の頭を下げるわ。そしてあなたのチンコの先端をキスして舐めるわ。"

    # say L1504 pla
    old "Mmm, I love that, I love how you kiss it."
    new "うん、それが好きだ、君がキスするのが大好きだ。"

    # say L1514 lyd
    old "That was a great conversation! Wasn't it?"
    new "それは素敵な会話だったわね！ そうよね？"

    # say L1516 pla
    old "Uhm, sure... I was very good."
    new "うん、そうだね… 僕は本当に上手かったよ。"

    # say L1517 lyd
    old "I think this might be the right guy for me, he's hot, he's into me. He's just great, right?"
    new "この人が私にとってピッタリかもしれないわ、カッコよくて、私のこと好きそうだし。最高よね、そうでしょう？"

    # say L1518 pla
    old "Yeah, yeah... He sounds like a great guy."
    new "うん、うん… 彼は最高の男の子のようだな。"

    # say L1519 pla
    old "Anyway, I think I should probably go now."
    new "まあ、俺はそろそろ行こうかな。"

    # say L1520 pla
    old "You know, before Anna arrives and stuff."
    new "ねぇ、アンナが来る前にさ。"

    # say L1522 lyd
    old "Yeah, that's probably better. Thank you so much."
    new "うん、そうした方がいいね。本当にありがとう。"

    # say L1538 pla
    old "Whoaa?! What are you doing here?!"
    new "誰あ、ここにいるんだ？！"

    # say L1539 lyd
    old "H- Heelloo [pla]!"
    new "H- おっ hey [pla]！"

    # say L1540 lyd
    old "Did I zurprish you?"
    new "びっくりさせちゃった？"

    # say L1542 lyd
    old "Did I s- surprize you?!"
    new "びっくりさせちゃった？！"

    # say L1543 pla
    old "Oh! Yes, you did! Why are you in my room?"
    new "オッ！そうか、びっくりさせたな！どうして君の部屋にいるんだ？"

    # say L1544 pla
    old "How did you get in?"
    new "どうやって入ったの？"

    # say L1545 lyd
    old "Sue gave 'e a key."
    new "スーが鍵をくれたの。"

    # say L1547 pla
    old "I see, well, that makes sense."
    new "なるほど、それは道理だ。"

    # say L1548 pla
    old "But you still haven't answered, what are you doing in my room? And this smell... It's alcohol."
    new "でもまだ答えてないよ、君は俺の部屋で何してるんだ？それにこの臭い… 酒の匂いだな。"

    # say L1549 pla
    old "Are you drunk? I thought tonight was the night of your date."
    new "酔っ払ってるのか？今夜はデートの夜だと思ったけど。"

    # say L1550 pla
    old "Shouldn't you be with the guy?"
    new "お前は男の子といていいんじゃないのか？"

    # say L1551 lyd
    old "I 'uess I zhould be. But it didn't go well, like a' all."
    new "私もそう思ってたけど、全然上手く行かなかったわ。"

    # say L1552 pla
    old "It didn't? What happened this time?"
    new "うまくいかなかったのか？今度は何があったんだ？"

    # say L1553 lyd
    old "I don't know!"
    new "わからない！"

    # say L1554 lyd
    old "I just wasn't able to, when 'e moment came I just felt... nothing."
    new "その時になって、ただ何も感じられなかったの。"

    # say L1555 pla
    old "What do you mean nothing? I thought you liked the guy."
    new "何言ってんの？何も感じなかったってどういうこと？君はその男のことを好きだって思ったんじゃないの。"

    # say L1556 lyd
    old "I did, I really did, and I think he's cute, and sexy, and funny... but I just wasn't able to focus on him."
    new "私は本当にそう思ってたの、彼はかわいいし、セクシーだし、面白いと思ったけど…結局、彼に集中できなかったの。"

    # say L1557 lyd
    old "I just didn't want to do it with him... but I still want to have sex."
    new "彼とやりたくなかったの……でも、セックスはしたいの。"

    # say L1559 pla
    old "I don't get it, if you want sex all you had to do was sleep with that guy."
    new "分かんないけど、 SEXしたいならその男と寝りゃいいじゃん。"

    # say L1560 lyd
    old "I don't really think that would have worked."
    new "そんなのうまくいかなかっただろうと思うの"

    # say L1561 lyd
    old "I think I was wrong about some'ing, I'm not the type of woman who... hips!"
    new "何か勘違いしてたみたい、私はそんな女じゃないわ…ヒップ！"

    # say L1562 lyd
    old "Sorry... who sleeps around. I'm a one-man woman!"
    new "ごめんなさい…浮気なんてしない女よ。私は一人の男だけを愛する女なの！"

    # say L1563 pla
    old "I get that, but you told me you believed this guy was that one man, why did you suddenly backed out of it? "
    new "分かってるけど、君はこの男がその一人の男だって信じてたって言ってたのに、なんで急に引いちゃったの？"

    # say L1564 lyd
    old "D- don't you get it? I already have a man in my life."
    new "分かんないの？私にはもう彼氏がいるのよ。"

    # say L1565 pla
    old "What? Don't tell me you're still thinking about grandpa."
    new "何？まだおじいちゃんのことを考えてるの？"

    # say L1566 pla
    old "I think you need to move on from that, that's the whole point, that you wouldn't be caught up in the past."
    new "それから先に進むべきだよ、過去に囚われてちゃダメだろ。"

    # say L1567 lyd
    old "No, not, no, think about it, there's only one man that I let, and want to touch me."
    new "いいえ、違うの、考えてみて、私を触らせていいのはただ一人だけよ。"

    # say L1569 pla
    old "You don't mean... me?!"
    new "君は… 俺のこと？！"

    # say L1570 lyd
    old "Who else dummy?"
    new "誰だと思ってるの、バカ？"

    # say L1572 pla
    old "W- w- what?"
    new "何？"

    # say L1574 lyd
    old "As I said you're the only one I'll allow to touch me."
    new "私が言った通り、あなた以外には誰にも触らせないわ。"

    # say L1575 lyd
    old "Not only that, you're the only man I was able to think about when I tried to do it with those other guys."
    new "それだけじゃない、他の男の人たちとやろうとした時も、君のことしか考えられなかったの。"

    # say L1576 lyd
    old "Oh [pla]! I know it sounds crazy to you, but that's how it is, and I don't want to go around wasting my time with those other men."
    new "ああ [pla]！確かに変な話かもしれないけど、それが現実で、他の男の人とはもう時間の無駄だと思うの。"

    # say L1577 lyd
    old "After having seen all those dick pics they kept sending me, now I only think they're not much. Nothing compared to you."
    new "あの人の送ってくるチンポの写真を見てから、今じゃ彼らのこと全然魅力的じゃないわ。君と比べたら、何もかも物足りないもの。"

    # say L1578 lyd
    old "Besides, all of those guys, they're so childish, going all out on a phone."
    new "それに、あの男の子たちはスマホで全然子供っぽいよね。"

    # say L1579 lyd
    old "Ugh!"
    new "うう"

    # say L1580 lyd
    old "There's only one man I want to be intimate with..."
    new "私にとって親密になりたいのは、ただ一人だけよ..."

    # say L1581 pla
    old "Are you for real? Do you really mean this?"
    new "本気で言ってるの？ほんとうにそう思ってるの？"

    # say L1582 lyd
    old "I do, I really do."
    new "うん、本当にそう思ってるの。"

    # say L1583 lyd
    old "And I also know you want it too, come on, I know you liked it, the other times. So come on, let's just do it."
    new "そして、あなたも欲しくて仕方ないってことも知ってるよ、さあ、前も気に入ったんでしょ？だからさ、もうやっちゃおうよ。"

    # say L1585 lyd
    old "Why do you think I came all the way here?"
    new "なんで私がここまで来たと思ってるの？"

    # say L1586 lyd
    old "It wasn't only to tell you that I couldn't get it on with some other guys."
    new "それだけのために来たんじゃないよ。"

    # say L1587 pla
    old "But- but... w- we're in my room, I don't think we should."
    new "でも、でも……ここは俺の部屋だけど、そんなことしちゃダメだと思うよ。"

    # say L1589 lyd
    old "Shhh, don't worry, nobody will listen to us. It's ok..."
    new "シッ、心配しないで、誰も聞いてないから。大丈夫よ…"

    # say L1596 lyd
    old "What do you think, I'm finally cutting loose and doing what I want."
    new "何考えてんの、ついに自由になって、やりたいことをするのよ。"

    # say L1605 lyd
    old "Ever since last time I've been wanting you to fuck me again."
    new "前回からずっと、またあなたに犯して欲しがってたの。"

    # say L1606 lyd
    old "It's because of this dick of yours that I haven't been able to be with other guys."
    new "あなたのチンポのせいで、他の男の人とは関係持てなかったの。"

    # say L1607 lyd
    old "I still remember how good it felt that one time."
    new "あの時の感じがまだ忘れられないの。"

    # say L1608 lyd
    old "Now, let's not delay it anymore, I want it in me right now!"
    new "さあ、待たせないで、今すぐ私の中に入れて！"

    # say L1617 lyd
    old "Oh! Oh my god! What am I doing in your room?!"
    new "あっ！神様！どうして私は君の部屋にいるの？！"

    # say L1619 pla
    old "Uhh... Well... yesterday you came here."
    new "うーん… 昨日君がここに来たんだね。"

    # say L1620 pla
    old "You were drunk and..."
    new "君は酔っ払ってて…"

    # say L1621 lyd
    old "Oh God! That's right! I came in here when I was drunk!"
    new "ああ、そうだった！ 酔っ払ってここに入ってきたんだ！"

    # say L1622 lyd
    old "Listen [pla], I'm sorry, I don't know what happened."
    new "[pla]、ごめんなさい、何が起こったのかわからないの。"

    # say L1623 lyd
    old "And I shouldn't be here, last night was just a product of the alcohol and nothing else."
    new "ここにいるべきじゃないの、昨夜はただ酔っ払っていただけで、何も意味ないんだから。"

    # say L1624 pla
    old "Hey..."
    new "Hey... 何も言うな、もう朝方になってきて誰かに見られるかもしれないから。さようなら、もう行きます。"

    # say L1625 lyd
    old "Don't say anything, it's getting very early and somebody could see us."
    new "何も言わないで、もう朝方になって誰かに見られそうだから。"

    # say L1626 lyd
    old "I should just leave, bye."
    new "もういきまーす、さよなら。"

    # say L1644 pla
    old "Hi... Uhh, h- how are you... feeling?"
    new "ひ… うーん、感じはどう？"

    # say L1645 lyd
    old "[pla]! H- hi."
    new "[pla]！　ひっ、 hey。"

    # say L1647 lyd
    old "Listen [pla] what happened last night made me think a lot about some stuff."
    new "[pla]、昨夜のこと考えちゃったの。"

    # say L1648 lyd
    old "That was a horrible mistake, and it shouldn't have happened."
    new "それは最悪の間違いで、起こるべきじゃなかった。"

    # say L1649 lyd
    old "So, I decided we shouldn't see each other or talk again for a while."
    new "だから、しばらく会ったり話したりするのはやめようって決めたの。"

    # say L1651 pla
    old "Listen, I know you're shook and confused."
    new "リディア、俺も君がショックで混乱してるって分かってる。"

    # say L1652 pla
    old "But I don't think you should be alone right now."
    new "でも今君が一人でいるのはよくないと思うよ。"

    # say L1653 lyd
    old "This isn't just a rash decision."
    new "これはただの衝動的な判断じゃないわ。"

    # say L1654 lyd
    old "I think I made a mistake with this whole online dating thing."
    new "このオンラインデートのこと、間違えたのかもしれないと思うの。"

    # say L1655 lyd
    old "I did want to meet and date somebody."
    new "会って付き合う人を見つけたくて思ったの。"

    # say L1656 lyd
    old "But it got out of my hands at one point. You saw how much it was affecting me."
    new "でも、ある時点でコントロールできなくなったの。あなたもそれがどれだけ私に影響を与えていたか見たでしょ。"

    # say L1657 lyd
    old "My sudden mood swings, and odd behavior."
    new "急な気分の変化や、変な行動。"

    # say L1658 lyd
    old "I don't want to deal with that anymore."
    new "もうそんなの対処したくない。"

    # say L1659 lyd
    old "No, what I need is time to think and get my bearings together."
    new "いいえ、私が必要としているのは、頭を整理する時間よ。"

    # say L1660 pla
    old "So, I shouldn't have helped you?"
    new "じゃあ、俺が手伝うんじゃなかったってことか？"

    # say L1661 lyd
    old "That's not what I said. I actually think that your help was good for me, and I'm grateful for it."
    new "そうじゃなくて。あなたの助けは私にとって良かったし、感謝してるの。"

    # say L1662 lyd
    old "It's just that I feel that things have gotten out of hand lately, so we should just relax for a little while. You know?"
    new "最近、ちょっと手が回りすぎちゃってる感じがするから、少しはゆっくりしようよ。分かってくれる？"

    # say L1663 pla
    old "I guess that if that is what you want..."
    new "分かった、そうしたいなら…"

    # say L1664 lyd
    old "It is, it really is."
    new "そう、本当にそうよね。"

    # say L1666 pla
    old "I see... I understand. If you're ok, then I guess I better leave."
    new "分かった…わかったよ。君がいいなら、俺は帰るよ。"

    # say L1667 pla
    old "But if you ever feel like you need to talk, don't hesitate to call me. Ok?"
    new "でも、もし話したいと思ったら、遠慮せずに連絡してね。いいよね？"

    # say L1668 lyd
    old "I will, thank you."
    new "うん、ありがとう。"


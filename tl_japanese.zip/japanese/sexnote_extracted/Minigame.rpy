# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Mechanics/Minigame.rpy
translate japanese strings:

    # narrator L270 
    old "Drag the documents that must be sent to the right destination, do it quickly to reach all the deliveries of the day."
    new "送らなければならない書類を右の宛先にドラッグして、一日の配達を全部早く終わらせろ。"

    # say L311 drag_name
    old "Town Hall"
    new "市役所"

    # narrator L396 
    old "To fix the roof you have to drag the tiles one by one to cover the damage."
    new "屋根を直すには、瓦を一つずつドラッグして壊れた部分を覆うんだ。"

    # narrator L633 
    old "Open up the boxes two by two, and pair them up with the one equal to them."
    new "箱を二つずつ開けて、同じものとペアにしよう。"

    # narrator L744 
    old "Try to select the profiles that are more akin to what Lydia wants. Swipe the correct ones right and the wrong ones left."
    new "Lydiaが好むタイプに近いプロフィールを選ぼう。正しいものは右に、間違っているものは左にスワイプする。"

    # narrator L746 
    old "Remember that these are some of the characteristics that Lydia doesn't like: white hair, red hair, old look and mustache."
    new "リディアが嫌う特徴を覚えておこう：白髪、赤髪、老けた見た目、そしてひげ。"


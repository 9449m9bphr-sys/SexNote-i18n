# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/rubAnimations.rpy
translate japanese strings:

    # say L6 gomRub
    old "Mmm, I love how it tastes."
    new "んん、この味が大好き。"

    # say L7 gomRub
    old "Your dick is so big."
    new "あなたのちんこ、大きいね。"

    # say L8 gomRub
    old "And you’re so hard."
    new "君のチンポ、めちゃくちゃ硬いね。"

    # say L12 gomRub
    old "Sluurp! Are you enjoying it?"
    new "スループ！楽しんでるのか？"

    # say L13 pla
    old "Mmm...  I guess. it’s a bit weird with Ruby’s body though."
    new "んん… まあ、そうだな。でもルビーの体でやってるとちょっと変だよ。"

    # say L14 gomRub
    old "Your dick, it’s twitching."
    new "あなたのちんこ、震えてるね。"

    # say L15 gomRub
    old "Mmm! And it’s so tasty, I love it!"
    new "ん！こんなに美味しいの、大好き！"

    # say L19 gomRub
    old "Yes, Yes! I love this feeling in my mouth!"
    new "はい、はい！口の中で感じるのが大好き！"

    # say L20 gomRub
    old "I can feel your body tensing up!"
    new "あなたの体が緊張してるのを感じる！"

    # say L21 pla
    old "T- This is, aaah!"
    new "これだ、ああっ！"

    # say L45 gomRub
    old "Yes! Yes! Do it!"
    new "はい！はい！やって！"

    # say L46 gomRub
    old "Give me that magic power!"
    new "魔法の力くれ！"

    # say L52 gom
    old "Oh wow! You’d given me magic before, but this is way different!"
    new "あわ、すごい！前にも魔法をくれたけど、これとは全然違うわ！"

    # say L53 gom
    old "Human bodies are amazing. It feels so different."
    new "人間の体ってすごいね。全然違う感じがする。"

    # say L54 gom
    old "It didn’t feel bad before, it’s just so... weird!"
    new "前は悪くなかったけど、ただすごく... 異質な感じ！"

    # say L55 pla
    old "Hmm... Yeah, sure."
    new "うーん… そうかも。"


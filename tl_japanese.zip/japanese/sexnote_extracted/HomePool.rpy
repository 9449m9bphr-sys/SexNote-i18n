# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/HomePool.rpy
translate japanese strings:

    # say L13 pla
    old "I should talk with Brixxida first."
    new "ブリクシダと話すべきだな。"

    # say L37 pla
    old "No, no, sorry I was just walking around."
    new "いやいや、すみません、ただ歩いていただけです。"

    # say L55 ann
    old "[pla]... Are you trying to peek at me while I sunbathe?"
    new "[pla]… 日光浴してるところを覗こうとしてるの？"

    # say L57 pla
    old "What? No, I wasn't-"
    new "何？いや、そんなつもりじゃなかったけど-"

    # say L59 ann
    old "Uhm, you get very nervous, kid..."
    new "うーん、君は結構緊張してるんだね…"

    # say L61 ann
    old "Is this what you want to see?"
    new "これを見たいの？"

    # say L66 ann
    old "Well, if that's what you want..."
    new "もしそれが君が見たいものなら…"

    # say L68 ann
    old "Just don't bother me while I sunbathe, ok?"
    new "日光浴してるときは邪魔しないでよね、いい？"

    # say L82 ann
    old "Didn't I tell you not to bother me? Don't keep bothering me."
    new "私が邪魔しないでって言ったでしょう？ まだ邪魔するの？"

    # say L84 pla
    old "Ok, sorry."
    new "分かった、ごめん。"


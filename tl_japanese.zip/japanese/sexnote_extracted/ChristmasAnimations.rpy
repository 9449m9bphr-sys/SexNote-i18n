# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/ChristmasAnimations.rpy
translate japanese strings:

    # say L6 shiHin
    old "Ok [pla], just make sure to enjoy it."
    new "じゃあ [pla]、楽しんでね。"

    # say L7 shiBil
    old "Mmmmm."
    new "んんん。"

    # say L8 shiBel
    old "Yes, like that, do you like the taste of his dick?"
    new "うん、そうやって、その味気に入ってる？"

    # say L9 shiBil
    old "Mmm! Slurrp!"
    new "んっ！ジュルッ！"

    # say L10 shiHin
    old "Hahaha, that’s right. Enjoy it, put it all in your mouth."
    new "ははは、そうだよ。楽しんで、全部口に入れて。"

    # say L14 shiBel
    old "It’s so big, it can’t even fit it in her mouth."
    new "大きいから、全然口に入らないね。"

    # say L15 shiHin
    old "Is it feeling good [pla]?"
    new "気持ちいいかい [pla]？"

    # say L16 pla
    old "Y- yes, it feels really good."
    new "うん、本当に気持ちいい。"

    # say L19 shiBil
    old "It's so fucking huge..."
    new "大きいよ、本当に巨大だ..."

    # say L20 shiBil
    old "And it’s throbbing in my mouth."
    new "それが私の口の中で脈打ってるの。"

    # say L21 shiBil
    old "I think he’s getting close."
    new "もうすぐイきそうね。"

    # say L22 shiBel
    old "That’s right, keep pushing that cock in your mouth!"
    new "そうだよ、そのチンコをもっと奥まで咥えて！"

    # say L47 shiHin
    old "Are you cummin [pla]?"
    new "お前、もうイクの [pla]？"

    # say L48 pla
    old "Ughh... Y- yes..."
    new "うっぐh... よ、はい..."

    # say L49 shiBel
    old "Then do it! Cum! Fill her mouth!"
    new "じゃあ、やれ！ 出して！ 口の中いっぱいに！"

    # say L50 pla
    old "Ughhh! Ahhh!!!"
    new "うぐっ！ああっ！！"

    # say L55 shiHin
    old "That looked great!"
    new "それ、良かったね！"

    # say L56 shiBel
    old "It really did."
    new "本当に良かったね。"

    # say L57 shiBel
    old "You see Mildret? We knew you would enjoy it."
    new "ミルドレット、見たでしょ？楽しんでくれると思ってたの。"

    # say L58 shiBil
    old "It was... good."
    new "それは…良かった。"

    # say L59 shiBil
    old "These bodies are certainly incredible."
    new "これらの身体は確かに素晴らしいね。"

    # say L60 shiBil
    old "And the taste... I feel I could get used to it."
    new "そしてその味……惯れるかもしれないな。"

    # say L61 shiHin
    old "Hahaha, it’s good to see you’re enjoying the ritual."
    new "ははは、儀式を楽しんでくれて何よりだね。"

    # say L62 shiBel
    old "What about if we get ready to enjoy that cock inside us?"
    new "それじゃ、そのチ○ポを楽しむ準備をしようか？"

    # say L63 shiHin
    old "That's a good idea..."
    new "いいアイデアだね…"

    # say L64 shiBil
    old "All right."
    new "よし。"

    # say L73 shiBel
    old "How is the ritual going Linett?"
    new "リネット、儀式はうまくいってるか？"

    # say L74 lin
    old "It’s good, I was able to stabilize a breaching point."
    new "大丈夫、侵食ポイントを安定させることができたよ。"

    # say L75 lin
    old "But to open it I’m going to need an even bigger magic discharge."
    new "でも開くにはもっと大きな魔力の放出が必要だよ。"

    # say L76 shiHin
    old "Oh, don’t worry, that’s what’s coming just now. Or maybe I meant cumming..."
    new "心配しなくていい、今まさにそれをしてるところさ。もしかしたら、出してるって意味かもしれないけど…"

    # say L77 shiBel
    old "This is where we really enjoy it."
    new "ここが本番で本当に楽しむところだよ。"

    # say L78 shiHin
    old "Let’s do it then."
    new "それじゃ、やろう。"

    # say L79 milBil
    old "This is still new for me [pla]. So remember to be gentle."
    new "まだ慣れてないから [pla]、優しくしてね。"

    # say L80 pla
    old "Sure."
    new "分かってるよ。安心しろ。"

    # say L93 milBil
    old "Mmm, this sensation. It’s so strong."
    new "この感覚、強烈だな。"

    # say L94 milBil
    old "And so big, incredible."
    new "でかくて、すごいな。"

    # say L95 gomHin
    old "Move a little faster [pla]."
    new "もっと早く動いて [pla]。"

    # say L99 milBil
    old "Oh! It feels so hot!"
    new "ああ！ 熱いっ！"

    # say L100 devBel
    old "Yes, enjoy it Mildret. Do you like his cock inside you?"
    new "うん、楽しんで Mildret。彼のチ○ポの中が好きかい？"

    # say L101 milBil
    old "I do, I really like it!"
    new "うん、本当に好き！"

    # say L105 milBil
    old "Ahh! Ahh! This is amazing!"
    new "アッ！アッ！これ、最高だよ！"

    # say L106 milBil
    old "It feels so good!"
    new "気持ちいい！"

    # say L107 milBil
    old "Do it some more, keep going!"
    new "もっとやって、続けて！"

    # say L130 milBil
    old "This feeling, I think I’m cumming!"
    new "この感じ、イキそう！"

    # say L132 pla
    old "Ahh! Y- yes!"
    new "アッ！ や、やあ！"

    # say L138 devBel
    old "So, did you like it?"
    new "じゃあ、気に入ったか？"

    # say L139 gomHin
    old "It was very good."
    new "それはとても良かった。"

    # say L140 devBel
    old "I’m glad you enjoyed it, but it’s my turn now."
    new "良かったけど、今度は私の番だよ。"

    # say L141 devBel
    old "I actually wonder how it’s going to be with this small body."
    new "この小さな体でどんな風になるのかな、実際に試してみないとね。"

    # say L142 devBel
    old "I hope it’s going to be as good as last time."
    new "前回と同じくらい楽しくなるといいな。"

    # say L143 gomHin
    old "Only one way to find out..."
    new "確かめるのは一つしかないな"

    # say L161 devBel
    old "Ohh! Ahh! It’s so big!"
    new "オッ！アッ！大きい！"

    # say L162 devBel
    old "It fills me up, completely."
    new "いっぱい感じるよ、完全に。"

    # say L163 devBel
    old "Uhhh it hurts, but still feels so good!"
    new "うーん、痛いけど、それでも気持ちいい！"

    # say L167 devBel
    old "Yes, yes, just like that."
    new "うんうん、そうそう。"

    # say L168 devBel
    old "I love how your cock feels."
    new "あなたのちんこが感じるのを愛してる。"

    # say L169 devBel
    old "Ohhh yeah, with this little body feels even better!."
    new "オッホッホ、そうだよ、この小さな体で感じるともっといい！"

    # say L173 gomHin
    old "Do you like how he pounds your pussy Devonne?"
    new "デボンヌ、彼のチ○ポがおま○こを突くのが好き？"

    # say L174 devBel
    old "Ah, Ah, YES!"
    new "アッ、アッ、イイ！"

    # say L175 devBel
    old "I love it! I love it!"
    new "好きだ！大好きだ！"

    # say L176 devBel
    old "I want to keep doing it in this body forever!"
    new "この体で永遠に続けたい！"

    # say L199 devBel
    old "I’m cummin! I can feel it!"
    new "出そう！感じてる！"

    # say L200 pla
    old "M- me too!"
    new "俺もだ！"

    # say L201 devBel
    old "Do it! Cum in me!"
    new "やって！ 中に出すんだ！"

    # say L207 devBel
    old "That was sooo good."
    new "それがすごく良かった。"

    # say L208 devBel
    old "I think I could get addicted to it."
    new "これって、ハマっちゃいそうだな。"

    # say L209 devBel
    old "And I think it felt even better because of how small this body is."
    new "そして、この体が小さくて感じやすかったから、もっと良かったと思う。"

    # say L210 gomHin
    old "Hmm, now you’ve made me crave it even more!"
    new "うむ、今さら欲しくなってきたな。"

    # say L211 gomHin
    old "Come on [pla] let’s finish the ritual."
    new "さあ、[pla]、儀式を完了させよう。"

    # say L212 gomHin
    old "You’ve done a lot [pla]."
    new "よくやったな [pla]。"

    # say L213 gomHin
    old "So you must be tired, but don’t falter now."
    new "疲れてるだろうけど、ここで諦めるなよ。"

    # say L214 pla
    old "S- sure."
    new "うん、そうさ。"

    # say L231 gomHin
    old "Oh yes! That’s just what I wanted."
    new "ああそう！それがちょうど欲しかったんだ。"

    # say L232 devBel
    old "That’s right [pla]. Fill her all the way up."
    new "そうだよ [pla]、いっぱい満たしてあげて。"

    # say L233 devBel
    old "And go a little faster."
    new "もっと速く動いて。"

    # say L237 gomHin
    old "Ah, Ah, your cock, it’s reaching so deep!"
    new "あ、あ、あなたのチ○ポ、奥まで届いてる！"

    # say L238 gomHin
    old "And it feels so hot as you penetrate me!"
    new "そしてその熱さが私を貫くたびに伝わるの！"

    # say L239 gomHin
    old "I can feel it throbbing in me. I love how it feels!"
    new "感じてるよ、中で脈打ってるの。こんな感じ、大好き！"

    # say L243 gomHin
    old "Ohh! Ohh! YES!"
    new "オッ！オッ！ヤァ！"

    # say L244 gomHin
    old "This is great!"
    new "これ最高だよ！"

    # say L245 gomHin
    old "I feel the magic pushing in!"
    new "魔法が押し寄せてくる感じ！"

    # say L268 gomHin
    old "I’m about to cum!"
    new "もうすぐイク！"

    # say L269 pla
    old "M- me too"
    new "俺もだ！"

    # say L270 pla
    old "I can’t hold it anymore!"
    new "俺も限界だ！"

    # say L271 gomHin
    old "Let it go!"
    new "出しちゃえ！"

    # say L272 gomHin
    old "Shoot your magic in my pussy!"
    new "オマンコに魔法をぶちまけろ！"


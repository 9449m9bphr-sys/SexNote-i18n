# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/BilStory.rpy
translate japanese strings:

    # say L64 pla
    old "What's this? Doodles, messy scratches... hold up, are these lyrics?"
    new "これって何？落書き、乱雑な線……待てよ、これは歌詞なのか？"

    # say L65 pla
    old "Music notes scribbled everywhere. 'Faded echoes, songs we lost...'"
    new "音符が至る所に書き散らされているな。『褪せたエコー、失われた歌…』"

    # say L69 pla
    old "Yeah, that's the right call."
    new "うん、その通りだ。"

    # say L144 pla
    old "Hold up, what’s this flyer on the floor?"
    new "待て、床に落ちてるこのフライヤーは何か？"

    # say L150 pla
    old "School’s doing a music contest? 'Sign up now'..."
    new "学校で音楽コンテストやってるのか？‘今すぐ応募’…"

    # say L339 bey
    old "So breathe, have fun, and remember: the stage is the one place where you’re allowed to be 100 percent yourself. Ready? Let’s make magic!"
    new "息を吐いて、楽しんで、そして覚えておけ：ステージは君が100パーセントの自分自身でいられる唯一の場所だ。準備できてるか？魔法を起こそうぜ！"

    # say L415 bey
    old "Arielle and Kayla!"
    new "アリエルとケイラ！"

    # say L425 bey
    old "Lord have mercy on my edges! Arielle, those whistle tones cleaner than my Sunday choir. Kayla, that belt could wake the dead."
    new "神様、俺の声の端を助けてください！アリエル、そのホイッスルトーンは日曜日のコーラスより綺麗だな。ケイラ、そのベルトは死人を起こすほど強いな。"

    # say L474 bey
    old "Your tone is pure velvet, phrasing is heartbreaking, emotional truth 100 percent. Volume was whisper quiet, but somehow you filled the entire room."
    new "君のトーンは純粋なベルベットで、フレージングは心を打つよ。感情の真実が100パーセントだ。音量はほとんど囁きだったけど、何故か君は部屋全体を埋め尽くした。"

    # say L476 bey
    old "However, [pla]... sweetheart, you were a potted plant."
    new "しかし、[pla]... 甘い子、君はただの観葉植物だったね。"

    # say L478 bey
    old "Next time you move, you breathe with her, you support her. Deal?"
    new "次は動くときに彼女と呼吸を合わせて、支えてあげるんだ。約束だ？"

    # say L496 bey
    old "Sharpay & Ryan: spectacle and precision. Arielle & Kayla: vocal olympics. Billie & [pla]: pure soul."
    new "シャープエイとライアンは見せ場と正確さ、アリエルとケイラは声のオリンピック、ビリーと[pla]は純粋な魂だ。"

    # say L873 pla
    old "Watched like three tutorials last night. How hard can be?"
    new "昨夜三個のチュートリアルを見た。どれだけ難しくなるんだ？"

    # say L892 pla
    old "Let’s try again..."
    new "もう一回やってみようか…"

    # say L905 pla
    old "One more time. Come on, [pla]."
    new "もう一回だ。さあ行こう、[pla]。"

    # say L933 pla
    old "Okay... that almost sounded like music... right?"
    new "よし… ほとんど音楽みたいだった… そうだろう？"

    # say L934 pla
    old "Ugh, enough for today. Fingers are officially dead."
    new "うげ、今日はこれでいいや。指がもう全然動かないよ。"

    # say L1109 pla
    old "Wow... you're amazing."
    new "すごいな…"

    # say L1377 pla
    old "Still not perfect... but it sounded more like a song this time."
    new "まだ完璧じゃないけど…今回は曲らしくなったね。"

    # say L1551 pla
    old "T- they're so sensitive... I can feel them hardening more."
    new "T- そんなに敏感だ… 僕、硬くなってるのが感じるよ…"

    # say L1604 pla
    old "W- what do you have in mind?"
    new "W- 何考えてるんだ？"

    # say L1613 bil
    old "And of course, I know you’re gonna need a little extra motivation..."
    new "もちろん、君は少し余分な動機が必要だってことは私にも分かるよ…"

    # say L1623 bil
    old "Shh. Focus. This is practical training, remember?"
    new "しーっ。集中。これは実践訓練だからね。"

    # say L1624 pla
    old "O- Ok..."
    new "分かった..."

    # say L1625 bil
    old "Mmm... good. Feel how it responds under your fingers?"
    new "うん…いい感じ。指の下での反応を感じてみて？"

    # say L1626 pla
    old "It's... getting wetter already."
    new "もう少し湿ってきているな。"

    # say L1627 bil
    old "That's normal. Keep the rhythm steady. You're learning the technique."
    new "それが普通だよ。リズムを保って続けて。上手になってきたね。"

    # say L1632 bil
    old "Now increase the pressure a bit. Faster circles. Don't lose the rhythm."
    new "圧力を少し上げて。もっと速い円を描いて。リズムは崩さないで。"

    # say L1634 bil
    old "Nngh— yes... that's it. You're doing well. Keep going."
    new "んんー… うん… そう、その調子。上手いわ、続けて。"

    # say L1639 bil
    old "Harder. Don't stop. Make me feel it."
    new "もっと強く。止めてもらわないで。感じさせて。"

    # say L1640 pla
    old "[bil]... you're breathing heavier."
    new "[bil]… 呼吸が荒くなってるな。"

    # say L1641 bil
    old "Fuck... just like that. Keep going. Don't you dare slow down."
    new "ファック…そのまま続けて。絶対に遅くすんじゃねえよ。"

    # say L1646 bil
    old "Ngh- Stop, stop, stop..."
    new "ンッ… 止めて、止めて、止めて…"

    # say L1647 pla
    old "... Did I do something wrong?"
    new "……何か間違ったか？"

    # say L1648 bil
    old "Mmm, no, no... actually you were doing it really well."
    new "ううん、ううん… 実際、すごく上手だったよ。"

    # say L1649 bil
    old "But I want you to try something... Uhh, more advanced."
    new "でも、ちょっと難易度の高いのを試してみてくれない？うーん、もっと上級なことを。"

    # say L1650 bil
    old "Now... use two fingers. Slide them in together. Start slow."
    new "今……二本の指を使って。一緒に挿入して。ゆっくりと始めよう。"

    # say L1652 pla
    old "Uhh... like this?"
    new "うーん…こう？"

    # say L1653 bil
    old "Mmm, yeah, just like that..."
    new "うん、そう、その感じで..."

    # say L1654 bil
    old "Curl them. Find the spot and start moving them slowly... let me feel it."
    new "クルクルさせて。その場所を見つけて、ゆっくりと動かして……感じさせて。"

    # say L1755 bil
    old "Ready for your advanced practice?"
    new "準備できてる？"

    # say L1808 bil
    old "Finally. You're late."
    new "やっと来たね。遅いわよ。"

    # say L1809 pla
    old "I know, I know... I’m sorry."
    new "知ってる、知ってる… ごめん。"

    # say L1810 bil
    old "We don’t have time for this. The teacher’s expecting us."
    new "時間ないわ。先生待ってるんだから。"

    # say L1813 pla
    old "Billie... Wait!"
    new "ビリー… 待ってくれ！"

    # say L1815 pla
    old "I- I don’t think I can do this."
    new "俺は…これ、無理そうだ。"

    # say L1816 bil
    old "Here we go again."
    new "また来たか。"

    # say L1817 pla
    old "I mean it. I don’t feel ready. Not even close."
    new "本気で言ってる。全然準備できてない。全く。"

    # say L1818 bil
    old "Come on! You’ve been practicing for days. You improved a ton."
    new "Come on！何日も練習してきたんだよ。ずいぶん上達したじゃない。"

    # say L1819 pla
    old "Yeah, but only with you. Or at home. This is different. With the teacher... with pressure... I’m not ready."
    new "そうだよ、でも君とだけだ。家でも同じだ。これは違うんだ。先生の前で、プレッシャーを感じながら…まだ準備ができてない。"

    # say L1820 bil
    old "Relax, you don’t have to be perfect today."
    new "リラックスして、今日完璧じゃなくてもいいのよ。"

    # say L1821 pla
    old "But I’m barely even good. What if I mess everything up?"
    new "でも俺、全然上手くないよ。もしそのまま全部ボロボロにしてしまったらどうする？"

    # say L1822 bil
    old "Then you mess up. It happens."
    new "じゃあ失敗するわ。そんなこともあるよ。"

    # say L1823 pla
    old "I don't know, Billie... maybe you should just do this one alone."
    new "比利……maybe you should just do this one alone。"

    # say L1824 bil
    old "Stop. You’re not backing out now."
    new "止めて。今さら引き下がるわけないでしょう。"

    # say L1825 pla
    old "Billie... I really don’t think I can do this."
    new "ビリー……俺には無理だよ。"

    # say L1826 bil
    old "Shut Up! I know you can. You’ve improved. A lot."
    new "黙って！あなたならできるわ。ずいぶん成長したじゃない。"

    # say L1827 pla
    old "But what if I freeze? What if everything falls apart? What if—"
    new "でも、もし固まっちゃったら？ すべてが崩れちゃったら？ もし—"

    # say L1828 bil
    old "Okay, okay, breathe. You’re spiraling."
    new "大丈夫、大丈夫、深呼吸して。落ち着いてよ。"

    # say L1829 pla
    old "I- I don’t know... I feel like I’m gonna choke the moment she looks at me."
    new "俺、知らねえよ… 俺、彼女が見ただけで喉が締め付けられる気がする。"

    # say L1830 bil
    old "Look, standing here arguing isn’t helping either. Come with me."
    new "見ろ、ここで言い争っても何も解決しないわ。私について来い。"

    # say L1831 pla
    old "What? W- where?"
    new "何？どこに？"

    # say L1832 bil
    old "Somewhere quiet. You need to reset before we walk in there."
    new "静かな場所。入る前にリセットしないとね。"

    # say L1855 pla
    old "The bathroom? [bil], what are we—"
    new "トイレか？[bil]、何やってんだよ—"

    # say L1856 bil
    old "Shh. Ok, i locked the door."
    new "しーっ。大丈夫、ドアロックしたよ。"

    # say L1857 pla
    old "Uhh, W- what? Why? We should be heading to class."
    new "うっ、なに？　なんで？　授業に行かなきゃいけないだろ。"

    # say L1858 bil
    old "Listen, you need to chill first. Watch."
    new "聞いて、まずは落ち着いて。見て。"

    # say L1861 pla
    old "W- whoa! [bil]!"
    new "Ｗ－誰だよ！[bil]！"

    # say L1862 bil
    old "There. Take a look."
    new "そこに、見て。"

    # say L1863 pla
    old "I... Uh... they're... wow."
    new "俺… うーん… それらは… すごいな。"

    # say L1864 bil
    old "Heh. Does this help?"
    new "へへ、これで役立つかな？"

    # say L1865 pla
    old "Kinda? But... this isn't about that."
    new "KINDA？でも…これじゃ本題じゃないよ。"

    # say L1866 bil
    old "You can touch them if you want. Might relax you more."
    new "触っても良いよ。もっとリラックスできるかも。"

    # say L1867 pla
    old "Hmm... to be honest, I don't think this is gonna help with the anxiety."
    new "うーん……正直、これじゃ不安は増すだけだと思う。"

    # say L1868 bil
    old "Really? Not even a little?"
    new "ほんと？全然ダメなの？"

    # say L1869 pla
    old "I mean, I really like them, of course. But I'm still freaked about performing."
    new "まあ、もちろん好きだけど、それでもまだ緊張してるんだ。"

    # say L1870 bil
    old "Hmm. Okay, okay... Plan B then."
    new "うーん、うーん… 別の手を使うわ。"

    # say L1871 pla
    old "Plan B?"
    new "プランB？"

    # say L1872 bil
    old "Yeah. Something that always works."
    new "うん、いつも効果的な方法よ。"

    # say L1879 pla
    old "Oh God, [bil]..."
    new "おっかなbinebuta、[bil]..."

    # say L1880 bil
    old "Shh. Let me handle your stress."
    new "しー。ストレスを任せて。"

    # say L1881 pla
    old "This is crazy... but... don't stop."
    new "これって狂ってる… でも… 止めないで。"

    # say L1893 bil
    old "Told you. My methods are foolproof."
    new "言ったでしょ。私の方法は絶対よ。"

    # say L1894 pla
    old "Phew... okay, nerves are gone. Mostly."
    new "ふう… 緊張もだいぶなくなったな。"

    # say L1895 bil
    old "Good. Now let's go before Bey bails on us."
    new "よし、それじゃ行こう。ベイが逃げ出しちゃう前にね。"

    # say L1896 pla
    old "Right. I'm ready now. I think."
    new "よし、今準備できたと思う。"

    # say L1897 bil
    old "You are. Come on."
    new "あなたもね。さあ、行こう。"

    # say L1906 bey
    old "Oh! There you two are. I was about to leave."
    new "おっ、二人か。もう出かけようと思ってたんだ。"

    # say L1907 bil
    old "Sorry. We had... a situation."
    new "ごめん。ちょっと... 状況があったの。"

    # say L1909 bey
    old "A situation?"
    new "状況？"

    # say L1910 bil
    old "Stage panic. I had to calm him down with... a technique that always works."
    new "ステージパニックだったの。彼を落ち着かせるために、いつも効くテクニックを使ったの。"

    # say L1911 bey
    old "Oh! Well, whatever you did, I’m glad it helped. Next time, bring him here, I have plenty of ways to help with anxiety too."
    new "オッ！まあ、何をしたにせよ、助かったよ。次は連れてきなよ、俺にも不安解消の方法がたくさんあるから。"

    # say L1912 bil
    old "Don’t worry. I have a method that works every time."
    new "心配しないで。いつも効く方法があるから。"

    # say L1914 bey
    old "Well, as long as he’s fine now."
    new "まあ、今は大丈夫ならいいけど。"

    # say L1915 pla
    old "I... think so."
    new "俺……そう思うな。"

    # say L1916 bey
    old "Good. Now tell me, how have you two been? Practicing together?"
    new "よし、じゃあ教えてくれ。二人はどうだった？一緒に練習してたのか？"

    # say L1917 bil
    old "A lot. He’s been improving faster than I expected."
    new "たくさん練習してるよ。彼は予想以上に上達が早くて。"

    # say L1918 bey
    old "Really? That’s wonderful."
    new "本当に？それは素晴らしいな。"

    # say L1919 pla
    old "Uhh, actually, I’m still not that great."
    new "うーん、実はまだそんなに上手くないな。"

    # say L1920 bey
    old "No one expects you to be. What matters is progress."
    new "誰もそんなこと期待してないよ。大事なのは成長だ。"

    # say L1921 bil
    old "He’s now supporting me with guitar for the performance."
    new "彼がギターでサポートしてくれるから、パフォーマンスが楽しみだね。"

    # say L1922 bey
    old "Ah! Excellent idea. Your voice with live accompaniment gives the duet a lot of potential."
    new "アハ！いいアイデアだね。君の声に生演奏が加わると、デュエットの可能性が広がるよ。"

    # say L1923 bil
    old "Yeah, that’s the plan."
    new "うん、そのつもりだよ。"

    # say L1924 bey
    old "Alright then, let’s hear you. Perform as if it were the actual contest. After that, I’ll give you both feedback."
    new "じゃあ、聞かせてみろ。本番さながらにやってみてくれ。その後で二人にフィードバックをあげるよ。"

    # say L1926 pla
    old "O-okay..."
    new "おっ、おｋあい…"

    # say L1927 pla
    old "({i}No pressure... no pressure...{/i})"
    new "{i}プレッシャーないよ…プレッシャーないよ…{/i}"

    # say L1936 bey
    old "Okay! Why don’t we do this like a mock presentation?"
    new "Okay！ なんでこんな感じで模擬プレゼンやってみようぜ？"

    # say L1938 bey
    old "Imagine you’re already on stage at the contest. Perform the piece you’ve been working on."
    new "ステージに立っているつもりで、練習してきた曲を演奏してみろ。"

    # say L1939 pla
    old "{i}Billie... I don—{/i}"
    new "{i}ビリー…俺は—{/i}"

    # say L1940 bil
    old "Don’t start panicking again. Just do what we’ve practiced."
    new "またパニックにならないで。練習した通りにやればいいんだから。"

    # say L1941 pla
    old "{i}Right... right.{/i}"
    new "{i}うん…うん。{/i}"

    # say L1975 bey
    old "Wow. That was genuinely impressive."
    new "おお。それは本当に凄かったな。"

    # say L1977 bey
    old "Absolutely. You two have grown a lot."
    new "絶対にね。お前ら二人、ずいぶん成長したな。"

    # say L1978 bey
    old "[pla]... last time you barely moved. You were like a decorative tree."
    new "[pla]... 前はほとんど動かなかったじゃん。まるで飾りの木みたいだった。"

    # say L1979 pla
    old "Uhh... ok."
    new "うーん… 分かったか。"

    # say L1980 bey
    old "This time you actually you played. And with feeling. I’m proud of that."
    new "今回はちゃんと動いてくれたな。感情も込めて。それが良かったよ。"

    # say L1981 bey
    old "You still get nervous, and it shows in your transitions. A few spots were shaky."
    new "まだ緊張してるな、それが移行部分に出ちゃってる。いくつかの場所が揺れてた。"

    # say L1983 bey
    old "It’s normal. With more practice you'll smooth it out. If you want, you can come to extra sessions with me. I can help strengthen your hand technique."
    new "大丈夫だ。もっと練習すれば滑らかになるさ。もし良かったら、俺と一緒に特別練習に来ないか？手のテクニックを強化する手伝いをするよ。"

    # say L1984 bil
    old "No need. I’ve already got him on a very effective practice."
    new "必要ないわ。もう彼ととても効果的な練習をしてるから。"

    # say L1985 bey
    old "Oh! Great. If it works, keep doing it. You two clearly connect well."
    new "オッ、そうか。うまくいってたら続けてくれ。二人、明らかに相性がいいね。"

    # say L1986 bey
    old "Now, Billie. As always your voice is beautiful. Rich tone, controlled color, great emotional delivery."
    new "Billie、いつものように君の声は美しいな。豊かな音色、コントロールされた色彩、素晴らしい感情表現だ。"

    # say L1988 bey
    old "However, there’s room to grow. You rely a bit too much on natural skill."
    new "しかし、成長の余地はあるな。自然の才能にあまりに依存してる部分があるからね。"

    # say L1989 bey
    old "We need to work on technique, breath support, especially sustaining phrases without losing power."
    new "技術と息遣い、特に力を落とさずにフレーズを続けるテクニックを磨く必要があるんだ。"

    # say L1990 bey
    old "Your diaphragm engagement is good, but not consistent. With proper training, your projection and stability will improve a lot."
    new "君の横隔膜の使い方はいいけど、一貫性に欠けてるな。適切なトレーニングをすれば、声の投影と安定性がかなり向上するよ。"

    # say L1991 bil
    old "Oh, ok..."
    new "うーん、そうね..."

    # say L1992 bey
    old "I’d love to train that with you. Come for vocal sessions, and we’ll shape your sound for the contest."
    new "君と一緒に練習したいな。ボーカルのセッションに来てくれれば、コンテスト向けの声を整えられるよ。"

    # say L1993 bey
    old "Just you and me. We’ll polish your technique and make sure you’re ready for the real contest."
    new "君と二人でね。テクニックを磨いて、本番に備えよう。"

    # say L1994 bil
    old "Sounds good. I’m in."
    new "いいな、参加する。"

    # say L1995 bey
    old "Perfect. And [pla], keep practicing with Billie. You two work wonderfully together."
    new "完璧だな。そして [pla]、ビルリーと練習を続けてくれ。君たちのコンビは最高だ。"

    # say L1996 pla
    old "We will."
    new "絶対に練習するよ。"

    # say L1997 bil
    old "Oh, trust me... We definitely will."
    new "信じていいよ…絶対に練習するから。"

    # say L1998 bey
    old "You both have something special together."
    new "二人の間には特別な何かがあるね。"

    # say L1999 bey
    old "Keep up the rhythm. I’ll call you both again for another evaluation soon."
    new "リズムを保ってな。また近いうちに二人を呼んで評価するよ。"

    # say L2000 bil
    old "Thank you for everything."
    new "ありがとう"

    # say L2016 ari
    old "Well, well... look who actually survived a real practice session."
    new "まあまあ… 実践の練習を生き残ったとはね。"

    # say L2017 tay
    old "We heard you two through the wall. That was... almost not terrible. Hahaha"
    new "壁越しに聞こえたよ。それは…まあ、悪くなかったな。ははは"

    # say L2019 bil
    old "Heh. Almost?"
    new "へへ、ほぼ？"

    # say L2020 ari
    old "Your breath control still wavers on the sustain, sweetie. Fix it or you’ll crack on stage."
    new "息のコントロールがまだ不安定だね、甘い子。直さないとステージで音が割れちゃうよ。"

    # say L2021 tay
    old "And you, [pla]... congrats on finally moving. You’re only half a statue now."
    new "お前も、[pla]……やっと動けるようになったな。でもまだ半分像だな。"

    # say L2022 pla
    old "Thanks... I think?"
    new "ありがとう……かな？"

    # say L2023 bil
    old "Keep taking notes, girls. We’re just warming up."
    new "女の子たち、ノートを取って。これからが本番だよ。"

    # say L2024 ari
    old "Please. Technique beats 'raw emotion' every single time."
    new "テクニックが生の感情を上回るよ、毎回ね。"

    # say L2026 tay
    old "See you at the contest... try not to choke when it actually counts."
    new "コンテストで会うわよ……本番では失敗しないようにね。"

    # say L2032 pla
    old "They’re still exactly the same, huh?"
    new "まだ全然変わってないね。"

    # say L2033 bil
    old "Perfect. Makes crushing them way more satisfying."
    new "完璧ね。負かすのがずっと気持ちいいのさ。"

    # say L2040 bil
    old "Okay... I have to admit, that went better than I expected."
    new "まあ……認めざるを得ない、思っていたよりうまくいったわ。"

    # say L2041 pla
    old "Way better. I didn’t completely freeze."
    new "全然固まらなかったよ。"

    # say L2042 bil
    old "Wow, what an achievement. Should we throw you a parade?"
    new "Wow、何の偉業だね。パレードでも開いてあげようか？"

    # say L2043 pla
    old "Hey, for me that’s huge."
    new "Hey、それだけで俺にとっては大したことなんだよ。"

    # say L2044 bil
    old "Yeah... it kinda is."
    new "うん…そうかもね。"

    # say L2045 pla
    old "Seriously, thanks for earlier. Uhh, you know."
    new "まじで、ありがとうな。うーん、さっきのことで。"

    # say L2046 pla
    old "If you hadn’t helped me calm down, I would’ve messed everything up."
    new "もし君が俺を落ち着かせてくれなかったら、全部台無しだったよ。"

    # say L2047 bil
    old "I know."
    new "知ってるよ。"

    # say L2048 bil
    old "You owe me one."
    new "私に一つ借りがあるね。"

    # say L2049 pla
    old "Actually, more than one. I mean it."
    new "実際はそれ以上だ。本気だぞ。"

    # say L2050 bil
    old "Relax. You did the hard part. You didn’t run away."
    new "リラックスして。君が難しい部分をやってくれたんだから。逃げ出さなかったじゃない。"

    # say L2051 pla
    old "Heh, I almost did."
    new "へへ、幾乎やっちゃった。"

    # say L2052 bil
    old "And I almost slapped you. Balance."
    new "そして私はあなたを叩きそうになったわ。バランスね。"

    # say L2053 pla
    old "Still... I’m glad you didn’t let me quit."
    new "それでも……君が辞めさせてくれなかったことに感謝してる。"

    # say L2054 bil
    old "Good. Because you’re way more useful when you don’t panic every five seconds."
    new "良かったわ。だってあなたが五秒ごとにパニックにならなければ、ずっと役立つんだから。"

    # say L2055 pla
    old "I’m working on that."
    new "頑張ってるさ。"

    # say L2056 bil
    old "And you’re getting better. With the guitar. With the nerves. With everything."
    new "あなたは上手くなってるわ。ギターも、緊張も、全部ね。"

    # say L2057 pla
    old "You really think so?"
    new "本当にそう思ってる？"

    # say L2058 bil
    old "Don’t get cocky. But yeah... you’re not useless anymore."
    new "自慢するなよ。でもまあ…もう無駄遣いじゃないね。"

    # say L2059 pla
    old "Haha, that’s the nicest thing you’ve ever said to me."
    new "ははは、君が俺に言った中で一番優しい言葉だな。"

    # say L2060 bil
    old "Don’t get used to it."
    new "慣れるなよ。"

    # say L2061 pla
    old "So... what now?"
    new "じゃあ……次はどうする？"

    # say L2062 bil
    old "Now we keep practicing. You, with the guitar. Me, with the teacher."
    new "これから練習を続けよう。君はギター、私は先生と。"

    # say L2063 bil
    old "And together... We make this thing actually work."
    new "一緒に……これを本当に動かすの。"

    # say L2064 pla
    old "Deal."
    new "約束だな。"

    # say L2067 bil
    old "Alright, it’s getting late. Go home before you turn into a pumpkin."
    new "さあ、時間も遅くなったわ。かぼちゃになっちゃう前に帰って。"

    # say L2068 pla
    old "Yeah, I should. But... thanks again. For everything."
    new "そうだな、帰るか。でも…本当にありがとう。全てのことについて。"

    # say L2069 bil
    old "Yeah, yeah. Just don’t waste what we started."
    new "うん、うん。始まったことだけは無駄にしないでね。"

    # say L2070 pla
    old "I won’t. I promise."
    new "絶対に無駄にしないから安心しろ。"

    # say L2072 pla
    old "See you soon."
    new "また会おうな。"

    # say L2092 bil
    old "Finally. You're here."
    new "やっと来たのね。"

    # say L2093 pla
    old "Yeah, your text said it was urgent. What's up?"
    new "そうだな、君のメッセージには急いでるって書いてあったよ。何があったんだ？"

    # say L2094 bil
    old "Well, I've been in lessons with the teacher. It's going okay, but I need your help with something."
    new "まあ、先生の授業を受けているの。うまくいっているんだけど、ちょっと手伝ってほしいことがあるの。"

    # say L2095 pla
    old "Do you need my help?"
    new "手伝って欲しくない？"

    # say L2096 bil
    old "Better talk in my room. Come on."
    new "部屋で話した方がいいわ。来なよ。"

    # say L2103 bil
    old "Alright, so, those vocal sessions with Bey were way tougher than I expected."
    new "ええ、あのボーカルのセッションは、ベイとやったんだけど、思っていた以上に大変だったの。"

    # say L2104 pla
    old "'Tougher' for you? Seriously?"
    new "君の『tougher』って、本気？"

    # say L2105 bil
    old "Yeah, I mean, I have the talent, sure. But I haven't practiced consistently in years."
    new "うん、才能はあるんだけどね。でも何年もちゃんとした練習してなかったからさ。"

    # say L2106 bil
    old "I lost some edge on breath control, especially under pressure."
    new "息のコントロールが少し鈍くなったの、特に緊張したり心拍数が上がると声が震えて、いくつかの音を継続的に保てないの。"

    # say L2107 bil
    old "Like, when nerves hit or heart rate spikes, my voice shakes. So, I can't sustain some notes without cracking."
    new "緊張したり心拍数が上がると、声が震えちゃうの。だから、一部の音を継続的に保つのが難しくて、声が割れちゃうの。"

    # say L2108 pla
    old "That sounds rough. What does the teacher say?"
    new "それきついね。先生はなんて言ってる？"

    # say L2109 bil
    old "She's got me on diaphragmatic breathing deep belly breaths to stabilize. And box breathing: inhale four, hold four, exhale four, hold four."
    new "先生は腹式呼吸を教えてくれて、深呼吸で安定させるようにしてるの。あと、ボックス呼吸も：吸う4秒、止める4秒、吐く4秒、止める4秒。"

    # say L2110 bil
    old "Helps calm the nervous system, reduces anxiety. But it's not enough for real stage stress."
    new "神経系を落ち着かせ、不安を軽減するんだけど、本番の舞台の緊張には足りないの。"

    # say L2111 pla
    old "Stage stress? Like performance anxiety?"
    new "ステージストレス？パフォーマンス時の不安みたいなやつ？"

    # say L2112 bil
    old "Exactly. Heart pounding, shallow breaths... Voice goes to shit. Need to practice holding technique when everything's agitated."
    new "そうよ。心臓がドキドキして、息が浅くなる……声も出にくくなるわ。そんな状態のときに、テクニックを保つ練習が必要なの。"

    # say L2113 pla
    old "Ohh, like exercises while running or something?"
    new "オッ、走ってる時とかの練習のこと？"

    # say L2114 bil
    old "Hmm, kinda. I already tried that stuff. Jogging while singing, high-heart-rate drills... even picturing the crowd without freaking out."
    new "うん、そんな感じ。走ってるとき歌ったり、心拍数が高い状態のトレーニングをしたり... さらには、観客を想像しても動じないよう練習したの。"

    # say L2115 bil
    old "Progress is slow. With the contest coming, traditional stuff won't cut it."
    new "進歩は遅いわ。コンテストが近づいてるのに、伝統的な方法じゃ足りないの。"

    # say L2116 pla
    old "Damn. So what's the plan?"
    new "くそ、じゃあ何をするつもり？"

    # say L2117 bil
    old "Well, I've been researching some non-traditional stuff. Found training under extreme stimulation to build resilience."
    new "まあ、非伝統的な方法を調べてみたの。極度の興奮状態でのトレーニングで耐性をつける方法を見つけたの。"

    # say L2118 pla
    old "Like... What kind?"
    new "どんな種類の刺激？"

    # say L2119 bil
    old "Ways to spike heart rate and nerves, but controlled. Make the body adapt to singing through it."
    new "心拍数と神経を高める方法だけど、コントロールしながら体に慣らすの。そうすればその状態でも歌えるようになるの。"

    # say L2121 bil
    old "Anyway, the thing is I need you, because I wanna practice vocals under some strong stimulation. You know, to simulate the pressure."
    new "とにかく、私が你需要なのは、強い刺激の下でボーカルの練習をしたいから。圧力のある状況を再現するためにね。"

    # say L2122 pla
    old "Strong stimulation? Like... Distracting you?"
    new "強烈な刺激？例えば…君を惑わせるような？"

    # say L2123 bil
    old "Why do you have to be so slow sometimes?"
    new "なぜそんなに遅いの有时候翻译会超出简单的\"OK\"或者纠正的句子，但根据您的要求，我将仅提供纠正后的句子："

    # say L2124 pla
    old "Uh?"
    new "う？"

    # say L2125 bil
    old "Listen, I need my heart racing and my body all tense while I'm practicing singing."
    new "ねぇ、歌を練習してるときには心臓がドキドキして体が緊張してる状態でないとダメなの。"

    # say L2126 pla
    old "Still not following..."
    new "まだ全然わかんないな…"

    # say L2127 bil
    old "Ughh. I need you to stimulate me... sexually. While I sing."
    new "うっ… 私を刺激して… 性的に… 歌ってる間よ。"

    # say L2128 pla
    old "Ohhhh..."
    new "オォ……"

    # say L2129 bil
    old "Yeah, it's not orthodox, but time's short. And hey, I've helped you with 'non-traditional' methods before."
    new "うん、普通じゃないけど時間がないの。それにさ、前にも『非伝統的』な方法で手伝ったじゃん。"

    # say L2130 bil
    old "You owe me a few, remember?"
    new "いくつか私に借りがあるって覚えてるでしょ？"

    # say L2131 pla
    old "Well, that’s... fair, I guess."
    new "まあ、そうかな。"

    # say L2132 bil
    old "But, I mean, I’m not saying you’re obligated."
    new "でも、義務的だって言ってるわけじゃないよ。"

    # say L2133 bil
    old "I’m saying this could actually help me control my voice when everything inside me is going wild."
    new "これは実際に、中が暴走しそうなときでも声をコントロールできる手助けになると思ってるの。"

    # say L2134 pla
    old "And you really think this will work?"
    new "本当にこれで上手くいくと思うのか？"

    # say L2135 bil
    old "Well, I’m not doing it just for fun."
    new "まあ、ただの遊びじゃないけどね。"

    # say L2136 bil
    old "Okay, maybe a little."
    new "まあ、少しはね。"

    # say L2137 pla
    old "Heh. Alright, if you’re serious, then... Yeah. I’ll help."
    new "へへ、本気なら手伝うよ。"

    # say L2139 pla
    old "You helped me when I was stuck. If this is what you need, I’m in."
    new "君が困ってる時に手伝ってくれたし、これが君が必要なものなら、俺も協力するよ。"

    # say L2141 bil
    old "If you’re going to help, we’ll treat this like real training."
    new "手伝うなら、本気のトレーニングと思ってくれる？"

    # say L2142 pla
    old "Alright... So what exactly am I supposed to do?"
    new "よし… じゃあ、具体的に何をすればいいんだ？"

    # say L2143 bil
    old "Ok, first, you follow my lead."
    new "まずは、私の後を追うんだ。"

    # say L2144 bil
    old "Second, you don’t overthink it."
    new "二つ目、過剰に考えないで。"

    # say L2145 bil
    old "Third, remember the goal: I have to keep singing no matter what I’m feeling."
    new "三つ目は、目標を忘れないこと。どんな気分になっても歌い続けなきゃならないの。"

    # say L2146 pla
    old "Got it. You sing, I... create the distraction."
    new "わかった。君が歌うなら、俺は... 観客を惑わすことにする。"

    # say L2147 bil
    old "Yeah. If we do this right, my voice should stays steady even when everything else is falling apart."
    new "うん、うまくいけば、私の声は安定してるはずよ、どんなことが起こってもね。"

    # say L2148 pla
    old "Alright, I'm in. Just tell me exactly what you need, and I'll handle it."
    new "分かった、任せて。必要なこと全部教えて、俺がうまくやってみせる。"

    # say L2149 bil
    old "Ok, first let me get ready..."
    new "Ok、まずは準備するね..."

    # say L2153 bil
    old "Do you like what you see? Heh?"
    new "見てくれた？へhé？"

    # say L2158 bil
    old "What about now?"
    new "これでどう？"

    # say L2159 pla
    old "Holy... fuck..."
    new "Holy... fuck... → 見てびっくりだな... やばい..."

    # say L2160 bil
    old "No reason we both can't benefit from this 'practice', right?"
    new "この‘練習’で二人とも利益を得られなくもないわ、よね？"

    # say L2161 bil
    old "Heh. Still takes your breath away every time, huh?"
    new "へへ、毎回そうやって息をのむのね。"

    # say L2162 bil
    old "Perfect. Means you're properly motivated."
    new "完璧ね。ちゃんとやる気になったってことだもの。"

    # say L2163 bil
    old "Now that you're all fired up... let me get comfortable."
    new "それじゃ、やる気になったところ……私が楽になるわ。"

    # say L2164 bil
    old "Now lie down on the floor before you pass out staring."
    new "今すぐ床に寝なさい、それとも見とれて気絶しちゃうの？"

    # say L2165 pla
    old "Uhh, a- alright..."
    new "うーん、あ、ああ、いいよ…"

    # say L2169 bil
    old "Perfect."
    new "完璧。"

    # say L2173 bil
    old "Your job: stimulate me as hard as you can. Mine: keep breath controlled, sustain notes, hold pitch no matter what."
    new "あなたの仕事は私をできるだけ強く刺激すること。私の仕事は呼吸をコントロールして音を保ち、どんな時でもピッチを維持することよ。"

    # say L2174 pla
    old "Got it. Let's do this."
    new "分かった。やるぞ。"

    # say L2186 bil
    old "Phew... that was intense."
    new "ふう… それは激しかったね。"

    # say L2187 pla
    old "Yeah... did it actually work?"
    new "よし… 実際効いたのか？"

    # say L2188 bil
    old "Big time. I could feel the control improving even as everything else was going crazy."
    new "大成功だったわ。制御が上手くいっているのを感じられたの、他のことが全部狂ってる中でもね。"

    # say L2189 bil
    old "Voice held up better than I expected... but yeah, I'm definitely gonna need more of this."
    new "声の調子は予想以上に保てたけど、うん、これが必要だな。"

    # say L2190 bil
    old "A lot more practice before the stage doesn't wreck me."
    new "ステージでボロボロにならないようにもっと練習が必要だね。"

    # say L2191 pla
    old "Uhh, if you need it, I'm down to keep helping. Same way you've been helping me."
    new "うーん、必要なら俺が手伝うよ。君が俺を助けてくれたように。"

    # say L2192 pla
    old "You know... with the 'advanced practice' and all."
    new "君、\"高度な練習\"のことか。"

    # say L2193 bil
    old "Oh, I get it."
    new "分かったわ。"

    # say L2194 bil
    old "Heh. Tit for tat, huh? Fair enough."
    new "へへ、見返りね。まあ、そうよね。"

    # say L2195 bil
    old "Deal. You keep me steady under pressure... I'll keep those fingers of yours 'motivated'."
    new "約束だよ。君がプレッシャーの下で私を支えてくれるなら、私のほうで君の指をちゃんと動かすね。"

    # say L2196 bil
    old "We're both getting better this way. Win-win."
    new "お互い上手くなっていくわね。 WIN-WIN だね。"

    # say L2197 pla
    old "Exactly. Looking forward to it."
    new "そうだな。今から楽しみだ。"

    # say L2198 bil
    old "Alright, perv. Now seriously, get out before grandma shows up and smells the trouble."
    new "よし、変態。本気で言ってるの。おばあちゃんが来ちゃったら、まずいことになるわ。"

    # say L2199 pla
    old "On my way. See you soon... for more 'practice'."
    new "行くよ。またすぐ来るからな... もっと‘練習’のために。"

    # say L2200 bil
    old "You better. Don't slack on that guitar either."
    new "ちゃんとしなよ。ギターの練習も怠っちゃダメよ。"

    # say L2201 pla
    old "Wouldn't dream of it."
    new "夢にも思わねえよ。"

    # say L2220 bil
    old "Wow, you’re on time. That’s new."
    new "Wow、あなたが時間通りだなんて。新しいね。"

    # say L2221 pla
    old "Yeah... I made sure to wake up early today. Been doing extra practice every day. Feeling ready for whatever comes today."
    new "今日こそは早起きしたよ…毎日追加で練習してきたから、何が来ても大丈夫だと思う。"

    # say L2222 bil
    old "Wow. Actual growth. Who would’ve thought?"
    new "Wow. 実際の成長か。誰も思わないだろうね。"

    # say L2223 bil
    old "So? No panic attack today?"
    new "そう？今日はないの？"

    # say L2224 pla
    old "A little butterflies, sure... but I'm fine. We've got this."
    new "ちょっとドキドキしてるけど… 大丈夫だよ。やれるさ。"

    # say L2225 bil
    old "Look at you. All grown up."
    new "見なさい。立派に大人になったわね。"

    # say L2226 pla
    old "Yeah. I trust what we’ve practiced."
    new "そうだ。練習した通りにできるよ。"

    # say L2227 bil
    old "Good. Because today is just about showing what we can already do."
    new "Good. 今日の試験はすでにできることを示すだけだから。"

    # say L2228 bil
    old "No panic, no drama."
    new "心配しないで、大袈裟にしないでね。"

    # say L2229 pla
    old "I'll try to keep the drama to a minimum."
    new "ドラマは最小限に抑えよう。"

    # say L2230 bil
    old "Do that and I might even be proud of you."
    new "そうしてくれたら私まで誇りに思うかもしれないわ。"

    # say L2231 pla
    old "High honor."
    new "高貴な名誉だね。"

    # say L2242 sha
    old "Darlings! Look who we found!"
    new "ダーリンたち！見つけちゃったわよ！"

    # say L2243 rya
    old "We just finished our private session with Bey. Absolute perfection!"
    new "ベイとのプライベートセッション終わったところだよ。絶対的パーフェクトだった！"

    # say L2244 sha
    old "The choreography, the lighting cues, the costume changes... we have a full Broadway production ready, honey!"
    new "演出、照明のタイミング、衣装替え……全部揃ってるわ、ハニー！まるでブロードウェイのショーみたいよ！"

    # say L2245 rya
    old "Everything planned down to the last sparkle. The crowd is going to lose their minds!"
    new "最後のきらめきまで全て計画済みだよ。観客は興奮するだろうな！"

    # say L2247 bil
    old "Great for you."
    new "良かったな。"

    # say L2248 sha
    old "Oh, look at their little faces. So serious. So... scared."
    new "あら、見てごらん。そんな真剣な顔して、怖がってるんだね。"

    # say L2249 rya
    old "It’s adorable, really. Like two lost puppies trying to play with the big dogs."
    new "かわいいよね、ほんと。迷子の子犬が大人の犬と遊ぼうとしてるみたいだよ。"

    # say L2250 sha
    old "You two still look like you’re auditioning for your very first school play."
    new "君たちはまだ初めての学校の演劇のオーディションのようだね。"

    # say L2251 rya
    old "While we just delivered a show stopping number that will make people stand up and cheer."
    new "俺たちがやったのは、観客を立ち上がらせるような圧巻のパフォーマンスだったんだよ。"

    # say L2252 bil
    old "Keep talking, Sparkle Twins."
    new "話しっぱなし、スパークル・ツインズ。"

    # say L2253 sha
    old "Cute. Very cute. The underdogs always have that fighting spirit."
    new "かわいいね。本当にかわいい。弱者の立場の人たちは、いつもその闘志を忘れないよね。"

    # say L2254 rya
    old "Good luck in there, sweethearts. Try not to faint from all the pressure."
    new "頑張ってね、甘い子たち。でも、プレッシャーで気絶しないようにね。"

    # say L2255 sha
    old "Ta-ta, lovebirds! The stage belongs to the stars... not the scared little duo."
    new "さよなら、ラブラブちゃんたち！　舞台はスターのもの……怖がってる二人組じゃないよ。"

    # say L2263 bil
    old "Ughh... I hate those two so much."
    new "うっ... あの二人、本当にうざい。"

    # say L2264 pla
    old "They really know how to get under your skin..."
    new "本当にイラっとくるよな…"

    # say L2265 bil
    old "Good. Let’s use that anger. Time to show Bey what we can really do."
    new "よし、その怒りを使って。今こそベイに私たちの本当の力を見せてやろう。"

    # say L2274 bey
    old "There you are already! Early today, I wasn’t expecting you two so soon."
    new "もう来てるのか！今日早いな、こんなに早く来るとは思ってなかったよ。"

    # say L2275 bil
    old "This time we didn't wanna show up late like last session."
    new "今回は遅刻したくなくて早めに来たのさ。"

    # say L2276 pla
    old "Yeah, sorry if we’re a little early this time."
    new "まあ、ちょっと早かったかもしれないな。ごめん。"

    # say L2277 bey
    old "That’s a good problem to have. Gives us extra time to really dig in."
    new "それは良い問題だな。余分な時間ができて、本気で楽しめそうだな。"

    # say L2278 bey
    old "So, this is our last tutoring session before the contest."
    new "じゃあ、これはコンテスト前の最後の勉強会だね。"

    # say L2279 bey
    old "How are you both feeling?"
    new "二人とも、どんな感じ？"

    # say L2280 bil
    old "Ready."
    new "準備できてる。"

    # say L2281 pla
    old "Nervous... but ready."
    new "緊張してる... けど準備はできてる。"

    # say L2282 bey
    old "That’s exactly how you should feel."
    new "その通り感じてるべきだ。"

    # say L2283 bey
    old "Alright, let’s do this like before."
    new "よし、前と同じようにやろう。"

    # say L2284 bey
    old "Perform as if you were already on stage at the contest."
    new "ステージに立っているかのように本番モードでいこう。"

    # say L2286 pla
    old "Alright... let’s go."
    new "よし……行こう。"

    # say L2319 bey
    old "Wow."
    new "おわっすげえ…"

    # say L2320 bil
    old "Is that a good ‘wow’ or...?"
    new "その「わー」はいい意味の「わー」なのか、それとも…？"

    # say L2321 bey
    old "Oh honey, it’s a ‘hell yes’ wow!"
    new "お前、これは「絶対イエス」のわおだよ！"

    # say L2322 bey
    old "This is night and day from your audition. Completely different level."
    new "オーディションの時とは全然違うな。全く別のレベルだ。"

    # say L2323 bey
    old "[pla], look at you!"
    new "[pla]、お前を見ろ！"

    # say L2324 pla
    old "Me?"
    new "俺？"

    # say L2325 bey
    old "From that quiet little tree in the audition to actually carrying the whole song with her!"
    new "あの静かな木から、今や曲を支えきっているんだ！"

    # say L2326 bey
    old "Your chords are locking in perfectly now, your rhythm is steady, and you’re breathing with Billie like you were born to do this."
    new "今やコードが完璧に決まり、リズムも安定して、ビリーと息を合わせているみたいだな。生まれたときからやってるかと思ったよ。"

    # say L2327 bey
    old "You’re not just following anymore... you’re complementing her. You’re making her voice shine even brighter."
    new "もうただついていくだけじゃなくて……彼女の声をより輝かせるように補完してるんだ。"

    # say L2328 pla
    old "For real? That actually worked?"
    new "マジで？それ Actually worked？ の部分を修正する必要があるね。"

    # say L2329 bey
    old "Yes! You two are finally sounding like a real duo."
    new "はい！お前らついに本物のデュオみたいになったな。"

    # say L2330 bey
    old "And Billie... that breath control? Chef’s kiss."
    new "そしてビリー……その息遣い？シェフのキスだな。"

    # say L2332 bey
    old "Absolutely. Way more power behind those soft notes. You’re letting that voice breathe."
    new "絶対だな。ソフトなノートにもっと力が乗ってる。声を自由に使ってんだ。"

    # say L2333 bey
    old "Your breath support is stronger, and you’re keeping your tone stable even in longer phrases."
    new "君の息遣いが強くなって、長いフレーズでも声を安定させられるようになったね。"

    # say L2334 bey
    old "You’re managing your diaphragm much more consciously now."
    new "君の横隔膜のコントロールがずいぶん意識的になったな。"

    # say L2335 bil
    old "That’s... really good to hear."
    new "それが…本当にうれしい。"

    # say L2336 bey
    old "You both sound like a team now."
    new "二人で一つのチームみたいだね。"

    # say L2337 bey
    old "Not just two people doing their own thing, but one performance."
    new "二人でそれぞれやってるんじゃなくて、一つのパフォーマンスだね。"

    # say L2338 bil
    old "That’s what we were aiming for."
    new "それが目指していたことだね。"

    # say L2340 bey
    old "Well, I think you’re ready for the contest."
    new "まあ、君はコンテストに出る準備ができてると思うよ。"

    # say L2341 bil
    old "You mean... really ready?"
    new "本当に…準備できてるの？"

    # say L2342 bey
    old "Yes. You should keep practicing, of course."
    new "もちろん、君はもう準備できてるよ。でも練習は続けて、"

    # say L2343 bey
    old "But now it’s about polishing, not fixing big problems."
    new "でも今は磨き上げる段階だよ、大きな問題を直すわけじゃないから。"

    # say L2344 bey
    old "Also... don’t forget to rest."
    new "それに……休むことも忘れずにね。"

    # say L2345 bey
    old "Overworking right before a performance can be just as bad as not practicing."
    new "パフォーマンス直前に過労するのは、練習しないのと同じくらい悪いんだ。"

    # say L2347 pla
    old "We’ll be careful."
    new "気をつけるよ。"

    # say L2348 bey
    old "And one more thing."
    new "あと一つ、言っておくことあるんだ。"

    # say L2349 bey
    old "Start thinking about your stage look."
    new "ステージでの見た目から考え始めてみろ。"

    # say L2350 bil
    old "O- Our look?"
    new "ええ、私たちの見た目について？"

    # say L2351 bey
    old "Clothes, style, how you present yourselves."
    new "服やスタイル、自分たちをどう見せるかだよ。"

    # say L2352 bey
    old "Your music has a mood. Your image should match it."
    new "音楽には雰囲気があるんだ、そのイメージに合わせてほしいんだよ。"

    # say L2353 pla
    old "Oh, That actually sounds fun."
    new "なるほど、それって意外と面白そうだな。"

    # say L2355 bey
    old "I’ll be cheering for you both."
    new "二人とも応援してるよ。"

    # say L2356 bil
    old "Thank you. For everything."
    new "ありがとう。すべて本当に感謝してる。"

    # say L2357 pla
    old "Yeah, thank you."
    new "うん、ありがとう。"

    # say L2379 bil
    old "Well... that timing was just perfect."
    new "まあ……そのタイミングはぴったりだったわね。"

    # say L2380 pla
    old "Yeah, that rain came out of nowhere."
    new "そうだな、その雨は突然降り出したな。"

    # say L2381 bil
    old "Tell me about it."
    new "そうよね、そのとおりよ。"

    # say L2382 bil
    old "Anyway, go dry off in the bathroom, towel's there."
    new "まあ、 Bathroom で乾いて。タオルは那儿にあるから。"

    # say L2383 bil
    old "I'm heading to my bedroom to change."
    new "私は寝室に行って着替えるわ。"

    # say L2385 bil
    old "Try not to flood the place."
    new "場所を水浸しにしないでね。"

    # say L2386 pla
    old "No promises."
    new "約束はできないな。"

    # say L2396 pla
    old "Hey [bil], sorry, I kinda flooded the bathroom floor while drying off-"
    new "Hey [bil]、ごめん、ちょっと浴室の床を水浸しにしてしまったよ"

    # say L2399 bil
    old "Hey, eyes up here, perv."
    new "Hey、目を上に向けろ、変態。"

    # say L2402 bil
    old "Heh, what? Rain made them look that good?"
    new "へへ、何？雨でそんなに良く見えたの？"

    # say L2403 pla
    old "Uhhh, well, I- I can literally see your nipples through the shirt..."
    new "うーん、あの、君の乳首がシャツを通して見えちゃってるんだけど…"

    # say L2404 bil
    old "Haha, you’re practically drooling already... you're such a mess"
    new "へへ、もうよだれが出そうじゃないの… 本当に困ったやつね"

    # say L2406 bil
    old "Heh, wanna get a better view?"
    new "へへ、もっとよく見てみる？"

    # say L2407 pla
    old "I— I- I- Uhhh... y- yea-"
    new "俺—— うっ、うーん…… ん、ん、そうか……"

    # say L2412 bil
    old "There. Way better without anything in the way, right?"
    new "ほら、何も邪魔がない方が全然いいよね？"

    # say L2413 pla
    old "Holy shit, [bil]..."
    new "Holy shit、[bil]..."

    # say L2415 bil
    old "Heh, oh my gosh... look at you."
    new "へへ、おおっ... あなたを見て。"

    # say L2416 bil
    old "Someone got rock hard just from staring at my tits."
    new "誰かが私の胸を見ただけでこんなに硬くなったんだね。"

    # say L2417 pla
    old "S- Sorry, I can't help it..."
    new "す、すみません、我慢できなくて..."

    # say L2420 bil
    old "Obviously. I love how easily I can turn a perv like you into a complete mess."
    new "私が見ただけでそんなに興奮しちゃうなんて、本当に簡単だわ。"

    # say L2427 bil
    old "You know... good boys who practice as hard as you do deserve something special."
    new "あなたがこんなに一生懸命練習してるんだから、特別なご褒美をあげたいよね。"

    # say L2434 bil
    old "And you’ve been such a good boy lately..."
    new "最近、ずいぶん良い子だったね…"

    # say L2435 pla
    old "Uhh..."
    new "うっ…"

    # say L2441 bil
    old "Yeah, so I think you’ve earned yourself a little prize."
    new "うん、だから君にはちょっとしたご褒美をあげるわ。"

    # say L2448 bil
    old "Mmm... feel that? Every single inch sliding in..."
    new "んん… 感じてる？ 一寸ずつ全部が入っていくの…"

    # say L2449 pla
    old "God... you’re so fucking tight..."
    new "神… お前は本当にきつくて…"

    # say L2450 bil
    old "Slow... nice and deep. Let me take control."
    new "ゆっくり……深くして。コントロールは任せて。"

    # say L2459 pla
    old "({i}That was... intense. Too intense.{/i})"
    new "({i}それが... 強烈だった。強烈すぎた。{/i})"

    # say L2460 bil
    old "You okay? You look like I just broke your brain."
    new "大丈夫？　顔がクラッシュしたみたいだよ。"

    # say L2461 pla
    old "I... yeah. I’m good. Just... damn."
    new "俺…ああ、大丈夫。ただ…クソだな。"

    # say L2462 bil
    old "Heh. 'Damn' is right. We both really needed that, didn’t we?"
    new "へへ。『damn』だね。二人とも本当に必要だったよね。"

    # say L2463 pla
    old "Yeah... I think we did."
    new "ああ… そう思うな。"

    # say L2465 pla
    old "But... it felt different this time..."
    new "でも... 今回は違う感じがしたんだ..."

    # say L2467 pla
    old "I mean, when we were looking at each other... I could see it in your eyes. You were feeling it too."
    new "俺も見てたよ、お互いいちめんに。君も感じてたよね。"

    # say L2468 bil
    old "Uhh.. D- Don’t get all sappy on me now..."
    new "うっ、*D* そんな甘いこと言わないでよ…"

    # say L2470 bil
    old "Listen, it was just blowing off steam, okay? Don't start reading too much into it."
    new "ねぇ、ただストレス発散だったのよ、分かってよ？深読みしないで。"

    # say L2471 pla
    old "I guess, you're right, still... it felt really good."
    new "うん、君の言う通りだよ、でも… 確かめりゃ気持ちよかったな。"

    # say L2472 bil
    old "Heh. Yeah... you weren’t half bad yourself."
    new "へへ、そういえば… お前も悪くなかったな。"

    # say L2473 bil
    old "Doesn’t mean I’m going soft on you though."
    new "それは私があなつに甘くなるって意味じゃないけどね。"

    # say L2474 bil
    old "The contest is in a few days. We can’t afford to get distracted."
    new "コンテストまであと数日だよ。気を散らされてる暇はないわ。"

    # say L2475 pla
    old "Right... back to serious practice."
    new "分かってる…真剣な練習に戻すか。"

    # say L2476 bil
    old "Exactly. Guitar for you, vocals for me. No slacking."
    new "そうだよ。ギターはあなた、ボーカルは私。甘えてるんじゃないよ。"

    # say L2479 bil
    old "But... if you need a little extra 'motivation' again... I guess I can make time."
    new "でも…もしまたちょっとした『モチベーション』が必要になったら…時間は作れるわ。"

    # say L2480 pla
    old "I’ll take that."
    new "受け取るぜ。"

    # say L2481 bil
    old "Don’t get cocky. Next time I might make you work even harder for it."
    new "自慢しないでね。次はもっと頑張らせるかもしれないから。"

    # say L2482 pla
    old "Bring it."
    new "Bring it. → 来てみろ。"

    # say L2484 bil
    old "Now seriously, we need to clean up before my grandma walks in and smells sex and rain in my room."
    new "本気で掃除しないとダメよ。ばあちゃんが入ってきて、私の部屋でセックスと雨の匂いを嗅ぐわ。"

    # say L2485 pla
    old "Yeah... I’m moving."
    new "そうだな…移動するか。"

    # say L2486 bil
    old "And [pla]?"
    new "そして [pla]？"

    # say L2488 bil
    old "Uhh, nevermind... Just keep practicing like your life depends on it. I expect results."
    new "うーん、いいや… 命懸けで練習しろ。結果を見せてほしいからね。"

    # say L2489 pla
    old "I will. Promise."
    new "約束するよ。"

    # say L2509 pla
    old "Yeah, you said you needed me for something. But... we've been practicing a lot lately, right?"
    new "うん、君が何か俺が必要だって言ったけど……最近、けっこう練習してんだろ？"

    # say L2510 bil
    old "Heh, yeah. But no, I don't need you for that today."
    new "へへ、そうだけど、今日は何もなくて。他に用事があるの。"

    # say L2511 pla
    old "Wait, seriously? Not practice?"
    new "まじか？ 練習じゃないの？"

    # say L2512 bil
    old "Nope. Today I need you for something else."
    new "ううん、今日はそれじゃないの。他の用事があるの。"

    # say L2514 bil
    old "I want to go buy some clothes. For the contest."
    new "服を買いに行きたいの。コンテスト用に。"

    # say L2515 pla
    old "Clothes? Like... an outfit?"
    new "服？つまり…一式の服？"

    # say L2516 bil
    old "Exactly. I don't want to show up in my usual stuff."
    new "そうよ。普段着じゃ恥ずかしいわ。"

    # say L2517 bil
    old "Those other idiots are probably gonna be all glitter and sequins. I don't wanna look like I didn't even try."
    new "他のバカたちったら、多分キラキラとパチパチの格好だろうね。私は全然準備してこなかったみたいには見られたくないんだ。"

    # say L2518 pla
    old "Okay, that makes sense. Let's go then. I'll help you pick."
    new "分かった、それならいいな。行こうぜ。手伝うから。"

    # say L2519 bil
    old "Good. I already have a few ideas. Come on."
    new "良いわ。すでにいくつかアイデアがあるのさ。来いよ。"

    # say L2525 bil
    old "Alright, there's this store I saw online. Not really my usual vibe, but they might have something that works for the stage."
    new "あのオンラインの店があるの。普段の私とはちょっと違うけど、ステージ用には何かいいものがあるかもしれないから。"

    # say L2526 pla
    old "What exactly are you thinking?"
    new "何考えてるんだ？"

    # say L2527 bil
    old "Honestly? I don't know yet. I wanna look around, try a bunch of stuff, and see what feels right. Let's just go in."
    new "正直？まだわからないけど、見て回って、色々試して、しっくりくるものを見つけてみたいの。行こうよ。"

    # say L2544 bil
    old "Hi. I'm performing in a music contest in a few days and I need an outfit that fits the stage."
    new "こんにちは。数日後に音楽コンテストでパフォーマンスするんだけど、ステージに合う衣装が必要なの。"

    # say L2546 bil
    old "Hello?"
    new "こんにちは？"

    # say L2547 lan
    old "Huh? Oh. Yeah, everything's for sale. Just browse and bring whatever you want to the counter when you're ready."
    new "へ？あ、うん、全部売ってるよ。見たいものがあったらレジに持って来い。"

    # say L2549 pla
    old "({i}Wow, helpful.{/i})"
    new "{i}なるほど、親切だね。{/i}"

    # say L2550 bil
    old "Uh... okay?"
    new "うーん… まあいいわ。"

    # say L2556 bil
    old "Hmm, whatever. Let's just look around."
    new "Hmm、まあいいや。周りを見てみましょう。"

    # say L2557 pla
    old "Yeah. What are you searching for exactly?"
    new "そうだな。具体的に何を探してるんだ？"

    # say L2558 bil
    old "I'm not totally sure yet. I'll grab a few things, try them on, and you tell me what you think. Deal?"
    new "まだはっきりとは決めてないの。いくつか持って来て、試着してみて、あなたの意見を聞こうと思って。どう？"

    # say L2559 pla
    old "Deal. I'll be honest."
    new "約束だ。本音を言うよ。"

    # say L2560 bil
    old "You better be."
    new "ちゃんとしてね。"

    # say L2566 pla
    old "Ready?"
    new "準備OK？"

    # say L2568 bil
    old "Yeah. I grabbed a few options... even some wigs. Didn't expect that here."
    new "うん。いくつか持ってってきたよ…ウィッグもね。ここであんなものがあるとは思わなかった。"

    # say L2569 pla
    old "Wigs? For the contest?"
    new "ウィッグ？コンテストのために？"

    # say L2570 bil
    old "I'm trying to switch up my whole look a bit. Not going full Sparkle Queen like the others, but... something different."
    new "ちょっとイメージチェンジしようと思って。スパークルクイーンみたいにはならないけど、何か違うものにしたいな。"

    # say L2579 bil
    old "Okay, first one coming out."
    new "まずは一つ目が出すね。"

    # say L2587 bil
    old "Okay... I was thinking something like what those empty headed girls would wear. Bright, short, cute. What do you think?"
    new "じゃあ……あの空っぽな女の子たちが着るようなもので、明るくて短くて可愛いの。どう思う？"

    # menu L2591 
    old "Use Agamoto's eye"
    new "アガモトの目を使う"

    # say L2595 pla
    old "Uhh... Y- you look really good actually. The color pops and the skirt is beautiful... wait, and that hair? It's completely black now."
    new "うっ、実際によく似合ってるな。色がよく映えて、スカートも美しい……って、髪の毛は？完全に黒くなってるじゃん。"

    # say L2605 bil
    old "It's a wig, obviously."
    new "もちろん、これはウィッグよ。"

    # say L2606 bil
    old "My green hair would clash horribly with this pink. It'd look ridiculous, so I grabbed a black one to match the outfit."
    new "緑の髪だとこのピンクと全然合わなくて、バカみたいになっちゃうから、黒のウィッグを選んだの。"

    # say L2607 bil
    old "Uhh... So? What do you think overall? Do you like it?"
    new "うーん…どう思う？全体的に気に入ったと思う？"

    # say L2608 pla
    old "Totally. It screams 'stage presence'."
    new "これならステージで存在感が出るね。"

    # say L2609 bil
    old "But... it's so pink. So girly. So... not me. Ugh, too cutesy. Nope."
    new "でも……ピンク色で、女の子らしくて、全然私じゃないわ。うっ、可愛すぎ。ダメ。"

    # say L2610 pla
    old "({i}She looks killer though... but I get it.{/i})"
    new "{i}君はかっこいいけど... 分かるよ。{/i}"

    # say L2611 bil
    old "Whatever. Next one."
    new "次のをみせて。"

    # say L2624 bil
    old "Ok, now this one... more elegant, kinda bohemian, long flowy thing. Thoughts?"
    new "Ok、今のは……もっとエレガントで、ちょっとボヘミアンな感じの、長いフローリーなもの。どう思う？"

    # say L2625 pla
    old "({i}Wow... she looks absolutely stunning. The long dress and blonde hair completely transform her vibe.{/i})"
    new "{i}Wow... びりー、君は絶対に Stunning だな。その長いドレスとブロンドの髪で、完全に雰囲気が変わってるよ。{/i}"

    # say L2632 pla
    old "Uhh... Damn, Billie... you look like a whole vibe. Sophisticated, mysterious... and that blonde hair? It's wild on you."
    new "うわっ… Billie… 本当に全然雰囲気変わってるな。洗練されてて神秘的だよ… それにブロンドの髪は君に似合ってるよ。wild みたいに。"

    # say L2643 bil
    old "It doesn't look much like a wig, right? I picked one that blended in pretty well."
    new "それほどウィッグには見えないよね？よく似合うものを選んだから。"

    # say L2644 pla
    old "Well, it looks a bit odd to me, but I think it's just because I know you."
    new "まあ、少し変な感じがするけど、それは君を知ってるからだと思うよ。"

    # say L2645 pla
    old "It's like seeing a completely different person, you know?"
    new "まるで別人を見ているみたいだな、分かってる？"

    # say L2646 bil
    old "A different person? Uhh, but do you think it could actually work for the contest?"
    new "違う人？うーん、でもコンテストには合うと思う？"

    # say L2647 pla
    old "I guess so. It's classy as hell. You'd definitely stand out for sure."
    new "まあ、そうかもな。めちゃくちゃ上品だし、絶対に目立つよ。"

    # say L2648 bil
    old "Hmm, I don't know... I think it's too much. Way too much, you know?"
    new "うーん、ちょっと多い感じがするな… 全然多いよ、わかる？"

    # say L2649 bil
    old "I feel like I'm playing dress up as some celebrity. This isn't me at all."
    new "この格好だと有名人の cosplay みたいな気分で、全然私じゃないよ。"

    # say L2650 bil
    old "Ughh, and no more wigs after this. They're boiling hot and I feel super fake wearing them."
    new "うげっ、これで最後にウィッグは卒業だよ。頭が熱くて、偽物みたいで気持ち悪いんだもん。"

    # say L2651 bil
    old "Alright, moving on."
    new "よし、次に進もう。"

    # say L2665 bil
    old "Okay, this one's bolder. Short skirt, tight top... figured it might grab attention. Be honest."
    new "この衣装は大胆だね。短いスカート、きついトップス……注目を引くと思って選んだの。正直な感想を教えて。"

    # say L2666 pla
    old "({i}Holy fuck... her ass is completely exposed. That skirt is barely covering anything...{/i})"
    new "({i} Holy fuck... そのスカート、ほとんど何も隠してないじゃねえか... {/i})"

    # say L2690 pla
    old "({i}Shit... no, not now! Why the hell am I getting hard right here in the middle of the store? This is so bad...{/i})"
    new "（{i}クソ… 今じゃない、今じゃない！なぜこんな場所で硬くなっちまうんだ？マジで最悪だな…{/i}）"

    # say L2691 bil
    old "So? What do you think?"
    new "じゃあ？どう思うの？"

    # say L2692 pla
    old "I- I... Uhh... That's... This one is really nic- ass..."
    new "うっ、うーん… これが… 本当は良いって思ってるんだけど…"

    # say L2695 bil
    old "Ohhh, look at that. Someone really liked what he saw."
    new "オーッ、それを見てるうちに誰かがかなり気に入ったみたいね。"

    # say L2696 bil
    old "You're already rock hard just from staring at my ass. How cute."
    new "もう硬くなっちゃってるのね、私のお尻見て。かわいいわ。"

    # say L2697 pla
    old "I- I can't help it... you look way too good like that."
    new "俺、しょうがないんだ…君はその格好で本当にsexyすぎるからさ。"

    # say L2698 bil
    old "Mmm, really? Then don't just look."
    new "うん、そう？じゃあ、ただ見ているだけじゃなくて、もっとしてみて。"

    # say L2704 bil
    old "So, you really liked this outfit, huh? Why could that be?"
    new "そう、この格好気に入ったのね？どうしてだろう？"

    # say L2705 bil
    old "Do you like how your cock looks between my cheeks?"
    new "あなたのちんこが私の股の間から見えるのが好き？"

    # say L2707 bil
    old "Pull it out. I want to feel that warm big cock against my skin."
    new "出すの。その温かい大きなちんこを肌に感じたいの。"

    # say L2708 pla
    old "W- wait! Billie! We're in a fitting room... someone could walk in any second!"
    new "待て、ビルリー！フィッティングルームだぞ……誰かが入ってくるかもしれないよ！"

    # say L2709 bil
    old "Relax, dummy. That stupid salesgirl is still glued to her phone. No one's coming this way. We're basically alone."
    new "リラックスしなさい、バカ。あのバカな店員はまだスマホに夢中よ。誰も来ないわ。ほとんど二人きりだわ。"

    # say L2710 bil
    old "Now take your cock out... or should I do it for you?"
    new "今、チンコ出しなさい... それとも私がやる？"

    # say L2714 bil
    old "Mmm... it feels warm... and so hard."
    new "んん… 温かい… そして硬い…"

    # say L2716 bil
    old "That's what makes it fun."
    new "それが楽しいんだよ。"

    # say L2730 bil
    old "It's nice you like it so much..."
    new "好きでくれて嬉しいわね…"

    # say L2732 bil
    old "Besides, this feels way too slutty for the stage. Like I'm selling my ass instead of my voice. Hard pass."
    new "それに、これじゃあ舞台に立つのが恥ずかしいな。まるで自分の身体を売ってるみたいで、声を売るつもりはないのに。絶対に無理。"

    # say L2733 pla
    old "({i}She does look fire though... but yeah, she is right.{/i})"
    new "{i}彼女はかわいいけど…でも確かに、彼女の言う通りだな。{/i}"

    # say L2734 bil
    old "Next."
    new "次。"

    # say L2748 bil
    old "Last one. Casual but edgy. Urban, not too flashy. What do you say?"
    new "最後の一枚。カジュアルだけど尖ってる。都会的で、派手すぎないね。どう思う？"

    # say L2749 pla
    old "({i}Fuck... even in this one she looks incredible. Those tits in that blue bra...{/i})"
    new "({i}くそ……この写真でもめちゃくちゃsexyだな。青いブラジャーにその爆乳……{/i})"

    # say L2773 pla
    old "({i}Nooo... not again! I just came all over her ass two minutes ago... What the hell is wrong with me?!{/i})"
    new "({i}ノォ… またか！ たった今、彼女の尻に全部出しちゃったのに… 俺、一体どうしたんだよ！{/i})"

    # say L2775 pla
    old "Uhh... yeah, this one is nice too..."
    new "うーん… そうかも、これも良いな…"

    # say L2776 bil
    old "What? Just that? Wait a second..."
    new "何？それだけ？ちょっと待って…"

    # say L2777 bil
    old "Are you serious right now?! You just blew a huge load on my ass and you're already rock hard again? Just from seeing me squeeze my tits?"
    new "本気で言ってるの？！ お尻に大量に出したのに、また全然硬くなってるの？ ただ私の胸を絞ってるのを見て？"

    # say L2778 bil
    old "Damn... these really drive you crazy, huh?"
    new "ダメ… これだけで本当にこんなに興奮しちゃうの？"

    # say L2780 bil
    old "Mmm, greedy boy... still got more for me? Let me milk you dry."
    new "ん、欲張りな子ね…まだ私にくれるの？ さあ、全部搾っちゃおう。"

    # say L2781 bil
    old "Come here. Let me take care of that with my tits."
    new "ここに来なさい。私の胸で直してあげる。"

    # say L2796 bil
    old "Alright, this one isn't right either."
    new "じゃあ、これも駄目なのかしら。"

    # say L2797 pla
    old "What? W-why?"
    new "何？　なぜ？"

    # say L2798 bil
    old "Judging by the way you just got hard again... it doesn't make much difference from the last one."
    new "あなたがまた硬くなった様子を見ると… 前のやつとそんなに変わらないみたいね。"

    # say L2799 pla
    old "Yeah... I guess you're right."
    new "うん…君の言う通りだね。"

    # say L2800 bil
    old "Hmm, whatever... I'm just gonna change back."
    new "うーん、まあいいわ…元に戻すわ。"

    # say L2801 pla
    old "({i}I thought this would be easier...{/i})"
    new "{i}これって簡単だと思ったけどな…{/i}"

    # say L2809 bil
    old "Alright, let's go."
    new "じゃあ、行こう。"

    # say L2815 pla
    old "W- What? so, none of them? You didn't like any?"
    new "W- 何？全然ダメだったのか？一つも気に入らなかったのか？"

    # say L2816 bil
    old "No. None of them feel right. All that color, glitter, fake glamour..."
    new "ダメよ。どれもしっくりこないの。そんな色鮮やかで、キラキラした偽りの華やかさ..."

    # say L2817 bil
    old "It's not me. I don't want to pretend to be someone I'm not just to compete with those idiots."
    new "私には似合わないわ。あんな偽りの華やかさで、あいつらと競争するなんて、本物の私じゃなくなっちゃうから。"

    # say L2818 pla
    old "({i}She's got a point. That's what makes her special.{/i})"
    new "{i}彼女の言う通りだ。それが彼女を特別にするんだ。{/i}"

    # say L2819 pla
    old "Okay, fair enough. So... sticking with your usual look for the contest?"
    new "分かってる、それも一理あるな。じゃあ……コンテストでは普段のままいくつもりなのか？"

    # say L2820 bil
    old "For now, yeah. I'll keep thinking, but I'm not forcing something that doesn't feel like me. Thanks for coming with me though. Seriously."
    new "今のところね。考えは続けるけど、自分らしくないものは無理にしないつもり。でも、 acompañadesが来てくれたありがとう。本気だよ。"

    # say L2821 pla
    old "Anytime. I had fun watching you rock every single one, even if you hated them."
    new "いつでも。君がどの服も似合ってたのを見てて楽しかったから、好きじゃなかったって言ってもね。"

    # say L2822 bil
    old "Heh. Flatterer. Come on, let's get out of here before I change my mind and buy the whole store."
    new "へへ、お世辞だね。さあ行こうよ、ここにいるのが飽きちゃう前に、気分が変わって全部買っちゃう前に。"

    # say L2842 bil
    old "You made it."
    new "できたね。"

    # say L2843 pla
    old "Of course. You texted 'last practice' like it was serious."
    new "もちろんさ。君は「最後の練習」って本気で書いてきたんだな。"

    # say L2845 pla
    old "Uh... You okay?"
    new "うーん…大丈夫？"

    # say L2846 bil
    old "Yeah, don't worry. Come in."
    new "大丈夫、心配しなくていい。入って。"

    # say L2852 bil
    old "Tomorrow’s the contest."
    new "明日がコンテストだね。"

    # say L2853 pla
    old "Yeah... kinda crazy, huh?"
    new "そうだな…ちょっと信じられないよな。"

    # say L2854 bil
    old "I never thought I’d stand on a stage again."
    new "舞台に立つなんて、思いもしなかった。"

    # say L2855 pla
    old "'Again'?"
    new "「また」？"

    # say L2856 bil
    old "I mean... after everything."
    new "あのさ… すべてが終わった後のことだよ。"

    # say L2857 pla
    old "But you’re here."
    new "でも君はここにいるんだ。"

    # say L2858 bil
    old "Yeah. And that scares me more than the stage."
    new "うん。でもそれよりもステージの前で緊張してる方がまだマシだよ。"

    # say L2860 bil
    old "Because the stage can’t leave."
    new "ステージは去れないけど、私がここにいることが怖いの。"

    # say L2861 pla
    old "You don’t have to carry everything alone, you know."
    new "君ひとりで全部背負う必要ないんだよ。"

    # say L2863 bil
    old "Let’s run it once. Soft. No pressure."
    new "一度やってみよう。ソフトに。プレッシャーはかけないね。"

    # say L2903 pla
    old "That felt different."
    new "その感じだったな。"

    # say L2904 bil
    old "It always does..."
    new "いつもそうよね..."

    # say L2907 bil
    old "Do you know why I really stopped singing?"
    new "本当の理由を教えてあげる？"

    # say L2908 pla
    old "Uhh, your grandma told me some of it."
    new "うーん、お婆ちゃんが少し教えてくれたな。"

    # say L2909 bil
    old "She tells the gentle version."
    new "優しいバージョンを教えてあげたの。"

    # say L2910 pla
    old "What’s the real one?"
    new "本当の話聞かせてくれよ。"

    # say L2911 bil
    old "When they died... everyone said 'be strong’."
    new "彼らが死んだとき……みんな「強くあれ」と言ったの。"

    # say L2912 bil
    old "So I was."
    new "だからそうしたの。"

    # say L2913 bil
    old "I stopped crying. Stopped singing. Stopped needing."
    new "泣き止めたわ。歌うのを止めた。必要を感じなくなった。"

    # say L2914 pla
    old "That’s not strength."
    new "それは強さじゃないよ。"

    # say L2915 bil
    old "Well, it felt like survival."
    new "まあ、そう感じたわ。"

    # say L2916 bil
    old "Every song sounded like them."
    new "毎曲が彼らのようだった。"

    # say L2917 bil
    old "Every note felt like losing them again."
    new "毎音がまた彼らを失ったような感じがした。"

    # say L2918 pla
    old "So you buried it."
    new "じゃあ、君はそれを埋めたのか。"

    # say L2919 bil
    old "Yeah. And I buried part of me with it."
    new "うん。そして、そのと一緒に私自身の一部分も埋めてしまった。"

    # say L2921 bil
    old "But then you showed up. Loud. Stubborn. Impossible."
    new "でもその後にあなたが現れた。大きな声で、頑固で、手に負えない存在として。"

    # say L2922 pla
    old "I guess I have a talent for that."
    new "俺にもそんな才能があるらしいな。"

    # say L2923 bil
    old "You dragged me back to something I was scared to touch."
    new "あなたが私を、怖くて触れられなかったものに引き戻してくれた。"

    # say L2924 bil
    old "And now I’m scared of losing it again."
    new "今度はそれをまた失うのが怖いわ。"

    # say L2926 pla
    old "You won’t."
    new "俺が守るから大丈夫だよ。"

    # say L2927 bil
    old "You don’t know that."
    new "君がそう思うとは限らないよ。"

    # say L2928 pla
    old "I know I’ll be with you."
    new "俺は君と一緒にいられるって知ってるよ。"

    # say L2929 bil
    old "You promise too easily."
    new "約束しすぎだよ。"

    # say L2930 pla
    old "I don’t make promises I can’t keep."
    new "約束は守れないものを轻易にしないよ。"

    # say L2931 bil
    old "I don’t want to be alone tomorrow, [pla]."
    new "明日ひとりになりたくない、[pla]。"

    # say L2932 pla
    old "You won’t be."
    new "君は一人にならないよ。"

    # say L2933 bil
    old "I mean... really alone."
    new "つまり... 絶対に一人ってこと。"

    # say L2937 pla
    old "Then don’t be."
    new "じゃなきゃ、比利。"

    # say L2938 bil
    old "You don’t run when things get heavy?"
    new "重たくなったら逃げるの？"

    # say L2939 pla
    old "I would never leave you."
    new "俺は絶対に君を置いていかないよ。"

    # say L2941 bil
    old "What if I break on stage?"
    new "ステージで崩れちゃったらどうするの？"

    # say L2942 pla
    old "Then I’ll be right there, with you."
    new "じゃあ、俺が君の隣にいるよ。"

    # say L2943 bil
    old "What if I fail?"
    new "もし失敗しちゃったらどうしよう。"

    # say L2944 pla
    old "Then you still tried. And that already makes you brave."
    new "それでも君は挑戦した。それだけで君は勇敢だ。"

    # say L2945 bil
    old "I don’t want to have to hide anymore."
    new "もう隠れ続けるのは嫌だな。"

    # say L2946 pla
    old "Then don’t."
    new "隠すな、比利。"

    # say L2947 bil
    old "I don’t know how to do this..."
    new "わからないわ..."

    # say L2948 pla
    old "Don’t. Just be real."
    new "しないで。素直に言えばいい。"

    # say L2950 bil
    old "If this goes wrong tomorrow..."
    new "もし明日うまくいかなかったら…"

    # say L2951 pla
    old "It won’t erase everything we’ve done."
    new "明日うまくいかなくても、今までやってきたことは消えないよ。"

    # say L2952 bil
    old "You’re not scared of me falling apart?"
    new "あなたは私が崩れることを怖がってるの？"

    # say L2953 pla
    old "I’m scared of you thinking you have to."
    new "君がそう思ってるのが怖いんだよ。"

    # say L2960 bil
    old "I don’t know what this is..."
    new "この状況が何なのかわからないけど…"

    # say L2961 pla
    old "Neither do I. But I know it’s real."
    new "俺も知らない。でも、これが本物だってことはわかる。"

    # say L2967 bil
    old "That... wasn’t in the plan."
    new "その… 計画にはなかったよね。"

    # say L2968 pla
    old "Neither was any of this."
    new "これも計画外だったさ。"

    # say L2969 bil
    old "I don’t want this to be a mistake."
    new "これがあやまちになるのは嫌だな。"

    # say L2970 pla
    old "Then let it be a choice."
    new "じゃあ、選択しよう。"

    # say L2971 bil
    old "I think I want you... right now..."
    new "今あなたが欲しくなったの..."

    # say L2986 pla
    old "Hey... whatever happens tomorrow..."
    new "Hey... 明日はどうなってもね。"

    # say L2987 pla
    old "I'm really glad you decided to do this. And I’m really proud of you."
    new "本当に決めてくれて嬉しいよ。君のことを誇りに思う。"

    # say L2989 bil
    old "Don’t make me all soft right now."
    new "今そんなに優しくされたら困るよ。"

    # say L2990 bil
    old "But... thank you. For pushing me. For being here tonight."
    new "でも... ありがとう。背中を押してくれて。今夜ここにいてくれて。"

    # say L2991 pla
    old "I’ll be right there with you on that stage."
    new "そのステージで君と一緒にいさせてもらうよ。"

    # say L2992 bil
    old "You better not run away when I get nervous."
    new "緊張したとき逃げ出さないでね。"

    # say L2994 pla
    old "Goodnight, Billie."
    new "おやすみ、ビリー。"

    # say L2997 bil
    old "Goodnight... and [pla]?"
    new "おやすみ…そして[pla]？"

    # say L2999 pla
    old "Hmm?"
    new "Hmm？"

    # say L3000 bil
    old "Wait... I almost forgot something."
    new "待って…何か忘れてた。"

    # say L3005 bil
    old "Give me a second. Don’t move."
    new "ちょっと待って。動かないで。"

    # say L3012 bil
    old "Here. I have something for you."
    new "これ。あなたにあげるの。"

    # say L3015 pla
    old "A jacket?"
    new "ジャケット？"

    # say L3017 bil
    old "It’s my dad’s old one."
    new "これは私の父の古いものよ。"

    # say L3018 pla
    old "Billie... I can’t take this."
    new "ビリー… 俺には受け取れないよ。"

    # say L3019 bil
    old "Yes, you can. And you will."
    new "できるわ。絶対に着てね。"

    # say L3020 bil
    old "No one else deserves to wear it more than you."
    new "あなたが着るにふさわしい人なんて、他にはいないよ。"

    # say L3021 bil
    old "Besides, I can’t let you show up to the contest in that same old t-shirt and those ridiculous pink shorts again."
    new "それに、君がその古びたTシャツと馬鹿みたいにピンクのショーツでコンテストに現れるわけにはいかないよ。"

    # say L3022 pla
    old "Hah... fair point."
    new "ハハ... なるほどな。"

    # say L3024 bil
    old "I’m serious. I want you to have it."
    new "本気だよ。君に着てほしいんだ。"

    # say L3025 bil
    old "It feels right... you wearing it. It meant a lot to me."
    new "着てくれるのが嬉しいの... 私にとって大切な物だから。"

    # say L3027 pla
    old "Then... thank you. I’ll take good care of it."
    new "じゃあ……ありがとう。大切にするよ。"

    # say L3032 bil
    old "Mmm, looking good, handsome."
    new "うん、似合ってるね、ハンサム。"

    # say L3033 pla
    old "Heh... you really think so?"
    new "へへ…本当にそう思ってる？"

    # say L3034 bil
    old "Well, not as good as it looked on him... but damn, it still looks good on you."
    new "まあ、彼が着ていた時ほどじゃないけど…でも、本当に君には似合ってるよ。"

    # say L3036 bil
    old "Now go. Before I change my mind and drag you back to bed."
    new "さあ、行こう。私が心変わりしてまたベッドに引きずり込む前にね。"

    # say L3037 pla
    old "Whoa... you really have gotten bold tonight."
    new "誰あ、今夜は随分大胆になったな。"

    # say L3038 pla
    old "But yeah... we both need to rest. Big day tomorrow."
    new "でもな…二人とも休むべきだ。明日は大事な日だから。"

    # say L3039 bil
    old "Go home. Sleep. And be ready."
    new "家に帰って、よく寝て、明日は準備しておいて。"

    # say L3040 pla
    old "I will. See you tomorrow... on that stage."
    new "分かってる。明日のそのステージで会おう。"

    # say L3041 bil
    old "See you tomorrow."
    new "明日会おうね。"

    # say L3044 bil
    old "({i}Tomorrow changes everything... but tonight was ours.{/i})"
    new "{i}明日はすべてが変わる……でも今夜は私たちの時間だったんだよね。{/i}"

    # say L3061 pla
    old "Today’s the day..."
    new "今日がその日だね…"

    # say L3062 pla
    old "The contest. Our contest."
    new "コンテストだね。俺たちのコンテストだ。"

    # say L3063 pla
    old "I feel... ready. For the first time in a long time."
    new "俺は……準備万端だ。長い間、こんなに準備ができたって感じたことがない。"

    # say L3072 pla
    old "This jacket... it feels like she’s with me already."
    new "このジャケット……もう彼女が一緒みたいだな。"

    # say L3073 pla
    old "Alright. Let’s go win this thing."
    new "よし、行こうぜ。"

    # say L3081 pla
    old "I’m actually early for once."
    new "俺、珍しく早めに来ちゃったな。"

    # say L3082 pla
    old "Billie should be here any minute. She said she’d meet me right here."
    new "ビリーはもうすぐ来るはずだ。彼女とはここで会う約束をしたんだ。"

    # say L3083 pla
    old "We’ve practiced so much... today’s gonna be good."
    new "練習した甲斐がある…今日こそ上手くいくはずだ。"

    # say L3096 pla
    old "Okay... she’s still not here."
    new "分かってる…でもまだ来ないな。"

    # say L3097 pla
    old "Where is she? The contest is gonna start soon."
    new "どこにいるんだ？ 決勝戦が始まるぞ。"

    # say L3098 pla
    old "She’s probably just running a little late. No big deal."
    new "多分ちょっと遅れてるだけだよ。大丈夫さ。"

    # say L3111 ari
    old "Look who it is. The tree and his little jacket upgrade."
    new "見つけたぞ。木とその小物のアップグレードだな。"

    # say L3112 tay
    old "Cute jacket, [pla]. Do you think that’s enough to impress anyone?"
    new "かわいいジャケットだね、[pla]。これで誰かを驚かせられると思う？"

    # say L3113 ari
    old "Yeah, good luck trying not to be a statue again."
    new "よし、また像にならないように頑張ってね。"

    # say L3114 pla
    old "Whatever. You two just worry about your own act."
    new "お前らは自分の演技に集中しろ。"

    # say L3115 ari
    old "We’re up soon. See you losers on stage."
    new "もうすぐ私たちの番だよ。ステージで会おうね、負け組み。"

    # say L3126 pla
    old "They’re already heading in... the contest really is starting."
    new "もう向かってるみたいだな… コンテストが始まるんだ。"

    # say L3138 pla
    old "Still no sign of her..."
    new "まだ彼女の姿はないな…"

    # say L3139 pla
    old "Come on, Billie... you promised."
    new "比利、さあ……約束したんだろ。"

    # say L3140 pla
    old "Screw it. I’m gonna check if the contest already started."
    new "やーわ。コンテストが始まったかどうか確認に行く。"

    # say L3145 pla
    old "Oh no... fuck... the contest already started!"
    new "おい、しまった… コンテストすでに始まってる！"

    # say L3146 pla
    old "Fuck, fuck, fuck... Billie still hasn’t arrived."
    new "くそ、くそ、くそ… ビリーまだ来ないのか。"

    # say L3147 pla
    old "Why isn’t she here? What happened?"
    new "なぜここにいないんだ？何があったんだ？"

    # say L3155 pla
    old "Should I run to her house? But what if she shows up and doesn’t see me?"
    new "俺が彼女の家まで走るか？でも、もし彼女が来て俺がいなかったらどうする？"

    # say L3156 pla
    old "No... I have to wait here. She said she’d come. I know she’s coming."
    new "ダメだ…ここであくまで待つ gotta wait ここで待たなきゃ。彼女は来るって言ったんだ。絶対来るはずだ。"

    # say L3163 pla
    old "Billie! There you are! Finally!"
    new "ビリー！いたんだ！やっと来たね！"

    # say L3164 pla
    old "Oh wow! You look... beautiful. Really. That outfit... wow."
    new "おわ、ビリー！君は……本当に綺麗だ。その格好……すごい。"

    # say L3166 bil
    old "[pla], I... I can’t do this."
    new "[pla]、私……これ、無理だよ。"

    # say L3167 pla
    old "Hey, hey what’s wrong? Talk to me."
    new "hey、hey 何があったんだ？話してみろ。"

    # say L3168 bil
    old "My hands won’t stop shaking. I feel like I’m going to throw up."
    new "手が止まらないほど震えてる。吐きそうになっちゃう。"

    # say L3169 bil
    old "Every time I close my eyes I hear their voices... my parents. And then I remember they’re gone."
    new "毎回目を閉じると、親の声が聞こえてくるの……。そして、彼らがもういないことに気付くの。"

    # say L3170 bil
    old "What if I open my mouth and nothing comes out? What if I break in front of everyone?"
    new "もし口を開いても何も出なかったらどうしよう…？みんなの前で崩れちゃったらどうしよう…？"

    # say L3171 pla
    old "Breathe. Look at me."
    new "息を吸って、俺を見て。"

    # say L3172 bil
    old "I’m not ready. I thought I was, but I’m not."
    new "まだ準備できてない。できてると思ってたけど、そうじゃなかった。"

    # say L3173 pla
    old "Come with me. We’re going somewhere quieter."
    new "比利、一緒に来よう。もっと静かな場所に行こう。"

    # say L3185 pla
    old "Ok, just breathe with me, okay? In... and out."
    new "大丈夫、一緒に呼吸しよう、いいかい？息を吸って……そして吐いて。"

    # say L3186 bil
    old "I can’t... my chest feels tight."
    new "胸がきゅっとする……"

    # say L3187 pla
    old "You’re safe. I’m right here."
    new "大丈夫、君は安全だ。俺がここにいるんだ。"

    # say L3188 bil
    old "It doesn’t feel safe... it feels like I’m about to lose everything again."
    new "安全じゃない気分...またすべてを失うみたいだ。"

    # say L3203 bil
    old "What if I freeze on stage... what if I open my mouth and nothing comes out..."
    new "ステージで固まっちゃったらどうするの... 口を開いても何も出なかったらどうするの..."

    # say L3204 pla
    old "Billie, look at me. You’ve practiced this a thousand times."
    new "ビリー、俺を見て。君はこれだけ練習してきたんだ。"

    # say L3205 bil
    old "Practicing is not the same as standing in front of everyone..."
    new "練習とは違うのよ、みんなの前で立つってことは..."

    # say L3206 bil
    old "Every note is going to bring them back... and then they’ll disappear again..."
    new "毎音が彼らを呼び戻す……でもまた消えていく……"

    # say L3212 pla
    old "Hey... hey, come here."
    new "hey... hey、ここに来い"

    # say L3214 bil
    old "I can’t... I can’t do this..."
    new "私… 私にはできない…"

    # say L3217 pla
    old "({i}Nothing I say is working... she’s spiraling hard.{/i})"
    new "{i}君が言うこと全部効果ないみたいだな…彼女、どんどんどんどん落ちてくよな。{/i}"

    # say L3218 pla
    old "Wait! I have an idea!"
    new "待て！アイデアがある！"

    # say L3229 pla
    old "I don’t want to get your dad’s jacket dirty."
    new "お前の親父のジャケットを汚したくないんだ。"

    # say L3230 bil
    old "I don’t understand..."
    new "わ、わからない……"

    # say L3231 pla
    old "Well, I want you to take off your dress... and your underwear."
    new "じゃあ、君のドレスと下着を脱いでくれ"

    # say L3232 bil
    old "W- what...?"
    new "えっ……？"

    # say L3233 pla
    old "Well, I’m using that technique you showed me once... the one that always works."
    new "まあ、君が教えてくれたあの手を使ってるんだ… 常に効くやつさ。"

    # say L3234 pla
    old "It's called 'Plan B'"
    new "それは「プランB」って呼ばれるんだ"

    # say L3235 bil
    old "I- I am not sur-"
    new "私、ちょっと自信ないんだけど…"

    # say L3236 pla
    old "You calmed me down the same way once. Let me do the same for you."
    new "君が俺を落ち着かせてくれたことがあるだろ。今度は俺が君を落ち着かせる番だ。"

    # say L3237 bil
    old "This is insane..."
    new "これって狂ってる..."

    # say L3238 pla
    old "Come on. Take off your dress... and the underwear. Now."
    new "さあ、ドレスを脱いで……下着も。今すぐ。"

    # say L3240 pla
    old "I’m not asking twice. Come on, take it all off."
    new "俺は二度と聞かないからな。さあ、全部脱げ。"

    # say L3241 pla
    old "Sit on my face. Let me take care of you."
    new "俺の顔の上に座れ。俺がお前にcare ofするから。"

    # say L3249 bil
    old "You’re really doing this..."
    new "あなた、本当にこれするの…"

    # say L3250 bil
    old "Mmm... your tongue..."
    new "むむ... あなたの舌..."

    # say L3268 bil
    old "We’re late... but I think I can do this now."
    new "遅刻しちゃうけど、今ならこれできる気がする。"

    # say L3269 pla
    old "Then let’s go win this thing."
    new "じゃあ、この試合を勝ち取ろうぜ。"

    # say L3273 bey
    old "Last call for Billie and [pla]!"
    new "ビリーと[pla]の最終呼び出しです！"

    # say L3283 pla
    old "We’re here! We’re coming!"
    new "俺たち来たよ！来てるぞ！"

    # say L3285 pla
    old "Hey... look at me."
    new "Hey... 俺を見て。"

    # say L3286 pla
    old "You’ve got this. You’re not alone up there."
    new "大丈夫、君は一人じゃない。"

    # say L3287 pla
    old "Breathe with me, okay? In... and out."
    new "一緒に深呼吸しよう、ね？ 吸って… 吐いて。"

    # say L3288 bil
    old "Okay... T- thank you..."
    new "Okay... ありがとう..."

    # say L3289 pla
    old "You’re the one with the voice. I’m just there to hold you steady."
    new "君の声だよ。俺はただ支えてあげるだけさ。"

    # say L3290 pla
    old "You ready?"
    new "準備OK？"

    # say L3291 bil
    old "No... but I’m doing it anyway."
    new "Nope...でも、やっちゃうわ。"

    # say L3292 pla
    old "That's good, let´s go!"
    new "よし、行こう。"

    # say L3312 pla
    old "Do it for them."
    new "彼らのためにやってみろ。"

    # say L3314 pla
    old "Do it for your mom... and your dad. They’d be so proud of you right now."
    new "お母さんとお父さんのためにやってみろ。今ならきっと誇りに思うだろう。"

    # say L3316 bil
    old "They would, wouldn’t they?"
    new "そうよね、そう思うわ。"

    # say L3317 bil
    old "Thank you... for reminding me why I’m here."
    new "ありがとう……私がここにいる理由を思い出させて。"

    # say L3318 bil
    old "Let’s do this."
    new "やろうね。"

    # say L3319 pla
    old "Together."
    new "一緒に行こう。"

    # say L3339 bey
    old "Wow... what a night."
    new "すごい夜だったな。"

    # say L3340 bey
    old "First of all, thank you all for waiting so patiently... I know we made you sit through a lot today."
    new "まずは、皆さんの我慢に感謝します... 今日一日、長い時間お待たせしましたね。"

    # say L3341 bey
    old "Because you didn’t just perform... you gave us a show we’re never going to forget."
    new "君たちはただパフォーマンスをしただけじゃなくて、一生忘れないようなショーを繰り広げてくれた。"

    # say L3342 bey
    old "Every duo showed heart, talent, and courage."
    new "各組が心、才能、そして勇気を見せてくれた。"

    # say L3343 bey
    old "This wasn’t just a Music contest. This was a night full of real stories, real voices, and real passion."
    new "これはただの音楽コンテストじゃなかったんだ。この夜は本物の物語、本物の声、本物の情熱が詰まっていた。"

    # say L3344 bey
    old "The jury had an almost impossible job tonight."
    new "審査員は今夜、ほとんど不可能な仕事だったんだ。"

    # say L3345 bey
    old "They argued, they debated, they went back and forth... because every single performance deserved to be celebrated."
    new "彼らは議論し、話し合った…なぜなら、どのパフォーマンスも称えられるべきだったからだ。"

    # say L3346 bey
    old "But after long deliberation... they finally made their decision."
    new "長い議論の末……ついに決断した。"

    # say L3348 bey
    old "The winners of this year’s Music Contest are..."
    new "今年の音楽コンテストの優勝者は..."

    # say L3356 bey
    old "Come on up here, you two! You earned this."
    new "さあ、二人とも上がってこい！ お前らがこれを勝ち取ったんだ。"

    # say L3357 bey
    old "Get your prize and let everyone see the duo that stole the show tonight!"
    new "賞を取りに行って、みんなに今夜の主役の二人を見てもらおう！"

    # say L3371 pla
    old "We... we actually did it."
    new "俺たち… 本当にやったんだな。"

    # say L3372 bil
    old "I... I can’t believe it."
    new "信じられない..."

    # say L3373 pla
    old "We did it."
    new "やったぞ。"

    # say L3374 bey
    old "Come on, darling... come and get your trophy."
    new "さあ、 Darling... お前のトロフィーを取ってみろ。"

    # say L3377 pla
    old "Go ahead, this is your moment..."
    new "行け、今が君の時間だよ。"

    # say L3393 bey
    old "Billie, honey... would you like to say a few words to the audience?"
    new "ビリー、かわいい子……観客に何か言いたいことない？"

    # say L3395 bil
    old "I... no, I’m not good with words."
    new "私…いや、言葉が上手くないな。"

    # say L3396 bil
    old "I don’t think I can..."
    new "私は……多分無理かも。"

    # say L3397 pla
    old "Come on, Billie. Say something."
    new "比利、さあ。何か言ってみろ。"

    # say L3398 pla
    old "They want to hear from you. You earned this moment."
    new "彼らは君の声を聞きたいんだ。君がこの瞬間を勝ち取ったんだから。"

    # say L3401 bil
    old "Okay... just this once."
    new "いいよ... ただ一度だけ。"

    # say L3404 bil
    old "I... I didn’t think I’d ever sing again."
    new "私……また歌うなんて、思ってもみなかった。"

    # say L3405 bil
    old "For years I buried this part of me because every note reminded me of my parents."
    new "何年もこの部分を隠してたの。毎度音を出すたびに、親のことを思い出したから。"

    # say L3406 bil
    old "They taught me to sing. They taught me to love music. And when I lost them... I lost that too."
    new "彼らは私に歌を教えてくれた。音楽を愛することを教えてくれた。そして彼らを失ったとき……それも失ってしまった。"

    # say L3408 bil
    old "But someone stubborn refused to let me hide forever."
    new "でも誰か頑固な人が、私を永遠に隠れ続けることを許さなかった。"

    # say L3410 bil
    old "He dragged me back to the stage... even when I fought him every step of the way."
    new "彼は私をステージに戻した…私が抵抗したって関係なく。"

    # say L3411 bil
    old "Come here, dummy."
    new "来い、バカ。"

    # say L3420 bil
    old "So tonight... this win isn’t just mine. It’s ours."
    new "今夜……この勝利は私だけのものじゃない。私たちのものよ。"

    # say L3421 bil
    old "Mom... Dad... this one’s for you."
    new "ママ、パパ、これもあなたたちのために勝ったのよ。"

    # say L3437 bil
    old "I still can’t believe we actually won..."
    new "まだ信じられない... 優勝したなんて。"

    # say L3438 pla
    old "You were incredible up there. Everyone saw it."
    new "君はステージで最高だったな。みんなが見てたぜ。"

    # say L3439 bil
    old "I didn’t think I’d ever stand on a stage again... and now I’m holding a trophy."
    new "ステージに立つなんて、もう二度とないと思ってたのに… 今、トロフィーを手にしてるんだ。"

    # say L3440 bil
    old "For a long time I told myself I was going to win just to look strong... I never really believed it."
    new "長い間、自分に強そうに見せるために勝つって言ってきたの... でも本当は信じていなかった。"

    # say L3441 pla
    old "But you did win. And it wasn’t fake. It was real."
    new "でも君は勝ったんだ。それも偽物じゃなかった。本物だった。"

    # say L3442 pla
    old "Your voice came straight from your heart. The others were all flash and technique... but you? You made people feel something."
    new "君の声は心から出てきた。他の人はみんな見せかけと技術だったけど、君は？ 君は人々に何かを感じさせた。"

    # say L3444 pla
    old "I know so. That’s why you won. Not because of any outfit or trick... because it was you."
    new "知ってるよ。だから君が勝ったんだ。衣装やトリックじゃなくて、君自身だからさ。"

    # say L3446 bil
    old "It’s weird... I spent years running from this, and now it feels like I finally got a piece of myself back."
    new "変な感じ……このために何年も逃げ続けてきたのに、今となっては自分の一部を取り戻したみたい。"

    # say L3447 pla
    old "You did. And I’m really proud of you."
    new "お前がそうしたんだ。そして、本当に君のことを誇りに思ってる。"

    # say L3448 bil
    old "I couldn’t have done any of this without you."
    new "あなたがいなければ、何もできなかった。"

    # say L3449 bil
    old "You pushed me when I wanted to hide. You stayed when I tried to push you away."
    new "あなたが私を隠れようとしたとき、押してくれた。私があなたを遠ざけようとしても、いってくれた。"

    # say L3450 pla
    old "I wasn’t going anywhere."
    new "どこにも行かなかったよ。"

    # say L3451 bil
    old "I know... and that means more than you’ll ever understand."
    new "知ってる… それがどれだけ大切なのか、あなたにはわからないわ。"

    # say L3452 bil
    old "Speaking of outfits... you never really said anything about this one."
    new "服の話が出たけど……この服装については何も言ってくれなかったよね。"

    # say L3453 bil
    old "What do you think? Be honest."
    new "どう思う？正直に言ってね。"

    # say L3454 pla
    old "You look... stunning. It’s edgy, it’s dark, it’s completely you. No one else could pull it off like that."
    new "君は… Stunning。尖ってて、ダークで、完全に君らしい。他の誰もこんな風には着こなせないよ。"

    # say L3455 bil
    old "Heh... good answer."
    new "へへ…いい答えだね。"

    # say L3456 bil
    old "I was nervous about wearing something so different... but the way you’re looking at me right now..."
    new "こんなに違う格好をするのは緊張してたの... でも、今あなたが見つめているその目が..."

    # say L3457 bil
    old "Makes me want to give you a better view."
    new "今のあなたの視線が、もっと見せたくなるわ。"

    # say L3468 bil
    old "Tonight I want to celebrate... my way."
    new "今夜は私的方式で祝いたいの。"

    # say L3477 bil
    old "You’ve been staring at my tits all night... time to give them some attention."
    new "あなた、私の胸ばかり見つめてるわね… そろそろちゃんとしてあげるわ。"

    # say L3486 bil
    old "Mmm... morning already?"
    new "うーん…もう朝なのか？"

    # say L3487 pla
    old "Yeah... I don’t want it to be."
    new "うん… そうじゃなくないんだけど。"

    # say L3488 bil
    old "Last night still feels like a dream."
    new "昨夜の出来事はまだ夢のようだね。"

    # say L3489 pla
    old "It wasn’t a dream. You won. We won."
    new "夢じゃなかったよ。君が勝った。俺たちが勝った。"

    # say L3490 bil
    old "And I didn’t completely fall apart... thanks to you."
    new "そして、完全に崩れなかったのは…あなたのおかげだよ。"

    # say L3491 pla
    old "You didn’t need me to win. You just needed to remember who you are."
    new "君が勝つために俺が必要だったわけじゃない。ただ、君が誰なのかを思い出せばよかったんだ。"

    # say L3492 bil
    old "Still... having you there made it feel possible."
    new "それでも……あなたがいてくれて、それが可能に感じられた。"

    # say L3494 bil
    old "I don’t usually do the whole ‘morning after’ thing."
    new "私は普段、‘朝-after’ってのをしないんだけど。"

    # say L3495 pla
    old "Neither do I... but I’m really glad we did."
    new "俺もそう思ってた…でも、本当に良かったと思う。"

    # say L3496 bil
    old "Don’t get used to it, though. I’m still the same Billie."
    new "でも惯れないでね。私は依然として同じBillieよ。"

    # say L3497 pla
    old "Good. I like that Billie."
    new "Good. I like that Billie。"

    # say L3499 bil
    old "You should probably head home before your family starts asking questions."
    new "家に帰った方がいいわ、家族に質問される前に。"

    # say L3501 pla
    old "But last night... everything we did, everything we said..."
    new "でも昨夜……俺たちがした全てのこと、言葉を交わした全て……"

    # say L3502 pla
    old "It meant a lot to me."
    new "俺にとってはすごく意味があったんだ。"

    # say L3504 bil
    old "It meant a lot to me too."
    new "私にとっても大切なことだったよ。"

    # say L3505 bil
    old "I’m not great at saying this stuff, but... thank you. For not giving up on me. For pushing me. For staying."
    new "私はこんなこと上手く言えないけど…ありがとう。あきらめずにいてくれて、押してくれて、いてくれて给了比较直接的翻译，但可以稍微调整一下以使语气更加自然和流畅。"

    # say L3508 bil
    old "Alright, we better get dressed."
    new "さあ、服を着よう。"

    # say L3515 pla
    old "I’ll see you at school later?"
    new "後で学校で会おう？"

    # say L3516 bil
    old "Yeah... I’ll be there."
    new "うん…いるよ。"

    # say L3517 bil
    old "And don’t be late, or I’ll drag you back here again."
    new "遅刻するな、さもないとまた連れてくるからね。"

    # say L3518 pla
    old "Wouldn’t miss it."
    new "欠かさないな。"

    # say L3524 pla
    old "Take care of yourself, Billie."
    new "お前も気をつけて、Billie。"

    # say L3525 bil
    old "You too."
    new "あなたもね。"

    # say L3530 bil
    old "({i}He really stayed... and I didn’t push him away.{/i})"
    new "({i}彼は本当に残って…私は彼を追い払わなかったんだ。{/i})"

    # say L3531 bil
    old "I guess I know what it means..."
    new "なるほど、その意味がわかったような…"

    # say L3551 pla
    old "Alright... time for some practice."
    new "よし…練習の時間だ。"

    # say L3553 pla
    old "It’s becoming part of the routine... and I actually look forward to it."
    new "ルーチンの一部になってきたな… 俺もこれに期待してんだ。"

    # say L3574 pla
    old "Feels natural now... like the guitar is actually listening."
    new "自然になったな... ギターが実際に聴いてるみたいだ。"

    # say L3590 pla
    old "({i}This is actually fun... who would’ve thought?{/i})"
    new "{i}これって意外と楽しいな... 誰が思ったか...{/i}"

    # say L3605 pla
    old "Still a couple of rough spots... but overall it sounded solid."
    new "まだいくつか荒いところがあるけど、全体的にはしっかりした音が出たな。"

    # say L3607 pla
    old "It doesn’t feel like a chore anymore. It feels... right."
    new "もう面倒くさくないな。正直、これでいい感じがする。"

    # say L3610 pla
    old "Tomorrow I’ll pick it up again... no pressure, just playing."
    new "明日また触るよ…プレッシャーではなくて、ただ楽しむためだね。"

    # say L3651 pla
    old "Yeah... I’ve been practicing a lot by myself, but I feel like I improve faster when I’m with you."
    new "そうだな… 自分で練習してるけど、君と一緒にやると成長が早い気がする。"

    # menu L3663 
    old "Rehearse the song together"
    new "一緒に曲を練習する"

    # say L3665 pla
    old "I want to polish the chords even more, you know..."
    new "もっとコードを磨きたいんだ、分かるか？"

    # say L3666 bil
    old "Heh. Going for the safe route first? Fine by me... for now."
    new "へへ、まずは安全な道を選ぼうとしてるの？いいよ、今はそれで……。"

    # say L3701 bil
    old "Hmm... your changes are actually smooth now. You’ve been practicing."
    new "Hmm... あなたの弾き方 actually 滑らかになったね。練習してたんだね。"

    # say L3706 bil
    old "Still... I wouldn’t mind if you picked something a little more fun next time."
    new "それでも、次はちょっと面白いやつを選んでくれてもいいな。"

    # menu L3708 
    old "Finger practice"
    new "指の練習"

    # say L3743 pla
    old "They’re... so soft every time. I can feel them filling my hands."
    new "彼女たちが……毎回こんなに柔らかいんだ。手の中で膨らむのが感じるよ。"

    # say L3744 bil
    old "Mmm... squeeze them slowly. Open and close your hands... just like that."
    new "んん…ゆっくりと握って。手を開いたり閉じたり…そう、その通り。"

    # say L3747 bil
    old "Nngh— yeah... a little harder now. Grip them properly."
    new "んんー… そうだよ… ちょっと強くして。ちゃんと握るように。"

    # say L3750 bil
    old "Fuck... keep that pace. Squeeze them like you mean it."
    new "くそ……そのペースで。本気で絞るように。"

    # say L3753 bil
    old "Now the nipples... grab them and pull... slow at first."
    new "乳首を……握って引いて……最初はゆっくりと。"

    # say L3764 bil
    old "That’s it... stretch them gently."
    new "そうそう…優しく引っ張って。"

    # say L3772 bil
    old "Fuck... faster. Pull them nice and firm. I love how confident your hands feel now."
    new "くそ……もっと速く。しっかり引っ張って。今さら手つきが自信に満ちてるの、大好き。"

    # say L3777 bil
    old "Mmm... your touch is way more precise lately. You’ve improved a lot."
    new "うん... 最近あなたのタッチがずいぶん正確になったね。ずいぶん上達したわ。"

    # say L3779 bil
    old "Keep practicing that rhythm at home... or just come back whenever you want more of... this."
    new "家でそのリズムを練習して... あるいはもっとこれが必要な時にまた来ればいいよ。"

    # menu L3781 
    old "Advanced finger practice"
    new "上達した指の練習"

    # say L3801 pla
    old "Uhh... I’ve been practicing the guitar a lot by myself lately."
    new "うーん……最近ギターの練習ばっかしてたんだ。"

    # say L3802 pla
    old "And I was thinking... maybe it would be good if I helped you with your practice too, you know?"
    new "でもね、君の練習にも手伝ったらどうかなあって思ったんだ。"

    # say L3803 pla
    old "Like... helping you stay steady under pressure... like last time..."
    new "プレッシャーに耐えて落ち着けるように手伝うってことさ、ビリー"

    # say L3804 bil
    old "Heh... look at you trying to be all subtle."
    new "へへ、ずいぶんと上手くやっているね。"

    # menu L3826 
    old "Get motivated"
    new "モチベーションを上げる"

    # say L3828 pla
    old "And sometimes I feel like I still need... a little extra motivation to keep improving."
    new "時々、まだちょっとした追加のモチベーションが必要だって思うことがあるんだ。"

    # say L3829 bil
    old "Heh... so that’s what this is really about."
    new "へへ… そうなのか、これが本題ってわけね。"

    # say L3834 bil
    old "Just looking at them... does that help?"
    new "見ているだけでも... 効果あるの？"

    # say L3836 pla
    old "Y-yeah... they look amazing but... I was thinking maybe something more... direct?"
    new "うん… 確かに見ただけでもいいんだけど… もっと直接的なこと考えた方がいいのかな？"

    # say L3839 bil
    old "Heh... fine. I know exactly how to motivate you properly."
    new "へへ、いいわ。私を proper に動機づける方法、知ってるのさ。"

    # say L3859 bil
    old "Phew... that’s enough for today."
    new "ふう… 今日はこれで十分だわ。"

    # say L3861 bil
    old "Hey... before you go."
    new "Hey... 行く前よ。"

    # say L3865 bil
    old "It’s important... and I don’t want to go alone."
    new "大事なことだから…一人で行きたくないの。"

    # say L3875 bil
    old "Oh, by the way..."
    new "ちょっと、その前に..."

    # say L3887 bil
    old "Just text me. I’ll always make time... especially if you want the fun version."
    new "ただメッセージくれればいいよ。いつでも時間作るから…特に楽しいバージョンが欲しいならね。"


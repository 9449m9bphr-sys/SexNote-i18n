# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/anaAnimations.rpy
translate japanese strings:

    # say L12 ana
    old "What a nice cock do you have..."
    new "どんな素敵なちんこしてるのね…"

    # say L16 ana
    old "Do you like it, Uh? Do you want it faster baby?"
    new "好きよね、ウーン？もっと速くしてほしいの、ベイビー。"

    # say L20 ana
    old "Oh yeah baby, I wanna see that huge cock cumming..."
    new "おおyeahベイビー、その大きなちんこでイッちゃうの見せてほしいな..."

    # say L45 pla
    old "Mrs Anastasia... I- going to-"
    new "アナスタシアさん… 行くよ…"

    # say L46 ana
    old "Oh yes, cum for mommy, give it to me..."
    new "ああ、そう、ママのために出しなさい、全部私にくれてください…"

    # say L51 ana
    old "Wow that was a lot of cum..."
    new "すごい精子が出たね…"

    # say L60 ana
    old "Mmm, I love your huge cock!"
    new "うん、あなたの大きなちんこ大好き！"

    # say L64 ana
    old "Do you like my mounth, baby?"
    new "ベイビー、私の口好き？"

    # say L68 ana
    old "Come on fuck my throat with your big cock!"
    new "さあ、私の喉をあなたの大きなちんこで犯して！"

    # say L92 pla
    old "Anastasia I'm going to..."
    new "アナスタシア、俺のチンポで君の喉を犯すよ…"

    # say L93 ana
    old "Ohh yeah, cum all over my face!"
    new "オッホ、そうよ、私の顔に全部出して！"

    # say L98 ana
    old "Uhhh warm and sweet..."
    new "うーん、暖かくて甘い…"

    # say L115 ana
    old "Ahhh, yeah baby fuck me, FUCK ME!"
    new "アーッ、そうよベイビー、私を犯して、もっと犯して！"

    # say L119 ana
    old "Oh god, Oh god, It feels great!"
    new "ああ神、ああ神、気持ちいい！"

    # say L123 ana
    old "H- Harder... Fuck me harder!"
    new "もっと激しく……強くファックして！"

    # say L147 ana
    old "Ahhh I'm cumming!"
    new "ああっ、イクッ！"

    # say L148 pla
    old "I- I'm cumming too..."
    new "俺も出る…"

    # say L169 ana
    old "Oh my God! This is amazing! Fuck me, Fuck me!"
    new "ああ神様！これ最高！もっと突いて、もっと突いて！"

    # say L173 ana
    old "AHHHH AHHHH, YEAH YEAH, HARDER BABY, HARDEER!"
    new "アヒャアヒャ、イイイイ、もっと激しくBaby、もっと激しくッ！"

    # say L177 ana
    old "OH MY GOD I LOVE YOUR COCK! GIMME MOREE!"
    new "ああ神様！あなたのコック大好き！もっともっとくれぇ！"

    # say L212 ana
    old "Oh my god! I loved it..."
    new "神様！それは本当に良かった…"

    # say L213 pla
    old "I- I like it... too."
    new "俺も…好きだよ。"

    # say L216 ana
    old "Oh my god! You are amazing, I loved it..."
    new "神様！あなたは本当に凄いわ、大好きだった…"

    # say L220 ana
    old "I loved it..."
    new "大好きだった…"

    # say L229 ana
    old "Ohhh, your cock feels so nice!"
    new "あぁ、あなたのチ○ポ、気持ちいい〜！"

    # say L233 ana
    old "YEAH, BABY, FASTER, FASTER!"
    new "はい、ベイビー、もっと速く、速く！"

    # say L237 ana
    old "OH MY FUCKING GOD! HARDER, FUCK ME HARDER!"
    new "おおおっ、もっと強くファックして！"

    # say L275 lis
    old "Alright, take a few moments to settle into your position."
    new "よし、少しポジションを整える時間を使って。"

    # say L276 lis
    old "Bring your attention to your breath."
    new "息に意識を向けて。"

    # say L277 lis
    old "Focus on the air coming in and out."
    new "息の出入りに意識を向けて。"

    # say L281 lis
    old "Notice the cool air entering your nostrils and the warm air leaving them."
    new "冷たい空気が鼻から入って、温かい空気が出ていくのを感じて。"

    # say L282 lis
    old "Without trying to change your breath, simply observe it."
    new "呼吸を変えようとせずに、ただ観察して。"

    # say L283 lis
    old "Let your body and mind relax."
    new "体と心をリラックスさせて。"

    # say L289 lis
    old "If your mind begins to wander, that's okay."
    new "もし頭がさまよっても、それは構わない。"

    # say L290 lis
    old "Let your body feel everything it needs to feel."
    new "体が感じたいこと全てを感じさせて。"

    # say L291 lis
    old "The sensation of my and [pla]'s hands going over your body."
    new "私の手と[pla]の手があなたの体をなぞる感覚。"

    # say L296 lis
    old "Gently guide your focus back to the sensation of breathing."
    new "ゆっくりと呼吸の感覚に意識を戻してみて。"

    # say L297 lis
    old "Allow yourself to be fully present with each breath."
    new "息をするたびに、完全にここにいることを許して。"

    # say L298 lis
    old "Finding calm and clarity in this simple act."
    new "このシンプルな行為から平静と明瞭さを見つける。"

    # say L303 ana
    old "Mmm, this feels great, guys."
    new "うん、これ感じいいわ、みんな。"

    # say L304 ana
    old "M-My body's feeling amazing!"
    new "あ、あたしの体、すっごく気持ちいい！"

    # say L305 lis
    old "That's good, that's your body reacting to the energy flowing within you."
    new "それはいいね、君の体が内的なエネルギーに反応してるんだ。"

    # say L306 lis
    old "As your chakras are being cleansed."
    new "あなたのチャクラが浄化されていくね。"

    # say L327 lis
    old "[pla], place yourself between her legs, and help her energy flow through a massage."
    new "[pla]、彼女の足の間に位置して、マッサージで彼女のエネルギーが流れるように手伝って。"

    # say L336 ana
    old "I... Oh my god!"
    new "ああ……神様！"

    # say L337 ana
    old "This feels incredible!"
    new "これ、すごい感じる！"

    # say L338 ana
    old "I feel like I'm having an orgasm, Lisa!"
    new "私はオーガズムを感じているわ、リサ！"

    # say L339 lis
    old "Good! Enjoy that feeling!"
    new "いいよ！その感覚を楽しんで！"

    # say L340 lis
    old "Let yourself fall deeply into it!"
    new "その感覚に深く溺れて！"

    # say L347 ana
    old "Oh gosh! I can't believe it!"
    new "ああっ！信じられない！"

    # say L348 ana
    old "I actually had an orgasm that way."
    new "あたし、その方法で実際にイッちゃったの。"

    # say L349 lis
    old "Of course, your body reacted positively to your Mudhalara chakra coming into balance."
    new "もちろん、あなたの身体はムドララチャクラがバランスを取ることでポジティブに反応したの。"

    # say L350 lis
    old "That is the beauty of a tantric process."
    new "それがタントラのプロセスの美しさよね。"

    # say L351 ana
    old "I have to say it was amazing!"
    new "本当に素晴らしかったわ！"

    # say L352 lis
    old "Haha, I'm glad you liked it."
    new "はは、良かったみたいで嬉しいな。"

    # say L353 lis
    old "I'll let you get up now."
    new "じゃあ、起きていいよ。"

    # say L361 ana
    old "Uhh, that was so good!"
    new "うーん、それは凄かった！"

    # say L362 ana
    old "I loved it!"
    new "好きだったわ！"

    # say L363 lis
    old "I see that your connection with yourself and the balance of your chakras is improving."
    new "アナ、君の自己とのつながりとチャクラのバランスが良くなってきたね。"

    # say L364 lis
    old "I think that with this we can move on to the next exercise."
    new "この調子で次のエクササイズに進めると思うわ。"

    # say L365 ana
    old "Great!"
    new "素晴らしい！"

    # say L387 lis
    old "Remember to focus on your breathing, Anastasia."
    new "息を意識して、アナスタシア。"

    # say L388 lis
    old "Feel the air going in and out of your body."
    new "体の中を出入りする空気を感じて。"

    # say L389 lis
    old "Let go of any thoughts or worries, allowing them to drift away with your breath."
    new "思いや心配事を手放して、息とともに遠くへと流れていくのを感じてください。"

    # say L393 lis
    old "Continue to focus on this flow of energy, allowing it to move freely and naturally."
    new "このエネルギーの流れに集中し続けて、自由で自然に動かせるように。"

    # say L394 lis
    old "With each breath, feel more relaxed and centered."
    new "一呼吸ごとに、よりリラックスして落ち着いて。"

    # say L395 lis
    old "Just breathe and let your energy flow in and out."
    new "ただ息をして、エネルギーが出入りするのを感じて。"

    # say L399 ana
    old "Mmm! This feels amazing, Lisa."
    new "うん！これ、最高の気分だよ、リサ。"

    # say L400 lis
    old "Yes! Focus on that sensation!"
    new "うん！その感覚に集中して！"

    # say L401 lis
    old "Let your body guide you in what you need!"
    new "体の感覚に任せて、求めていることを感じて！"

    # say L424 ana
    old "I'm about to... Cum Lisa!"
    new "私はもう… リサにイクよ！"

    # say L425 lis
    old "Yes! Yes! Let it all out!"
    new "はい！はい！全部出しちゃって！"

    # say L426 lis
    old "Let everything flow out of you!"
    new "全部出しちゃって！"

    # say L434 ana
    old "Oh that was so amazing!"
    new "ああ、それ凄かった！"

    # say L435 ana
    old "It felt so good!"
    new "それはすごく感じられたわ！"

    # say L436 lis
    old "I'm glad you enjoyed it, that's your Mudhalara chakra coming into balance."
    new "良かったね、あなたのムドララチャクラがバランス取れたんだ。"

    # say L437 lis
    old "I belive we're on the right path."
    new "正しい道を歩んでると思うよ。"

    # say L438 lis
    old "But now, let's get up, so that [pla] can also rest a little."
    new "でも今、起きて [pla] も少し休めるようにしましょう。"

    # say L450 lis
    old "Relax, feel the depth of your energy."
    new "リラックスして、あなたのエネルギーの深さを感じてみて。"

    # say L451 lis
    old "Feel how far it goes inside you."
    new "体内深くまで感じてみて。"

    # say L452 lis
    old "And the connection [pla]'s helping you achieve."
    new "そして [pla] のつながりが君を助けてくれていることを感じて。"

    # say L456 lis
    old "Do you feel it, Anastasia?"
    new "感じてる、アナスタシア？"

    # say L457 lis
    old "How deep inside you your energy goes?"
    new "エネルギーがどれだけ奥まで届いてるか感じてる？"

    # say L458 lis
    old "Do you feel it flowing?"
    new "流れているのを感じてる？"

    # say L459 ana
    old "Y-Yes I do."
    new "うん、感じてる。"

    # say L460 ana
    old "I can feel it very deep inside me!"
    new "奥深くまで感じてる！"

    # say L464 lis
    old "Do you feel your energy flowing inside, Anastasia?"
    new "アナスタシア、君の中にエネルギーが流れているのを感じてる？"

    # say L465 ana
    old "Oh yes! It's going so far inside me!"
    new "ああ、そうよ！奥まで届いてるの！"

    # say L466 ana
    old "I love how it feels!"
    new "感じがいい！"

    # say L489 ana
    old "Lisa! [pla]! I can't hold it in anymore!"
    new "リサ！[pla]！もう我慢できないよ！"

    # say L490 lis
    old "Don't! Let yourself go!"
    new "待って！　我慢しないで！"

    # say L491 lis
    old "Let it all out!"
    new "全部出しちゃって！"

    # say L499 lis
    old "How do you feel, Anastasia?"
    new "アナスタシア、どう感じる？"

    # say L500 ana
    old "I feel amazing!"
    new "凄い感じてる！"

    # say L501 lis
    old "Were you able to make an internal connection?"
    new "内部でつながれたの？"

    # say L502 ana
    old "I can feel it all inside me."
    new "全部感じてるわ。"

    # say L503 lis
    old "Wonderful! That was the objective of this!"
    new "素晴らしい！それがこの目的だったのよ！"

    # say L504 ana
    old "Now, time to get up and get cleaned up."
    new "じゃあ、起きて洗いっこしようね。"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/whiAnimations.rpy
translate japanese strings:

    # say L6 whi
    old "Give me that big cock..."
    new "そんな大きなチ○ポをください…"

    # say L8 whi
    old "Oh my, you've definitely grown a lot! "
    new "あら、ずいぶん大きくなりましたね！"

    # say L12 whi
    old "Uhh, it feels so warm and hard."
    new "うーん、温かくて硬いですね。"

    # say L14 pla
    old "Y- yes it feels nice too."
    new "うーん、確かに気持ちいいです。"

    # say L18 whi
    old "What about if you cum for mommy?"
    new "もし私がママとしてイッちゃったらどうするの？"

    # say L43 whi
    old "Mrs. W- white I- I-"
    new "ミス・ホワイト、イ、イって"

    # say L44 whi
    old "Ohh, yeah baby..."
    new "ああ、そうねベイビー…"

    # say L45 whi
    old "Give it to mommy!"
    new "ママにあげて！"

    # say L53 whi
    old "I have to say, [pla], you have a wonderful cock."
    new "[pla]、あなたのペニスは素晴らしいわ。"

    # say L54 pla
    old "Uhh... T-thanks..."
    new "うっ… ありがとう…"

    # say L64 pla
    old "Wow! Mrs. White, w- what are you doing?"
    new "Wow！ ホワイトさん、な、何してるんですか？"

    # say L65 whi
    old "Just enjoy it baby... Mommy is gonna blow your mind..."
    new "そのまま楽しんで dear... ママはあなたの頭を爆発させるわ..."

    # say L66 pla
    old "(Holly shit!)"
    new "くそっ！"

    # say L70 whi
    old "Oh God, you got a huge cock..."
    new "おお神様、あなたのちんぽは本当に大きいわ…"

    # say L71 whi
    old "It hardly fits in my mouth."
    new "口に入りきらないわ。"

    # say L76 whi
    old "Do you want to cum in my mouth?"
    new "あなたの精液を私の口の中で xuất hiện了一个错误，让我纠正它："

    # say L78 whi
    old "I wanna taste it!"
    new "味わってみたいの！"

    # say L101 whi
    old "Oh yeah, cum for mommy!"
    new "ああ、そうよ、ママのために出してちょうだい！"

    # say L102 whi
    old "Give me all that cum baby."
    new "私に全部出しなさい、ベイビー。"

    # say L121 whi
    old "By the way, you haven't said anything about the food. Are you liking it?"
    new "それにしても、食事については何も言わなかったわね。気に入ってるの？"

    # say L122 pla
    old "Oh... yes ma'am, I- I like it... a lot."
    new "はい…はい、そうですね、僕は…とても気に入りました。"

    # say L123 whi
    old "It makes me so happy to hear you say that."
    new "それを聞いて嬉しいです。"

    # say L124 whi
    old "I made everything with my... hands, after all."
    new "私があの手この手で作ったものですから。"

    # say L125 mik
    old "Yes, It's really good mom, thank you."
    new "はい、本当に美味しいです、ありがとうございます。"

    # say L130 whi
    old "I see you're enjoying it a lot, right [pla]?"
    new "そうですね、とても楽しんでらっしゃるようですね [pla]。"

    # say L131 pla
    old "Mmm... Y- yes ma'am, I- I like it a lot!"
    new "うん… は、はい、すごく気に入ってます！"

    # say L132 whi
    old "Well, have as much as you like."
    new "好きなら、存分にどうぞ。"

    # say L133 whi
    old "You can ask me for more whenever you want to."
    new "いつでももっと欲しいって言ったらいいわよ。"

    # say L134 mik
    old "Yeah, I think I would like to repeat."
    new "そうだな、またやりたいと思うよ。"

    # say L155 whi
    old "Look at that [pla], you're almost done!"
    new "あの [pla] 見て、もうすぐ終わっちゃうわね！"

    # say L156 whi
    old "Would you finish for me?"
    new "終わりさせていただけますか？"

    # say L157 pla
    old "Mmm... Yes Mrs. White..."
    new "うむ、はい、ホワイト先生…"

    # say L164 whi
    old "Well, it looks like you're done, did you enjoy it [pla]?"
    new "あたし、あなたはもう終わったみたいね、楽しめたかしら [pla]？"

    # say L165 pla
    old "Y- yes Mrs. White, it was very pleasing."
    new "はい、ホワイト先生、とても気持ちよかったです。"

    # say L166 mik
    old "What? But he hasn't finished his food... Why do you say he is done?"
    new "何？でも彼の食事はまだ終わってないじゃん… なんで終わったって言うの？"

    # say L167 whi
    old "Trust me honey, [pla] is completely satisfied."
    new "信じてちょうだい、ミク。[pla]は完全に満足してるの。"

    # say L168 whi
    old "Anyway, Mike, please take the dishes to the kitchen."
    new "それにしても、マイク、食器はキッチンに片付けてくれますか。"

    # say L169 mik
    old "Hmm, sure."
    new "うん、わかった。"

    # say L182 whi
    old "Mmm, yes, this big dick."
    new "大きなチ○ポ、 yummy です。"

    # say L183 whi
    old "It tastes so good in my mouth."
    new "このおちんちん、私の口中でとっても美味しいです。"

    # say L185 whi
    old "Just relax and enjoy it, like I'm enjoying it."
    new "リラックスして、私が楽しんでいるように楽しんでみてください。"

    # say L189 whi
    old "God! I swear it's getting even bigger!"
    new "神様！ 本当にもう、どんどんでかくなってるわよ！"

    # say L190 whi
    old "This is just what I wanted!"
    new "これこそ私が欲しかったものよ！"

    # say L191 whi
    old "Are you enjoying it [pla]?!"
    new "楽しんでる？ [pla]？！"

    # say L192 pla
    old "Y- Yes ma'am!"
    new "はい！"

    # say L196 whi
    old "Yes! Shove that dick down my throat!!"
    new "はい！そのチンポを私の喉に突き入れて！"

    # say L197 whi
    old "Push it!"
    new "押し込んで！"

    # say L198 whi
    old "Yes, fuck my mouth like that..."
    new "はい、そうやって私の口を犯して…"

    # say L199 whi
    old "Don't come yet! I want it a little longer!"
    new "まだ出さないで！もう少し続けたいの！"

    # say L222 pla
    old "M- Mrs. White! I can't hold it anymore!"
    new "白さん！もう我慢できないっす！"

    # say L223 whi
    old "Mmmm! It's ok, you can cum!"
    new "大丈夫、イッていいよ！"

    # say L224 whi
    old "Cum for mommy!"
    new "ママのためにイッて！"

    # say L225 whi
    old "Give me all your load!"
    new "私に全部出しなさい！"

    # say L230 whi
    old "Mmm, I love your cum."
    new "ん、あなたの精液が大好き。"

    # say L231 whi
    old "It's like a very nice, hot, sweet treat!"
    new "それはとても美味しい、熱々で甘いおやつのようです！"

    # say L232 pla
    old "Mrs. White, I- I think we should get dressed."
    new "白さん、あの、着ておいた方がいいんじゃない？"

    # say L233 whi
    old "Oh no, what are you talking about?"
    new "何言ってるの？それって始まったばかりよ、それが序の口に過ぎないわ。"

    # say L234 whi
    old "We're only getting started, that was just the beginning."
    new "始まったばかりよ、それがあくび一つの始まりに過ぎないわ。"

    # say L235 whi
    old "Now it's time for the main course."
    new "では、メインディッシュに入りましょう。"

    # say L239 whi
    old "Oh fuck! He arrived already!"
    new "あらっ！もう来ちゃったの！"

    # say L240 pla
    old "Shit! He's gonna catch us! We better get dressed quickly."
    new "しまった！見つかるぞ！急いで服を着よう。"

    # say L242 whi
    old "I'm in here honey!"
    new "ハニー、私はここにいるの！"

    # say L243 whi
    old "Just give me a second!"
    new "ちょっとだけ待ってね！"

    # say L244 whi
    old "Hmm, this is annoying, he has to come back just when things are getting good!"
    new "うーん、これって面倒くさいわ、ちょうどいい感じになってきたところにまた戻ってくるなんて。"

    # say L245 pla
    old "We should just hurry up."
    new "急いだ方がいいな。"

    # say L257 whi
    old "Mmm, look how hard it is."
    new "ん、こんなに固くなってるわ。"

    # say L258 whi
    old "And you were pretending to be nervous."
    new "あなたが緊張しているふりをしていたのね。"

    # say L260 whi
    old "Just relax, I'll make you cum before you know it."
    new "リラックスして、気づかないうちにイかせちゃうから。"

    # say L264 pla
    old "M- Mrs. White... Mmm, Mike could come back a- any minute."
    new "ミス・ホワイト… マイクがいつ戻ってきてもおかしくないですよ。"

    # say L265 whi
    old "You're right, this is so naugthy!"
    new "そうですよ、これってすごく悪戯ですね。"

    # say L266 whi
    old "I love this adrenaline rush."
    new "この興奮が大好きです。"

    # say L270 whi
    old "Mmm, yes, like that."
    new "うん、そうよ。"

    # say L271 whi
    old "Just enjoy it, I'll keep going."
    new "楽しんでいてください、続けますよ。"

    # say L272 whi
    old "I love how your cock twitches in my mouth."
    new "あなたのペニスが私の口の中でピクピクするのが大好きです。"

    # say L295 whi
    old "I can feel you getting close!"
    new "感じてるわ、もうすぐだね！"

    # say L296 whi
    old "Do it, cum in my mouth!"
    new "やって、私の口の中で射精して！"

    # say L297 whi
    old "I'll swallow it all!"
    new "全部飲み干すわ！"

    # say L298 pla
    old "Ahhhh...."
    new "ああっ……"

    # say L304 whi
    old "Oh, I loved that!"
    new "ああ、それ大好きでしたね！"

    # say L305 whi
    old "You were so excited, and you got soo hard!"
    new "あなたがそんなに興奮して、全然硬くなってましたね！"

    # say L306 whi
    old "I think I'll do this again... "
    new "またこれをするかもしれません…"

    # say L307 pla
    old "M- mrs. White, I think you should clean up before Mike comes back."
    new "ミス・ホワイト、マイクが戻る前に片付けた方がいいと思います。"

    # say L308 whi
    old "Sure, sure, it will be just a second."
    new "はい、はい、すぐです。"

    # say L317 whi
    old "Ah Yes! This big dick is just what I needed today."
    new "ああ、そうです！今日私が必要としていたのはこの大きなちんこだったの。"

    # say L318 whi
    old "I'll never get tired of the smell of your cock."
    new "あなたのちんぽの香りにはいつでも新鮮な気持ちがするわ。"

    # say L319 whi
    old "It's making me so wet!"
    new "これでぐっしょりになっちゃうの！"

    # say L323 whi
    old "Mmm, yes, like that, enjoy it!"
    new "んん、そう、その調子で楽しんで！"

    # say L324 whi
    old "Are you liking it you sweet boy?"
    new "あなた、これが好きなのかわいい男の子？"

    # say L326 pla
    old "I-I am!."
    new "俺、してるの！"

    # say L330 whi
    old "Mmmm! Slrrp! This taste is the best!"
    new "んん！すりゅる！この味が最高です！"

    # say L331 whi
    old "Your dick feels so hot inside my mouth!"
    new "あなたのペニスが私の口中でこんなに熱いなんて！"

    # say L332 whi
    old "Do you like it [pla]?! Tell me!"
    new "好きですか [pla]？！ 言ってください！"

    # say L333 pla
    old "Yes ma'am! I do!"
    new "はい、そうです！好きです！"

    # say L356 whi
    old "Your dick! Is twitching!"
    new "あなたのちんぽ！震えてるわよ！"

    # say L357 whi
    old "I want you to cum! Do it!"
    new "私はあなたが射精するのを待ってるの！お願い！"

    # say L358 pla
    old "I- I'm about to...!"
    new "俺、もうすぐ…！"

    # say L359 whi
    old "Yes! Give me your cum!"
    new "はい！あなたの精液をちょうだい！"

    # say L364 whi
    old "Oh yes! It's always so good to have your dick in my mouth."
    new "ああ、そうよ！あなたのペニスを私の口に感じるの、いつも最高よ。"

    # say L365 whi
    old "I'll never get tired of it."
    new "私はこれに飽きることはないわ。"

    # say L366 pla
    old "Listen, Mrs. White, I think I just heard someone move outside."
    new "白さん、ちょっと外で何か動く音がしたんだけど。"

    # say L367 pla
    old "We should hurry up and..."
    new "急いだ方がいいだろう、白さん。"

    # say L368 whi
    old "What are you talking about?"
    new "何を言っているの？"

    # say L369 whi
    old "We're not done yet."
    new "まだ終わっていませんよ。"

    # say L370 whi
    old "And last time we were interrupted when Mike got home."
    new "前回はマイクが帰ってきて中断されちゃいましたよね。"

    # say L371 whi
    old "So, you're not going anywhere. There's something else that I want right now!"
    new "だから、どこにも行かないで。今すぐ私が必要としているものがあるの！"

    # say L387 whi
    old "Oh! Yes! That's it!"
    new "あら！そうなの！それよ！"

    # say L388 whi
    old "I've been wanting for you to be inside me for a while!"
    new "ずいぶん前から、あなたが私の中に入ってくれることを欲しがっていたの！"

    # say L389 whi
    old "Yes! Like that, move a little faster."
    new "はい！そうよ、もう少し速く動いて。"

    # say L393 whi
    old "Oh boy, oh my sweet boy, yes, keep fucking me."
    new "ああ、私の甘いボーイ、そう、もっと続けて。"

    # say L394 whi
    old "Oh yeah! Oh do you like how my pussy feels?"
    new "ああそう！あたしのオマンコの感じ、好きでしょ？"

    # say L395 pla
    old "Uhh yes, it feels amazing!"
    new "うわ、最高だ！"

    # say L399 whi
    old "Ah! I love your dick!"
    new "あっ！あなたのチ○ポ大好き！"

    # say L400 whi
    old "Do you like that baby? Do you like how I fuck you?"
    new "好きですか、ベイビー？ 私がアナタを犯すのが好きですか？"

    # say L401 pla
    old "I- I think I'm about to finish!"
    new "俺、もう出ちゃいそうだ！"

    # say L402 whi
    old "Not yet, keep going baby boy!"
    new "まだよ、もっと続けてね baby boy！"

    # say L425 pla
    old "M- Mrs. White, I can't hold it anymore!"
    new "白さん、もう我慢できません！"

    # say L426 whi
    old "It's ok, cum inside."
    new "大丈夫よ、中に出して。"

    # say L427 whi
    old "Fill me up sweety!"
    new "私を満たしてちょうだい、 Darling！"

    # say L433 whi
    old "Wow, that was great!"
    new "すごい、それ本当に最高だったわ！"

    # say L434 whi
    old "I'd been wanting to fuck you so bad."
    new "あなたとセックスしたくて仕方がなかったの。"

    # say L435 whi
    old "And you were even better than I imagined you would be."
    new "あなたは私が想像していたよりもずっと良かったです。"

    # say L436 whi
    old "Did you like it too baby boy?"
    new "赤ちゃん、あなたも気に入ったわね？"

    # say L437 pla
    old "Uh, yes, I really did."
    new "うん、本当にそう思った。"

    # say L438 pla
    old "Listen Mrs. White I think it's better if I get dressed and leave."
    new "白さん、服を着て帰った方がいいと思いますね。"

    # say L439 pla
    old "I've been here for a while and I don't want Mike to catch us."
    new "俺はもう少しいるけど、マイクに見つかるのは避けたいな。"

    # say L440 whi
    old "Yeah, I think so too. It would be better."
    new "うん、私もそう思うわ。早く着替えて帰った方がいいね。"

    # say L441 whi
    old "I'll see you and that big cock later."
    new "後でね、その大きなチ○ポの話を後にするわ。"

    # say L454 mik
    old "By the way, let me get back to what I was telling you before."
    new "それでは、前に話してたことを続けさせてもらうけど。"

    # say L455 mik
    old "It was about Belle."
    new "それはベールについてだった。"

    # say L456 mik
    old "She wanted me to ask you if you could let us see the project you did with Hinn."
    new "ベルが俺に頼んでさ、ヒンとやったプロジェクト見せてもらえるかどうか、君に聞いてみてくれって。"

    # say L457 mik
    old "It's for reference, we're very late with it, and she says that since it is my fault that we're late, I should ask you."
    new "参考のためにだよ、かなり遅れてるし、ベルが言ってたんだ、遅れたのは俺のせいだから、君に頼むべきだって。"

    # say L459 mik
    old "Woah, are you ok dude? You look kinda tense."
    new "おわ、大丈夫か？ 顔色がちょっと悪そうだけど。"

    # say L460 pla
    old "Yeah... it's just... the sauce. I think it had something spicy in it."
    new "ああ…ただ…ソースがね。多分何か辛いものが入ってたんだと思う。"

    # say L461 mik
    old "Yeah, I think my mom put some chili in it, but it's very good anyway."
    new "うん、多分母が唐辛子入れたんだと思うけど、それでもめちゃくちゃうまいよ。"

    # say L462 pla
    old "I- it is. Yeah she is really good..."
    new "うん、そういえば本当にうまいな。"

    # say L463 pla
    old "Uhhh... You need the project? Sure."
    new "うーん… プロジェクトが必要？もちろん。"

    # say L464 pla
    old "I- I have it on my... Mmmm... computer, I'll email it to you."
    new "俺- 俺の... ムム... コンピューターに入ってる、メールで送るよ。"

    # say L465 mik
    old "Really? Thanks man you are the best."
    new "本当に？ありがとう、お前最高だな。"

    # say L484 mik
    old "Oh, I forgot, Olivia told me she saw you the other day when she was leaving."
    new "オ、そういえば、オリビアが先日君と会ったって言ってたよ。"

    # say L485 pla
    old "Uh?..."
    new "うっ？..."

    # say L486 pla
    old "Oh yeah, I- I think we... crossed over... Ahh... on the way out."
    new "ああ、そうか……俺も彼女と……すれ違ったっけ……アッ……出ていくときだ。"

    # say L487 mik
    old "Hmm... Yeah, that's what she told me. But dude, she was super angry about running into you."
    new "うん、そう言われたけど、 Dude、彼女は君に会ったことめちゃくちゃ怒ってたよ。"

    # say L488 mik
    old "Please, don't tell anyone dude, or she won't talk to me anymore. Please?"
    new "お願い、誰にも言わないでくれ Dude、そうでないと彼女が私に話しかけなくなるから。お願い？"

    # say L489 pla
    old "S- Sure... no problem!"
    new "わかった... 大丈夫だよ！"

    # say L491 mik
    old "Thank you, you are a really good friend."
    new "ありがとう、お前は本当に良い友達だな。"

    # say L510 mik
    old "Dude, you sure you are ok?"
    new "お前、大丈夫なのか？"

    # say L511 pla
    old "Mmm... Y- yeah... Ugh, sure... N- no problem."
    new "うん… 大丈夫… あー、もちろん… 問題ないさ。"

    # say L512 mik
    old "You should drink some water."
    new "水を飲んだ方がいいぞ。"

    # say L514 pla
    old "Hmm, I'm definitely not the only one who will drink something."
    new "俺だけが飲むわけじゃねえよ。"

    # say L516 pla
    old "Oh... Never mind, it's just the spice talking here."
    new "オッ、気にするな、単に辛さが効いてるだけだ。"

    # say L554 mik
    old "Dude, I'm starting to get worried. You look like you're about to burts. Here, let me hand you..."
    new "おい、心配になってきたぞ。お前、今にも爆発しそうだな。これ、持て…"

    # say L555 pla
    old "N- no... i- it's ok, I'm just feeling a little bad."
    new "ん…大丈夫、ちょっと具合が悪いだけだよ。"

    # say L556 pla
    old "Just give me a minute."
    new "ちょっと待っててくれ"

    # say L557 mik
    old "Are you sure? I think you should relax and release everything."
    new "大丈夫なのか？リラックスして全部出しちゃってもいいと思うけど。"

    # say L558 pla
    old "Ughh... That's exactly what I'm going to do..."
    new "うげっ… それがまさに今やろうとしてるんだよ…"

    # say L578 whi
    old "Mmmm! It's so big, so thick and long!"
    new "うふふ、こんなに大きいの、太くて長い！"

    # say L579 whi
    old "I was waiting for this, baby boy!"
    new "待ってたの、ベイビーボーイ！"

    # say L580 whi
    old "That's it, fill me up!"
    new "それがいい、いっぱい私を満たして！"

    # say L584 whi
    old "Ahhh! Mmmm!!"
    new "アーッ！ムムム！！"

    # say L585 whi
    old "I love how hot your cock is in my pussy!"
    new "あなたの熱いペニスが中に入っているのが大好きです！"

    # say L586 whi
    old "I can feel it filling me up!"
    new "感じてる、中でいっぱいになってくのが！"

    # say L587 whi
    old "It's so big and hot!"
    new "大きいの、熱いのだわ！"

    # say L591 whi
    old "Oh god! This dick! I love it!"
    new "ああっ！このチ○ポ！大好き！"

    # say L592 whi
    old "MMMM! AAAAH! Yes! Yes!"
    new "MMMM！ AAAAH！ はい！はい！"

    # say L593 whi
    old "I love your cock sweetie!"
    new "あなたのちんこ大好きよ、スイートピー！"

    # say L594 whi
    old "I love to feel your cock inside me my baby boy!"
    new "あなたのちんこが私の中にあるのを感じるの大好きです、ベイビー！"

    # say L617 pla
    old "I-I'm about to finish Mrs. White!"
    new "俺、もう出ちゃいそう、ミス・ホワイト！"

    # say L618 whi
    old "YES! YES! ME TOO!"
    new "はい！はい！私も一緒にイキたい！"

    # say L619 whi
    old "Do it! Cum in my pussy!"
    new "やって！ 私のオマンコでイッて！"

    # say L620 whi
    old "Do it my sweet baby!"
    new "やって、私の甘い赤ちゃん！"

    # say L624 whi
    old "Phew, that was amazing!"
    new "ふう、それはすごかったわ。"

    # say L625 pla
    old "Ohh yeah."
    new "オッ、そう。"

    # say L640 whi
    old "H- Hi son, I- I'm ok."
    new "あ、こんにちは息子、大丈夫です。"

    # say L641 whi
    old "I wasn't expecting you to come home so quickly."
    new "早く帰るとは思わなかったわ。"

    # say L643 mik
    old "Yeah, me either. But Olivia said she had to take care of some personal things."
    new "うん、俺もそう思ってたけど、オリビアが個人的な用事があるって言ってたからな。"

    # say L644 mik
    old "So, I had to come early."
    new "だから、早めに帰ってきちゃったんだ。"

    # say L645 whi
    old "Oh, I see, well..."
    new "なるほど、そうね…"

    # say L646 whi
    old "Since you have some free time, why don't you go up to your room and play some video games?"
    new "時間があるなら、部屋でビデオゲームでもしてみたらどうですか？"

    # say L647 whi
    old "Or just relax, you've been studying a lot these days, you deserve a break."
    new "あるいはゆっくりしてもいいわ、最近は勉強ばっかりで疲れているでしょう、少し休むのも良いわよ。"

    # say L648 mik
    old "Sure, but first I'm going to grab a snack from the kitchen."
    new "分かったけど、まずはキッチンでスナックを取ってくるよ。"

    # say L654 whi
    old "Wait!"
    new "待って！"

    # say L655 mik
    old "What? What happens?"
    new "何？どうしたの？"

    # say L656 whi
    old "Ehhh... Just, I know you're tired."
    new "えぇっと… ただ、あなたが疲れているのはわかっていますから。"

    # say L657 whi
    old "So, why don't you just go up and I'll prepare and bring you some snacks?"
    new "じゃあ、上に上がって、私がおやつを用意して持っていきますね。"

    # say L658 mik
    old "Wow, really?"
    new "ほんとですか？"

    # say L659 whi
    old "Yeah sure, just go up and I'll be there in a bit."
    new "はい、大丈夫よ。上がっていて、すぐに行くから。"

    # say L660 mik
    old "Ok, thanks mom!"
    new "Ok、ありがとう、ママ！"

    # say L666 whi
    old "Phew, that was really close"
    new "ふう、本当に危なかったわね。"

    # say L667 pla
    old "I knew he was going to catch us!"
    new "俺が知ってたよ、絶対に捕まえると思ってた！"

    # say L668 pla
    old "We should have gone to your room!"
    new "君の部屋に行けばよかった！"

    # say L669 whi
    old "Calm down, he didn't see anything."
    new "落ちついて、何も見られなかったわ。"

    # say L670 whi
    old "But we don't have time to talk about that."
    new "でも、そんな時間ないわ。"

    # say L675 mik
    old "Mom! Do you think you could bring me a soda with the snacks?"
    new "ママ！おやつと一緒にジュースも持ってきてもらえるかな？"

    # say L677 whi
    old "Now, quickly, leave!"
    new "さっさと出て行って！"

    # say L678 pla
    old "Ok, ok, I'm going!"
    new "分かった分かった、行きます！"

    # say L692 whi
    old "Ah! Ah! Ah! That's it sweety, fuck me just like that."
    new "あっ！あっ！あっ！そうよ、そのまま私を突いて。"

    # say L693 whi
    old "I- I can feel your entire dick! It's so long and thick!"
    new "あ、あ、あ、あなたのペニスが全部入ってるのを感じるの！こんなに長いの！"

    # say L694 whi
    old "Yes! This is just what I wanted!"
    new "はい！これが私欲しかったの！"

    # say L698 whi
    old "Ah! It's so good!"
    new "ああ！すごくいいです！"

    # say L699 whi
    old "Mmm I love your big cock!"
    new "ああ、あなたの大きなチ○ポが大好きです！"

    # say L700 whi
    old "Ohh yeah, just like that baby!"
    new "ああ、そう、その調子で！宝贝～"

    # say L704 whi
    old "Fuck! YES! YES! FUCK ME MORE!"
    new "ファック！イエス！イエス！もっとファックして！"

    # say L705 whi
    old "Fuck me, fuck your mommy!"
    new "私を犯して、あなたのママを犯して！"

    # say L706 whi
    old "Keep pounding me!"
    new "もっと突いて！"

    # say L729 whi
    old "I- I can feel you tensing up!"
    new "ああ、あなたが緊張してるの、感じちゃう！"

    # say L730 whi
    old "Do it! CUM! CUM INSIDE ME!"
    new "やって！ 出して！ 私の中に出して！"

    # say L731 pla
    old "Y-yes!"
    new "Ｙ－はい！"

    # say L732 whi
    old "Ahhh! This is the best cock I've ever had!"
    new "ああっ！これほど素晴らしいちんぽは初めてよ！"

    # say L738 whi
    old "That was very good sweety!"
    new "それはとても良かったわね、スイーティ。"

    # say L739 whi
    old "You keep doing it better and better. You just keep making me want that cock even more every time..."
    new "あなたは本当に上手くなっていくわ。毎回あなたのチ○ポが欲しくなってきちゃうの..."

    # say L740 pla
    old "I'm glad you liked it Mrs. White."
    new "白さん、気に入っていただけて嬉しいです。"

    # say L741 whi
    old "I didn't just like it, I loved it!"
    new "好きだったんじゃない、大好きだったわ！"

    # say L742 whi
    old "And I hope you know we'll be doing it again very soon."
    new "そしてすぐにまたやることを望んでいるわ。"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Lydia.rpy
translate japanese strings:

    # say L60 lyd
    old "No Anna, you can't live your life like this."
    new "アンナ、そうやって人生を過ごしてはダメよ。"

    # say L62 ann
    old "I'm already big enough to decide what I do with my life."
    new "私はもう自分で人生を決められるくらい大きくなったわ。"

    # say L64 lyd
    old "Yes, but in recent weeks you have been drinking excessively and even using drugs!"
    new "そう、でも最近君は酒を飲みすぎてるし、薬まで使ってることがあるじゃないか！"

    # say L66 lyd
    old "I'm very worried about you, about your health, I know your father's loss was not easy, it hurts me a lot too-"
    new "心配してるの、君の健康のこと。父親を失ったのは簡単なことじゃなかった、私もすごく辛い思いをしたよ…"

    # say L68 ann
    old "it has nothing to do with it... I just want to enjoy my life, I don't want to live locked up and self-conscious like... You."
    new "それは関係ないよ… 私はただ人生を楽しんでいたいだけ、自分を閉じこめて、常に意識しているような生活はしたくない… あなたみたいに。"

    # say L76 ann
    old "Anyway... Don't wait for me tonight..."
    new "でも... 今夜は待たないでね..."

    # say L80 lyd
    old "I'm sorry you heard that... Things have not been very easy for either of us."
    new "ごめんなさい、そんなこと聞かせちゃって… お互い最近大変だったよね。"

    # say L82 pla
    old "I'm very sorry, I just came to accompany you a little..."
    new "ごめん、ちょっと寄っただけだったんだ…"

    # say L85 lyd
    old "Aww thank you very much pumpkin."
    new "あわ、ありがとう pumpkin。"

    # say L87 lyd
    old "But you don't have to worry, I know you have your things to do, and at the moment I don't feel very well."
    new "でも心配しないで、あなたの事情は分かってるから。今はちょっと体調がよくないだけよ。"

    # say L89 pla
    old "Hmm, is it because of the discussion with Anna?"
    new "うん、アンナとの話し合いのせいかな？"

    # say L91 lyd
    old "Yes honey, she was greatly affected by her father's death and has been... Quite bad lately."
    new "うん、彼女は父親の死に深く影響を受けているの。最近、かなり辛そうよ。"

    # say L93 pla
    old "I understand, I can come another day if you want."
    new "分かった、君がそうしたいなら別の日に来てもいいよ。"

    # say L95 lyd
    old "You know what? Yes, come over the weekend and come with me to church, are you okay with that?"
    new "知ってる？週末に来て、一緒に教会に行こうよ、どう？"

    # say L97 pla
    old "Perfect! I will come in the weekend."
    new "Perfect！ 週末に行くよ。"

    # say L99 lyd
    old "Great, thank you for your visit and support honey, I really appreciate it."
    new "ありがとう、来てくれて助かったわ、ほんとにお世話になったわ。"

    # say L101 pla
    old "Don't worry, I'm glad for helping you..."
    new "心配しなくていい、君のために手伝えて嬉しいよ。"

    # say L120 lyd
    old "Oh hi pumpkin, did you come to help me with the dating app?"
    new "あら、こんにちはピューパン、デートアプリの手伝いに来たの？"

    # say L121 pla
    old "Uhh yeah, how's it going?"
    new "うーん、そうか、どうしてる？"

    # say L122 lyd
    old "Well, remember we have to do it in the afternoons, because Anna is here in the mornings..."
    new "ええ、覚えててほしいんだけど、午後じゃないとダメなの。朝はアンナがいるから……"

    # say L123 pla
    old "Ohh, you're right! I'm sorry, I totally forgot."
    new "オッ、そうだった！ごめん、完全に忘れてた。"

    # say L124 lyd
    old "Don't worry pumpkin, just come back in a few hours."
    new "心配しないでかぼちゃ、数時間後にまた来てね。"

    # say L125 pla
    old "Alright, see you later then."
    new "分かった、後でな。"

    # say L126 lyd
    old "See you later."
    new "じゃあ、またね。"

    # say L135 lyd
    old "Hey pumpkin, did you come to accompany me to church?"
    new "ねえ、かぼちゃ、教会に連れて行ってくれるの？"

    # say L137 pla
    old "Of course, are you ready?"
    new "もちろん、準備はできてる？"

    # say L139 lyd
    old "Sure, let's go!"
    new "もちろん、行こう！"

    # say L146 lyd
    old "Thank you so much for joining me to this mass in commemoration of my husband."
    new "ありがとうございます、夫の追悼ミサに一緒に来てくれて。"

    # say L148 pla
    old "Don't worry, it's a pleasure to share with you."
    new "心配しないで、君と一緒にいられて嬉しいよ。"

    # say L150 lyd
    old "Oh honey, you don't know how important is the support like yours right now."
    new "あたし、あなたがいてくれるだけでどれだけ心強いか知りません。"

    # say L153 jon
    old "Hi Lydia, I'm so sorry for your husband, how have you been these past few week?"
    new "リディア、ご主人のこと本当に申し訳ありません。この数週間、お元気ですか？"

    # say L155 lyd
    old "Coping with patience, Mrs. Jones."
    new "耐え忍びました、ジョーンズさん。"

    # say L157 jon
    old "Yes, I understand you perfectly, I also lost my husband 5 years ago."
    new "はい、あなたの気持ちよく理解しています、私も５年前に主人を亡くしました。"

    # say L159 jon
    old "Do you know what helped me? Praying and approach to God."
    new "私を支えてくれたのは何だと思います？祈りと神様への近づき方でした。"

    # say L161 lyd
    old "Yes Mrs. Jones, that's the best."
    new "はい、ジョーンズさん、それが一番です。"

    # say L164 jon
    old "I will continue coming to church everyday, giving my life to the lord."
    new "私は毎日教会に通い続け、人生を主にささげます。"

    # say L166 lyd
    old "Yes... He comforts us..."
    new "はい……彼は私たちを慰めてくれるわ……"

    # say L168 jon
    old "There's nothing like being faithful to the Lord all your life, right Lydia?"
    new "生涯を神様に捧げることは、他には代えがたいものよね、リディア。"

    # say L170 lyd
    old "Sure... Excuse me Mrs. Jones, I have to go, I hope to see you soon."
    new "はい……失礼します、ジョーンズ夫人。またお会いできるのを楽しみにしています。"

    # say L172 jon
    old "Okay Lydia, remember that this is the house of God and here you will always be welcome."
    new "オーケー、リディア。神の家であることを覚えておいて、ここではいつでも歓迎されるわ。"

    # say L174 lyd
    old "Let's go [pla]."
    new "行きましょう [pla]。"

    # say L182 pla
    old "Are you feeling alright? You seem a little disturbed."
    new "大丈夫か？君、ちょっと落ち着かないみたいだな。"

    # say L184 lyd
    old "Did you hear what Mrs. Jones said?"
    new "ジョーンズさんが言ったこと、聞いた？"

    # say L186 pla
    old "Yes, she is a very religious woman, will you accompany her to church?."
    new "そうだ、彼女は本当に宗教心の強い人だな。教会に連れて行くか？"

    # say L188 lyd
    old "No, no, you don't understand..."
    new "いいえ、いいえ、わかってないよ…"

    # say L190 lyd
    old "I've been thinking... After so many years, I have never lived my life..."
    new "考えてたの... 何年も経って、私は自分の人生を生きてこなかった..."

    # say L194 lyd
    old "[pla], I've never lived, I've always been a homely woman, I haven't really felt happy."
    new "[pla]、私は生きてきたことがないの、いつも地味な女で、本当の幸せを感じたことがなかった。"

    # say L196 lyd
    old "You know when you reach a certain age you start looking back and see what you've lived..."
    new "ある程度の年になると、振り返って自分の人生を見てみるのよね…"

    # say L198 lyd
    old "And after so many years I had conformed to what it should be like."
    new "そして何年も経って、自分がどうあるべきかに合わせて生きてきた。"

    # say L200 lyd
    old "But after listening to Mrs. Jones... That's not what I want for my life."
    new "でも、ミス・ジョーンズの話を聞いて……それが私の人生じゃないって思ったの。"

    # say L204 lyd
    old "I already gave my whole life to a man, now he isn't here anymore, I don't want to stay locked up in a church now either."
    new "もう一生を男の人に捧げてしまったのに、今では彼はいない。だから今さら教会に閉じこもる気もないよ。"

    # say L208 lyd
    old "I don't want to be like Mrs Jones in 5 years, it's not what I want for my life..."
    new "5年後、私はMrs Jonesみたいにはなりたくないの。それが私の人生じゃないから…"

    # say L210 pla
    old "Then, what will you do?"
    new "じゃあ、これからどうするの？"

    # say L212 lyd
    old "I think Anna is right... I have to start living my life, live new experiences."
    new "Annaさんの言う通りだと思う… 私は自分の人生を生きなきゃいけない、新しい経験をしていかないと。"

    # say L214 lyd
    old "You know? I never had sex with any other man... I really don't know if I enjoyed sex at least!"
    new "知ってる？私、他の男の人とセックスしたことがないの…本当にSEXが楽しかったのかさえわからないの！"

    # say L218 lyd
    old "Today was a revelation for me... and I don't want to bother you anymore."
    new "今日が目覚めの日だった……もう君を困らせたくない。"

    # say L220 lyd
    old "Thank you very much for your company, these days I will be thinking about what I should do with my life."
    new "この日 Shooter、あなたの付き添いありがとう、これらの日私は私の人生について何を考えるべきか考えているでしょう。"

    # say L222 pla
    old "I understand, if you need anything just let me know..."
    new "分かってる、何か-needed-あったら教えてくれ……"

    # say L224 lyd
    old "In fact I think if I'm going to need several things from you..."
    new "実はね、いくつか頼むことあるかもと思って…"

    # say L228 lyd
    old "Never mind, see you later pumpkin."
    new "気にしないで、またね、かぼちゃ。"

    # say L243 lyd
    old "Hi Honey, remember that I need you to accompany me to the church the weekend."
    new "こんにちは honey、週末に教会に連れて行ってくれること覚えてるよね。"

    # say L245 pla
    old "Ohhh, of course, no problem, I'll be here on the weekend."
    new "オッケー、もちろん、週末はここにいるよ。君のことを待ってるぜ。"

    # say L247 lyd
    old "Thank you very much pumpkin!"
    new "ありがとう、かぼちゃ！"

    # say L254 lyd
    old "Hi Honey, do you need me?"
    new "ハイハニー、何か必要？"

    # say L256 pla
    old "Oh no, sorry, I was just walking around."
    new "ああ、ごめん、ただ散歩してたんだ。"

    # say L258 lyd
    old "Ok, pumpkin"
    new "大丈夫、かぼちゃちゃん"

    # say L286 pla
    old "Sorry, I was just walking around."
    new "ごめん、ただ散歩してたんだ。"


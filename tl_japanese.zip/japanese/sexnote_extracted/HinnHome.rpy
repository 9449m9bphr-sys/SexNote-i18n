# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/HinnHome.rpy
translate japanese strings:

    # say L20 pla
    old "I should find a therapist and talk with Mrs. Jade first."
    new "まずはジェイド先生と話すべきだな。"

    # say L26 pla
    old "I should talk with Mrs. Jade first."
    new "まずはジェイド先生と話すべきだな。"

    # say L32 pla
    old "I should talk with Dr. Johnson first."
    new "まずは Dr. Johnson と話すべきだな。"

    # say L91 pla
    old "Hey Hinn!"
    new "Hey Hinn！"

    # say L93 hin
    old "Hi [pla], how are you doing?"
    new "こんにちは [pla]、調子はどう？"

    # say L95 pla
    old "Great and you?"
    new "元気だよ、君は？"

    # say L97 hin
    old "I'm fine. I wanted to ask you if you've shown our progress to Mrs. Mia?"
    new "私は大丈夫。Mrs. Mia に私たちの進捗を見せたかどうか聞きたかったの。"

    # say L99 pla
    old "Oh sorry. I haven't yet."
    new "すみません、まだできてないよ。"

    # say L101 hin
    old "Well, we should do it before continuing."
    new "じゃあ、それをする前に進むべきだね。"

    # say L103 pla
    old "Ok, doing it now."
    new "わかった、今やるよ。"

    # say L112 hin
    old "Hi, [pla]..."
    new "あい、[pla]…"

    # say L114 pla
    old "Hey, Hinn... I wanted to talk about yesterday."
    new "Hey、Hinn... 昨日のことについて話したいんだけど。"

    # say L116 hin
    old "Oh... Listen... I'm so sorry. I shouldn't have got you into all this. It's my fault..."
    new "あっ…聞いて…本当にごめんなさい。あなたをこんなことに巻き込んでしまって、全部私の fault... のせいだから…"

    # say L118 pla
    old "No, no, I agreed to help, in fact I think it was... fun."
    new "いや、いや、手伝うって言ったのは俺だしさ。実際、楽しかったよ。"

    # say L122 pla
    old "Yes, I liked helping. Also, I think your mom did everything with good intentions."
    new "うん、手伝って楽しかったよ。それに、お母さんも善意でやってたと思う。"

    # say L124 hin
    old "Hmm... Maybe in her own way. But you're probably right."
    new "うーん… 好意的にやってたのかもしれないけど、あなたが言っている通りかもね。"

    # say L126 pla
    old "I really think you look good with any clothes you decide to wear, the most important thing is that you feel good about yourself."
    new "君が着る服は全部似合ってるよ、一番大事なのは自分に自信を持つことだよ。"

    # say L129 hin
    old "Thank you, [pla]. (He's so sweet.) I really appreciate it..."
    new "ありがとう、[pla]。 （優しい人だな。）本当に感謝してるよ…"

    # say L131 pla
    old "My pleasure... Well, should we continue with the class project?"
    new "俺の pleasure... それじゃ、授業のプロジェクトを続けようか？"

    # say L134 hin
    old "Yes, lets do it."
    new "うん、やろうか。"

    # say L136 pla
    old "Great."
    new "いいね。"

    # say L154 pla
    old "Wow Hinn, you changed your outfit..."
    new "Wow Hinn、服変えたのか…"

    # say L156 hin
    old "Well... I wanted to try something new... What do you think?"
    new "えっと……新しいのを試してみたの……どう思う？"

    # say L158 pla
    old "You look great."
    new "君はすごくかっこいいね。"

    # say L162 pla
    old "Yes, but the most important thing is how do you feel?"
    new "そうだ、でも一番大事なのは君がどう感じてるかだよ。"

    # say L165 hin
    old "Hmmm, I feel comfortable, the sessions with Dr. Johnson worked."
    new "うん、リラックスしてるわ、ドクター・ジョンソンとのセッションが効果的だったみたい。"

    # say L169 hin
    old "Actually, we have a new session today."
    new "実は今日新しいセッションがあるのね。"

    # say L171 pla
    old "Oh perfect, are you ready?"
    new "よし、準備はできてるか？"

    # say L173 hin
    old "Yes, let's go."
    new "はい、行きましょう。"

    # say L189 hin
    old "I'm fine, thanks."
    new "大丈夫、ありがとう。"

    # say L191 pla
    old "I was wondering if you have a scheduled a new session with Dr. Johnson."
    new "ジョンソン博士との新しいセッションを予定してるか気になってさ。"

    # say L193 hin
    old "Yes, tomorrow morning don't worry."
    new "はい、明日の朝だから心配しないで。"

    # say L195 pla
    old "Oh great, see you tomorrow then."
    new "じゃあ、明日な。"

    # say L200 hin
    old "Wait..."
    new "待って..."

    # say L202 hin
    old "We could... Practice again... If you want."
    new "また練習できるわ... 欲しければね。"

    # say L207 pla
    old "Sounds great."
    new "それいいね。"

    # say L209 hin
    old "Nice."
    new "いいな。"

    # say L216 pla
    old "That sounds great, but I can't right now."
    new "それいいけど、今ちょっと無理だな。"

    # say L218 hin
    old "Oh don't worry, see you tomorrow then."
    new "心配しなくていい、明日ね。"

    # say L220 pla
    old "Great, see you."
    new "じゃあ、またね。"

    # say L227 hin
    old "Great!."
    new "すごい！"

    # say L245 pla
    old "I was wondering if you you have a scheduled a new sesión with Dr. Johnson."
    new "ヒン、君はDr. Johnsonとの新しいセッションを予定してるのか？"

    # say L251 hin
    old "See you."
    new "またね。"

    # say L296 pla
    old "No, no, sorry I was just walking around. I have to go."
    new "いやいや、すみません。ただ歩いていただけです。行かないと。"

    # say L313 pla
    old "Hey, Hinn."
    new "Hey, Hinn。"

    # say L315 hin
    old "Hi [pla], Are you ready to start?"
    new "あたし、準備できてるよ、[pla]。"

    # say L319 pla
    old "Yes, I'm ready. Let's get to it."
    new "はい、準備できてるよ。さっそく始めよう。"

    # menu L324 
    old "Not"
    new "今日は君と仕事できないんだ。"

    # say L326 pla
    old "Actually, I come to tell you I can't work with you today."
    new "実は、今日君と仕事できないんだ。"

    # say L328 hin
    old "Oh, ok, don't worry we could work tomorrow on the class project."
    new "あ、そうね、心配しないで。明日クラスのプロジェクトに取り組めばいいよ。"

    # say L330 pla
    old "Of course, tomorrow we will be working hard!"
    new "もちろん、明日はがんばるぞ。"

    # say L332 hin
    old "Hehehe great, see you."
    new "へへへ、じゃあ明日ね。"

    # say L334 pla
    old "See you Hinn."
    new "またね、ヒン。"

    # say L363 pla
    old "Damn, are we done? Really?"
    new "ほんと、終わりなの？マジで？"

    # say L365 hin
    old "Yup... Looks like that's everything..."
    new "うん…これで全部終わったのね…"

    # say L367 pla
    old "Hinn? You look sad. You ok?"
    new "ヒン？君、悲しそうだな。大丈夫？"

    # say L369 hin
    old "Yeah, I'm fine... I'm happy we finally finished this project..."
    new "うん、大丈夫… 終わって良かったわ…"

    # say L371 pla
    old "Really?..."
    new "本当に？…"

    # say L373 hin
    old "Yes, it's nothing. Don't worry. Just give the final project to Mrs. Mia tomorrow and let me know what she says. Ok?"
    new "はい、大丈夫よ。心配しないで。最終課題をミア先生に明日提出して、感想を教えてね。いい？"

    # say L375 pla
    old "Alright, Hinn. No problem."
    new "分かった、ヒン。問題ないよ。"

    # say L377 hin
    old "See you tomorrow, [pla]."
    new "明日ね、[pla]。"

    # say L380 pla
    old "See you tomorrow, Hinn."
    new "明日ね、ヒン。"

    # say L396 pla
    old "Well, we made a lot of progress!"
    new "WELL、結構進んだな！"

    # say L398 hin
    old "Yes, it's a little late. We should continue tomorrow."
    new "うん、少し遅いね。明日続けよう。"

    # say L400 pla
    old "Ok, see you tomorrow, Hinn. Have a good night."
    new "分かった、明日ね、ヒン。良い夜を。"

    # say L402 hin
    old "By the way, remember to show Mrs. Mia our progress, let her know how far we've come. See you tomorrow."
    new "それにしても、ミア夫人に進捗を見せることを忘れないで。どれだけ進んだか教えて。また明日ね。"


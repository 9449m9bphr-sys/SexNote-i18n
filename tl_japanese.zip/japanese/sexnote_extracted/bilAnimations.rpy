# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/bilAnimations.rpy
translate japanese strings:

    # say L6 lin
    old "Wow! I see you've a lot of energy repressed... Big and impressive."
    new "わあ！エネルギーが溜まってるんだね… 大きくて立派だね。"

    # say L7 pla
    old "... I guess..."
    new "……そうなのか……"

    # say L8 pla
    old "Hmm..."
    new "うーん…"

    # say L13 lin
    old "Ohh it tastes great! I really like it."
    new "オッ、美味い！本当に気に入った。"

    # say L19 lin
    old "Oh yeah... Give it to me... Give me all your load!"
    new "オッ、ヤッ…もっとちょうだい…全部ちょうだい！"

    # say L44 lin
    old "Ahhh... I'm feeling it on my mouth!"
    new "アーッ……口の中で感じてる！"

    # say L49 lin
    old "Hmmm, It was great... Now I need your dick inside, the energy transfer should be done now."
    new "ふむ、最高だったわ… 今度はあなたのチ○ポを中に入れて、エネルギーの移転は終わったから。"

    # say L71 lin
    old "Oh yeah... I haven't felt this in a long time ..."
    new "ああ、そう…… こんな感覚は久しぶりだ……"

    # say L76 lin
    old "Wow is huge and is drilling this girl..."
    new "Wow、大きいわ… この子を貫いてる…"

    # say L82 lin
    old "Ohhh yeahhh, harder, harder!"
    new "オッホッホ、もっと強く、もっと強く！"

    # say L83 lin
    old "Don't stop! Gimme more! I want it all!"
    new "止めてないで！もっとくれ！全部欲しい！"

    # say L107 lin
    old "Ahhhhh.... Yeah!"
    new "ア─────ッ.... やっぱり！"

    # say L108 pla
    old "Wow... Ahhhhhhhh!"
    new "おわ... アHHHHHHH！"

    # say L113 pla
    old "Pfff... "
    new "ふっ……"

    # say L124 bel
    old "Hmm, Billie has really big boobs, isn't she [pla]?"
    new "Billieの胸って本当に大きいよね、[pla]？"

    # say L125 pla
    old "Ohh yeah..."
    new "オッ、そうか"

    # say L130 bel
    old "How does it feel to get your boobs sucked Billie?"
    new "比利の胸を吸われてどんな感じがするの？"

    # say L131 bil
    old "I'm not gonna lie, it feels pretty nice."
    new "うん、正直かなり気持ちいいな。"

    # say L137 bel
    old "Woahh, [pla] are you getting excited?"
    new "Woahh、[pla]、もう興奮しちゃってるの？"

    # say L138 bil
    old "Mmm, I'm really enjoying it..."
    new "うん、本当に気持ちいい..."

    # say L139 bel
    old "Mmm..."
    new "んん…"

    # say L162 bil
    old "All right, I think is enough."
    new "もういいわ、これで十分だと思う。"

    # say L173 bel
    old "So Billie? Do you like that big dick in your mouth?"
    new "比利、その大きなちんこを口に感じるのは好き？"

    # say L174 bil
    old "Mmmm."
    new "んんん。"

    # say L175 bel
    old "Yeah, I bet you do. Just enjoy it."
    new "うん、そうだろうな。楽しんでればいいの。"

    # say L181 bel
    old "Keep going, you have to do it well. Are you enjoying it [pla]?"
    new "もっと続けて、上手くやらないと。楽しんでるよね [pla]？"

    # say L182 pla
    old "Uhh... Mmm..."
    new "うっ… んん…"

    # say L183 bel
    old "He's enjoying it Billie!"
    new "彼、楽しんでるよ、ビリー！"

    # say L184 bil
    old "Gulp."
    new "ごく。"

    # say L189 bil
    old "Slurrp, I- I can feel you getting even harder."
    new "スルル、あ、あたし、もっと硬くなってるのを感じてる。"

    # say L190 bel
    old "He's close Billie! Keep going!"
    new "彼、もうすぐだよビリー！そのまま続けて！"

    # say L191 pla
    old "Ahhh, ahhhh!"
    new "アhh、アhh！"

    # say L215 bel
    old "That's it Billie! Just like that."
    new "その通りビルリー！そのまま続けて。"

    # say L216 pla
    old "Ahh! I- I'm cumming!"
    new "ああ！ 出る、出ちゃう！"

    # say L221 bil
    old "Ugh, duuude, you came all in my mouth!"
    new "うわ、だめぇ、全部私の口に来ちゃった！"

    # say L222 bil
    old "And Belle had already told you to be careful!"
    new "ベルはもう気をつけるって言ってたじゃん！"

    # say L223 pla
    old "S- sorry, I couldn't stop myself."
    new "すみません、止まらなくて。"

    # say L224 bel
    old "Yeah, he does come a lot, doesn't he?"
    new "うん、彼はよく来るよね。"

    # say L225 bil
    old "He does, anyway, help me clean myself."
    new "そうよね、私をきれいにするの手伝って。"

    # say L226 pla
    old "S- sure..."
    new "うーん、分かったよ…"

    # say L239 pla
    old "Oh God... [bil]..."
    new "おお神… [bil]…"

    # say L240 bil
    old "Mmm... you taste even better than I remembered."
    new "むむ... あなたは私が思い出していた以上に美味しいわ。"

    # say L241 pla
    old "This feels... insane."
    new "これって… 狂ってるな。"

    # say L242 bil
    old "Good. That's the point."
    new "いい、それが目的だ。"

    # say L247 bil
    old "A little faster now..."
    new "もっと速くして..."

    # say L248 pla
    old "Yes... please... don't stop."
    new "はい…お願い…止めるな。"

    # say L249 bil
    old "Your cock's throbbing... love feeling you like this."
    new "あなたのペニスが脈打ってる…こんな感じが大好き。"

    # say L254 bil
    old "Harder... give me more."
    new "もっと強く…もっとちょうだい。"

    # say L255 pla
    old "[bil]... I'm close..."
    new "[bil]… もうすぐだ…"

    # say L256 bil
    old "Yeah? Cum for me. Fill my mouth."
    new "あら？私の口にかけて。いっぱい出して。"

    # say L257 pla
    old "Oh fuck... yes!"
    new "オッシャイ… やべえ、出る！"

    # say L281 pla
    old "I- I'm cumming—!"
    new "俺、出るよ—！"

    # say L282 bil
    old "Mmm... give it all to me."
    new "mmm... 全部私にちょうだい。"

    # say L283 bil
    old "Every drop... that's it."
    new "毎一滴……それだね。"

    # say L290 pla
    old "That was... wow."
    new "それが…凄いな。"

    # say L291 bil
    old "Better?"
    new "うん、もっと良くなった？"

    # say L292 pla
    old "Uhh, yeah, definetly, t- thank you..."
    new "うーん、そう、ありがとう…"

    # say L293 bil
    old "Alright... we should clean up this mess before my grandma walks in."
    new "じゃあ……この片付けを終わらせないと、婆ちゃんが入ってきちゃうよ。"

    # say L294 pla
    old "Yeah... good idea."
    new "うん…いいアイデアだ。"

    # say L306 pla
    old "Is this okay?"
    new "これでいいのか？"

    # say L307 bil
    old "Oh god, yeah... you're doing it right. Keep the technique."
    new "神様、うん… その通りだ。そのテクニックで続けて。"

    # say L311 bil
    old "Faster now. Rub harder."
    new "もっと速く。強く擦って。"

    # say L312 pla
    old "You're so tight..."
    new "君は本当に締まってるな…"

    # say L313 bil
    old "Deeper. D-don't stop-"
    new "もっと深く。やめてくれない..."

    # say L317 bil
    old "Harder! I want to feel you deeper."
    new "もっと強く！もっと奥まで感じたいの。"

    # say L318 pla
    old "[bil]... you're pulsing..."
    new "[bil]... 脈打ってるな..."

    # say L319 bil
    old "Yes! I'm close!"
    new "うん！ もうすぐイク！"

    # say L320 pla
    old "Oh fuck..."
    new "オイ…"

    # say L344 bil
    old "Oh God... that's it."
    new "ああ…それだよ。"

    # say L350 pla
    old "That was... intense."
    new "それは… 強かったな。"

    # say L351 bil
    old "Phew... yeah, it was nice."
    new "ふう……うん、良かった。"

    # say L352 bil
    old "Better fingers?"
    new "指が上手くなった？"

    # say L353 pla
    old "Way better. Like they woke up."
    new "WAY BETTERだな。指が目覚めたみたいだ。"

    # say L368 bil
    old "Mmm... feel better already?"
    new "mmm... すでに感じが良くなってきた？"

    # say L369 pla
    old "Yeah... tension's melting away."
    new "そうだな…緊張がほぐれていく感じだ。"

    # say L373 bil
    old "Good. Deeper now."
    new "いいね。もっと深くして。"

    # say L374 pla
    old "Fuck... yes."
    new "くそ… うん。"

    # say L378 bil
    old "Cum for me. Let it all out."
    new "私にかけて。全部出しちゃって。"

    # say L379 pla
    old "I'm... close!"
    new "俺、もうすぐだ！"

    # say L402 pla
    old "Ahh— cumming!"
    new "ああっ——出るよ！"

    # say L403 bil
    old "Mmm... that's it."
    new "うん… そうよ。"

    # say L410 pla
    old "Wow... that was... intense."
    new "ああ……それこそ……強烈だったな。"

    # say L411 bil
    old "Feeling better?"
    new "調子は良くなった？"

    # say L426 bil
    old "{i}I used to float... above the ground...{/i}"
    new "{i}私は以前、地面から浮いていたんだ...{/i}"

    # say L427 pla
    old "You're already tensing up... feel that?"
    new "もう緊張してるな…その感覚、感じてる？"

    # say L428 bil
    old "Mmm—keep it slow—notes steady... don't rush me yet..."
    new "mmm—ゆっくりと—音を steady... まだ急いだらダメよ..."

    # say L432 bil
    old "{i}Now every step... just pulls me down...{/i}"
    new "{i}今、一歩ずつ……ただ引きずり下ろされていく……{/i}"

    # say L433 pla
    old "Heart's racing already, huh? Your voice is still holding strong."
    new "心がすでに高鳴ってるのか？ 声はまだしっかりしてるな。"

    # say L434 bil
    old "Yes—fuck—deeper now—everything I wanted... slips right through my hands..."
    new "うん—くそ—もっと深く—これこそ私が欲しかったもの…なのに、全部手から滑り落ちていく…"

    # say L438 bil
    old "{i}And I’m still breathing... but I don’t... understand—{/i}"
    new "{i}まだ息が続いているけど… 分からない—{/i}"

    # say L439 bil
    old "{i}Ahh—fuck—keep going—don't stop—{/i}"
    new "{i}アッ——もっと続けて——止まらないで——{/i}"

    # say L440 pla
    old "You're pulsing around my fingers... you're so close, [bil]."
    new "君の体が俺の指に脈打ってる…もうすぐだな、[bil]。"

    # say L441 bil
    old "Harder—yes—right there—I'm—I'm gonna—"
    new "もっと強く——そう——その通り——あ、私——私、イキそう——"

    # say L464 bil
    old "I-I'm—cumming—fuck—yes—!"
    new "イク——くそ——イイ——！"

    # say L465 bil
    old "Nngh... holy shit..."
    new "ンっ… 神聖なshit… やばい…"

    # say L472 bil
    old "Fuuck..."
    new "くっ…"

    # say L473 pla
    old "... Damn..."
    new "……クソっ……"

    # say L474 bil
    old "Okay... that... was something else."
    new "あの… それ… 何か別だったね。"

    # say L475 pla
    old "You... held it together. Mostly."
    new "お前…なんとか持ちこたえたな。大体は。"

    # say L476 bil
    old "Mostly? I felt the slip at the peak... but I pulled it back. That's progress."
    new "Mostly？ 峰で滑ったけど、何とか戻したわ。これでも進歩よね。"

    # say L477 bil
    old "This method is insane... but it might just work."
    new "この方法は狂ってる…でも、うまくいくかもしれない。"

    # say L478 pla
    old "Yeah... insane in the best way."
    new "そうだな…最高の狂気だ。"

    # say L490 bil
    old "Do you like when I ride you like this?"
    new "このように乗られると気に入ってる？"

    # say L491 pla
    old "Fuck yes... you’re perfect..."
    new "断然やる... 完璧だよ..."

    # say L492 bil
    old "Good boy... keep looking at me."
    new "いい子… ずっと見てて。"

    # say L496 bil
    old "Faster now... bounce with me."
    new "もっと速く……私と一緒に跳ねて。"

    # say L497 pla
    old "Bil... you’re gonna make me lose it..."
    new "ビル… お前がこんなにくると、俺、もう限界だよ…"

    # say L498 bil
    old "Not yet. I want to feel you throb inside me."
    new "まだよ。あなたが中で脈打つ感じをもっとしたいの。"

    # say L502 bil
    old "Harder— give it to me—"
    new "もっと強く……私の中に入れて……"

    # say L503 pla
    old "I’m so close..."
    new "もう出るよ…"

    # say L504 bil
    old "Inside! Cum inside me-"
    new "中で！ 中に出して-"

    # say L527 bil
    old "Yes— fill me up—!"
    new "はい— 私を満たして—！"

    # say L528 pla
    old "Ahh— fuck— cumming— !"
    new "ああっ—— 出るっ——！"

    # say L529 bil
    old "Nngh... that’s it... every drop..."
    new "んん… そうよ… 一滴も逃がさないで…"

    # say L536 bil
    old "Mmm... good boy. That felt so damn good."
    new "うん... 良かったわ、いい子。それ、めちゃくちゃ気持ちよかったよ。"

    # say L537 pla
    old "That was... insane."
    new "それが… 狂ったな。"

    # say L538 bil
    old "Heh. Way better than any vocal warm up, right?"
    new "へへ、声のウォームアップよりずっといいでしょ？"

    # say L539 bil
    old "But we gotta stop... grandma could walk in any second."
    new "でも止めないと……おばあさんが入ってきてしちゃうかもしれないし。"

    # say L540 pla
    old "Right, right..."
    new "そうそう..."

    # say L553 bil
    old "Mmm... feel how soft and warm my ass is rubbing all over your hard cock?"
    new "mmm... お尻がこんなに柔らかくて温かいの、あなたの硬いチ○ポに擦れてるの感じて？"

    # say L554 pla
    old "Fuck... Billie... that feels incredible..."
    new "くそ…ビリー…それが最高に感じる…"

    # say L558 bil
    old "You're throbbing so much between my cheeks. My ass turns you on that bad, huh?"
    new "あなたが私の割れ目で脈打ってるの感じてるわ。私のお尻があなたをそんなに興奮させるのね？"

    # say L559 pla
    old "Yes... don't stop..."
    new "うん... やめないで..."

    # say L563 bil
    old "Do you like feeling my ass? Then cum for me. I want you to finish all over it."
    new "感じるの好き？なら私のアナルに射精して全部出しちゃって。"

    # say L564 pla
    old "Oh God, Billie, don't stop..."
    new "ああ神様、ビリー、やめてくれないで…"

    # say L587 pla
    old "Ahh— fuck— I'm cumming—!"
    new "ああ——くそ——出る——！"

    # say L588 bil
    old "Mmm... yes, that's it. Cum all over my ass."
    new "んん… そう、それよ。全部私の尻に出て。"

    # say L594 bil
    old "Heh... look at the mess you made on me. Someone really liked this outfit."
    new "へへ… 你看你在我身上弄的這一片狼藉。這套衣服真是很對你的胃口啊。"

    # say L595 pla
    old "That was insane... we could've been caught..."
    new "それが狂気の沙汰だな… 見つかるところだったぞ…"

    # say L596 bil
    old "But we weren't. Now help me clean up before that lazy bitch looks up from her phone."
    new "でも捕まらなかったね。さあ、掃除手伝って。あの怠け者がスマホから目を離す前にね。"

    # say L607 bil
    old "Mmm... feel how soft and warm they are wrapping all around your cock?"
    new "んん…こんなに柔らかくて温かいの、あなたのち○こを包み込む感じ？"

    # say L608 pla
    old "Fuck... Billie... your tits feel amazing..."
    new "くそ……ビリー……お前の胸が最高だよ……"

    # say L612 bil
    old "You're throbbing so much between them. You love fucking my tits, don't you?"
    new "あなたは私の胸の間で脈打ってるわね。私の胸を犯すのが好きでしょう？"

    # say L617 bil
    old "That's it... fuck my tits harder. I want you to cum all over them."
    new "そうよ…もっと私の胸を犯して。あなたの精液を全部私の胸にかけてください。"

    # say L618 pla
    old "Billie... I'm gonna cum..."
    new "ビリー… 出るよ…"

    # say L619 bil
    old "Do it. Cover my tits. I want to feel your hot load on me."
    new "やって、私の胸にかけて。あなたの熱い精液を感じたい。"

    # say L642 pla
    old "Ahh— fuck— I'm cumming!"
    new "アッ— クソ— 出るよ！"

    # say L643 bil
    old "Mmm... yes, give it to me. Cum all over my tits."
    new "mmm... そう、私にくれて。私の胸に全部出しなさい。"

    # say L650 bil
    old "Heh... look at you. Made another mess on me."
    new "へへ… 你看みて。また私に汚れさせちゃったね。"

    # say L651 bil
    old "Guess my tits are too much for you."
    new "私の胸が君には大きすぎるみたいね。"

    # say L652 bil
    old "It's nice you like them so much..."
    new "へへ、そんなに気に入ってくれて嬉しいね…"

    # say L664 bil
    old "Mmm... slow... just like this... I want to feel every inch of you."
    new "んん…ゆっくり…このまま…あなたのすべてを感じたい…。"

    # say L665 pla
    old "You feel so good... so warm..."
    new "君の体温がこんなにも感じよくて暖かいな…"

    # say L666 bil
    old "Mmm... deeper... I need you inside me... all of you."
    new "んん…もっと深く…あなたが必要だ…すべてを。"

    # say L670 bil
    old "Ahh... yes... right there..."
    new "アッ…そう…そこ…"

    # say L671 pla
    old "Fuck... Billie... you’re perfect."
    new "くそ……ビリー……君は完璧だ。"

    # say L672 bil
    old "Don’t hold back... I want all of you tonight... I need this."
    new "抑えなくて…今夜は全部ちょうだい…必要なの。"

    # say L676 bil
    old "Harder... don’t stop... I want to feel you lose control..."
    new "もっと強く…止めてくれないで…あなたが制御を失うのを感じたい…"

    # say L677 pla
    old "I’m getting so close..."
    new "俺もうすぐだ…"

    # say L678 bil
    old "Inside me... cum inside me... I want to feel you let go completely."
    new "中に入りな… 中に出して… 全ての CONTROL を失いたいの…"

    # say L701 pla
    old "Billie— I’m cumming—!"
    new "ビリーー、出るよー！"

    # say L702 bil
    old "Yes— fill me up... give me everything..."
    new "はい— 私の中を満たして…全部ちょうだい…"

    # say L708 bil
    old "Mmm... I can still feel you pulsing inside me..."
    new "うん... まだ中で脈打ってるのを感じてる..."

    # say L709 pla
    old "That was... incredible."
    new "それは… 素晴らしかったな。"

    # say L710 bil
    old "That wasn’t everything. Tonight I don’t want to stop until you’ve given me all of you."
    new "それが全部じゃないの。今夜はあなたから全部を奪うまでやめないつもりよ。"

    # say L711 bil
    old "Come here... don’t pull out yet."
    new "ここに来な…まだ抜かないで。"

    # say L712 bil
    old "I want to feel you again... deeper this time."
    new "また感じたいの... 今度はもっと深く penetra."

    # say L728 bil
    old "Slow... just like that... I love feeling you fill me completely."
    new "ゆっくり……そう……私を完全に満たす感じが大好き。"

    # say L729 pla
    old "God, Billie... you’re so tight... so warm..."
    new "神様、ビリー… 緊張してるね… 暑苦しいよ…"

    # say L730 bil
    old "Mmm... keep your eyes on me... I know how much you love looking at my tits like this."
    new "mmm... 目を離さないで... こう見つめるのがどれだけ好きか知ってるわ。"

    # say L731 bil
    old "Look at them bouncing for you... they’re all yours tonight."
    new "見て、私の胸が为你而上下着呢... 今夜は全部君のものよ。"

    # say L735 bil
    old "Ahh... yes... right there... harder now..."
    new "アッ…そう…そこ…今度はもっと強く…"

    # say L736 pla
    old "You feel amazing... I can’t get enough of you."
    new "君は最高だ…俺は君から離れられない。"

    # say L737 bil
    old "Don’t hold back... I need you to lose yourself in me tonight."
    new "遠慮しないで…今夜は私の中に溺れちゃっていいのよ。"

    # say L741 bil
    old "Faster... fuck me harder... I want everything you have left."
    new "もっと速く……強く感じさせて……あなたが残しているすべてを私にちょうだい。"

    # say L742 pla
    old "Billie... I’m so close again..."
    new "ビリー… もうすぐまたイクよ…"

    # say L743 bil
    old "Then give it to me... cum inside me again... fill me up."
    new "それなら私にくれて……中で射精して……全部注いで。"

    # say L767 bil
    old "Yes— deep inside... let go... I want to feel every drop."
    new "うん——奥で……出しちゃって……全部感じたいの。"

    # say L773 bil
    old "Mmm... I feel you throbbing again... so warm..."
    new "うん... またあなたが脈打ってるのを感じる... すごく温かい..."

    # say L774 bil
    old "I don’t want this night to end..."
    new "この夜が終わらないでほしいな…"

    # say L775 pla
    old "Neither do I."
    new "俺もだよ。"

    # say L776 bil
    old "But tomorrow is going to be a long day..."
    new "でも、明日は長そうね…"

    # say L777 pla
    old "Yeah... I know."
    new "うん… 分かってる。"

    # say L778 bil
    old "I hate saying it, but we both need to rest."
    new "嫌だけど、二人とも休む必要があるの。"

    # say L779 pla
    old "You’re right, we better get dressed in case your grandma shows up."
    new "君が言う通りだ、着替えた方がいいな。万一、おばあさんが来ちゃったら困るから。"

    # say L792 bil
    old "Ahh... just like that..."
    new "あー… ちょうどいい…"

    # say L793 pla
    old "Focus on my mouth... nothing else matters right now."
    new "口に集中して……他は気にしないんだ。"

    # say L797 bil
    old "Yes... right there... don’t stop..."
    new "うん…ちょうどそこ…止めてないで…"

    # say L798 pla
    old "You’re getting so wet... that’s it, let go."
    new "お前、もうこんなに濡れてる… そう、そのまま感じて。"

    # say L802 bil
    old "Harder... use your tongue... I’m so close..."
    new "もっと強く…舌を使って…私、もうすぐ…感じる…"

    # say L804 bil
    old "Ahh— I’m— I’m cumming—!"
    new "アッ—— 私—— 私、イク——！"

    # say L832 bil
    old "Fuck... that actually worked..."
    new "ああ……本当に効いた……"

    # say L833 pla
    old "You look a lot calmer now."
    new "君は随分と落ち着いたね。"

    # say L834 bil
    old "I do... thank you. I really needed that."
    new "うん…ありがとう。本当に必要だったな。"

    # say L835 pla
    old "I don’t want to freak you out, but the contest already started. We gotta get on stage."
    new "ビリー、焦らなくていいけど、コンテストはもう始まってるんだ。ステージに行かないといけないな。"

    # say L836 bil
    old "Okay, okay... yeah, I feel way better now. Let’s go."
    new "Okay、okay... もう大丈夫、気分よくなったわ。行こう。"

    # say L848 bil
    old "Mmm... feel how soft they are wrapping around you?"
    new "ん…こんなに柔らかいのに感じてる？"

    # say L849 pla
    old "Fuck... Billie... they feel perfect..."
    new "ファック…ビリー…最高だよ…"

    # say L853 bil
    old "You’re throbbing so much between them... you love fucking my tits, don’t you?"
    new "あなたはそこで脈打ってるよね…私の胸を弄ぶのが大好きだよね？"

    # say L854 pla
    old "Yes... don’t stop..."
    new "うん... 止まらないで..."

    # say L858 bil
    old "Harder... fuck them... I want you to cum all over them."
    new "もっと激しく……犯して……中に全部出したいの。"

    # say L859 pla
    old "Billie... I’m so close..."
    new "ビリー… もうすぐだ…"

    # say L860 bil
    old "Then do it. Cover me."
    new "じゃあ、そうしなよ。私を塗りつぶして。"

    # say L883 pla
    old "Ahh— fuck— I’m cumming—!"
    new "あーっ、くそっ、出るっ！"

    # say L884 bil
    old "Mmm... yes, give me every drop... paint them nice and white."
    new "うん... そう、全部私にくれて... 素白く塗りつぶして。"

    # say L891 bil
    old "Heh... look at the mess you made."
    new "へへ… こんなに汚しちゃったね。"

    # say L893 bil
    old "We’re not done yet."
    new "まだ終わってないよ。"

    # say L894 bil
    old "Come here... I want you inside me again."
    new "ここに来な…また中に入れてほしいの"

    # say L906 bil
    old "Slow at first... I want to feel all of you."
    new "ゆっくりと……全部感じたいわ。"

    # say L916 bil
    old "Mmm... yes... just like that..."
    new "うん…そう…その通り…"

    # say L917 pla
    old "You feel so good... so tight..."
    new "君の感じがいい... すごく紧締感がある..."

    # say L921 bil
    old "Harder... don’t hold back..."
    new "もっと強く… 抑えちゃダメね…"

    # say L922 pla
    old "Billie... you’re perfect."
    new "ビリー… 完璧だよ。"

    # say L926 bil
    old "Fuck me... I want everything you have left..."
    new "ファックして… 私の中に入れて… 残ってる全部を…"

    # say L927 pla
    old "I’m gonna cum again..."
    new "またイクぞ..."

    # say L928 bil
    old "Inside me... fill me up one more time."
    new "中に入りて…もう一度満たして"

    # say L952 bil
    old "Yes... give it all to me..."
    new "はい…全部私にあげて…"

    # say L959 bil
    old "Mmm... I can feel you... so warm inside..."
    new "んん… 私の中がこんなに温かいのを感じてる…"

    # say L960 pla
    old "I don’t think I can move..."
    new "動けないかも..."

    # say L961 bil
    old "Then don’t. Stay right here with me."
    new "じゃあ動かないで。ここに私と一緒にいて。"

    # say L962 bil
    old "Tonight... everything feels right."
    new "今夜…すべてがうまくいっている気がする。"

    # say L963 pla
    old "We did it. Together."
    new "俺たちできた。一緒に。"

    # say L964 bil
    old "Yeah... we really did."
    new "うん…本当にそうよ。"

    # say L965 bil
    old "({i}Tomorrow the world will keep spinning... but right now, this is all I need.{/i})"
    new "{i}明日も世界は回り続けるだろうけど…でも、今この瞬間がすべてだ{/i}"

    # say L978 bil
    old "Mmm... circle my clit first. Gentle, like I showed you."
    new "ん…まずはクリを円を描くように優しく。私が見せた通りに。"

    # say L979 pla
    old "Like this?"
    new "こんな感じ？"

    # say L980 bil
    old "Deeper. Slide one in and curl it. You already know the spot."
    new "もっと深く。一本入れて曲げて。その場所はもう知ってるでしょ。"

    # say L984 bil
    old "Add another—fuck—yes, right there. You’re getting so good at this."
    new "もう一つ追加して——ふっく——そう、その通り。上手くなってるね。"

    # say L988 bil
    old "Harder, baby. Make me cum all over your hand."
    new "もっと激しく、ベイビー。手でイかせて"

    # say L1011 bil
    old "I’m—cumming—fuck—!"
    new "私は—イク—クソ—！"

    # say L1017 bil
    old "Shit... your fingers really kept perfect rhythm this time."
    new "くそ…指のリズムが今回は本当に完璧だったわ。"

    # say L1018 bil
    old "You’re getting faster and way more precise every time. I can feel it."
    new "あなたがずいぶん速くなって正確になったのが感じるわ。毎回そう感じてる。"

    # say L1019 bil
    old "This is exactly the kind of dexterity we need... both on stage and off it."
    new "この手つきがまさに必要なものだ…舞台上でも、それ以外でも。"

    # say L1034 bil
    old "{i}I used to float above the ground...{/i}"
    new "{i}私は以前は空中を浮遊していたように感じた...{/i}"

    # say L1035 pla
    old "You’re already dripping..."
    new "もう濡れてるな…"

    # say L1039 bil
    old "Deeper—fuck—keep the rhythm steady."
    new "もっと深く—くそ—リズムを保って。"

    # say L1043 bil
    old "Faster—make me cum while I try to hold the note—ahh—!"
    new "もっと速く——私が音を保とうとしてる間にイかせて——ああん——！"

    # say L1066 bil
    old "I’m cumming—fuck—yes—!"
    new "イクッ——クソ——そうッ！"

    # say L1073 bil
    old "Nngh... your tongue is getting way too good at this."
    new "んっ…あなたの舌がずいぶん上手くなってて…。"

    # say L1074 bil
    old "You held me through it perfectly. That’s the kind of control I need."
    new "あなたが上手く支えてくれたから、完璧だったわ。これこそ私が求めていたコントロールよ。"

    # say L1075 bil
    old "Every time you do this my voice gets stronger under pressure... and I get to enjoy that mouth of yours."
    new "毎回あなたがこれをするたびに、私の声はプレッシャーの中で強くなって…そしてあなたの口を楽しむことができる。"

    # say L1088 bil
    old "Mmm... look at you. Already so hard just from asking."
    new "うん… ほら、もうこんなに硬くなってる。ただ言葉を聞いただけで。"

    # say L1089 pla
    old "Billie... that feels so good..."
    new "ビリー…それがすごくいい感じだ…"

    # say L1094 bil
    old "Deeper now... I want to feel every throb."
    new "もっと深く…すべての脈動を感じたいの。"

    # say L1095 pla
    old "Fuck... you’re way too good at this."
    new "くそ……君はこれ、本当に上手すぎるな。"

    # say L1100 bil
    old "Don’t hold back. Cum for me. Let me give you the motivation you need."
    new "抑えなくていい。私のために精出しちゃって。私が君のやる気出させるから。"

    # say L1101 pla
    old "I’m— I’m close...!"
    new "俺は——すぐに出る……！"

    # say L1126 bil
    old "Mmm... every drop. Good boy."
    new "mmm... すべての滴を。いい子だね。"

    # say L1133 bil
    old "Heh... feeling more motivated already?"
    new "へへ…もうやる気になってきた？"

    # say L1134 bil
    old "Your confidence always shoots up after this. I can tell."
    new "この後、自信が上がるのはいつもそうだね。わかるわ。"

    # say L1135 bil
    old "Come back whenever you need some real motivation again... I’ll be waiting."
    new "また本物のモチベーションが必要になったら戻ってきてね…私待ってるから。"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Mall.rpy
translate japanese strings:

    # say L30 roo
    old "Hey buddy, how are you doing?"
    new "hey buddy、元気？"

    # say L31 pla
    old "Wow!!!"
    new "Wow！！！"

    # say L32 roo
    old "Oh! No worries at all, she is harmless, actually the only way to be attacked by them is that they feel threatened, it's ok, touch her."
    new "あら！心配しないで、彼女は無害だから。実際には、彼らが脅威を感じた時だけ攻撃するのよ。大丈夫、触ってみてもいいわ。"

    # say L33 pla
    old "No, no...  It's fine thank you."
    new "いや、大丈夫、ありがとう。"

    # say L35 roo
    old "Hehehe! It's ok, the first time is kind of impressive... Her name is Gorgo, I really love her, it's my pet."
    new "へへへ！大丈夫よ、初めてはちょっと感動ものよね… 名前はゴルゴ、本当に私の大好きなペットなの。"

    # say L36 pla
    old "I can see it..."
    new "見えるな…"

    # say L37 roo
    old "Do you like snakes? Would you like to adopt one?"
    new "蛇が好き？飼ってみたい？"

    # say L38 pla
    old "Oh no, no thank you... Hmm I'm more a cat person... You know..."
    new "ううん、いいや断る…… 僕は猫派だな……分かってるだろう？"

    # say L39 roo
    old "Oh, they are beautiful too, here you can find anything you need related with any pet... You know their food, cat litter or any toy you want for them to play with."
    new "あ、それも美しいですね、ここならどんなペットにも必要なものが全部揃っていますよ… 餌や猫砂、遊ぶためのおもちゃなんかも何でもありますから。"

    # say L40 pla
    old "Alright, thank you, I've never been to this place before! It 's amazing..."
    new "わかった、ありがとう、ここには初めて来たけどすごいね..."

    # say L42 roo
    old "Yes, I just opened a couple of months ago, so that's probably  why you haven't seen it before..."
    new "うん、数ヶ月前にオープンしたばかりだから、まだ見たことないのも無理ないよね。"

    # say L43 roo
    old "You can come at any time, this place is a free space for animals and earth care, you can find anything and help with everything to save this beautiful world..."
    new "いつでも来ていいよ、ここは動物や地球のケアのための自由な空間だから。必要なものは何でも見つけて、この美しい世界を守る手伝いができるよ。"

    # say L44 pla
    old "Oh, it's very nice to see this kind of place."
    new "ああ、こんな場所があるのは嬉しいね。"

    # say L45 roo
    old "Anytime you want to come we are here for you, ok? What's your name buddy?"
    new "いつでも来てもいいよ、ここはあなたのためにあるから。名前は？"

    # say L46 pla
    old "I'm [pla] nice to meet you."
    new "俺は[pla]、よろしくね。"

    # say L47 roo
    old "It's a pleasure [pla], I'm Roonie, I love the energy I can feel from people, yours is quite special keep that feeling, we need more people like you."
    new "[pla]、会えて嬉しいよ、私はルーニー。人の持つエネルギーを感じるのが好きで、あなたのそれは特別だよ。その感じを忘れないで、もっとあなたのような人が必要だよ。"

    # say L48 pla
    old "Ok... Thank you..."
    new "Ok... ありがとう..."

    # say L49 roo
    old "It was nice to meet you! Have a peaceful day!"
    new "お会いできて良かったです！ 平和な一日を！"

    # say L50 pla
    old "Thanks, see you!"
    new "ありがとう、またね！"

    # say L64 roo
    old "Hey buddy, how are you?"
    new "ねえ、元気？"

    # say L65 pla
    old "I'm fine, thank you."
    new "元気だよ、ありがとう。"

    # say L66 roo
    old "It's nice to see you here, very nice and positive energy you are spreading today."
    new "ここにいてくれて嬉しいわ、今日のあなたのポジティブなエネルギーが伝わってくるの。"

    # say L67 pla
    old "... Thank you."
    new "ありがとう。"

    # say L68 roo
    old "What do you need today, I'm here to help you."
    new "今日何が必要なの？手伝うから。"

    # say L69 pla
    old "Oh, I was just passing by."
    new "あ、ただ通りかかっただけだよ。"

    # say L71 roo
    old "Ok, Remember if you find any homeless animal you can bring it here, so we can help, I know this world is very mean to them..."
    new "分かったわ、もし野良の動物を見つけたら連れてきてね、手伝えるから。この世界は彼らにとって厳しくて…"

    # say L72 pla
    old "I will do!"
    new "やるよ！"

    # say L73 roo
    old "Count on you buddy to make a more beautiful world for them."
    new "あなたがいてくれるだけで彼らのためのより美しい世界になるわ。"

    # say L74 pla
    old "Sure... I need to leave."
    new "そうだな…行かないとならないんだ。"

    # say L75 roo
    old "I know, busy day, isn't it?"
    new "忙しい日だね、そうじゃない？"

    # say L76 pla
    old "Kind of..."
    new "まあね..."

    # say L77 roo
    old "Thank you for stopping by to say hi."
    new "ありがとう、顔を見せてくれて。"

    # say L78 pla
    old "Don't mention it."
    new "気にするな。"

    # say L80 pla
    old "You too, bye!"
    new "じゃあ、また！"

    # say L93 pla
    old "Hey! How are you?"
    new "Hey！ 元気？"

    # say L94 roo
    old "Hey my man, nice seeing you again! I'm pretty fine, what about you?"
    new "Hey my man、また会えて嬉しいわ。私は元気よ、あなたは？"

    # say L95 pla
    old "I'm glad... Well, Hmm, I'm ok."
    new "うれしいな... まあ、そうだね、大丈夫さ。"

    # say L96 roo
    old "Cool man! Is there anything I can do for you?"
    new "クールだね！何か手伝えることある？"

    # say L97 pla
    old "Hmm, actually yes... I- I w- wanted to ask you for a j- job? I thought you maybe had something for me."
    new "うん、実はそうなんだ… あの、君に仕事の依頼をしたいんだけど… 何か手伝えることはある？"

    # say L98 roo
    old "Really? [pla] you put me in a complicated situation. I would like to help you but now it's impossible. I don't have much resources right now and Angelina is pregnant."
    new "ほんと？ [pla] あなたに困らせちゃうわ。手助けしたいけど、今は無理なの。今、あまりリソースがないし、エンジェリナが妊娠してるから。"

    # say L99 pla
    old "Pregnant? Oh right! Uhh...  Congrats Ronnie, t- that's... great."
    new "妊娠？ああ、そうだった！うーん…… おめでとう、ロニー。それは……すごいね。"

    # say L100 pla
    old "I'm sorry I bothered you, I understand you can't help me now. I should go now... I have things to do but thanks..."
    new "すみません、迷惑かけちゃった。今は手伝ってくれないのはわかってる。行かなきゃいけないな… やることもあるし、ありがとう…"

    # say L101 roo
    old "No, no, it's fine, sorry I couldn't help, but you don't have to go, stay and let's chit-chat."
    new "いいえ、大丈夫、手伝えなくてごめん。でも、行かなくてもいいから、残っておしゃべりしよう。"

    # say L103 pla
    old "Oh n- no, thanks but I really need to go now. See you!"
    new "あ、うーん、ありがとうけど、本当に今行くんだ。またね！"

    # say L104 roo
    old "Have a nice one! Take care [pla]."
    new "良い一日を！気をつけてね [pla]。"


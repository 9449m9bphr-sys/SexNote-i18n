# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/JadStory.rpy
translate japanese strings:

    # say L7 pla
    old "Hi Hinn, good morning. How are you?"
    new "嗨 Hinn、おはよう。元気ですか？"

    # say L10 pla
    old "Boy, I feel like it's been a while since I've seen you."
    new "おい、ヒン、ずいぶん久しぶりだな。"

    # say L12 hin
    old "Yeah... We haven't really hung out lately."
    new "うん… 最近あまり会ってないよね。"

    # say L13 hin
    old "Actually, I've been thinking..."
    new "実は、考えていたの…"

    # say L14 hin
    old "Do you think you would like to come to my house? Maybe we could watch a movie together?"
    new "あなたが来てくれたらうれしいな。一緒に映画でも見ようか？"

    # say L15 hin
    old "I- if you want to... Of course."
    new "もしよければ… もちろん。"

    # say L16 pla
    old "Of course, that would be nice."
    new "もちろん、いいよ。"

    # say L17 hin
    old "Really? That's great!"
    new "本当に？それは嬉しいな。"

    # say L18 hin
    old "Well, since we're done with school for the day. Would you like to go now?"
    new "じゃあ、学校も終わったし。今すぐ行こうか？"

    # say L19 pla
    old "Sure, that sounds great."
    new "そうだな、いいね。"

    # say L33 pla
    old "Ok, so, what movie do you think you would like to watch?"
    new "じゃあ、どの映画を見たいのか教えてくれる？"

    # say L34 hin
    old "Well, I've been wanting to watch this new movie called 'Lusted Note.'"
    new "ええ、新しい映画で『Lusted Note』っていうのを見たかったの。"

    # say L35 pla
    old "Uhh, ok... What's it about?"
    new "うーん、そうか… どんな内容の映画？"

    # say L36 hin
    old "It's a romance movie about a stepbrother and stepsister who fall in love."
    new "それは義理の兄妹が恋に落ちるラブストーリーだよ。"

    # say L37 hin
    old "It's been all the rage lately, everyone says it's so good! And the lead actress is really good, I'm her fan!"
    new "最近話題になってて、みんな超いいって言うんだよ！主演の女優さんもめちゃくちゃ上手で、私は彼女のファンなんだ！"

    # say L38 pla
    old "Well, sounds interesting, let's watch it."
    new "まあ、面白そうだし、観てみよう。"

    # say L54 pla
    old "Wow this movie is actually really good."
    new "この映画、実際にめちゃくちゃいいな。"

    # say L55 hin
    old "Yeah, it's great."
    new "うん、すごくいいよね。"

    # say L56 hin
    old "I really like their love story, it's so beautiful."
    new "彼らのラブストーリーが本当に好きだ、すごく美しいよね。"

    # say L57 hin
    old "You know, I'm very happy you decided to come, today."
    new "今日来てくれて、本当に嬉しいの。"

    # say L58 hin
    old "I thought maybe, you wouldn't want to come."
    new "あなたが来てくれるかどうか、ちょっと心配だったの。"

    # say L61 pla
    old "What? Why would you think that?"
    new "何言ってんの？なんでそう思ってるんだ？"

    # say L62 hin
    old "Well, it's just that you're such a popular guy, you know..."
    new "まあ、だってあなたはそんなに人気者だからって思ってたの..."

    # say L63 pla
    old "Popular? Me??"
    new "人気者？俺？"

    # say L64 pla
    old "Come on... There's no way you think I'm popular."
    new "Come on... そんなこと思ってるわけないだろう。"

    # say L65 hin
    old "Well, you seem to get along quite well with a lot of people."
    new "まあ、あなたは結構たくさんの人と上手くやっているみたいね。"

    # say L66 hin
    old "You know... You get along so well with Belle and Billie."
    new "あなたって…ベルやビリーとも仲良しだよね。"

    # say L70 pla
    old "Well, you know... They're my friends too."
    new "まあ、君も知ってるだろう… 彼女たちは俺の友達だ。"

    # say L71 pla
    old "And I really like hanging out with them."
    new "そして、彼らと一緒にいるのが本当によかったんだ。"

    # say L72 pla
    old "But that doesn't mean I wouldn't want to hang out with you. Or that I would be too busy."
    new "でも、それって君と過ごしたいと思ってないわけじゃなくて、忙しくて君との時間を作れないわけでもないんだ。"

    # say L73 pla
    old "I really enjoy spending time with you Hinn."
    new "ヒン、君と過ごす時間は本当に楽しいんだ。"

    # say L78 hin
    old "Thank you [pla], I really like spending time with you too."
    new "ありがとう、[pla]。私もあなたと過ごす時間が大好きだよ。"

    # say L92 hin
    old "You know, my mom won't come home for a while."
    new "知ってるでしょ、ママはしばらく帰ってこないの。"

    # say L93 pla
    old "Oh!"
    new "オッ！"

    # say L94 hin
    old "So... If you want, we could... You know..."
    new "そう……もしよければ、私たちは……わかってるよね……"

    # say L95 pla
    old "Uhh... Should we go up to your bedroom?"
    new "うーん… 寝室に行くか？"

    # say L97 hin
    old "Haha, there's no need."
    new "ははは、そんな必要ないよ。"

    # say L98 hin
    old "She'll take a while, so, we can just do it here."
    new "彼女、時間がかかるから、ここでいいじゃん。"

    # say L117 jad
    old "Well?!"
    new "WELL？！"

    # say L118 jad
    old "Aren't you going to say anything?"
    new "何も言うの？"

    # say L122 hin
    old "Wait a minute! What are you doing home so early?! You told me you were going to be late today!"
    new "ちょっと待って！　どうしてこんなに早く帰ってきたの？！　今日遅くなるって言ってたじゃん！"

    # say L123 jad
    old "I decided to come home early today."
    new "今日は早めに帰ることにしたのさ。"

    # say L124 jad
    old "But I see now this is why you kept asking me what I was going to be doing today..."
    new "でも、だから君は今日一日中何してるのか聞きたがってたんだね..."

    # say L125 jad
    old "This is incredible..."
    new "これはすごい..."

    # say L127 hin
    old "We weren't doing anything wrong you know."
    new "私たちは何も悪いことしてないよ。"

    # say L128 jad
    old "I didn't say you were!"
    new "言ってないわよ！"

    # say L129 jad
    old "Listen Hinn, [pla], I understand you two are adults now, I'm not bothered by you having sex or anything."
    new "ヒン、[pla]、君たちが大人になったのはわかるよ、セックスしてるのを見ても別に気分悪くないけど。"

    # say L130 jad
    old "But if you're going to have sex, please do it in a private place!"
    new "でもSEXするなら、せめてプライベートな場所でやってちょうだい！"

    # say L131 jad
    old "Just look at the way you two are right now!"
    new "二人の今の様子を見てよ！"

    # say L132 jad
    old "Just standing there completely naked!"
    new "ただ全裸で立ってるだけじゃない！"

    # say L140 jad
    old "(Whoah, h-he's so big!)"
    new "わあ、ひっ、そんなに大きいの！"

    # say L141 jad
    old "You have to think about other people, you know..."
    new "他の人のことを考えないとね..."

    # say L142 hin
    old "We just didn't know you were coming home so soon..."
    new "私たちは君がこんなに早く帰ってくるとは知らなかったんだよ..."

    # say L143 jad
    old "Listen, I know you guys are young and full of hormones..."
    new "ねぇ、君たち若いのにホルモン全開なのはわかるけど…"

    # say L146 jad
    old "But this is the living room! I usually watch tv on that couch!"
    new "でもここはリビングだよ！そのソファでテレビを見るのが普通なんだもん！"

    # say L147 jad
    old "Besides, I could've come home with company..."
    new "それに、私が誰かと一緒に帰ってきてもいいじゃん。"

    # say L148 jad
    old "Imagine what would have happened if someone saw you and your boyfriend having sex on the couch Hinn."
    new "誰かがソファで君と彼氏がセックスしてるところを見つけてたら、どうなってたと思う Hinn？"

    # say L151 hin
    old "B- boyfriend? (Gosh! Mom why can't you shut up...)"
    new "ボーイフレンドって誰よ？（ああ！ママ、黙ってよ...)"

    # say L152 hin
    old "Uhh... W- We are not a... C- couple... (Not yet, THANKS MOM!)"
    new "うっ… ウン、まだ… カップルじゃないよ…（まだ、ママンありがとう！）"

    # say L153 hin
    old "We still being... Uhh, just friends."
    new "まだ…うん、ただの友達だよ。"

    # say L157 jad
    old "E- excuse me?"
    new "え、何？"

    # say L158 jad
    old "B- but you two were just..."
    new "でも二人はさっきまで…"

    # say L159 hin
    old "Mom please, this is not your business!"
    new "ママ、これ私に関係ないって！"

    # say L161 jad
    old "Well, I guess that's just how you do things these days..."
    new "まあ、今の若い人はそういうふうにするのね…"

    # say L162 jad
    old "I get it, young people are a little more open nowadays, as long as your kids are safe... I guess it's alright."
    new "分かってるよ、最近の若い人はちょっとオープンになったりするけど、子供たちが安全なら……まあいいか。"

    # say L163 jad
    old "But that's not the point, the point is that you should be more careful with these things."
    new "でもそれじゃなくて、大事なのはもっと気をつけることよ。"

    # say L164 jad
    old "If you're going to be having sex, do it in your bedroom."
    new "ensex行為をするなら、寝室でね。"

    # say L165 jad
    old "It doesn't matter if I'm not home, try to be a little respectful, will you?"
    new "家にいなくても関係ないわ、でもせめて少しは敬意を持ってほしいの。"

    # say L167 hin
    old "Oh my gosh! It was an accident!"
    new "あらまあ！偶然だったの！"

    # say L168 hin
    old "Ugh, I don't want to talk about this anymore. Come on [pla], let's go to my bedroom!"
    new "うーん、これ以上話したくないな。さあ、[pla]、私の寝室に行こう！"

    # say L175 pla
    old "Sorry, Mrs. Jade."
    new "すみません、ジェイドさん。"

    # say L185 jad
    old "(God, he really has a huge...)"
    new "神様、彼のそれは本当に大きいな..."

    # say L202 hin
    old "Listen [pla], I'm sorry about that, I didn't expect her to come home so early."
    new "[pla]、ごめんなさい。彼女がこんなに早く帰ってくるとは思わなかったの。"

    # say L203 hin
    old "I'm also sorry about what she said. She can be a drag sometimes."
    new "私も彼女が言ったことについて謝るよ。時々、めんどくさいよね。"

    # say L205 pla
    old "It's ok. Besides, I sort of think that she's  right."
    new "大丈夫だよ。それに、俺も彼女の言うことに一理あると思う。"

    # say L208 pla
    old "Yeah, I mean, we did it in the living room."
    new "まあ、リビングでやっちゃったし。"

    # say L209 pla
    old "In a way, we're lucky she wasn't even angrier."
    new "ある程度、彼女がもっと怒らなかったのが幸いだったってことか。"

    # say L211 hin
    old "{b}*Sigh*{/b} Yeah, I guess you're right."
    new "{b}…… {/b} うん、そうね。"

    # say L212 hin
    old "I suppose next time we'll just have to be more careful."
    new "次はもっと気をつけるしかないのかな。"

    # say L214 hin
    old "I guess you have to go, right?"
    new "帰らなきゃならないのね。"

    # say L215 pla
    old "Yeah, I better go home, but, maybe we can finish the movie some other time."
    new "そうだな、家に帰った方がいいけど、また今度映画の続きを観ようか。"

    # say L217 hin
    old "Yeah, that would be great!"
    new "そうね、それがいいな。"

    # say L219 hin
    old "Alright, see you later [pla]."
    new "じゃあ、またね [pla]。"

    # say L238 pla
    old "Hi Hinn, I'm great. And you? How are things with your mom?"
    new "嗨ん、元気だよ。君は？お母さんとの関係はどう？"

    # say L239 hin
    old "Oh, it's fine, she wasn't really all that angry."
    new "うーん、別に怒ってたわけじゃないけど。"

    # say L240 pla
    old "I see, that's good I guess."
    new "まあ、良かったな。"

    # say L241 hin
    old "On that note, I was thinking..."
    new "その話題で、実はね、前回映画を途中でやめちゃったから、また続きを一緒に見ない？"

    # say L242 hin
    old "You know, since last time we couldn't actually finish the movie, what do you think if you come over and we finish it?"
    new "あのね、前回映画を最後まで見られなかったから、君がうちに来て続きを一緒に見ない？"

    # say L244 pla
    old "Huh? Come over? To your house?"
    new "へ？来るの？君の家に？"

    # say L246 hin
    old "Yeah, of course."
    new "もちろん啦。"

    # say L247 hin
    old "Is there a problem?"
    new "問題あるの？"

    # say L248 pla
    old "No, no problem. I'm just not sure about it, you know?"
    new "問題ないけど、ちょっと不安なんだ、わかってる？"

    # say L249 pla
    old "What if your mother doesn't like that I go there?"
    new "お母さんが行かせてくれないんじゃないかって思うけど。"

    # say L250 hin
    old "Don't be silly, I told you, she's not angry."
    new "バカ言わないで、言ったでしょう、怒ってないよ。"

    # say L251 hin
    old "We just need to be careful and nothing will happen."
    new "気をつけていれば大丈夫よ。"

    # say L253 pla
    old "Hmm, I guess you're right."
    new "うん、そうかもな。"

    # say L254 pla
    old "Ok, I'm in."
    new "分かった、入るよ。"

    # say L283 jad
    old "Oh, hi [pla]! I didn't know you were here!"
    new "あ、こんにちは[pla]！ここにいるなんて知らなかったの。"

    # say L286 pla
    old "Hi Mrs. Jade, how are you? I was just watching a movie with Hinn."
    new "こんにちは、ジェイドさん。元気ですか？ヒンと一緒に映画を見てたところです。"

    # say L288 jad
    old "Well, it's good to see you again..."
    new "まあ、また会えて嬉しいです…"

    # say L296 jad
    old "So, what are you watching?"
    new "じゃあ、何を見ていたの？"

    # say L300 whi
    old "Phew, I definitely should take some extra parking lessons, heh."
    new "ふう、駐車の練習をもっとしないとね、へへ。"

    # say L304 whi
    old "Oh, hi kids! How are you?"
    new "おひさしぶりですね、お子さんたち！元気ですか？"

    # say L314 whi
    old "Oh, it's been a while [pla]..."
    new "あら、久しぶりですね [pla]..."

    # say L315 pla
    old "Hi Mrs. White... Nice to see you..."
    new "こんにちは、ホワイトさん… お久しぶりです…"

    # say L317 hin
    old "Hello Mrs. White, how are you?"
    new "こんにちは、ホワイト夫人、お元気ですか？"

    # say L318 whi
    old "I'm very good darling. I have to say I love your new outfit, it suits you much better than that old jumper you used before."
    new "私はとても元気です Darling。あなたの新しい服、とても似合っていますわ。前のセーターの時よりもずっといいわ。"

    # say L319 whi
    old "I have to say [pla], you're also very good-looking."
    new "[pla]、君もとても魅力的だわ。"

    # say L320 whi
    old "These kids just get so big from one moment to another, right Jade?"
    new "これらの子供たちは、一瞬で这么大になっていくわね、ジェイド。"

    # say L321 jad
    old "You're right, it's amazing..."
    new "そうね、本当に驚くほど成長するわね。"

    # say L323 hin
    old "So, you two were out together?"
    new "そう、二人で出かけていたの？"

    # say L324 jad
    old "Yeah, that's right, Mrs. White was helping me with some shores."
    new "うん、そうよ、ミス・ホワイトが手伝ってくれてたの。"

    # say L325 jad
    old "And I told her to come to hang out with me."
    new "そして彼女に一緒に遊ぼうって言ったの。"

    # say L326 jad
    old "We hadn't spoken in a while."
    new "久しぶりに話すんだ。"

    # say L327 hin
    old "Oh, ok. That's great."
    new "うん、そうね。それはいいわね。"

    # narrator L331 
    old "{b}*PHONE RINGING*{/b}"
    new "{b}*スマホが鳴っている*{/b}"

    # say L333 jad
    old "Uhh, the phone is ringing. I'll be right back."
    new "うーん、スマホが鳴ってる。すぐ戻るね。"

    # say L338 whi
    old "So, you two were watching a movie?"
    new "そう、二人は映画を見ていたの？"

    # say L339 pla
    old "Yeah... that's right."
    new "うん…そうだよ。"

    # say L340 whi
    old "Well? Was it good?"
    new "良かったの？"

    # say L341 hin
    old "Umm, yeah, I guess..."
    new "うん、まあ、そうかなあ…"

    # say L342 hin
    old "I think we're going to keep watching it, so, if you don't mind"
    new "うん、もしよければ、これからも見続けるつもりなのだけど"

    # say L343 whi
    old "Oh well, I'll watch it with you then."
    new "まあ、そうしましょう。私も一緒に見ますね。"

    # say L356 jad
    old "I can't believe you! I just simply can't"
    new "信じられないわ！本当に信じられないのね"

    # say L357 jad
    old "Why don't you take..."
    new "なぜ君が取らないの？"

    # say L358 jad
    old "No! I did not say that!"
    new "ダメよ！そんなこと言わなかったわ！"

    # say L364 jad
    old "It's always the same with you Hiashi!"
    new "あなたっていつも同じよね、ヒアシ！"

    # say L370 jad
    old "It's almost as if you don't care about your daughter's well-being."
    new "あなたがあたしの幸せなんてほとんど気にしてないみたいね。"

    # say L371 jad
    old "My God!!"
    new "神様 (！！ )"

    # say L372 jad
    old "No, NO! YOU listen to me! You have to figure out something and fulfill your responsibility or I'm taking action."
    new "いいえ、いいえ！君がよく聞きなさい！何か方法を見つけて責任を果たさないと、私が行動に出るわ。"

    # say L383 jad
    old "Ok, I'm here again."
    new "はい、また来ちゃったわ。"

    # say L393 whi
    old "Are you ok? What happened?"
    new "大丈夫？何があったの？"

    # say L394 jad
    old "Uhh, please don't tell me you heard everything I said..."
    new "うーん、お願いだから私が言ったこと全部聞いてないでよね…"

    # say L395 whi
    old "You weren't very quiet, to be honest..."
    new "正直に言うと、君はそんなに静かじゃなかったわ..."

    # say L397 jad
    old "{b}*Sigh*{/b}... I'm very sorry, it wasn't my intention."
    new "{b}……申し訳ありません、そんなつもりじゃなかったんです。{/b}"

    # say L399 jad
    old "Let's just pretend it never happened, and enjoy the movie."
    new "起こったことなかったことにしようとして、映画を楽しもう。"

    # say L413 whi
    old "Well, that was very good!"
    new "まあ、それはとても良かったわね！"

    # say L414 hin
    old "It really was."
    new "本当にそうね。"

    # say L416 whi
    old "I think I'll watch it in full when I get home. Don't you think it was great Jade?"
    new "私は家に帰ったら全部見ようと思うの。ジェイド、すごく良かったと思わない？"

    # say L419 jad
    old "What? Oh, yeah... Very good."
    new "何？あ、うん…とても良かったよ。"

    # say L421 whi
    old "Ok, tell me, what is it?"
    new "じゃあ、何なの？教えてよ。"

    # say L423 whi
    old "Come on, don't play dumb with me."
    new "さあ、私を馬鹿にしないで。"

    # say L424 whi
    old "What did Hiashi say this time?"
    new "Hiashiさんは今は何を言ったの？"

    # say L425 jad
    old "Honestly, I don't want to talk about this, especially not in front of the kids."
    new "正直、これについては話したくないの、特に子供たちの前では。"

    # say L426 whi
    old "Oh come on, they're adults now. Nothing bad will happen to them."
    new "まあ、彼らはもう大人よ。何が悪いことになるっていうの。"

    # say L427 whi
    old "Just spit it out, if you don't talk about it you'll be in a bad mood all week."
    new "さっさと話して、黙ってるとな一日中機嫌が悪くなるわよ。"

    # say L429 jad
    old "That was Hiashi, saying, once again! That he can't pay my alimony this month."
    new "それはハイアシからだったの、またしても！今月も養育費を払えないってさ。"

    # say L430 jad
    old "That's four months in a row! That irresponsible bum!"
    new "それが四ヶ月連続よ！ その無責任な男のくせに！"

    # say L431 jad
    old "And it's not as if things are any easy around here, he should know how the economy is around here."
    new "それにここも決して楽なわけじゃないわ、経済状況くらい分かってるでしょ。"

    # say L432 whi
    old "That's Hiashi for you, always the same guy..."
    new "ヒアシったら、いつも同じだよね…"

    # say L434 whi
    old "I bet he's still seeing that 19-year-old bimbo isn't he?"
    new "あの19歳のバIMBOとまだ付き合ってるに決まってるわよね？"

    # say L435 jad
    old "Yes, he is! God! That's what bothers me! He doesn't have enough money to help his daughter!"
    new "そうよ！ それが気に入らないの！ お金がないくせに娘を助けることもできないのに！"

    # say L437 jad
    old "But he can go around buying expensive clothes and vacations for some hussy that could be his grandchild!"
    new "でも、彼はその孫の年齢の女のために高価な服や旅行を買っているんだよ！"

    # say L439 jad
    old "I'm sorry Hinn, sweety, I wouldn't want to talk to you about your father like that."
    new "ごめん、ヒン、愛してるけど、お父さんのことそんな風に話したくないな。"

    # say L442 hin
    old "Hmph, whatever, not like any of this is new to me."
    new "ふん、別にこれって私にとっては新しいことじゃないわ。"

    # say L443 hin
    old "But I would've liked to have a calm movie night."
    new "でも、落ち着いた映画の夜を過ごせたかったのに。"

    # say L444 hin
    old "Come on [pla] let's get out of here."
    new "さあ、[pla]、ここから出て行こう。"

    # say L457 hin
    old "Listen, I'm sorry for what happened."
    new "ねぇ、起こったことについて謝るわ。"

    # say L458 hin
    old "God! My mom ruins everything!"
    new "神様！母さんって本当に台無しだよ！"

    # say L459 pla
    old "No, no, don't worry. That's ok, I understand."
    new "大丈夫、気にしないで。分かってるよ。"

    # say L460 pla
    old "I get it, this type of thing can stress anybody."
    new "分かってるよ、こんなことは誰でもストレス感じるもんさ。"

    # say L462 hin
    old "You know, you're always very sweet."
    new "あなたって、いつも優しいよね。"

    # say L464 hin
    old "Yes, and it deserves a reward..."
    new "うん、それに報酬がもらえるわ…"

    # say L484 pla
    old "What are we doing here?"
    new "ここに来てる目的は何？"

    # say L485 hin
    old "Well, we needed privacy to give you a special reward."
    new "まあ、プライバシーが必要だったのよ、特別なご褒美をあげるために。"

    # say L488 pla
    old "Whoah! What are you doing?"
    new "誰あ！何やってんの？"

    # say L489 hin
    old "I told you, I'm giving you a reward."
    new "言ったわ、報酬をあげるの。"

    # say L490 hin
    old "I was thinking that we could finish what we started the other night."
    new "あの夜の続きをしようと思ってたの。"

    # say L491 hin
    old "But my mom and Mrs. White got home when I wasn't expecting it."
    new "でも、母とホワイト夫人が予想外に帰ってきちゃったの。"

    # say L492 hin
    old "So, I'll just give  you a little something before you go home."
    new "じゃあ、帰る前にちょっとだけあげるからね。"

    # say L494 pla
    old "{b}*Glup*{/b}"
    new "{b}*グリップ*{/b}"

    # say L510 whi
    old "Hey, what are you doing there?"
    new "Hey、何してるの？"

    # say L512 jad
    old "What?! Oh, my God! You surprised me!"
    new "何？！ おっ、神様！びっくりした！"

    # say L513 whi
    old "Well, you were taking your sweet time and you left the stove on... Do you want me to finish dinner for you?"
    new "まあ、ずいぶんと時間をかけてるわね。ストーブもつけっ放しだし……私が夕飯を仕上げてあげようか？"

    # say L514 jad
    old "No, no, I just got distracted by... Something."
    new "いいえ、いいえ、ただ何かに気を取られちゃって。"

    # say L516 whi
    old "Right... Is there anything in the bathroom?"
    new "そうね……お風呂場には何かあるの？"

    # say L518 jad
    old "Nothing! Nothing! I was just looking for Hinn, but she isn't there."
    new "何もありません！何もありません！ヒンを探してただけなんですけど、彼女はいませんでした。"

    # say L519 whi
    old "Ok, sure."
    new "わかりました、そうしましょう。"

    # say L520 jad
    old "Anyway, let's go, help me with the mac and cheese."
    new "それじゃあ、行きましょう。マカロニとチーズの手伝いをしてください。"

    # say L538 hin
    old "That was very good."
    new "それはとても美味しかったです。"

    # say L539 pla
    old "Yeah, it was, I wasn't expecting it though."
    new "うん、そうだったけど、予想外だったな。"

    # say L540 hin
    old "Well, I wanted to make it up to you for the interruption last time, you know."
    new "前回の中断のあ补偿しようと思ってそうしたのよ。"

    # say L541 pla
    old "Yeah, I think I get it."
    new "うん、わかったような気がする。"

    # say L542 pla
    old "Anyway, I think, I shoould go home."
    new "まあ、そろそろ帰るかな。"

    # say L543 hin
    old "Hmm, yeah you are right."
    new "うん、そうだね。"

    # say L544 hin
    old "Listen, I'm really sorry about today, with my mom yelling all the movie and everything."
    new "ねえ、今日のこと、本当にごめんなさい。ママが映画中ずっと怒ってて、全部台無しちゃったよね。"

    # say L545 hin
    old "It ruined the movie afternoon."
    new "映画の午後を台無しにしてしまったね。"

    # say L546 pla
    old "Oh come on, I still had a great time."
    new "ほら、それでも楽しかったよ。"

    # say L547 pla
    old "If you'd like, maybe we could watch another movie some other day."
    new "もし君がいいなら、また別の日に映画を見ようか。"

    # say L549 pla
    old "Let's do it then."
    new "じゃあ、そうしよう。"

    # say L551 pla
    old "Alright, so, I better go now."
    new "よし、じゃあ、俺は帰るか。"

    # say L552 hin
    old "Oh, right. Have a good night [pla]."
    new "そうよ、おやすみなさい [pla]。"

    # say L553 pla
    old "Thank you, I really enjoyed the day. See you soon Hinn."
    new "ありがとう、今日一日楽しかったよ。またすぐ会おうね、Hinn。"

    # say L572 hin
    old "I'm great actually, my mom and I talked, and we're both feeling a lot better."
    new "実は元気で、ママと話して、二人ともずいぶん楽になったの。"

    # say L573 pla
    old "That's good, it's great that you can talk about those things."
    new "それは良かった、そんなこと話せるようになったのは素晴らしいね。"

    # say L574 pla
    old "It's a shame about the movie tho, though I suppose that still annoys you a little bit..."
    new "映画のことは残念だけど、でもまだ少し気にしてるのか？"

    # say L575 hin
    old "Well, about that..."
    new "まあ、そのことについてだけど…"

    # say L577 hin
    old "Do you think you would like to go to my house again?"
    new "また私の家に来てくれない？"

    # say L578 hin
    old "There's another movie that I would like to watch with you..."
    new "他にも見たい映画があるの……"

    # say L580 pla
    old "Hmm... Yeah, sure, I don't see why not."
    new "うーん… そうね、別にいいじゃん。"

    # say L581 hin
    old "Hey, that's great."
    new "へえ、それはいいな。"

    # say L582 hin
    old "And listen, this time my mom will be leaving for some event dinner she was invited to."
    new "そして、今度は母が招待されたイベントディナーに行くので、"

    # say L583 hin
    old "So, maybe we can finish the movie... And something else."
    new "じゃあ、映画を最後まで見よう... それから、他にも何かできるよね。"

    # say L584 pla
    old "Oh, sure."
    new "オッケー、いいよ。"

    # say L585 pla
    old "Sounds good."
    new "いいね。"

    # say L587 hin
    old "Great! So, let's go."
    new "グレート！じゃあ、行こう。"

    # say L617 jad
    old "God dammit!"
    new "くそっ！"

    # say L618 hin
    old "Ugh! What now?!"
    new "うっせえ！また何よ？！"

    # say L629 jad
    old "Oh! Hi [pla]!"
    new "あ！[pla]！いるのね！"

    # say L633 jad
    old "I didn't know you were here honey!"
    new "あなたがここにいるなんて知らなかったの、ハニー！"

    # say L636 jad
    old "Are you having a good time?"
    new "楽しんでる？"

    # say L637 pla
    old "Hello Mrs. Jade, I was just watching a movie with Hinn."
    new "こんにちはジャド夫人、ヒンと一緒に映画を見ていました。"

    # say L639 jad
    old "I'm glad honey."
    new "うれしいわ、honey。"

    # say L640 hin
    old "What happened now mom?"
    new "何があったの、ママ？"

    # say L641 hin
    old "Why did you scream and come out running in a towel?"
    new "お母さん、どうしてタオル巻いて走り出しつつ叫んだの？"

    # say L642 jad
    old "Well, I was taking a shower to get ready for that dinner I told you about."
    new "まあ、その晩ご飯のためにシャワーを浴びて準備してたのよ。"

    # say L643 jad
    old "But, then my shower suddenly exploded!"
    new "でも、シャワーが突然爆発しちゃったの！"

    # say L644 jad
    old "Now there's a lot of water running out of the piping."
    new "今、配管から水がどんどこ漏れてるの。"

    # say L646 hin
    old "So? Just call a plumber to fix it."
    new "じゃあ？ただ plumber 呼べばいいじゃん。"

    # say L647 jad
    old "Well, young lady, in case you haven't been paying attention lately. We're not exactly swimming in money right now."
    new "まあ、お嬢さん、最近気づいてなかったのかな。今私たちは特に金に余裕がないの。"

    # say L648 jad
    old "Since your father hasn't been paying my alimony, I've been having to take care of things."
    new "あなたの父親が養育費を払ってくれてないから、私がいろいろと自分でやりくりしてるんだよ。"

    # say L649 jad
    old "Right now I just can't afford to have somebody come and redo the entire bathroom tubing."
    new "今すぐ誰かを呼んでバスルームの配管全部やり直すお金はないのよ。"

    # say L651 hin
    old "Oh great!"
    new "ああ、そういえば…"

    # say L652 pla
    old "Uh, I think that maybe I could do something about that."
    new "うーん、見てみたら何かできるかもしんないな。"

    # say L653 jad
    old "Really? You know how to fix that type of thing?"
    new "ほんと？そんなの直せるの？"

    # say L654 pla
    old "I mean, I'd have to take a look, but maybe I can do something."
    new "まあ、見てみないとわからないけど、何かできるかもな。"

    # say L655 hin
    old "Oh great, another fantastic movie night..."
    new "また素晴らしい映画の夜かあ..."

    # say L661 pla
    old "Ok, ok, I see what happened, there was a rusty pipe, and it broke."
    new "分かった、分かった、何が起きたかわかったよ。錆びた配管があったんだ、それが壊れたんだ。"

    # say L663 pla
    old "I should be able to fix that."
    new "直せるけど、時間がかかるだろうな。バスルームの配管全部を交換しないと。"

    # say L664 jad
    old "Really? You think so?"
    new "本当？そう思ってるの？"

    # say L665 pla
    old "Well, it's going to take a while, because I'll have to change the whole piping for the bathroom."
    new "まあ、時間がかかるだろうな。トイレの配管全部を交換しないといけだからさ。"

    # say L666 pla
    old "And that means breaking some of the wall and the floor."
    new "そして、そのために壁と床を壊さないといけないんだ。"

    # say L667 pla
    old "But it shouldn't be too much of a problem."
    new "でもそれほど大きな問題にはならないだろうな。"

    # say L668 pla
    old "I actually have some experience doing house repairs and stuff."
    new "俺、家修理とかちょっと経験があるんだ。"

    # say L669 jad
    old "You do? Did you have a part-time job doing that?"
    new "そうなの？ その手のバイトをやってたの？"

    # say L671 pla
    old "I guess you could call it a summer job."
    new "夏のバイトって言えるかも。"

    # say L673 jad
    old "I see, well, I guess the only thing I can say is. When do you start?"
    new "なるほど、じゃあ私が言えるのは、いつから始めるの？"

    # say L675 pla
    old "Well, I would need to get some materials. But overall it shouldn't be too expensive."
    new "まあ、材料は必要になるけど、全体的にはそんなに高くはならないだろう。"

    # say L676 pla
    old "It's not too late, so, I should be able to make it to the hardware store."
    new "遅くないから、ハードウェアストアに行けるだろう。"

    # say L678 jad
    old "Oh, but you shouldn't spend your own money on that honey."
    new "でも、それのために自分のお金を出さなくていいのよ、 honey。"

    # say L679 pla
    old "Well, I'll just buy some things, and if you want me to, I'll just hand you the receipt the next time I'm here."
    new "まあ、必要なものだけ買って、もし君が欲しがったら次来たときに領収書を渡すよ。"

    # say L680 jad
    old "That would be really nice of you."
    new "それは本当に親切な Angebot だね。"

    # say L681 pla
    old "Don't worry, this won't be expensive at all."
    new "心配しなくていい、全然高くならないから。"

    # say L682 jad
    old "That's a relief to hear."
    new "そう言ってくれて安心したわ。"

    # say L683 pla
    old "Alright, I better go now, before they close."
    new "よし、閉まる前に帰るぞ。"

    # say L684 jad
    old "Thank you [pla], I really appreciate it."
    new "ありがとう、[pla]。本当に助かるわ。"

    # say L685 pla
    old "Oh, it's nothing, don't worry. But, I better hurry up, it's getting a bit late."
    new "ああ、気にしなくていい。でも、急がないと遅くなるからな。"

    # say L706 hin
    old "So? How bad it is?"
    new "そう？どれくらい大変なの？"

    # say L707 pla
    old "Well, not that bad, but it will definitely take a few days of work."
    new "まあ、そんなに悪くはないけど、確実に数日かかるだろうな。"

    # say L708 hin
    old "Oh [pla], that sounds like a lot of work, you don't have to do it."
    new "Oh [pla]、それってかなり大変そうね、無理しなくていいよ。"

    # say L709 pla
    old "Oh, don't worry. It won't be nothing, and I will be here visiting you more often."
    new "心配しなくていい、大したことじゃないし、俺は君のところによく来るからな。"

    # say L712 hin
    old "Hmm, I really can't belive you mom..."
    new "うーん、本当に信じられないよ、ママ…"

    # say L713 hin
    old "Anyway, so, let's finish the movie."
    new "まあ、そうね、映画を終わらせましょう。"

    # say L714 pla
    old "Uhh, actually... I have to try and get to the hardware store before they close."
    new "うーん、実は… 俺、ホームセンター閉まる前に行かなきゃいけんだ。"

    # say L728 jad
    old "I'm sorry [pla], it wasn't my intention to ruin your movie afternoon."
    new "ごめんなさい [pla]、映画の午後の台無しにするつもりじゃなかったの。"

    # say L729 pla
    old "It's ok, I get why she's angry. No problem, besides, you didn't know this was going to happen."
    new "大丈夫、彼女の気持ちは分かるよ。気にしないで、君が知らなかったことだしね。"

    # say L732 pla
    old "No problem."
    new "大丈夫だよ。"

    # say L733 pla
    old "Now, I better leave before they close the hardware store."
    new "じゃあ、ハードウェア屋が閉まる前に帰ろう。"

    # say L734 jad
    old "Sure, thanks again, honey."
    new "もちろん、またありがとう、ハニー。"

    # say L750 pla
    old "Hi Hinn."
    new "嗨ん、元気ですか？"

    # say L753 hin
    old "I'm fine, I guess..."
    new "元気だよ、多分..."

    # say L754 hin
    old "Listen [pla], I wanted to apologize about the way I acted yesterday."
    new "[pla]、昨日の私の態度について謝りたいの。"

    # say L758 hin
    old "Is just that things haven't been great at home this past few days."
    new "最近家のことがあまり上手くいってなくてね。"

    # say L759 hin
    old "Mom has been stressed a lot, which means I've been stressed even more."
    new "母が最近ストレスフルで、だから私も余計にイライラしてしまってるの。"

    # say L760 hin
    old "And I thought that maybe you and I could relax a little bit."
    new "それで、あなたと私で少しリラックスできないかと思ったの。"

    # say L762 hin
    old "But everytime we tried we kept being interrupted."
    new "でも毎回試すたびに邪魔されてばかりだったの。"

    # say L763 hin
    old "And it's just frustrating."
    new "イライラするよね。"

    # say L764 pla
    old "It's ok, I know how important our movie times are to you."
    new "大丈夫だよ、君の映画時間の大事さ、俺もわかってるから。"

    # say L765 pla
    old "I completely get it, don't worry."
    new "分かってるよ、心配しないで。"

    # say L766 hin
    old "Thank you, [pla]!"
    new "ありがとう、[pla]！"

    # say L767 pla
    old "By the way, I was thinking maybe I could drop by your house this afternoon."
    new "ちょっと今度、今日の午後に君の家に寄ってもいいかな。"

    # say L768 pla
    old "And start working on the repairs for the bathroom."
    new "そしてお風呂場の修理を始めるんだ。"

    # say L769 pla
    old "Maybe we could even finish that movie we started last time."
    new "でも、あの映画の続きを Completion: 見終えようか。"

    # say L770 hin
    old "Oh, sorry [pla], actually, I'll be staying late here in school for some days."
    new "ごめん [pla]、実は学校でしばらく遅くなるの。"

    # say L771 hin
    old "I have some extracurricular activities. Helping the teacher and stuff."
    new "部活があるの。先生のお手伝いとか。"

    # say L773 hin
    old "But, my mom will be there. So, why don't you go and start working on the repairs?"
    new "でも、私のママがいるから、修理を始めてみない？"

    # say L774 hin
    old "That way it won't take you that long, and we can have time to..."
    new "そうすればそんなに時間はかからないし、私たちも時間を過ごせるわ…"

    # say L775 hin
    old "Finish the movie when I'm done with my stuff here."
    new "私が終わったら映画を観ようね。"

    # say L777 pla
    old "That's a good idea."
    new "それは良いアイデアだね。"

    # say L778 pla
    old "Ok, sure, I'll go there and get started on the repairs."
    new "分かった、じゃあ修理に取りかかるよ。"

    # say L779 hin
    old "Alright, then see you soon. And sorry about my mom once again."
    new "それじゃ、またすぐね。母のこと、本当にごめんなさい。"

    # say L780 pla
    old "Hey, don't worry, everything will be alright. See you later."
    new "大丈夫だよ、心配しないで。また後でな。"

    # say L796 pla
    old "Good morning, Mrs. Jade."
    new "おはようございます、ジェイドさん。"

    # say L797 jad
    old "Oh, Hi [pla]! Hi, how are you?"
    new "あら、こんにちは [pla]！元気？"

    # say L798 pla
    old "Fine, thank you."
    new "元気だ、ありがとう。"

    # say L799 jad
    old "How did it go? Were you able to get all the things you need for the repair?"
    new "どうだった？修理に必要なものは全部手に入った？"

    # say L800 pla
    old "Yes, I got everything without problems, and it was even cheaper than I expected."
    new "はい、問題なく全部揃えたよ、しかも予想より安かった。"

    # say L801 jad
    old "Oh, thank God! Alright, then I will let you work, if you need something, please just let me know."
    new "あら、良かったわ！じゃあ、あなたが作業できるようにさせてあげるわ。何か必要になったら、いつでも言ってくださいね。"

    # say L803 pla
    old "Alright, I'll get to it."
    new "分かった、取りかかるよ。"

    # say L812 pla
    old "Hi Mrs. Jade, how are you?"
    new "Jad: こんにちは、ジャッドさん、元気ですか？"

    # say L813 jad
    old "[pla]! Hi, how are you?"
    new "[pla]！こんにちは、元気ですか？"

    # say L816 jad
    old "Did you come to work in the bathroom?"
    new "トイレで働くため来たの？"

    # say L818 pla
    old "Yes, there is still work to be done."
    new "はい、まだやることあるからな。"

    # say L819 jad
    old "Oh, thank you darling. Well, you know where the materials are, I won't bother you."
    new "あら、ありがとう Darling。材料の場所は知ってるから、邪魔しないわね。"

    # say L821 pla
    old "Sure, I'll get to it."
    new "わかった、手をつけるよ。"

    # say L827 pla
    old "There's some work to do here. But, I know what I have to do, so, it should be easy."
    new "ここにはやることがあるな。でも、何をすればいいか分かってるから、簡単だよ。"

    # say L828 pla
    old "Well, I guess I'll get to it."
    new "じゃあ、取りかかろうかな。"

    # say L829 pla
    old "I'll try and finish this quickly."
    new "早めに片付けようと思う。"

    # say L872 pla
    old "Phew, I got a lot done today."
    new "ふう、今日も結構やれたな。"

    # say L873 pla
    old "Although, I still have quite a bit to do, anyway, at least this is something."
    new "でも、まだやることが多いけど、せめてこれだけはできたな。"

    # say L874 pla
    old "It's kinda late, so, let's call it a day."
    new "もうちょっと遅いし、今日はこの辺で終わりにしよう。"

    # say L895 pla
    old "But, she knew I was here, just next to her bedroom..."
    new "でも、彼女は俺がここにいること知ってる、彼女の寝室のすぐ隣に..."

    # say L911 jad
    old "It's getting a bit late [pla], I think we just better call it a day."
    new "もう少し遅い時間になったし [pla]、今日はここまでにしておきましょう。"

    # say L913 pla
    old "That's right Mrs. Jade, I'm actually happy with it, I got quite a bit done today."
    new "そうですよね、ジェイドさん。今日は結構進めたので満足です。"

    # say L914 pla
    old "But you are right, it's kinda late now, I better come back and continue another time."
    new "でも君が言う通り、もう遅いな、また今度続きをやろう。"

    # say L915 jad
    old "Well, it's great that you had progressed a lot, thanks, honey."
    new "進捗がたくさん進んだのは嬉しいわ、ありがとう、ハニー。"

    # say L916 jad
    old "You have no idea of how helpful you are."
    new "あなたがどれだけ役立つのか、想像もつかないわ。"

    # say L917 pla
    old "My pleasure."
    new "喜んでさ、jadさん。"

    # say L918 jad
    old "You're so sweet."
    new "あなたってほんと優しいね。"

    # say L919 jad
    old "By the way, don't forget to bring me the bill for the materials, so, that I can reimburse you."
    new "それから、材料費の領収書を忘れずに持ってきてね、後で私が精算するから。"

    # say L920 pla
    old "Sure thing. Well, good night Mrs. Jade."
    new "了解。じゃあ、おやすみ、ジェイドさん。"

    # say L921 jad
    old "Good night honey."
    new "おやすみ、 Darling。"

    # say L958 hin
    old "Hi [pla], you came to help mom with the bathroom?"
    new "おっ、[pla]、お風呂の手伝いに来たの？"

    # say L960 pla
    old "I wasn't expecting to see you here. I thought you had that extra work with the teacher."
    new "君がここにいるとは思わなかったな。先生と追加の授業があると思ってたんだ。"

    # say L962 hin
    old "Well, I did, but the teacher had something important to do."
    new "でも、先生には重要な用事があったんだ。"

    # say L963 hin
    old "So, I'm free today."
    new "じゃあ、今日は空いてるんだ。"

    # say L964 pla
    old "Oh, cool."
    new "へえ、いいね。"

    # say L965 hin
    old "Yeah, it is, and my mom is  not here, and she'll be out for a while... You know what this means, right?"
    new "そう、今日はずっと空いてるし、ママもいないし、しばらく帰ってこないんだよ…これって何か意味がわかるよね？"

    # say L966 pla
    old "Uhh, you want to finish the movie?"
    new "うーん、映画を見終わる？"

    # say L967 hin
    old "Hahaha, no you dummy."
    new "ははは、違うのバカ。"

    # say L968 hin
    old "I mean that we're finally alone."
    new "つまり、ついに二人きりになれたってこと。"

    # say L974 hin
    old "We have some privacy to be a little... Intimate."
    new "私たちだけの時間だから、ちょっと… 親密になろうね。"

    # say L975 pla
    old "Oh... A- alright."
    new "オッ… ア、いいよ。"

    # say L976 hin
    old "So, what do you say? We should go up to my bedroom."
    new "じゃあ、どうする？私の寝室に行こうよ。"

    # say L977 pla
    old "Uhh... Are you sure about this? I mean what if your mom comes home and sees us again?"
    new "うーん… 本当に大丈夫なのか？ 万一、お母さんが帰ってきてまた見つかったらどうする？"

    # say L979 hin
    old "Relax, she won't be home for a while. Besides, you heard what she told us, she's ok with us doing it."
    new "安心しなさい、彼女はしばらく帰ってこないから。それに、私たちがすることを許可してくれたじゃない。"

    # say L980 hin
    old "And we'll be in my bedroom."
    new "そして私の寝室でやるわ。"

    # say L981 pla
    old "I- I guess you're right."
    new "うーん、そうかもな。"

    # say L983 hin
    old "Stop worrying, just come with me."
    new "心配しないで、私について来なさい。"

    # say L991 hin
    old "I've been waiting for this for a while."
    new "この瞬間を待ってたのよ。"

    # say L992 hin
    old "Every time we've tried to do it we've been getting interrupted."
    new "毎回やろうとしてると中断されちゃうんだよね。"

    # say L993 hin
    old "I was thinking we were never going to have a chance to do it again."
    new "ずっとこんな感じで中断され続けて、もう二度とチャンスがないんじゃないかって思ってたの。"

    # say L994 pla
    old "Well, we're finally alone."
    new "まあ、ついに二人きりになったな。"

    # say L995 hin
    old "Yeah, so, let's don't waste more time. I want to feel you inside."
    new "そうよ、だから時間浪費しないで。あなたのなかに入りたいの。"

    # say L1009 hin
    old "Well, I'm very happy we finally got to do it without being interrupted."
    new "やっと二人きりになれて嬉しいわ。中断されずに済んで良かったわ。"

    # say L1010 pla
    old "Yeah, me too..."
    new "うん、俺も。"

    # say L1011 hin
    old "Are you going home now?"
    new "今から家に帰るの？"

    # say L1012 pla
    old "I think I'll go take a look at the bathroom before your mom gets home."
    new "トイレを見に行ってくるよ、君のママが帰る前にね。"

    # say L1013 hin
    old "Ok, then I guess I'll just stay here and organize my bedroom."
    new "じゃあ、私はここにいて自分の寝室を片付けるわ。"

    # say L1025 pla
    old "Oh! Hi Mrs. Jade."
    new "オッ！こんにちは、ジェイドさん。"

    # say L1026 pla
    old "I didn't know you were home already."
    new "君がもう帰ってるとは知らなかったな。"

    # say L1028 jad
    old "Hi [pla], I- I just arrived."
    new "嗨 [pla]、あたし、今帰ったところ。"

    # say L1029 jad
    old "Did you come to check on the bathroom?"
    new "トイレを見に来たの？"

    # say L1030 pla
    old "Uhh... I did, yeah, then I ran into Hinn, and we started talking."
    new "うーん… そう、それからヒンと出会って、話し始めちゃったんだ。"

    # say L1031 jad
    old "Oh, that's ok."
    new "あ、それはいいわ。"

    # say L1032 jad
    old "Actually, [pla], it's getting kind of late, and I'm sure you must be tired from working so... Hard."
    new "実は、[pla]、もう遅いしね、きっと疲れてるだろうから…頑張りすぎたでしょ。"

    # say L1034 jad
    old "Why don't you go home for now? And just come back another time?"
    new "今帰った方がいいわよ、また別の日に来ればいいのじゃない"

    # say L1036 pla
    old "Are you sure? I'm not really all that tired, I could just work a little on the bathroom and..."
    new "別に疲れてないけど、ちょっとだけトイレの掃除でもしてから…"

    # say L1037 jad
    old "I'm sure. I think I would like to go to bed early today, so, it's fine if you take a day free."
    new "大丈夫よ。今日は早めに寝たいから、あなたが休む日を取っても全然いいわ。"

    # say L1038 pla
    old "Uh, ok, sure."
    new "うん、わかった。"

    # say L1039 pla
    old "Then I guess I'll leave for today."
    new "じゃあ今日は帰るよ。"

    # say L1040 jad
    old "Sure honey, see you later."
    new "じゃあね、また後でね。"

    # say L1056 pla
    old "Oh, hi Hinn! I didn't think I'd see you here. I thought you were going to be in school."
    new "お、ヒン！ここであなたに会うとは思わなかったよ。学校に行ってると Thought してたけど。"

    # say L1057 hin
    old "Hi [pla], I only popped in to grab a couple of books, I'm on my way back."
    new "お、[pla]、ちょっと本を取りに来ただけ、今から戻るところだよ。"

    # say L1059 pla
    old "Uhh, yeah."
    new "うーん、そうね。"

    # say L1060 hin
    old "Well, my mom's not home right now, but you can go ahead and get started."
    new "WELL、母は今家にいないけど、先に始めていいよ。"

    # say L1061 hin
    old "She'll be here in no time."
    new "すぐ来るわね。"

    # say L1063 hin
    old "Good, that way you'll finish quickly."
    new "そうね、そうすれば早く終わるわ。"

    # say L1064 hin
    old "So, that we'll have time to ourselves again."
    new "そうすればまた二人きりの時間が持てるわね。"

    # say L1066 hin
    old "Well, I gotta run, bye [pla]."
    new "じゃあ、行かなくちゃ、バイバイ [pla]。"

    # say L1067 pla
    old "See you Hinn!"
    new "またね、ヒン！"

    # say L1085 pla
    old "Oh! Wow!"
    new "オォ！すごい！"

    # say L1090 jad
    old "Oh God! [pla]! W- What are you doing here?"
    new "おお神様！ [pla]！ ここに何してるの？"

    # say L1097 pla
    old "I- I came to work on the bathroom."
    new "俺、バスルームの工事に来たんだ。"

    # say L1098 pla
    old "I didn't know you were here Mrs. Jade."
    new "俺、君がここにいるって知らなかったんだ、ジェイドさん。"

    # say L1099 jad
    old "Uhh... I- it's fine, I suppose Hinn let you in while I wasn't in here, right?"
    new "うーん… 大丈夫だよ、きっとヒンが入らせてくれたんだよね、私がいなかったからって。"

    # say L1100 pla
    old "Y- yeah, yeah, that's what happened..."
    new "うん、そう、そんな感じだ..."

    # say L1101 jad
    old "I'm sorry it's my fault, I didn't know you were already here. You just startled me, that's all."
    new "ごめんなさい、私のせいだよ。あなたがもうここにいるって知らなかったの。びっくりさせちゃっただけだから。"

    # say L1108 pla
    old "I- I think I should leave now."
    new "俺、もう行こうかな。"

    # say L1110 jad
    old "Yeah, you probably should."
    new "うん、そうした方がいいね。"

    # say L1111 pla
    old "R- Right... See you later Mrs. Jade."
    new "Ｒ- 右… またね、ジェイドさん。"

    # say L1133 jad
    old "The gaul off the man!!!"
    new "この男のガルって何よ！！"

    # say L1134 hin
    old "I know, I know!! You don't need to keep telling me about it!"
    new "知ってるよ、知ってるよ！！ 何度も言われなくてもいいのに！"

    # say L1135 jad
    old "I just can't believe your father sometimes!!!"
    new "信じられないよ、時々お父さんのこと！！！"

    # say L1136 jad
    old "So, this is why he never had any money and he kept coming up with excuses when it came to paying the alimony!"
    new "だから、これが彼がいつもお金がなくて、養育費を払うときにはいつも言い訳ばかりだった理由なんだね。"

    # say L1137 hin
    old "I know mom, I know, but again, I have nothing to do with it!!"
    new "知ってるよ、ママ。でもこれと私は全然関係ないの！！"

    # say L1138 jad
    old "I didn't say you had to."
    new "言わなかったよ。"

    # say L1143 jad
    old "{b}*Sigh*{/b} I'm sorry Hinn, honey, I shouldn't be screaming like this."
    new "{b}……{/b} ごめん、ヒン、私がこんなに怒鳴っちゃダメよね。"

    # say L1144 jad
    old "But I just can't believe how brazen your father is!!!"
    new "でも、お父さんの厚顔無恥さには驚くしかないよ！"

    # say L1145 jad
    old "Not only does he take his little girlfriend on some expensive vacation."
    new "彼の小女友達を高級旅行に連れて行くだけでなく、結婚まで申し込んでいるんだよ。"

    # say L1146 jad
    old "But he's also asking her to marry him?!!!"
    new "でも、彼女と結婚しようとしてるの？！！！"

    # say L1147 jad
    old "I mean! GOD!!"
    new "うわ！神！！"

    # say L1148 hin
    old "Oh, [pla]! H- Hi, I didn't notice when you came in."
    new "あ、[pla]！ あたし、入ってきたの気づかなかったの。"

    # say L1152 jad
    old "[pla], H- Hi honey."
    new "[pla]、ハニー、こんにちは。"

    # say L1153 pla
    old "H- hi Mrs. Jade, I came to work in the bathroom, is everything ok?"
    new "嗨、ジェイドさん。お風呂場で作業するために来たんですが、大丈夫ですか？"

    # say L1154 jad
    old "Well, not really."
    new "まあ、そうでもないかな。"

    # say L1155 jad
    old "I- I think I need to let my head cool down a bit. I'll just leave you two alone so you can talk."
    new "ちょっと頭を冷やした方がいいかも。二人でゆっくり話すといいわ。"

    # say L1165 hin
    old "Sorry you had to see that."
    new "見ちゃってごめんなさい。"

    # say L1167 pla
    old "It's ok. So, I take it your father has been giving you some trouble?"
    new "大丈夫だよ。で、君の父親が君に何か Trouble を起こしてるってことか？"

    # say L1168 hin
    old "Hmph, you can say that twice."
    new "ふん、そう言えるわね。"

    # say L1169 hin
    old "Listen [pla], we're very thankful that you're taking the time to come work on the bathroom repairs."
    new "[pla]、Bathroomの修理に来てくださって本当にありがとうございます。"

    # say L1170 hin
    old "But I don't think today's a good day. With my father acting like an idiot my mom's not in a very good mood."
    new "でも今日っていい日じゃないなあ。パパがバカなことばっかりして、ママも機嫌が悪いんだ。"

    # say L1171 hin
    old "And I don't feel good either. Do you think you could come another time?"
    new "私も調子がよくないの。別の日に来てくれないかな。"

    # say L1172 pla
    old "Of course, of course. Hey, don't worry about it, this is completely understandable."
    new "もちろん、もちろん。心配しなくていい、これは全く理解できるよ。"

    # say L1173 pla
    old "It's fine. I'll just leave, so, the two of you can rest, and I'll come back some other day."
    new "大丈夫だよ。俺が帰るから、二人でゆっくり休んで、また別の日に来るよ。"

    # say L1174 hin
    old "Thank you, I'm glad you understand."
    new "ありがとう、理解してくれて嬉しいです。"

    # say L1176 pla
    old "Alright, then see you later."
    new "じゃあ、またね。"

    # say L1177 hin
    old "See you [pla], thank you again."
    new "またね[pla]、ありがとう。"

    # say L1195 pla
    old "Oh! dammit, the pipe got broken again, and now my pants are all wet."
    new "ああ！くそ、また配管が壊れちまったよ、今度はズボンまでびしょ濡れだ。"

    # say L1203 jad
    old "[pla]! Is everything ok?! I heard a loud noise."
    new "[pla]！大丈夫ですか？！大きな音がしたから心配になって。"

    # say L1205 pla
    old "Yeah, yeah, don't worry. Is just that one of the pipes broke and I got spilled with water. But I'm ok."
    new "大丈夫、心配しなくていい。ただパイプが壊れて水をかぶっただけだ。でも俺は大丈夫だ。"

    # say L1206 jad
    old "Oh, ok, that's somewhat of a relief."
    new "あ、そう、少し安心したわ。"

    # say L1207 jad
    old "Come with me, let's go to the other bathroom, so, you can towel dry."
    new "一緒に来なよ、他のバスルームでタオルドライしよう。"

    # say L1208 pla
    old "Oh, don't worry, I'm fine really."
    new "心配しなくていい、大丈夫really."

    # say L1209 jad
    old "Don't be silly, you don't want to catch a cold. Come with me."
    new "バカ言わないで、風邪引きたくないでしょ。一緒に来なよ。"

    # say L1222 jad
    old "Okay, let me give you a hand with that."
    new "大丈夫、手伝ってあげるから。"

    # say L1240 pla
    old "Uhh, I- I'm sorry Mrs. Jade, I don't know what to say. It's just that..."
    new "うーん、すみません、ジェイドさん。何て言ったらいいのかわからないんです。ただ、その……"

    # say L1241 jad
    old "It's ok, it's ok, don't worry. You're a young man, after all."
    new "大丈夫、大丈夫、心配しないで。あなたは若者なのだから。"

    # say L1243 jad
    old "I- I'll take it as a compliment."
    new "うーん、お compliment は嬉しいな。"

    # say L1245 pla
    old "S- sure, t- thank you."
    new "うーん… ありがとう。"

    # say L1246 jad
    old "Now, why don't you take those pants off? So, I'll throw them in the dryer."
    new "じゃあ、そのジーンズ脱いで？ そうしたら乾燥機に入れるから。"

    # say L1248 pla
    old "Uhh... Alright."
    new "うーん… 分かった。"

    # say L1254 jad
    old "(What?! He's not wearing anything!!)"
    new "(ええっ？！ 何も穿いてないじゃない！！)"

    # say L1255 jad
    old "(Does he just go outside without underwear on?)"
    new "（まさか下着も穿かずに外に出るの？）"

    # say L1256 jad
    old "(But I must say, it's so... big! Is that what my daughters been putting in her?)"
    new "（でも、これだけ大きいなんて…。娘がこれを入れてたの？）"

    # say L1257 pla
    old "Uhh... Mrs. Jade?"
    new "うっ……ジェイドさん？"

    # say L1262 jad
    old "What? Oh, right!"
    new "何？あ、そうね！"

    # say L1263 jad
    old "Just wait here, I'm going to put this on the dryer and see if there's a pajama bottom or something that you can use."
    new "待ってて、これ乾燥機に入れて、パジャマのボトムか何か使えるものがないか探してくるから。"

    # say L1277 jad
    old "{i}OH MY GOD, HINN IS HERE!{/i}"
    new "{i}ああ、神様！ヒンがここにいる！{/i}"

    # say L1280 jad
    old "Uhh... H- hi honey! How did school go?"
    new "うーん… ひーん、お帰り！学校はどうだった？"

    # say L1281 hin
    old "Fine. Hey mom, are you going to be there much longer?"
    new "ねえママ、もうすぐ帰るの？"

    # say L1282 hin
    old "I kinda need to use the bathroom."
    new "ちょっとトイレに行かないといけないな。"

    # say L1285 jad
    old "{i}OH, NO, NO, NO... SHE CAN'T SEE US LIKE THIS...{/i}"
    new "{i}ああ、ダメ、ダメ、ダメ… 見られちゃダメよ…{/i}"

    # say L1288 jad
    old "Uhhh! I'll be here for a while, honey."
    new "うーん！ちょっと待ってな、ハニー。"

    # say L1289 jad
    old "I- I'm taking a shower and.... Uhh, I just got in. Sorry honey."
    new "あ、あたしシャワー浴びて……うーん、刚に入ったの。ごめんね、はちみつ。"

    # say L1290 hin
    old "Oh, but I only need to use the toilet, so, it should be fine."
    new "でもトイレだけなら大丈夫よ"

    # say L1291 jad
    old "Uhh... Uhhh..."
    new "うーん… うーん…"

    # say L1295 jad
    old "{i}Shut! What are we going to do?!!{/i}"
    new "{i}シャッ！どうしよう？！！{/i}"

    # say L1296 jad
    old "{i}If she sees you here she'll flip her mind.{/i}"
    new "{i}もし彼女がここであなたを見つければ、頭を吹き飛ばすわ。{/i}"

    # say L1297 jad
    old "{i}And with how difficult it's been to deal with her lately.{/i}"
    new "{i}最近彼女と上手くやってるわけじゃないし。{/i}"

    # say L1298 jad
    old "{i}We need to hide you!{/i}"
    new "{i}隠さないと！{/i}"

    # say L1300 pla
    old "{i}I don't really know where I could hide Mrs. Jade.{/i}"
    new "{i}俺もどこに隠せばいいのかわからないよ、ジェイドさん。{/i}"

    # say L1304 jad
    old "Uhh, yeah, yeah, j- just give a sec, honey."
    new "うーん、そう、そう、ちょっと待って honey。"

    # say L1305 hin
    old "Ughh, come on mom, you can just keep taking your shower."
    new "うーん、ママ、シャワーを続けなよ。"

    # say L1306 jad
    old "J- just give me a second!"
    new "ちょっとだけ待って！"

    # say L1309 jad
    old "{i}Come with me! Hurry up!{/i}"
    new "{i}一緒に来て！早くして！{/i}"

    # say L1322 jad
    old "Ok, you can come in!"
    new "はい、入っていいわよ！"

    # say L1330 hin
    old "Mom, didn't [pla] come today?"
    new "ママ、[pla]は今日来なかったの？"

    # say L1331 jad
    old "Uhh... N- no, he didn't. I guess he must be very busy with school."
    new "うーん… い、いえ、来なかったみたいだね。学校が忙しいのかな。"

    # say L1332 hin
    old "Hmm, that makes sense."
    new "うーん、そうよね。"

    # say L1333 jad
    old "He's very busy, so, we should just let him come when he can find the time."
    new "彼は忙しいから、来られるときに来ればいいよ。"

    # say L1335 jad
    old "(Wait... What is this I'm feeling... Is [pla]'s cock between my legs?)"
    new "（待って……これは何を感じてるの……[pla]のちんこが私の足の間に……？）"

    # say L1339 jad
    old "(Holy cow! It's huge!)"
    new "（うわさっ！　でかい！）"

    # say L1340 jad
    old "(And still hard... Oh my God...)"
    new "（まだ硬い… オマイゴッド…）"

    # say L1342 jad
    old "Uhh, w- what? With Hiashi?"
    new "うっ、え、ヒアシと？"

    # say L1343 jad
    old "I- I haven't."
    new "い-いや、してない。"

    # say L1344 jad
    old "(Mmm... Damn, I feel so horny all of a sudden… I haven't been in an intimate situation like this in years...)"
    new "ん……くそ、急にすごく欲しくなっちゃった……こんな密着した状況になったの、何年も前以来よ……"

    # say L1345 jad
    old "I- I called him but he didn't answer."
    new "あー、電話したんだけど出なかったの。"

    # say L1356 jad
    old "Listen, I think it's best if you leave now. Here are your pants."
    new "ねぇ、今すぐ帰った方がいいと思うの。これがあなたのパンツよ。"

    # say L1362 jad
    old "I'm sorry, I wasn't able to dry them for you."
    new "ごめん、乾かすの忘れてたよ。"

    # say L1363 jad
    old "But Hinn might come back, and this situation is already difficult to explain."
    new "でもヒンが戻ってくるかもしれないし、この状況は説明するのが難しいよ。"

    # say L1364 pla
    old "It's ok, I'll just go straight home."
    new "大丈夫、そのまま家に帰るよ。"

    # say L1365 jad
    old "Yeah, that's the best idea."
    new "うん、そうするのが一番だね。"

    # say L1366 pla
    old "Ok, see you another time Mrs. Jade. I'll come back later to keep working on the repairs"
    new "じゃだ夫人、また今度ね。修理の続きを後でやるから"

    # say L1385 jad
    old "That's good."
    new "それはいいわね。"

    # say L1386 jad
    old "Listen, I'm glad you came."
    new "聞いて、来てくれて嬉しいわ。"

    # say L1387 pla
    old "Uhh, really? Why?"
    new "うーん、本当？なぜ？"

    # say L1388 jad
    old "Well, I wanted to talk to you. About what happened last time."
    new "まあ、話したいことがあったの。前回のことをね。"

    # say L1391 pla
    old "Uh... sure."
    new "うーん…いいよ。"

    # say L1393 jad
    old "I'm so sorry [pla], I don't know what got into me."
    new "ごめんなさい [pla]、何が私をそんなにさせたのか全然わからないの。"

    # say L1394 jad
    old "It's just that I've been so stressed out about so many things."
    new "最近、いろいろなことでストレスが溜まってしまって。"

    # say L1396 jad
    old "You know, dealing with my husband's behavior, and Hinn's not been easy either."
    new "夫の態度のことや、ヒンのことでもストレスが溜まっていたの。"

    # say L1398 jad
    old "So, I'm sorry, very, very sorry."
    new "だから、本当に本当にごめんなさい。"

    # say L1399 pla
    old "I- it's ok, Mrs. Jade. Really, don't worry."
    new "大丈夫ですよ、ジェイドさん。ほんと、気にしないでください。"

    # say L1400 pla
    old "I understand, it was an accident. It's fine."
    new "分かってるよ、事故だったんだ。大丈夫だよ。"

    # say L1402 pla
    old "Yes, I know that you and Hinn are going through a lot lately."
    new "はい、最近君とヒンが大変なことは知ってるよ。"

    # say L1403 pla
    old "Uhh, and yesterday, it was mostly a misunderstanding that escalated quickly."
    new "うーん、昨日はほとんど誤解から急に悪化したんだ。"

    # say L1404 jad
    old "Oh, thank you [pla]! Thanks for understanding, you're such a good young man."
    new "あ、ありがとう[pla]！理解してくれてありがとう、いい子だね。"

    # say L1405 pla
    old "Thanks for saying that Mrs. Jade."
    new "ありがとう、ジェイドさん。"

    # say L1407 pla
    old "So, I'll just go to work in the bathroom. I think it shouldn't be long before I finish."
    new "じゃあ、Bathroomで作業するよ。多分すぐ終わると思う。"

    # say L1408 jad
    old "Sure, sure, also, thanks a lot for doing that."
    new "もちろん、それとも、やってくれてありがとう。"

    # say L1409 pla
    old "It's not a problem."
    new "問題ないよ。"

    # say L1423 pla
    old "Hi! Hello? Hinn? Mrs. Jade?"
    new "嗨！こんにちは？ヒン？ジェイド夫人？"

    # say L1424 pla
    old "That's weird, they're usually here in the afternoon."
    new "変だな、普段は午後にいるのに。"

    # say L1425 pla
    old "Hello?!"
    new "こんにちは？！"

    # say L1433 pla
    old "Hinn? Mrs. Jade? Anyone here?"
    new "ヒン？ジェイドさん？誰かいますか？"

    # say L1434 pla
    old "This is odd."
    new "妙だな。"

    # say L1435 pla
    old "I guess they went out."
    new "彼らは出かけたみたいだな。"

    # say L1436 pla
    old "I suppose there's no problem if I go up and work on the bathroom."
    new "まあ、俺が上がってバスルームで作業をしても問題ないだろう。"

    # say L1459 jad
    old "Oh my God! [pla]! W- what are you doing there?!"
    new "おっ天！ [pla]！ なにやってるの、そこであなた？！"

    # say L1460 pla
    old "S- sorry! I didn't see anything, I was looking for you and I just opened the door."
    new "す、すみません！何も見てないよ、君を探してただけで、ドアを開けちゃった。"

    # say L1461 pla
    old "I was going to work in the bathroom, but, I think I should just leave."
    new "Bathroomで作業しようと思ってたけど、やっぱ帰るよ。"

    # say L1469 jad
    old "Uhh, this is my fault, I'd forgotten you were coming today."
    new "うーん、これは私のせいね、あなたが今日来る gonna 今日来ることを忘れてたの。"

    # say L1470 jad
    old "So, I'll just dress up and you can get to work on the repairs."
    new "じゃあ、着替えて、修理の作業を始めてね。"

    # say L1471 jad
    old "Can we just pretend this never happened?"
    new "これなかったことにしてもらえる？"

    # say L1472 pla
    old "Uhhh, sure."
    new "うーん、いいな。"

    # say L1480 jad
    old "(My God, he has another boner, and it's so big.)"
    new "神様、また Erect してるの、しかも这么大。"

    # say L1481 pla
    old "I- I think I'll start working on the bathroom, then."
    new "うーん、そうだな。じゃあ、まずはバスルームから始めるか。"

    # say L1482 jad
    old "R- right, right. Well, you know where everything is."
    new "R- 右、右。まあ、どこにあるか知ってるよね。"

    # say L1492 pla
    old "Wow, that was crazy..."
    new "すげえ、さっきのはマジでびっくりしたわ..."

    # say L1493 pla
    old "Thank God, she is very calm and reasonable."
    new "良かった、彼女は落ち着いてて合理的だな。"

    # say L1494 pla
    old "Anyway, I better finish this as soon as possible."
    new "とにかく、早く片付けないと。"

    # say L1507 pla
    old "Oh, hi Mrs. Jade, yeah, I'm done for today."
    new "あ、こんにちはジャッド夫人、はい、今日は終わりました。"

    # say L1508 pla
    old "It's almost done, I don't think it will be too long until I'm finished with the repairs."
    new "もうすぐ終わるよ、修理もそんなに時間はかからないと思う。"

    # say L1509 jad
    old "That's great honey, thank you."
    new "それは良かったわ、ありがとう。"

    # say L1510 jad
    old "And listen, about what you saw me doing today."
    new "そして聞いて、今日見た私のことについて。"

    # say L1511 jad
    old "I'm sorry, I wouldn't have wanted you to see that. It must've been very awkward."
    new "ごめんなさい、見られたくなかったの。すごく気まずかったよね。"

    # say L1513 pla
    old "No, no, I'm the one who should be apologizing, this is your house after all."
    new "Jad、そんなことないよ、謝るのは俺の方だ。ここは君の家なんだし。"

    # say L1514 pla
    old "I shouldn't have come into your bedroom without knocking."
    new "ドアをノックせずに君の寝室に入っちゃいけなかったな。"

    # say L1515 jad
    old "Well, anyway, I'm sorry you had to see that."
    new "まあ、とにかく、見せちゃってごめんね。"

    # say L1516 jad
    old "I'm sure it must not be enjoyable to see an older woman in those... Circumstances."
    new "きっと、そんな状況で年上の女性を見るのは楽しいものじゃないよね。"

    # say L1518 pla
    old "Ohh, of course not, you're a very beautiful woman."
    new "もちろん、君はとても美しい女性だよ。"

    # say L1520 pla
    old "I- I mean...!"
    new "い、いって……！"

    # say L1521 jad
    old "I get it, I get it, thank you [pla]."
    new "分かった、分かった、ありがとう [pla]。"

    # say L1523 pla
    old "Oh, ok."
    new "分かった、オーケー。"

    # say L1524 pla
    old "Well, I think I should get going."
    new "じゃあ、俺は帰るかな。"

    # say L1525 jad
    old "Yeah, it's getting a little late."
    new "うん、ちょっと遅くなってきたね。"

    # say L1526 pla
    old "Have a good night Mrs. Jade."
    new "おやすみなさい、ジェイド夫人。"

    # say L1527 jad
    old "You too darling."
    new "おやすみなさい Darling。"

    # say L1546 pla
    old "Oh, hi Mrs. Jade, Mrs. White."
    new "お、こんにちはジャド夫人、ホワイト夫人。"

    # say L1551 whi
    old "Well hello there [pla]. Tell me jade? What is this fine young man doing here?"
    new "まあ、こんにちは [pla]。教えてちょうだい、ジェイド？このすばらしい若者がここにいるのはなぜなのかしら？"

    # say L1552 jad
    old "Well, do you remember I told you there was some damage in my bathroom?"
    new "そうです、私が先日話したように、私の浴室に少し損傷があったことを覚えていらっしゃいますか？"

    # say L1553 whi
    old "Uh huh."
    new "うん。"

    # say L1554 jad
    old "Well, I'll have you know that [pla] here was kind enough to volunteer to help me do the repairs."
    new "じゃあ、知っておいてほしいんだけど、[pla] が親切にも修理のお手伝いを申し出てくれたの。"

    # say L1556 jad
    old "He did. You know that with everything that's been going on with Hiashi things have been a little tight around here."
    new "彼はそうしてくれたの。Hiashiのことで忙しいから、ここ最近お金に余裕がなかったのよ。"

    # say L1557 whi
    old "Uhmm."
    new "うーん。"

    # say L1558 jad
    old "Well, I couldn't really afford for a plumber to do it, but [pla] has been  perfect."
    new "WELL、[pla] がいてくれて本当に助かったわ。彼は本当に完璧ね。"

    # say L1559 jad
    old "He's such a fine young man."
    new "彼は本当に立派な若者だね。"

    # say L1561 whi
    old "Oh, you don't have to tell me too much about it."
    new "Oh、それほど詳しく話さなくてもいいんです。"

    # say L1563 whi
    old "I know full well what a helpful capable young man [pla] is. He actually helped me with something in the past."
    new "私はよく分かっていますわ、[pla]さんがどれだけ優しくて頼りになる若者なのか。彼は過去に私にも手伝ってくれたことがあります。"

    # say L1564 pla
    old "Uh... I think I'll go work in the bathroom for now."
    new "うーん……一応、トイレで作業することにするかな。"

    # say L1565 jad
    old "Sure honey, you know where everything is."
    new "もちろん、あなたがどこにあるか知っているわ。"

    # say L1566 pla
    old "With your permission, see you later, Mrs. White and Mrs Jade."
    new "ご許可をいただき、また後で。ホワイトさん、ジェイドさん。"

    # say L1576 whi
    old "So, tell me, what came of that whole business with Hiashi? Did you get him to pay your alimony?"
    new "じゃださん、その件はどうなったの？ヒアシさんには養育費を払わせることができたの？"

    # say L1577 jad
    old "Ha! Not only he didn't pay, but he also took that little bimbo he calls his girlfriend on vacation."
    new "ははは、支払うどころか、彼女が彼の彼女だと呼ぶその小娘を連れて旅行に行っちゃったんです。"

    # say L1578 whi
    old "No way!"
    new "そんなはずないよ！"

    # say L1579 whi
    old "You're joking."
    new "冗談じゃないわ。"

    # say L1581 jad
    old "I wish, but that's not all of it. Apparently, while they were there."
    new "望むけど、それだけじゃないの。どうやらそこにいたときに何かあったみたいよ。"

    # say L1582 jad
    old "He asked her to marry him!"
    new "彼は彼女に求婚したんだよ！"

    # say L1583 whi
    old "Oh my God! I can't believe it!"
    new "神様！ 信じられないわ！"

    # say L1584 whi
    old "I remember he was a pig, but I didn't know just how low he could sink."
    new "彼が豚だとは覚えていたけど、ここまで落ちぶれるとは思わなかったわ。"

    # say L1585 jad
    old "Ugh, Tell me about it!"
    new "うーん、本当にね。"

    # say L1586 jad
    old "After he posted the photos with the engagement ring, he realized that they were public, so, he took them down."
    new "彼が婚約指輪の写真を投稿した後、それが公開されていることに気づいて、すぐに削除したの。"

    # say L1587 jad
    old "But by that point, it was already too late. We had already seen them."
    new "でもその時点で、もう遅かったの。私たちはすでに見ちゃってたから。"

    # say L1588 whi
    old "I just can't believe how irresponsible that man is."
    new "その男の人、ほんとにもう、責任感がないわ。"

    # say L1589 jad
    old "{b}*Sigh*{/b} In a way, I can't either, I mean, ever since we broke up I never had any hopes that he would be exemplary."
    new "{b}*ため息*{/b} そうね、私もそう思うわ。別れてから、彼が模範的な人になるなんて、期待してなかったもの。"

    # say L1590 jad
    old "But I didn't want to believe he would stand this low. It's always the same disappointing story when it comes to him."
    new "でも、彼がこれほどまでに落ちぶまっているとは思いたくなかったの。彼のことになると、いつも同じようながっかりする話ばかりだもの。"

    # say L1591 jad
    old "And that's not all, I've been having terrible migraines, and insomnia because of it."
    new "それに、ひどい頭痛が続いて、そのせいで不眠症にもなってるの。"

    # say L1592 jad
    old "Not to mention that Hinn's been a real handful as of late. I swear to God, I don't even know how to talk to her anymore."
    new "それに最近のヒンは本当に手がかかるの。神様に誓って、もう彼女とどう話していいのかさえわからないよ。"

    # say L1593 jad
    old "The whole thing has culminated in me being in constant panic and with my emotions all over the place!"
    new "その結果、私は常にパニック状態で、感情がめまぐるしく変化してるの。"

    # say L1594 jad
    old "I've been thinking that maybe I should go to a psychiatrist. Maybe I have some sort of anxiety, you know?"
    new "最近、精神科医に行くべきかどうか考えているの。もしかしたら、何かの不安症かもしれないなって。"

    # say L1595 whi
    old "Well... I guess you could call it that..."
    new "まあ……そう呼んでもいいのかな……"

    # say L1596 jad
    old "Well, duh, that's the name of it. What else could it be?"
    new "まあ、その名前の通りじゃない。他に何があるっていうの？"

    # say L1597 whi
    old "For one thing, a lack of sex."
    new "一つには、セックスがないことね。"

    # say L1599 jad
    old "A what?!"
    new "何それ？！"

    # say L1600 whi
    old "You heard me, it sounds to me that what you have is a typical case of not fucking."
    new "聞こえたでしょ、君が抱えてるのは典型的なセックス不足の症状だと思うの。"

    # say L1602 whi
    old "Hey, I've been there myself, so, I know the symptoms."
    new "Hey、私も経験があるから、症状はよくわかるわ。"

    # say L1603 whi
    old "You've been under a lot of stress lately, all of that accumulates in your body."
    new "最近、ストレスがたまってるのね、それが体に影響してるのよ。"

    # say L1604 whi
    old "And since you're not sexually active with anybody you just get anxious."
    new "ensex行為をしていないから、ただ焦るだけなのよ。"

    # say L1606 jad
    old "Oh, come on! Be serious please..."
    new "お願い、真剣にしてよ…"

    # say L1608 whi
    old "I am!"
    new "私は本気です！"

    # say L1609 whi
    old "Listen, you're not having sex, but you still need to do it."
    new "君がセックスをしていないのはわかるけど、それでもやらなきゃならないのよ。"

    # say L1610 whi
    old "Add to that all of the other problems that you have to deal with."
    new "それに、あなたが抱えている他の問題も全部加わるからね。"

    # say L1611 whi
    old "And you're a ticking time bomb!"
    new "そしてあなたは爆発寸前の時限爆弾です！"

    # say L1612 whi
    old "You're repressed Jade, and believe me, that's not good for you."
    new "あなたは抑圧されてるわ、ジェイド。信じて、それは君にとってよくないのよ。"

    # say L1613 whi
    old "It's clear to me that what you need is a good fucking. That'll help you."
    new "あなたが本当に必要としているのは良いセックスだということは私には明白よ。それが君のためになるわ。"

    # say L1614 jad
    old "Hahaha, yeah right. Who am I going to do it with?"
    new "ははは、そうね。誰とやるつもり？"

    # say L1615 jad
    old "I'm an old divorced woman."
    new "私は離婚した年老いた女です。"

    # say L1616 jad
    old "Who's going to want to be with me?"
    new "誰が私と一緒にいようとするのかしら？"

    # say L1617 whi
    old "Oh! You know you're pretty. Any man would give an arm and a leg to have a chance to jump into your bed."
    new "Jadさん、あなたはとてもきれいよ。どんな男も、あなたのベッドに入れるチャンスのために右腕でも左足でも差し出すわ。"

    # say L1618 jad
    old "Yeah right."
    new "うん、そうよね。"

    # say L1620 whi
    old "Listen, girl, I'm not saying it just to mess with you. You need physical intimacy, it's good for you."
    new "君、真剣に言ってるの。身体的な親密さが必要なんだ、君のためになるから。"

    # say L1621 whi
    old "If you don't do something about it you'll just start getting depressed and maybe even having anxiety attacks!"
    new "もし何もしなければ、君はただ落ち込んでしまって、ひょっとしたら不安発作まで起こすかもしれないよ。"

    # say L1622 whi
    old "You need to release all of those things you're holding in."
    new "あなたが抱えているすべてを解放する必要があるわ。"

    # say L1624 jad
    old "Hmm, maybe you're right..."
    new "うーん、もしかしたらそうかも知れないですね…"

    # say L1626 jad
    old "But even so? Who would I even be intimate with?"
    new "でもそう言われても、誰とそんな関係になるのかしら？"

    # say L1640 pla
    old "Ok Mrs. Jade, I've  finished for today."
    new "Ok 奥さん、今日のところはこれで終わります。"

    # say L1642 jad
    old "Thank you, honey, you were done very quickly!"
    new "ありがとう、ハニー、さっさと終わったね！"

    # say L1643 pla
    old "Yeah, I would've liked to do some more, but sadly I'm busy with some school work, so, I'm gonna have to go for today."
    new "うーん、もっとやれたんだけど、残念ながら学校の宿題があるから、今日はこれで帰らせてもらうね。"

    # say L1644 jad
    old "That's ok honey, see you another time."
    new "大丈夫よ、また今度ね。"

    # say L1645 whi
    old "By the way [pla], you should come to my house one of these days."
    new "あとで [pla]、私の家に遊びに来てほしいな。"

    # say L1646 whi
    old "I can think of one or two things you could help me fix."
    new "一つか二つ、手伝ってほしいことがあるのだけど。"

    # say L1647 pla
    old "Yeah, haha... Maybe I'll go later."
    new "ははは、そうかも…後で行くかもしれねえ。"

    # say L1648 pla
    old "Well, hope to see you soon. Bye."
    new "じゃあ、またすぐ会えるのを楽しみにしているよ。バイ。"

    # say L1650 jad
    old "Bye honey."
    new "バイ、ハニー。"

    # say L1652 whi
    old "See you later sweetie."
    new "またね、甘いの。"

    # say L1661 jad
    old "So, what were we talking about?"
    new "じゃあ、何話してたっけ？"

    # say L1662 whi
    old "We were saying that you need to fuck!"
    new "私たちが言っていたのは、あなたがセックスする必要があるってことよ！"

    # say L1663 jad
    old "Ah, right, that..."
    new "あ、そうね、それのことだったわ…"

    # say L1664 jad
    old "But you know, it's not as if I'm not doing anything, I masturbate often, and I feel like that's good."
    new "でもね、何もしていないわけじゃないの、よく自分で触ってるし、それがいいと思っているの。"

    # say L1665 whi
    old "That won't be enough. Believe me, I have some experience with this."
    new "それは足りないわ。信じて、私にはこのことでの経験があるの。"

    # say L1666 whi
    old "What you need is a big, hard cock to ravage you."
    new "あなたが必要なのは、大きな硬いチ○ポで荒々しく犯されることよ。"

    # say L1668 jad
    old "So classy..."
    new "そんな上品ね…"

    # say L1670 jad
    old "But then again, who's it going to be? I don't know anybody, and I'm too busy, and frankly tired, to go out looking for dates."
    new "でもね、誰がしてくれるのかしら？知ってる人はいないし、忙しいし、正直デート探しに行くのは疲れるわ。"

    # say L1672 whi
    old "Also, not just anybody can do it. It has to be someone that can rock you."
    new "それに、誰でもできるわけじゃないわ。君を揺さぶることができる人でないとダメよ。"

    # say L1676 whi
    old "Well, I'll tell you what, I think I know just the right guy to do it!"
    new "じゃあ、私がちょうどいい相手を知っているわ。"

    # say L1677 jad
    old "You do? Do we have any common friends that I don't know about?"
    new "知ってるの？私たちに共通の友達がいるの？私が知らないだけかもしれないけど。"

    # say L1680 whi
    old "Listen, what you don't need is some old guy who's just going to get tired after a couple of pumps."
    new "君が本当に必要とするのは、数回のピストンで疲れ果ててしまうような年寄りじゃないわ。"

    # say L1681 whi
    old "You need a young, healthy stallion that's going to pump you full, and it's going to make you scream with his big dick."
    new "あなたが必要なのは、若くて元気な牡馬よ。彼はあなたを満たし、大きなちんこであなたを絶叫させるわ。"

    # say L1682 jad
    old "Hahaha, what are you saying?"
    new "ははは、何言ってるの？"

    # say L1683 jad
    old "Ok, let's say that's what I need. Where am I going to find this young stallion that's going to do that to me?"
    new "じゃあ、それが私が必要なものだとしたら、そんな若い牡馬を見つけるにはどうすればいいの？"

    # say L1684 whi
    old "Baby, you've already met him!"
    new "ベイビー、あなたはもう会ってるわよ！"

    # say L1686 jad
    old "I have?"
    new "え？会ってるの？"

    # say L1687 whi
    old "Well of course! He's always here at your house!"
    new "もちろんよ！彼はいつも君の家にいるわ。"

    # say L1689 jad
    old "What? You mean [pla]?!! What are you talking about?!"
    new "何？君は[pla]のこと？！！何言ってるの？"

    # say L1690 whi
    old "What? What's so odd about that?"
    new "何がそんなに変なの？"

    # say L1691 whi
    old "He's young, he's healthy, he's a very good kid."
    new "彼は若いし、健康で、とても良い子です。"

    # say L1692 whi
    old "And he has some experience."
    new "そして彼には少し経験があるのよ。"

    # say L1693 whi
    old "He's just what you need!"
    new "彼はちょうどあなたが必要としている人よ！"

    # say L1694 jad
    old "Yeah right! As if!"
    new "ほんとね！そんなわけないでしょ！"

    # say L1696 whi
    old "Oh my God! Why not?!"
    new "おっ天！なぜダメなのよ！"

    # say L1697 jad
    old "Well, for one thing, he's actually having sex with my daughter!"
    new "まずは、彼は私の娘と実際にセックスしてるのよ！"

    # say L1698 whi
    old "So, are they officially dating?"
    new "じゃあ、彼らは正式に付き合ってるの？"

    # say L1699 jad
    old "Well, it's complicated, it's one of those new things the kids are doing these days."
    new "複雑なの、最近の若者はそういう新しい関係性をやっているのよ。"

    # say L1700 jad
    old "You know, having sex without an official relationship... I honestly don't understand."
    new "関係が公式じゃないままセックスするって、正直理解できないんだよね。"

    # say L1701 whi
    old "Then there's no problem!"
    new "じゃあ問題ないわ！"

    # say L1702 whi
    old "Of course you couldn't tell Hinn, but that's not too much of a big deal."
    new "もちろんヒンには言えなかったでしょうけど、それほど大きな問題じゃないわ。"

    # say L1703 jad
    old "That's not all of it!"
    new "それだけじゃないの！"

    # say L1704 whi
    old "It isn't? What else then?"
    new "そうじゃないの？他还有什么别的吗？"

    # say L1705 jad
    old "He's too young..."
    new "彼はまだ子供すぎ…"

    # say L1706 jad
    old "He could be my son!"
    new "彼は私の息子のような年齢だよ！"

    # say L1707 whi
    old "Oh please! So what? Why do you think Hiashi is dating that nineteen-year-old hussy?"
    new "お願い！それがどうしたの？ヒアシが十九歳のあの女と付き合ってるってことの問題点はどこにあるの？"

    # say L1709 whi
    old "It's because the sex it's really, really good, and she helps him feel good."
    new "それはセックスが本当に、本当にいいからよ、それに彼女が彼を気持ちよくさせるのを手伝うから。"

    # say L1710 whi
    old "Also, you can use this as a chance to get back at that pig of your ex-husband's for what he's doing."
    new "それに、この機会を利用して、あなたの元夫の豚のようなやつに報復できるわ。"

    # say L1711 jad
    old "Hmm, I don't know... That would be really inappropriate."
    new "うーん、よくわからないな… それって本当に不適切だよ。"

    # say L1712 whi
    old "Oh! Stop acting as if I'm saying something crazy."
    new "Oh！ そんなことないわよ。"

    # say L1713 jad
    old "Aren't you?"
    new "そうじゃないの？"

    # say L1714 whi
    old "Please! With all of the time that he's been in here."
    new "お願い！彼がここにいる時間を考えたら。"

    # say L1716 whi
    old "Can you honestly tell me that you've never thought about having your way with him?"
    new "正直に言って、一度も彼のことを自分のものにしようと思ったことがないって言えるの？"

    # say L1717 whi
    old "Or him having his way with you. Whichever way you prefer."
    new "どちらでもいいわ。あなたが彼に手を出すのか、それとも彼があなたに手を出すのか。どちらでも構わないわ。"

    # say L1718 jad
    old "Uhhh."
    new "うーん。"

    # say L1720 whi
    old "Wait! Wait a minute!"
    new "待って待って！ちょっとだけ！"

    # say L1721 whi
    old "Don't tell me you already did something with him!"
    new "待って、待って！もう彼と何かしたの？"

    # say L1722 jad
    old "No, no, no, no!"
    new "いや、いや、いや、いや！"

    # say L1723 jad
    old "Nothing like what you're thinking."
    new "そんなことじゃないの。"

    # say L1725 whi
    old "But you did do something didn't you?"
    new "でも何かしたんでしょ？"

    # say L1726 jad
    old "You're unbelievable."
    new "信じられないわ。"

    # say L1727 jad
    old "Ok, the other day as he was doing something in the bathroom one of the pipes broke, and his pants got wet."
    new "あのね、先週彼がバスルームで何かやってたら、配管が壊れてズボンが濡れちゃったの。"

    # say L1731 jad
    old "So, I told him that maybe he should take them off just so that I could throw them in the dryer."
    new "だから、私が彼にそのズボンを脱いだ方がいいって言ったの。乾燥機に入れるためよ。"

    # say L1732 whi
    old "I like where this is going."
    new "この展開、気に入ってるわ。"

    # say L1734 jad
    old "Well, the thing is that... For some reason, he had a boner, and wasn't wearing drawls."
    new "ええ、そのことなんだけど…… 何故か彼は勃起していて、下着をつけていなかったの。"

    # say L1736 whi
    old "Oh my God and you saw his boner?!"
    new "ああっ、君ったらそのアレを見ちゃったの？！"

    # say L1737 whi
    old "Hahaha, this is great! It was huge wasn't it?"
    new "ははは、これは最高だね！ かなり大きかったんでしょ？"

    # say L1738 jad
    old "You're terrible, you know that?"
    new "あなたってほんと、最悪だね。"

    # say L1739 jad
    old "... But yes, he was very big. Like, very, very big."
    new "でもね、彼は本当に大きかったの。とても、とても大きくて。"

    # say L1740 jad
    old "But that's it, nothing else happened."
    new "でもそれだけよ、他には何も起こらなかった。"

    # say L1741 jad
    old "At all..."
    new "全然"

    # say L1742 whi
    old "It doesn't matter, this is great!"
    new "それは関係ないわ、これだけで十分よ！"

    # say L1745 whi
    old "Don't you see? He got a boner because of you! He already thinks you're hot!"
    new "見えないの？彼は君のせいで硬くなったのよ！君はもうかなりセクシーだって思ってるわ！"

    # say L1746 whi
    old "But that kid's too timid to do anything, he won't make a move unless he thinks you want it too."
    new "でもその子はあまりにも臆病だから何もしないわ、君が欲しがってると思って動くかどうかね。"

    # say L1747 whi
    old "But that's not a problem, I can deal with that."
    new "でもそれって問題じゃないの、私が対処できるから。"

    # say L1748 jad
    old "Wait! What are you going to do?!"
    new "待って！何するつもり？！"

    # say L1750 whi
    old "Don't worry, I won't do anything you don't want."
    new "心配しないで、君が望まないことは決してしないから。"

    # say L1751 jad
    old "Wait, don't do anything dumb."
    new "待って、馬鹿なことしないで。"

    # say L1752 whi
    old "Me? I'll just take care of this for you, that's all."
    new "私？ただこれを手伝うだけよ。"

    # say L1753 whi
    old "And I better leave before you change your mind."
    new "それじゃ、あなたが変心する前に帰った方がいいわ。"

    # say L1769 jad
    old "Oh my God, what did I get myself into?"
    new "ああ、何に巻き込まれたのかしら。"

    # say L1790 pla
    old "Hi [mo1]."
    new "こんにちは [mo1]。"

    # say L1791 mo1
    old "Sweetie, Mrs. White's outside, she says she has something to talk to you about."
    new "スイートピー、ミセス・ホワイトが外にいるの、あなたと話したいことがあるって言うの。"

    # say L1792 pla
    old "She wants to talk to me?"
    new "彼女が私と話したいって？"

    # say L1793 mo1
    old "Yes, she says it's something about your friend Mike."
    new "はい、彼女はマイクについて何か話したいんだって。"

    # say L1794 pla
    old "I see, well, I'll be right out."
    new "分かった、すぐに行くよ。"

    # say L1795 mo1
    old "Ok, honey."
    new "はい、わかりました。すぐに出て行きますね。"

    # say L1805 pla
    old "Hi Mrs. White, is everything alright with Mike?"
    new "白さん、マイクは大丈夫ですか？"

    # say L1806 whi
    old "Hi honey, yeah, yeah, don't worry. It's just that I need you to come with me to my house for a second."
    new "はい、心配しなくていいわ。ただ、ちょっと私の家まで来てくれないかしら。"

    # say L1807 whi
    old "There's something I want you to talk about with Mike."
    new "ミクに話してほしいことが有一点て。"

    # say L1808 pla
    old "Me? Is it something serious?"
    new "俺？何か深刻なことなのか？"

    # say L1809 whi
    old "Not really, but it's more of a guy thing, so, I think it would be better if he hears it from another man."
    new "そんなに深刻なことじゃないけど、男同士で話した方がいいと思うから、マイクに直接聞いてもらった方がいいと思う。"

    # say L1810 pla
    old "Oh, ok, I guess that's fine. Sure, I'll come with you."
    new "わかった、そうか、それならいいよ。もちろん、一緒にいくよ。"

    # say L1817 pla
    old "So, it's Mike in his bedroom?"
    new "じゃあ、マイクの寝室で会うんだね？"

    # say L1818 whi
    old "No, actually, I must admit I lied to you, he's not in the house, and he won't be for a while."
    new "実は、ウソをついてしまったんです、彼は家にいませんし、しばらくは戻ってこないんです。"

    # say L1819 pla
    old "Then how am I supposed to talk to him?"
    new "じゃあ、どうやって話せばいいんだ？"

    # say L1820 whi
    old "Well, to be honest with you [pla], I don't actually want you to talk to Mike."
    new "正直に言うと [pla]、マイクと話すのは望んでいません。"

    # say L1821 pla
    old "You don't?"
    new "君が話さなくてもいいってこと？"

    # say L1822 whi
    old "No, the person I want you to help is a friend of mine, who needs something from you."
    new "いいえ、あなたに手伝ってほしいのは私の友達で、その人があなたから何かを必要としているんです。"

    # say L1823 pla
    old "Who is it?"
    new "誰だ？"

    # say L1824 whi
    old "Well honey, it's Jade, there's something that she needs from you."
    new "まあ、ハニー、それはジェイドよ。彼女から何か必要なんだって。"

    # say L1825 pla
    old "Did anything happen to her?"
    new "彼女に何かあったのか？"

    # say L1827 whi
    old "Not yet."
    new "まだです。"

    # say L1828 pla
    old "I have to tell you, Mrs. White, you're not really making a lot of sense here, you know?"
    new "白さん、正直に言うと、あなたの言っていることが全然分かりませんね。"

    # say L1829 whi
    old "That's because I haven't really told you anything."
    new "それは私がまだ何もあなたに話していないからよ。"

    # say L1830 whi
    old "Listen [pla], the thing I want you to do, is to have sex with Jade."
    new "[pla]、私があなたに頼みたいのは、ジェイドとセックスすることよ。"

    # say L1831 pla
    old "What?!"
    new "何っ？！"

    # say L1832 whi
    old "Just as you hear it, you are going to help Jade by fucking her."
    new "聞こえた通りよ、あなたはジェイドを助けるために彼女とセックスするの。"

    # say L1833 pla
    old "Why would I do that?"
    new "なぜそれをしなきゃならないんだよ？"

    # say L1835 whi
    old "Well, there's a lot to explain, but basically, Jade's been under a lot of pressure."
    new "まあ、説明することはたくさんあるけど、要はジェイドがかなりストレスを抱えてるの。"

    # say L1836 whi
    old "She wouldn't admit it, but she's repressed. So, she really needs to release that, you know what I mean?"
    new "彼女は認めたくなかったけど、抑圧されてるの。だから、そのストレスを発散させる必要があるの、わかってるよね？"

    # say L1837 whi
    old "And since I know how gifted you are in that regard, I thought that you're the right person to help her."
    new "そして、あなたがその方面で才能があることを知っているので、彼女を助けるのに適任だと思ったんです。"

    # say L1838 pla
    old "This is crazy Mrs. White, I mean, how do we even know that Mrs. Jade would want to do anything with me?"
    new "これはおかしいですね、ホワイトさん。Jadeさんが私と一緒に何かしたいかどうか、どうやって知るんですか？"

    # say L1839 whi
    old "Oh, don't you play dumb with me!"
    new "あら、そんなふうにわからない振りをするんじゃないわよ。"

    # say L1840 whi
    old "I already know you two have done a couple of things already."
    new "もうあなた二人が何回か一緒に過ごしたことは知っていますよ。"

    # say L1842 whi
    old "So, listen carefully, this is what's going to happen..."
    new "だから、よく聞いて、これがこれから起こることよ…"

    # say L1853 jad
    old "Hey, where have you been?"
    new "Hey, どこ行ってたの？"

    # say L1854 whi
    old "I was just having a little word with [pla], you know, getting him onboard and what not."
    new "私はただ[pla]とちょっと話をしていただけよ、君も知ってる通り、彼を説得しようとしていたの。"

    # say L1855 jad
    old "Oh my God! Did you actually bring him here?"
    new "Oh my God！本当に彼を連れてきたの？"

    # say L1856 jad
    old "I can't believe I let you talk me into doing something this crazy!"
    new "信じられないわ、あなたに誘惑されてこんなばかなことになっちゃったなんて！"

    # say L1857 whi
    old "Well, he's already here, so, no turning back now."
    new "もう来ちゃってるんだから、後戻りはできないわ。"

    # say L1859 whi
    old "Listen, I already talked to him, so, you don't need to worry about anything other than enjoying yourself."
    new "Listen, 私はもう彼と話したから、君はただ楽しむことだけを考えていればいいの。"

    # say L1860 whi
    old "I don't want you thinking about anything stressful, or about your daughter."
    new "あなたがストレスを感じることや、娘のことを考えないでほしいの。"

    # say L1861 whi
    old "I especially don't want you thinking about that asshole Hiashi!"
    new "特にあのクソ野郎ヒアシのことは考えちゃダメよ！"

    # say L1862 whi
    old "All you need to do is focus on your own pleasure. Ok?"
    new "あなたの楽しみに集中することだけです。いいですね？"

    # say L1865 whi
    old "Good, then I'll tell [pla] to come in."
    new "それなら、[pla]に来てもらうことにしましょう。"

    # say L1867 whi
    old "Hey [pla]! You can come in now honey!"
    new "Hey [pla]！入ってきなさい、Darling。"

    # say L1874 pla
    old "H- hi Mrs. Jade..."
    new "こんにちは、ジェイドさん…"

    # say L1875 jad
    old "H- hi [pla]."
    new "こんにちは、[pla]。"

    # say L1876 whi
    old "Oh! What is this tension? You have to loosen up!"
    new "あら！こんなに緊張してどうするの？リラックスしなきゃダメよ！"

    # say L1877 whi
    old "Well, I think this might help a little."
    new "まあ、これなら少しは役立つかもしれないわね。"

    # say L1881 whi
    old "Look at that, isn't that just an amazing dick?"
    new "見てごらん、すごい逸品じゃない？"

    # say L1882 whi
    old "I bet he's even bigger than you remember isn't Jade?"
    new "あのね、彼は君が覚えてるよりももっと大きいわよね、ジェイド？"

    # say L1883 jad
    old "W- well..."
    new "えーと、そうね…"

    # say L1884 whi
    old "And it's so thick, hot, and hard..."
    new "そして、太くて熱くて硬いんだよ..."

    # say L1894 whi
    old "Hmph, slrrrrp!"
    new "ふん、するるるるっ！"

    # say L1895 whi
    old "My God [pla] you really have the best tasting dick in the world."
    new "神様、[pla] あなたのチ○ポは本当に世界一おいしいわ。"

    # say L1896 whi
    old "It's so great!"
    new "それは素晴らしいわ！"

    # say L1897 whi
    old "I could suck it all day!"
    new "私は一日中吸い続けられるわ！"

    # say L1898 whi
    old "I bet you want to have a taste too, don't you Jade?"
    new "あなたも味見したいでしょう、ジェイド？"

    # say L1899 whi
    old "It's great, believe me!"
    new "素晴らしいわ、信じてちょうだい！"

    # say L1900 whi
    old "But he's mine first!"
    new "でも彼は最初に私のものよ！"

    # say L1910 whi
    old "I hope this has helped you take some tension off."
    new "この経験が少しでもストレスを発散できたことを願っています。"

    # say L1911 whi
    old "Now that we've broken the ice, you can do it at her house."
    new "それじゃ、氷を破ったわけだから、彼女の家でやっても良いでしょう。"

    # say L1915 whi
    old "Oh come on, Is that a problem?"
    new "あらまあ、そんなに難しく考えないでよ。"

    # say L1917 whi
    old "Come on, you both enjoyed it and it's a win win."
    new "さあ、二人とも楽しんだし、お互いに得したわけだよね。"

    # say L1920 whi
    old "You [pla], did you like to had your dick sucked by a hot MILF as Jade?"
    new "あなた、[pla]、ホットなミルフの私がチンポを咥えるの好きでしたか？"

    # say L1922 pla
    old "Uhh, y- yes..."
    new "うーん、はい…"

    # say L1923 whi
    old "And you Jade? Did you enjoyed with a real big cock in your mouth?"
    new "あなたはジャッド、大きなチ○ポを口に含むのが気に入ったのよね？"

    # say L1925 whi
    old "Well that's it, enjoy it together and don't make a fuss about it."
    new "まあ、そうですね。一緒に楽しんで、騒がないでくださいね。"

    # say L1926 whi
    old "Sadly, I won't be able to be there with you guys every time you fool around, but Jade still needs some stress relief."
    new "残念ながら、毎回あなたたちが遊ぶたびに一緒にいられるわけではありませんが、ジェイドはまだストレス解消が必要です。"

    # say L1927 whi
    old "So, I trust that you'll give it to her whenever she needs it."
    new "それでは、彼女が必要なときにはちゃんと与えてあげてくださいね。"

    # say L1930 whi
    old "Now, Mike's about to come home, so, sadly we'll have to see each other again another time."
    new "マイクが帰ってきますから、残念ですがまた今度ね。"

    # say L1931 whi
    old "But I've enjoyed a lot this little meeting."
    new "でも、この小さな集まりはとても楽しかったです。"

    # say L1932 pla
    old "I guess I have to get going too."
    new "俺も帰る時間だな。"

    # say L1934 jad
    old "Y- yeah, uhh, me too. But before we leave."
    new "うーん、そうですね。でも、出発する前に。"

    # say L1937 jad
    old "Uhh... T- thank you [pla]."
    new "うーん… ありがとう、[pla]。"

    # say L1939 pla
    old "Uhmm... Sure, no problem."
    new "うん、もちろんだ、問題ないよ。"

    # say L1941 whi
    old "That's great, alright, see you later guys."
    new "それじゃあ、またね。"

    # say L1958 jad
    old "Wow, that was nice, isn't it?"
    new "うわ、気持ちよかったですね。"

    # say L1959 pla
    old "Phew, I wasn't expecting that to be honest.."
    new "ふう、正直予想してなかったな。"

    # say L1960 jad
    old "Heh, well, I figured that if I was going to do it, I should just go ahead and try."
    new "へへ、まあ、やるなら思い切ってやってみようかなって思った。"

    # say L1961 jad
    old "I'm glad you did seem to enjoy it."
    new "良かったみたいで私も嬉しいよ。"

    # say L1963 jad
    old "I've been thinking a lot about what Mrs. White said, and..."
    new "Whiteさんの言葉をよく考えて、…"

    # say L1964 jad
    old "I think she's right, I need to relax a bit more."
    new "私はそう思うわ、もっとリラックスすべきだと思う。"

    # say L1965 jad
    old "So, I'm happy I took the leap."
    new "だから、一歩踏み出せて良かったわ。"

    # say L1967 pla
    old "Well, I'm happy I can be of help to you."
    new "じゃだ、俺も君の役に立てて嬉しいよ。"

    # say L1968 jad
    old "You're a lot more than that honey."
    new "あなたはそれ以上だよ、ハニー。"

    # say L1969 jad
    old "About what just happened, you can think of it as your reward for all of the hard work you've been doing lately."
    new "今起こったことは、最近のあなたの頑張りの報酬と思っていいわよ。"

    # say L1971 jad
    old "Well, now, if you'll excuse me, I think I'll lay down for a bit, honey."
    new "それじゃ、失礼するわ、ちょっと横になるからね、ハニー。"

    # say L1972 pla
    old "Sure, I'll see you later."
    new "分かった、後でね。"

    # say L1973 jad
    old "Sure, good bye."
    new "じゃあ、またね。"

    # say L1982 pla
    old "I can't believe that actually happened."
    new "信じられない、本当にそんなことが起きたなんて。"

    # say L1983 pla
    old "Oh God, how do I always get into this."
    new "神様、どうしていつもこんなことになるんだ。"

    # say L2001 pla
    old "Hi? Mrs. Jade? Hinn? I came to work in the bathroom!"
    new "嗨？ジェイド夫人？ヒン？トイレ掃除に来ました！"

    # say L2002 pla
    old "Mrs. Jade?"
    new "ジャド夫人？"

    # say L2012 pla
    old "Uhh, This feels like Deja Vu..."
    new "うーん、これってデジャヴみたいだな…"

    # say L2013 pla
    old "Hmm, I don't like where this is going..."
    new "うーん、この感じが気に入らないな…"

    # say L2022 pla
    old "O- oh! Mrs. Jade, Mrs. White, you're here... Hi."
    new "おー、ジャド夫人、ホワイト夫人、いらっしゃいますか… こんにちは。"

    # say L2024 jad
    old "Nevermind that [pla], we've been waiting for you."
    new "気にしないで [pla]、私たちはあなたを待っていたの。"

    # say L2025 pla
    old "W- waiting?"
    new "待ってたの？"

    # say L2026 whi
    old "Well sweetie, Jade was thinking maybe it was time to get drilled by your huge cock."
    new "まあ、親愛なる子よ、ジェイドはあなたの大きなちんこで貫かれることのタイミングが来たかもしれないと考えていたの。"

    # say L2027 pla
    old "... (Holly Shit...)"
    new "…（ホーリーシット…）"

    # say L2028 whi
    old "So, I thought I should be here to give her a little nudge forward."
    new "なので、私が少しだけ後押しするためにここに来るべきだと思ったんです。"

    # say L2030 jad
    old "Now honey, don't just stand there looking lost."
    new "あたし、はちさん、そんな立ち尽くしてたらダメよ。"

    # say L2031 whi
    old "Come here and fuck us [pla]!"
    new "ここへきて、私たちを犯して [pla]！"

    # say L2046 whi
    old "Ok, I'm glad I was able to be of help to you Jade."
    new "はい、ジェイドに少しでも役立てて良かったわ。"

    # say L2047 whi
    old "I suppose the next time you two won't need my assistance."
    new "次は二人だけで大丈夫そうね。"

    # say L2048 whi
    old "But, don't be selfish, you can always invite me to spend a sexy afternoon like today."
    new "でも、わがまましないでね、いつでも私を誘って、今日のようなセクシーな午後を過ごしましょう。"

    # say L2049 jad
    old "For sure I will."
    new "もちろんよ。"

    # say L2050 whi
    old "Nice! So, I guess it's ok if I leave for now."
    new "Nice！ それじゃ、今から帰ってもいいかしら。"

    # say L2051 jad
    old "Ok, but again, thank you so much for all your help."
    new "Ok、でもまた、本当にありがとう。"

    # say L2052 jad
    old "You were completely right about everything."
    new "あなたが言ってたことは全部正しかったわ。"

    # say L2053 whi
    old "Well, I'm always right, girl, you know that."
    new "まあ、私はいつも正しいのよ、君も知ってるでしょう。"

    # say L2054 whi
    old "I'll be seeing you later [pla]."
    new "後でまた会おう [pla]。"

    # say L2060 jad
    old "Well, I guess it's too late for you to work on the bathroom now."
    new "もう浴室の工事に取り掛かるのは遅すぎたわね。"

    # say L2061 jad
    old "And you must be very tired anyway, so, I suppose we'll see each other another time."
    new "それに、お疲れでしょうから、また今度会いましょう。"

    # say L2062 pla
    old "Yeah, don't worry. I'll be back soon..."
    new "大丈夫、心配しないで。またすぐに来るから…"

    # say L2063 pla
    old "See you later Mrs. Jade."
    new "またね、ジェイドさん。"

    # say L2064 jad
    old "See you later honey."
    new "またね、ハニー。"

    # say L2078 pla
    old "Ok! That's it! I think I'm done!"
    new "オッケー！これでいいや！終わりだと思う！"

    # say L2079 pla
    old "Finally."
    new "やっと終わったな。"

    # say L2080 pla
    old "I think I should go tell Mrs. Jade."
    new "じゃだ夫人に報告しに行くべきだな。"

    # say L2088 pla
    old "Alright Mrs. Jade, I finished fixing the shower."
    new "ジャド夫人、シャワーの修理が終わったよ。"

    # say L2090 pla
    old "You can now use it as before, it should be completely fine."
    new "今なら以前のように使えるよ、完全に直したから。"

    # say L2091 jad
    old "Really? That's very good."
    new "本当に？それは良かったわ。"

    # say L2092 pla
    old "Yeah, why don't you come with me so you can see it?"
    new "じゃだ、一緒に来てくれよ。見せてやるから。"

    # say L2102 pla
    old "You see? It's fine now."
    new "見ろ？今なら大丈夫だよ。"

    # say L2104 jad
    old "Thanks great! Thank you so much [pla]!"
    new "ありがとう、本当に助かった [pla]！"

    # say L2108 pla
    old "W- what? What are you doing Mrs. Jade?"
    new "ワッ、何やってるんですか、ジェイドさん？"

    # say L2111 jad
    old "Well, since the shower's now working, I figured I should give it a try, don't you think?"
    new "シャワーが使えるようになったから、試してみようかな、どう思う？"

    # say L2113 jad
    old "And since you've been working so hard, you should also try it, so you can relax a little bit after all of that hard work."
    new "あなたがそんなに頑張ってくれたんだから、少しリラックスするためにシャワーを試してみてはどう？"

    # say L2114 jad
    old "So, now you and I are going to take a shower together."
    new "じゃあ、今から二人でシャワーを浴びようね。"

    # say L2115 jad
    old "Now take off your clothes and get in the shower [pla]."
    new "服を脱いでシャワーに入りなさい [pla]。"

    # say L2128 jad
    old "Ok, honey, I guess that's it with the bathroom."
    new "はい、 Darling、お風呂場のことはこれで終わりね。"

    # say L2129 jad
    old "Thanks a lot for what you did."
    new "ありがとう、助けてくれて。"

    # say L2130 jad
    old "I don't know how much it would've cost to fix it if I had contacted a plumber."
    new "もし業者に連絡してたら、修理費がどれだけかかったかわからないわ。"

    # say L2131 pla
    old "No problem Mrs. Jade, I'm happy to help."
    new "大丈夫です、ジェイドさん。喜んで手伝いますよ。"

    # say L2132 jad
    old "Oh, you did a lot more than that."
    new "あなたはそれ以上のことまでしてくれたわ。"

    # say L2133 jad
    old "And I hope you know I expect to see you around here soon."
    new "そして、また近いうちに会えることを期待してるわ。"

    # say L2134 jad
    old "Please remember to come and pay me a visit once in a while."
    new "時々遊びに来てほしいな。"

    # say L2135 jad
    old "I know you'll enjoy it."
    new "あなたが楽しむのは間違いないわ。"

    # say L2136 pla
    old "Sure, I'll come by soon."
    new "行こうと思うよ。"

    # say L2137 jad
    old "That's good honey, very good."
    new "それはいい、本当にいい。"

    # say L2138 jad
    old "I suppose you have to go?"
    new "行かなくちゃならないの？"

    # say L2140 pla
    old "Yeah, it's a little bit late, and I'm really tired..."
    new "うん、ちょっと遅いし、めっちゃ疲れてるからな..."

    # say L2141 jad
    old "Oh yeah, honey, you deserve a good rest."
    new "ああそうね、甘いもの、よく休んでね。"

    # say L2142 pla
    old "Yeah, I will sleep like a baby tonight."
    new "今夜は赤ちゃんのようにぐっすり眠るぞ。"

    # say L2144 pla
    old "Alright, have a good night Mrs. Jade."
    new "じゃだ夫人、よい夜を。"

    # say L2145 jad
    old "Have a good night, honey."
    new "良い夜を、ハニー。"

    # say L2162 pla
    old "Oh, hi Hinn."
    new "お、嗨、ヒン。"

    # say L2163 pla
    old "How are you? How have your extra classes been going?"
    new "元気？追加の授業はどうだ？"

    # say L2166 hin
    old "Hey, I wanted to thank you for all the hard work you did at my house with fixing the shower and stuff."
    new "Hey、私が家でシャワーを直したりしたことでありがとうって言いたかったの。"

    # say L2168 pla
    old "Oh, my pleasure. I'm glad I was able to help you."
    new "ああ、全然問題ないよ。君のためになれて嬉しいよ。"

    # say L2169 hin
    old "Yeah well, I still wanted to thank you personally, because I bet my mom didn't even say thank you, did she?"
    new "まあ、個人的に感謝したかったの。多分ママは全然ありがとうも言わなかったよね？"

    # say L2170 pla
    old "Uhh... She did, she did."
    new "うーん… 言ってた、言ってた。"

    # say L2171 pla
    old "She was actually very, very grateful."
    new "彼女は実際、すごく感謝してたよ。"

    # say L2173 hin
    old "She was? Well, that's a surprise."
    new "そうだったの？まあ、それは意外ね。"

    # say L2174 hin
    old "I'm glad she did."
    new "良かったな。"

    # say L2175 hin
    old "But don't think I forgot to give you my own thank you."
    new "でも私があなたに感謝の言葉を伝えるのを忘れたと思わないでね。"

    # say L2177 hin
    old "I'll be busy a couple more days with my extracurricular activities."
    new "あと数日は部活動で忙しいわ。"

    # say L2178 hin
    old "But as soon as I'm free I'll give you something to really say thanks."
    new "でも自由になったら、本当に感謝の気持ちを伝えようと思う。"

    # say L2179 hin
    old "Well, I don't have much more time, so, I have to leave, see you later [pla]."
    new "時間がないから、ちょっと行ってくるね。またね [pla]。"

    # say L2191 hin
    old "By the way, I almost forgot to tell you. "
    new "それと、幾乎忘了告诉你。"

    # say L2192 hin
    old "My mom asked me to tell you that there are a couple more things in the house that need fixing."
    new "ママが言わせてくれたんだけど、家の中にまだ直さなきゃいけないところがあるんだって。"

    # say L2193 hin
    old "And wanted to know if you could come and help us with that."
    new "そして、それを手伝ってくれるかどうか知りたいって。"

    # say L2194 hin
    old "Which is terrible of her to ask after all you already did. So, if you can't do it just tell me and I'll set her straight."
    new "それが彼女の言い分だけど、あなたがもうたくさんやってくれたのに、そんなお願いをするのは申し訳ないよね。もし無理なら言ってくれれば、私が母に言っておくから。"

    # say L2195 pla
    old "Uhh, yeah, actually it's fine, I kinda have an idea of what she wants me to do, so, don't worry, it's fine."
    new "うーん、実際大丈夫だよ、彼女が何を頼むのかちょっと分かるから、心配しなくていい。"

    # say L2196 hin
    old "It is? Well, I'm glad it doesn't bother you."
    new "そう？でも、あなたが困らないなら良かったのね。"

    # say L2197 hin
    old "Thanks a lot [pla], I'll see you later."
    new "ありがとう [pla]、後でね。"

    # say L2216 pla
    old "Hi Mrs. Jade."
    new "嗨、ジェイド夫人。"

    # say L2217 jad
    old "Hi honey, tell me, do you need anything?"
    new "あたし、何か必要なことある？"

    # say L2222 pla
    old "I should find a therapist first."
    new "まずはカウンセラーを見つけた方がいいな。"

    # say L2234 jad
    old "Hey [pla], don't you have to be at school?"
    new "Hey [pla]、学校に行くんじゃなかった？"

    # say L2236 pla
    old "Right, I was just looking for Hinn."
    new "そうだ、ヒンを探してただよ。"

    # say L2238 jad
    old "Hinn? She is already at school... Don't be late, [pla]... "
    new "ヒン？もう学校にいるわよ…遅刻しないで、[pla]…"

    # say L2240 pla
    old "You're right. Sorry. I better go now..."
    new "そうだな。ごめん。行かなきゃな..."

    # say L2242 jad
    old "...(Hmm.)"
    new "（ん？）"

    # say L2276 jad
    old "What? But right now it's school time!"
    new "何？でも今は学校の時間だよ！"

    # say L2277 jad
    old "It's very sweet of you to come here to help, but I don't want you missing any classes because of me."
    new "あなたがここに来て助けてくれるのはとても嬉しいけど、私のために授業を休んでは困るわ。"

    # say L2278 jad
    old "You should go to school, I'll be here in the afternoon, so you can come and do the bathroom then."
    new "学校に行きなさい、午後にまたここにいられるから、そのときにトイレに来なさい。"

    # say L2279 pla
    old "Yeah, I think you're right."
    new "うん、君の言う通りだな。"

    # say L2280 pla
    old "I'll come here later then."
    new "じゃあ、後で来るよ。"


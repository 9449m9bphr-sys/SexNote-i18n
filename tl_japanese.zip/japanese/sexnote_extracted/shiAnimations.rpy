# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/shiAnimations.rpy
translate japanese strings:

    # say L45 pla
    old "And... Who are you?"
    new "そして… お前は誰だ？"

    # say L47 dev
    old "Wow, can you see me? So it was true. Interesting... "
    new "おお、見えるのか？本当だったのか。興味深い..."

    # say L50 dev
    old "You are the human with Agamoto's Eye?"
    new "あなたがアガマトの目を持つ人間？"

    # say L51 pla
    old "Yes... and you... are you a... shinigami?"
    new "はい… そして君は… 死神なのか？"

    # say L53 dev
    old "Yes! This is the first time I've met a human."
    new "はい！人間と会るのは初めてよ。"

    # say L54 pla
    old "Ok... So, do you know the shinigami of the other night?"
    new "おｋ... じゃあ、先日の死神のことは知ってるか？"

    # say L56 dev
    old "You mean Mildret?"
    new "ミルドレットのことね？"

    # say L57 pla
    old "I don't know her name, but she also sucked up my magical power..."
    new "名前は知らないけど、彼女も俺の魔力を吸い取ったんだ..."

    # say L59 dev
    old "Yes, then you talk about Mildret  hehehe."
    new "はい、そのあとミルドレットのことを話してるわ へへへ。"

    # say L60 pla
    old "Are there more shinigami, besides Mildret and... you?"
    new "ミルドレットと……君以外にも、他に死神はいるのか？"

    # say L62 dev
    old "Yes we are only three and I am Devonne. Nice to meet you!"
    new "はい、私たちは三人だけよ。私はデボンヌ。はじめまして！"

    # say L63 pla
    old "Nice... to... meet... you. My name is [pla]..."
    new "お前と出会えて良かった... 俺の名前は[pla]..."

    # say L65 dev
    old "Wow, [pla]? What strange names humans have... hahaha."
    new "わお、[pla]？人間の名前って変よね…ははは。"

    # say L66 pla
    old "You're not mad at me?"
    new "君が怒ってるのか？"

    # say L68 dev
    old "Me? No... Why would I be?"
    new "私？怒ってるわけないよ… どうして私が怒るの？"

    # say L69 pla
    old "Because Mildret accused me of stealing magical power..."
    new "ミルドレットが魔力を盗んでいるって accusé されたからさ。"

    # say L71 dev
    old "Ohhh you mean that... Well, there has been someone who has been gathering the magical power in this area and we think it's you... Is it you?"
    new "ああ、それのことね… ここら辺で魔力を集めてる誰かがいて、それがあなただと思われてるの… 本当にあなた？"

    # say L72 pla
    old "Well, yes... But..."
    new "まあ、そうだけど…でもね…"

    # say L74 dev
    old "Ohhh... Then it's true, You are the thief... And you were starting to like me... I better go before you take away the little I recovered..."
    new "オーッ…そうなのか、あなたが泥棒だったのね…でも、少しずつ私を好きになってくれてたんでしょ…私が回復した力を全部奪われちゃう前に逃げないと…"

    # say L77 pla
    old "No,wait!"
    new "待って待って！"

    # say L78 pla
    old "Hmm... Again... And they are three huh?"
    new "またか… しかも三人か"

    # say L98 pla
    old "So, did you get enought magic power?"
    new "じゃあ、十分な魔力は手に入ったか？"

    # say L100 dev
    old "Yeay! Thank you so much..."
    new "やった！本当にありがとう..."

    # say L101 pla
    old "Don't worry, I just wanna help you..."
    new "心配しなくていい、ただ君を助けるだけだ。"

    # say L103 dev
    old "You are the best!"
    new "あなたが最高だよ！"

    # say L105 dev
    old "Well I have to go... Goodbye, [pla]"
    new "じゃあ、行かなきゃ……さよなら、[pla]"

    # say L171 pla
    old "I hoped you wouldn't steal more magical power..."
    new "君がもっと魔法の力を奪うと思ってたんだよ…"

    # say L173 dev
    old "You destroyed the magical world!!!"
    new "あなたが魔術の世界を壊したのよ！"

    # say L176 dev
    old "You are the worst being in the universe!..."
    new "あなたは宇宙で最悪の存在よ！"

    # say L177 pla
    old "I don't understand... Why do you say that?..."
    new "俺は理解できない… なんでそんなこと言うの？"

    # say L179 dev
    old "You have already done a lot of damage, and now you want to make us disappear by talking away the magical power... Leave us alone, once and for all..."
    new "あなたはもう十分な迷惑をかけて、今度は魔法の力を奪って私たちを消そうとしてるの… もう私たちを放っておいてくれよ…"

    # say L182 pla
    old "... What the hell?..."
    new "何だよこれ？"

    # say L272 dev
    old "Oh boy, there is nothing more fun than sharing magical power."
    new "あら、魔法の力を分かち合うのは最高の楽しみだわ。"

    # say L274 pla
    old "I'm glad you feel good, you can still count on receiving magical power when you need me, you can go when you want it..."
    new "君が感じていてくれて嬉しいよ、必要になったらいつでも魔法の力を分けてあげるから、欲しくなったら来い..."

    # say L276 dev
    old "Do not hesitate..."
    new "迷わず"

    # say L278 pla
    old "Well, I must go now, I'm glad I closed the deal and finished everything in good terms..."
    new "WELL、今すぐ行かなきゃならないけど、取引をうまくまとめられて良かったし、すべてをきれいに片付けて良かったよ..."

    # say L280 dev
    old "[pla], take care of Brixxida, she's not what she seems..."
    new "[pla]、ブリクシダには気をつけて、彼女は見た目通りじゃないから…"

    # say L282 pla
    old "Yes, I'll be careful..."
    new "うん、気をつけるよ…"

    # say L284 dev
    old "Okay..."
    new "わかった…"

    # say L306 dev
    old "Yeay! really fun... right?..."
    new "やーい！ほんと楽しいよね…ね？"

    # say L308 pla
    old "Haha right, it was fun."
    new "ははは、そうだね、楽しかったよ。"

    # say L310 dev
    old "Ok, I'm going to collect more magic power to do it again..."
    new "Ok、魔法の力をもっと集めてまたやるから…"

    # say L312 pla
    old "Just take it easy... Ok?"
    new "ゆっくりしろ... 分かったか？"

    # say L314 dev
    old "Ok, ok..."
    new "大丈夫、大丈夫…"

    # say L421 pla
    old "(Perfect, I must use Sauron's mouth) {b}Sauron's mouth!{/b}"
    new "完璧だ、{b}ソーウロンの口だ！{/b}"

    # say L422 pla
    old "Tell me your name shinigami!"
    new "名前を教えて、死神！"

    # say L424 gom
    old "My name is Gomory..."
    new "私の名前はゴモリです…"

    # say L426 pla
    old "Hmmm... Do you know Devonne and... Mildret? "
    new "へぇ…デボンヌとミルドレットを知ってるか？"

    # say L428 gom
    old "Yes, they are two allied shinigamis..."
    new "はい、彼らは同盟した死神同士です。"

    # say L430 pla
    old "Why are you stealing magic power from me?"
    new "なぜ俺から魔力を奪ってるんだ？"

    # say L432 gom
    old "You have been collecting magical power from this area, which has left us with few reserves... and soon we'll not enough to exist."
    new "この地域から魔力を集めていたせいで、私たちの備えがほとんどなくなって……很快就将不足以维持我们的存在。"

    # say L434 gom
    old "I should go... I've said enough..."
    new "行かなくちゃ… 言いたいことは言ったし…"

    # say L435 pla
    old "No, no, wait! I didn't know I was taking magic power from you..."
    new "待って、待って！　俺、君たちから魔力取ってるって知らなかったよ…"

    # say L438 gom
    old "Well, actually, it is not the magic power from us. It's just that there is less and less in the area."
    new "実は、私たちから取られているわけじゃないの。ただ、この地域の魔力が少なくなってきているだけ。"

    # say L439 gom
    old "I think we will soon cease to exist because there will be no more..."
    new "私たちが存在できなくなるのは、もうすぐかもしれないわ……"

    # say L442 gom
    old "And you do not need the magic power to exist..."
    new "魔法の力がなくても存在できるわけじゃないの…"

    # say L445 pla
    old "Ohhh... I understand perfectly... I didn't know... I mean, I knew it, but I didn't know you existed..."
    new "オーッ… 分かってるよ… 知らなかったわけじゃなくて、君が存在することを知らなかったんだ…"

    # say L447 gom
    old "Well, you already know... It is not something that makes much difference. At some point all the magical power will end and we will disappear..."
    new "まあ、既に知ってるでしょ… 大した違いじゃないの。いずれ魔法の力も尽きて、私たちも消えちゃうんだから…"

    # say L448 pla
    old "What about the 'Chosen One'? Who will rebuild the magical world? "
    new "選ばれし者ってどうなるの？魔法の世界を再建するのは誰なんだ？"

    # say L450 gom
    old "It's a myth... No one really thinks that will happen since years have passed... Anyway... I'm leaving..."
    new "それは伝説よ… 誰もそんなことになると本気で思ってないわ、何年も経ったんだから… とにかく… 行くわ…"

    # say L453 pla
    old "But... Hmm... Now I understand... I have to talk with Brixxida"
    new "でも……うーん……今わかったよ……ブリクシダと話さなきゃならないんだ"

    # say L473 pla
    old "Well, did you get enough magic power?"
    new "まあ、充分な魔力は手に入れたか？"

    # say L475 gom
    old "Yes, I have enough for now..."
    new "はい、今のところ十分よ…"

    # say L476 pla
    old "Ok, you can come anytime if you need more..."
    new "大丈夫、必要になったらいつでも来なさい。"

    # say L478 gom
    old "Ok, thanks. I have to go."
    new "ありがとう。行かなきゃ。"

    # say L543 gom
    old "Damn, you left me with too little energy..."
    new "ダメ、エネルギーが全然足りないよ…"

    # say L545 pla
    old "{b}Sauron's mouth!{/b}"
    new "{b}サウロンの口！{/b}"

    # say L547 pla
    old "Answer me, why do you say that I destroyed the magical world?"
    new "何言ってるの、俺が魔法の世界を壊したって？"

    # say L549 gom
    old "You are the owner of the SexNote, who destroyed the magical world..."
    new "あなたがSexNoteの持ち主で、魔法の世界を壊したって言うの？"

    # say L552 pla
    old "What? But I didn't..."
    new "何？でも俺は……"

    # say L554 pla
    old "How was the magical world destroyed? "
    new "魔法の世界はどうやって壊れたんだ？"

    # say L556 gom
    old "A powefull being who possessed the SexNote, performed a forbidden spell that caused the magical world to collapse..."
    new "強大な力を持つSexNoteの持ち主が、禁じられた呪文を唱えて魔法の世界を崩壊させてしまったの..."

    # say L559 pla
    old "What the fuck?..."
    new "何てことだよ…"

    # say L564 bri
    old "Thieves!! Stop stealing the magic power!"
    new "泥棒たち！！魔力を盗むのを止めて！"

    # say L567 gom
    old "We have little magic energy left for Mildret and me... Don't attack us anymore..."
    new "ミルドレットと私にはもう魔法エネルギーがほとんど残ってないの… もう攻撃しないで…"

    # say L569 bri
    old "You must die! I will finish you!"
    new "あなたたちには死んでもらうしかない！私が仕留めるわ！"

    # say L573 pla
    old "What are you doing!?"
    new "何やってんだ！？"

    # say L575 bri
    old "I'm trying to make them not bother you again..."
    new "私がもう二度と彼らに迷惑をかけさせないようにしてるの..."

    # say L577 pla
    old "I was getting information... You chased her away..."
    new "情報集めてたんだ... 君が追い払ったのか..."

    # say L579 bri
    old "Sorry, I am upset about the magical power that was stolen from us..."
    new "ごめん、私たちから奪われた魔法の力のことで腹が立ってるの…"

    # say L581 pla
    old "But... Why did you do that?"
    new "でも... なんでそんなことしたの？"

    # say L583 pla
    old "Anyway, just let's go home..."
    new "とにかく、家に帰ろうよ…"

    # say L590 pla
    old "Hmm... Things are very suspicious... I'll have to talk to Brixxida to clarify everything..."
    new "うーん……状況が怪しいな……ブリクシダと話して、すべてをはっきりさせないと……"

    # say L608 gom
    old "Well I hope this little help you, to improve your skills..."
    new "まあ、この小さな手助けが君のスキルアップに役立つといいな"

    # say L610 pla
    old "Thank you, I really appreciate all your help."
    new "ありがとう、君の助けが本当に役立ったよ。"

    # say L612 gom
    old "You're welcome, we count on you to save the magical world."
    new "どういたしまして、魔法の世界を救うのは君に任せるわ。"

    # say L614 pla
    old "I'll take care of fixing everything, I promise..."
    new "全部直すから、約束する。"

    # say L616 gom
    old "Thank you."
    new "ありがとう。"

    # say L676 pla
    old "What the fuck? Who are you? And What was that?!"
    new "何だよ？君は誰だ？それと、何だったんだ？！"

    # say L678 mil
    old "What? Can you see me?"
    new "何？私を見えるの？"

    # say L679 pla
    old "Yes! Of course, I can see you..."
    new "もちろん、君が見えるよ..."

    # say L681 mil
    old "How the fuck can you see me? You are a simple human... "
    new "どうして私を見られるの？ あなたはただの人間じゃないよね…"

    # say L682 pla
    old "Uhh no... I think it's because I have Agamoto's eyes."
    new "うーん、そうじゃなくて……多分アガモトの目があるからだと思う。"

    # say L684 mil
    old "What?! You have Agamoto's eyes?"
    new "何？！ アガモトの目を持ってるの？"

    # say L685 pla
    old "Ehh yeah... But who are you?"
    new "ええっと…でも君は誰？"

    # say L687 mil
    old "Sooo... it's you who's been stealing the magic power?!"
    new "そう……魔力量を盗んでいたのは君だったのね？！"

    # say L688 pla
    old "What? Stealing magic power?"
    new "何？魔法の力を盗むって？"

    # say L690 mil
    old "Look, I'll only warn you this once... If you keep stealing the magic power I will be forced to take extreme measures..."
    new "見ろ、これだけ警告しておくけど……魔力の盗みを続けたら、極端な手段に出るしかないわ。"

    # say L691 pla
    old "Extreme measures?"
    new "極端な手段？"

    # say L693 mil
    old "This is not a children's game... You better stop stealing the magical power."
    new "これは子供の遊びじゃないわ… 魔力の盗みをやめた方がいいわ。"

    # say L696 pla
    old "But- wait... What?"
    new "でも待って…何？"

    # say L697 pla
    old "Hmm... Will have to talk to Brixxida tomorrow..."
    new "うーん… 明日ブリクシダと話さないとね…"

    # say L723 pla
    old "Well, did you get enough?"
    new "まあ、充分堪えたか？"

    # say L725 mil
    old "Yes, thank you for everything..."
    new "はい、すべてありがとう…"

    # say L726 pla
    old "No problem. You can come back anytime if you need more..."
    new "問題ないよ。また必要になったらいつでも来なよ..."

    # say L728 mil
    old "We just need a little to not disappear..."
    new "消えちゃわないように、ちょっとだけ必要なの..."

    # say L730 mil
    old "Anyway I will let you keep sleeping... Bye..."
    new "それじゃあ、もう少し寝てていいから… さよなら…"

    # say L798 mil
    old "Don't you see? You're a thief... And now you steal directly."
    new "見えないの？あなたは泥棒よ… そして今、直接奪っているわ。"

    # say L800 pla
    old "I'm not... I'm only recovering what you took away from me, Nothing more."
    new "俺はただ、君が奪ったものを取り戻してるだけだよ、それだけのことさ。"

    # say L802 mil
    old "You have been taking away all the energy in these past few days..."
    new "この数日、あなたのエネルギーを全部奪っていったのね..."

    # say L804 mil
    old "You don't need it to exist..."
    new "あなたが存在するには必要ないのよ..."

    # say L806 pla
    old "I am the chosen one, I will be able to restore the magical world..."
    new "俺が選ばれた者だ、魔界を復活させられるよ..."

    # say L808 mil
    old "You are a simple human, you cannot do anything for the magical world..."
    new "あなたはただの人間よ、魔法の世界のために何もできないわ。"

    # say L810 pla
    old "I am the owner of the SexNote!..."
    new "俺がSexNoteの持ち主だ！"

    # say L812 mil
    old "You... have... the... SexNote?..."
    new "あなた…… SexNote を持ってるの？……"

    # say L814 pla
    old "That's right... I will rebuild the magical world..."
    new "そうだよ… 魔法の世界を再建するんだ…"

    # say L820 pla
    old "Wait... Hmm..."
    new "待って…… hmm……"

    # say L840 mil
    old "Ok, I think is enought for now, right?..."
    new "まあ、これくらいでいいよ、ね？"

    # say L842 pla
    old "Well, yes, thank you... But if you have little just left tell me."
    new "うん、ありがとう……でも、まだ少し残ってるなら教えてくれ。"

    # say L844 mil
    old "Don't worry I'm good for now..."
    new "大丈夫、今は満足よ…"

    # say L846 mil
    old "Now let me rest and recover some magic power..."
    new "それじゃ、少し休んで魔力を回復するね..."

    # say L848 pla
    old "Ok, see you..."
    new "Ok、じゃあまたね。"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/sisAnimations.rpy
translate japanese strings:

    # say L6 pla
    old "W- What are you doing?"
    new "何やってんの？"

    # say L7 sis
    old "What does it look like?"
    new "何してるの？"

    # say L12 sis
    old "Hmm, your cock is so tasty!"
    new "ん、あなたのチ○ポ、とっても美味しいのよ。"

    # say L13 sis
    old "Don't you like it?"
    new "好きじゃないの？"

    # say L18 sis
    old "I can't believe you have such a big cock!"
    new "こんなに大きなチ○ポを持っているなんて、信じられない！"

    # say L43 pla
    old "Please, stop. You are... Gonna make me-"
    new "お願い、止めて。君は… 俺を-"

    # say L44 sis
    old "Cum? Oh please do it. I'm dying to see this monster cock cum all over..."
    new "Cum？ お願い、出して。 このデカチ○ポが全部出るのを見せてほしいの…"

    # say L50 sis
    old "Shit! That was so intense... Did you like it?"
    new "くそ！それって凄かった… 気に入った？"

    # say L51 pla
    old "Ye... I- I have to go..."
    new "よ… 俺、行かなきゃ…"

    # say L58 pla
    old "What the fuck was that?"
    new "何だったんだよ、それ？"

    # say L59 pla
    old "I better go to sleep now..."
    new "寝るか"

    # say L74 pla
    old "Ready for a new day!..."
    new "新しい日のための準備はできてるぜ！..."

    # say L92 sis
    old "Hmm I love this taste."
    new "ん、この味が大好き。"

    # say L93 sis
    old "Do you like how it feels inside my mouth?"
    new "私の口の中の感じ方が好き？"

    # say L97 sis
    old "It's fucking huge, I want to have it all inside, do you think I'm capable?"
    new "これめっちゃでかい、全部入れたいの、私にできると思う？"

    # say L99 sis
    old "Oh my god, I can feel it reaching my throat."
    new "おおっ、喉まで届くのを感じてる。"

    # say L103 sis
    old "What about a deepthroat?"
    new "奥まで吸い込めたらどうなるかな？"

    # say L105 pla
    old "Oh my God!"
    new "オーマイゴッド！"

    # say L106 sis
    old "Oh my, I can feel every inch inside my mouth!"
    new "あら、口の中であの大きさ全部感じちゃう！"

    # say L129 pla
    old "Ohhh, I- I!"
    new "オッ、イッ、イッ！"

    # say L134 sis
    old "Wow... That was massive, let me clean this mess... "
    new "Wow... それは大きかったわ、これをきれいにしなきゃ..."

    # say L163 pla
    old "(Oh man in a second I will be hard...)"
    new "おっ、すぐまた硬くなるな…"

    # say L166 sis
    old "Ohh, I love it ... My tits are very sensitive, I'm getting horny..."
    new "あぁ、大好き… 私の胸はとても敏感で、興奮しちゃってる…"

    # say L170 sis
    old "Ohh yeah, just like that... Don't stop baby..."
    new "ああ、そうね… 止めてないで、ベイビー…"

    # say L207 sis
    old "How does it feel in between these amazing boobs?"
    new "この素晴らしいおっぱいの間はどんな感じ？"

    # say L208 pla
    old "Ohh... It... Feels great."
    new "オッ… 感じがいい…"

    # say L211 sis
    old "Ohh... It feels really good..."
    new "ああ…本当に気持ちいい…"

    # say L212 sis
    old "Do not try to stop, keep moving faster."
    new "止めるな、もっと速く動いて。"

    # say L216 sis
    old "Oh yeah, fuck my tits! Harder, fuck them harder!"
    new "ああ、そう、私の胸を弄んで！もっと強く、もっと強く弄んで！"

    # say L240 pla
    old "[sis], I'm going to..."
    new "[sis]、出しちゃうぞ…"

    # say L241 sis
    old "Oh yeah, cum all over me!"
    new "ああ、そう、全部私の中に出して！"

    # say L259 pla
    old "Hey Ky-... (Wow!)"
    new "Hey キャ…（わお！）"

    # say L260 pla
    old "Oh shit, she is playing with her dildo..."
    new "おい、彼女、バイブで遊んでるぞ…"

    # say L261 pla
    old "I have to keep quiet so she doesn't notice me."
    new "静かにしてないと気づかれちゃうな。"

    # say L265 sis
    old "Mmm, it feels so good!"
    new "うーん、すごく気持ちいいな…"

    # say L266 sis
    old "My pussy wants a big, hard cock!"
    new "私のマンコは大きな硬いチ○ポが欲しくて仕方ない！"

    # say L270 sis
    old "Oh yeah! it feels better than fingering!"
    new "ああ、そうよ！指で弄ぶよりも全然いい感じ！"

    # say L271 sis
    old "I'm so fucking wet right now."
    new "今、めちゃくちゃ濡れてるの。"

    # say L302 sis
    old "Ughhh I can't take it anymore, I want to feel my pussy fucked! "
    new "うーん、もう我慢できない、オマ○コを突かれたいの！"

    # say L304 pla
    old "(Oh wow!)"
    new "おわっ！"

    # say L305 sis
    old "Ohhh yeah!"
    new "オッ、そうよ！"

    # say L309 sis
    old "Ahhh, yes! Right there."
    new "アッ、ああ！そこよ！"

    # say L310 sis
    old "This is so fucking good!"
    new "これ、めちゃくちゃいいっす！"

    # say L314 sis
    old "Mmmm, I want to cum now!"
    new "んん、今すぐイキたいの！"

    # say L343 sis
    old "Oh, yeah! Yeahh!!!"
    new "ああ、そうよ！ やべえ！"

    # say L344 sis
    old "I'm cumming!"
    new "私イク！"

    # say L360 pla
    old "(Oh my god it's like my dream!)"
    new "俺の夢みたいだよ！"

    # say L361 sis
    old "Oh yeah, fuck my mouth [pla]."
    new "ああ、そう、私の口を犯して [pla]。"

    # say L364 sis
    old "Come on! I want you to fuck my throat harder!"
    new "Come on！喉の奥までもっと激しくして！"

    # say L365 pla
    old "A- alright..."
    new "あー、分かったよ…"

    # say L370 sis
    old "I want to have it all inside my mouth."
    new "全部を口の中に入れてください"

    # say L371 sis
    old "Harder [pla], fuck my mouth harder!"
    new "もっと激しく [pla]、私の口を犯せ！"

    # say L373 sis
    old "Hmmm!"
    new "んん！"

    # say L397 sis
    old "Don't stop, don't stop! Cum inside my throat!"
    new "止めてくれない、止めてくれない！喉の奥にぶち込んで！"

    # say L414 sis
    old "Ohh! It's so big..."
    new "オッ！凄い大きい…"

    # say L415 sis
    old "Your cock is so much better than my dildo."
    new "あなたのチ○ポは私のディルドよりずっと良いの。"

    # say L419 sis
    old "Come on, I want you harder, fuck me harder [pla]!"
    new "さあ、もっと強く、もっと激しくファックして [pla]！"

    # say L422 sis
    old "Do you like being inside your [sisrel]?"
    new "あなたの [sisrel] 中に入ってるのが好き？"

    # say L426 sis
    old "Yeah! Yeah! Fuck me [pla], Fuck me!"
    new "うん！うん！ファックして [pla]、ファックして！"

    # say L428 sis
    old "Oh gosh! It's fucking huge!"
    new "あらっ！すごくでかいわ！"

    # say L429 sis
    old "You're drilling me"
    new "あなたが私を突いてる"

    # say L452 sis
    old "I'M GONNA... I'M GONNA-"
    new "出る… 出ちゃう…"

    # say L453 sis
    old "OOOOOHHHH! YEAHHH..."
    new "オォォォッ！イィィッ…"

    # say L457 sis
    old "Fuck... It was really good..."
    new "ああ…本当に良かった…"

    # say L466 pla
    old "Ok... Let me try, like this?"
    new "Ok... こうやってみるか？"

    # say L467 sis
    old "Just relax your hands and enjoy what you are doing, don't you like it?"
    new "手をリラックスさせて、自分がしていることを楽しんで。好きだよね？"

    # say L468 pla
    old "Gulp... Y-yes."
    new "ゴクリ… う、うん。"

    # say L471 sis
    old "Yeah, you're doing great, very gentle."
    new "うん、上手だね、優しくていいね。"

    # say L472 pla
    old "(This is delicious, she is so hot.)"
    new "これ yummy 美味しい、君はすごく HOT な。"

    # say L473 sis
    old "Do you like my ass?"
    new "私の尻、気に入ってる？"

    # say L478 sis
    old "Be creative, you can touch all you want! I like it."
    new "触れて全然いいよ、もっとしてほしいな。"

    # say L479 sis
    old "Do it harder baby..."
    new "もっと強くしてよ、ベイビー…"

    # say L517 sis
    old "Ugghh... It feels great."
    new "うーん… すごく感じてる。"

    # say L518 sis
    old "Oh yeah... Fuck my pussy baby."
    new "ああ、そうよ… 私のオマンコを突いてよ、ベイビー。"

    # say L522 sis
    old "Ohh yeah baby, don't stop."
    new "ああ、そうよベイビー、止めてないで。"

    # say L523 sis
    old "Yes! Yes! Just like that fuck me [pla]!"
    new "はい！はい！その調子で私を犯して [pla]！"

    # say L527 sis
    old "Ohhh, ohhh, I'm goona cum. Harder. Fuck me harder!"
    new "あぁ、あぁ、イクわ。もっと強く。もっと激しくファックして！"

    # say L551 sis
    old "OHH GOD, OHH GOD. I'M CUMMING!"
    new "オッホ、神様、出ちゃう！"

    # say L553 pla
    old "I- I'm cumming too!"
    new "俺も、出るよ！"

    # say L556 sis
    old "Oh yeah... I can feel it all inside me."
    new "ああ、そう… 中で全部感じてる。"

    # say L570 sis
    old "I love playing with your cock"
    new "あなたのちんぽで遊ぶのが大好き"

    # say L571 sis
    old "Enjoy the view..."
    new "景色を楽しんでる？"

    # say L574 sis
    old "Do you like my throat?"
    new "私の喉、好き？"

    # say L575 pla
    old "Oh yes..."
    new "ああ、そうね..."

    # say L576 sis
    old "Then, what are you waiting to fuck it?"
    new "それなら、何待ってるの？早く私の喉に犯されなさい。"

    # say L580 sis
    old "Harder [pla], fuck your [sisrel] throat!"
    new "もっと強く [pla]、私の [sisrel] 喉を犯しなさい！"

    # say L606 pla
    old "[sis] I'm going to-"
    new "[sis] 出すよ…"

    # say L607 sis
    old "Cum in my mouth baby..."
    new "私の口に精液を出して baby..."

    # say L625 sis
    old "Ughh, is so big."
    new "うげっ、こんなに大きいの。"

    # say L626 sis
    old "I love it!!!"
    new "大好きだよ！！"

    # say L627 sis
    old "Ohhh nicee baby, yeah fuck your [sisrel]!"
    new "オッホ、いいねベイビー、そうよ、あなたの[sisrel]を deepest！"

    # say L630 sis
    old "Ohh I want you deep inside me..."
    new "オッ、私の中深くまで入ってほしいの…"

    # say L633 sis
    old "My pussy is gripping that fucking cock."
    new "私のマンコがそのクソデカチ○ポを締めつけてるよ。"

    # say L636 sis
    old "HARDER! FUCK ME HARDER BABY!"
    new "もっと強く！ 強く突いてよベイビー！"

    # say L638 sis
    old "OH GOD, OH GOD! I'M CUMING!"
    new "おお神様、おお神様！ イクッ！"

    # say L661 pla
    old "I'm gonna-"
    new "出るぞ…"

    # say L662 sis
    old "YES BABY CUM INSIDE ME!"
    new "はい、Baby、中に出して！"

    # say L707 sis
    old "Alright, now it's time to wake up."
    new "さあ、目を覚ませ。"

    # say L709 sis
    old "This is a dream, dummy... "
    new "これは夢よ、バカ…"

    # say L710 sis
    old "Did you really think that I would let you fuck my mouth?"
    new "本当に私が君の口を犯すのを許すと思ったの？"

    # say L712 sis
    old "Hahaha! Hahahaha!"
    new "はははは！はははは！"

    # say L721 linSis
    old "That’s right, just let me do the work."
    new "そうだよ、任せて。"

    # say L722 linSis
    old "Mmmm! It’s so big."
    new "んんん！　大きいね。"

    # say L723 pla
    old "Do you feel ok? Has anything changed?"
    new "大丈夫か？何か変わった？"

    # say L724 linSis
    old "I do, it feels so different, human bodies are more sensitive after all."
    new "そう、全然違う感じがするよ、人間の体って結局敏感なんだよね。"

    # say L725 linSis
    old "But nothing has changed, no problem."
    new "でも何も変わってないよ、問題ないから。"

    # say L729 linSis
    old "Oh, yes, like that."
    new "ああ、そう、その感じ。"

    # say L730 linSis
    old "It feels soo great."
    new "感じがすごくいいよ。"

    # say L731 pla
    old "Do you feel any magic?"
    new "まだ魔法の感じないか？"

    # say L732 linSis
    old "Not yet... Ah! keep going."
    new "まだ感じない……あっ！もっと続けて。"

    # say L733 linSis
    old "Maybe in a little. Mmmm."
    new "もう少しで感じるかもしれない。んんん。"

    # say L737 linSis
    old "AH, AH, YES!"
    new "ああ、ああ、そう！"

    # say L738 linSis
    old "N- now I feel it."
    new "今、感じてる。"

    # say L739 linSis
    old "Don’t stop, keep going!"
    new "止めてないで、もっと！"

    # say L762 pla
    old "I- I can’t hold it anymore."
    new "もう我慢できないっす。"

    # say L764 linSis
    old "Oh yes, do it!"
    new "ああそう、もっと！"

    # say L766 linSis
    old "Ohh yeahh!"
    new "オーやっぱり！"

    # say L772 lin
    old "Amazing, it’s incredible how much magic power you’re able to hold and release."
    new "すごいわ、あなたがそんなに魔法の力を保って放出できるなんて。"

    # say L773 lin
    old "And doing it in a human body felt so different and good!"
    new "人間の体でやると、全然違うし気持ちいいんだ！"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/johAnimations.rpy
translate japanese strings:

    # say L6 joh
    old "Perfect, you are doing it so good, don't stop..."
    new "完璧です、とても上手です、やめないでください..."

    # say L8 joh
    old "Please keep in mind the places where it's better to touch, where you can make your patient feel even more..."
    new "患者さんがより感じる場所に触れることが大切です、そこを刺激することでさらに効果的になりますので..."

    # say L15 joh
    old "You are doing perfect, don't stop, it feels so good."
    new "あなたは完璧です、やめないで、すごく気持ちいいです。"

    # say L16 pla
    old "Slurp... Slurp..."
    new "スルル… スルル…"

    # say L39 joh
    old "Ahh, I want you to do it faster!... Go as fast as you c- can."
    new "ああ、もっと速くして！… できるだけ速くしてほしいな。"

    # say L40 joh
    old "Yeah, Yeah, YEAH! keep moving... I- I am cuming! AHH!"
    new "はい、はい、はい！動いて…… もう、イキそう！アッ！"

    # say L59 joh
    old "Please, just let me to enjoy your dick..."
    new "お願い、私のチ○コを楽しんでください…"

    # say L61 joh
    old "It's so hard... I just wanted to have it since I saw you fucking Angelina."
    new "こんなに硬くて… アンジェリナとセックスしてるのを見たときから欲しくて仕方がなかったんです。"

    # say L64 joh
    old "I want you to feel the tip of my tongue playing with the head of your dick..."
    new "あなたのチンポの先端を私の舌で弄ぶのが好きです…"

    # say L65 pla
    old "(Oh God...)"
    new "おお、神様…"

    # say L70 joh
    old "I'm really really wet right now... Do you like my mouth?"
    new "今、ものすごく濡れています… 口が気に入っていますか？"

    # say L71 pla
    old "Oh God, yes, it feels really good..."
    new "神様、そう、本当に気持ちいい..."

    # say L74 joh
    old "I need you to feel my mouth, to internalize the pleasure you are feeling, it's something you should handle. "
    new "あなたが私の口を感じ、その快感を内面化する必要がある、それがあなたが処理すべきことだ。"

    # say L80 joh
    old "Who do you prefer to suck your cock?  Me... Slurp... Or... Slurp... Angelina?"
    new "誰がお前のちんこをしゃぶるのが好きか？　俺... ジュル... それとも... ジュル... アンジェリーナ？"

    # say L82 joh
    old "Are you really considering it?"
    new "本当にそれを考えているんですか？"

    # say L85 joh
    old "Can you feel my tongue? Do you feel how wet it is now, feel the tip playing with your dick's head..."
    new "舌を感じられますか？ 今どれだけ濡れているか、先端があなたのチ○ポの先を弄んでいるのが感じられますか…"

    # say L86 pla
    old "Yes, I- I can."
    new "はい、俺-俺には感じるよ。"

    # say L106 joh
    old "I'm gonna show you WHO is the MASTER..."
    new "私がマスターだということを証明するよ..."

    # say L110 joh
    old "I'm going to do it with all I have, so be ready."
    new "私は全力でやりますから、準備しておいてください。"

    # say L129 joh
    old "This is how a master do it..."
    new "これがマスターの仕業です…"

    # say L130 pla
    old "Uhhh..."
    new "うっ..."

    # say L133 joh
    old "Stay focused, you can't cum."
    new "集中して、イッちゃダメだよ。"

    # say L134 pla
    old "I won't."
    new "俺はイかないよ。"

    # say L135 joh
    old "I hope so!"
    new "そうか、期待しているよ。"

    # say L139 joh
    old "So? What do you think now? Who is better?"
    new "じゃあ？今どう思う？誰が上手いと思う？"

    # say L140 pla
    old "Ahh... Y- you... You are better..."
    new "ああ… よ、あなたの方が上手いです…"

    # say L141 joh
    old "That's what I wanted to ear..."
    new "それが聞きたいだったんです…"

    # say L144 joh
    old "I will speed up a bit, I know you will enjoy it."
    new "少し早めますが、きっと楽しんでいただけるでしょう。"

    # say L152 joh
    old "I'm going to make you cum NOW!"
    new "今すぐイかせますよ！"

    # say L154 joh
    old "You are doing it better than I expected... But you can't against my full speed."
    new "あなたが想像以上に上手いですね… でも私の全速力には敵わないですよ。"

    # say L157 pla
    old "AHH!"
    new "アッ！"

    # say L186 pla
    old "I- I think I'm going to-"
    new "俺、出そう…"

    # say L187 joh
    old "Oh, please let it go, spill it over my mouth..."
    new "オッ、お願い、そのまま出して、私の口に全部かけて…"

    # say L188 pla
    old "A- are you sure?"
    new "あ、本当に大丈夫？"

    # say L189 joh
    old "Yess, I want to feel all you cum in my mouth, give it all to me!"
    new "はい、あなたの精液を全部私の口で感じたい、全部私に注いでください！"

    # say L200 joh
    old "Definetly, I need to ride this cock, I want it all inside me, lie on the bed I need you to fuck me!"
    new "絶対に、このち○こで骑乗させて、全部中に出してほしいの、ベッドに横になって、ちゃんとして！"

    # say L202 joh
    old "I don't want any kids game, fuck me really HARD!"
    new "子供の遊びじゃない、本当に強く犯して！"

    # say L203 pla
    old "A- alright."
    new "あー、分かった。"

    # say L219 joh
    old "Listen carefully, I want you to keep a regular rythm, and also an uniform strength..."
    new "よく聞いてください、リズムを一定に保つことと、力を均一にすることが大切です…"

    # say L220 joh
    old "You need to plan your movements, your energy, I will tell when you can do it faster."
    new "動きとエネルギーを計画的にコントロールし、私が速くしてもいいと言ったら速めてください。"

    # say L225 joh
    old "Ahh... I like it, keep it like that..."
    new "ああっ…いい感じ、そのまま続けて…"

    # say L228 joh
    old "Oh, now faster, I'm very wet, do it harder."
    new "オッ、今もっと早く、私はもう濡れちゃってるから、もっと強くして。"

    # say L229 pla
    old "O- ok."
    new "分かった、オッケー。"

    # say L249 joh
    old "POUND ME HARDER!"
    new "もっと激しく突いて！"

    # say L250 pla
    old "Huh..."
    new "へえ..."

    # say L271 joh
    old "Ahh, do it as hard as you have to, I want you to smash my pussy"
    new "ああ、どれだけ強くてもいいから、私のオマンコをぶち壊して"

    # say L273 joh
    old "Oh yeah, don't stop, don't stop!"
    new "ああ、止めてないで続けて！"

    # say L276 joh
    old "Show me how powerful your dick is, I want you to make cum!"
    new "あなたのチ○ポの力を見せて、中でイかせて！"

    # say L278 pla
    old "Ughh... "
    new "うっ……"

    # say L307 joh
    old "Oh God! I'm cumming!! Ahhh! Ahhhh!"
    new "ああああ！ 出ちゃう！ アHHH！ アHHHH！"

    # say L325 joh
    old "Yes, just like this baby..."
    new "はい、そうよ baby..."

    # say L326 pla
    old "Gulp..."
    new "ゴクリ…"

    # say L330 joh
    old "Ahh! Your dick is so good..."
    new "ああ！あなたのチ○ポ、本当にいいですね…"

    # say L331 pla
    old "Ah!"
    new "あっ！"

    # say L332 joh
    old "SO GOOD!!!"
    new "ああっ、最高ですっ！！！"

    # say L335 joh
    old "Ohh yeahh, it's so big!"
    new "ああ、そうよ、大きいのね！"

    # say L336 pla
    old "AH!"
    new "AH！"

    # say L337 joh
    old "HARDER, HARDER!"
    new "もっと強く、もっと強く！"

    # say L362 joh
    old "I'm gonna cum!!!"
    new "出ちゃうよ！"

    # say L364 joh
    old "Let's cum together, DON'T STOP, DON'T STOP... AHHH!"
    new "一緒にイこう、止まらないで、止まらないで… アッ！"

    # say L365 pla
    old "Mmmm!! I- I'm coming..."
    new "うん！！ 俺も、イく..."

    # say L371 joh
    old "Wow..."
    new "すごい..."

    # say L383 joh
    old "Oh yeah, I'm going to show you how an expert fucks!"
    new "オーケー、エキスパートがどうやってセックスするか見せてやるよ！"

    # say L384 pla
    old "Ughh, It feels amazing..."
    new "うげっ、すごい感じだ..."

    # say L387 joh
    old "Mmmm... Riding you drives me crazy!"
    new "うん、気持ちいいね… あなたにまたがってるだけで、もう頭が混乱しそう！"

    # say L388 pla
    old "Oh yess... Please don't stop it... Ahh!"
    new "あぁ、お願い、止めないで… アッ！"

    # say L389 joh
    old "Yeah, you like it? Then I'm gonna fuck you harder!"
    new "はい、気に入ってる？　それならもっと激しく犯してやるよ！"

    # say L393 joh
    old "Uhhh... You have really huge cock! I can't fit it all in my pussy."
    new "うーん… あなたのチ○ポ、本当に大きいですね！ 私のマ○コには全部入りきらないです。"

    # say L394 joh
    old "Fuck me! Fuck me! I want you to fill my cunt of cum."
    new "お願い、もっと犯して！ 精液で満たしてほしい！"

    # say L419 joh
    old "Yeeeeesss... Yesss... I- I'm cumming!!"
    new "イエェェッス… イエッス… わたし、イキますっ！！"

    # say L420 pla
    old "Ahhhhh... Ughhh..."
    new "アアァッ… ウッ…"

    # say L426 joh
    old "Ohh, yes, I feel it inside, that's delicious."
    new "ああ、そう、中で感じてる、これが delicious ではなく、美味しそうだ。"

    # say L427 joh
    old "Don't even think about stopping... I need more of your cock NOW!"
    new "止めて欲しくない… 今すぐもっとあなたのチ○ポが欲しいの"

    # say L442 joh
    old "Now softly... I wanna feel all your big cook..."
    new "今優しく……あなたの大きなちんこ全部感じたいの……"

    # say L443 joh
    old "Ohh yeahh... Just like that baby..."
    new "ああ、そうよ… その調子、ベイビー…"

    # say L447 joh
    old "Do you like my big boobs? How do they bounce when you fuck me?"
    new "私の大きなおっぱい、好きですか？ あなたが私を犯すとき、どう跳ねるか感じますか？"

    # say L448 pla
    old "Yes, I love your tits!"
    new "そうだ、お前のオッパイ大好きだ！"

    # say L449 joh
    old "Then, fuck me faster, with that huge cock!"
    new "それなら、もっと速く、その大きなチ○ポで私を犯して！"

    # say L453 joh
    old "Harder! Fuck me harder! I want you to make me cum as you did with Angelina!"
    new "もっと強く！ もっと強く突いて！ アンジェリーナのときみたいに、私をイかせて Wants you to make me cum as you did with Angelina！"

    # say L455 joh
    old "OH GOD... I'M GONNA FUCK YOU EVERYDAY..."
    new "OH GOD... 毎日、あなたを犯すつもりだ..."

    # say L479 pla
    old "I- I going to..."
    new "俺、イクよ…"

    # say L480 joh
    old "Yes! Cum inside me!"
    new "はい！ 中に出してください！"


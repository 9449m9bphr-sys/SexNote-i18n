# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Building.rpy
translate japanese strings:

    # say L96 pla
    old "Uhh... Yes..."
    new "うーん… そうだな…"

    # say L99 pla
    old "Ohh, alright, don't worry I will come tomorrow. Thank you."
    new "オッケー、心配するな、明日行くから。ありがとう。"

    # say L132 pla
    old "Good morning Barbie..."
    new "おはよう、Barbie..."

    # say L141 pla
    old "Good afternoon Barbie..."
    new "お afternoon、Barbie…"

    # say L145 pla
    old "I'm [pla]... I was wondering if I can find a Therapist in this business center."
    new "俺は[pla]… このビジネスセンターでカウンセラーを見つけることができるかどうか知りたいんだ。"

    # say L150 pla
    old "Wow great, Can I go to talk with her?"
    new "Wow great、彼女と話せそう？"

    # say L155 pla
    old "Hmmm, actually is for a friend of mine, but thanks that's all that I needed it."
    new "うーん、実は友達のために聞いてたんだけど、ありがとう。これで十分だ。"

    # say L160 pla
    old "Thank you..."
    new "ありがとう..."

    # say L164 pla
    old "Now I can talk with Mrs. Jade."
    new "今ならジェイド夫人と話せるな。"

    # say L196 pla
    old "I was wondering if Dr. Johnson is in her office."
    new "Dr. Johnsonはお留守ですか。"

    # say L200 pla
    old "Great, thanks"
    new "ありがとうございます、助かりました。"

    # say L217 joh
    old "Hey [pla], did you make an appointment?"
    new "Hey [pla]、予約をしましたか？"

    # say L218 pla
    old "Oh, no, I'm sorry, I just-"
    new "あ ah、すみません、ただ-"

    # say L219 joh
    old "Don't worry if you need anything just let me know."
    new "心配しないでください、何か必要な時はいつでもお知らせください。"

    # say L220 pla
    old "Ok, Thanks."
    new "わかりました、ありがとうございます。"

    # say L248 pla
    old "No, no, sorry I was just looking for Hinn. I have to go."
    new "すみません、ヒンを探してただけです。行かなければなりません。"

    # say L255 joh
    old "Hi [pla], welcome back."
    new "こんにちは [pla]、お帰りなさい。"

    # say L256 pla
    old "Hi doctor Johnson, I'm here because you mentioned we could repeat some lessons..."
    new "ジョンソン先生、先日再び練習できると言っていたので来ました..."

    # say L257 joh
    old "That's great! So, what lesson you want to practice?"
    new "それは素晴らしいですね！どのレッスンを練習したいですか？"

    # menu L262 
    old "Lesson 1"
    new "レッスン1"

    # say L264 joh
    old "Great choice. Let's go to the  practice room..."
    new "素晴らしい選択ですね。練習室に行きましょう..."

    # say L277 joh
    old "Just like that, try to keep it wet, and slowly move a bit faster..."
    new "そのまま、濡れたままで少しずつ速く動かしてみてください…"

    # say L278 joh
    old "Keep doing it like that... Ahh"
    new "そのまま続けて… アッ"

    # say L279 pla
    old "O- ok"
    new "分かったよ"

    # menu L283 
    old "Lesson 2"
    new "レッスン2"

    # say L305 joh
    old "Let's do it!"
    new "それじゃ、始めましょう！"

    # menu L314 
    old "Lesson 3"
    new "レッスン3"

    # menu L332 
    old "Lesson 4"
    new "レッスン4"

    # say L358 joh
    old "You did it wonderful, I'm glad to have you here again..."
    new "素晴らしいですね、また来てくれて嬉しいです。"

    # say L359 pla
    old "Definitely, I will pass by more often."
    new "確かに、もっとよく来るよ。"

    # say L360 joh
    old "It would be the best thing to do, we can enjoy a lot."
    new "それは最良の選択だと思います、一緒にたくさん楽しめますね。"

    # say L361 pla
    old "I don't doubt it."
    new "疑う余地ないね。"

    # say L362 joh
    old "Hope to see you soon."
    new "またお会いできるのを楽しみにしています。"

    # say L363 pla
    old "Thank you, have a great day."
    new "ありがとうございます、良い一日を。"

    # say L364 joh
    old "Bye bye!"
    new "さようなら、またお会いしましょう。"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/BelStory.rpy
translate japanese strings:

    # say L20 pla
    old "Hey guys, how are you?"
    new "おっす、みんな元気？"

    # say L25 hin
    old "Hi [pla], good morning."
    new "おはよう、[pla]。"

    # say L26 mik
    old "Hi dude."
    new "おっす、元気か？"

    # say L27 bil
    old "Hey, what's up?"
    new "hey、何してんの？"

    # say L28 bel
    old "Hi [pla]."
    new "あたし、[pla]。"

    # say L30 pla
    old "What were you guys talking about?"
    new "何を話してたの？"

    # say L34 bil
    old "Oh you know, just listening to Mike's dumb stuff."
    new "ああ、ただマイクのバカな話聞いてただけよ。"

    # say L38 mik
    old "Hey, what do you mean dumb stuff?"
    new "おい、何が馬鹿なことだよ？"

    # say L39 mik
    old "As I recall, you seemed to think it was very interesting."
    new "覚えてるけど、君は結構面白がってたじゃん。"

    # say L44 bel
    old "Well, it was only because there's nothing else going on this early in the morning."
    new "ただ、朝早いから他にすることがないだけよ。"

    # say L57 hin
    old "Hey guys, I think we should get going, classes are about to start."
    new "Hey guys、授業始まっちゃうよ、行こうかな。"

    # say L58 mik
    old "Yeah, we probably should."
    new "そうだな、行こうか。"

    # say L75 bel
    old "[pla], wait."
    new "[pla]、待って。"

    # say L82 pla
    old "Yeah? What's up?"
    new "何だよ？"

    # say L83 bel
    old "Uhm, the thing is... That there's something I need your help with."
    new "うーん、そのことなんだけど… 手伝ってほしいことがあるの。"

    # say L85 pla
    old "Sure, what is it?"
    new "もちろん、何だい？"

    # say L86 bel
    old "Hmm, I think it would be better if we talk about this somewhere else."
    new "うーん、これについては別の場所で話した方がいいかなって思うの。"

    # say L88 bel
    old "Besides, there's something I have to show you."
    new "それに、見せたいものがあるの。"

    # say L89 bel
    old "So, how about you come to my house after classes."
    new "じゃあ、授業が終わった後、我家に来ない？"

    # say L91 pla
    old "Uh, yeah, sure..."
    new "うーん、まあいいけど…ベルの家はどこだ？"

    # say L100 luc
    old "Good morning Belle, [pla]."
    new "ベル、おはよう [pla]。"

    # say L102 pla
    old "Godd morning Miss Lucy."
    new "おはよう、ルーシー。"

    # say L103 bel
    old "Good morning Miss Lucy."
    new "おはよう、ルーシーさん。"

    # say L106 luc
    old "Guys, classes are about to start."
    new "二人とも、授業が始まるよ。"

    # say L107 luc
    old "It's not good that you two stay here talking in the hallway."
    new "二人とも廊下で話してるわけにはいかないわ。"

    # say L109 luc
    old "Good, now go to the classroom you two..."
    new "よし、じゃあ二人とも教室に行きなさい。"

    # say L141 bel
    old "Ugh, that was eternal."
    new "うーん、それが長かったわ。"

    # say L142 bel
    old "Miss Lucy just kept talking and talking."
    new "ミス・ルーシーったら、話が長すぎたわ。"

    # say L143 pla
    old "Tell me about it. I thought classes weren't going to end today."
    new "そう思うよ。授業が今日終わると思わなかったよ。"

    # say L144 bel
    old "Yeah, but anyway."
    new "うん、でもまあ。"

    # say L145 bel
    old "Now that that is over, will you come with me to my house?"
    new "それじゃ、終わったから、私の家に来てくれる？"

    # say L146 pla
    old "Uhh, sure."
    new "うーん、いいよ。"

    # say L147 bel
    old "Alright, then let's go!"
    new "じゃあ、行こう！"

    # say L173 pla
    old "What?! Oh."
    new "何？！ああ。"

    # say L175 pla
    old "I'm just realizing that I have never visited your house before."
    new "俺は今更気づいたんだが、君の家に行ったことないな。"

    # say L177 bel
    old "Oh, I see."
    new "なるほどね。"

    # say L179 bel
    old "Well, I try to avoid inviting people over because my mom tends to be intrusive and it annoys me."
    new "まあ、母が intrusive なのが気に入らないから、あまり人を呼ぶのを避けてるの。"

    # say L181 bel
    old "Although Mike has been here before."
    new "でもマイクは以前来たことがあるの。"

    # say L183 bel
    old "I had to bring him when we were doing that team project."
    new "チームのプロジェクトをやってたから、連れてくなくちゃならなかったの。"

    # say L185 bel
    old "And he met my mom..."
    new "そして彼は私のママに会った…"

    # say L187 bel
    old "It wasn't any fun to see him constantly trying to hit on her..."
    new "彼が常に彼女に言い寄ってるのを見るのは全然楽しくなかった…"

    # say L188 pla
    old "I can imagine him doing that."
    new "想像つくよ。"

    # say L189 bel
    old "It was so awkward."
    new "それはすごく気まずかったわ。"

    # say L191 bel
    old "But anyway, what do you think about the house?"
    new "でも、その家どう思う？"

    # say L193 pla
    old "Uh... It's very nice. I like the decoration a lot."
    new "うーん… すごくいいな。インテリアも気に入ったよ。"

    # say L195 bel
    old "You do? My mom would be happy to hear that, she's really into interior design."
    new "そうなの？母はインテリアデザインが大好きだから、きっと喜ぶね。"

    # say L196 pla
    old "She is? Really?"
    new "そうなのか？本気で？"

    # say L198 bel
    old "Yep, she's a graphic designer, so, she's quite into decorating and stuff."
    new "うん、母はグラフィックデザイナーだから、インテリアデザインにもめっちゃ興味があるんだ。"

    # say L200 pla
    old "Hmm, I guess that makes a lot of sense."
    new "へえ、納得だ。"

    # say L202 bel
    old "So... Changing the subject."
    new "そう……話題を変えよう。"

    # say L204 bel
    old "About... Uhhh, what I wanted to talk to you [pla]."
    new "あの… うーん、話したいことがあって、[pla]。"

    # say L205 pla
    old "Right, right, w- what is it?"
    new "そうだ、そうだ、何なんだ？"

    # say L206 bel
    old "Well, there's something I want to let you know about."
    new "あのね、私について隠していたことがあるの。"

    # say L208 bel
    old "Something I- I've been keeping hidden about myself."
    new "私の中にずっと隠していたことがあるの。"

    # say L209 pla
    old "Uhh... W- what is it?"
    new "うーん… 何だ？"

    # say L210 bel
    old "Well, I- I think it's easier if I show you..."
    new "えっと、これを見た方が早いかなって思うの。"

    # say L213 bel
    old "This is it."
    new "これよ。"

    # say L225 pla
    old "Oh wow, w- what is this?"
    new "おわ、これは何だ？"

    # say L235 bel
    old "Well, not exactly."
    new "まあ、そうとも言えないの。"

    # say L236 bel
    old "I'm a webcam model, it's a little different."
    new "私はウェブカメラモデルで、ちょっと違うの。"

    # say L240 bel
    old "This is something I've been doing for a while now."
    new "これは私がずいぶん前からやってることよ。"

    # say L241 bel
    old "I started by streaming video games, and I enjoyed it a lot."
    new "私はビデオゲームの配信から始めて、それがすごく楽しかったの。"

    # say L243 bel
    old "Over time some of my followers started asking me about some..."
    new "徐々に私のフォロワーの中には、もっと大人向けの内容について聞いてくる人がいましたが..."

    # say L244 bel
    old "More adult content."
    new "もっと大人向けのコンテンツ。"

    # say L246 bel
    old "I started thinking about it. And decided I should give it a go."
    new "考えてみたの。そして、やってみることにした。"

    # say L249 bel
    old "After all, I like being in front of the cameras, and I figured it would be alright as long as my face wasn't shown."
    new "結局、カメラの前でいるのが好きだから、顔が出なければ大丈夫かなと思った。"

    # say L252 bel
    old "From then on, I kept getting deeper and deeper into it."
    new "それから、どんどこ深みにはまっていったわ。"

    # say L254 bel
    old "After all, I discovered I really enjoyed it."
    new "結局、これが結構楽しかったことに気づいたの。"

    # say L255 bel
    old "I've gotten a lot of experience doing this now."
    new "今ではかなりの経験を積んだわ。"

    # say L256 pla
    old "I- I guess I get it."
    new "まあ、分かってきたかな。"

    # say L258 bel
    old "It's been good actually. I've even gotten to make some money off of it."
    new "実際にいい経験になってるの。甚至しお金も稼げるようになったわ。"

    # say L260 pla
    old "Oh! That sounds good."
    new "オォ！それは良いじゃん。"

    # say L262 pla
    old "But why are you suddenly bringing this up?"
    new "でも、急にこれを持ち出すのは何故？"

    # say L263 pla
    old "It's just that I imagine this is the type of thing you would want to keep secret, right?"
    new "ただ、君がこんなことは秘密にしたいと思ってるだろうな、って思っただけだよ。"

    # say L265 bel
    old "I guess, so. Yeah."
    new "うーん、そうかな。"

    # say L266 bel
    old "But there's something happening, and I need some help with it."
    new "でも、何か起こってるの。手伝ってほしいの。"

    # say L267 bel
    old "And I think you're the one that could help me with it."
    new "あなたが手伝ってくれる人だと思ったの。"

    # say L269 pla
    old "M- me?!"
    new "ま- 俺？！"

    # say L271 bel
    old "You see, this is only my first year camming."
    new "実はこれが初めてのキャム YEARで、まだ慣れてないの。"

    # say L273 bel
    old "But my results have been very good. I have received a lot of fan engagement."
    new "でも私の成績はとてもいいの。たくさんのファンからの反応もあったの。"

    # say L276 bel
    old "I even got nominated for an award!"
    new "賞にノミネートされたのよ！"

    # say L277 pla
    old "That's great Belle!"
    new "それはすごいな、ベール！"

    # say L278 pla
    old "Uh, I- I mean... I think so..."
    new "うーん、そうか… そう思うけど…"

    # say L280 bel
    old "Yeah, it is. It's a {b}'Female Revelation Streamer of the Year.'{/b}"
    new "そうよ、これって「{b}女性リベレーションストリーマー・オブ・ザ・イヤー」の賞なの。{/b}"

    # say L281 bel
    old "And I'm one of the forerunners for it!"
    new "そしてそれが私に向けられているのよ！"

    # say L282 pla
    old "I see, congrats Belle, that's awesome!"
    new "なるほど、おめでとうベル、すごいね！"

    # say L283 pla
    old "But all of that sounds very good."
    new "でも、それ全部すごくいいね。"

    # say L284 pla
    old "I don't see what you could need my help with."
    new "俺には君が何のために俺の手伝いが必要なのか見えないな。"

    # say L286 bel
    old "You see, these awards are measured as a popularity contest."
    new "あなたが思う通り、これらの賞は人気投票で決まるの。"

    # say L288 bel
    old "So, the winner is decided by who gets the most fan votes and tips in their category by the end of the time period."
    new "だから、期間終了までに最も多くのファン投票とチップを獲得した人が勝者になるの。"

    # say L290 bel
    old "The number of votes and tips each person receives is put into a public chart, so, we know who's in the lead."
    new "各人の投票数とチップが公開チャートに載せられるから、誰がリードしているのかわかるの。"

    # say L291 bel
    old "Well, that's only until the final days of the contest."
    new "まあ、それはコンテストの最終日までのことね。"

    # say L292 bel
    old "Some days before it's over the results are hidden and the winner is announced at the end."
    new "終了の数日前には結果が隠されて、最終日に優勝者が発表されるの。"

    # say L294 pla
    old "I see."
    new "なるほどか。"

    # say L295 bel
    old "I've been doing pretty well on the polls."
    new "投票の結果、私はなかなか好調なの。"

    # say L297 bel
    old "Since the beginning of the contest I have been at the top of the standings."
    new "コンテストが始まってから、ずっと上位に立ってるの。"

    # say L298 bel
    old "So much so that I thought I was going to win it easily."
    new "そんなに上位に立っていたので、簡単に勝てると思っていたの。"

    # say L300 bel
    old "However, recently a new model has been getting all the attention."
    new "しかし、最近新しいモデルが注目を集めているの。"

    # say L301 bel
    old "There's this girl named Lana. She just appeared seemingly out of nowhere and overtook me."
    new "この子、ラナって言うの。突然現れて、私を追い越しちゃったの。"

    # say L303 bel
    old "With the way things are going, she's going to run away with the lead, and beat me."
    new "この調子だと、彼女はトップを独占して、私を抜いちゃうわ。"

    # say L305 pla
    old "Oh, I'm sorry Belle, it sucks that something like this is happening."
    new "ベル、そんなことが起こってほんとにつらいね。"

    # say L307 bel
    old "Oh! It really does! Especially because she's not getting the lead in the competition fairly!"
    new "Oh！本当にそうだわ！特に彼女が競技でフェアに主役を獲得していないのに、なおさらだわ！"

    # say L309 bel
    old "Well, I've been thinking about why this girl is so popular."
    new "まあ、この子がこんなに人気がある理由を考えたの。"

    # say L311 bel
    old "And I figured it out."
    new "わかったわ。"

    # say L312 bel
    old "It's just because she's not doing the same things I and the other girls in the category are doing."
    new "それは彼女が私や他の女の子たちがやってることと違うことをしてるからだよ。"

    # say L314 pla
    old "Isn't she doing livestreams like the others?"
    new "彼女も他の子たちと同じように配信してるんだよね？"

    # say L316 bel
    old "Yes, but, as I told you, the category in which I'm competing is called ‘Female Revelation Streamer of the Year.'"
    new "はい、でも私が言った通り、私が競うカテゴリーは『年間最優秀新進女性ストリーマー』だよ。"

    # say L317 bel
    old "It's a {i}single-person{/i} category."
    new "それは{i}個人{/i}のカテゴリーだ。"

    # say L318 bel
    old "Otherwise couples or even groups could take part and compete in it."
    new "それじゃ、カップルやグループまで参加できちゃうよ。"

    # say L319 bel
    old "But they have their own category."
    new "でも彼らには独自のカテゴリーがあるの。"

    # say L320 bel
    old "However, she is doing streams with a guy..."
    new "しかし、彼女は男の子と一緒にストリームをしているんだ..."

    # say L322 bel
    old "Obviously, this type of content is much more appealing to the audience since it's literally a sex live show."
    new "当然、この種のコンテンツは視聴者にとってずっと魅力的だもん。字面通りセックスの生配信なんだから。"

    # say L323 bel
    old "And this gives her a significant advantage over those of us who participate individually in our category..."
    new "これで、彼女には私たち個別に参加している人間たちよりも大きなアドバンテージがあるわ…"

    # say L325 bel
    old "So she should be participating in another category, for example, {i}'Best Streamer couple of the Year'{/i}."
    new "だから彼女は別のカテゴリーに参加した方がいいんだよ、例えば {i}'最優秀ストリーマーカップル賞'{/i} とか。"

    # say L326 pla
    old "I see, I suppose that makes sense."
    new "なるほど、それも道理だな。"

    # say L327 bel
    old "Of course, that makes sense! I even thought they would move her to a different category or suspend her for doing a different type of content..."
    new "もちろん、その通りだよ！ 私は彼女が別のカテゴリーに移動されるか、あるいは異なるコンテンツを配信したことで一時的に活動停止になると思っていたの..."

    # say L328 bel
    old "But apparently, there aren't any rules against what she is doing to compete in this category..."
    new "でも、どうやら彼女がこのカテゴリーで競うためにやってることに対してはルールがないみたいね…"

    # say L329 bel
    old "Since when she was nominated in the category, she was doing solo streams."
    new "ノミネートされたときから、彼女はソロストリームをやってたんだ。"

    # say L330 bel
    old "But then, does that mean she can do whatever she wants and win?"
    new "でも、それって彼女は何をしても勝てるってこと？"

    # say L331 bel
    old "Taking advantage of doing things from other categories to get more attention?"
    new "他のカテゴリーのことをやって注目を集めようとしてるの？"

    # say L332 pla
    old "Hmm, yes, I understand. If you look at it a certain way, it's like she's cheating."
    new "うん、そうだな。ある意味、彼女はルールを捻じ曲げて、より注目を集めようとしてるみたいだな。"

    # say L333 bel
    old "That's exactly what I think too! But the webcam platform doesn't seem to care..."
    new "そう思うよ！でもウェブカメラのプラットフォームはそんなの気にしてなさそう…"

    # say L334 bel
    old "After all, is not the same to see a couple fucking on screen, to just seeing somebody playing with a toy or something."
    new "結局、画面でカップルがセックスしてるのと、ただ誰かがオモチャで遊んでるのとは全然違うじゃない。"

    # say L336 bel
    old "And the problem with that is that she's only doing it to win..."
    new "その問題は、彼女が勝つためにだけやってることだよね…"

    # say L337 bel
    old "Which means she's only interested in winning in this category now, by using tactics that of course gain her more popularity here."
    new "それはつまり、彼女は今このカテゴリーで勝つことにしか興味がないってことよね、その戦略は当然ここでの人気を上げるものだから。"

    # say L338 bel
    old "Because she knows she wouldn't win doing what we do, or doing what she's doing in a couples category!"
    new "だって彼女は私たちがやってることや、カップル部門でやってることでは勝てないって知ってんだから！"

    # say L342 bel
    old "Look, this is a recording from a recent streaming she did."
    new "これ、彼女が最近配信した時の録画だよ。"

    # say L361 sis2
    old "I know this is what you guys have been waiting for."
    new "これがあなたたちが待っていたものだって知ってるわ。"

    # say L362 sis2
    old "You all wanted to see me sucking a big cock didn't you?"
    new "みんな、大きなちんこを咥えてるところを見たかったんでしょ？"

    # say L382 bel
    old "Do you see? She's practically doing live sex!"
    new "見なさい？彼女、ほとんど生でセックスしてるんだ！"

    # say L384 bel
    old "She shouldn't be in the 'Female Revelation Streamer' category!"
    new "彼女は『女性リベレーションストリーマー』カテゴリーに入るべきじゃない！"

    # say L386 pla
    old "I guess that her winning the contest by doing something that no one else is doing is unfair."
    new "他の誰もやっていないことをやって優勝するのは、不公平だな。"

    # say L387 pla
    old "I get it, I get it."
    new "分かった、分かった。"

    # say L388 pla
    old "And what are you planning to do about it?"
    new "じゃあ、どうするつもりなんだ？"

    # say L390 bel
    old "Well, to be honest [pla]..."
    new "正直に言うと、[pla]..."

    # say L394 bel
    old "I really like doing this, a lot."
    new "正直、これをするのが本当に大好きなんだ。"

    # say L396 bel
    old "I've worked so hard from the beginning."
    new "最初からずいぶんと努力してきたの。"

    # say L398 bel
    old "And ever since I started I've put a lot of effort into being number one."
    new "だから始めてからずっと、一位になるため頑張ってきたの。"

    # say L399 bel
    old "In fact, until just a few days ago I was first in the rankings."
    new "実際、ほんの数日前までランキングのトップだったのよ。"

    # say L400 bel
    old "So, I think I should be the one that wins that award!"
    new "だから、その賞は私が取るべきだと思うの！"

    # say L401 bel
    old "Not some rando that just came out nowhere!"
    new "ただのどこからともなく現れた誰かじゃない！"

    # say L402 bel
    old "So, I've decided that I'm going to retake the lead in the contest."
    new "だから、私はコンテストで再びリードを取り戻すことに決めたの。"

    # say L405 bel
    old "That's where I want you to help me."
    new "そこで君の手伝いが必要なの。"

    # say L406 pla
    old "Uhm... H- how?"
    new "うーん… どうすりゃいいんだ？"

    # say L409 bel
    old "I want to fight fire with fire!"
    new "火事場の马鹿力を発揮したいわ！"

    # say L410 bel
    old "I want to see if she will actually beat me if both of us are doing the same."
    new "見たいと思うの、二人とも同じことをしていても、彼女が本当に私を打ち負かすかどうか。"

    # say L414 pla
    old "You want to record yourself having sex on camera?!"
    new "お前カメラの前でセックスするの録音したいのか？！"

    # say L416 bel
    old "W- Well... Technically we would be having s- sex live, but it would be recorded."
    new "ええと……厳密には生でエッチすることになるけど、録画されるのよ。"

    # say L418 bel
    old "Well, yeah, that's why I need your help..."
    new "うん、だからあなたの手伝いが必要なんだ…"

    # say L419 bel
    old "T- that way, I- I think I'll manage to get the votes to surpass Lana."
    new "そうすれば、ラナを上回る票を集めるかなと思うの"

    # say L421 pla
    old "That's not the point..."
    new "それって違うんじゃない？"

    # say L422 pla
    old "I kinda get what you're saying, but, this is a little unexpected, you know?"
    new "君の言っていることは理解できるけど、ちょっと意外だったな。"

    # say L424 bel
    old "I- I know it is. But listen, I've put a lot of effort into this."
    new "知ってるよ、でもね、これにはかなりの労力を使ったの。"

    # say L425 bel
    old "From streaming video games to getting into camming, and growing my fanbase."
    new "ゲームの配信からカメラワークに挑戦して、ファンベースを広げて。"

    # say L427 bel
    old "Losing is just not an option..."
    new "負けるなんて選択肢にないの…"

    # say L429 bel
    old "So I need your help, please."
    new "だから、助けてほしいの。"

    # say L430 bel
    old "It will only be a couple of times, only until I can overtake her."
    new "数回だけよ、彼女を追い越せるまでだけ。"

    # say L432 pla
    old "I mean, I think I get it."
    new "つまり、まあ理解したつもりだよ。"

    # say L433 pla
    old "What I don't understand is why it has to be me."
    new "何が俺でなきゃいけないのか、それがわからないんだ。"

    # say L434 pla
    old "Don't you know somebody that knows about this sort of thing?"
    new "君が知ってるようなことについて詳しい人でもいいんじゃないか？"

    # say L435 pla
    old "You know... a professional?"
    new "君が知ってるプロでもいいだろ？"

    # say L437 bel
    old "Actually, I don't know anybody... Any men, I mean."
    new "実は誰も知らないの... 男性のことを言っているの。"

    # say L439 bel
    old "I've been doing everything by myself."
    new "私、全部自分でやってきました。"

    # say L442 bel
    old "I haven't ever worked with anybody before, so I don't know any man inside this business that would do it."
    new "私、誰とも一緒に仕事をしたことがないから、この業界でそんな男の人を知らないの。"

    # say L444 bel
    old "But if I'm completely honest with you [pla], even if I knew a webcam actor or model I would still prefer to do it with you."
    new "でも正直に言うと [pla]、ウェブカメラの俳優やモデルを知っていたとしても、あなたとやりたいと思うわ。"

    # say L446 pla
    old "What? R- Really?"
    new "何？本気だよ？"

    # say L448 bel
    old "Well, I don't want to do this with some unknown person. For me sex is a very intimate thing."
    new "WELL、未知の人とこんなことしたくないの。私にとってセックスはとても個人的なことだから。"

    # say L450 bel
    old "I at least want it to be with someone I trust."
    new "せめて信頼できる人としたいの。"

    # say L451 pla
    old "I- uh... I understand."
    new "うーん……なるほど。"

    # say L453 pla
    old "But I'm don't know Belle. I don't think I want people watching me have sex on camera."
    new "でも Belle、カメラの前でセックスするのはちょっと抵抗あるな。"

    # say L455 pla
    old "Besides, and I know this is kind of obvious... That also means that you and I would have to have sex, right?"
    new "それに、これはちょっと当然かもしれないけど… それって君と俺がセックスしないといけないってことだよね？"

    # say L456 pla
    old "Are you ok with that?"
    new "君はそれでいいんだ？"

    # say L458 bel
    old "I- I do... As I told you [pla], I trust you."
    new "あたし、大丈夫… 先に言った通り、あなたを信頼してるの [pla]。"

    # say L460 bel
    old "Also, is not as if you and I have never done that sort of thing before, right?"
    new "それに、私たちはそんなことしたことがないわけじゃないよね。"

    # say L461 bel
    old "This won't be too different from that."
    new "これもそれとそんなに変わらないよ。"

    # say L463 bel
    old "And about the whole appearing on camera thing, you don't have to worry about that."
    new "カメラに映ることについて心配しなくていいから。"

    # say L465 bel
    old "I will focus the camera so that your face doesn't show in any way."
    new "カメラを調整して、あなたの顔が映らないようにするから。"

    # say L467 bel
    old "Please [pla], I want to win this."
    new "お願い、[pla]、この勝負に絶対に勝ちたいの。"

    # say L469 bel
    old "I know this is just what I need to win against Lana."
    new "これでランナに勝てるって分かってるの。"

    # say L476 pla
    old "I guess it's fine if it helps you..."
    new "まあ、君の役に立つならいいけどね。"

    # say L477 bel
    old "So, you'll do it?"
    new "じゃあ、やってくれるの？"

    # say L480 pla
    old "I can't believe it, but I will."
    new "信じられないけど、やるよ。"

    # say L482 bel
    old "Thanks a lot [pla]!"
    new "ありがとう、[pla]！"

    # say L483 bel
    old "So, I have to prepare everything on stream."
    new "じゃあ、配信のために全部準備するね。"

    # say L485 bel
    old "I have to let my fans know about it."
    new "ファンに知らせる必要があるんだ。"

    # say L488 bel
    old "Let them know there's a surprise coming and stuff."
    new "ファンにサプライズがあるって知らせてあげるね。"

    # say L489 bel
    old "I'll let you know when we'll do it."
    new "私が決まったら教えてあげるね。"

    # say L493 bel
    old "Thanks a lot [pla]."
    new "ありがとう、[pla]。"

    # say L496 pla
    old "So... "
    new "じゃあ……"

    # say L497 pla
    old "I think I'll see you later then."
    new "じゃあ、後でな。"

    # say L499 bel
    old "Sure, I'll prepare everything and let you know when we're ready to stream."
    new "分かった、準備してからストリームできるようになったら知らせるね。"

    # say L500 pla
    old "Alright, great!"
    new "じゃあ、よし！"

    # say L501 pla
    old "Bye Belle."
    new "バイベル。またな。"

    # say L502 bel
    old "Bye [pla], and thank you so much again."
    new "バイ、[pla]。また本当にありがとう。"

    # say L526 pla
    old "Hi Belle, good morning, how are you?"
    new "ベル、おはよう、元気ですか？"

    # say L528 bel
    old "Listen [pla], my mother told me she won't be in the house this afternoon."
    new "[pla]、聞いて。母が今日の午後、家にいないって言ったの。"

    # say L529 bel
    old "She has a meeting or something."
    new "彼女は会議か何かがあるって。"

    # say L531 bel
    old "So, today can be the first day that you come and help me with my stream."
    new "じゃあ、今日が君が初めて手伝いに来る日になるわ。"

    # say L535 bel
    old "Plus, I think this is a good opportunity for you to make your first appearance on camera."
    new "それに、これはあなたが初めてカメラの前で登場するいい機会だと思うの。"

    # say L536 bel
    old "So that you can get a feel for it, and start getting used to beign on camera."
    new "そうすれば、雰囲気をつかめて、カメラの前でいることに慣れていくわ。"

    # say L538 pla
    old "O- ok sure, no problem."
    new "おー、わかった、問題ないよ。"

    # say L539 pla
    old "L- lets do it."
    new "よし、やろう。"

    # say L541 bel
    old "Ok, great!"
    new "おｋ、良かった！"

    # say L542 bel
    old "Come to my house in the afternoon."
    new "午後に私の家に来なさい。"

    # say L544 pla
    old "I thought I would go with you right after we finished classes."
    new "クラスが終わったら君と一緒に行くつもりだったんだ。"

    # say L546 bel
    old "No, I will skip classes today. I need to go home and get everything ready for the stream. I just came to let you know."
    new "今日は授業を休むわ。配信の準備のために家に帰らないといけないの。ただ、あなたに伝えるためだけに来たのよ。"

    # say L547 pla
    old "Alright, no problem."
    new "分かった、問題ないよ。"

    # say L549 bel
    old "So, see you later at my house."
    new "じゃあ、後でうちでね。"

    # say L571 pla
    old "Ok, I think Belle must be waiting for me..."
    new "じゃあ、ベールが待ってるだろうな…"

    # say L572 pla
    old "Phew, I don't know how I always get myself into these things..."
    new "ふう、どうしていつもこんなことになるんだろう…"

    # say L593 ash
    old "Oh! Hello."
    new "あ！こんにちは。"

    # say L595 pla
    old "Uh... H- hi, g- good afternoon."
    new "あー… あ、こんにちは、ご、ごきげんよう。"

    # say L597 ash
    old "Good afternoon. Can I help you with something?"
    new "こんにちは。何か手伝えることある？"

    # say L599 pla
    old "I- uh... yes, I'm [pla], I'm a friend of Belle."
    new "あー、うん… はい、俺は [pla] だ、ベールの友達なんだ。"

    # say L600 pla
    old "I- I came to do some... Uh, s- schoolwork with her."
    new "あー、あの... 学校の勉強を一緒にしようと思って来たんだ。"

    # say L602 ash
    old "Oh! Nice meeting you [pla]! My name is Ashley, I'm Belle's mother."
    new "Oh！ 会えて嬉しいわ [pla]！ 私はアシュリー、ベルの母よ。"

    # say L603 pla
    old "H- Hi..."
    new "Ｈ－ひょえ…"

    # say L605 pla
    old "{i}(Her mother? Belle told me she wouldn't be here. I guess I should ask her about Belle.){/i}"
    new "({i}(Belleの母親？Belleは彼女がここにはいないって言っていたけどな。まあ、Belleについて聞いてみよう。){/i})"

    # say L606 pla
    old "Excuse me Mrs. Ashley..."
    new "すみません、アシュレイさん…"

    # say L608 ash
    old "Mrs. Ashley? Haha, oh dear no, just call me Ashley. I'm too young to have anyone call me Mrs."
    new "アシュレイさん？ハハ、いえいえ、アシュレイでいいですよ。まだ「奥様」なんて呼ばれる年齢じゃないですからね。"

    # say L610 pla
    old "O- ok, A- Ashley. Is Belle around? She told me to come at this time."
    new "あ、あしーりー。ベッちゃんはいる？彼女にこの時間に来るように言われたんだ。"

    # say L612 ash
    old "She is dear, she's in her bedroom."
    new "いるよ、彼女の寝室にいるの。"

    # say L613 ash
    old "I'll let her know you're here."
    new "私が伝えるよ。"

    # say L615 pla
    old "T- thanks."
    new "ありがとう、アッシュ。"

    # say L625 bel
    old "[pla]! H- hi! I- I didn't notice you arrived! Sorry."
    new "[pla]！　ひっ！　あ、こんにちは！　来てくれたのに気づかなかったわ！　ごめんなさい。"

    # say L627 bel
    old "Mom, why didn't you tell me a visit for me had arrived?"
    new "ママ、どうして私に客人が来たって教えてくれなかったの？"

    # say L630 ash
    old "Well sweety, you didn't tell me you were expecting anyone."
    new "まあ、君が誰かを待ってるって言ってくれなかったじゃないね"

    # say L633 ash
    old "But I was just about to come and tell you your friend had arrived."
    new "でも私がちょうどあなたに友達が来たって言おうとしてたところだったのよ。"

    # say L635 bel
    old "I- I see...."
    new "あ、そうか..."

    # say L636 bel
    old "Anyway mom, [pla] and I are going to be working in my room."
    new "でも、ママ、[pla] と私は部屋で作業するからね。"

    # say L639 bel
    old "So, it would be nice if you could avoid interrupting us."
    new "だから、邪魔をしないでくれると嬉しいな。"

    # say L641 ash
    old "Well, I guess I'll do my best not to bother you, sweetheart."
    new "まあ、なるべく邪魔しないようにするわ、甘いもの。"

    # say L644 bel
    old "Come on [pla], let's go."
    new "さあ、[pla]、行こう。"

    # say L658 pla
    old "Hey, what's up? I thought you said she wasn't going to be here today?"
    new "hey、何言ってんだよ？君が今日ここに来ないって言ったじゃん？"

    # say L659 bel
    old "Yeah I know, sorry"
    new "うん、ごめんなさい。"

    # say L661 bel
    old "She just suddenly came back home and said she was going to work from home today."
    new "急に家に戻ってきて、今日から在宅勤務だって言うよ。"

    # say L662 bel
    old "I don't know why, I guess something happened at the office."
    new "理由はわからないけど、オフィスで何かあったのかもしれないね。"

    # say L663 pla
    old "Hmm ok, yeah, I understand."
    new "うん、わかった。"

    # say L664 pla
    old "I suppose we're not streaming today then."
    new "じゃあ今日は配信しないんだな。"

    # say L666 bel
    old "Yep, we can't do the stream with my mother here."
    new "Yep、母親がいるから今日は配信できないね。"

    # say L668 bel
    old "She could come in at any time."
    new "いつでも入ってきちゃうかもしれないから。"

    # say L670 bel
    old "She'll be bringing some snacks, or knocking on the door to see how we're doing, or something."
    new "お母さん、おやつを持ってきたり、ドアをノックして私たちがどうしてるか見に来たりするかもしれないから。"

    # say L673 bel
    old "My mom's very controlling, and she'll want to know what we're doing here."
    new "私のママはとてもコントロール欲が強く、私たちがここで何をしているのか知りたがるわ。"

    # say L675 bel
    old "So, it's better if we don't risk being caught in the middle of it."
    new "だから、途中で見つかるリスクは避けた方がいいな。"

    # say L679 bel
    old "I'm sorry [pla]... that ruins our plans for today."
    new "ごめんなさい [pla]… 今日の計画台無しだね。"

    # say L680 bel
    old "I'm sorry to have you come here for nothing."
    new "ごめんなさい、無駄に来ちゃったね。"

    # say L682 pla
    old "Oh, don't worry. We can do it on any other day. I'll head back home then."
    new "大丈夫だよ、他の日にすればいいさ。じゃあ、俺は帰るとするか。"

    # say L684 bel
    old "Well, maybe you should stay for a little while."
    new "まあ、ちょっとだけいなよ。"

    # say L685 bel
    old "After all, you just got here. My mom could get suspicious if you leave just after arriving."
    new "刚到这里而已嘛。妈妈要是你刚来就走可能会起疑心哦。"

    # say L687 pla
    old "Ok, so what are we going to do?"
    new "じゃあ、何する？"

    # say L689 bel
    old "I was thinking I could let you know a bit more about this whole camming thing, how it works and stuff."
    new "私が考えたのは、このカムについてもっと詳しく教えてあげることかな。どのように動いているのかとかね。"

    # say L690 pla
    old "Oh, ok sure."
    new "分かった、オッケー。"

    # say L692 bel
    old "So, the way the stream works is through a {i}'tips'{/i} system."
    new "ストリームの仕組みは、{i}チップ{/i}システムなんだ。"

    # say L694 bel
    old "While we're doing it, that's the most important thing to keep in mind."
    new "やってる最中、それが一番大切なのよ。"

    # say L696 bel
    old "And whatever I'm going to do, I do it live, instead of having it pre-recorded, like in porn."
    new "そして私がやることって、生放送でやるの。事前に録画したものじゃなくて、本物のライブよ。"

    # say L697 bel
    old "Since everything is completely live, tips are very important."
    new "ライブで全部やっているから、チップはとても重要なんだよ。"

    # say L698 pla
    old "Why?"
    new "なんで？"

    # say L700 bel
    old "Well, because the livestream is a type of show."
    new "まあ、ライブストリームは一種のショーだからね。"

    # say L701 bel
    old "Which means that my fans have to be engage and entertained."
    new "それはつまり、私のファンが参加して楽しむ必要があるってことよ。"

    # say L703 bel
    old "And the only reliable way I can gauge if they really like it, is by seeing their tips."
    new "そして、彼らが本当に気に入っているかどうかを確実に知る唯一の方法は、チップを見ることだよ。"

    # say L704 bel
    old "So, the whole objective of each time I'm on camera is to get them to tip."
    new "だから、私がカメラの前でやる目的は、彼らにチップをくれてもらうことなの。"

    # say L705 pla
    old "Uhh... I see."
    new "うーん… 分かったか。"

    # say L706 bel
    old "So, whenever the stream starts, I have to set up some {i}'goals'{/i}."
    new "ストリームが始まるたびに、いくつかの {i}目標{/i} を設定しないといけないの。"

    # say L708 bel
    old "Which is the number of tips I want my fans to give me before I do anything."
    new "それが私がファンからもらうチップの数の目標よ。"

    # say L709 bel
    old "If the audience matches the goals by tipping, I do what I promised for that goal, and move into the next one."
    new "視聴者が目標のチップを達成したら、その目標で約束したことをして、次の目標に進むの。"

    # say L711 pla
    old "I think I get it."
    new "わかったような気がする。"

    # say L712 pla
    old "So, whether we do something or not, depends on the audience?"
    new "そうか、やるかどうかは観客次第なのか？"

    # say L713 bel
    old "That's right, we decide what to do, but we only do it if the goal is met."
    new "そうです、私たちが何をするかは決めるけど、目標が達成された時だけ実行するの。"

    # say L715 pla
    old "That sounds simple."
    new "そうか、それなら簡単そうだな。"

    # say L717 bel
    old "Well, it's all about personality, and how much you connect with the audience, you know?"
    new "まあ、それは個性と、どれだけ視聴者とつながれるかってことよね。"

    # say L718 bel
    old "So it's important to talk to them, try and pay attention to their comments, and the demands they make."
    new "だから、彼らと話して、コメントや要求に耳を傾けるのが大事なんだよ。"

    # say L720 pla
    old "That makes sense."
    new "なるほど"

    # say L722 bel
    old "And as I told you before, you don't need to talk or interact with them."
    new "そして前に言った通り、あなたが話したり関わる必要はないの。"

    # say L724 bel
    old "After all, my fans want to see me doing something with a... w- with a penis."
    new "結局、私のファンは私があなたの… ペニスを使って何かすることを見たいだけよ。"

    # say L726 bel
    old "But they don't really want to get to know you."
    new "でも、あなたのこと知りたくないのよ。"

    # say L728 bel
    old "T- the most important is for you to... have a b- boner during the show."
    new "Ｔ- 一番大切なのは君が… 舞台上で ｂ- ボンエrectionしてることだよ。"

    # say L729 bel
    old "I- I'll take care of the rest."
    new "あとは私がやってあげるから。"

    # say L731 pla
    old "Well... I- I guess I can manage that."
    new "WELL... 俺がそれをなんとかできると思うけど、頑張るよ。"

    # say L742 ash
    old "Hey guys! How are you doing?"
    new "ねぇみんな！元気してる？"

    # say L744 bel
    old "Uhmm, we're doing fine mom."
    new "うーん、大丈夫よ、ママ。"

    # say L745 bel
    old "But I would've appreciated it if you'd knocked on the door before entering."
    new "でも、入る前にドアをノックしてくれたら嬉しかったのに。"

    # say L748 ash
    old "I'm sorry honey, but I just wanted to see if you needed anything."
    new "ごめんなさい、ただ見に来たの。何か必要なものがあったかと思って。"

    # say L750 ash
    old "Maybe you would like me to bring you some snacks?"
    new "おやつを持ってきてもいいかな？"

    # say L752 bel
    old "I think we're fine mom, thank you."
    new "大丈夫よ、ママ、ありがとう。"

    # say L753 ash
    old "Ok sweety, I'll leave for now then."
    new "分かったわ、今帰るね。"

    # say L754 ash
    old "But if you two need anything, just let me know."
    new "でも二人で何か必要になったら、教えてね。"

    # say L755 bel
    old "Yeah, right, thank you..."
    new "うん、そうね、ありがとう…"

    # say L763 bel
    old "Sorry, she just came in unannounced."
    new "ごめん、彼女が勝手に入ってきちゃった。"

    # say L765 pla
    old "It's ok, we kinda knew she was going to do that."
    new "大丈夫、彼女がそうするってのは予想してたから。"

    # say L766 bel
    old "Yeah... but that's why we can't do anything whenever she's here."
    new "うん……でも、それが彼女がいるときには何もできない理由なの。"

    # say L767 pla
    old "Y- yeah, I- I get it..."
    new "Ｙ－\"わ－わかった...\""

    # say L769 bel
    old "Well, anyway, t- there hasn't been enough time since you came here."
    new "まあ、でも、あなたがここに来てからまだ時間があんまりないよね。"

    # say L770 bel
    old "So, why don't I show you the webcam platform in the meantime?"
    new "じゃあ、その間ウェブカメラのプラットフォーム見せてあげる？"

    # say L771 pla
    old "Yeah... sure."
    new "うん…いいよ。"

    # say L780 bel
    old "Ok, this is my profile..."
    new "Ok、これは私のプロフィールです…"

    # say L792 bel
    old "Ok [pla], I think that should be enough time for my mom not to suspect anything."
    new "Ok [pla]、これくらいなら母に疑われないだろうね。"

    # say L793 bel
    old "I'll let you know when it's ok for you to come again."
    new "また来てもいいって言ってから来なさいね。"

    # say L794 pla
    old "Yeah, sure, just tell me when and I'll come to help you."
    new "分かった、ベル。何時来てもいいと言われたら行くから。"

    # say L796 pla
    old "You're welcome Belle, I'm happy to help you."
    new "ベル、喜んで手伝うよ。"

    # say L797 bel
    old "I hope next time we won't have any problems streaming."
    new "次は問題なく配信できるといいな。"

    # say L799 bel
    old "The voting period is closing soon, and we won't be able to do anything if we have to postpone it too much."
    new "投票期間が終わりつつあるし、延期が長引くと何もできなくなっちゃうわ。"

    # say L801 pla
    old "I get it, but what happened today was just unexpected."
    new "分かってるけど、今日のことは本当に予想外だったな。"

    # say L802 pla
    old "I bet there won't be any problem going forward."
    new "多分これからは問題ないだろうな。"

    # say L804 bel
    old "Yeah, you're probably right."
    new "うん、多分そうかな。"

    # say L805 pla
    old "So, listen... I guess I should get going, right?"
    new "じゃあ、聞いて…俺は帰るってことだな？"

    # say L807 bel
    old "Sure, I'll see you later [pla], thanks again for coming."
    new "うん、またね[pla]、来てくれてありがとう。"

    # say L808 pla
    old "You're welcome, see you later Belle."
    new "どういたしまして、またねベール。"

    # say L831 bel
    old "Hi [pla]!"
    new "こんにちは [pla]！"

    # say L832 pla
    old "Hi Belle."
    new "嗨ベル。"

    # say L834 pla
    old "Uhm, I'm doing well, and you?"
    new "うーん、俺は調子いいよ、君は？"

    # say L838 bel
    old "So listen, after you left, my mom said it was very nice to meet you."
    new "じゃあ聞いて、あなたが帰った後、ママが会えて良かったって言ってたの。"

    # say L840 pla
    old "S- she did?"
    new "え、そうなのか？"

    # say L842 bel
    old "Yeah, she said that you seemed to be a good person."
    new "うん、あなたが良い人そうだって言ってたよ。"

    # say L844 pla
    old "I- I guess that's nice."
    new "うーん、そうか。まあ、それはいいことだな。"

    # say L846 bel
    old "It is, when she met Mike she went on an on about how rude he was."
    new "彼女がマイクに会ったとき、彼の無礼さについて延々と話してたわ。"

    # say L848 bel
    old "So, I'm glad she liked you."
    new "そう、彼女が君のことを気に入ったのは嬉しいわ。"

    # say L849 pla
    old "Uhh, w- well, that's great."
    new "うーん、まあ、それは良かったな。"

    # say L851 bel
    old "Yeah, that may make things easier in the future."
    new "そうね、それなら今後は少し楽になるかもしれないわ。"

    # say L852 bel
    old "But leaving that aside, my mom told me she won't be home this afternoon."
    new "でも、それとは別に、ママが今日の午後は家にいないって言ってたの。"

    # say L854 bel
    old "So we can start streaming today!"
    new "じゃあ今日から配信始められるね！"

    # say L856 pla
    old "Ok... that sounds alright."
    new "そうだな…いいじゃん。"

    # say L858 bel
    old "Ok, let's go to my house after classes then."
    new "じゃあ、授業が終わったら私の家に行こうね。"

    # say L887 bel
    old "Ok, let's go to my house then."
    new "じゃあ、私の家に来よう。"

    # say L919 bel
    old "Alright, before we begin there's a couple of things we have to check."
    new "それじゃ、始める前に確認しておかないといけないことがあるの。"

    # say L920 pla
    old "Oh... Ok."
    new "わかった…"

    # say L922 bel
    old "You remember what I told you about how it's important to talk to the audience, right?"
    new "覚えてるよね、観客と話すことが大事だって言ったこと。"

    # say L925 bel
    old "You also remember that I told you I'm the one who's going to be talking to them, right?"
    new "あなたも覚えてるよね、私が彼らと話すことになるって言ったこと。"

    # say L926 pla
    old "Yeah, I do, no problem."
    new "うん、覚えてる、問題ない。"

    # say L928 bel
    old "Ok, I already announced that I was going to have a big surprise in today's stream."
    new "じゃあ、今日の配信で大きなサプライズがあるってすでに発表したよね。"

    # say L929 bel
    old "So, I'll come in on stream and start the whole thing."
    new "配信が始まってから入ってくるわ。"

    # say L931 bel
    old "Talking to the audience, and when it's the right time, I'll tell you to come in."
    new "皆さんと話してるときに、ちょうどいいタイミングで入ってきてって言うからね。"

    # say L933 pla
    old "Ok, I understand."
    new "分かったよ。"

    # say L935 bel
    old "The camera will be pointing in my direction."
    new "カメラは私の方向を向いています。"

    # say L936 bel
    old "You'll wait out of frame while I start the stream, and when I tell you, you come in."
    new "あなたはフレーム外で待っていて、私がストリームを始めるから。そして私が合図をしたら、入ってきてね。"

    # say L938 bel
    old "By the way, you won't be naked from the beginning... J- just wearing your shorts will be ok."
    new "それにしても、最初から裸じゃなくて……ショーツだけでもいいのよ。"

    # say L940 pla
    old "Ok, I think I get it."
    new "分かった、大体理解したよ。"

    # say L942 bel
    old "You know, [pla], I'm very thankful to you for doing this."
    new "知ってる？[pla]、あなたがこれをしてくれて本当に感謝してるの。"

    # say L944 bel
    old "I know this is new for you, and you're probably not very comfortable with it."
    new "新しいことだから、きっとまだ慣れてないよね。"

    # say L945 bel
    old "So it means a lot to me that you're willing to help me this way."
    new "だから、あなたがこのように手伝ってくれるって、私にとってはすごく意味があるの。"

    # say L950 pla
    old "I will admit I was very surprised when you asked me to do this."
    new "君がこれをお願いしてきたときは、正直驚いたよ。"

    # say L952 pla
    old "But you're a very good friend, and if this is important for you, then I'm happy to help you."
    new "でも君は大切な友達で、これが君にとって重要なら、喜んで手伝うよ。"

    # say L955 bel
    old "Now, we should go to my room."
    new "それじゃ、私の部屋に行こう。"

    # say L976 bel
    old "Now, before we start, I have to change. Wait here a minute."
    new "それじゃ、始める前に着替える必要があるの。ちょっと待ってて。"

    # say L994 bel
    old "What are you making that face for?"
    new "何そんな顔してるの？"

    # say L997 pla
    old "Oh, n- nothing, you just..."
    new "あ、な-何も、君がただ...予想外だったよ。"

    # say L1001 pla
    old "I- I wasn't expecting it."
    new "僕は予想していなかったよ。"

    # say L1002 bel
    old "Well... thank you."
    new "まあ...ありがとう。"

    # say L1003 bel
    old "So, I'll start with the stream, and let you know when to come into frame, ok?"
    new "じゃあ、配信を始めるから、フレームに入るタイミングを教えてね、いい？"

    # say L1005 pla
    old "Right, sure."
    new "うん、わかった。ベル、よろしくな。"

    # say L1020 bel
    old "Ok guys!"
    new "オッケー、みんな！"

    # say L1021 bel
    old "Hello! Are you all ready for a new session?"
    new "こんにちは！みんな準備できてる？"

    # say L1022 bel
    old "I've missed you guys!"
    new "みんな、会えて嬉しいわ！"

    # say L1023 bel
    old "Yes, I know I didn't stream the other day when I told you I would."
    new "うん、前日に配信するって約束したんだけどね。"

    # say L1024 bel
    old "But something came up, and it became impossible to start the stream."
    new "でも、用事ができて、配信を始めるのが不可能になっちゃったの。"

    # say L1025 bel
    old "But I'm going to make it up to you guys!"
    new "でも、その分皆さんに补偿するつもりだから！"

    # say L1026 bel
    old "As I promised you, I have a big surprise today!"
    new "約束した通り、今日は大きなサプライズがあるの！"

    # say L1027 bel
    old "This is something a lot of you have been asking me about!"
    new "これは皆さんからよく聞かれてたことなの！"

    # say L1028 bel
    old "So I decided to treat you!"
    new "だから皆に Treat する事に決めたの！"

    # say L1029 bel
    old "This is my first time doing something like this on camera. So I'm a little nervous."
    new "これはカメラの前でこんなことするの初めてだから、ちょっと緊張してるの。"

    # say L1030 bel
    old "But I bet that if you show me your support by tipping, I'll feel a lot better."
    new "でも、もしチップで応援してくれるなら、ずいぶん楽しくなるわ。"

    # say L1031 bel
    old "Now, do you want to see the surprise I have in store for you?"
    new "それじゃ、私が用意したサプライズを見たい？"

    # say L1033 bel
    old "This person is a very good friend of mine. And he's very excited to be joining me here in the stream today!"
    new "この人は私のとても良い友達です。そして彼は今日、配信に参加できてとても興奮しています！"

    # say L1034 bel
    old "Say hi to him!"
    new "彼に挨拶してね！"

    # say L1039 bel
    old "Everyone, my friend is here because I promised you that you would see me having some fun with a real dick!"
    new "皆さん、私の友達がここにいるのは、皆に本物のちんこで遊ぶところを見せるって約束したからよ！"

    # say L1040 bel
    old "And he came to help me with it."
    new "そして彼が手伝いに来てくれたの。"

    # say L1041 bel
    old "Why don't we see what he's hiding under these shorts then?"
    new "じゃあ、ショーツの下に何隠してるのか見せてもらおうか？"

    # say L1049 bel
    old "Oh my god! Look at how big it is!"
    new "神様！これの大きさを見て！"

    # say L1050 bel
    old "I bet you want to see me play with this big dick, right?"
    new "あなたがこの大きなちんこをいじりたくてしょうがないんでしょ？"

    # say L1051 bel
    old "You want me to care for it, and play with it, don't you?"
    new "あなたがこれを大事にしたいと思ってるんでしょ？触ってあげたくてしょうがないんでしょ？"

    # say L1052 bel
    old "Let's not wait anymore for it then!"
    new "それじゃあもう待たせないわ！"

    # say L1059 bel
    old "Oh! You have been waiting to see me play with your dick, haven't you?"
    new "あら！あなた、私の手であなたの大きなちんぽをいじるのを待ってたんでしょ？"

    # say L1060 bel
    old "I bet you love the way I stroke your big, thick, dick!"
    new "あなたの大きくて太いおちんちんをなでるの、大好きよね！"

    # say L1072 bel
    old "I knew you were going to love what I had in store for you!"
    new "あなたが私の用意したことを気に入ると思っていたわ！"

    # say L1073 bel
    old "Thanks a lot for accomplishing the goals!"
    new "ありがとう、目標を達成してくれて！"

    # say L1074 bel
    old "You guys have made me very happy!"
    new "みんながくれた幸せ、本当に感謝してる！"

    # say L1075 bel
    old "Now, sadly is time for me to disconnect, but be sure I'll come back soon."
    new "さあ、残念ながらDisconnectの時間だけど、またすぐに戻ってくるからね。"

    # say L1076 bel
    old "And, of course, my friend will be here, accompanying us once again."
    new "もちろん、私の友達もまた一緒にいられるわよ。"

    # say L1077 bel
    old "Don't forget to subscribe to the stream!"
    new "ストリームに登録忘れないでね！"

    # say L1078 bel
    old "So you will get a notification the next time I'm online guys!"
    new "次にオンラインになったときに通知が届くからね！"

    # say L1079 bel
    old "And of course, don't forget to check all my socials!"
    new "もちろん、私のソーシャルメディアもチェックしてね！"

    # say L1080 bel
    old "Thanks a lot guys!"
    new "ありがとうね、みんな！"

    # say L1081 bel
    old "See you soon..."
    new "またすぐね..."

    # say L1091 bel
    old "It's amazing how many tips we got!"
    new "すごいね、こんなにたくさんのアドバイスが集まった！"

    # say L1092 bel
    old "I already thought that we were going to do well because my fans had never seen me doing something like this."
    new "ファンがこんなことを見たことがないから、うまくいくと思っていたけど、これほどとは思わなかったよ。"

    # say L1094 bel
    old "But this is far more than I expected!"
    new "でもこれほどまでとは思ってなかった！"

    # say L1095 bel
    old "They really came through with the tipping!"
    new "チップで盛り上がってくれたみんな、本当にありがとう！"

    # say L1096 bel
    old "We reached the goal in no time!"
    new "目標すぐ達成したわ！"

    # say L1098 pla
    old "I'm very happy that it all came out better than you expected Belle."
    new "ベル、君の予想以上にうまくいったんで、とても嬉しいよ。"

    # say L1100 pla
    old "That's very good."
    new "それはとてもいいね。"

    # say L1101 pla
    old "Do you think that with this you'll surpass Lana in the voting?"
    new "この投票でラナを抜くことができると思うか？"

    # say L1102 bel
    old "It's hard to tell, I think I will."
    new "難しいけど、多分そうなるかな。"

    # say L1103 bel
    old "But only temporarily, with this type of thing you never know for certain who's going to win until the end."
    new "でも一時的なものよ、こんなことじゃ最後まで誰が勝つかわからないわ。"

    # say L1105 pla
    old "Does that mean you're going to need my help on another occasion?"
    new "それって、また俺の手助けが必要になるってことなのか？"

    # say L1107 bel
    old "Oh, don't doubt it! This is only the first time you're appearing on camera with me."
    new "Oh、疑わないで！これは君がカメラの前で私と一緒に登場する初めての機会だからよ。"

    # say L1109 bel
    old "And I'm very thankful for that [pla]."
    new "そしてそのことは本当に感謝してる [pla]。"

    # say L1111 pla
    old "Well, I'm happy to help."
    new "まあ、手伝うのは嬉しいけど。"

    # say L1113 bel
    old "Thanks [pla]."
    new "ありがとう [pla]。"

    # say L1123 pla
    old "{i}W- what is she doing here?! Wasn't she going to be out today?!{/i}"
    new "{i}ベル、彼女がここにいるのはどういうことだ？今日出勤しないって言ってなかったか？{/i}"

    # say L1125 bel
    old "{i}I don't know!{/i}"
    new "{i}知らない！{/i}"

    # say L1126 bel
    old "{i}Maybe she had some problems at work or something like that.{/i}"
    new "{i}もしかしたら仕事で何か問題があったのかもしれないね。{/i}"

    # say L1131 pla
    old "{i}You better answer her, or else she's going to come here to see if everything is alright.{i}"
    new "{i}君が答えた方がいいよ、さもないと彼女がここに来て大丈夫か確認するだろうからな。{i}"

    # say L1134 bel
    old "I'm here mom! I... I was just doing some schoolwork!"
    new "ここにいます、ママ！ 私……私はただ宿題をやっていただけです！"

    # say L1135 ash
    old "I see honey, ok!"
    new "分かったわ、いいわよ！"

    # say L1137 bel
    old "I think we better get dressed up and get out of here before she comes to check on me and sees us like this."
    new "私たち、着替えて出かけよう。ママが見に来ちゃう前に。"

    # say L1138 pla
    old "Yeah, yeah, you're right."
    new "うん、そうかも。"

    # say L1151 ash
    old "Oh [pla], hi, I didn't know you were here."
    new "あら [pla]、こんにちは、ここにいるとは知らなかったの。"

    # say L1152 pla
    old "H- hi, uh... A- Ashley."
    new "あ、あー… アシュレイ。"

    # say L1154 ash
    old "It's good seeing you again dear."
    new "また会えて嬉しいわ、親愛なる。"

    # say L1155 ash
    old "Are you guys working on that school work you told me about?"
    new "みんな、その学校の宿題やってるの？"

    # say L1157 pla
    old "Uh... y- yeah, t- that's right."
    new "うーん… うん、そうさ。"

    # say L1160 bel
    old "What are you doing home mom? I thought you had that important meeting you had talked about."
    new "お母さん、どうして家にいるの？重要な会議があったって言ってたじゃない。"

    # say L1163 ash
    old "Oh honey, you won't believe what just happened!"
    new "お honey、信じられないことが起きたの！"

    # say L1166 ash
    old "Today was supposed to be my first planning meeting with my team."
    new "今日が私のチームとの最初の計画会議だったの。"

    # say L1167 ash
    old "You know, so we could make a marketing plan to show our clients."
    new "そう、クライアントに見せるマーケティングプランを作ろうと思ってたの。"

    # say L1170 ash
    old "But the web developer I had hired suddenly backed out of the deal!"
    new "でも、私が雇っていたウェブ開発者が突然契約を破棄しちゃったの！"

    # say L1173 ash
    old "Apparently he got a better job offer, and decided to take it."
    new "どうやら彼はもっと良い仕事のオファーを受けたようで、それを選んだらしい。"

    # say L1174 ash
    old "But he didn't even give me a heads up or anything, he just bailed without notice!"
    new "でも彼は全く何も教えてくれなかったの、突然に辞めちゃったんだよ！"

    # say L1176 ash
    old "What am I going to do now?"
    new "今からどうするの？"

    # say L1177 bel
    old "Can't you just replace him, mom? I'm sure there must be someone out there that you can hire."
    new "代わりの人を雇えばいいんじゃない、ママ？きっとどこかに雇える人がいるはずよ。"

    # say L1179 ash
    old "If it was that easy I wouldn't have a problem."
    new "そんなに簡単なら問題にならないわ。"

    # say L1180 ash
    old "Getting that web developer wasn't easy."
    new "そのウェブ開発者を見つけるのって簡単じゃなかったのさ。"

    # say L1182 ash
    old "You know my firm is only setting up here in town, so we can't actually offer anybody long-term contracts."
    new "知ってるよね、私の会社はまだこの町で立ち上げ段階だから、長期契約を提供できないんだ。"

    # say L1184 ash
    old "Finding somebody qualified that's willing to freelance for a while is very hard."
    new "適切な資格を持ちながら、しばらくフリーランスで働いてくれる人を見つけるのは本当に難しい。"

    # say L1185 ash
    old "But we already took the commission, and my bosses are expecting me to show them a marketing plan soon!"
    new "でも私たちはすでに契約を受けていて、ボスたちは近々マーケティングプランを見せてほしいって言ってるの！"

    # say L1187 ash
    old "Tell me dear, do you know of anybody that could help me?"
    new "親愛なる君、誰か手伝ってくれる人がいる？"

    # say L1188 bel
    old "Me? Why would I happen to know someone who is a web developer?"
    new "私？なぜ私にウェブ開発者の知り合いがいるっていうの？"

    # say L1190 ash
    old "I don't know, maybe someone from your school?"
    new "知らないわ、もしかしたら君の学校の人かもしれないけど。"

    # say L1192 bel
    old "Well, I'm sorry to disappoint you, mom, but I don't know any web developers..."
    new "まあ、がっかりさせるのはごめんだけど、ママ、私ウェブ開発者なんて知らないの..."

    # say L1194 ash
    old "I see... that's disappointing."
    new "そうね…残念だわ。"

    # say L1207 bel
    old "MOM! What are you talking about? Don't rope him into this!"
    new "ママ！何言ってるの？彼を巻き込まないでよ！"

    # say L1209 ash
    old "Well honey, I'm sorry if you don't like me asking your friend for help."
    new "WELL、ハニー、君の友達に手伝ってもらうだけなのに、そんなに嫌がられると残念だな。"

    # say L1212 ash
    old "But I'm in a very thought spot right now, I need whatever help I can get."
    new "でも今、私にとってとても難しい状況で、どんな助けでも必要なの。"

    # say L1214 ash
    old "So, do you know of anybody that could help me [pla]?"
    new "じゃあ、誰か手伝ってくれる人いる？ [pla]？"

    # say L1217 pla
    old "Well... Actually, I- I think that... Maybe I could help"
    new "まあ…… 実は、俺が少し手伝えるかもしれないんだけど……"

    # say L1219 ash
    old "Really? Are you a web developer?"
    new "本気で？あなたウェブ開発者？"

    # say L1222 pla
    old "Well, I'm not a professional, but I have a little bit of experience."
    new "プロじゃねえけど、ちょっと経験はあるぜ。"

    # say L1224 pla
    old "My [sisrel] has an online clothing store."
    new "俺の [sisrel] はオンラインの服屋さんをやってるんだ。"

    # say L1226 pla
    old "When she was getting started I was the one who set up the e-commerce for her."
    new "彼女が始めた頃、俺がECサイトをセットアップしたんだ。"

    # say L1227 pla
    old "And... I have been doing the maintenance ever since."
    new "そして…そのメンテナンスをずっとやってきたんだ。"

    # say L1230 ash
    old "And you think you could help me with this?"
    new "そして、これについて手伝ってくれるかな？"

    # say L1232 pla
    old "W- well, I think so, I would have to see first what it is that you need me to do, though."
    new "うーん、そう思えるけど、まずは君が何を手伝ってほしいのか見てみないとね。"

    # say L1234 ash
    old "That's wonderful [pla]! Oh my God! I would love it if you could help me."
    new "それは素晴らしい [pla]！神様！あなたが手伝ってくれたら嬉しいな。"

    # say L1236 ash
    old "Maybe asking you to do the whole website right now would be too much."
    new "今すぐ全部のウェブサイトをやってもらうのは無理かもしれないけど。"

    # say L1238 ash
    old "But I think you could help me with the planning of it, while I find a web developer to hire."
    new "でも、計画の部分は手伝ってくれる？ウェブ開発者を見つけるまでの間だけだから。"

    # say L1240 ash
    old "It would only be a few times that I would need your help with the planning."
    new "Planningの手伝いを数回だけお願いすればいいだけよ。"

    # say L1242 pla
    old "Hmm... Sure, I think I could do that."
    new "うーん…いいよ、手伝えると思う。"

    # say L1244 ash
    old "That's great!"
    new "それは良かった！"

    # say L1245 ash
    old "And don't worry, I'll make sure you get properly compensated for it. I can add the cost to the budget."
    new "心配しないで、ちゃんとした補償するようにするから。予算に追加するよ。"

    # say L1246 ash
    old "So, there shouldn't be any problem with your pay."
    new "じゃあ、あなたの給料には問題ないね。"

    # say L1248 pla
    old "I- I see... So, s- should I come to your office later?"
    new "あー、そうか… じゃ、後で君のオフィスにいっていいのかな？"

    # say L1250 ash
    old "Actually, I'm not sure if that would be a good idea because I wouldn't want the firm's directors to know about this."
    new "実は、それをやると良いかどうかわからないの。会社の役員たちに知られたくはないから。"

    # say L1252 ash
    old "I think it's better if we just work here at home."
    new "家で働いた方がいいと思う。"

    # say L1257 ash
    old "You're really helping me with this [pla], a lot! You have no idea about how useful you're being!"
    new "あなたがどれだけ助けてくれてるか、本当に感謝してるの！[pla]"

    # say L1258 ash
    old "Now, I left some documents that you'll need in the office, I'll go and grab them."
    new "じゃあ、必要な書類を置いてきちゃったから、オフィスに行って取りにくるね。"

    # say L1259 ash
    old "But don't worry, we won't be starting right away, you can come back on another occasion and I'll let you know what the job is about."
    new "でも心配しないで、すぐに始めるわけじゃないから。また別の日に来て、そのときに仕事の内容を教えてあげるから。"

    # say L1261 pla
    old "Alright, I'll be sure to do it."
    new "わかった、ちゃんとやるよ。"

    # say L1262 ash
    old "Great, see you later then [pla]."
    new "じゃあ、またね [pla]。"

    # say L1270 bel
    old "I can't believe you're actually going to help her with that."
    new "本当になんて、あなたが彼女を助けるなんて信じられない。"

    # say L1272 bel
    old "Don't you think that's going to get in the way of us doing the stream?"
    new "それって私たちの配信の邪魔にならないの？"

    # say L1274 pla
    old "In fact, I think it's convenient for us because since she needs me to work here, we'll know more accurately when she will be here and when she won't."
    new "実際、彼女が必要とする時間だから、ここにいる時間を正確に把握できて便利だと思うよ。"

    # say L1277 bel
    old "But still, I'm sorry my mom is putting you up to this."
    new "でも、母が君にこんなことさせてごめんね。"

    # say L1279 pla
    old "Don't worry about it, I'm happy to help."
    new "心配するな、手伝うのは全然問題ないよ。"

    # say L1280 bel
    old "Yeah, I know."
    new "うん、そうね。"

    # say L1281 bel
    old "You're being very nice helping both my mom and me like this."
    new "あなたがこんなに優しくて、私とママの手伝いをありがとう。"

    # say L1282 bel
    old "That's very good of you [pla]."
    new "それはとても優しいね[pla]。"

    # say L1284 pla
    old "Thanks for saying that."
    new "ありがとうって言ってくれてさ。"

    # say L1291 pla
    old "Hey, so I think I should get going, after all, we just finished streaming, I bet you want to take a shower or something."
    new "Hey、そういえば帰るかな。配信も終わったし、シャワー浴びたいとか思ってるだろう？"

    # say L1293 bel
    old "Uhh, yeah, sure, I'll let you know when we have to stream the next time, thanks again [pla]."
    new "うーん、そうね、次ストリームするときには教えてあげるから、またありがとう [pla]。"

    # say L1295 pla
    old "Sure, see you later, bye."
    new "じゃあ、またね、さよなら。"

    # say L1325 bel
    old "Hi [pla]! I have great news!"
    new "こんにちは [pla]！いい知らせがあるの！"

    # say L1328 bel
    old "The poll results from yesterday came out this morning!"
    new "昨日の投票結果が今朝出ました！"

    # say L1332 bel
    old "I'm number one now!"
    new "今一位になったの！"

    # say L1334 pla
    old "That's great belle!"
    new "ベル、それは凄いな！"

    # say L1335 pla
    old "I'm very happy for you."
    new "君のことが本当に嬉しいよ。"

    # say L1337 bel
    old "Thanks, this is wonderful!"
    new "ありがとう、これは素晴らしいよ！"

    # say L1339 bel
    old "She's been appearing with a guy on stream for longer, so I didn't know if I would be able to catch her with just one stream."
    new "彼女は最近ストリームで男の子と長時間一緒にいることが多いから、一つのストリームだけじゃ彼女を捕まえることができるかわからなかったの。"

    # say L1341 bel
    old "But my fans really liked it!"
    new "でもファンの皆さん本当に喜んでくれたの！"

    # say L1343 bel
    old "If we keep going like this, she won't have any chance of catching me!"
    new "この調子で続けたら、彼女は絶対に追いつかないわ！"

    # say L1345 pla
    old "That sounds great."
    new "それはいいね。"

    # say L1348 pla
    old "So, when it's the next stream?"
    new "じゃあ、次の配信はいつだ？"

    # say L1349 bel
    old "Well, that's where we have a little bit of a problem."
    new "まあ、そこがちょっと問題があるのね。"

    # say L1350 pla
    old "Why? What happened?"
    new "なんで？何があったんだ？"

    # say L1352 bel
    old "You see, I had already thought about what we're going to do next."
    new "ね、実は次に何をするかすでに考えていたのよ。"

    # say L1353 bel
    old "My fans have been asking for me to do cosplay for a while, so I thought now it would be a good occasion."
    new "ファンからコスプレをやってほしいって要望が多かったから、今がいい機会だと思ったの。"

    # say L1354 pla
    old "Cosplay?"
    new "コスプレ？"

    # say L1356 bel
    old "Yes, we can't just repeat the same as last time."
    new "うん、同じことを繰り返すわけにはいかないわ。"

    # say L1357 bel
    old "If we just do the same thing over and over the audience will get bored."
    new "同じことばかりやってると、観客は飽きちゃうわ。"

    # say L1358 bel
    old "We have to give them some variety."
    new "バリエーションを提供しないといけないよね。"

    # say L1362 bel
    old "But you see, I don't know when the next stream will be."
    new "でもね、次の配信がいつになるかわからないの。"

    # say L1363 bel
    old "I already know what character I want to do."
    new "もう決めてるの。"

    # say L1364 bel
    old "It's somewhat of an interesting character, and my fans seem to have a fixation for that type of girl."
    new "そのキャラクターはちょっと面白いし、私のファンもそんなタイプの女の子にハマってるみたい。"

    # say L1365 bel
    old "So I wanted to please them, I even ordered for the cosplay to be delivered by express shipping."
    new "だからファンのために喜んでもらおうと思って、コスプレを急送で注文したの。"

    # say L1367 bel
    old "But it turns out there was a mixup when I placed my order, when I bought it they had alredy sold it!"
    new "でも注文したときに間違えて、買った時にはすでに売れていたの！"

    # say L1368 bel
    old "And they don't seem to have any more!"
    new "もうないみたい！"

    # say L1370 bel
    old "I have been looking for that same cosplay in other websites, but I can't find it!"
    new "他のサイトでもそのコスプレを探したけど、見つからないの！"

    # say L1371 bel
    old "And I already promised the audience that's the character I was going to do."
    new "そして、すでに観客にそのキャラクターをやることを約束しちゃってるの。"

    # say L1372 bel
    old "I guess we'll have to postpone it for another time."
    new "そうね、また今度にしようか。"

    # say L1374 bel
    old "Besides, you also have to go help my mom with that website thing..."
    new "それに、あなたも私のママがやってるウェブサイトの手伝いに行かなきゃいけないし…"

    # say L1376 bel
    old "Ugh, this annoys me so much, Lana's going to overtake me again!"
    new "うーん、これ本当にイライラするわ、またランナに抜かれるかもしれないって！"

    # say L1378 pla
    old "Hmm, I might be able to do something about that. My [sisRel] has her own clothing store."
    new "Hmm、それなら何かできるかもしれないな。俺の [sisRel] は自分の服屋やってるから。"

    # say L1380 pla
    old "So, I think maybe she can find that cosplay for you in time for the next stream."
    new "じゃあ、次の配信までにそのコスプレを見つけてくれるかもしれないな。"

    # say L1382 bel
    old "Really? Oh [pla] that would be great!"
    new "本当に？あたしのコスプレが間に合ったら、[pla]最高だね！"

    # say L1384 pla
    old "Well, it's not certain, I'll have to ask, but I think it's possible."
    new "まあ、確実じゃないけど、聞いてみるよ。多分できるかもな。"

    # say L1385 bel
    old "If you could, that would be wonderful."
    new "もしできたら、本当に嬉しいな。"

    # say L1386 pla
    old "I'll ask with my [sisRel] this afternoon, after classes."
    new "今日の授業が終わってから、俺の[sisRel]で聞いてみるよ。"

    # say L1387 pla
    old "And I'll let you know."
    new "そして結果を教えてあげるよ。"

    # say L1388 bel
    old "Sure, thanks a lot [pla]."
    new "うん、ありがとう[pla]。"

    # say L1391 pla
    old "For now let's go to class."
    new "じゃあ、まずは授業に行こうか。"

    # say L1412 pla
    old "Hi [sis], how are you?"
    new "おっ [sis]、調子はどう？"

    # say L1413 sis
    old "I'm doing pretty well, working on a new collection."
    new "調子はいいわ、新しいコレクションを作ってるの。"

    # say L1414 pla
    old "Uhh, so are you busy?"
    new "うーん、忙しいの？"

    # say L1415 sis
    old "Uhh a little bit, Why? What do you need?"
    new "うーん、ちょっとね。どうしたの？何か用？"

    # say L1417 pla
    old "Well, I was wondering if you could help me with getting a cosplay."
    new "まあ、君にコスプレの手伝いを頼もうかなって思ってさ。"

    # say L1418 sis
    old "A cosplay? I didn't know you were into that kind of stuff..."
    new "コスプレ？そんなこと興味あると思ってなかったけど..."

    # say L1421 sis
    old "Anyway, what kind of cosplay is it? Like a superhero or something?"
    new "どんなコスプレなの？ スーパーヒーローとか？"

    # say L1423 pla
    old "Uhh, it's actually a female cosplay, it's a famous character from a videogame."
    new "うーん、実は女キャラのコスプレなんだ。有名なゲームのキャラさ。"

    # say L1424 sis
    old "A female cosplay? Why do you need that?"
    new "女性のコスプレ？なぜそれを必要とするの？"

    # say L1426 sis
    old "Don't tell me you're thinking of becoming a drag queen."
    new "まさかドラクイーンになろうとしてるわけじゃないでしょ。"

    # say L1428 pla
    old "W- what? Of course not!"
    new "な、何言ってんの？もちろんそんなつもりはないよ！"

    # say L1430 pla
    old "It's for a friend of mine that needs it."
    new "友達が必要だって言うからだよ。"

    # say L1432 sis
    old "Oh! Is that so? And why are you getting it for her? Are you two doing something naughty?"
    new "Oh！そうなの？でも、彼女のために何をするの？二人で何か Naughty なことをしているの？"

    # say L1434 pla
    old "N- no, we're not, I'm just doing her a favor because she needs it. That's all."
    new "な、ないよ、ただ彼女が欲しがってるものを手伝ってるだけだ。それだけだよ。"

    # say L1436 sis
    old "Haha! Relax, I'm just messing with you."
    new "ははは！落ち着いて、からかってるだけよ。"

    # say L1438 sis
    old "I don't mind what you're doing with your friend."
    new "友達と何をやっててもいいよ、気にしないから。"

    # say L1439 sis
    old "As long as you keep helping me with my business, you can do whatever you want."
    new "ビジネスを手伝ってくれるなら、何をしてもいいよ。"

    # say L1441 sis
    old "I'll get you the cosplay, it should be easy to get it here soon."
    new "コスプレはすぐ手に入ると思うから、大丈夫よ。"

    # say L1442 pla
    old "Thanks a lot [sis]!"
    new "ありがとうな、[sis]！"

    # say L1444 sis
    old "I'm happy to help."
    new "手伝うのが嬉しいわ。"

    # say L1445 sis
    old "I'll let you know when it's ready."
    new "準備ができたら教えてあげるね。"

    # say L1469 ash
    old "Hello [pla]! How are you dear?"
    new "こんにちは[pla]！元気にしてる？亲爱的。"

    # say L1470 pla
    old "Hi Mrs. Ash-"
    new "ただのアシュリーでいいよ"

    # say L1472 ash
    old "Just Ashley dear, remember what I told you, no need for the Mrs."
    new "ただのアシュリーでいいの、覚えててね、Mrs. はいらないの。"

    # say L1473 pla
    old "Uhh... Right."
    new "うーん… そうだね。"

    # say L1474 pla
    old "Hi A- Ashley."
    new "Hey アシュリー。"

    # say L1476 ash
    old "That's better."
    new "そうね、それの方が良いわ。"

    # say L1477 ash
    old "How have you been honey?"
    new "ハニー、元気にしてた？"

    # say L1479 ash
    old "Is school going well?"
    new "学校は順調？"

    # say L1481 pla
    old "Uhh? Y- yeah. I- I have been studying a lot..."
    new "うーん？ よ、よし。あ、あたしは勉強ばっかりしてるんだ…"

    # say L1482 ash
    old "That's great dear."
    new "それは良かったわね。"

    # say L1484 pla
    old "Uh... Listen, A- Ashley, about the w- website."
    new "うーん… アシュレイ、あのさ、ウェブサイトについての話なんだけど。"

    # say L1486 ash
    old "Right! We should focus on that."
    new "そうだね！ それ concentrate すべきだ。"

    # say L1488 pla
    old "Sure ma'am. But I'm not entirely sure what it is that I will be doing."
    new "もちろん、でも具体的に何をすればいいのかまだよくわかんないんだ。"

    # say L1490 ash
    old "Well, before that, I would like to see the e-commerce site you told me you made for your [sisrel]."
    new "それよりも、あなたが作ってくれたって言った[sisrel]のECサイトを見せてほしいな。"

    # say L1493 pla
    old "Uh... Sure, no problem."
    new "うーん…いいよ、問題ない。"

    # say L1503 pla
    old "So, this is the site where you can see the apparel that my [sisrel] sells."
    new "じゃあ、これが俺の [sisrel] が売ってる服を見られるサイトだよ。"

    # say L1504 pla
    old "And if you click here you can place an order."
    new "そして、ここをクリックすると注文できます。"

    # say L1505 pla
    old "Then, it will take you to the payment portal. And there you can finalize the purchase."
    new "じゃあ、そこから決済ページに移動するんだ。そしてそこで購入手続きを完了できる。"

    # say L1507 ash
    old "You know [pla]? This is very good."
    new "知ってる [pla]？これ、かなりいいよ。"

    # say L1508 ash
    old "This is very high quality, even better than the work some of the developers I've worked with before."
    new "これは本当に高品質で、私がこれまで一緒に働いた開発者の作品よりも上だよ。"

    # say L1509 ash
    old "Actually, this is more than what I need you to do."
    new "実は、これ以上やってほしいの。"

    # say L1512 ash
    old "After seeing this, I'm thinking that you could just take the full job of developing the website for the client."
    new "これを見て、あなたがクライアントのウェブサイト開発の全てを任されるんじゃないかって思ってるの。"

    # say L1516 ash
    old "Come on, why are you surprised? You did a very good job with this website."
    new "Surpriseして何なの？ あなた、このウェブサイトで素晴らしい仕事をしたじゃない。"

    # say L1518 ash
    old "And as I told you, this is even more than what I need to be done for the marketing campaign."
    new "そして私が言った通り、これでマーケティングキャンペーンに必要な以上のことが済むんだから。"

    # say L1519 ash
    old "You could just do the job by yourself."
    new "自分でやってくれればいいのに。"

    # say L1521 ash
    old "And It would really help me, because I wouldn't have to look for someone to finish the project."
    new "それが本当に私にとって役立つわ、プロジェクトを完成させるために他の人を探す必要がなくなるから。"

    # say L1522 pla
    old "I mean, that's a very nice offer, uh... Ashley, b- but I'm not sure if I have the experience to do it."
    new "つまり、それはとても親切な申し出だよ、アッシュリー。でも経験が足りないかもしれないな。"

    # say L1523 pla
    old "It would be a lot of responsability."
    new "それはかなりの責任だな。"

    # say L1525 ash
    old "Don't worry about it, dear. I'll accompany you every time you work on it, so I'll tell you exactly what I need from you."
    new "心配しないで、亲爱的。あなたが作業するたびに私が一緒だから、私が必要とするものを正確に教えてあげるから。"

    # say L1529 pla
    old "Alright, if you think it's ok for me to do it, I guess I can take the job."
    new "分かった、君がいいって言うなら、仕事受けようかな。"

    # say L1531 ash
    old "Great! That's just what I wanted to hear."
    new "素晴らしい！そう言ってくれて嬉しいわ。"

    # say L1533 pla
    old "Ok, but what exactly is the type of website that I'm going to be working on? Is it an e-commerce?"
    new "分かったけど、具体的にどんなサイトなのか教えてくれ。ECサイトなのか？"

    # say L1534 ash
    old "Not really, what I need you to make is one where we can show a lot of information about a business."
    new "そうじゃなくて、私が欲しているのはビジネスに関する情報をたくさん掲載できるサイトだよ。"

    # say L1535 ash
    old "The business in question is an organic coffee shop that's gotten very popular here in the city."
    new "そのビジネスは、この街で大人気のオーガニックコーヒー店なんだ。"

    # say L1536 ash
    old "And they're looking to expand their business by franchising outside of town."
    new "そして町外れでのフランチャイズ展開を目指して、事業を拡大したいんだ。"

    # say L1537 pla
    old "I see. So they hired you to do their marketing campaign?"
    new "なるほど。つまり君のマーケティング会社がそのキャンペーンを担当することになったのか？"

    # say L1539 ash
    old "Not me, my marketing firm. I'm just leading my team."
    new "私じゃなくて、私のマーケティング会社よ。私はチームをリードしてるだけ。"

    # say L1541 ash
    old "But, I still have the responsibility for the entire marketing plan."
    new "でも、全体のマーケティング計画の責任は私にあるの。"

    # say L1543 ash
    old "Because the clients already paid for the service, and I already received the budget."
    new "クライアントはすでにサービス代金を支払い、私はすでに予算を受け取っています。"

    # say L1545 ash
    old "That's why it's so bad that the web developer quit all of a sudden. Because he put me in a very difficult position."
    new "だからウェブ開発者が突然辞めたのが最悪なんだ。彼がいなくなって、私にとってはかなり難しい立場になっちゃったから。"

    # say L1547 pla
    old "I understand, I'm sorry that happened."
    new "分かってる、そんなことになっちゃって申し訳ない。"

    # say L1549 ash
    old "That's very nice of you dear, thank you."
    new "それはとても優しいわ、ありがとう。"

    # say L1550 ash
    old "Now, why don't we get started and I'll tell you what to do along the way?"
    new "それじゃ、始めようか。途中で何をすればいいか教えてあげるから。"

    # say L1562 ash
    old "Ok, now please put the title in higher case."
    new "では、タイトルを大文字にしてください。"

    # say L1564 ash
    old "That's it, perfect. Could you also make those pictures a little bigger?"
    new "それがいい、完璧だね。あの写真もちょっと大きくしてもらえる？"

    # say L1565 ash
    old "I want the raw coffee shots to be front and center."
    new "生豆のショットを前面に出してほしいの。"

    # say L1567 pla
    old "Ok, is that because of their brand?"
    new "ああ、そのブランドのためか？"

    # say L1569 ash
    old "That's right, they want to show themselves as an organic coffee business, that's a contrast to the bigger coffee chains you see everywhere."
    new "そうです、彼らは有機コーヒーの企業として自分たちをアピールしたいんだ。大きなチェーン店とは対照的にね。"

    # say L1570 pla
    old "I see, I think I get it."
    new "なるほど、わかったような気がする。"

    # say L1574 ash
    old "Well, the whole point of marketing is developing and delivering the message the client wants to show."
    new "Marketingの本質は、クライアントが見せたいメッセージを開発して伝えることだね。"

    # say L1575 ash
    old "So, I really enjoy the process of using optics and messaging to find good ways to attract attention to our clients."
    new "だから、オプティクスとメッセージングを使って、クライアントに注目を集めるいい方法を見つけるプロセスがすごく楽しいの。"

    # say L1576 pla
    old "That's really cool Ashley."
    new "それは本当にクールだな、アシュリー。"

    # say L1577 ash
    old "Thanks dear..."
    new "ありがとう、親愛なる..."

    # say L1578 ash
    old "Now, let's keep going."
    new "それじゃ、続けていこう。"

    # say L1590 ash
    old "Yes! That's exactly what I wanted!"
    new "はい！それがまさに私が欲しかったものよ！"

    # say L1591 ash
    old "You're really good at this [pla], I can't believe you thought you wouldn't do it properly."
    new "あなた、これ本当に上手だね [pla]、うまくやれないなんて思ってたなんて信じられない。"

    # say L1593 pla
    old "T- Thank you, Ashley, I hope your bosses will like it too."
    new "ありがとう、アシュリー。ボスたちにも気に入ってくれるといいな。"

    # say L1594 ash
    old "I'm sure they will, this is turning out better than what I expected."
    new "きっと喜んでもらえるよ、これ比我の予想以上に上手くいってるから。"

    # say L1595 ash
    old "Actually, I think you've done enough for today."
    new "実際、今日の分だけで十分だと思うよ。"

    # say L1596 ash
    old "Why don't we stop and continue another day?"
    new "今日はここまでにして、また明日続けようよ。"

    # say L1605 ash
    old "You're very good at this [pla], I think that with your help we will have this ready in no time."
    new "あなたは本当にこれ上手だね、[pla]。あなたの手伝いがあればすぐに完成しそうだよ。"

    # say L1606 pla
    old "Thanks ma'am, I'm sure we will."
    new "ありがとう、きっとそうなるな。"

    # say L1608 pla
    old "So, I- I guess I should leave for know."
    new "じゃあ、俺はもう帰るよ。"

    # say L1610 ash
    old "Wait, before you go, I wanted to ask you about how much time you have available to work on this."
    new "待って、行っちゃう前に、このプロジェクトにどれくらいの時間を使えるか教えて欲しかったの。"

    # say L1612 ash
    old "You're a student after all. I wouldn't want to use all of your time."
    new "あなたは学生だものね。全部の時間を使っちゃうのは申し訳ないと思ってるの。"

    # say L1613 ash
    old "But if I'm honest, I could use your help as often as possible."
    new "でも正直に言うと、できるだけあなたの手助けがほしいの。"

    # say L1615 ash
    old "So, it occurs to me that you could tell me when it works best for you."
    new "そういえば、あなたが都合のいい時間っていつか教えてくれたらいいな。"

    # say L1616 ash
    old "For us to work on the website."
    new "私たちがウェブサイトを一緒に作業するため、都合のいい時間教えてくれる？"

    # say L1619 pla
    old "I- I guess I could come... Maybe every other day and work with you?"
    new "俺、隔日なら来られるかもしれないけど、君と一緒に作業できる？"

    # say L1621 ash
    old "That's just perfect for me!"
    new "それが私にとってはぴったりだ！"

    # say L1622 pla
    old "Great, that's good to hear."
    new "良かった、そう聞いて安心した。"

    # say L1623 pla
    old "Alright, it's getting a bit late, so,I think I'll go home now, Ashley."
    new "じゃあ、ちょっと遅いし、俺は帰るよ、アシュリー。"

    # say L1625 ash
    old "Sure dear, thanks again for your great help."
    new "もちろん、またお世話になったわ。"

    # say L1626 pla
    old "You're welcome, see you later."
    new "どうも、またね。"

    # say L1628 ash
    old "See you honey."
    new "またね、ハニー。"

    # say L1649 pla
    old "Hey [sis]."
    new "ねえ、[sis]。"

    # say L1651 sis
    old "Listen, your cosplay has arrived."
    new "ねえ、あなたのコスプレが届いたよ。"

    # say L1653 pla
    old "Really? It arrived this quickly? That's great!"
    new "本当に？そんなに早く届いたの？すごいな！"

    # say L1654 sis
    old "Well, I have a direct contact, and they always send it via express delivery."
    new "直接のコネクションがあるから、いつも速達で送ってくれるの。"

    # say L1655 pla
    old "Oh, that's great."
    new "お、それは良かったな。"

    # say L1656 sis
    old "Come with me, the package is in my bedroom."
    new "一緒に来なさい、荷物は私の寝室にあるの。"

    # say L1657 pla
    old "Oh, right."
    new "ああ、そうか。"

    # say L1672 sis
    old "Wait here."
    new "ここで待ってて。"

    # say L1685 sis
    old "Here it is."
    new "ここだよ。"

    # say L1687 sis
    old "I ordered it directly from a producer."
    new "直接プロデューサーから注文したの。"

    # say L1689 sis
    old "I knew that you needed it quickly, right?"
    new "早く必要だって思ってたでしょ？"

    # say L1693 pla
    old "This is great, thanks a lot."
    new "これって最高だ、ありがとうな。"

    # say L1694 sis
    old "Don't worry about it, I'm happy to help you."
    new "気にしないで、手伝うのが嬉しいから。"

    # say L1695 sis
    old "I hope your friend likes it."
    new "友達が気に入ってくれることを願ってるね。"

    # say L1696 pla
    old "I'm sure she will, thanks [sis]."
    new "きっと喜んでくれるよ、ありがとう[sis]。"

    # say L1709 pla
    old "Hi belle, good morning."
    new "おはようベル、"

    # say L1710 bel
    old "Hi [pla], how are you today?"
    new "おはよう[pla]、今日怎么样？"

    # say L1714 pla
    old "Hey, listen, I got your cosplay!"
    new "Hey、聞いてくれ、君のコスプレ手に入れたぞ！"

    # say L1716 bel
    old "Really? That's wonderful [pla]!"
    new "本当に？それは素晴らしいね、[pla]！"

    # say L1717 pla
    old "Yeah, I received it this morning. Is your mom going to be home this afternoon? If not, I can bring it to your house so you can try it on."
    new "うん、今朝届いたよ。君のママは今日の午後家にいないのか？もしいなかったら、家に持って行って試着できるよ。"

    # say L1719 bel
    old "She won't be, so we can stream today as well!"
    new "ママはいないから、今日も配信できるわ！"

    # say L1721 pla
    old "You want to stream right away?"
    new "今すぐ配信したいの？"

    # say L1722 bel
    old "Of course, we have to."
    new "もちろん、そうしないとね。"

    # say L1724 bel
    old "Lana has been putting up a lot of new content, I can't let any more time pass by."
    new "ランナは新しいコンテンツをどんどんどきょうしているし、もっと時間をおかすわけにはいかないわ。"

    # say L1726 pla
    old "Yeah, you're right, I'll bring the cosplay after classes. Ok?"
    new "そうだな、君が言う通りだ。授業が終わったらコスプレを持ってくるよ。いいか？"

    # say L1727 bel
    old "Yeah, perfect."
    new "うん、ぴったりだね。"

    # say L1753 bel
    old "Ok, so you'll pick up the cosplay at your house and I'll set up the stream. Ok?"
    new "じゃあ、あなたは家でコスプレを持ってきて、私は配信の準備をするね。いい？"

    # say L1754 pla
    old "Sure, I'll be there right away."
    new "わかった、すぐに行くよ。"

    # say L1770 pla
    old "Hey Belle, here it is."
    new "ベール、これだよ。"

    # say L1775 bel
    old "Great! Let's go up to my room and I'll try it on."
    new "グレート！私の部屋に上がって、着替えてみるね。"

    # say L1796 bel
    old "Ok, I'll put it on."
    new "はい、着替えるね。"

    # say L1808 bel
    old "So, what do you think?"
    new "じゃあ、どう思う？"

    # say L1810 pla
    old "You look great Belle!"
    new "ベール、君は gorgeous だな！"

    # say L1811 pla
    old "It really fits you."
    new "本当に似合ってるよ。"

    # say L1812 bel
    old "I'm happy you like it."
    new "嬉しいよ、気に入ってくれて。"

    # say L1813 bel
    old "Let's get started with the stream then."
    new "じゃあ、配信始めましょう。"

    # say L1828 bel
    old "Ok guys, it's time for another good time!"
    new "皆さん、また楽しい時間の始まりです！"

    # say L1829 bel
    old "What do you think of the cosplay that I prepared for you?"
    new "私が準備したコスプレ、どう思う？"

    # say L1830 bel
    old "I know you have been waiting to see me like this, so be sure to enjoy!"
    new "待っててくれたよね、この格好で。だから、楽しんでくださいね！"

    # say L1831 bel
    old "But that's not all."
    new "でもそれだけじゃないわ。"

    # say L1832 bel
    old "Since you guys liked to see my friend so much last time, I brought him here again!"
    new "前回私の友達を見て気に入ったみたいだから、また連れてきたよ！"

    # say L1833 bel
    old "So say hi to him again!"
    new "また挨拶してね！"

    # say L1839 bel
    old "Ok, guys, let's not waste any more time."
    new "みんな、時間浪費しないで、さっさと始めよう。"

    # say L1840 bel
    old "I know you've been waiting for it, so let's get to it."
    new "待ってたよね、だからさっさと始めよう。"

    # say L1847 bel
    old "OH! God! This cock!"
    new "OH！神！このちんこ！"

    # say L1848 bel
    old "I love it! It's just the best taste in the world!"
    new "大好き！世界で一番おいしい味だよ！"

    # say L1849 bel
    old "Your dick is so big guys!"
    new "あなたのちんぽ、めっちゃ大きいわね！"

    # say L1861 bel
    old "I'm happy you enjoyed the stream and my cosplay!"
    new "みんなが配信と私のコスプレを楽しんでくれてうれしいわ！"

    # say L1862 bel
    old "After all, I'm doing this for all of you!"
    new "みんなのためにやってるんだから！"

    # say L1863 bel
    old "I'll end the stream here for now."
    new "では、ここであと暫くストリームを終了するわ。"

    # say L1864 bel
    old "But be sure that I'll come back soon."
    new "でも、すぐに戻ってくるからね。"

    # say L1865 bel
    old "As always, remember to subscribe to the stream."
    new "いつものように、配信の登録をしてね。"

    # say L1866 bel
    old "And you’ll be notified every time I’m online!"
    new "オンラインになるたびに通知が届くよ！"

    # say L1867 bel
    old "And of course, remember to check out my social media links!"
    new "もちろん、私のソーシャルメディアのリンクもチェックしてね！"

    # say L1868 bel
    old "Thans for your support guys!"
    new "皆さん、応援ありがとう！"

    # say L1869 bel
    old "See you later, bye!"
    new "じゃあ、またね！バイバイ！"

    # say L1879 bel
    old "I'm sure that with this, Lana will not have a chance to catch me!"
    new "これでラナには絶対に追いつかれやしないわ！"

    # say L1881 pla
    old "Awesome!"
    new "すごいな！"

    # say L1883 pla
    old "After all you've worked really hard for this."
    new "君の頑張りが報われたね。"

    # say L1887 pla
    old "I think I'll head back home before your mother arrives."
    new "じゃあ、お母さんが来る前に家に戻るよ。"

    # say L1888 bel
    old "Alright, I'll let you know how the voting goes tomorrow."
    new "明日、投票の結果を教えてあげるね。"

    # say L1889 pla
    old "Sure, I'm sure it's going to go great."
    new "うん、きっと上手くいくさ。"

    # say L1906 pla
    old "Hi, Ashley, I'm fine thank you."
    new "Hey、アシュリー、元気だよ、ありがとう。"

    # say L1907 ash
    old "That's good, tell me, is there anything I can help you with?"
    new "それは良いわ、何か手伝えることはある？"

    # say L1915 pla
    old "Well, I was thinking that I could keep helping you with developing the website."
    new "まあ、ウェブサイトの開発を手伝い続けられるんじゃないかって思ってたんだ。"

    # say L1916 ash
    old "That would be great [pla]!"
    new "それは最高だ [pla]！"

    # say L1917 ash
    old "Ok, wait here a minute and I'll get everything ready."
    new "待ってて、すぐ準備するよ。"

    # say L1926 pla
    old "Oh, not much, I was just passing by."
    new "ああ、別に、ただ通りかかっただけだ。"

    # say L1929 ash
    old "Please remember to come work on the website project soon. The deadline is coming soon."
    new "ウェブサイトのプロジェクトのこと忘れないでね。締め切りが近いから。"

    # say L1931 pla
    old "Sure, don't worry I'll keep that in mind."
    new "安心しろ、忘れないから。"

    # say L1933 ash
    old "Thank you [pla], I'll see you later then."
    new "ありがとう、[pla]。じゃあ後でね。"

    # say L1947 ash
    old "Ok, so for today I want us to focus on a new part of the project."
    new "じゃあ、今日のフォーカスはプロジェクトの新しい部分にしようと思うの。"

    # say L1948 pla
    old "Alright, what are we doing?"
    new "よし、何するんだ？"

    # say L1950 ash
    old "Let's get started and I'll explain to you along the way."
    new "始めて、進むうちに説明するから。"

    # say L1967 ash
    old "Ok, Ok, I really like how this turned out."
    new "Ok、Ok、これ本当にいい感じになったね。"

    # say L1968 ash
    old "I think we can move on to the next category."
    new "次カテゴリーに進めると思う。"

    # say L1971 pla
    old "Really? Don't you want to use make any corrections?"
    new "本当に？修正を入れたくならないの？"

    # say L1973 ash
    old "Not right now, because I haven't  seen how it works with other areas of the website."
    new "今はまだ、他の部分でどう動くか見ていないからね。"

    # say L1975 ash
    old "So, let's shift our focus to those, and then we can make any pertinent corrections."
    new "じゃあ、まずはそちらに焦点を当てて、必要なら後で修正を入れましょう。"

    # say L1977 pla
    old "I see, ok, let's do that."
    new "わかった、じゃあそうしよう。"

    # say L1983 ash
    old "Alright [pla], I think that was enough for today. I think we can continue this another time."
    new "そうだね [pla]、今日のところはこれで十分だよ。次回に続きをやろう。"

    # say L1984 ash
    old "Once again, thanks a lot for your help."
    new "またしても、お手伝いありがとう。"

    # say L1985 pla
    old "You're welcome. My pleasure to help you."
    new "どういたしまして。君の役に立てて嬉しいよ。"

    # say L1986 ash
    old "Now, it's a little late, so why don't you go home and rest?"
    new "今ちょっと遅いから、家に帰って休んだ方がいいわよ。"

    # say L1988 pla
    old "Yeah, you're right. See you later Ashley."
    new "うん、そうしよう。またねアシュリー。"

    # say L1989 ash
    old "See you later hon."
    new "またね、亲爱的。"

    # say L2019 pla
    old "Hi Belle, how are you?"
    new "嗨、ベール、元気ですか？"

    # say L2021 pla
    old "What? What's with that expresion?"
    new "何？その表情は何だ？"

    # say L2022 pla
    old "Is there anything wrong?"
    new "どうしたの？何かあったのか？"

    # say L2024 bel
    old "I guess you could say there is."
    new "まあ、あるかもしれないね。"

    # say L2025 bel
    old "I saw the latests results of the poll before I came."
    new "来る前に最新の投票結果を見ちゃったの。"

    # say L2027 bel
    old "And Lana is still on top!"
    new "そしてランナはまだトップなの！"

    # say L2028 pla
    old "She is? But I thought you said that with what we did last time, there was no way she could catch you."
    new "そうなのか？でも前は君が言ってたじゃん、咱らが上次やったことで絶対に彼女には追いつかないって。"

    # say L2030 bel
    old "I know, but you just won't believe what that whore is doing now!"
    new "知ってるけど、今その淫乱が何してるか信じられないわ！"

    # say L2032 bel
    old "She's doing anal!"
    new "彼女、アナルしてるの！"

    # say L2033 bel
    old "I mean, can you believe it?!"
    new "信じられるの？"

    # say L2035 pla
    old "Uhmm, I mean... Is it weird for people to do webcamming?"
    new "うーん、つまり……ウェブカメラでそういうことするの、変な話？"

    # say L2037 bel
    old "For a new model, of course it is... She just started streaming a few weeks ago!"
    new "新しいモデルだから当然よ…彼女は数週間前からストリーミングを始めたばかりなのよ！"

    # say L2039 bel
    old "She hasn't built a fanbase or anything yet, she is crazy!"
    new "ファンベースも何も築けてないのに、彼女は本当に狂ってるわ！"

    # say L2041 bel
    old "Besides, you know what else she did?"
    new "それに、彼女が他に何をしたか知ってる？"

    # say L2043 bel
    old "She just uploaded it as a video to her stream!"
    new "彼女はそれを動画としてストリームにアップロードしちゃったの！"

    # say L2045 bel
    old "Well, she didn't do it live; she just recorded it off-camera and then uploaded it as if it were live..."
    new "まあ、生中継じゃなくて、カメラの外で録画して、それをまるで生放送みたいにアップロードしただけよ..."

    # say L2048 bel
    old "I don't know for certain, but come on, you can tell she did."
    new "確実なことは言えないけど、でもさ、そうだってわかるでしょ？"

    # say L2050 bel
    old "She's not interacting with her chat, answering questions, or anything."
    new "彼女はチャットと絡んで質問に答えてないし、何もしてないよ。"

    # say L2051 bel
    old "She's just doing it and that's it."
    new "彼女はただやってるだけだよ。"

    # say L2053 bel
    old "It's clear that it wasn't a live stream, that's for sure!"
    new "生放送じゃなかったのは明らかだよ！"

    # say L2054 pla
    old "Ok, I get it, what are you going to do about it then?"
    new "分かった、じゃあどうするつもりだ？"

    # say L2056 bel
    old "Isn't it obvious?"
    new "明るいじゃない"

    # say L2058 bel
    old "I'm going to match her!"
    new "私は彼女に負けるつもりはない！"

    # say L2059 bel
    old "I'm not going to just sit down and wait for her to pass me in the rankings!"
    new "私はただ座って、彼女に順位を抜かれるつもりはないわ！"

    # say L2060 pla
    old "So... You're also doing anal too?"
    new "そう… 君もアナルやってるの？"

    # say L2062 bel
    old "Yes, why? Are you against doing it or something?"
    new "うん、どうしたの？反対とか？"

    # say L2063 pla
    old "Uhh, no, no, nothing like that."
    new "うーん、いや、そういうわけじゃないよ。"

    # say L2064 pla
    old "It's just surprising, that's all."
    new "ただ驚いただけさ。"

    # say L2066 bel
    old "It wasn't my plan, obviously."
    new "それは私の計画じゃなかったの、当然だけど。"

    # say L2067 bel
    old "But after I saw Lana's {i}'Stream'{/i}..."
    new "でもランナの{i}'Stream'{/i}を見た後……"

    # say L2068 bel
    old "I asked my followers if they would like to see me doing something similar."
    new "フォロワーに聞いてみたら、同じようなことをやってくれたら喜ぶって言ったの。"

    # say L2069 bel
    old "They said they'd totally love to see it."
    new "彼らは全然それを見たいって言ったわ。"

    # say L2070 bel
    old "So that settles it, we're doing it!"
    new "じゃあ、それが決まりね。やってみましょう！"

    # say L2071 bel
    old "I told them we had a surprise coming the next time you appeared on the stream with me."
    new "次にあなたが私の配信に出てくれるとき、サプライズがあるって伝えておいたわ。"

    # say L2072 pla
    old "I see, w- well if you're ok with it, I- I guess it's fine."
    new "わ、分かったよ。君がいいなら、別にいいけど。"

    # say L2074 bel
    old "Yeah, I know that the next time you come to my house you have to do that website thing with my mom."
    new "次に君がうちに来たとき、ママとそのウェブサイトのことをやってくれないとダメなんだけど。"

    # say L2075 bel
    old "But perhaps we could do it afterwards."
    new "でも、その後にやってみるのはどう？"

    # say L2077 pla
    old "Actually, it's going to be at least a couple of times that I come to your house and help your mom with the website."
    new "実際には、君の家に来てお母さんのウェブサイトの手伝いをするのは、少なくとも何回かになるだろう。"

    # say L2079 bel
    old "Really?!"
    new "本当に？！"

    # say L2080 bel
    old "But we're really short on time [pla]!"
    new "でも時間がないんだよ [pla]！"

    # say L2081 pla
    old "I know, I'm sorry, but apparently, she has to show some progress to her bosses in the next meeting."
    new "知ってる、ごめん、でも次の会議でボスたちに進捗を見せなきゃならないらしい。"

    # say L2082 pla
    old "So, I kinda have to help her with it."
    new "だから、ちょっと彼女を手伝うしかないんだ。"

    # say L2084 bel
    old "Hmph OK, I guess that's fine."
    new "うーん、わかったわ。仕方ないか。"

    # say L2085 bel
    old "I'll tell my fans to wait for a while before I show them the '{i}surprise{/i}' I'd promise them."
    new "ファンには少し待ってもらおうから、約束した‘{i}サプライズ{/i}’は後で見せるわ。"

    # say L2086 bel
    old "But after that we have to do it, ok?"
    new "でもその後は必ずやるからね、いいでしょ？"

    # say L2089 bel
    old "Ok, I guess we better go to classes for now."
    new "そうだね、まずは授業に行こう。"

    # say L2115 ash
    old "Thank you, dear. I'm very glad I've got to meet you, you know?"
    new "ありがとう、親愛なる人。君と出会えて本当に嬉しいわ。"

    # say L2117 ash
    old "After all, Belle never introduces me to any of her friends."
    new "結局、ベルは私を彼女の友達に紹介してくれたことが一度もないの。"

    # say L2118 ash
    old "That girl's so secretive now."
    new "あの子、最近秘密主義よね。"

    # say L2119 pla
    old "So... Aren't you and Belle close?"
    new "そう……ベッリーやって近い間柄なのか？"

    # say L2120 ash
    old "No, we're not."
    new "ううん、そうじゃない。"

    # say L2121 ash
    old "We used to be very close before, but over the years she and I have distanced a lot."
    new "昔はとても仲が良かったけど、年月が経つにつれてお互いの距離が広がった。"

    # say L2124 ash
    old "Yes, when Belle was growing up we were inseparable."
    new "はい、ベールが成長していく過程で私たちは離れられなかったわ。"

    # say L2126 ash
    old "I would never go anywhere without her, and you'd be hard-pressed to see one without the other."
    new "彼女と別行動することはほとんどなかったし、片方を見たらもう片方もいるって感じだった。"

    # say L2129 ash
    old "But as time went by we began to distance."
    new "でも時間が経つにつれて、少しずつ距離が開いていった。"

    # say L2131 ash
    old "Now we barely even talk, and whenever we're together is like she's angry with me all the time."
    new "今ではほとんど話さないし、一緒にいるときはずっと私に怒っているみたい。"

    # say L2133 pla
    old "I'm sorry, I didn't know things were like that between the two of you."
    new "すみません、二人の関係がそんなになっていたとは知らなかった。"

    # say L2135 ash
    old "Yeah, but I blame myself."
    new "うん、でも自分を責めている。"

    # say L2138 ash
    old "Well, I'm a single mother, and I had Belle when I was very young."
    new "まあ、私はシングルマザーで、ベールを産んだのはとても若かったから。"

    # say L2140 ash
    old "I decided that I would do everything I could to raise her properly."
    new "私が一生懸命に育てることに決めたの。"

    # say L2142 ash
    old "So, as she grew up, my focus was on my work."
    new "だから、彼女が成長するにつれて、私の焦点は仕事に向けられていたの。"

    # say L2144 ash
    old "Since I was always working, I never had any time for her or the things related to school."
    new "仕事ばかりで、彼女や学校のことに手をつける時間なんて全然なかったから。"

    # say L2146 ash
    old "Is not that I wasn't interested, is just that I was busy all the time."
    new "興味がないわけじゃなくて、ただいつも忙しくて仕方なかったんだ。"

    # say L2147 ash
    old "I sort of thought that as long as I was providing for her, things would be fine."
    new "私が生活を支えてさえいれば、大丈夫だろうって思ってたの。"

    # say L2149 ash
    old "But I didn't realize she was pulling away from me. Nowadays I never know what she's doing."
    new "でも、彼女が離れていくことに気づいていなかったの。最近は彼女が何をしているのかわからないことが多いわ。"

    # say L2150 ash
    old "Her interests, or the things she's into..."
    new "彼女の興味や、ハマってるものって…"

    # say L2152 ash
    old "It's a miracle I even know Hinn, and that's just because I came home one time while she was here."
    new "ヒンを知ってるだけでも奇跡みたいなものだよ、それも私が家に帰ったときに彼女がいたからこそさ。"

    # say L2154 ash
    old "Oh, and that other friend... Mike."
    new "あ、それから別の友達がいるの… マイク。"

    # say L2156 ash
    old "But I'd rather not to talk about him."
    new "でも、彼のことあまり話したくないの。"

    # say L2158 pla
    old "I- I'm sorry about that M- Mrs... I- I mean A- Ashley."
    new "あー、すみません、ミス…あ、アシュリー。"

    # say L2159 pla
    old "But I'm sure you and Belle will be fine."
    new "でも君とベールは大丈夫だよ。"

    # say L2161 ash
    old "You think so?"
    new "そう思うの？"

    # say L2163 pla
    old "For sure, after all, you say you've always been close."
    new "もちろん、君はいつもベールと仲が良かったって言ってたじゃないか。"

    # say L2164 pla
    old "I'm sure Belle's just..."
    new "俺はベルがただ…"

    # say L2165 pla
    old "Uhm... Worried about things from school and such."
    new "うーん… 学校のこととかで心配してるんだな。"

    # say L2167 ash
    old "I guess I'll have to take your word for it. After all, you may be more informed about what she's doing lately than me."
    new "そうね、君の言う通りにするわ。結局、最近の彼女のことを君の方がよく知ってるかもしれないしね。"

    # say L2169 ash
    old "The good thing is that she doesn't seem to be doing anything weird or out of the ordinary."
    new "良いこととしては、彼女が特に変なことや普通と違うことをしていないみたいね。"

    # say L2170 ash
    old "She's just focused on school."
    new "彼女はただ学校に集中してるだけみたいよ。"

    # say L2173 ash
    old "Although I think it would be good if she went out a little bit more. She seems to expend most of her time on her computer."
    new "でも、もう少し外に出たらいいのに。彼女はほとんどパソコンの前で過ごしてるみたいだよ。"

    # say L2175 ash
    old "But I guess that's good, at least she's not doing anything bad."
    new "でもまあ、それはいいか、せめて悪いことしてないし。"

    # say L2177 pla
    old "Uhh, sure..."
    new "うーん、そうかな…"

    # say L2180 ash
    old "Why don't you go home for now? We can continue working some other time."
    new "今帰った方がいいわ。また別の時間に続けよう。"

    # say L2181 pla
    old "Oh! Sure!"
    new "オッ！そうか！"

    # say L2187 pla
    old "I'll see you later then. Goodbye, Ashley."
    new "じゃあ後でな。アシュリー、さよなら。"

    # say L2189 ash
    old "Goodbye hon, thanks for your help today."
    new "さよなら、今日の手伝いありがとう。"

    # say L2190 ash
    old "And thank you, for listening to me."
    new "ありがとう、聞いてくれて。"

    # say L2192 pla
    old "Gladly, I'm happy to help you, and to talk to you."
    new "もちろん、君の手伝えて、話せてうれしいよ。"

    # say L2194 ash
    old "That's very sweet."
    new "それはとても甘いね。"

    # say L2199 pla
    old "I think I should get going then."
    new "じゃあ、行こうかな。"

    # say L2200 ash
    old "Yeah, yeah, sure. Bye."
    new "うんうん、そうね。バイバイ。"

    # say L2222 bel
    old "Hi [pla], how are you?"
    new "こんにちは [pla]、元気？"

    # say L2224 bel
    old "Well, I wanted to discuss what we're going to do for our next stream together."
    new "じゃあ、次に一緒に配信するときに何するか話し合いたかったの。"

    # say L2228 bel
    old "Well, I know you had to help my mom with that website she's working on."
    new "まあ、母のウェブサイトの手伝いをしてくれたことは知っています。"

    # say L2230 bel
    old "But I think today you're supposed to be free, right?"
    new "でも今日はずっと自由なはずだよね、そうじゃない？"

    # say L2231 bel
    old "So, do you think you could come to my house today?"
    new "今日、うちに来れるかな？"

    # say L2233 bel
    old "Great! So let's go after classes."
    new "Great！ じゃあ授業が終わったら行こう。"

    # say L2259 bel
    old "Ok, let's go."
    new "じゃあ、行こう。"

    # say L2260 pla
    old "Right, let's do it."
    new "よし、やろう。"

    # say L2273 bel
    old "Alright, let's do this!"
    new "よし、行こう！"

    # say L2274 pla
    old "Wait, before we start."
    new "待って、始める前に。"

    # say L2275 pla
    old "Are you sure you want to do this?"
    new "本当にこれをする気なのか？"

    # say L2276 pla
    old "I know it's not that big a deal to some people, but  you would be doing it for the first time."
    new "知ってるよ、有些人對這件事可能不在意、でも君は初めてだよ。"

    # say L2277 bel
    old "I am, listen [pla], I've worked very hard for this."
    new "私は、聞いて [pla]、これのためにとても頑張ってきたの。"

    # say L2279 bel
    old "Winning this award means a lot to me."
    new "この賞は私にとってとても大切なことなの。"

    # say L2280 bel
    old "And I'm not backing down because of Lana suddenly coming into the scene."
    new "ランナが突然現れたからって、私は引かないわ。"

    # say L2282 bel
    old "So yeah, I'm sure!"
    new "そうよ、絶対に勝つわ！"

    # say L2283 pla
    old "Ok, if you're this determined, let's do it."
    new "分かった、そんなに決心してるなら、やってみよう。"

    # say L2285 bel
    old "Yeah! Let's do it!"
    new "うん！やろうよ！"

    # say L2298 bel
    old "Hello again guys!"
    new "また会えたね！"

    # say L2299 bel
    old "I'm very happy to see you all again!"
    new "またみんなに会えてとても嬉しいわ！"

    # say L2300 bel
    old "And I have very good news, everybody!"
    new "そして皆さん、とても良いニュースがあります！"

    # say L2301 bel
    old "Remember the other surprise I'd talked to you about?!"
    new "あのサプライズのことを覚えてる？！"

    # say L2302 bel
    old "Well, it's happening today!"
    new "じゃあ、今日実現するのよ！"

    # say L2303 bel
    old "I know this is something you've been dying to see!"
    new "これがあなたが見たくてうずうずしていたものだって知っていてよ！"

    # say L2304 bel
    old "And I know you will love it!"
    new "そして、あなたが大好きになることを知っています！"

    # say L2305 bel
    old "So, say hello again to my friend, and let's get to it!"
    new "じゃあ、また私の友達にこんにちはと言って、始めるよ！"

    # say L2310 bel
    old "Remember guys, just as always! Today's surprise can only come if you guys reach our goal."
    new "みんな、いつも通りね！ 今日のサプライズは、みんなが目標を達成したときにだけ来るんだから。"

    # say L2311 bel
    old "But I'm sure you'll reach it!"
    new "でもきっと達成してくれるよね！"

    # say L2318 bel
    old "For today we're going to need it well lubricated, isn't that right, guys?"
    new "今日はしっかり潤しておかないといけないね、みんな。"

    # say L2319 bel
    old "So I'll take care of doing a good job with my mouth to get it ready for what comes next."
    new "それなら、私が口でしっかり準備して、次に備えるわ。"

    # say L2320 bel
    old "My God! What a great cock!"
    new "神様！なんて立派なちんこだ！"

    # say L2321 bel
    old "Right guys?!"
    new "そうよね？"

    # say L2322 bel
    old "I bet you can't wait to see me being ravaged by it."
    new "きっとあなたも、私がこれで嬲られるのを楽しみに待っているでしょう。"

    # say L2323 bel
    old "Just be sure to get to the goal guys!"
    new "目標には絶対到達するんだよ！"

    # say L2336 pla
    old "Uh- I- uh..."
    new "うー、あー、ベルと…"

    # say L2337 pla
    old "I came to do something with Belle."
    new "俺はベールと何かするために来たんだ。"

    # say L2339 pla
    old "Some... Uh- school work..."
    new "いくつか… えっと、学校の宿題を…"

    # say L2341 ash
    old "Ok, I see, but where is Belle?"
    new "分かったわ、でもベールはどこ？"

    # say L2343 pla
    old "She... Uh- she went out for a while."
    new "彼女…ちょっと外に出たってさ。"

    # say L2344 pla
    old "She said something about picking up a thing at Hinn's house."
    new "彼女はヒンの家で何かを拾いに行くって言ってた。"

    # say L2346 ash
    old "I had to pop home to get some documents for work, and I wanted to talk with her."
    new "家に寄って仕事の書類を取りに行かなくてはならなかったし、彼女と話したかったの。"

    # say L2347 ash
    old "Well, it's good to see you anyway."
    new "まあ、会えて良かったね。"

    # say L2348 ash
    old "I'll go back to the office, please tell Belle to give me a call when she gets back."
    new "オフィスに戻るから、ベールが戻ったら電話してって伝えてね。"

    # say L2349 ash
    old "See you later [pla]."
    new "じゃあ、またね [pla]。"

    # say L2350 pla
    old "Sure, see you later ma'am."
    new "分かった、またね。"

    # say L2362 pla
    old "{i}What the fuck just happened...{/i}"
    new "{i}何てことだよ……{/i}"

    # say L2363 bel
    old "{i}Holy shit, I know... Anyway, let's just keep going with the stream... Shhh...{/i}"
    new "{i}おおっ、私も知ってる… とにかく、配信を続けていこう… シッ…{/i}"

    # say L2364 bel
    old "Sorry, guys! I'm sorry for that little interruption... You know, this can happen when you're doing it live..."
    new "ごめんなさい、皆さん！そのちょっとした中断、すみませんでした… 生放送だから、こんなこともあるのよ…"

    # say L2365 bel
    old "Anyways, let's continue with the show!"
    new "それじゃ、ショーを続けましょう！"

    # say L2366 bel
    old "But now we can resume with what we were doing, and you know what that means."
    new "でも、今から先ほどの続きができるわ、それが何を意味するか、あなたも知ってるよね。"

    # say L2368 bel
    old "No, she won't be joining us or anything."
    new "彼女は参加してこないよ。"

    # say L2369 bel
    old "That was just an unplanned thing."
    new "それはただ予定外のことだったの。"

    # say L2370 bel
    old "But don't worry, we're not stopping here."
    new "でも心配しないで、ここで止まらないから。"

    # say L2371 bel
    old "Let's keep going!"
    new "進みましょう！"

    # say L2388 bel
    old "Wow, that was close!"
    new "わあ、それは危なかったね！"

    # say L2389 pla
    old "Really close."
    new "本当に危なかったね。"

    # say L2390 pla
    old "That really scared me."
    new "本当にビビったな。"

    # say L2391 bel
    old "It's good that she didn't see us doing anything."
    new "彼女に何もしているところを見られなくて良かったわ。"

    # say L2393 bel
    old "I can't imagine how we would explain the whole situation to her."
    new "彼女に状況を説明するのは想像もつかないわ。"

    # say L2394 pla
    old "Yeah, tell me about it."
    new "そうだよ、本当に。"

    # say L2395 bel
    old "Well, we should get back to the stream before the fans get impatient."
    new "ファンが待ちきれない前に、ストリームに戻るべきだわ。"

    # say L2408 bel
    old "Hngh! Oh yes!"
    new "うんぐ！そうよ！"

    # say L2409 bel
    old "This is what you've all been waiting for isn't it?"
    new "これがみんな待ってたものよね？"

    # say L2410 bel
    old "Well, you earned it!"
    new "WELL、あなたたちが待っていたものよね。でも、あなたたちがそれを得る価値があったわ！"

    # say L2411 bel
    old "So, be sure to enjoy it!"
    new "じゃあ、楽しんでね！"

    # say L2424 bel
    old "Guys! I'm so glad you liked it!"
    new "みんな！私が作ったのを気に入ってくれてうれしいよ！"

    # say L2425 bel
    old "You keep making all of this possible."
    new "あなたたちがすべてを可能にしてくれるから。"

    # say L2426 bel
    old "Witout your support this just wouldn't be possible."
    new "あなたの応援がなければ、これほどまでにはならなかったわ。"

    # say L2427 bel
    old "So, it makes me very happy to do this kind of thing for you."
    new "だから、あなたのためにこんなことをしてあげられてとても嬉しいよ。"

    # say L2428 bel
    old "Ok guys, I have to leave for now."
    new "みんな、ちょっと行ってくるからね。"

    # say L2429 bel
    old "But be sure that I'll be back soon with another stream."
    new "でも、またすぐ戻ってくるからね。"

    # say L2430 bel
    old "I wonder what surprise I'll have for you then?"
    new "どんなサプライズを用意しているのかな、楽しみにしていてね。"

    # say L2431 bel
    old "As always remember to subscribe so you will get notified of the next stream!"
    new "いつも通り、次の配信の通知を受け取れるように登録をお願いしますね！"

    # say L2432 bel
    old "And remember to follow me on all my socials."
    new "そして私のソーシャルメディアも全部フォローしてね。"

    # say L2433 bel
    old "So you won't miss any updates!"
    new "そうすればアップデートを見逃さないよ！"

    # say L2434 bel
    old "Until next time, see you guys! Love you!"
    new "それじゃ、またね！みんな、愛してる！"

    # say L2443 bel
    old "That came out really well [pla]!"
    new "それってすごくうまくいったね [pla]！"

    # say L2444 bel
    old "They matched the goal so quickly!"
    new "目標に到達するのが早かったね！"

    # say L2445 bel
    old "I'm sure I'll overtake Lana in no time!"
    new "ランナをすぐに追い抜けると思う！"

    # say L2446 bel
    old "And this time I'm certain the first spot in the rankings is mine for sure!"
    new "今回はランキングのトップを獲得できる自信があるわ！"

    # say L2448 pla
    old "That's great to hear Belle, I'm sure you'll get it."
    new "ベル、それは良かったな。君ならきっとできるよ。"

    # say L2450 pla
    old "Although I hope your fans weren't bothered by your mom coming in midstream."
    new "でも、君のファンが配信中に君のお母さんが入ってきたことで困らなかったか心配だな。"

    # say L2452 pla
    old "That really scared me, I thought she was going to see us."
    new "本当に驚いたよ、ベル。母さんに見られるかと思った。"

    # say L2454 bel
    old "Yeah, me too, I'm sorry that happened, by the way."
    new "うん、私もびっくりした。ごめんね、そんなことになっちゃって。"

    # say L2455 bel
    old "She just had to come in at the most inopportune time."
    new "彼女は本当に最悪のタイミングで入ってきちゃったね。"

    # say L2456 bel
    old "But don't worry, the fans weren't too bothered by her intrusion."
    new "でも心配しないで、ファンたちは彼女の乱入にそんなに気にしてなかったよ。"

    # say L2458 bel
    old "Yeah... they were writing how thrilling it was."
    new "うん… みんなそれがどれだけ興奮したか書いてたよ。"

    # say L2460 bel
    old "So many of them were even writing how hot it would be to see my mom fuck with us."
    new "そんなに多くのファンが、私のママが私たちと一緒にセックスするシーンがどれだけエロいのかって書いてたわ。"

    # say L2462 bel
    old "But leaving that aside, everything went better than I expected."
    new "でも、それとは別に、すべてが予想以上によかったわ。"

    # say L2464 bel
    old "Thanks a lot [pla], this wouldn't have been possible without you."
    new "ありがとう、[pla]。これ無くてはできなかったね。"

    # say L2466 pla
    old "Don't even mention it, I'm happy I can help you."
    new "全然言わないで、君の役に立てて嬉しいよ。"

    # say L2467 pla
    old "I know how much this means to you."
    new "俺は君がどれだけこのことに関係があると思っているか知ってるよ。"

    # say L2469 bel
    old "But even still, is not as if this is just nothing."
    new "でも、それでも、これだけは何もないわけではないよね。"

    # say L2471 bel
    old "After all, we're... Getting closer."
    new "でも、結局、私たちは… お互いに近づいてるのね。"

    # say L2473 pla
    old "Yeah... We are."
    new "そうだな… お互いに近づいてるよ。"

    # say L2479 pla
    old "Well, I think I should leave for now."
    new "まあ、そろそろ帰るか。"

    # say L2481 bel
    old "Right, for sure! I think I better get dressed and call my mom before she goes crazy because I haven't talked to her."
    new "そうだね、そうしよう！着替えてからママに電話しないと、心配しちゃうだろうね。"

    # say L2482 bel
    old "Once again [pla], thanks."
    new "また [pla]、ありがとう。"

    # say L2483 bel
    old "You're doing so much for me, I can't thank you enough."
    new "あなたがこんなにたくさん助けてくれて、本当に感謝の言葉もありません。"

    # say L2484 pla
    old "Don't worry, I'm just happy I can help you Belle, with anything you need."
    new "心配しないで、君のために何か手伝えることがあって嬉しいんだよ、ベール。"

    # say L2485 pla
    old "I'll leave for now, see you later."
    new "じゃあ、今度会おうベル。またね。"

    # say L2507 pla
    old "Hi Ashley, I came to help you with the website."
    new "Hey、アシュリー、ウェブサイトの手伝いに来たよ。"

    # say L2508 ash
    old "Oh, is good that you're here I need your help with something right now."
    new "あ、あなたが来てくれて良かったわ。今すぐにあなたの手が必要なの。"

    # say L2510 ash
    old "Well, I was thinking about the design of the banners that we're making for the coffee shop."
    new "あのね、コーヒー店のバナーのデザインについて考えていたの。"

    # say L2511 ash
    old "And I remembered some banners that we had made before but never got around to releasing."
    new "そして、前に作ったけど使わなかったバナーを思い出したの。"

    # say L2512 ash
    old "I think we'll be able to reuse some of those ready-made designs to add them to the website."
    new "あの既製のデザインをウェブサイトに追加できそう思う。"

    # say L2513 ash
    old "I remembered that I saved those designs on an old flash drive, and I placed it up there on the shelves."
    new "あのデザインを古いフラッシュドライブに保存して、それを棚の上に置いておいたのを思い出した。"

    # say L2514 ash
    old "But it's a bit too high for me to reach by myself without risking falling over."
    new "でも、自分で届くのはちょっと高すぎて、落ちちゃいそう。"

    # say L2515 ash
    old "So, I need you to help me stay stable on the ladder while I look for it."
    new "じゃあ、私が探す間、あなたが梯子を支えてくれない？"

    # say L2517 pla
    old "Uhh, s- sure, no problem."
    new "うーん、す、すみません、問題ないです。"

    # say L2518 ash
    old "Thank you, hun."
    new "ありがとう、甘いの。"

    # say L2523 pla
    old "Are you okay there? Can you reach it?"
    new "大丈夫？届けることができる？"

    # say L2524 ash
    old "Yeah, I'm close. Just a little more and I'll grab it."
    new "うん、近いわ。ちょっとだけ手を伸ばせば取れるよ。"

    # say L2525 pla
    old "{i}(... Damn, I hadn't thought about it, but Ashley's really hot.){/i}"
    new "{i}(……くそ、考えてなかったけど、アッシュはほんとカッコいいな。){/i}"

    # say L2529 pla
    old "{i}(I mean, just look at her ass...){/i}"
    new "{i}(ほら、そのお尻見てみろ...){/i}"

    # say L2530 pla
    old "{i}(Oh shit! I'm getting horny.){/i}"
    new "{i}(しまった！興奮してきた。){/i}"

    # say L2531 pla
    old "{i}(I have to calm down or I'll get a boner){/i}"
    new "{i}落ち着かないと、勃っちゃいそうだな{/i}"

    # say L2533 pla
    old "Uh, yeah, yeah... Why do you ask?"
    new "うん、うん…何で聞くんだ？"

    # say L2534 ash
    old "Well, you moved suddenly, so I was wondering if I made you lose your balance."
    new "WELL、急に動いたから、バランスを崩しちゃったのかなって。"

    # say L2535 pla
    old "No, no, Uhh, nothing happened, it's ok."
    new "うん、うん、大丈夫、何も起こらなかったよ。"

    # say L2536 ash
    old "Uh, ok... sure."
    new "うーん、そうね。"

    # say L2537 pla
    old "{i}(Shit! I better calm down before I get a boner.){/i}"
    new "{i}(しまった！ボンカーになる前に冷静にならないと。){/i}"

    # say L2538 ash
    old "Ok, I think I've got them, I'm coming down."
    new "わかった、拾えたと思うから、降りてくるね。"

    # say L2539 pla
    old "Oh, alright."
    new "わかった、わかった。"

    # say L2547 pla
    old "Ughh, damn, that was painful."
    new "うげっ、くそ、それは痛かったな。"

    # say L2548 pla
    old "{i}(Hmm? What is this? What do I have on my face?){/i}"
    new "{i}(ん？これって何？顔に何かついてる？){/i}"

    # say L2549 pla
    old "{i}(Oh wow, it's Ashley's ass!){/i}"
    new "{i}(あー、これはアシュリーの尻だ！){/i}"

    # say L2551 ash
    old "Ouch, that really hurt."
    new "いたたた、本当に痛かったよ。"

    # say L2552 ash
    old "I'm sorry [pla], I don't know what happened, are you okay?"
    new "ごめん、[pla]、何が起こったのかわからないけど、大丈夫？"

    # say L2554 pla
    old "{i}(Oh fuck, just what I wanted to avoid! I got a boner!){/i}"
    new "{i}(くそ、避けたかったことだ！勃っちまった！){/i}"

    # say L2556 pla
    old "Y- yeah, I- I am. I'm sorry, I think I was the one who slipped."
    new "あー、うん、そうなんだ。ごめん、俺が滑っちゃったみたいだ。"

    # say L2560 pla
    old "Uh... A- Ashley? Can you please move?"
    new "あー… アシュレイ？ ちょっと動いてくれないか？"

    # say L2561 ash
    old "Uh, I- I..."
    new "あ、あたし…"

    # say L2563 ash
    old "Is just that you have a..."
    new "ただ、君がちょっと…"

    # say L2574 pla
    old "I- I uh... I'm sorry Ashley, it wasn't my intention..."
    new "あー、その、すまんアッシュ、故意じゃなかったんだよ…"

    # say L2575 pla
    old "I- its just that..."
    new "俺ー、その、ただ、"

    # say L2576 ash
    old "It's fine, it's fine."
    new "大丈夫、大丈夫。"

    # say L2578 ash
    old "You're a young man after all. It's perfectly understandable that this happens."
    new "君は若者だものね、これは仕方ないわ。"

    # say L2579 ash
    old "I fell on you and... M- my butt landed on your face..."
    new "私が君の上に倒れて、その、お尻が君の顔に当たっちゃって…"

    # say L2580 ash
    old "So, I think I understand that you would get a..."
    new "そう、私が理解できるわ。あなたがそんな反応をするのも当然よね。"

    # say L2598 pla
    old "Uhh... T- thank you... for understanding."
    new "うーん… 分かってくれて… ありがとう。"

    # say L2599 ash
    old "Hmm... Sure, i- it's very normal."
    new "うん… それはとても普通のことだね。"

    # say L2604 pla
    old "Uhh, s- should we get to working on the website then?"
    new "うーん、じゃあウェブサイトの作業に取りかかろうか？"

    # say L2606 ash
    old "I- I don't think that's a good idea right now [pla]."
    new "今すぐは [pla] いいアイデアじゃないと思うけど。"

    # say L2607 ash
    old "B- because I have to bring the banners to my team in the office, so they can use them to design the new ones."
    new "だって、バナーをオフィスのチームに持っていく必要があるから、新しいデザインに使うんだよね。"

    # say L2609 pla
    old "Oh... Alright."
    new "わかった、オッケー。"

    # say L2611 pla
    old "I- I think I'll leave for now, see you later."
    new "俺- 俺はちょっと先走るよ、後でな。"

    # say L2612 ash
    old "Y- yeah... S- see you later hon."
    new "うん… またね、親愛。"

    # say L2618 ash
    old "Wow, he really has it very big c-... Now I understand why Belle likes him so much..."
    new "Wow、彼の大きさは本当にすごいわ… 今さらだけど、ベルが彼のことが好きなのも納得できるわ…"

    # say L2638 pla
    old "Hey Belle, good morning, how are you?"
    new "ベール、おはよう、調子はどう？"

    # say L2640 bel
    old "To be honest, I'm quite upset..."
    new "正直、かなり落ち込んでるの..."

    # say L2641 pla
    old "Why? What happened now?"
    new "なんで？今何があったんだ？"

    # say L2643 bel
    old "Well, it's that bitch Lana."
    new "まあ、そのバitchランナのことよ。"

    # say L2645 bel
    old "You won't believe what she pulled now!"
    new "信じられないわ、今度は何をしたのよ…！"

    # say L2646 pla
    old "W- what? Why?!"
    new "何だよ？どうして？！"

    # say L2647 pla
    old "I thought that you had surpassed her with what we did last time."
    new "前回のことで君は彼女を追い越したと思ったんだ。"

    # say L2649 bel
    old "And we did!"
    new "やったわ！"

    # say L2651 bel
    old "After our last streaming session I went up on the charts by a lot."
    new "前回の配信後、私の順位がかなり上がったんだ。"

    # say L2653 bel
    old "So, I guess Lana felt desperate or something."
    new "そう、ラナは必死だったのかな。"

    # say L2654 bel
    old "Because then she came out and did a threesome!"
    new "だから彼女が突然 threesome をしたの！"

    # say L2655 pla
    old "A threesome?"
    new "三人で？"

    # say L2657 bel
    old "Yeah, she just did it out of nowhere."
    new "そう、突然やってきたのね。"

    # say L2659 bel
    old "You know what really triggers me? She didn't even do it with another cam streamer or anything!"
    new "あなた知ってる？彼女、他のキャスとも全然してなかったんだよ！"

    # say L2661 bel
    old "But of course she didn't, she doesn't know anybody in this business."
    new "もちろんそうよ、彼女はこの業界の誰とも知り合いでないんだから。"

    # say L2663 bel
    old "I bet she just paid some amateur pornstar to do it with her, that whore!"
    new "あのスレッド、きっと素人のAV女優に金払ってやってもらったに決まってるわ！"

    # say L2664 pla
    old "OK, what is your plan then?"
    new "じゃあ、君のプランは何だ？"

    # say L2666 bel
    old "What do you mean what is my plan? I'm going to answer her the same way of course?"
    new "何言ってるの？もちろん同じように返すつもりよ？"

    # say L2667 pla
    old "Uhh, really? Are you sure?"
    new "うーん、本当に？確実なのか？"

    # say L2669 bel
    old "Of course I'm sure [pla], I've done too much to win this contest."
    new "もちろん自信あるわ [pla]、このコンテストに勝つためにはこれだけやってきたんだから。"

    # say L2670 bel
    old "I've been working hard to get every vote I've received."
    new "私は一生懸命働いて、受け取った全ての票を獲得したのよ。"

    # say L2671 bel
    old "I've augmented the number of times I stream weekly. I roped you into this."
    new "週にストリームする回数を増やしたわ。あなたを巻き込んだのよ。"

    # say L2673 bel
    old "I even let you fuck me in the ass!"
    new "EVEN LET YOU FUCK ME IN THE ASS！"

    # say L2675 bel
    old "I've worked hard for this, and I'm not going to let some newcomer take it away."
    new "私はこれのために頑張ってきたの。新米に取って代わされるわけにはいかないわ。"

    # say L2676 pla
    old "Well, I don't know what to tell you."
    new "WELL、何言えばいいかわかんないな。"

    # say L2677 bel
    old "You don't have to say anything, all I need is for you to be willing to help me when I need it."
    new "何も言わなくてもいいよ、必要なときに手伝ってくれればそれで十分だよ。"

    # say L2679 pla
    old "Of course! You know I'll help you with anything I can."
    new "もちろん！君が必要な時は何でも手伝うぜ。"

    # say L2681 bel
    old "Thanks [pla], I'm glad I can count on you."
    new "ありがとう、[pla]。君に頼れるのが嬉しい。"

    # say L2682 bel
    old "Also, I already have someone in mind who can help us with the threesome."
    new "それに、三人プレイの相手もすでに決まっているの。"

    # say L2683 bel
    old "I'll have to contact her and see when she would be available to arrange everything for the stream."
    new "彼女に連絡して、ストリームのためにいつ手配できるか確認しないとね。"

    # say L2684 bel
    old "Meanwhile, you have to work with my mom the next time you come home, right?"
    new "次に家に帰るときは、ママと一緒に働くことになっているんでしょ？"

    # say L2686 pla
    old "Uhh, yeah, we are still working on the website, there are still several things left to finish."
    new "うーん、そうだな、ウェブサイトの作業はまだ続いてて、終わらなきゃいけないことがいくつか残ってるんだ。"

    # say L2688 bel
    old "Ok, so while you do that I'll talk with my friend and see if she can help us."
    new "じゃあ、その間に私が友達と話して、手伝ってくれるかどうか見てくるね。"

    # say L2689 bel
    old "I'll let you know as soon as we can do it."
    new "すぐにお知らせするね。"

    # say L2691 pla
    old "Uhh, alright."
    new "うーん、分かった。"

    # say L2693 bel
    old "Great, then see you later [pla]."
    new "じゃあ、後でね [pla]。"

    # say L2695 pla
    old "See you Belle."
    new "またね、ベール。"

    # say L2707 pla
    old "Well, I was thinking I could keep helping you develop the website."
    new "まあ、Websiteの開発を手伝い続けられるんじゃないかって思ってたんだ。"

    # say L2708 ash
    old "Hmm... There might be a problem with that [pla]."
    new "Hmm... その [pla] について問題があるかもしれないね。"

    # say L2709 pla
    old "Hmm, what is it?"
    new "へえ、何なんだ？"

    # say L2711 ash
    old "Well, my laptop isn't working right now."
    new "ええっと、私のラップトップが今調子悪いの。"

    # say L2712 ash
    old "I was... Uh, u- using it the other day, looking for some... References."
    new "あのう、先日使ってて、参考資料を探してたんだけど……"

    # say L2713 ash
    old "But it suddenly stopped working."
    new "でも突然動かなくなったの。"

    # say L2715 ash
    old "I can turn it on now, it will even power up normally."
    new "今なら点けられるよ、普通に起動もする。"

    # say L2716 ash
    old "But after that, it doesn't work."
    new "でもその後、動かなくなっちゃった。"

    # say L2717 pla
    old "What do you mean? The screen just stays black?"
    new "何がどうしたって？画面が真っ黒のままなのか？"

    # say L2718 ash
    old "No, it's not that. Once it's fully turned on, you simply can't do anything with it."
    new "そうじゃなくて、完全に起動したら、何もできなくなるんだ。"

    # say L2720 ash
    old "If you click on something, multiple windows open up, and when you attempt to use the web browser, numerous tabs start to open up."
    new "クリックすると複数のウィンドウが開いて、ウェブブラウザを使おうとするとたくさんのタブが開き始めるの。"

    # say L2721 ash
    old "And you can't close them down or do anything about it."
    new "そしてそれらを閉じることも何もできないの。"

    # say L2722 pla
    old "Hmm, that sounds like an adware."
    new "うーん、広告ソフトのようだな。"

    # say L2724 pla
    old "But don't worry, I think I can fix it."
    new "でも心配しないで、直せると思うよ。"

    # say L2727 pla
    old "Yeah, all I have to do is run an antivirus through it, and it should be completely fine."
    new "そうだな、アンチウイルスをかけてやれば、完全に治るはずだ。"

    # say L2728 ash
    old "That sounds great! Alright, let's do it."
    new "それいいね！じゃあ、やってみよう。"

    # say L2743 ash
    old "There, that's what happens as soon as you try to use it."
    new "あそこで、使おうとするとすぐにこんなことになるのね。"

    # say L2744 pla
    old "Hmm, yeah, I see what you mean."
    new "うん、そうなるな。君が言う通りだ。"

    # say L2745 pla
    old "Yeah, this appears to be an adware virus. But don't worry, it can be easily fixed."
    new "そうだな、これは広告ウイルスだね。でも心配しないで、簡単に直せるよ。"

    # say L2746 pla
    old "I just have to run the antivirus, and it will take care of cleaning up all those annoying ads."
    new "アンチウイルスを走らせれば、あのうざい広告全部をきれいにしてくれるよ。"

    # say L2747 pla
    old "It should start to work quickly."
    new "すぐに効果が出るはずだ。"

    # say L2754 pla
    old "See? It's already starting to work."
    new "見ろ？もう効果が出始めてるぞ。"

    # say L2760 pla
    old "Ok, now it's searching for viruses and malicious content."
    new "よし、今からウイルスや悪意のあるコンテンツを探し始めるぞ。"

    # say L2761 pla
    old "As soon as it's done with the scanning, it will start deleting all the damaged files and threats to the system."
    new "スキャンが終わったら、システムを脅かす壊れたファイルや脅威を全部削除し始めるよ。"

    # say L2762 ash
    old "Wow, you're very good with computers [pla]."
    new "すごいね、パソコンに詳しいのね [pla]。"

    # say L2763 pla
    old "Well, it's not as difficult as it seems, heh."
    new "まあ、それほど難しくないさ、へへ。"

    # say L2769 pla
    old "Ok, it's almost done, it shouldn't take much longer."
    new "じゃあ、もうすぐ終わるよ、それほど時間はかからないはずだ。"

    # say L2770 ash
    old "Wow, I didn't know it was so fast. I thought I would have to take it for maintenance and it would take days."
    new "Wow、そんなに早くなるとは思わなかった。修理に出すと思ってたから、数日かかると思っていたの。"

    # say L2777 pla
    old "Okay, we're done. The viruses that were affecting your computer should have been eliminated by now."
    new "大丈夫、終わったよ。君のパソコンに影響を与えていたウイルスは消去されたはずだ。"

    # say L2778 ash
    old "Great, thank you!"
    new "ありがとう、助かったわ。"

    # say L2779 pla
    old "Just let me refresh it and we'll see..."
    new "ちょっと待って、リフレッシュさせてみるからな..."

    # say L2786 pla
    old "Now, all of those ads and windows that it opened previously should start closing down."
    new "それじゃ、前に開いた広告やウィンドウが次々と閉じ始めるはずだ。"

    # say L2790 pla
    old "Oh! there's a webpage from your previous session."
    new "あ！前回のセッションで開いたウェブページが残ってるな。"

    # say L2791 pla
    old "Hmm, let's see, what does it say?"
    new "ん、見てみよう、何書いてあるんだ？"

    # say L2795 pla
    old "Sneaky Stepmom Fucks Step Daugther's Boyfri-..."
    new "すかさずステップマザーがステップ娘の彼氏に…"

    # say L2797 ash
    old "Oh! T- that's..."
    new "あ！ それって…"

    # say L2798 ash
    old "I- I Uh- I- I'm sorry [pla]! I don't know what that's doing in there."
    new "あっ、すみません[pla]！それがそこにどうしてあるのか、わかりません。"

    # say L2799 ash
    old "M- maybe the virus s- send us to that website!"
    new "もしかしてウイルスがそのサイトに飛ばしたのかもしれない！"

    # say L2800 pla
    old "Uhm... Yeah, that's probably what happened."
    new "うーん… そうかもね。"

    # say L2801 ash
    old "W- well, let's just close it. And keep checking if the pc is fine."
    new "わ、じゃあ閉じちゃおう。パソコンが大丈夫かどうか確認しつつね。"

    # say L2809 pla
    old "Okay, I think the computer is good to go."
    new "じゃあ、パソコンは大丈夫そうだな。"

    # say L2810 pla
    old "Now it shouldn't be a problem to continue with the work."
    new "じゃあ、これから作業を続けるのに問題ないはずだな。"

    # say L2812 ash
    old "Ohh, t- thank you [pla]."
    new "あっ、た- ありがとう、[pla]。"

    # say L2813 ash
    old "I- It's great that you managed to get it working again."
    new "あっ、また使えるようになったのが嬉しいです。"

    # say L2816 ash
    old "And I'm sorry about that website that you saw."
    new "そして、そのウェブサイトを見てしまったこと、すみません。"

    # say L2817 ash
    old "I don't know how that got in there."
    new "それがどうして入っちゃったのか、わからないの。"

    # say L2819 pla
    old "Uhh sure... I'm just glad I can be of help."
    new "うーん、そうだな… ただ、君の役に立てて嬉しいよ。"

    # say L2821 ash
    old "That's very nice of you."
    new "それはとても親切だね。"

    # say L2827 ash
    old "Uhh, I guess we should continue working, right?"
    new "うーん、働くことを続けるって言うなら、そうするべきよね。"

    # say L2828 pla
    old "Oh, sure, we should get to that."
    new "ああ、そうか、始めようか。"

    # say L2887 pla
    old "Hey Belle, how are you?"
    new "ベール、調子はどうだ？"

    # say L2888 bel
    old "Actually, I'm doing great, you know? I have very good news!"
    new "実は、調子いいのよ。すごくいいニュースがあるの！"

    # say L2891 bel
    old "Remember what I told you before? What we needed to do for the next stream?"
    new "覚えてる？前に話したよね？次の配信のために必要なことを。"

    # say L2893 pla
    old "Uhh, yeah, I do."
    new "うーん、そうだね。"

    # say L2895 bel
    old "Well, I got the girl we needed for the stream!"
    new "WELL、必要な女の子をゲットしたわ！"

    # say L2897 pla
    old "T- that's great."
    new "うーん、それは良いね。"

    # say L2898 bel
    old "Yeah, she's an amazing streamer."
    new "うん、彼女は素晴らしいストリーマーだよ。"

    # say L2899 bel
    old "So, get ready because today we're going to do the stream!"
    new "じゃあ、準備してね。今日の配信、楽しみにしてて！"

    # say L2901 pla
    old "A- alright, so, are we going to your house after class ends?"
    new "あー、そうか。授業が終わったら君の家に行くのか？"

    # say L2903 bel
    old "Uhh, actually, I will skip classes today."
    new "うーん、実は今日の授業を休むことにしたの。"

    # say L2905 bel
    old "I have to go to the girl's house now to pick her up and take her to my house."
    new "今、女の子の家に行って彼女を拾って、うちへ連れて帰るの。"

    # say L2906 bel
    old "And then I'll set up the stream and make sure that everything's ready."
    new "そしてストリームの準備をして、すべてが整っているか確認する。"

    # say L2909 bel
    old "So, don't worry, you go to class and we'll meet at my house when you're done."
    new "心配しないで、授業に行って、終わったら私の家で待ってるね。"

    # say L2914 bel
    old "You'll see, with this, I will definitely surpass Lana in the rankings for good."
    new "これで絶対にラナをランキングで抜けるわ。"

    # say L2917 bel
    old "Thanks, [pla]. Now, I'll leave, and we'll meet at my house in the afternoon."
    new "ありがとう、[pla]。それじゃ、私は行くから、午後に家で会おう。"

    # say L2938 pla
    old "Ok, I guess  I'll go to Belle's house now."
    new "じゃあ、ベルの家に行くか。"

    # say L2939 pla
    old "That's weird, I'm going to Belle's house to have a... Threesome, and with a girl I don't know..."
    new "変な話だな、ベールの家に行くのは… 三人で、しかも知らない子と…"

    # say L2940 pla
    old "This definitely escalated quickly..."
    new "これは確かに急展開だな…"

    # say L2941 pla
    old "Well, anyway, I better go quickly. I don't want to be late for Belle's stream.."
    new "まあ、とにかく早く行かなきゃな。Belleの配信に遅れたくはないな。"

    # say L2958 bel
    old "Hi [pla], thanks for coming."
    new "あたし、[pla]、来てくれてありがとう。"

    # say L2959 bel
    old "So, this is my friend Amorette, she will be joining us for today's stream."
    new "じゃあ、これは私の友達アモレットで、今日の配信に参加してくれるよ。"

    # say L2960 pla
    old "Oh... U- uhm... Hi!"
    new "オッ… ア、あの… こんにちは！"

    # say L2962 amo
    old "Hi! Nice meeting you!"
    new "こんにちは！会えて嬉しいよ！"

    # say L2964 amo
    old "So this is the guy you've been streaming with lately, Belle!"
    new "じゃあこれが最近ベルが配信で一緒にやってる男の子か！"

    # say L2965 amo
    old "I can't believe I'm actually meeting you! You know, I'm a big fan of yours."
    new "信じられないな、実際に会えて！君のファンだぞ。"

    # say L2966 pla
    old "My fan? Really?"
    new "本気でファン？"

    # say L2968 amo
    old "Of course I follow Belle's stream because she's one of the best-ranked streamers."
    new "もちろん、ベルの配信をフォローしてるよ。彼女は最高ランクの配信者の一人だからね。"

    # say L2970 amo
    old "And lately her content has been great, especially the one she's doing with you."
    new "最近彼女のコンテンツが最高でね、特に君とやってるやつさ。"

    # say L2971 amo
    old "So, I'm also a fan of yours."
    new "だから、君のファンでもあるんだよ。"

    # say L2974 amo
    old "But how couldn't I be? After all, you have that amazing cannon in between your legs."
    new "でも、そうじゃないだろ？君の足の間にあるあの素晴らしい大砲があるんだから。"

    # say L2976 amo
    old "With how long and thick it is... I know my views would skyrocket if I ever have you in one of my streams."
    new "その長さと太さを見れば……もし君を配信で紹介したら、視聴者数間違いなく爆上げだな。"

    # say L2977 pla
    old "I- Uh- Well... I- I don't know what to say..."
    new "あー、うー、えーと…… 何て言ったらいいのかわからない……"

    # say L2979 amo
    old "Oh! Look at that reaction! It's so cute, hahaha."
    new "おっ！その反応かわいいな、ははは。"

    # say L2985 bel
    old "Ok guys, everything's already set up, so we're ready to go."
    new "みんな、もう全部準備できてるから、始められるよ。"

    # say L2986 bel
    old "At first I'll be alone on camera, I'll introduce you and then you can come in Amorette."
    new "最初は私がカメラの前で一人でいるわ、自己紹介をしてからアモレッテを連れてくるから。"

    # say L2987 bel
    old "After that I'll bring you in [pla], and we can get started."
    new "その後[pla]を連れてきて、始めるわよ。"

    # say L2992 bel
    old "Great, then let's do it."
    new "じゃあ、始めようか。"

    # say L3009 bel
    old "Hey guys! It's great to see you all again!"
    new "皆さん！また会えてうれしいわ！"

    # say L3010 bel
    old "I've been waiting for today's show more than ever!"
    new "今日のショーを待ち侘びていたの！"

    # say L3011 bel
    old "Because I have yet another great surprise for you guys!"
    new "だって皆さんにまた素晴らしいサプライズがあるんだから！"

    # say L3012 bel
    old "This is something you have been asking me about! And it's finally time for you guys to enjoy it."
    new "これは皆さんからずっと聞かれていたものよ！そしてついに皆さんに楽しんでもらう时候来了。"

    # say L3013 bel
    old "So, today I have with me a friend that's going to help us."
    new "じゃあ、今日は私と一緒に特別な友達が来てくれました。"

    # say L3014 bel
    old "I know you all know her because she's very popular, so please give a warm welcome to my friend Amorette!"
    new "みんな、彼女を知ってるよね、とても人気があるから。それじゃ、友達のアモレットを暖かく迎えてあげて！"

    # say L3019 amo
    old "Hi guys! How are you?!"
    new "おっす！元気だよ？！"

    # say L3020 amo
    old "It's so nice to be here!"
    new "ここにいられるだけでうれしいな！"

    # say L3021 amo
    old "Oh, some of you know me from my stream?"
    new "お、君たちの中には俺の配信を見たことがある人もいるのか？"

    # say L3022 amo
    old "It's great to see you!"
    new "君たちに会えて嬉しいな！"

    # say L3023 amo
    old "I hope we'll have a very good time together today guys!"
    new "今日もみんなと楽しく過ごせることを願ってるよ！"

    # say L3025 bel
    old "And of course, my friend from before is also here to help us!"
    new "もちろん、前の友達も手伝いに来てくれたわ！"

    # say L3030 bel
    old "Well guys, it's time for me to tell you about the surprise I'd planned for you."
    new "皆さ～ん、私が用意したサプライズをお話しするわ。"

    # say L3032 bel
    old "And it's that today we're having a threesome!"
    new "今日三人で楽しむことになったの！"

    # say L3034 bel
    old "It's great right?"
    new "いいでしょ？"

    # say L3035 amo
    old "Yey!"
    new "やった！"

    # say L3037 bel
    old "Oh! We've all been waiting for this! Let's not delay it anymore!"
    new "あら！みんなで待っていたのよ！さあ、始めましょう！"

    # say L3038 bel
    old "So, remember to tip so that we can reach the goal!"
    new "それじゃ、チップを忘れずにね。目標に到達できるように！"

    # say L3045 amo
    old "Oh wow, just look at that dick guys!"
    new "おわ、そのチ○ポ見ろよ！"

    # say L3046 amo
    old "I saw it before on screen, but it's so much bigger in person!"
    new "画面で見たことがあるけど、実物は全然違うな！"

    # say L3047 bel
    old "It's great isn't it?"
    new "すごいよね？"

    # say L3064 bel
    old "Thanks guys, you are the best fans in the world!"
    new "ありがとう、みんな。あなたたちは世界一のファンだよ！"

    # say L3065 bel
    old "I'm very happy and proud of you!"
    new "私はとても幸せで、あなたたちに誇りに感じてるわ。"

    # say L3066 bel
    old "I hope you enjoyed this threesome as much as we did."
    new "みんなが楽しんでくれたことを願ってるわ。私たちはすごく楽しかったから。"

    # say L3068 amo
    old "Belle is right guys!"
    new "ベールの言う通りだよ、みんな！"

    # say L3069 amo
    old "That was so hot!"
    new "それ熱かったな！"

    # say L3072 amo
    old "You guys have been so nice!"
    new "みんな優しくてさ！"

    # say L3074 amo
    old "It makes me think of coming back to stream with Belle again..."
    new "それがきっかけでまたベールと配信したいなって思うんだよ…"

    # say L3076 bel
    old "I know if Amorette comes back to stream with us, we will all enjoy it!"
    new "アモレッテがまた配信に戻ってくれたら、みんな楽しむよね！"

    # say L3078 bel
    old "And of course, my friend here will be back as well!"
    new "もちろん、ここにいる友達も戻ってくるよ！"

    # say L3080 bel
    old "Well, guys, that's all for today."
    new "皆さん、今日の配信はこれでおしまいです。"

    # say L3081 bel
    old "Remember to subscribe to my profile and follow me on my social networks!"
    new "プロフィールに登録して、ソーシャルネットワークもフォローしてね！"

    # say L3082 bel
    old "And remember to follow Amorette as well."
    new "そしてアモレットもフォローしてね。"

    # say L3083 bel
    old "She does some amazing things in her stream guys!"
    new "彼女が配信でやることは本当に凄いよ、皆！"

    # say L3085 amo
    old "Thanks for the warm reception guys!"
    new "ありがとう、みんな！"

    # say L3086 amo
    old "And thank you for having me Belle."
    new "ベル、俺を呼んでくれてありがとう。"

    # say L3087 amo
    old "See you later guys!"
    new "じゃあ、またな！"

    # say L3088 bel
    old "Bye guys!"
    new "じゃあね、みんな！"

    # say L3107 bel
    old "They really reached the goal in no time!"
    new "本当にすぐに目標達成しちゃったね！"

    # say L3108 bel
    old "Thanks a lot guys! I'm amazed it all went this well. And it's all thanks to you!"
    new "ありがとう、みんな！これだけうまくいったのは本当に驚いたわ。全部あなたたちのおかげよ！"

    # say L3109 amo
    old "You're welcome Belle."
    new "どういたしまして、ベッル。"

    # say L3110 amo
    old "I'm very happy to help, and this is also good for my own stream."
    new "君のためなら喜んで手伝うよ、それにこれも自分の配信にとって良い機会だしね。"

    # say L3111 amo
    old "It's great that you managed to reach the goal."
    new "目標を達成できたのは素晴らしいね。"

    # say L3112 amo
    old "And I love that I was able to meet you [pla]."
    new "そして、君に会えて本当にうれしいんだ [pla]。"

    # say L3113 amo
    old "You definitely have to come to do one of my streams with me one of these days."
    new "絶対にいつかは俺の配信に来てくれや。"

    # say L3114 amo
    old "Just you and me, I'm sure you'll enjoy it."
    new "二人だけで、きっと楽しむよ。"

    # say L3115 pla
    old "Uhh... Sure."
    new "うーん…そうだな。"

    # say L3116 bel
    old "Ok, that's great."
    new "そうね、それはいいね。"

    # say L3117 bel
    old "Guys, my mom's coming home soon."
    new "みんな、私のママがすぐ帰ってくるからね。"

    # say L3118 bel
    old "So it would be better if you go."
    new "じゃあ、早めに帰った方がいいね。"

    # say L3121 amo
    old "Thanks again for having me Belle."
    new "また来させてくれてありがとう、ベール。"

    # say L3122 amo
    old "I'll see you later."
    new "後でな"

    # say L3131 pla
    old "I guess I'll see you later then."
    new "じゃあ、後でな。"

    # say L3132 bel
    old "Of course, thank you, [pla]."
    new "もちろん、ありがとう、[pla]。"

    # say L3133 bel
    old "I'm sure that with this, I can surpass Lana in the voting."
    new "これでラナを投票で上回れる自信があるわ。"

    # say L3134 bel
    old "And it's all because of you."
    new "それ全部あなたのおかげよ。"

    # say L3135 pla
    old "Don't mention it, I know you've worked hard for it, so you deserve to win it."
    new "気にするな、君の努力は見逃せないから、勝つのは当然だよ。"

    # say L3136 pla
    old "And I'm sure you will."
    new "君が勝つことは間違いないよ。"

    # say L3137 bel
    old "Thank you so much, [pla]!"
    new "ありがとう、[pla]！"

    # say L3138 pla
    old "Alright, I'll get going then. See you later."
    new "じゃあ、行ってくるよ。後でな。"

    # say L3154 pla
    old "Ok! I think I managed to finish it all."
    new "Ok！ 全部終われたと思う。"

    # say L3156 ash
    old "That's great [pla]!"
    new "うれしいね [pla]！"

    # say L3157 ash
    old "Can you show me?"
    new "見せて？"

    # say L3161 pla
    old "Here, this is the homepage, in here I just left information about the business."
    new "ここがホームページで、ここには事業に関する情報を載せている。"

    # say L3162 pla
    old "Their history and stuff."
    new "その歴史とかね。"

    # say L3164 pla
    old "If you press here it will take you to the menu."
    new "ここを押すとメニューに移動するよ。"

    # say L3166 pla
    old "If you wish to make an order to pick up in advance, you can place it here."
    new "事前に受け取る注文はここで入れられるよ。"

    # say L3167 pla
    old "There's also an option for you to customize your order."
    new "注文をカスタマイズすることもできるんだ。"

    # say L3168 ash
    old "Oh! I see!"
    new "お！わかった！"

    # say L3170 pla
    old "Yeah, you can even select the coffee by level of roasting."
    new "そうだな、焙煎のレベルまで選べるんだ。"

    # say L3171 pla
    old "Or you can even select the region where it comes from."
    new "あるいは、そのコーヒーの産地を選んでもいいんだ。"

    # say L3173 ash
    old "This is really good work [pla]."
    new "これ本当にいい仕事してるね [pla]。"

    # say L3174 ash
    old "This is better than what I have seen some professional web developers do."
    new "これ、プロのウェブ開発者よりも上手いな。"

    # say L3176 ash
    old "I know you're not looking for a job right now."
    new "今すぐ仕事探してないって知っててよ。"

    # say L3177 ash
    old "Because you have to do things with school and stuff."
    new "学校のことで忙しいからね。"

    # say L3179 ash
    old "But if you ever want to get into web developing, just let me know."
    new "でも、もしウェブ開発に興味を持ったら、教えてね。"

    # say L3180 ash
    old "I'm sure I'll be able to get you something good."
    new "きっといいもの見つけてあげられるよ。"

    # say L3182 ash
    old "Also, if I ever need your help, I'll let you know."
    new "もちろん、私が何か手伝ってほしいと思ったら、あなたに言うわ。"

    # say L3184 ash
    old "Maybe you can give me a hand with something."
    new "手伝ってくれないかな。"

    # say L3185 pla
    old "For sure! If I can help you with anything, just tell me, I'll do my best to help you any time I can."
    new "もちろん！何か手伝えることがあったら教えて、いつでも全力で手伝うよ。"

    # say L3191 pla
    old "I guess I'll leave for now Ashley. But I guess I'll see you later."
    new "じゃあ、今から帰るけど、また後でな、アシュリー。"

    # say L3196 ash
    old "Wait [pla]."
    new "待って [pla]。"

    # say L3198 pla
    old "Yes ma'am?"
    new "はい、どうした？"

    # say L3199 ash
    old "Before you leave, I just wanted to take a second to thank you for all the help you've given me these days."
    new "去る前に、ちょっとだけ感謝の言葉を伝えたくなったの。最近のことで、あなたがくれた助けに本当に感謝してるの。"

    # say L3201 ash
    old "I was in a very difficult situation, and with your help, I was able to solve it even better than I expected."
    new "私はとても難しい状況にいたのだけれど、あなたの助けのおかげで、予想以上によく解決することができたの。"

    # say L3202 pla
    old "I just wanted to help you, I'm happy I was able to do something."
    new "ただ君を助けるためだった、何かできたことが嬉しいよ。"

    # say L3203 ash
    old "And you really did, you're welcome here at our home any time you need."
    new "あなたが本当にそうしてくれて、私たちの家はいつでもあなたが来てもいいよ。"

    # say L3205 ash
    old "So thanks again [pla], I hope I'll see you again soon."
    new "またありがとう、[pla]。また会えるのを楽しみにしてるわ。"

    # say L3207 pla
    old "Sure ma'am, I'm sure we'll see each other soon."
    new "うん、また近いうちに会おうね。"

    # say L3208 pla
    old "Bye for now then."
    new "じゃあ、またな。"

    # say L3209 ash
    old "Bye [pla]."
    new "バイ [pla]。"

    # say L3230 pla
    old "Why do you look so down?"
    new "どうしてそんな落ち込んでるの？"

    # say L3232 bel
    old "Nothing bad, I'm just a little nervous."
    new "何も悪いことじゃない、ちょっと緊張してるだけ。"

    # say L3236 bel
    old "Well, the results of the voting are coming out today."
    new "ええ、投票の結果が出る日だね。"

    # say L3238 pla
    old "Already? It didn't take any time."
    new "もう？そんなに早かったのか。"

    # say L3240 bel
    old "The contest was a bit longer. It's just that when we started streaming, we were already close to the deadline."
    new "コンテストは少し長かったけど、ストリーミングを始めた頃にはもう締め切りが近づいていたから。"

    # say L3242 pla
    old "Well, I hope that all the streaming we did helped you win."
    new "まあ、ストリーミングが君の勝ちに役立ったといいな。"

    # say L3244 bel
    old "I don't know, I checked the voting before I went out today. Me and Lana were neck and neck."
    new "あたしもよくわからないけど、今日出かける前には投票状況を見たのさ。あたしとラナはほぼ同点だったの。"

    # say L3245 bel
    old "I haven't seen anything else, I'll check it as soon as I get home."
    new "他には何も見てないわ、家に帰ったら確認するね。"

    # say L3246 bel
    old "So, I wanted to know if you want to accompany me this afternoon to check the results."
    new "じゃあ、今午後に一緒に結果を見に行かない？"

    # say L3248 pla
    old "Sure, I'll come with you."
    new "もちろん、一緒に行くよ。"

    # say L3249 bel
    old "Thank you [pla]. We can go to my house right after classes and check it."
    new "ありがとう、[pla]。授業が終わったら私の家に来て、結果を見よう。"

    # say L3250 pla
    old "For sure, let's go to class for now, and I'll come to your house with you when we're done."
    new "もちろん、まずは授業に行こう。終わったら君の家に行くよ。"

    # say L3281 bel
    old "I can't wait to see the results, but I'm also so nervous!"
    new "結果を見るのが待ち遠しいけど、すごく緊張してるの。"

    # say L3282 pla
    old "Don't worry, everything will be fine. Let's get going so we can see the results at your place."
    new "心配しなくていい、大丈夫だよ。さ、行こう。結果を見に君のところに行こうじゃないか。"

    # say L3283 bel
    old "Yes, yes, you're right... Let's go. I'll feel calmer there."
    new "はい、はい、そうね… 行こう。そこなら落ち着けるわ。"

    # say L3296 bel
    old "Ok, let's check how this all turned out."
    new "じゃあ、これの結果を見てみましょう。"

    # say L3302 pla
    old "You did?!"
    new "本当にやったのか？！"

    # say L3303 pla
    old "That's great Belle! Congrats!"
    new "ベル！おめでとう！"

    # say L3305 bel
    old "Thank you so much [pla]!"
    new "ありがとうずいぶん、[pla]！"

    # say L3307 bel
    old "This is all thanks to you!"
    new "これ全部君のおかげだよ！"

    # say L3308 pla
    old "What?! This is all because of you! You're the one that has been doing all the hard work."
    new "何だって！？これは全部君のおかげだよ！君がずっと頑張ってくれたんだな。"

    # say L3309 pla
    old "Really Belle, congrats, you deserve this."
    new "本当にそう言ってくれてありがとう、ベ儿。君が頑張ってくれたからこそだよ。"

    # say L3311 bel
    old "Well, it was impossible without you."
    new "あなたがいなければ無理だったわ。"

    # say L3312 bel
    old "I have no way of repaying you [pla], this is just so great."
    new "私にはあなたに恩返しの方法がないわ [pla]、こんなに素晴らしいことはない。"

    # say L3314 pla
    old "Really Belle, congratulations, you deserve that victory. And I'm happy I was able to help you. It makes me very happy."
    new "本当にそう思うよ、ベール。君が勝つべきだったし、手伝えてうれしいよ。これで俺も幸せだ。"

    # say L3329 bel
    old "What do you mean by 'what's going on here?' And why are you barging into my room as if it's yours?"
    new "何を言ってるの？それに、どうして私の部屋に勝手に入ってくるの？"

    # say L3335 ash
    old "What the hell is happening?!"
    new "何が起こってるの？！"

    # say L3337 bel
    old "Woah, woah, woah, where did you get that from?!"
    new "Woah、woah、woah、どこでそんなこと聞いたの？！"

    # say L3340 ash
    old "A coworker showed it to me! He caught his son using his credit card to send money to you on this website."
    new "同僚が見せてくれたの！息子がクレジットカードを使って、このサイトで君にお金を送ってるところを捕まえたんだって。"

    # say L3342 ash
    old "He recognized you and decided to ask me if this was you!"
    new "彼は君を認めて、これが君なのか私に聞くことにしたの！"

    # say L3344 ash
    old "Oh my gosh Belle! What the hell are you doing?"
    new "ベル！何やってるの？"

    # say L3346 ash
    old "Why are you asking for money from strangers on the internet?"
    new "インターネットで知らない人に金をねだってるの？なぜ？"

    # say L3348 ash
    old "If you needed money you could've told me!"
    new "お金が必要なら教えてくれればよかったのに！"

    # say L3350 ash
    old "And doing it this way! Oh my god!"
    new "こんな方法で！　神様！"

    # say L3352 bel
    old "Wait a minute, what do you mean by {i}'doing it this way{/i}'?"
    new "ちょっと待って、{i}こんな方法でやってる{/i}ってどういう意味？"

    # say L3354 bel
    old "First of all, I'll let you know I'm not doing it for the money!"
    new "まずは、私がお金を目当てにしていないってことをはっきりさせておくわ！"

    # say L3357 bel
    old "I'm doing it because I like it."
    new "私はこれをしてるのを好きだからよ。"

    # say L3360 bel
    old "But even if I was doing it for money. What's wrong with me doing something like that?"
    new "でも、仮にお金のためにやってたとしても、それが何が悪いの？"

    # say L3362 bel
    old "You're the one who's always telling me that I should just live my sexuality any way I can."
    new "あなたがいつも言ってるじゃない、自分の性を自由に生きるべきだって。"

    # say L3364 bel
    old "And that I shouldn't care about what people have to say about me."
    new "そして、他人の言うことに気を遣う必要はないって言ってるじゃない"

    # say L3367 ash
    old "That isn't the problem here!"
    new "それが問題じゃないのよ！"

    # say L3369 ash
    old "You know that I'm just taking over my new role in the company!"
    new "新しい役職を引き継いでるってこと知ってるでしょ！"

    # say L3371 ash
    old "Imagine how I felt when my coworker told me his son is stealing money from him to give to my daughter for being naked online!"
    new "想像してみてよ、同僚が息子がお金を盗んで私の娘にオンラインで裸になるために使ってるって言ったときの私の気持ちを。"

    # say L3372 ash
    old "This could bring problems to my image as the branch director of the company. The executives could fire me!"
    new "これじゃ会社の支店長としての私のイメージが損なわれるわ。経営陣に首を切られるかもしれない！"

    # say L3374 bel
    old "And what do you want me to do? To not do it just because those assholes at your job might think bad about it?"
    new "それじゃあ私が何をすればいいの？　ただ会社のクソ野郎たちが悪く思うからやめろってこと？"

    # say L3377 bel
    old "I'm sorry but I'm not doing that."
    new "ごめん、でも私はそれはしないよ。"

    # say L3379 ash
    old "Oh my gosh could you be any more selfish?!"
    new "信じられない、もっと自己中心的になれるの？"

    # say L3380 pla
    old "Ok, ok, why don't you two try to talk about this in a calmer way?"
    new "よしよし、二人とも落ち着いて話してみてはどうだ？"

    # say L3381 pla
    old "Before either of you says anything that you may regret."
    new "二人とも、後悔するようなことを言う前に、落ち着いて話し合ってみよう。"

    # say L3385 ash
    old "I was thinking about who's the person in the video with Belle! It's you isn't it?"
    new "あのビデオに出ていたのは誰か考えてたの！ あなたじゃない？"

    # say L3387 ash
    old "I'm so stupid!"
    new "私はばかだったな…"

    # say L3389 ash
    old "Here I was thinking that you were just a good friend of Belle!"
    new "私がベッ-Lifeにただの友達だと思ってたの！"

    # say L3390 ash
    old "Someone whom I could trust, and here doing this!"
    new "信じていたのに、こんなことになっちゃった！"

    # say L3391 ash
    old "And in my house, of all places!"
    new "そして、私の家でそんなことするなんて！"

    # say L3393 bel
    old "Wait a minute! Don't involve him in this!"
    new "ちょっと待って！彼を巻き込まないで！"

    # say L3394 bel
    old "He was just helping me, and it's something that I wanted to do and there's nothing wrong with it!"
    new "彼はただ私を助けてくれただけで、私がやりたかったことだから、何も問題ないんだよ！"

    # say L3396 ash
    old "Oh yeah? Well, I'm sorry you want to do it so badly because you're about to stop!"
    new "そう？でも君がそれほどやりたいなら、今すぐ止めるわ！"

    # say L3397 ash
    old "I already told you, the people at my company are not okay with this!"
    new "もう言ったでしょ、うちの会社の人たちはこれには反対してるんだよ！"

    # say L3399 ash
    old "So, unless whatever money you're making with that is enough for you to pay for everything around here!"
    new "だから、その金でここ的一切を賄えるなら別だけど！"

    # say L3400 ash
    old "You're about to stop with this weird little hobby of yours!"
    new "この変な趣味をやめるつもりなのか！"

    # say L3402 bel
    old "You have to be kidding me!"
    new "冗談じゃない！"

    # say L3403 bel
    old "Well I'm sorry, but I'm not going to stop doing anything! And if you don't like me doing it in your house then I guess I can leave!"
    new "ごめんね、でもやめるつもりはないの！それに、私が君の家でやってることが気に入らないなら、出るわ！"

    # say L3405 ash
    old "Then I guess you can!"
    new "じゃあ、そうしなよ！"

    # say L3407 bel
    old "I'll do it then!"
    new "じゃあ、私がやるわ！"

    # say L3415 pla
    old "Wait! Belle!"
    new "待て！ベール！"

    # say L3419 pla
    old "I- uh..."
    new "俺ー、あの…"

    # say L3420 pla
    old "I- I'm sorry!"
    new "俺ー、ごめん！"

    # say L3445 bel
    old "Hey, I guess I'm doing ok."
    new "まあ、私なりにやっていってるみたい。"

    # say L3447 bel
    old "I left my mom's house, so at least she's not annoying me or anything."
    new "家を出てきたから、少なくとも母に迷惑かけてないわ。"

    # say L3448 pla
    old "W- what? You actually left your home?"
    new "待って待って、本当に家を出たの？"

    # say L3450 bel
    old "I did, what else was I supposed to do?"
    new "そうよ、他に何をすべきだったの？"

    # say L3451 bel
    old "I'm not going to stop streaming just to give her the pleasure."
    new "私は彼女が喜ぶためにストリーミングをやめるつもりはないわ。"

    # say L3452 bel
    old "This is too important for me, no matter what she says."
    new "これは私にとって重要すぎるから、彼女の言うことなんて関係ないよ。"

    # say L3454 pla
    old "I see, I'm sorry Belle; I feel like I caused this."
    new "なるほど、ごめん Belle、俺が原因になったみたいだな。"

    # say L3455 bel
    old "Don't worry, this isn't your fault. It was bound to happen sooner or later."
    new "心配しないで、あなたのせいじゃないよ。いつかは起こる運命だったんだから。"

    # say L3456 pla
    old "I guess."
    new "まあ。"

    # say L3457 pla
    old "So, where are you staying now?"
    new "じゃあ、今どこに住んでるの？"

    # say L3459 bel
    old "I'm staying at Amorette's apartment."
    new "アモレットのアパートに住んでるの。"

    # say L3460 bel
    old "It's really nice because she has an entire room where we can stream."
    new "そこが本当にいいの。彼女は専用の部屋があって、そこで配信できるの。"

    # say L3461 bel
    old "By the way, she says that you're welcome to come to visit anytime you want."
    new "それに、彼女はいつでも遊びに来てもいいって言ってたわ。"

    # say L3462 pla
    old "I see... Well, thank you I guess."
    new "なるほど… まあ、ありがとうってことか。"

    # say L3463 pla
    old "Leaving aside her offer."
    new "彼女のお誘いはさておき。"

    # say L3465 pla
    old "I hope things will be fixed between you and your mom soon."
    new "君とお母さんの関係が早く上手くいくことを望んでるよ。"

    # say L3467 bel
    old "Thanks... But I wouldn't count on it."
    new "ありがとう……でも、期待はしてないわ。"

    # say L3468 bel
    old "Listen, I have a couple of things to do now, so I'll see you later, ok?"
    new "ちょっと今から用事があるから後でね、いい？"

    # say L3469 pla
    old "Yeah, see you."
    new "うん、またね。"

    # say L3475 pla
    old "Damn, things between them really went out of whack."
    new "二人の関係、ほんとに行き違いになっちまったな。"

    # say L3476 pla
    old "Maybe I could do something to help them."
    new "何か手伝えることがないかな。"


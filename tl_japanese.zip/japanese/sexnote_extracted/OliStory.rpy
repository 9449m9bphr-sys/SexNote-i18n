# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/OliStory.rpy
translate japanese strings:

    # say L8 oli
    old "Did you see my notes report?!"
    new "私のノートのレポート、見た？！"

    # say L12 oli
    old "You're a fucking moron!"
    new "あなたってほんとクソバカだね！"

    # say L14 oli
    old "{i}'Oh yeah, I know all the topics, I'll for sure help you get better...'{/i}"
    new "{i}ああ、もちろん。全部のトピック知ってて、君の成績上げる手伝いするから安心しなさい…{/i}"

    # say L16 oli
    old "{b}*Sigh*{/b} Honestly..."
    new "{b}*ため息*{/b} 正直に言えば…"

    # say L23 mik
    old "B- but, I- I really did teach you what was needed for the exam... I mean, I did well..."
    new "でも、試験に必要なことはちゃんと教えてやったぞ… つまり、俺はちゃんとやってるつもりだよ…"

    # say L24 oli
    old "Are you suggesting that I'm dumb? Or that it was my fault?"
    new "あなたが私を馬鹿だと思うのか、それとも私のせいにするつもりなのか？"

    # say L25 mik
    old "No, no, what I'm saying is that..."
    new "いや、違うんだ、言いたいのは……"

    # say L44 oli
    old "You assured me that if I spent time with you and let you do 'that' to me..."
    new "あなたは私に、あなたと時間を過ごして、あなたに『それ』をさせてあげたら…"

    # say L47 oli
    old "... You were going to help me pass the exams."
    new "……あなたが試験に合格する手助けをしてくれるって約束したじゃない。"

    # say L48 oli
    old "But I ended up failing anyway!"
    new "でも結局、落ちちゃったんだよ。"

    # say L51 oli
    old "If you didn't actually understand the subjects, you could've just told me that..."
    new "分かってなかったら、最初から言ってくれればよかったのに..."

    # say L52 oli
    old "That way I wouldn't have wasted my time with you."
    new "そうすれば、私の時間も無駄にしなくて済んだのに。"

    # say L53 mik
    old "But I don't know what happened, I explained it to you just like [pla] did with m-..."
    new "でも、何が起きたのかわからない、俺は君に[pla]が説明したのと同じように説明したつもりだったんだよ..."

    # say L56 oli
    old "What? [pla]? What does he have to do with all this?"
    new "何？[pla]？彼がこれに関わってるってどういうこと？"

    # say L58 mik
    old "N- nothing, nothing, I meant that I also helped him and he had a good result on the exam..."
    new "な- 何も、ただ彼も手伝ってあげて、テストで良い結果が出ただけって意味だよ…"

    # say L60 mik
    old "Maybe you just didn't understand the topics I explained well."
    new "もしかして、俺が説明したトピックをちゃんと理解できなかったのかもしれないな。"

    # say L79 pla
    old "Hey man... That sounded rough. What's going on?"
    new "おい、なんだよ… それってきつかったな。何 happened？ どうしたんだ？"

    # say L81 mik
    old "Apparently, she did really poorly on the last set of exams we took."
    new "どうやら彼女は先日のテストでかなり悪い点を取ったらしい。"

    # say L83 mik
    old "And now she's blaming me!"
    new "そして今、それが俺のせいだって言ってるんだよ！"

    # say L84 mik
    old "Like it's my fault..."
    new "俺のせいにするのか…"

    # say L86 pla
    old "Well, you did promise her you'd help her with her exams."
    new "まあ、君は彼女が試験で手伝ってほしいって言った時、約束したんだろ。"

    # say L87 pla
    old "But you didn't really follow through..."
    new "でも、ちゃんと履行しなかったじゃん。"

    # say L89 mik
    old "W- well, t- that's just because..."
    new "まあ、それはただ……"

    # say L91 mik
    old "I don't know, man, I really helped her!"
    new "俺は本当に彼女を助けてやったんだよ、マジで！"

    # say L92 mik
    old "I- I mean, I even got good grades, man!"
    new "俺は成績も良かったんだよ、マジで！"

    # say L93 pla
    old "Well, yeah, but it doesn't matter how well you did."
    new "まあ、そうだよ、でもどれだけ頑張ったかじゃなくて、彼女がどうだったかが重要なんだよ。"

    # say L94 pla
    old "What matters is that she didn't do well."
    new "大事なのは、彼女がうまくできなかったことだ。"

    # say L96 pla
    old "I think you just didn't know how to explain the subjects to her."
    new "俺は君が彼女に科目の説明の仕方を教えてあげられなかったんじゃないかと思う。"

    # say L97 mik
    old "Alright! You don't have to repeat what she said!"
    new "分かってるよ！彼女の言ったことを繰り返す必要ないだろ！"

    # say L99 mik
    old "Besides, I don't think you get to say anything to me, this is your fault after all."
    new "それに、お前が何か言う資格なんてないよ、これ全部お前のせいだしな。"

    # say L100 pla
    old "Excuse me? What's that supposed to mean?"
    new "何言ってんだ？その意味は？"

    # say L101 mik
    old "What I said! You were supposed to explain the subjects to me so that I could help Olivia!"
    new "言ったじゃん！お前が科目の説明をすべきだったんだよ、そうすればオルiviaも助かったのに！"

    # say L103 mik
    old "But look at the results she got."
    new "でも見てみろよ、あの成績さ。"

    # say L105 pla
    old "That has nothing to do with me!"
    new "それ俺には関係ないよ！"

    # say L106 pla
    old "If she didn't learn anything, it's just because you're such a shit teacher!"
    new "もし何も学んでないなら、それはお前がクソな教師だからだよ！"

    # say L108 pla
    old "Maybe you should've taught her properly instead of spending your time staring at her tits."
    new "お前がちゃんとして教えてやれば良かったんだよ、彼女の胸見ながら時間潅すんじゃねえよ。"

    # say L110 mik
    old "Yeah well, whatever the reason is, she's super angry with me now."
    new "まあ、理由はなんであれ、今じゃ彼女は俺のことめちゃくちゃ怒ってるよ。"

    # say L112 mik
    old "If she fails the coming exams, that's going to really suck, man."
    new "もし彼女が次の試験に落ちたら、ほんとにつらいよ、な。"

    # say L113 pla
    old "Well, it would be bad, but she'll have other chances to pass."
    new "まあ、悪いけど、他のチャンスはあるだろう。"

    # say L115 mik
    old "What? That's not what I mean, dude."
    new "何？　それ違うだろ、兄貴。"

    # say L117 mik
    old "If she fails, she'll just blame me, and I won't be able to move forward with her."
    new "もし落ちたら、俺のせいにするだろうし、一緒に進むことができなくなるぞ。"

    # say L119 mik
    old "I'm so close to hooking up with her, dude, so close."
    new "俺はもう彼女とヤべそうだったんだ、兄貴。"

    # say L120 mik
    old "She was just about to let me hit it, and now this."
    new "彼女がもうすぐ本気で讓我來一下、結果こうなっちまった。"

    # say L121 pla
    old "... Sure, dude."
    new "...まあ、いいだろう、兄貴。"

    # say L126 pla
    old "Hey, come on, let's go to class."
    new "おい、さあ、授業行こ。"

    # say L127 pla
    old "You can keep worrying about this later."
    new "後で心配すればいいさ。"

    # say L129 mik
    old "Yeah... Okay."
    new "うん… 分かった。"

    # say L160 oli
    old "Hey [pla]! Wait!"
    new "Hey [pla]！待って！"

    # say L171 pla
    old "Uh, yeah? Do you need something?"
    new "うん、何？何か用？"

    # say L174 oli
    old "Yeah, I need to talk to you about something."
    new "うん、ちょっと話があるの。"

    # say L175 pla
    old "Uh... Alright, what is it?"
    new "うーん… 分かった、何なんだ？"

    # say L177 oli
    old "Well, as you probably already know."
    new "まあ、あなたもすでに知ってるかもしれないけど。"

    # say L179 oli
    old "I've been having some problems with my grades lately."
    new "最近、成績が芳しくないの。"

    # say L180 pla
    old "Hmph, I mean... I haven't really paid attention to what you've been doing or anything..."
    new "ふん、つまり……君のことをちゃんと見てなかったってことさ。"

    # say L182 oli
    old "Oh please, don't pretend you haven't talked with that dumbass Mike."
    new "お願い、マイクのアホなこと話してないふりしないでよ。"

    # say L183 oli
    old "I know he told you about him giving me lessons in the subjects I'm failing, so don't play dumb."
    new "ミケが私に落ちてる科目の補習を教えてること、君にも話したって知ってるんでしょ？だからバカなふりしないでよ。"

    # say L185 pla
    old "Well, he did mention something about that."
    new "まあ、そんなことは言ってたな。"

    # say L186 pla
    old "But what about it?"
    new "でもそれについてどうしたって？"

    # say L188 oli
    old "The thing is, I haven't really learned much of anything."
    new "問題は、ほとんど何も学んでいないのよね。"

    # say L189 oli
    old "Because he's so fucking bad at teaching!"
    new "だって彼の教え方が全然ダメだから！"

    # say L191 oli
    old "But on the last exams, I did notice his grades got better."
    new "でも、最後のテストでは成績が良くなったことに気づいたの。"

    # say L193 oli
    old "I thought that was strange, very strange."
    new "それがとても不思議だと思ったの。"

    # say L195 oli
    old "While spending time with him, I realized he's not the brightest guy."
    new "彼と過ごしているうちに、彼がそんなに頭がいいわけじゃないって気づいたの。"

    # say L197 oli
    old "Actually, he's a fucking idiot!"
    new "実は、彼はほんとクソバカだよ！"

    # say L199 pla
    old "Okay, okay, but what does this have to do with me?"
    new "分かってる、分かってるけど、それと俺に何の関係があるんだ？"

    # say L201 oli
    old "As I told you, spending time with your friend made me realize he's a fucking idiot."
    new "私が言った通り、あなたの友達と過ごした時間で、彼がほんとによくない馬鹿だと気づいたの。"

    # say L203 oli
    old "It just didn't make sense to me that he would suddenly make such an improvement in his grades."
    new "急に成績が良くなったのが、私には全然納得いかなかったの。"

    # say L205 oli
    old "So, I met him under the pretense that it was a date."
    new "だから、デートのフリをして会ったの。"

    # say L207 oli
    old "And I pushed him until he spilled the beans about how he'd suddenly managed to get good grades in the exams."
    new "そして、彼が急に成績を上げられた理由を吐露するまで追い詰めたの。"

    # say L209 oli
    old "After a while, he confessed that he wasn't any good at studying."
    new "しばらくすると、彼は勉強が得意じゃないって打ち明けたの。"

    # say L211 oli
    old "But that it was thanks to YOU that he was able to get better grades."
    new "でも、それが君のおかげで成績が上がったってさ。"

    # say L212 pla
    old "T- that's what he told you?"
    new "え、そう言ったんだ？"

    # say L213 oli
    old "He did! And I should've known from the start that his grades didn't get better because of him!"
    new "そうよ！ それに最初から彼の成績が上がったのは彼自身の力じゃないって気づくべきだったわ！"

    # say L215 oli
    old "But anyway, that's not what I care about."
    new "でも、それよりも私が気になるのは別のことだ。"

    # say L217 oli
    old "Because I'm still stuck with my bad grades."
    new "成績が悪いままだからさ。"

    # say L219 oli
    old "I got to thinking about it."
    new "考えちゃったの。"

    # say L225 oli
    old "Well, if you were able to teach that dumbass Mike enough to get good scores on the exams."
    new "まあ、あのバカのマイクにまで良い点数を取れるくらい教えてくれたんだから。"

    # say L227 oli
    old "You should be more than capable of bringing me to the top of the class."
    new "あなたなら私をクラスのトップに連れて行くのは余裕でしょう。"

    # say L229 pla
    old "Yeah, I mean, thanks for the compliment."
    new "まあ、誉めてくれてありがとう。"

    # say L231 pla
    old "But, why would I do that?"
    new "でも、なんでそんなことするんだ？"

    # say L235 pla
    old "In case you don't remember, every time you and Ruby are around."
    new "君が覚えてないかもしれないけど、Rubyがいるたびにね。"

    # say L236 pla
    old "You attack and bully my friends and me. The only thing you know how to do is be rude to us."
    new "お前らはいつも俺と友達を攻撃して虐めるだけだ。失礼なことしか知らないくせに。"

    # say L238 pla
    old "Especially towards Belle and Hinn."
    new "特にベールとヒンに対してさ。"

    # say L240 pla
    old "So no, I think I'll pass."
    new "だからな、パスするか。"

    # say L245 oli
    old "So that's how it is... Either way, you HAVE to help me whether you like it or not."
    new "そうなのか… どちらにしても、君は好きでも嫌いでも手伝ってもらうしかないの。"

    # say L247 pla
    old "And why would that be?"
    new "なぜそうなるんだ？"

    # say L249 oli
    old "I'll tell you why."
    new "理由を言うわ。"

    # say L253 oli
    old "You better help me, or I'll spill what I know."
    new "手伝ってくれないと私が知ってることをバラしちゃうわよ。"

    # say L254 oli
    old "And everyone will know just what kind of guy you are and the stuff you’re up to."
    new "みんなが君がどんな男なのか、そして君が何をしているのかを知ることになるわ。"

    # say L265 pla
    old "But I want to make something clear."
    new "でも、一つはっきりさせておこう。"

    # say L267 pla
    old "If I do this, you can't bring it up ever again, no matter what."
    new "もし俺がこれをするなら、どんな状況でも後で絶対に持ち出さないでくれ。"

    # say L269 pla
    old "SO, after I'm done helping you, you can't tell anyone about it!"
    new "だから、俺が手伝い終わったら、誰にも言っちゃダメだよ！"

    # say L271 pla
    old "Are we clear?"
    new "分かってるな？"

    # say L272 oli
    old "Sure, I don't care about you or what you're doing."
    new "もちろん、あなたのことなんて興味ないわ。"

    # say L273 oli
    old "So I won't tell anyone."
    new "だから誰にも言わないよ。"

    # say L275 oli
    old "But that's only if I do well on the exams."
    new "でも、それは試験で良い成績を取れればの話よ。"

    # say L277 oli
    old "So you better outdo Mike, for your own sake."
    new "だからマイクよりはよくしなきゃね、自分のためのために。"

    # say L280 pla
    old "Hmph, sure."
    new "ふん、そうか。"

    # say L282 pla
    old "So... Should I go to your house?"
    new "じゃあ……君の家に行こうか？"

    # say L283 oli
    old "No, today's not a good day."
    new "今日はちょっと都合が悪いの。"

    # say L285 oli
    old "There are a couple of things I have to deal with at home."
    new "家で処理しないといけないことがいくつかあるの。"

    # say L286 oli
    old "Just keep your schedule open for now, and I'll let you know when we can start."
    new "今のところスケジュールは空けておいて、始められるタイミングになったら連絡するから。"

    # say L287 pla
    old "Hmm, alright..."
    new "うーん、そうか…"

    # say L289 oli
    old "Ok, see you later then. Bye."
    new "じゃあ、またね。バイバイ。"

    # say L297 pla
    old "{b}*Sigh*{/b} This is something I wasn't expecting."
    new "{b}*ため息*{/b} これは予想外の展開だな。"

    # say L298 pla
    old "What a fucking situation this is..."
    new "この状況はマジでクソだな…"

    # say L301 pla
    old "{b}*Sigh*{/b} I guess I'll head home."
    new "{b}*ため息*{/b} まあ、家に帰るか。"

    # say L313 pla
    old "Oh, h- hi dude, what's up?"
    new "お、ひ、ひい、どうした？"

    # say L315 mik
    old "I'm alright, but hey, don't dodge the question."
    new "俺は大丈夫だけど、質問から逃げないでくれ。"

    # say L317 mik
    old "What were you doing talking to my girl?"
    new "お前が俺の彼女と何してたんだ？"

    # say L319 mik
    old "Are you trying to snatch her from me?"
    new "お前、俺の彼女を横取りしようとしてんのか？"

    # say L320 pla
    old "{i}(Snatch her from him? So... He still thinks he has a chance with her? Is he serious?){/i}"
    new "{i}(彼女を奪うつもりか？そう……まだ彼女と付き合うチャンスがあると思ってるのか？本気なのか？){/i}"

    # say L321 pla
    old "It's not what you think, dude. She was just asking me for my notes from class."
    new "お前が思ってるようなことじゃないぜ、兄貴。彼女はただ授業のノートを借りたいって言ってただけさ。"

    # say L324 pla
    old "Well, I think she just wants to do some extra studying, and she asked for my notes."
    new "まあ、彼女はただ追加で勉強したいだけだと思うんだ。だから俺のノートを借りたってだけさ。"

    # say L326 mik
    old "And why your notes? She could've asked for mine..."
    new "なぜ俺のノート？ 彼女は他の人のノートを借りても良かったんじゃないか？"

    # say L327 pla
    old "Your notes? Do you even have any notes?"
    new "お前ノート持ってるのか？"

    # say L329 pla
    old "Did you even bring a notebook today?"
    new "今日ノート持ってきたのか？"

    # say L331 mik
    old "Well, I- I didn't."
    new "まあ、持ってこなかったな。"

    # say L332 mik
    old "I understand, dude, but still, I hope you're not thinking of using this to take my girl away from me!"
    new "分かってるけど、それでも俺の彼女を奪おうとしてるんじゃないだろうな！"

    # say L333 pla
    old "Don't worry, dude..."
    new "心配するな、マジで..."

    # say L334 pla
    old "I assure you that's not on my mind."
    new "安心しろ、そんな気は全くない。"

    # say L336 mik
    old "Alright, I'll believe you."
    new "わかった、信じるよ。"

    # say L337 mik
    old "We're pretty close, you know?"
    new "俺たち、結構仲いいだろ？"

    # say L338 mik
    old "In no time she'll be mine, don't doubt it."
    new "すぐに彼女は俺のものになる、心配すんな。"

    # say L339 pla
    old "Sure dude, no doubt..."
    new "そうだよ、心配すんな。"

    # say L345 pla
    old "Anyway, I have to go home now, are you leaving too?"
    new "まあ、俺も帰らなきゃならないんだけど、お前も帰るのか？"

    # say L347 mik
    old "Yeah sure, let's go."
    new "そうだな、行こう。"

    # say L375 pla
    old "Oh, damn, I'm really late. Has the class already ended?"
    new "ああ、しまった、本当に遅刻しちゃった。授業はもう終わったのか？"

    # say L395 rub
    old "Oh, look who decided to show up. Class ended a while ago, dumbass."
    new "あら、来たわね。授業はとっくに終わってるわよ、バカ。"

    # say L396 pla
    old "Oh crap, I totally lost track of time..."
    new "クソ、完全に時計を見失っちゃったよ..."

    # say L397 rub
    old "Really? I hadn't noticed. It's not like anyone wants to see your ugly face around here."
    new "本当に？気づかなかったわ。あなたの醜い顔を見たいって人はここにいないわよ。"

    # say L398 pla
    old "{b}*Sigh*{/b} Really? Do you want to do this now?"
    new "{b}*ため息*{/b} 本当に？今そんなことやってる時間ないんだよ。"

    # say L399 rub
    old "What? Not feeling brave without your little friends around?"
    new "何？友達がいないと勇気が出ないの？"

    # say L401 pla
    old "You know? I don't have time to deal with you right now."
    new "知ってる？今、君のことなんて相手にする時間ないんだ。"

    # say L411 rub
    old "Can you believe that loser?"
    new "信じられないわ、あんな負け犬。"

    # say L412 oli
    old "Yeah... What an idiot."
    new "そうね… ほんとバカだよね。"

    # say L413 oli
    old "Hey, listen, I think we'll have to cancel our plans for today."
    new "ねぇ、聞いて、今日の予定、キャンセルしなくちゃいけなさそうだ。"

    # say L416 rub
    old "I thought you wanted to meet those cute guys today."
    new "君が今日、あの可愛い男の子たちと会いたがってたと思ったけど。"

    # say L418 oli
    old "I do! I really do."
    new "本当にそう思ってるの！"

    # say L419 oli
    old "But I just remembered my mom needs me to help her with some stuff at home."
    new "でも、母が家で手伝って欲しがってるのを思い出したの。"

    # say L420 oli
    old "So I have to go home early."
    new "だから早めに帰らないと。"

    # say L422 rub
    old "Hmm, alright, I guess that's okay."
    new "うーん、そうね、仕方ないね。"

    # say L423 rub
    old "I guess I'll be hanging out with the guys by myself."
    new "じゃあ、男の子たちと一人で遊ぶことにするかな。"

    # say L424 oli
    old "Sure, but next time I'll definitely be going out with you guys."
    new "うん、でも次は絶対に一緒に出かけるからね。"

    # say L426 rub
    old "Alright, I guess that's fine."
    new "まあ、そうね。"

    # say L446 pla
    old "Yeah?"
    new "うん？"

    # say L448 oli
    old "Listen, I was thinking today could be a good day for you to come over."
    new "ねえ、今日は私の家に来てみようか。"

    # say L449 oli
    old "So we can start studying."
    new "そう、勉強を始めるために。"

    # say L450 pla
    old "W- what... Now?"
    new "え、今？"

    # say L452 oli
    old "Yes, why? I told you to clear your schedule."
    new "はい、どうして？　あなたにスケジュールを空けるように言ったでしょう。"

    # say L453 pla
    old "No, no, you just caught me off guard."
    new "いや、ちょっと驚いただけだよ。"

    # say L454 oli
    old "Well, you don't have to come if you don't want to."
    new "まあ、来たくないなら来なくてもいいわ。"

    # say L456 oli
    old "That is, if you don't care about everyone knowing you're fucking Mike's mom."
    new "みんなに君がマイクのママとセックスしてるって知られてもいいの？"

    # say L457 pla
    old "{i}(Damn... She's got some attitude.){/i}"
    new "{i}(くそ……彼女はなかなか強気だな。){/i}"

    # say L458 pla
    old "{b}*Sigh*{/b} Alright, let's go to your house."
    new "{b}*ため息*{/b} まあ、家に帰ろう。"

    # say L481 oli
    old "Oh, m- mom, you're here."
    new "あ、母さん、ここにいるの。"

    # say L483 oli
    old "I- I thought you were going to be out this afternoon."
    new "あの、お母さん、午後は外出してると思っていたの。"

    # say L484 vee
    old "That was the plan, but the appointment got canceled, so I just came back home."
    new "その予定だったんだけど、用事がキャンセルされたから家に戻ってきたの。"

    # say L486 vee
    old "But anyway honey, who's your friend here? Aren't you going to introduce me to him?"
    new "でもね、 Darling、この人誰？ 紹介してくれないの？"

    # say L488 oli
    old "Well... Yeah."
    new "うーん… そうだね。"

    # say L489 oli
    old "His name is [pla], he's a friend from school."
    new "彼の名前は[pla]、学校の友達だよ。"

    # say L494 oli
    old "[pla], this is my mother, her name's Priya."
    new "[pla]、これが私の母、プリヤです。"

    # say L498 pla
    old "Hello Mrs. Priya, nice to meet you."
    new "プリヤさん、こんにちは。お会いできて嬉しいです。"

    # say L500 vee
    old "Nice to meet you too, [pla]."
    new "こちらもよろしくね、[pla]。"

    # say L502 oli
    old "[pla]'s going to help me study some topics for school."
    new "[pla]が学校のいくつかの単元を勉強する手伝いをしてくれるのね。"

    # say L504 oli
    old "You know, some exams are coming up, and I want to do well."
    new "知ってる？試験が近くて、いい成績を取りたいの。"

    # say L507 oli
    old "And [pla] here is a great student. He always gets top grades."
    new "[pla]は優秀な生徒だからね。いつも成績がトップなんだよ。"

    # say L509 oli
    old "So I asked him to help me."
    new "だから彼に手伝ってもらうことにしたの。"

    # say L510 vee
    old "Oh, that's so good to hear, honey!"
    new "あら、それは聞いて嬉しいわ。"

    # say L513 vee
    old "I'm so glad you're finally taking your studies seriously."
    new "ついに勉強を真剣に取り組むようになったのね、本当に嬉しいわ。"

    # say L514 vee
    old "Your father's going to be very pleased if you do well in school, you know that."
    new "学校で成績が良ければ、お父さんもきっと喜ぶわよ。知ってるでしょ。"

    # say L517 oli
    old "Yeah, yeah, I know what he wants..."
    new "うんうん、分かってるよ…"

    # say L519 vee
    old "Honey, don't take that attitude."
    new "honey、そんな態度取らないでよ。"

    # say L522 vee
    old "I know your father can be hard to deal with sometimes."
    new "あなたの父親が時々扱いにくいことは分かってるわ。"

    # say L525 vee
    old "But you have to understand that he just wants what's best for you."
    new "でも、あなたが理解してほしいのは、彼はただあなたにとって最善を望んでいるだけだってことよ。"

    # say L527 vee
    old "As do I."
    new "私もそう思う。"

    # say L529 vee
    old "So, I'm very happy to see you making an effort to improve your grades."
    new "だから、君が成績を上げようとしてくれて嬉しいよ。"

    # say L530 oli
    old "Yeah... Thank you."
    new "うん…ありがとう。"

    # say L535 oli
    old "Hey mom, [pla] and I are going to study in my room, alright?"
    new "ママ、[pla] と私の部屋で勉強するからね、いいよね？"

    # say L537 vee
    old "Sure thing, sweetie."
    new "もちろん、甘い子。"

    # say L550 oli
    old "I'm sorry you had to see that."
    new "見せちゃってごめんなさい。"

    # say L552 oli
    old "I wasn't expecting my mom to be here."
    new "母がここにいるとは思わなかった。"

    # say L554 pla
    old "It's okay."
    new "大丈夫だよ。"

    # say L556 pla
    old "You don't have to apologize."
    new "謝らなくてもいいよ。"

    # say L559 oli
    old "Anyway, I guess it's a good thing she met you right away."
    new "まあ、すぐに彼女が君に会えたのは良かったみたいね。"

    # say L561 oli
    old "That will make things easier in the future."
    new "将来的には楽になるわね。"

    # say L564 oli
    old "So, should we get to it?"
    new "じゃあ、始めましょうか？"

    # say L574 pla
    old "Okay, let's start with this topic."
    new "じゃあ、この話題から始めよう。"

    # say L575 pla
    old "And we'll work our way to the others. Alright?"
    new "他のトピックにも進んでいくよ。分かった？"

    # say L577 oli
    old "Uhh... Sure, whatever you say."
    new "うーん… 分かったわ、あなたがそう言うなら。"

    # say L585 pla
    old "See? This is the right way to prove that result."
    new "見ろ？こうすれば結果を証明できるんだ。"

    # say L587 oli
    old "I see, that makes a lot of sense."
    new "なるほど、それはとても合理的ですね。"

    # say L589 pla
    old "Alright, I think we can move on to the next topic!"
    new "よし、次のトピックに進もうか！"

    # say L595 pla
    old "I never could have guessed you'd be so good at this, you know?"
    new "君がこれほど上手だとは、想像もつかなかったよ。"

    # say L597 oli
    old "I know, everyone assumes that just because I'm pretty and popular, I'm just an airhead..."
    new "みんな、私がきれいで人気があるからって、ただの空っぽの頭だと思ってるでしょ..."

    # say L599 oli
    old "But everyone is wrong, I'm not dumb at all..."
    new "でもみんな間違ってる、私は全然馬鹿じゃないの。"

    # say L601 oli
    old "Even if it doesn't look like it, I do pay attention, just to what really interests me."
    new "見た目とは違って、ちゃんと気を配ってるの、ただ興味のあることにだけ集中してるだけよ。"

    # say L602 pla
    old "Uhh... What do you mean?"
    new "うーん… 何それ？"

    # say L604 oli
    old "Well, I want to be a fashion designer, and for that, I don't need to memorize differential calculus formulas, you know what I mean?"
    new "まあ、私はファッションデザイナーになりたいの、だから微分方程式の公式を暗記する必要なんてないの、わかるでしょ？"

    # say L606 pla
    old "Hmm, so why do you want to improve your grades now?"
    new "うーん、じゃあなんで今成績を上げようとしてるんだ？"

    # say L607 pla
    old "Is it because of what you were talking to your mom about your dad?"
    new "お母さんと話したことが関係あるのか？"

    # say L609 oli
    old "Hmm, well, yeah... Something like that."
    new "うん、まあ… そんな感じだね。"

    # say L611 oli
    old "But wait!"
    new "でも待って！"

    # say L613 oli
    old "What does this have to do with you?"
    new "これはあなたに関係あるの？"

    # say L615 oli
    old "How about we stop with the questions and get back to studying?"
    new "質問は後にして、勉強に戻ろうよ。"

    # say L617 pla
    old "Hmm, yeah right, let's keep going."
    new "うん、そうか、続けよう。"

    # say L627 pla
    old "Alright, it was just our first session, but we got a lot done."
    new "よし、初めてのセッションだったけど、結構進んだね。"

    # say L628 pla
    old "We're very short on time."
    new "時間があんまないんだ。"

    # say L630 pla
    old "But I think at this pace, we should be able to cover everything we need to before the exams."
    new "でもこのペースなら、試験までに必要なことは全部こなせそうだ。"

    # say L640 aye
    old "Hey sis, can I borrow your blue dress today for a- "
    new "Hey sis、今日青いドレス貸していい？"

    # say L642 aye
    old "Oh, I didn't know you had company..."
    new "あ、知らなかったけど客人が来てるんだ…"

    # say L643 aye
    old "What were you two doing in here? Does Dad know you're bringing boys into your room?"
    new "何してたの？お父さんに男の子を部屋に連れてくること言ってたか？"

    # say L645 oli
    old "We were studying... And it's none of your business..."
    new "勉強してたの... それに、それはあなたの知らないことよ..."

    # say L646 aye
    old "Oh Olivia, where are your manners? You should introduce us."
    new "オливィア、礼儀って何？ properly introduce us, will you？"

    # say L647 aye
    old "Hi, my name is Ayeshaa, nice to meet you."
    new "こんにちは、俺の名前はアイシャだ、よろしく。"

    # say L649 pla
    old "Uhh, hi, nice to meet you too, my name's [pla]."
    new "うーん、こんにちは、会えて嬉しい、俺の名前は[pla]だ。"

    # say L652 oli
    old "Alright, alright, what have I told you about coming into my room unannounced?"
    new "いいえいいえ、勝手に入ってこないでと言ったでしょう？"

    # say L654 aye
    old "I just wanted to see if you could let me borrow the dress—"
    new "ただ、そのドレスを借りたいだけだったんだけど——"

    # say L656 oli
    old "No, you can't borrow my blue dress."
    new "ダメよ、私の青いドレスは貸さないわ。"

    # say L658 oli
    old "Now get the hell out of here."
    new "今すぐここから出て行け。"

    # say L660 aye
    old "Ugh, why do you always have to have that nasty attitude?!"
    new "うっせえ、なんでいつもそんな態度なんだよ？！"

    # say L663 aye
    old "You know what? I actually hope you screw up your grades..."
    new "知ってるか？成績が悪くなって欲しくてさ…"

    # say L666 aye
    old "So dad will take you to India with him!"
    new "そう親父にインドに連れて行ってくれるんだ！"

    # say L668 aye
    old "Maybe then you'll learn some humility."
    new "そうすれば、少しは謙虚になれるかもしれないな。"

    # say L670 aye
    old "Alright, alright!"
    new "分かった、分かった！"

    # say L671 aye
    old "Bye, cutie."
    new "バイバイ、かわいいの。"

    # say L672 pla
    old "B- bye..."
    new "バイバイ…"

    # say L679 oli
    old "I'm sorry about that."
    new "すみませんね、そのことについて。"

    # say L681 oli
    old "She's just a brat, and my mom always lets her get away with everything, that's why she acts like that."
    new "彼女はただのわがままな子で、私のママはいつも彼女を甘やかすから、そんなふうに振る舞うのよ。"

    # say L683 pla
    old "Uhh... S- sure, no problem."
    new "うーん… 分かった、問題ないな。"

    # say L684 pla
    old "Uhmm, by the way, w- what she said about you going to India..."
    new "うーん、そういえば、君がインドに行くって話についてなんだけど…"

    # say L686 oli
    old "I told you! I'm not talking about that!"
    new "言ったわ！その話はしないのよ！"

    # say L690 oli
    old "Anyway, I think we were done studying for today, right?"
    new "でも、今日の勉強はもう終わりにしようかな？"

    # say L692 pla
    old "Uhh, yeah, we made good progress today, but we still have more to do. You need to get a high grade to boost your average..."
    new "うーん、そうだな、今日はよく進んだけど、まだやることがあるな。君の平均点を上げるために、高得点が必要なんだ…"

    # say L693 pla
    old "I know you're worried, but I think we can handle it."
    new "心配してるってわかるけど、大丈夫だと思う。"

    # say L695 oli
    old "If you say so..."
    new "そうね…"

    # say L697 pla
    old "Alright, I think I have to go. So, are afternoons good for you to keep studying?"
    new "よし、行かなきゃな。午後の時間は勉強するのに都合がいいかい？"

    # say L699 oli
    old "Right, make sure to come by my house in the afternoons. Don't miss it, or you know what will happen..."
    new "うん、午後には必ずうちへ来なさい。欠かさないようにね、さもないと知ってるでしょ..."

    # say L700 pla
    old "Yeah, sure, you don't have to remind me."
    new "うん、そんなに念を押すことはないけど。"

    # say L701 pla
    old "Anyway, see you later."
    new "じゃあ、後でな。"

    # say L703 oli
    old "Ok, see you."
    new "じゃあ、またね。"

    # say L721 oli
    old "Hey, I was waiting for you. You’re here to help me study, right?"
    new "hey、待ってたの。勉強の手伝いに来たんでしょ？"

    # say L722 pla
    old "Yeah, I'm here to keep working on the stuff we still need to cover."
    new "そうだ、まだやっておくべきことが残ってるから。"

    # say L724 oli
    old "Great! I was getting worried you might take too long to come back."
    new "良かった！戻ってくるのが遅くなるかと思ったの。"

    # say L726 oli
    old "Let's not waste any time and get started."
    new "時間の無駄にしないで、さっそく始めましょう。"

    # say L727 pla
    old "Alright, let's continue where we left off last time."
    new "よし、前回のところから続けよう。"

    # say L729 oli
    old "Sure, let's do it."
    new "分かった、それじゃあ行こう。"

    # say L758 pla
    old "Alright, I think that's enough for today."
    new "よし、今日はこれで終わりにしよう。"

    # say L759 pla
    old "We still have some other things to cover, but I'll be back soon so we can continue with what's left."
    new "まだ他のこともあるけど、すぐ戻ってくるから残りはそのときに続けよう。"

    # say L760 pla
    old "And then we can move on to the next topic."
    new "そして次のトピックに進めるよ。"

    # say L762 oli
    old "Alright, sure, thanks for coming."
    new "分かった、ありがとう。"

    # say L763 oli
    old "I'll see you soon."
    new "またね。"

    # say L795 vee
    old "Hi [pla]! Good morning!"
    new "おはよう！[pla]"

    # say L796 pla
    old "Hi Mrs. Priya, how are you today?"
    new "プリヤさん、今朝は元気ですか？"

    # say L798 vee
    old "I'm doing alright sweetheart."
    new "元気だよ、スイートハート。"

    # say L799 vee
    old "Honey, did you come to see Olivia?"
    new "ハニー、オリビアを見に来たの？"

    # say L800 vee
    old "Because right now it's time for school."
    new "だって今、学校の時間だよ。"

    # say L802 vee
    old "Shouldn't you be there?"
    new "学校には行かなくちゃ？"

    # say L803 pla
    old "Oh, yeah, Mrs. Priya, I just have the day off school to run a couple of errands."
    new "ああ、そうか、プリヤ先生。今日は学校を休んで、用事を済ませに来たんだ。"

    # say L804 pla
    old "And I wanted to say hi."
    new "そして君に会いたかったんだ。"

    # say L805 vee
    old "I see, I'm glad to see you dear."
    new "そうね、会えて嬉しいわ。"

    # say L806 vee
    old "I'll be sure to tell Olivia you stopped by."
    new "オリビアにあなたが来たことを伝えておきますね。"

    # say L808 pla
    old "Alright, thanks ma'am."
    new "わかった、ありがとうプリヤさん。"

    # say L811 vee
    old "Hello, [pla]!"
    new "こんにちは、[pla]！"

    # say L812 pla
    old "Hi, Mrs. Priya!"
    new "こんにちは、プリヤさん！"

    # say L814 vee
    old "It's good to see you, dear. How are you today?"
    new "会えて嬉しい、親愛なる人。今日怎么样？"

    # say L816 pla
    old "I'm fine, Mrs. Priya, and you?"
    new "元気だ、プリヤ夫人、君は？"

    # say L818 vee
    old "I'm doing alright, dear. Keeping busy as usual, thanks for asking."
    new "元気にしてるわ、親愛なる人。いつも通り忙しくて、気にかけてくれてありがとう。"

    # say L819 vee
    old "Tell me, did you come to see Olivia?"
    new "教えて、オリビアに会いに来たの？"

    # say L823 vee
    old "Great! She's in her bedroom right now, dear."
    new "素晴らしいわ！彼女は今寝室にいるわ、親愛なる人。"

    # say L824 vee
    old "Don't mind me, you can go right in."
    new "気にしないで、そのまま入っていいわ。"

    # say L826 pla
    old "Thanks, Mrs. Priya. I'll catch up with you later."
    new "ありがとう、プリヤさん。後でまた話すね。"

    # say L828 vee
    old "That's alright, dear. Nice seeing you."
    new "大丈夫よ、親愛なる人。会えて嬉しいわ。"

    # say L829 vee
    old "And if you kids need anything, just let me know."
    new "kidsが必要なら、教えてね。"

    # say L840 pla
    old "Alright, that's it, that's the right method."
    new "そうだな、これでいい、これでうまくいくぞ。"

    # say L842 pla
    old "Great, you got it!"
    new "よし、分かったな！"

    # say L844 pla
    old "You know, we're making very good progress."
    new "知ってるか、かなりいい進捗だな。"

    # say L846 pla
    old "At this rate we'll manage to go over every topic before the exams."
    new "この調子なら試験前に全ての単元を終わらせられそうだな。"

    # say L847 oli
    old "Yeah, ok... Great."
    new "うん、まあ… でも、全然上手くいってるとは思えないな。"

    # say L849 pla
    old "That doesn't seem like you're too sure about it."
    new "そんなに自信ないのか？"

    # say L856 oli
    old "I just feel like this isn't working [pla]."
    new "このままじゃ上手くいかない感じがする [pla]。"

    # say L858 oli
    old "You just said that you think we'll be able to tackle every topic before the exams."
    new "あなた刚说过我们能在考试前搞定所有话题嘛"

    # say L860 oli
    old "But how well am I really going to do in them?"
    new "でも、試験でどれだけちゃんとできるかな。"

    # say L861 oli
    old "With so little time, there's only so much I can learn."
    new "時間があまりないから、学べる量にも限界があるのね。"

    # say L863 pla
    old "Come on, don't be so negative."
    new "おい、そんなにネガティブになるな。"

    # say L865 pla
    old "I know what you mean. But it's worth giving it a shot."
    new "分かってるよ。でも、やってみる価値はあるな。"

    # say L866 oli
    old "I know it is."
    new "そうよ。"

    # say L868 oli
    old "It's just that when I see how much more we have to study."
    new "ただ、まだこんなに勉強しなきゃいけないことがあってね。"

    # say L869 oli
    old "And the time that's left before the exams."
    new "そして試験までの残り時間を考えると。"

    # say L873 oli
    old "That was just a huge waste of time!"
    new "それは本当に時間の無駄だったわ！"

    # say L874 pla
    old "Hey, hey, come on."
    new "おい、おい、そんなに落ち込むな。"

    # say L875 pla
    old "I understand how you feel, but let's not get discouraged."
    new "分かってるよ、でも落ち込むな。"

    # say L877 pla
    old "I'm sure you'll do well in these exams."
    new "試験はきっと大丈夫だよ。"

    # say L879 pla
    old "I mean... Yeah, it would be very difficult to get perfect scores."
    new "まあ……そうだな、満点を取るのはかなり難しいだろうけど。"

    # say L880 pla
    old "But I'm sure that if we keep studying at this pace, and with a little luck."
    new "でも、この調子で勉強を続けて、少しの運があれば。"

    # say L882 pla
    old "You'll get grades that are good enough for you to pass all the subjects."
    new "君は充分に合格できる成績を取れるよ。"

    # say L883 oli
    old "But that's the problem! I can't just get {i}‘passing grades'{/i}."
    new "でもそれが問題なの！{i}合格点{/i}じゃ物足りないの。"

    # say L885 oli
    old "If I don't get maximum grades, it won't be good enough!"
    new "最大の成績を取らなきゃ、十分じゃないんだよ！"

    # say L887 pla
    old "Uh, ok?"
    new "うーん、いいのか？"

    # say L889 pla
    old "But why, though?"
    new "でも、なんでそんなに必要なんだ？"

    # say L890 pla
    old "I mean, I understand that studying and grades are important."
    new "まあ、勉強と成績が重要だってのは分かるけど。"

    # say L892 pla
    old "But why is it so important to get the maximum grades?"
    new "でも、最高の成績を取ることがなんでそんなに重要なんだ？"

    # say L900 oli
    old "I didn't want to tell you about this, but I guess it's better if you understand the full picture."
    new "このこと話したくなかったんだけど、全部を理解した方がいいかなって思った。"

    # say L902 oli
    old "Listen, if I don't get maximum or top grades by the end of the term, I'll be sent to India to live with my dad."
    new "Listen、もし期末までに最高の成績を取れなかったら、インドに送られて父親と暮らせと言われるの。"

    # say L905 oli
    old "Well, you know my parents are from India, right?"
    new "まあ、私の親はインド出身ってこと、知ってるでしょ？"

    # say L906 pla
    old "Hmm, yeah sure..."
    new "うん、そうなのか…"

    # say L908 oli
    old "See, my father is still living there. He comes here often, but his business is located there."
    new "見なさい、私の父親はまだインドに住んでいて、よくここに来てくれるけど、彼の仕事はそこでしているの。"

    # say L909 oli
    old "While we stay here with my mother."
    new "母とここにいる間はね。"

    # say L913 oli
    old "Well, my dad's a very traditional guy."
    new "まあ、私の父親はとても伝統的な人なの。"

    # say L915 oli
    old "He cares a lot about upholding tradition and customs."
    new "父は伝統や習慣を守ることにとてもこだわってるの。"

    # say L917 oli
    old "And since I'm the oldest daughter, he wants me to take part in a lot of those traditions."
    new "そして私が長女なので、彼は私に多くのその伝統に参加させたいと思っているの。"

    # say L921 oli
    old "Without consulting me or letting me know about it!"
    new "何も相談もせずに、知らせもなしに！"

    # say L922 pla
    old "Uh, I- I see."
    new "うーん、なるほど。"

    # say L925 pla
    old "B- but, don’t you think if you talked to him, he’d understand you’re not in love with the guy he wants you to marry?"
    new "でも、君が話せば、君が結婚したいんじゃないって理解してくれるかもしれないじゃん。"

    # say L927 oli
    old "{b}*Sigh*{/b} Come on, be realistic."
    new "{b}*ため息*{/b} ほら、現実的になよ。"

    # say L929 oli
    old "Love has nothing to do with it [pla]."
    new "愛なんて関係ないわ [pla]。"

    # say L931 oli
    old "The guy he engaged me to is the heir to a very successful company."
    new "彼が私を婚約させた男は、大成功した会社の後継者よ。"

    # say L932 oli
    old "He knows that by getting me married to him, he would get a big opportunity to do business."
    new "彼は私と結婚することで、大きなビジネスのチャンスを得られることを知っている。"

    # say L934 oli
    old "He thinks that since I'm the oldest daughter, it is my duty to the family to go through with his plan!"
    new "彼は私が長女だから、家族のために彼の計画を遂行することが私の義務だと思っているの。"

    # say L935 pla
    old "B- but, isn't there anything that you can do?"
    new "でも、何か手立てはないのか？"

    # say L937 oli
    old "Well, that's why I need to get good grades."
    new "だから成績を上げなきゃならないの。"

    # say L939 oli
    old "My mom's a little more open-minded than my dad. She knows I don't want to live my life that way."
    new "私のママはパパより少しオープンマインドで、私がそんな人生を送りたくないことも知ってるよ。"

    # say L941 oli
    old "She's been supporting me, and interceding on my behalf with my dad."
    new "母は私を支えてくれて、父との間で私の味方になってくれているの。"

    # say L943 oli
    old "That's been a huge problem between them, they've been fighting over it."
    new "それが二人の間での大きな問題で、いつもけんかになっているの。"

    # say L945 oli
    old "But my mom finally convinced him to let me off the hook if I get good grades by the end of the term."
    new "でも、母が期末までに成績を上げられたら私を許すことに父親を説得してくれたの。"

    # say L946 oli
    old "That's why I'm so desperate to get the highest scores! Because I really have to!"
    new "だから最高の成績を取らなきゃいけないの！本当に必要なんだもん！"

    # say L948 pla
    old "I- I see. I understand."
    new "わかった、なるほど。"

    # say L949 pla
    old "I didn't know how important the exam results would be for you."
    new "君が試験の結果をそんなに重要だと思ってるなんて知らなかったな。"

    # say L951 pla
    old "I'm not sure, but I think we can make it so that you'll be able to get the top grades."
    new "俺も確信はないけど、君が最高の成績を取れるように手助けできると思う。"

    # say L953 oli
    old "Do you really mean it?"
    new "本気で言ってるの？"

    # say L955 oli
    old "I know there's too little time to do this."
    new "時間はあまりないってことは分かってるけど、頑張ればできると思うの。"

    # say L956 pla
    old "But I know we can make it, come on let's keep going!"
    new "でも俺たちはできるよ、さあ、続けよう！"

    # say L958 oli
    old "Okay, okay."
    new "わかったわ、わかったわ。"

    # say L968 pla
    old "I think that's enough for today, but I'll be back soon so we can keep going."
    new "今日はこれで十分だけど、またすぐ戻ってくるから続けられるよ。"

    # say L969 pla
    old "Don't worry, we'll get this done before you know it."
    new "心配しなくていい、気づかないうちに終わらせるから。"

    # say L973 oli
    old "You know [pla], I'm not sure about this."
    new "知ってる [pla]、ちょっと心配してるのだけど。"

    # say L975 oli
    old "But if you say we can make it, I'll believe you."
    new "でもあなたができるって言うなら、信じるわ。"

    # say L977 oli
    old "Thanks for the help [pla]."
    new "ありがとう、[pla]。"

    # say L979 pla
    old "No problem, I'm happy to help."
    new "問題ないよ、手伝えて嬉しいさ。"

    # say L980 pla
    old "I'll go for now, but I'll see you later."
    new "今度会おう、今は行こうと思う。"

    # say L1005 vee
    old "Yeah, that's right. Your aunt Fatima said she'd be sending Devika here to spend some time with us."
    new "うん、そうよ。おばあちゃんのファティマがデヴィカを連れてくるって言ってたわ。"

    # say L1008 vee
    old "Oh honey, don't make that face."
    new "お Gł ちゃん、そんな顔しないで。"

    # say L1011 oli
    old "I just don't know if she should come here."
    new "私はただ彼女がここに来ることについて迷ってるの。"

    # say L1014 oli
    old "Where is she going to sleep?"
    new "どこで寝るの？"

    # say L1016 vee
    old "You don't need to worry about that."
    new "心配しなくていいよ。"

    # say L1018 vee
    old "Besides, I know you like your cousin. You two used to be very close!"
    new "それに、君のいとこが好きだって知ってるよ。二人は昔、とても仲が良かったよね！"

    # say L1019 oli
    old "Hmm, that was a long time ago."
    new "うーん、それは随分昔のことね。"

    # say L1021 oli
    old "But I guess it's alright if she comes here. I like Aunty Fatima, so it shouldn't be too much of a problem."
    new "でも、彼女が来てもいいかな。アニー・ファティマが好きだから、それほど問題にはならないだろうね。"

    # say L1027 pla
    old "Uh, s- sorry for interrupting."
    new "す、すみません、突然入れて"

    # say L1030 pla
    old "Hi Olivia, I came to continue our study sessions."
    new "オリビア、僕が勉強の続きをしに来たよ。"

    # say L1032 oli
    old "[pla], I'm so glad you're here! I was just waiting for you!"
    new "[pla]、あなたが来てくれて嬉しいです！ 待ってたの！"

    # say L1033 pla
    old "Uh... You were?"
    new "うーん… 本当に？"

    # say L1034 pla
    old "W- well, here I am, I guess."
    new "よ、来たよ、まあ。"

    # say L1035 oli
    old "Yeah, I was just waiting for you to make our announcement."
    new "うん、あなたが私たちの発表をするのを待ってただけなの。"

    # say L1037 pla
    old "O- our announcement? What do you-"
    new "お、私たちの発表？何を言おうとしてるの？"

    # say L1043 oli
    old "Mom, there's something that [pla] and I have been wanting to tell you."
    new "ママ、[pla] と私が伝えたいことがあって。"

    # say L1044 oli
    old "And we decided this is the right time to do it."
    new "そして、今がそのタイミングだって決めたの。"

    # say L1046 vee
    old "Hmm, o-kay? What is it?"
    new "うーん、そう？何のこと？"

    # say L1048 oli
    old "Well, you see, the truth is that [pla] isn't actually my friend."
    new "実はね、[pla]は私の友達じゃなかったの。"

    # say L1050 oli
    old "Actually, it would be more accurate to say that he's not only my friend."
    new "実際には、彼はただの友達じゃないの。"

    # say L1055 oli
    old "What you just heard, Mom. [pla] and I have been dating for a while now."
    new "ママ、あなたが今聞いた通り、[pla] と私はもうしばらく付き合ってるの。"

    # say L1057 vee
    old "I'm sorry, and why hadn't I heard about this until now?"
    new "ごめん、でもなんで今まで知らなかったの？"

    # say L1059 oli
    old "Because I just wanted to be sure about what he and I feel, and of our relationship."
    new "だって、私と彼の気持ちや関係が本当に確かなものなのか確かめたかったからよ。"

    # say L1062 oli
    old "Also, I knew that you and Dad wouldn't have approved."
    new "それに、君とパパが認めてくれないと思ってたの。"

    # say L1064 vee
    old "Oh, you think so?"
    new "そう思ってるの？"

    # say L1067 vee
    old "Not only are you dating someone without our approval."
    new "君が私たちの許可なく誰かと付き合っているだけでなく。"

    # say L1069 vee
    old "Now you also come and tell me like this?"
    new "今さらこんな風に言ってもね。"

    # say L1072 vee
    old "You know full well that this is not how we do things, Olivia!"
    new "オリビア、君もよく知ってるよね、私たちがこんな風にすることはないんだから！"

    # say L1074 vee
    old "I can't even imagine the face Vihaan's going to make when he finds out about this."
    new "ビハーンがこれを見つけた時の顔、想像もつかないわ。"

    # say L1075 oli
    old "That's precisely why I'm telling you this right now."
    new "それがちょうど今あなたに言っている理由なのよ。"

    # say L1078 oli
    old "Mom, [pla] and I are in love."
    new "ママ、[pla]と私は恋に落ちてるの。"

    # say L1081 oli
    old "But I know that if I tell Dad about this, he'll never approve of us."
    new "でも、パパにこれを話したら、絶対に認めてくれないってわかってる。"

    # say L1082 oli
    old "So I need your help to convince him that this is okay."
    new "だから君の助けが必要なんだ。パパにこれがOKだって納得させるため。"

    # say L1085 vee
    old "It's not that simple, honey. You know I have no problem with you having a boyfriend."
    new "それほど簡単じゃないよ、ハニー。君が彼氏を持つこと自体には全然問題ないってことは知ってるよね。"

    # say L1088 vee
    old "But Vihaan is a lot more traditional than me."
    new "でもヴィハーンは私よりもずっと伝統的だからね。"

    # say L1089 vee
    old "And he won't be pleased with this at all."
    new "そして彼はこれには全然満足しないわ。"

    # say L1092 oli
    old "I know that, Mom, but I don't want to go along with Dad's plan."
    new "ママ、それはわかってるけど、パパの計画には乗らないつもりよ。"

    # say L1093 oli
    old "You know what he wants..."
    new "君が知ってるよね、彼が何を欲しているか..."

    # say L1096 oli
    old "If it was up to him, I would already be wedded to that guy he wants me to marry."
    new "もし彼の思う通りなら、もうその男と結婚してたね。"

    # say L1099 oli
    old "But I don't want to live my life like that, Mom!"
    new "でも、そんな人生は望んでないの、ママ！"

    # say L1102 oli
    old "I don't care about that guy I don't know."
    new "その知らない男の人はどうでもいい。"

    # say L1105 oli
    old "He's not what I want for my life."
    new "彼は私が望む人生じゃない。"

    # say L1107 oli
    old "[pla] is the one I'm in love with!"
    new "[pla]が私の恋の相手よ！"

    # say L1110 oli
    old "I need your help to convince Dad, please Mom."
    new "ママ、パパを説得する手伝いが必要なの、お願い。"

    # say L1118 vee
    old "Alright, I can see you're serious about this."
    new "分かった、本気で言ってるんだね。"

    # say L1119 oli
    old "That means you'll help me?"
    new "それって、手伝ってくれるってこと？"

    # say L1121 vee
    old "Well, what choice do I have?"
    new "WELL、選択肢なんてないよ"

    # say L1123 vee
    old "You're putting me in a tough spot right now, honey."
    new "今君に言われて、かなり困ってるの、ハニー。"

    # say L1126 vee
    old "But I wouldn't want to force your hand."
    new "でも、あなたを強制したくはないの。"

    # say L1129 vee
    old "And to be honest, I'm not too keen on this whole arranged marriage situation."
    new "正直、この見合い結婚の話にはあまり乗り気じゃないの。"

    # say L1132 vee
    old "So I'll help you with your father for now."
    new "だから今は君の父親のことを手伝うわ。"

    # say L1134 oli
    old "That's great, Mom, thank you!"
    new "ありがとう、ママ。助けてくれてうれしいよ。"

    # say L1137 vee
    old "Yeah well, that's only if you get good grades, you know."
    new "まあ、成績が良ければの話だけどね。"

    # say L1138 vee
    old "Remember, that's a deal we already made with your father, so don't disappoint us."
    new "覚えておきな、それはもうお父さんとも約束したんだから、がっかりさせるなよ。"

    # say L1140 oli
    old "Don't worry, I promise you I'm working very hard."
    new "心配しないで、本当にがんばってるって約束するから。"

    # say L1142 oli
    old "Come on [pla], let's get to studying."
    new "さあ、[pla]、勉強しよ。"

    # say L1151 pla
    old "Uh, I- Uh... S- see to you later, Mrs. Priya."
    new "あのう、その、プリヤさん、また後で……"

    # say L1161 oli
    old "Ok, that went well."
    new "まあ、上手くいったみたいね。"

    # say L1164 pla
    old "Would you mind telling me what this business of us dating is about?"
    new "君が俺と付き合おうって話、どういうことだ？"

    # say L1165 oli
    old "Well, you heard me talking to my mom."
    new "ええ、私がママと話しているのを聞いたでしょう。"

    # say L1167 oli
    old "Listen, after the last time you came here, I got to thinking about how much work is still left to do."
    new "前回来た後、まだ残ってる仕事の量について考えちゃったの。"

    # say L1169 oli
    old "And I got worried about the possibility of not finishing it."
    new "そして、それが終わらないかもしれないって心配になったの。"

    # say L1171 oli
    old "So I figured I needed a contingency plan in case my grades don't turn out to be good."
    new "だから成績が良くなかった場合の対策が必要だと思ったの。"

    # say L1172 pla
    old "So you came up with the idea of us dating? How is that going to help?"
    new "じゃあ、俺たちが付き合うってアイデアを思いついたのか？それはどう役立つんだ？"

    # say L1174 oli
    old "Think about it [pla], if I can convince my Dad that I'm in love with you."
    new "考えてみて [pla]、私が君のこと愛してるって父を納得させられれば。"

    # say L1176 oli
    old "And that things are serious enough for me to consider marrying you."
    new "そして、私があなたと結婚することを真剣に考えているくらい本気だって思ってくれたら。"

    # say L1178 oli
    old "Maybe he'll give up on trying to push me into that marriage."
    new "もしかしたら、父はその結婚を押しつけようとしなくなるかもしれない。"

    # say L1180 oli
    old "I'm sorry, is this a problem for you?"
    new "すみません、これあなたにとって問題ですか？"

    # say L1182 pla
    old "No, not really. I promised to help you with this, and I get what you're doing."
    new "別に問題ない。約束した通り手伝うし、何してるかも理解してる。"

    # say L1183 pla
    old "So it's alright, I'll help you with it."
    new "大丈夫、手伝うよ。"

    # say L1184 oli
    old "Thanks [pla], you have no idea how much I appreciate you saying that."
    new "ありがとう、[pla]。そう言ってくれて本当に感謝してる。"

    # say L1185 pla
    old "I'm happy to help you."
    new "手伝うよ、嬉しいさ。"

    # say L1186 pla
    old "Now, let's get to studying, to ensure that you don't need your contingency plan."
    new "じゃあ、さっそく勉強しよう。君が非常手段に頼らなくてもいいようにね。"

    # say L1196 oli
    old "Ugh! This is pointless!"
    new "うっ！これって無駄じゃないの！"

    # say L1197 pla
    old "W-what? What do you mean?"
    new "何言ってんだ？"

    # say L1199 oli
    old "I'm talking about this whole studying for exams thing!"
    new "この試験勉強のことよ！"

    # say L1200 oli
    old "It's pointless!"
    new "意味がないよ！"

    # say L1201 pla
    old "W- why do you say that?"
    new "なんでそう言うの？"

    # say L1203 oli
    old "Think about it, [pla]..."
    new "考えてみて、[pla]..."

    # say L1204 oli
    old "Look at how much I still have to do!"
    new "見てよ、まだこんなにやることあるんだもん！"

    # say L1206 oli
    old "There are so many topics!"
    new "トピックがたくさんあるわね！"

    # say L1207 oli
    old "There's no way I can cram all of this into my head before the exams!"
    new "試験前にこれ全部頭に入れるなんて無理だよ。"

    # say L1220 aye
    old "Oh! Olivia is with her boyfriend in her room again?"
    new "オーリビアがまた彼氏と部屋で一緒なのか？"

    # say L1221 aye
    old "I wonder what they talk about when they're alone..."
    new "二人きりのとき何話してるのかな…"

    # say L1222 aye
    old "Or maybe they're doing some dirty stuff?"
    new "もしかしたら、汚いことやってるのかもしれないな。"

    # say L1228 aye
    old "I guess a little eavesdropping won't hurt."
    new "ちょっと聞き耳を立ててみるか。"

    # say L1235 pla
    old "I can see why you're worried."
    new "心配するのは分かるけど。"

    # say L1237 pla
    old "But you still have to try."
    new "でも、まだ頑張らないとね。"

    # say L1238 pla
    old "Look at how much work you've put in already."
    new "もうどれだけ頑張ってきたか見てみろよ。"

    # say L1240 pla
    old "You can't give up now."
    new "今さら諦めるわけにはいかないだろ。"

    # say L1242 oli
    old "I know I've put in a lot of work, [pla]."
    new "私は頑張ってたくさんやってきたのだけど、[pla]。"

    # say L1244 oli
    old "But come on, there's no way I'm going to be able to learn all of this before the exams."
    new "でもさ、試験までに全部覚えられるわけないじゃん。"

    # say L1246 aye
    old "{i}(Hmm, I guess they're talking about her grades.){/i}"
    new "{i}(成績のことで話しているんだな。){/i}"

    # say L1247 aye
    old "{i}(She seems to be struggling.){/i}"
    new "{i}(彼女、苦労してるみたいだな。){/i}"

    # say L1249 aye
    old "{i}(When Dad finds out, he'll bring her to India right away!){/i}"
    new "{i}(親父が知ったら、すぐにでもインドに連れていくぞ！){/i}"

    # say L1250 aye
    old "{i}(She'll finally get what she deserves!){/i}"
    new "{i}(ようやく彼女も報われるな！){/i}"

    # say L1252 pla
    old "I get it, I know you're stressed and frustrated."
    new "分かってる、お前がストレスでイライラしてるってのはわかるよ。"

    # say L1254 pla
    old "But come on, you can't give up."
    new "でもさ、諦めるわけにはいかないな。"

    # say L1256 oli
    old "I don't know, I think we should make another plan."
    new "わからないわ、別の計画を立てた方がいいと思うの。"

    # say L1260 aye
    old "{i}(W-what? What is she talking about?){/i}"
    new "{i}(え、何言ってるの？){/i}"

    # say L1261 aye
    old "{i}(He's not her boyfriend?){/i}"
    new "{i}(彼氏じゃないの？){/i}"

    # say L1262 aye
    old "{i}(Oh, this is too good!){/i}"
    new "{i}(お、これはいいぞ！){/i}"

    # say L1274 aye
    old "Hey sis! How are you?"
    new "hey sis！ 兄さんだよ！元気？"

    # say L1276 aye
    old "Oh, not much."
    new "ああ、特に何もね。"

    # say L1277 aye
    old "I was just walking down the hallway a minute ago."
    new "さっき廊下を歩いてたら、偶然に聞いたんだけど。"

    # say L1280 aye
    old "And I accidentally overheard something about [pla] here not being your boyfriend."
    new "偶然にここでは [pla] が君の彼氏じゃないって話聞いちゃった。"

    # say L1281 aye
    old "I wonder what that's about?"
    new "何それについてのこと？"

    # say L1283 oli
    old "I- I don't know what you're talking about."
    new "あたし、何言ってるのか全然わかんないわ。"

    # say L1284 aye
    old "Oh yeah, I bet you don't."
    new "おい、そうかと思っちゃったな。"

    # say L1287 aye
    old "You know, dad's going to be very displeased about this."
    new "知ってるよ、お父さんがこれでかなり不機嫌になるだろうな。"

    # say L1289 aye
    old "I can already imagine his face when I tell him that you're apparently faking having a boyfriend."
    new "もうその顔が目に浮かぶよ、お前が彼氏を装ってるとお父さんに言う時だね。"

    # say L1291 aye
    old "I can't wait."
    new "待てないな。"

    # say L1293 oli
    old "W-wait! You don't understand."
    new "待って！あなたには伝わらないかもしれないわ。"

    # say L1294 oli
    old "I think you misheard us or something."
    new "待って、何か聞き間違えたのかなと思ったの。"

    # say L1296 aye
    old "Oh no, don't give me that. I didn't mishear anything!"
    new "ああ、そんなの信じられないよ。全然聞き間違えなんてしてないから！"

    # say L1299 aye
    old "You know, I thought it was strange."
    new "変だと思ったんだよ。君が急に彼氏を連れてきたのが。"

    # say L1300 aye
    old "When you suddenly brought a boyfriend home."
    new "急に彼氏を連れて帰ってきた時だよ。"

    # say L1303 aye
    old "And not only that, from one moment to the next, you decided to start studying."
    new "しかも、急に勉強し始めたって。"

    # say L1305 aye
    old "When I had never seen you take your studies seriously."
    new "お前が勉強なんて本気になったこと、一度も見たことがなかったんだ。"

    # say L1307 aye
    old "I see now that this is just a ploy to avoid going to India with dad, isn't it?"
    new "今さら勉強始めたって、父さんとインドに行きたくないだけだろ？"

    # say L1311 oli
    old "Ugh, shut up! This has nothing to do with that!"
    new "うるさい！これとは関係ないのよ！"

    # say L1314 oli
    old "Now get out of my room before I throw you out!"
    new "さっさと私の部屋から出ていけよ、出さなければ追い出すわよ！"

    # say L1316 aye
    old "Oh, I'll get out of here!"
    new "出るよ！"

    # say L1319 aye
    old "And I'll go call Dad right away!"
    new "そしてすぐに Dad に電話するぞ！"

    # say L1320 aye
    old "With all the work Dad's doing to grant you a future!"
    new "父さんが君の未来のためにどれだけ働いてくれてるか考えてみろよ！"

    # say L1323 aye
    old "And this is how you decide to repay him, by lying to him!"
    new "これで父さんへの恩返しとは思ってないか？嘘ついて！"

    # say L1325 aye
    old "I can't wait to let him know how bad his favorite daughter really is!"
    new "お父さんにお前がどれだけ悪い娘か教えてやるのを楽しみにしてるよ！"

    # say L1336 aye
    old "Yes? What do you want?"
    new "何？用件は？"

    # say L1343 oli
    old "{b}*Sigh*{/b} If I prove to you that he's my boyfriend, will you shut up and not talk to Dad?"
    new "{b}……{/b} 私が彼が私の彼氏だって証明したら、黙ってパパと話さない約束してくれる？"

    # say L1344 aye
    old "Hmm... Maybe, if you can convince me, of course."
    new "うーん… まあ、説得できりゃね。"

    # say L1345 oli
    old "I swear to God, one day."
    new "神に誓って、いつか。"

    # say L1349 oli
    old "Here I come, [pla]..."
    new "行くよ、[pla]..."

    # say L1363 oli
    old "There, are you happy?"
    new "そこ、満足した？"

    # say L1365 aye
    old "What? Happy?"
    new "何？満足？"

    # say L1370 aye
    old "I could kiss him right now too."
    new "今すぐキスしちゃうかも。"

    # say L1372 aye
    old "That doesn't prove anything!"
    new "それだけじゃ証明にならないよ！"

    # say L1374 oli
    old "What are you insinuating?"
    new "何を暗に言っているの？"

    # say L1376 aye
    old "Come on sis, prove to me that you're really a couple."
    new "おい、姉さん、本当に恋人同士だって証明してみろよ。"

    # say L1378 oli
    old "What do you mean by that?"
    new "何それどういう意味？"

    # say L1379 aye
    old "Oh come on! I knew you were dumb, but I didn't think this much."
    new "おいおい！お前がバカだとは知ってたけど、ここまでとは思わなかったよ。"

    # say L1384 oli
    old "W- what? What are you talking about? Do you think I just go around doing that?"
    new "何言ってんの？そんなことするわけないじゃない。"

    # say L1385 oli
    old "I don't do that sort of thing!"
    new "そんなことするもんか！"

    # say L1388 aye
    old "Don't treat me like I'm stupid!"
    new "バカにしないでくれよ！"

    # say L1389 aye
    old "Maybe Mom and Dad are willing to buy your {i}‘nice girl'{/i} act..."
    new "もしかしてママとパパはお前の{i}いい子ぶり{/i}を買ってるのかな…"

    # say L1390 aye
    old "But I know who you really are!"
    new "でも、お前の本性は知ってるよ！"

    # say L1393 pla
    old "H- hey, hey! L- let's not get carried away, girls."
    new "おい、おい！　Girls、落ち着いてくれよ。"

    # say L1397 oli
    old "Stay out of this!"
    new "関わりたくない！"

    # say L1403 oli
    old "Listen, you little bitch."
    new "聞いてよ、小バカ者。"

    # say L1405 oli
    old "First, be very careful about who you're calling a whore."
    new "まずは誰を娼婦呼ばわりするか気をつけなさい。"

    # say L1407 oli
    old "Second, there must be something really wrong with your head if you want to see me fuck this guy in front of you."
    new "二つ目に、お前の頭が相当おかしいんだな。私がこの男の前でセックスするのを見たいって。"

    # say L1410 oli
    old "And if you think I'll let you watch that."
    new "私がそれを見せるとでも思ってるなら大間違いだよ。"

    # say L1411 oli
    old "So why don't you get the hell out of here?!"
    new "じゃあさっさと出て行けよ！"

    # say L1414 aye
    old "Oh, I can leave, I told you I have no problem with that."
    new "俺が出ていくのは簡単だよ、君に言ってるだろう？"

    # say L1416 aye
    old "But you know what I'll do right away!"
    new "でもすぐにこれをするぞ！"

    # say L1419 aye
    old "Because I don't have any proof that this guy is your real boyfriend."
    new "証拠がないから、この男が本物の彼氏だって言えないんだよ。"

    # say L1422 aye
    old "Thinking about it, right now it must be early morning in India."
    new "考えてみれば、今インドは早朝だな。"

    # say L1423 aye
    old "Daddy must be waiting for me to send him his good morning message."
    new "パパはきっと朝のメッセージを待ってるだろうな。"

    # say L1424 aye
    old "I'm sure he'll appreciate the extra news!"
    new "きっと追加のニュースも喜ぶだろうな。"

    # say L1430 oli
    old "{i}({b}*Sigh*{/b} I can't believe this...){/i}"
    new "{i}({b}*ため息*{/b} 信じられない...){/i}"

    # say L1431 oli
    old "Listen you..."
    new "聞いてよ..."

    # say L1433 oli
    old "I'm NOT going to have sex with this guy in front of you."
    new "私はこの男と君の前でセックスをするつもりはないわ。"

    # say L1434 oli
    old "But if I do something sexual with him..."
    new "でも私が彼と性的なことをしたら..."

    # say L1437 oli
    old "Will you stop saying he's not my boyfriend and leave us alone?"
    new "あなたが彼氏じゃないって言わないと、私たちを放っておいてくれる？"

    # say L1438 aye
    old "Hmm, I don't know, that really depends on you."
    new "うーん、それは君次第だな。"

    # say L1441 aye
    old "It has to look real, sis."
    new "本物らしく見せなきゃな、姐さん。"

    # say L1442 oli
    old "I get it..."
    new "分かった..."

    # say L1445 oli
    old "I will do this then."
    new "それなら私がやるの。"

    # say L1450 oli
    old "The only reason I'm going along with this sick game of yours."
    new "この変態ゲームに付き合う唯一の理由は、あなたに私とこの人が関係があることを証明する他の方法がないからよ。"

    # say L1453 oli
    old "Is because I don't have any other way of proving to you that this guy and I have a relationship."
    new "それは私が君にこの男の子と関係があることを証明する方法がこれしかないからよ。"

    # say L1455 oli
    old "But this is the last time I'll let you push me into something like this."
    new "でもこれ以上は我慢できないから、こんなの二度とさせないからね。"

    # say L1458 oli
    old "If you ever try this again, I don't care what you have to say to anyone, I'll fucking make you pay!"
    new "またこんなことしようものなら、誰に何を言われようが、絶対に罰を与えてやるからね！"

    # say L1460 aye
    old "Very clear, sis, but I don't see you proving anything, so why don't you get to it?"
    new "分かってるよ、姉さん、でも証明できるわけじゃないじゃん、さっさと証明しろよ？"

    # say L1461 aye
    old "And remember, make it convincing."
    new "そして、本気でやってみろよ。"

    # say L1466 pla
    old "W- woah! Woah! Is this for real? Do you want to do this in front of her?"
    new "わお！わお！マジで？彼女の前でやる気なのか？"

    # say L1468 oli
    old "Do you get the situation, [pla]? Do you know how serious it is?"
    new "状況分かってる？[pla]？この事態の深刻さが理解できる？"

    # say L1469 oli
    old "Of course I'm being serious..."
    new "もちろん本気だよ..."

    # say L1484 aye
    old "Oh gosh! You're actually doing it!"
    new "おわせー！本気でやってるのか！"

    # say L1485 aye
    old "This is for real! I can't believe it!"
    new "本気だ！信じられない！"

    # say L1496 aye
    old "I have to say, sis, that was quite the spectacle."
    new "お姉さん、それは相当な興行だったね。"

    # say L1497 oli
    old "Are you satisfied?"
    new "満足してる？"

    # say L1498 aye
    old "Oh! Of course, I am!"
    new "もちろん、満足してるぜ！"

    # say L1499 aye
    old "I can tell how much you liked it!"
    new "お前がどれだけ気に入ったか、すぐ分かったよ！"

    # say L1502 aye
    old "You can just tell how much love there is between the two of you!"
    new "君たちの間にある愛がどれだけ深いのか、一目でわかるよ！"

    # say L1504 oli
    old "Alright, you have what you wanted. Now get the hell out of here!"
    new "分かったわ、欲しかったものも手に入れたでしょう。さあ、ここから出て行きなさい！"

    # say L1506 oli
    old "And remember what I told you."
    new "そして私が言ったことを覚えておいてください。"

    # say L1508 oli
    old "I won't allow this to happen a second time, now get the hell out of my room, you bitch!"
    new "二度とこんなことは許さないから、今すぐ私の部屋から出て行け、クソバitch！"

    # say L1510 aye
    old "Oh, I'm leaving alright."
    new "よし、出てくよ。"

    # say L1511 aye
    old "But I can't wait to see you again soon, [pla]."
    new "でもまたすぐ会えるのを楽しみにしてるよ、[pla]。"

    # say L1512 oli
    old "Out!"
    new "出て行くわ。"

    # say L1521 pla
    old "Uhmm... A- are you alright?"
    new "うーん… 大丈夫なのか？"

    # say L1523 oli
    old "Shut up, [pla]."
    new "黙りな、[pla]。"

    # say L1524 oli
    old "We still have a lot of ground to cover."
    new "まだたくさんのことをするんだから。"

    # say L1525 oli
    old "And not a lot of time, so let's just get back to studying."
    new "時間もそんなにないし、さっさと勉強に戻ろう。"

    # say L1526 pla
    old "R- right."
    new "うん、そうか。"

    # say L1545 pla
    old "I guess I'll go home for now. And I'll come back later."
    new "俺は一旦家に帰るよ。後でまた来るから。"

    # say L1548 oli
    old "But before you leave, I want to make something clear."
    new "でもあなたが帰る前に、一つはっきりさせておきたいことがあるの。"

    # say L1550 oli
    old "What just happened here was just a one-time thing, alright?"
    new "ここでのことは一回きりだからね、分かってるよね？"

    # say L1552 oli
    old "Don't get any ideas about it happening again."
    new "またそういうことになるなんて思わないでね。"

    # say L1555 pla
    old "S-sure, of course."
    new "分かってるよ、そうだね。"

    # say L1557 oli
    old "Alright, then I'll see you later."
    new "それじゃ、またね。"

    # say L1558 pla
    old "Sure, bye."
    new "じゃあ、また。"

    # say L1574 pla
    old "Alright, we somehow managed to cover everything."
    new "よし、何とか全部終わったな。"

    # say L1575 pla
    old "It might not have been too thorough."
    new "まあ、それほど完璧じゃなかったかもしれないけどね。"

    # say L1576 pla
    old "But I'm sure you know enough now to shoot for the highest grades."
    new "でも、これで十分な知識を得たはずだ。"

    # say L1581 pla
    old "I'm sure you'll do great."
    new "大丈夫だ、君ならきっとできるよ。"

    # say L1583 pla
    old "Just remember, all you have to do is stay calm while you're answering the questions."
    new "ただ覚えておいて、質問に答えるときは落ち着いていればいいんだよ。"

    # say L1585 pla
    old "As long as you don't worry too much, you should be fine to answer everything."
    new "心配しすぎなければ、全てに答えるのは大丈夫だよ。"

    # say L1589 oli
    old "I'll do my best to answer everything as well as I can!"
    new "頑張って、できるだけ良い答えを出します！"

    # say L1591 oli
    old "I'm so thankful for your help!"
    new "あなたの助けが本当にありがたいです！"

    # say L1593 oli
    old "Without you, I couldn't have gone through all those topics."
    new "あなたがいなければ、そんなにたくさんの話題をこなせなかったわ。"

    # say L1594 oli
    old "Really, thank you so much."
    new "本当にありがとう。"

    # say L1596 pla
    old "It's alright, I'm glad I was able to help you."
    new "大丈夫だよ、君の役に立てて良かった。"

    # say L1598 pla
    old "And I'm sure you'll do great on the exam."
    new "君の試験もきっと上手くいくさ。"

    # say L1600 pla
    old "So, I'll leave for now, and I'll see you later."
    new "じゃあ、俺は行くよ。また後でな。"

    # say L1602 oli
    old "Alright, I'll be sure to let you know how I do in the exams."
    new "はい、試験の結果はちゃんと教えてあげるね。"

    # say L1630 pla
    old "Hmm, I just remembered, I need to check my exam results when I get home."
    new "俺、家に帰ったら試験の結果確認しないとな。"

    # say L1637 pla
    old "Oh! Hey Olivia."
    new "オッ！オリアン、元気？"

    # say L1638 oli
    old "Hey, [pla]..."
    new "Hey、[pla]..."

    # say L1640 pla
    old "How did you do on the exams? Have you checked the results yet?"
    new "試験どうだった？結果見てみた？"

    # say L1642 pla
    old "How do you think you did on them?"
    new "試験はどう思ってる？"

    # say L1644 oli
    old "Well, about that, do you think you could come with me to my house?"
    new "ええ、そのことなんだけど、家に来てくれない？"

    # say L1645 pla
    old "Uh, s-sure. Is there anything wrong?"
    new "うーん、そうだね。何かあったの？"

    # say L1647 oli
    old "You have no idea... But I'll tell you at my house."
    new "あなたには想像もつかないわ… でも家で話すから。"

    # say L1648 oli
    old "Come on, let's go."
    new "さあ、行こう。"

    # say L1673 vee
    old "Yeah, yeah, I know."
    new "うんうん、分かってるよ。"

    # say L1676 vee
    old "Oh my god, Vihaan! I said I got it!"
    new "ああ、ビハーン！言ったわ、分かってるって。"

    # say L1682 vee
    old "What do you mean my fault?"
    new "私のせいって何？"

    # say L1684 vee
    old "Maybe if you were here too..."
    new "もしかしてあなたもここにいれば..."

    # say L1687 vee
    old "Yeah, I know..."
    new "うん、わかってる…"

    # say L1692 vee
    old "You know, this really isn't as bad as you're making it out to be."
    new "これほど悪くないわ、あなたが思っているほどに。"

    # say L1693 vee
    old "Well, because this isn't the end of the world."
    new "だって、これが世界の終わりじゃなくてよ。"

    # say L1697 vee
    old "She can always try again..."
    new "また挑戦できるわよ…"

    # say L1698 vee
    old "Oh! I know full well what you think about that!"
    new "あたしはあなたがどう思ってるか、よく知ってるわよ！"

    # say L1702 vee
    old "But that's beside the point."
    new "でも、それとは関係ないわ。"

    # say L1712 vee
    old "And what do you propose we do about her boyfriend?"
    new "じゃあ、彼女の彼氏のことについて、どうするべきだと思う？"

    # say L1716 vee
    old "Of course it's important, Vihaan!"
    new "もちろん大事なことよ、ヴィハーン！"

    # say L1721 vee
    old "What do you mean why?"
    new "何がなぜなの？"

    # say L1725 vee
    old "Because her feelings are important!"
    new "だって彼女の気持ちが大事だからよ。"

    # say L1729 vee
    old "I know that."
    new "知ってるよ。"

    # say L1734 vee
    old "No, he's not rich."
    new "でも、彼は裕福じゃないの。"

    # say L1735 vee
    old "But I think that's beside the..."
    new "でも、それとは別に……"

    # say L1739 vee
    old "Hmm, yeah that's true."
    new "うん、そうね。"

    # say L1744 vee
    old "{b}*Sigh*{/b} Yeah, you're very right."
    new "{b}*ため息*{/b} うん、そうね。"

    # say L1745 vee
    old "Yeah, I guess I'll talk to her."
    new "うん、そうね。彼女と話すことにする。"

    # say L1746 vee
    old "Yes, you're right."
    new "うん、そうよね。"

    # say L1748 vee
    old "You should talk to her as well."
    new "あなたも彼女と話した方がいいね。"

    # say L1749 vee
    old "Yeah, talk to you later then."
    new "じゃあ、また後でね。"

    # say L1753 vee
    old "So, I guess you got what your father said in that conversation."
    new "じゃあ、お父さんがその会話で言ったこと、分かったみたいね。"

    # say L1754 oli
    old "Yeah, I can figure."
    new "うん、分かったわ。"

    # say L1756 aye
    old "Oh! You're in trouble!"
    new "おっ！お前、やばいぞ！"

    # say L1760 aye
    old "What's the matter, sis?"
    new "何があったんだ、妹さん？"

    # say L1761 aye
    old "Is the favorite daughter not living up to expectations?"
    new "お気に入りの娘が期待に応えてないのか？"

    # say L1764 oli
    old "Why don't you shut your mouth before I shut it for you?"
    new "口を閉じなよ、私が閉めちゃうから。"

    # say L1765 vee
    old "OK! That's enough."
    new "OK！もういいわ。"

    # say L1766 vee
    old "Listen, Olivia, I don't like the attitude your father's taking on this."
    new "オリビア、君の父親の態度には賛成できないんだ。"

    # say L1767 vee
    old "But you were aware of what he wanted you to do."
    new "でも、彼があなたに何をさせようとしていたことは分かっていたでしょう。"

    # say L1768 vee
    old "And the only way that you could stop him from sending you to India was by getting good grades."
    new "そして、お父さんがあなたをインドに送るのを止める唯一の方法は、成績を上げることだったのよ。"

    # say L1770 vee
    old "I know, I know, this isn't fair."
    new "知ってる、知ってる、これって不公平だね。"

    # say L1771 vee
    old "But it is the way things are."
    new "でも、それが現実の話よ。"

    # say L1774 aye
    old "Because you're too stupid."
    new "君が馬鹿すぎるからさ。"

    # say L1775 vee
    old "The point is that your dad decided that he's not going to wait for you to finish the school year."
    new "要点は、お父さんが君が学年末まで待つことを拒否したということよ。"

    # say L1778 vee
    old "He told me that he wants you to start organizing your things."
    new "お父さんから、君の荷物を整理し始めるようにって言われたの。"

    # say L1782 vee
    old "After the next batch of exams, you're transferring to a school in India."
    new "次の試験が終わったら、インドの学校に転校することになるんだよ。"

    # say L1785 oli
    old "But that's not fair! He doesn't get to decide that for me!"
    new "でも、それは不公平だよ！彼にはそんな決め権ないんだから！"

    # say L1786 vee
    old "Well, apparently he does."
    new "まあ、どうやら彼には決める権利があるみたいね。"

    # say L1790 vee
    old "And honestly, Olivia, you should've known this was going to happen."
    new "正直に言うと、オリビア、これは起こると思っていたべきだったわ。"

    # say L1791 vee
    old "I'm sorry, honey, but at this point, there's not a lot more that I can do for you."
    new "ごめんなさい、ハニー、でもこの段階では、私がもっとできることはあまりないの。"

    # say L1792 aye
    old "It looks like you're taking a plane to our motherland, sis! Hahaha!"
    new "お前が母国に飛行機に乗る日が来たな、姉さん！ハハハ！"

    # say L1797 vee
    old "You shouldn't be gloating too much, young lady."
    new "そんなに喜んじゃいけないわ、若い娘さん。"

    # say L1799 vee
    old "With the way your grades are going, you'll be joining your sister."
    new "あなたの成績じゃ、姉と同じ道を歩むわよ。"

    # say L1805 vee
    old "You heard me, your father wasn't only talking about Olivia."
    new "聞こえたでしょ、あなたの父親はオリビアのことだけじゃなかったわ。"

    # say L1806 vee
    old "And your grades aren't much better than hers."
    new "あなたの成績も彼女と大差ないわ。"

    # say L1807 aye
    old "But, I mean... Mom!"
    new "でも、つまり… ママ！"

    # say L1810 vee
    old "We'll talk about this later, I have to run some errands."
    new "後で話すから、用事があるの。"

    # say L1814 vee
    old "Listen, honey, I'm sorry about this, but I guess that's just how it is."
    new "ねぇ、ごめんね、でも仕方ないのよ。"

    # say L1820 aye
    old "Wait, Mom, let me go with you! We still need to talk about Dad!"
    new "待って、ママ、俺も行かせて！まだパパのことで話さなきゃならないんだよ。"

    # say L1829 oli
    old "I imagine you can guess what happened..."
    new "想像ついてるよね..."

    # say L1830 pla
    old "I think so... The exams didn't go well?"
    new "そう思う… 試験は上手くいかなかったのか？"

    # say L1832 oli
    old "They didn't."
    new "試験は上手くいかなかったわ。"

    # say L1833 pla
    old "But you studied so hard."
    new "でも君は頑張って勉強したよね。"

    # say L1835 oli
    old "I did, and you did a great job teaching me [pla]."
    new "私は頑張ったわ、あなたの教え方がすごく役立ったのよ [pla]。"

    # say L1836 oli
    old "But when I was taking the exams, I couldn't focus."
    new "でも試験を受けているとき、集中できなかったの。"

    # say L1838 oli
    old "I just kept thinking about how important it was to get top marks."
    new "試験中ずっとトップの成績を取ることがどれだけ重要なのかばかり考えてて。"

    # say L1840 oli
    old "And the more I thought about it, the more scared I got."
    new "考えれば考えるほど、どんどん怖くなっていった。"

    # say L1842 oli
    old "In the end, I couldn't answer anything correctly."
    new "結局、何も正解できなかった。"

    # say L1844 pla
    old "I mean, I get it."
    new "分かってるよ。"

    # say L1846 pla
    old "With that much pressure, it would be hard to do well."
    new "そんなプレッシャーじゃ、上手くいくわけないよ。"

    # say L1847 pla
    old "I'm sorry, Olivia."
    new "ごめん、オリビア。"

    # say L1848 oli
    old "Well, it happens. Nothing I can do about it."
    new "まあ、仕方ないわ。何もできないわけじゃないけどね。"

    # say L1849 oli
    old "But that doesn't mean I won't deal with this."
    new "でも、それだからといって何もしないわけではないわ。"

    # say L1850 pla
    old "Oh... Okay, what do you have in mind?"
    new "オーケー、何を考えてるんだ？"

    # say L1852 oli
    old "Well, this is going to surprise you."
    new "まあ、これは君を驚かせるかもしれないね。"

    # say L1854 oli
    old "But I don't have an easy way to say this."
    new "でも、簡単には言えないの。"

    # say L1858 pla
    old "W- WHAT?! What are you talking about?!"
    new "W- 何言ってんの？！ 何の話だよ？！"

    # say L1860 oli
    old "You heard me, I'm going to get pregnant."
    new "あなたに伝えた通り、私は妊娠するの。"

    # say L1861 pla
    old "Yeah, that doesn't explain anything."
    new "そうだよ、全然説明になってないな。"

    # say L1863 pla
    old "I'm sorry, like an actual pregnancy?"
    new "すみません、本当に妊娠するってこと？"

    # say L1864 pla
    old "Or are you talking about pretending to be pregnant?"
    new "それとも偽装した妊娠のことか？"

    # say L1865 oli
    old "No, I mean literally pregnant."
    new "いいえ、本当に妊娠することよ。"

    # say L1866 pla
    old "W- what? B- but why?"
    new "えっ？　けどなぜ？"

    # say L1868 oli
    old "Because it's the only way to change my circumstances."
    new "だって、これ以外に私の状況を変える方法がないのよ。"

    # say L1870 pla
    old "That's putting it mildly!"
    new "それほどまでにって言うなよ！"

    # say L1872 pla
    old "Is this what you want? To be a mother?"
    new "これが君の望みなのか？母親になることか？"

    # say L1874 oli
    old "I don't."
    new "私はそうじゃない。"

    # say L1875 oli
    old "Or at least not yet."
    new "少なくとも今はそうじゃないわ。"

    # say L1877 pla
    old "Then why do you want to get pregnant?"
    new "じゃあなんで妊娠したいんだ？"

    # say L1879 oli
    old "Getting pregnant doesn't automatically mean I have to be a mother [pla]!"
    new "妊娠しても自動的に母親になるわけじゃないわよ [pla]！"

    # say L1881 oli
    old "I don't plan on carrying the pregnancy to term."
    new "妊娠を継続するつもりはないわ。"

    # say L1883 oli
    old "I just want to get rid of this whole {i}'arranged marriage'{/i} thing."
    new "この {i} 結婚話 {/i} 全部をなくしたいだけよ。"

    # say L1884 pla
    old "And how would that work?"
    new "それはどうやって実現するんだ？"

    # say L1886 oli
    old "In our culture, when a woman is arranged to marry, she's expected to be virtuous."
    new "私たちの文化では、女性が結婚することが決まると、徳を積むことが求められるの。"

    # say L1888 oli
    old "Nowadays, there's no way to ensure that the girl is a virgin."
    new "今は、女の子が処女かどうかを保証する方法がないからね。"

    # say L1889 oli
    old "So that tends to be overlooked."
    new "だからそれが見落とされがちなの。"

    # say L1891 oli
    old "But a pregnancy is a very different thing."
    new "でも、妊娠は全く違う問題よ。"

    # say L1893 oli
    old "The family of the guy my dad chose for me is very illustrious and traditional."
    new "私が選ばれた男の家族はとても有名で伝統的な家系だよ。"

    # say L1895 oli
    old "If they find out I'm pregnant, they'll cancel it immediately."
    new "もし妊娠していることが分かったら、すぐに取り消すだろう。"

    # say L1897 oli
    old "And better yet, once the word spreads, it'll be impossible for my father to arrange another marriage for me."
    new "それに、噂が広まれば、父親がまた別の結婚を決めるのは無理になるわ。"

    # say L1898 pla
    old "You seem very certain this will work."
    new "君はこれでうまくいくってすごく確信してるな。"

    # say L1900 oli
    old "Well, because I've seen something like it."
    new "だって、似たような状況を見たことがあるからよ。"

    # say L1902 oli
    old "I have this cousin who was in a similar situation a couple of years ago."
    new "このいとこが、数年前に似たような状況にいたの。"

    # say L1903 oli
    old "The difference is that she actually wanted to get married."
    new "違いは、彼女が実際に結婚したかったってことね。"

    # say L1905 oli
    old "The guy my uncle selected for her is a doctor who lives in Delhi."
    new "叔父が選んだ相手はデリーに住む医者だったの。"

    # say L1906 oli
    old "So on paper, she had the perfect deal."
    new "だから、紙面上では完璧な相手だったの。"

    # say L1909 oli
    old "The problem came when she went to a party and hooked up with some guy."
    new "問題は、彼女がパーティーで誰かと寝ちゃったことよ。"

    # say L1910 oli
    old "That's not a big deal, but she wasn't careful and ended up getting pregnant."
    new "それは大したことじゃないけど、彼女は気をつけていなかったから結局妊娠しちゃった。"

    # say L1911 oli
    old "She tried to keep it under wraps while she dealt with it."
    new "彼女はそれを隠しながら対処しようと試みた。"

    # say L1913 oli
    old "But that kind of thing is almost impossible to keep hidden in a place like Delhi, to be honest."
    new "でも、正直に言うと、デリーみたいなところではそんなことはほとんど隠せないよね。"

    # say L1915 oli
    old "So, her marriage was canceled almost immediately, there was nothing she could do."
    new "だから、彼女の結婚はすぐに取り消されちゃって、どうすることもできなかったの。"

    # say L1917 oli
    old "Moreover, she hasn't been able to get a single meeting to arrange a marriage."
    new "それに、結婚のための面会すら一度もできていないんだ。"

    # say L1918 oli
    old "Much less a fiancé."
    new "ましてや婚約者なんていないの。"

    # say L1919 pla
    old "Wow, is it really like that?"
    new "Wow、そうなのか？"

    # say L1921 oli
    old "Of course it is."
    new "もちろんそうよ。"

    # say L1923 oli
    old "It's not good to say, but once a woman gets pregnant, she's no longer seen as virtuous."
    new "言うのはよくないけど、一度女性が妊娠すると、もう清らかな存在とは見なされなくなるんだ。"

    # say L1925 oli
    old "Rather as {i}'damaged goods.'{/i} Ugh!"
    new "むしろ {i}「傷物」{/i} って扱われるの。うっ！"

    # say L1927 oli
    old "But yeah... That's why I believe my idea will work."
    new "でもね… それが私なりの考えがうまくいくと思うの。"

    # say L1929 pla
    old "Still, it sounds so drastic."
    new "それでも、ずいぶんと過激な手だな。"

    # say L1931 pla
    old "Don't you think there's anything less... extreme you could do?"
    new "君がもっと穏やかな方法を考えられないか？"

    # say L1932 pla
    old "How about taking other exams?"
    new "他の試験を受けてみたらどうだ？"

    # say L1934 oli
    old "What will that do? You already heard my mother, my dad won't even let me finish the year."
    new "それじゃ何になるの？ あなたも私の母親の話を聞いただろう、父親は私に今年を終えさせることさえ許さないんだから。"

    # say L1936 oli
    old "And to be honest [pla], I don't think that was ever a real option."
    new "正直に言うと [pla]、それは最初から現実的じゃなかったと思う。"

    # say L1938 oli
    old "I think he was just entertaining my mom, but his real plan has always been to get me married to someone in India."
    new "私は母をなだめるためにそう言っただけだと思うけど、本当の計画は私をインドの誰かと結婚させることだったんだ。"

    # say L1940 oli
    old "But that's not what I want for myself [pla]!"
    new "でもそれが私にとって望むものじゃないわ [pla]！"

    # say L1941 oli
    old "Life in an arranged marriage is restrictive."
    new "結婚生活は制約が多いわ。"

    # say L1943 oli
    old "You're not your own person; everything you want to do or have has to come through your husband."
    new "あなたは自分の人間じゃないの；やりたいことや欲しいもの全部を夫を通さないとダメよ。"

    # say L1944 oli
    old "Any social life you might want or access depends on him."
    new "あなたが望む社交生活やアクセスも、すべて彼次第だ。"

    # say L1946 oli
    old "In the best case, the guy will be understanding and permissive. And you can imagine how it is at the worst."
    new "最好的ケースでも、男の人は理解があり許してくれるわ。でも、最悪の場合は想像できるでしょ。"

    # say L1948 oli
    old "I don't want that for myself! Why do I have to marry some guy I don't know just so my dad can make money from it?!"
    new "私にはそんなのイヤだ！　なんで知らない男の人と結婚しなきゃならないの？　ただパパがお金を稼ぐためだけに？！"

    # say L1949 oli
    old "So, if I have to get pregnant to stop myself from being married to some guy I don't know, I'll gladly do it."
    new "だから、知らない男の人に嫁ぐのを避けるために妊娠しなきゃならないなら、喜んでやるわ。"

    # say L1951 pla
    old "I see, but are you sure you can do this?"
    new "分かったけど、本当にこれができると思う？"

    # say L1953 pla
    old "I mean, interrupting a pregnancy's not easy."
    new "妊娠を中断するのは簡単じゃないってことさ。"

    # say L1957 oli
    old "Well, abortion is legal and pretty common these days."
    new "中絶は今の時代、合法でわりと一般的よ。"

    # say L1959 oli
    old "I know a girl who got one."
    new "知ってる、友達の一人がやったことがあるの。"

    # say L1962 oli
    old "Yeah, she's a friend of Ruby."
    new "そう、ルビーの友達なんだよ。"

    # say L1964 oli
    old "She got pregnant from a one-night stand with her ex-boyfriend."
    new "彼女は元彼との一夜限りの関係で妊娠したの。"

    # say L1965 oli
    old "But she went to the hospital to get an abortion, and it went very well. You know?"
    new "でもね、彼女は病院で人工流产手術を受けたの。うまくいったの、知ってるでしょ？"

    # say L1966 pla
    old "I see... I think I get it."
    new "なるほど… 分かったような気する。"

    # say L1967 oli
    old "That's right, so you see it now, it's not a bad plan."
    new "そうだね、だから今なら理解できるでしょ、悪くないプランだと思うよ。"

    # say L1969 pla
    old "{i}(Now that I think about it, Brixxida did mention that a magical pregnancy would be quicker.){/i}"
    new "{i}(今考えてみれば、ブリクシダも魔力による妊娠は早いって言っていたな。){/i}"

    # say L1971 pla
    old "{i}(And she did tell me that I had to get as many women as I could pregnant.){/i}"
    new "{i}(そして、彼女は俺にできるだけたくさんの女性を妊娠させなきゃならないって言ったんだ。){/i}"

    # say L1972 pla
    old "{i}(Hmm, it could be that this is a good idea.){/i}"
    new "{i}(うーん、これならいいかもしれないな。){/i}"

    # say L1973 pla
    old "No, it isn't a bad plan."
    new "いや、悪くない計画だな。"

    # say L1975 oli
    old "And... That's more or less where you come in."
    new "そして… そこで君の出番だね。"

    # say L1976 oli
    old "Listen [pla], our original deal is already fulfilled."
    new "聞いてよ [pla]、元の約束はもう果たされてるわ。"

    # say L1978 oli
    old "I didn't pass my exams, but you still helped me the best way you could."
    new "試験は落ちたけど、君はできる限りのことをしてくれたわ。"

    # say L1979 oli
    old "So I wouldn't tell you that you have to get me pregnant."
    new "だからあなたに妊娠してほしいとは言わないよ。"

    # say L1981 oli
    old "But if I'm honest, it's hard for me to think of a better person to ask."
    new "でも正直に言うと、頼む相手としてあなたよりいい人は思い浮かばないな。"

    # say L1982 oli
    old "You know my situation in a way that I couldn't explain to anyone else."
    new "あなたなら、私の状況を誰にも説明できないことを理解してくれるわ。"

    # say L1984 oli
    old "And you wouldn't have to worry about it, all I need is your seed."
    new "あなたが心配することはないわ、必要なのはあなたの種だけだよ。"

    # say L1985 oli
    old "And I would take care of everything regarding the pregnancy and the interruption."
    new "妊娠や中絶に関するすべてのことを私が引き受けるから安心して。"

    # say L1987 oli
    old "But I would understand if you didn't want to do it."
    new "でも、あなたがやりたくないなら、理解するわ。"

    # say L1989 pla
    old "Actually, I was thinking that I wanted to help you with it."
    new "実は、君を手伝いたいと思ってたんだ。"

    # say L1991 pla
    old "What you say is true. I am fully aware of your situation, both with your parents."
    new "君の言う通りだ。君の状況、親のこと含めて、よくわかってるよ。"

    # say L1993 pla
    old "And what you're doing to try and deal with it."
    new "そして君がそれをどうやって対処しようとしているのか、ちゃんと知ってるよ。"

    # say L1994 pla
    old "So I agree that I'm probably the best person to help you with this."
    new "だから俺が君を助けるのに最適な人間だと思うよ。"

    # say L1996 pla
    old "Also, I'm really against what your parents are putting you through, you know?"
    new "それに、お前の親がお前にしてること、全然賛成できないんだよ。"

    # say L1998 pla
    old "I don't think it's fair at all that you have to live your life the way they want you to."
    new "君が自分の人生を親の思う通りに生きなきゃならないなんて、全然公平じゃないと思うよ。"

    # say L1999 pla
    old "So I'll help you get out of it."
    new "だから手伝うからね。"

    # say L2003 oli
    old "OK, let's go to my room."
    new "じゃあ、私の部屋に行こう。"

    # say L2004 pla
    old "W- what? Do it now?"
    new "え、今？"

    # say L2005 oli
    old "Yeah, of course. I don't think there's a better time for it."
    new "もちろんよ。今が一番いいタイミングだと思うわ。"

    # say L2006 oli
    old "My mom will be out with Ayesha running errands until late."
    new "私のママはアイシャと用事をして、夜遅くまで帰ってこないから。"

    # say L2008 oli
    old "And we don't have much time. I need to get pregnant soon."
    new "時間ないし、早く妊娠しないと。"

    # say L2009 oli
    old "So we should do it now."
    new "じゃあ、今すぐやろう。"

    # say L2026 oli
    old "Ok, so... Uhh, let's do it..."
    new "うん、そうね… えっと、じゃあ、始めよう…"

    # say L2027 pla
    old "Uhh... Yeah, yeah..."
    new "うーん… そうだな、そうだな…"

    # say L2028 oli
    old "Well... Uhh, where do we start? I mean, I know how to do it, but... Uhhh you get what I mean..."
    new "うーん、じゃあ、どこから始めていいかわからないな。私、基本的なことは知ってるんだけど……うーん、わかってるよね？"

    # say L2030 pla
    old "Uhh... Well, I think, we should... Uhh..."
    new "うーん……まあ、始めようか……うーん……"

    # say L2032 oli
    old "You know what, this is silly, we don't have time for this. After all, I've already sucked your cock..."
    new "これってばかみたいね、時間ないんだから。だって、もうあなたのちんこをしゃぶったんだし…"

    # say L2034 oli
    old "Alright, I'll start, after all, I'm the one who needs your help with this."
    new "よし、私が先に始めるわ、結局、この件で君の手伝いが必要なのは私だからね。"

    # say L2043 oli
    old "Does this feel good?"
    new "これ、気持ちいい？"

    # say L2044 pla
    old "U- uh, yeah..."
    new "うー、うん…"

    # say L2045 oli
    old "I have to say, you have a big... dick..."
    new "言わざるを得ないけど、あなたのアレ、大きいな…"

    # say L2046 pla
    old "Uhh, thanks..."
    new "うーん、ありがとう…"

    # say L2055 oli
    old "Alright! That was great [pla]!"
    new "よし！それでしたね [pla]！"

    # say L2056 oli
    old "It may be too soon to know if I'm pregnant yet, but I'll take a test as soon as I can and let you know."
    new "まだ妊娠してるかどうかはわからないけど、できるだけ早くテストして教えてあげるね。"

    # say L2058 pla
    old "Alright, that sounds good."
    new "そうだな、それならいいね。"

    # say L2060 oli
    old "Thanks again for helping me [pla]."
    new "また助けてくれてありがとう [pla]。"

    # say L2062 pla
    old "It's alright, I'm happy to help."
    new "いいよ、手伝うって言ったのに。"

    # say L2064 oli
    old "Anyway, I think you should get going before my mom gets back."
    new "でも、母が帰ってくる前に帰った方がいいよね。"

    # say L2065 pla
    old "Oh! Right, sure, I'll see you later."
    new "オッ、そうか、じゃあ後でな。"

    # say L2068 oli
    old "And hey, thank you again."
    new "そして、またありがとうね。"

    # say L2092 pla
    old "Hey! Brixxida! I have some very good news for you!"
    new "Hey！ ブリクシダ！俺に君にとってとても良いニュースがあるんだ！"

    # say L2095 pla
    old "Well, I made an advancement in our plans!"
    new "WELL、計画が進展したぜ！"

    # say L2098 pla
    old "Our plan of getting women pregnant."
    new "計画が進展したんだよ、ブリクシダ。女性を妊娠させるための計画さ。"

    # say L2099 pla
    old "You know, so we can use their magical power to feed the portal to the magic world."
    new "君たちの魔力を使って魔法の世界へのゲートを育てるんだよ。"

    # say L2101 bri
    old "Okay? How did you make this {i}'advancement?'{/i}"
    new "分かった？この{i}進展{/i}はどんなの？"

    # say L2103 pla
    old "Well, I have this friend from school who asked me for some help studying."
    new "まあ、学校の友達が勉強の手伝いを頼んできたんだ。"

    # say L2105 pla
    old "As we studied, we got closer, and I got to know her."
    new "勉強してるうちに、お互いに親しくなって、彼女のことを知るようになった。"

    # say L2106 pla
    old "It turns out that her problems were a lot bigger than just school."
    new "結局、彼女の問題は学校だけのものじゃなかったんだ。"

    # say L2108 pla
    old "And that the only way out of them was to get pregnant."
    new "そしてその問題から脱出する唯一の方法は妊娠することだったんだ。"

    # say L2110 bri
    old "So... You're telling me that you got this woman pregnant?"
    new "そう……あなたがこの女性を妊娠させたってこと？"

    # say L2112 pla
    old "I did!"
    new "やった！"

    # say L2113 pla
    old "Or at least I think I did, she told me she was going to take a pregnancy test."
    new "まあ、そう思ってるけど、彼女は妊娠テストを取るって言ってたよ。"

    # say L2117 bri
    old "You heard me!"
    new "聞こえたでしょ！"

    # say L2118 bri
    old "Did you forget what I told you last time?"
    new "前回言ったことを忘れたの？"

    # say L2119 pla
    old "Uhmm- We need the magic?"
    new "うーん、魔法が必要なの？"

    # say L2121 bri
    old "No! You idiot!"
    new "ダメよ！バカ！"

    # say L2123 bri
    old "What I told you is that I had to be there when you have sex with the girl!"
    new "私が言ったのは、あなたが女の子とセックスするときには私がいなきゃならないってことよ！"

    # say L2126 bri
    old "Ugh, try to pay attention when I speak to you."
    new "うっ、私が話してるときにはちゃんと聞いてよね。"

    # say L2127 bri
    old "Listen, it's not just about you getting her pregnant and that's it."
    new "ねぇ、ただ彼女を妊娠させるだけじゃなくてよ。"

    # say L2128 bri
    old "I have to be there to perform a ritual while it's happening."
    new "私がその場で儀式を行わなければならないの。"

    # say L2131 bri
    old "Of course! Otherwise, it would just be a regular pregnancy."
    new "もちろん！そうじゃなかったらただの普通の妊娠になっちゃうよ。"

    # say L2132 bri
    old "That's why it's so bad that you just went ahead and tried to get her pregnant!"
    new "だからこそ、あなたが勝手に彼女を妊娠させようとしたのが最悪だったのよ！"

    # say L2133 bri
    old "Because if she is, then we will have lost the chance of getting a girl pregnant."
    new "だって、もし彼女が妊娠していたら、女の子を妊娠させるチャンスを失うことになるの。"

    # say L2135 bri
    old "And we'll have to look for another person."
    new "そして別の人のことを探さないといけないの。"

    # say L2140 pla
    old "If that's true, why weren't you there when I had sex with Barbie and got her pregnant?"
    new "もし本当なら、なぜバービーとSEXして妊娠させたときにお前はいなかったんだ？"

    # say L2142 bri
    old "Who says that I wasn't?"
    new "誰がそう言ったわ？"

    # say L2145 bri
    old "Think about it [pla], where did you do it with Barbie the first time?"
    new "考えてみて [pla]、バービーと初めてやったのはどこだったっけ？"

    # say L2146 pla
    old "Uhm, we did it here."
    new "うーん、ここだったね。"

    # say L2148 bri
    old "Exactly, and this is where I spend most of my time."
    new "ここが私たちが初めてやった場所よね、そして私がほとんどの時間を過ごす場所。"

    # say L2149 bri
    old "I'm either at the garage, taking care of the portal."
    new "私はガレージでポータルの世話をしているか、ここできっと休んでいるわ。"

    # say L2150 bri
    old "Or I'm here resting."
    new "ここで休んでいるかしら。"

    # say L2151 bri
    old "So last time, when you arrived with Barbie, I was able to initiate the spell when you two started to have sex."
    new "前回、バービーと君が来たとき、二人がセックスを始めたときに Spells を発動できたの。"

    # say L2152 bri
    old "Otherwise it would've been wasted."
    new "それじゃあ無駄になっちゃうわ。"

    # say L2154 bri
    old "Yeah... Luckily that time we were fine."
    new "うん… 幸運にもその時は大丈夫だった。"

    # say L2155 bri
    old "But I'm not omnipresent [pla]."
    new "でも私はいたるところにいられないのよ [pla]。"

    # say L2156 bri
    old "Now there's a chance that girl is pregnant and we may have lost our next chance."
    new "今その子が妊娠しているかもしれないし、次のチャンスを失ったかもしれないわ。"

    # say L2157 pla
    old "I- I'm sorry Brixxida, I should have talked it over with you before I had sex with her."
    new "ブリクシダ、ごめん、俺が先に君と相談すべきだったよ。"

    # say L2158 pla
    old "But I mean, there's still a chance that she's not pregnant."
    new "でも、まだ妊娠してない可能性もあるよ。"

    # say L2160 bri
    old "Hmph, for your sake, we better hope she isn't."
    new "ふん、あなたのためを思って、彼女が妊娠していないことを望むよね。"

    # say L2162 bri
    old "Now, in order for this to not happen again."
    new "それなら、これ以上起こらないようにするために。"

    # say L2163 bri
    old "I think I should teach you a summoning spell."
    new "私、あなたに召喚の呪文を教えてあげると思う。"

    # say L2164 bri
    old "So that this doesn't happen again."
    new "そう、これと同じことが二度と起こらないように。"

    # say L2166 pla
    old "S- summoning spell?!"
    new "Ｓ－召喚呪文？！"

    # say L2167 bri
    old "Right, this isn't the most complicated spell, so you should be able to master it easily."
    new "そうだね、この呪文はそんなに複雑じゃないから、君なら簡単にマスターできるはずだよ。"

    # say L2168 bri
    old "And it's good that you know it."
    new "それにあなたがそれを知っているのは良いことよ。"

    # say L2169 bri
    old "So that you can call on me whenever you see yourself in a situation where you think we can start the ritual with someone."
    new "そうすれば、あなたが誰かと一緒に儀式を始められると感じる状況で、私を呼び出せるわ。"

    # say L2170 pla
    old "I see... Alright, so how does this spell work?"
    new "分かった… じゃあ、この呪文はどう使えばいいんだ？"

    # say L2171 bri
    old "I'll tell you, get your SexNote out."
    new "SexNoteを出してね。"

    # say L2175 bri
    old "Alright, I'll explain everything to you, pay attention."
    new "大丈夫、全部説明するから、よく聞いて。"

    # say L2184 bri
    old "Alright, that should be enough for now."
    new "それじゃ、これで十分でしょう。"

    # say L2185 bri
    old "With that, you should be able to do the spell properly without needing any kind of help from my end."
    new "それであなたは、私の手助けなしにその呪文を正しく使えるはずです。"

    # say L2187 pla
    old "I got it, I'll keep that in mind."
    new "分かった、覚えておくよ。"

    # say L2190 pla
    old "By the way, since you say it isn't a normal pregnancy."
    new "それにしても、普通の妊娠じゃないって言ってたけど。"

    # say L2192 pla
    old "How is a magical pregnancy different from a normal one?"
    new "魔力による妊娠は普通の妊娠とどう違うんだ？"

    # say L2195 bri
    old "Listen, in general, she'll have more or less the same experience she would if this was a normal, human pregnancy."
    new "一般的には、普通の人間の妊娠と同じような経験をするのだけど。"

    # say L2196 bri
    old "But there will be two big differences."
    new "でも、二つの大きな違いがあります。"

    # say L2197 bri
    old "The first one is that it's going to be a lot faster than it would normally be."
    new "まずは、通常の人間の妊娠よりもずっと早く進むということです。"

    # say L2198 bri
    old "Since she'll be concentrating magic power within her."
    new "彼女が魔力を集中させるからね。"

    # say L2199 bri
    old "It's different from woman to woman, but it should be about a third of the time."
    new "それは人それぞれだけど、通常の三分の一くらいになるはずよ。"

    # say L2201 bri
    old "Maybe even a fourth, who knows."
    new "でも四分の一くらいかもしれないわね。"

    # say L2204 bri
    old "Well, if you're going to be a father or not depends on whether or not she'll have the {i}'baby'{/i}."
    new "まあ、あなたが父親になるかどうかは、彼女が {i}'赤ちゃん'{/i} を作るかどうかによるわ。"

    # say L2206 bri
    old "Either way, it doesn't make a difference for us."
    new "どちらにしても、私たちにとっては変わらないわ。"

    # say L2207 pla
    old "It doesn't?"
    new "そうか？"

    # say L2208 pla
    old "That's good to hear."
    new "それを聞いて嬉しいな。"

    # say L2210 bri
    old "Yeah, what we're doing is using the pregnancy to concentrate the magic in her body."
    new "そうね、私たちがやってることは彼女の体内に魔力を集中させるため妊娠を利用してるの。"

    # say L2212 bri
    old "The baby itself is not actually important to our plans."
    new "赤ちゃんそのものは私たちの計画にとって実際には重要じゃないんだ。"

    # say L2214 bri
    old "So, when the moment comes to harvest the magic, it can be done either by the baby being born."
    new "だから、魔法を収穫するタイミングが来たら、赤ちゃんが生まれるか、あるいは何らかの理由で妊娠が中断されるかのどちらでもいいの。"

    # say L2215 bri
    old "Or by the pregnancy being interrupted."
    new "または、妊娠が中断されるときでも。"

    # say L2217 bri
    old "It doesn't matter, as long as I can harvest the magic growing within her."
    new "どちらでもいいわ、彼女の体内で育っている魔法を収穫できればそれでいいの。"

    # say L2220 bri
    old "By the way, there's another small difference with a normal pregnancy you have to look out for."
    new "それとも、普通の妊娠とは違う小さな違いにも気をつけて。"

    # say L2222 bri
    old "This pregnancy will come with the added need for magic power within her system."
    new "この妊娠は、彼女の体内で魔法の力が必要になるわ。"

    # say L2224 bri
    old "As the baby grows in her womb, she'll naturally absorb it from the environment."
    new "胎児が大きくなるにつれて、彼女は自然と周囲から魔力を吸収するようになるわ。"

    # say L2225 bri
    old "But you can expect that she'll still feel the need for sex. Much like how us shinigami need it from you."
    new "でも彼女がセックスの欲求を感じ続けることは予想できるわ。私たち死神が君から必要とするのと似ているの。"

    # say L2227 bri
    old "You'll probably have to have sex with her once in a while during her pregnancy."
    new "妊娠中も時々セックスをする必要があるでしょうね。"

    # say L2228 bri
    old "So that's a very good thing for you."
    new "だからそれはあなたにとってとても良いことよ。"

    # say L2231 bri
    old "Listen [pla], I hope that girl isn't pregnant, so that we won't miss a chance to add somebody to the ritual."
    new "Listen [pla]、その子が妊娠してないことを願ってるわ。そうすれば儀式に誰かを加えるチャンスを逃さなくて済むから。"

    # say L2232 pla
    old "I understand, and I'm sorry I didn't let you know about it before doing it."
    new "分かってる、前に言ってあげなかったこと謝るよ。"

    # say L2233 pla
    old "I'll talk to her, and I'll let you know how things evolve."
    new "彼女と話すから、その後どうなったか教えてあげるね"

    # say L2234 bri
    old "Alright, I'll be waiting for the news."
    new "分かった、その後の話を待ってるね。"

    # say L2254 pla
    old "Hey Olivia, I came to-"
    new "Hey Olivia、俺が来たんだけど-"

    # say L2256 oli
    old "I can't believe this! I just can't believe it!"
    new "信じられない！本当にこれって！"

    # say L2258 vee
    old "I'm sorry honey, but this is not my fault."
    new "ごめんね、でもこれって私のせいじゃないよ。"

    # say L2260 oli
    old "And is it my fault?"
    new "それって私のせい？"

    # say L2261 vee
    old "Well, who else?"
    new "じゃあ、誰のせいなの？"

    # say L2262 oli
    old "Oh my God, I can't believe you're saying that!"
    new "お天道様、君がそんなこと言うなんて信じられない！"

    # say L2263 oli
    old "You know what this means, right?!"
    new "これってどういうことなのか知ってるわ？！"

    # say L2265 oli
    old "He already decided on the date of the marriage!"
    new "結婚の日をもう決めてるの！"

    # say L2267 oli
    old "He can't do that! How can you just let him decide that by himself!"
    new "彼はそんなことできるわけないよ！ 自分だけで決めるなんて、どうして許せるのさ！"

    # say L2269 vee
    old "This isn't my fault, Olivia!"
    new "これは私のせいじゃないよ、オリビア！"

    # say L2270 vee
    old "I tried to help you, you know that."
    new "知ってるでしょ、私は君を助けるためにはがしたんだ。"

    # say L2273 vee
    old "But you didn't do your part!"
    new "でもあなたの部分は全然しなかったじゃない！"

    # say L2274 vee
    old "You knew what your father's expectations were."
    new "あなたは父親の期待を知っていたはずだね。"

    # say L2277 vee
    old "But instead of studying to improve your grades, you decided to waste time."
    new "でも成績を上げるために勉強する代わりに、時間の無駄遣いを選んだのね。"

    # say L2278 vee
    old "What do you expect me to do for you then?"
    new "それじゃ、私が君のために何をすればいいの？"

    # say L2279 vee
    old "It was up to you, and you didn't do what you had to."
    new "君がやるべきことをしなかったんだよ。"

    # say L2282 oli
    old "And that means that I have to be sent away to be married to some stranger?!"
    new "それって、私が見知らぬ男の人に嫁ぐために送り出されるってこと？！"

    # say L2283 oli
    old "That's my punishment for doing badly in algebra?!"
    new "代数で成績が悪かったからって、それが私の罰なの？！"

    # say L2284 oli
    old "I can't believe you, Mom! With all that you kept talking about how you don't agree with what Dad wants to do!"
    new "信じられない、ママ！いつも爸爸のやり方には賛成していないって言ってたじゃない！"

    # say L2287 vee
    old "I don't agree with it! But you know that your father's word is law!"
    new "私は賛成できないけど、お母さんも知っててよね、お父さんの言うことは絶対だってことを。"

    # say L2290 vee
    old "If you wanted to get out of it so badly, all you had to do was study."
    new "もしそんなに嫌なら、勉強すればよかったのに。"

    # say L2292 vee
    old "Now it's too late to cry over spilled milk."
    new "今更泣いても仕方ないわ。"

    # say L2294 vee
    old "You should've thought about that before wasting your time with the likes of Ruby."
    new "その前にルビーのようないやらしいことに時間を使わなければよかったわね。"

    # say L2297 vee
    old "I'm sorry honey, but this is just how it is."
    new "ごめんね、でもこれが現実のようだわ。"

    # say L2298 vee
    old "And you'll have to learn to live with it."
    new "それを生き延びるしかないと学ばなきゃならないのよ。"

    # say L2299 oli
    old "Yeah... I don't think I will."
    new "うん… そうは思えない。"

    # say L2301 oli
    old "I don't think I'll have to learn to live with it."
    new "私はそれを受け入れる必要はないと思う。"

    # say L2302 oli
    old "I won't do what dad wants me to."
    new "パパが望むことにはしないわ。"

    # say L2303 vee
    old "Olivia, be reasonable, how are you planning to go against your father's wishes?"
    new "オリビア、まともに考えなさい、どうやって父親の望みに逆らうつもりなのかしら？"

    # say L2305 oli
    old "I don't plan on doing anything."
    new "何もするつもりはないよ。"

    # say L2308 oli
    old "Especially because I already did it."
    new "特に、もうやっちゃったから。"

    # say L2309 vee
    old "Okay now you're just being cryptic, what are you talking about?"
    new "何言ってるの詳しく説明してよ。"

    # say L2313 vee
    old "W- what?! P- pregnant?! What do you mean?!"
    new "W- 何よ？！ P- 妊娠って？！ どういうことよ？！"

    # say L2316 vee
    old "When did this happen?!"
    new "いつからそんなことになってたの？！"

    # say L2318 oli
    old "Well, I only found out last week, but I wouldn't know exactly when I got pregnant."
    new "先週わかったけど、いつ妊娠したのかは正確にはわからないの。"

    # say L2321 oli
    old "But that's how things are, Mom. I wanted to be sure before letting you know, but the situation calls for me to let you know."
    new "でもそうなの、ママ。確信が持てるまで言いたくなかったけど、状況的に言っておく必要があったの。"

    # say L2322 vee
    old "And you think this is the best moment to bring that out?!"
    new "今さらこんな時言うの？！"

    # say L2325 vee
    old "If you already knew, you should've let us know sooner!"
    new "知ってるなら、もっと早く教えてくれればよかったのに！"

    # say L2327 vee
    old "Do you have any idea about what this means?!"
    new "これって何を意味してるのか、分かってるの？！"

    # say L2328 vee
    old "Do you know how your dad will react?!"
    new "お父さんの反応、君知ってるの？！"

    # say L2330 oli
    old "I don't know, but he won't be able to send me to India like this."
    new "知らないけど、こんな状態じゃインドには行かせられないわ。"

    # say L2333 vee
    old "And you think things are just going to be alright?!"
    new "大丈夫だなんて思ってるの？！"

    # say L2335 vee
    old "Your father will come here and kill [pla]!"
    new "お前の父親がここに来て、[pla]を殺すぞ！"

    # say L2338 vee
    old "I can't believe this from you, Olivia! Not only did you get pregnant, but you also hid it!"
    new "Olivia、信じられないわ！お腹を膨らませただけじゃなく、隠してたなんて！"

    # say L2340 oli
    old "But you guys were pushing me so hard into it! I just didn't know how to!"
    new "でもあなたたちがそんなに押してきて！どうすればいいか分からなかったんだよ！"

    # say L2341 vee
    old "No! I don't want to hear anything from you!"
    new "ダメよ！何も聞きたくない！"

    # say L2343 vee
    old "You have no idea about what this that you're doing means."
    new "君がやってることの意味なんて、全然わかっていないわ。"

    # say L2344 vee
    old "So I won't listen to you and I won't talk to you about it for now!"
    new "だから今は君の話を聞かないし、これについては話さないわ！"

    # say L2345 oli
    old "What? B- but!"
    new "何？でも待って！"

    # say L2346 oli
    old "Ughh...!"
    new "うぐっ……！"

    # say L2353 pla
    old "I- Uh... E- excuse me!"
    new "あ、あの… す、すみません！"

    # say L2363 pla
    old "Hey."
    new "おい。"

    # say L2366 pla
    old "Sooo... I guess you're pregnant?"
    new "じゃあ……君が妊娠してるってことか？"

    # say L2368 oli
    old "Of course I'm not."
    new "もちろんじゃないわ。"

    # say L2370 oli
    old "We only did it once, it can happen but we weren't lucky."
    new "一度だけだから、妊娠する可能性はあったけど、運が良くなかったみたい。"

    # say L2372 oli
    old "I only said that to my mom to get both her and my dad off my back."
    new "私はママとパパに追いつめられたくなかったから、そう言っただけよ。"

    # say L2373 oli
    old "But now I have to be pregnant for real!"
    new "でも今度は本気で妊娠しないといけないのね。"

    # say L2375 oli
    old "And it can't take too long."
    new "それも長くはかかれないわ。"

    # say L2376 oli
    old "Because they'll want to check soon for it."
    new "彼らはすぐにチェックしにくるでしょう。"

    # say L2379 pla
    old "So, s- should we do it now?"
    new "じゃ、今すぐやるか？"

    # say L2382 oli
    old "Of course not!"
    new "もちろんないわ！"

    # say L2384 oli
    old "My mom said she didn't want to talk to me for now."
    new "私のママは今、私と話したくないって言ったの。"

    # say L2386 oli
    old "But be sure that she's going to barge in here any minute now."
    new "でもすぐにここに突入してきそうだから。"

    # say L2388 oli
    old "Actually, I think it would be better if you leave for now."
    new "実際、今しばらくいなくなってくれた方がいいと思うの。"

    # say L2390 oli
    old "Just to avoid an awkward situation."
    new "ちょっとした気まずさを避けるためよ。"

    # say L2391 pla
    old "Oh yeah, sure, we can talk later."
    new "分かった、後で話そう。"

    # say L2394 oli
    old "Sure, see you..."
    new "そうだね、後でね…"

    # say L2422 oli
    old "Oh! [pla]!"
    new "オッ！[pla]！"

    # say L2423 oli
    old "I was just thinking that I have to talk to you."
    new "ちょうどあなたに話さなきゃならないことがあったの。"

    # say L2427 pla
    old "How did everything turn out after I left your home?"
    new "家を出た後、どうなったんだ？"

    # say L2428 oli
    old "Ugh, you have no idea."
    new "うーん、あなたにはわからないだろう。"

    # say L2430 oli
    old "My mom called my dad and told him everything."
    new "私のママがパパに電話して、全部話しちゃったの。"

    # say L2432 oli
    old "He got incredibly angry and started screaming about honor and responsibility."
    new "父はものすごく怒って、名誉と責任について叫び始めた。"

    # say L2434 oli
    old "I'm glad it was only over the phone, I can't imagine what he would've done if I had been in front of him."
    new "電話で済んで良かった、直接会っていたら何をしたか想像もつかない。"

    # say L2435 pla
    old "It got that bad, huh?"
    new "それほどまでにか？"

    # say L2437 pla
    old "I guess he's that worried about you then."
    new "そうか、彼は君のことを心配してるのか。"

    # say L2438 oli
    old "I don't think it has anything to do with me."
    new "私とは関係ないと思うの。"

    # say L2440 oli
    old "He's just angry about having to call off the engagement."
    new "彼はただ、婚約を解消することに怒ってるだけよ。"

    # say L2441 pla
    old "Really?! That's what bothers him?"
    new "本当か？それがあいつを悩ませてるのか？"

    # say L2443 oli
    old "It is, it's just an integral part of our culture [pla]."
    new "そう、それは私たちの文化の重要な部分だから [pla]。"

    # say L2445 oli
    old "In India, an arranged marriage is something to be taken seriously."
    new "インドでは、見合い結婚は真剣に受け止められるものだよ。"

    # say L2446 oli
    old "Because it's a promise of uniting families."
    new "だって、それは家族を結びつける約束だから。"

    # say L2448 oli
    old "Now my dad has to go to his friend's house and explain to him why I can't get married."
    new "今、私の父親が友達の家に行って、なぜ私が結婚できないのか説明しなきゃならないの。"

    # say L2449 pla
    old "I see, I guess honor's very important there."
    new "なるほど、名誉が大切なんだな。"

    # say L2451 oli
    old "It is, but if I'm honest with you, it has nothing to do with that."
    new "そうだけど、正直に言うと、それとは全然関係ないの。"

    # say L2454 oli
    old "He's just angry about losing this business."
    new "彼はただこの商売を失ったことに怒ってるだけよ。"

    # say L2456 oli
    old "Yeah, those marriages are very honorable and whatever."
    new "そうね、その結婚はとても名誉なことみたいだけど。"

    # say L2458 oli
    old "But what he cares about are the business opportunities he could get by marrying his daughters to rich men."
    new "でも、彼が気にしているのは娘たちを裕福な男と結婚させることで得られるビジネスチャンスよ。"

    # say L2461 oli
    old "But it doesn't matter now."
    new "でも、もう関係ないわ。"

    # say L2463 oli
    old "Once the news that I'm pregnant starts spreading around, nobody will want to marry me."
    new "妊娠の噂が広まれば、誰も私と結婚なんてしたくないわ。"

    # say L2464 oli
    old "And Dad will have to leave that alone."
    new "でも、パパはそれ以上何も言わなくなるわ。"

    # say L2465 pla
    old "Ok, so it's all done, right?"
    new "分かった、じゃあ全部決まったってことだな。"

    # say L2469 oli
    old "Yeah, he has to get off my back, but that only means that I HAVE to get pregnant."
    new "うん、彼には文句を言わせないけど、それだけじゃなくて、私が絶対に妊娠しなきゃならないの。"

    # say L2471 oli
    old "And that's where you come in."
    new "そこで君の出番だよ。"

    # say L2473 oli
    old "I wanted to ask you if you can come to my house with me."
    new "あなたと家に来てくれないかな。"

    # say L2474 oli
    old "My mom's going to be out with my sister running some errands."
    new "ママは妹と一緒に用事を済ませにでかけるから。"

    # say L2475 oli
    old "Which means I'll have the house to myself for some hours."
    new "それって、何時間も家を独り占めできるってことよね。"

    # say L2477 oli
    old "That's an opportunity that we can't let pass."
    new "そのチャンスを逃す手はないわ。"

    # say L2478 oli
    old "So, can you come with me to my house?"
    new "じゃあ、私の家に来られる？"

    # say L2481 oli
    old "Alright! Let's not waste any time and go then."
    new "よし！時間無駄にせずにさっそく行こう。"

    # say L2502 oli
    old "Alright, are you ready for it?"
    new "よし、準備できてる？"

    # say L2505 oli
    old "Ok, give me a second to freshen up, and we'll do it."
    new "ちょっと待って、身支度を整えてからにしよう。"

    # say L2512 pla
    old "Ok, I guess now's the time to call Brixxida."
    new "よし、じゃあブリクシダに連絡するか。"

    # say L2525 bri
    old "Wow! What's this?"
    new "Wow！これって何？"

    # say L2527 pla
    old "Hey, this girl and I are about to start having sex."
    new "Hey、この子とセックスするところなんだ。"

    # say L2529 pla
    old "So I summoned you to make sure everything goes well."
    new "じゃあ、君を呼んだのは、すべてがうまくいくようにするためさ。"

    # say L2530 bri
    old "I see, good, that's good."
    new "そうね、それはいいわ。"

    # say L2538 oli
    old "Hey, are you ready?"
    new "HEY、準備できてる？"

    # say L2539 pla
    old "Sure, sure, let's do it."
    new "うん、うん、やろうやろう。"

    # say L2540 oli
    old "Ok, just remember to be gentle... I'm still not used to your big cock."
    new "じゃあ、優しくしてね…まだあなたの大きいのには慣れてないの。"

    # say L2541 pla
    old "Sure, of course..."
    new "もちろん、問題ないさ…"

    # say L2559 oli
    old "I'm sure that this time it worked."
    new "今度はきっと上手くいったわ。"

    # say L2561 pla
    old "Yeah, I'm sure it did."
    new "うん、きっと上手くいったさ。"

    # say L2562 pla
    old "At least this way you can get your family off your back a little."
    new "少なくともこの方法なら、家族に少しは文句をつけられないかもしれないな。"

    # say L2565 oli
    old "Yeah, well, I wouldn't be so sure about that."
    new "まあ、そうとも限らないけどね。"

    # say L2566 oli
    old "But let's see how everything goes."
    new "でも、まずは様子を見ましょう。"

    # say L2567 oli
    old "But now, I think you better leave before my mom comes back and sees us like this."
    new "でも、今ならママが戻ってきちゃう前に出ていった方がいいわ。"

    # say L2568 oli
    old "That shouldn't be a problem if we're supposed to be dating."
    new "それなら問題ないわね、付き合ってるふりをしてるんだから。"

    # say L2569 oli
    old "But let's not push our luck."
    new "でも、運を試すのはほどほどにしよう。"

    # say L2570 pla
    old "Sure, I understand. I'll leave, but I'll check on you later to see how you're doing."
    new "わかった、後でまた様子を見にくるからな。"

    # say L2572 oli
    old "Thank you [pla], for everything."
    new "ありがとう、[pla]。すべてのことについて。"

    # say L2574 pla
    old "Alright, I'll see you later."
    new "じゃあ、後でな。"

    # say L2591 bri
    old "I'm sure that this is going to work!"
    new "これならきっと大丈夫！"

    # say L2592 bri
    old "Well done!"
    new "よくやったね！"

    # say L2593 pla
    old "Thank you, I'm glad you're satisfied with the results."
    new "ありがとう、君が結果に満足してくれて嬉しい。"

    # say L2595 bri
    old "Of course I am."
    new "もちろんだよ。"

    # say L2596 bri
    old "And now we can move on to the next target!"
    new "そして次のターゲットに進めるわね！"

    # say L2597 pla
    old "Don't we have to make sure that everything's alright with Olivia before doing that?"
    new "オリビアが大丈夫かどうか確認しないとダメじゃないか？"

    # say L2598 bri
    old "Oh don't worry, I'm sure that everything's going to be alright!"
    new "心配しないで、きっと大丈夫だから！"

    # say L2599 bri
    old "There's no doubt about it."
    new "心配しないで、絶対大丈夫だから。"

    # say L2601 pla
    old "I guess I'll get to looking for new girls."
    new "じゃあ、新しい娘を探してみるか"

    # say L2602 pla
    old "I'll let you know what I find."
    new "見つければすぐ教えてるぞ。"

    # say L2604 bri
    old "Great! I'll be waiting."
    new "Great！ 待ってるね。"

    # say L2605 bri
    old "Once again, well done [pla]."
    new "またしても、よくやった [pla]。"

    # say L2625 pla
    old "Hey Olivia, how are you?"
    new "Hey Olivia、調子はどう？"

    # say L2628 oli
    old "I'm doing fine."
    new "調子はいいのよ。"

    # say L2629 oli
    old "Although I have to say it's been difficult to deal with my family these last few days."
    new "でも、最近の家族との対応はちょっと大変だったの。"

    # say L2630 pla
    old "It has?"
    new "そうなのか？"

    # say L2632 oli
    old "Yeah, I got a pregnancy test done."
    new "うん、妊娠テストしたの。"

    # say L2633 oli
    old "My dad and mom wanted to make sure that I actually was pregnant and I wasn't just lying to get out of the marriage."
    new "私のパパとママは、私が本当に妊娠しているのか、結婚から逃れるためのウソではないかを確認したくて。"

    # say L2634 oli
    old "So, they took me to an ob-gyn and asked them to do the test."
    new "だから、パパとママは産婦人科の先生に連れて行って、検査してもらったの。"

    # say L2635 pla
    old "And? What did it say?"
    new "で？結果はどうだった？"

    # say L2637 oli
    old "It came out positive!"
    new "陽性だった！"

    # say L2638 oli
    old "It's good that I got pregnant when I did, because otherwise who knows what would've happened."
    new "妊娠できたのは良かったわ、そうでなければ何が起こったかわからないわ。"

    # say L2639 oli
    old "I would probably be on a plane on my way to India right now."
    new "今ごろインド行きの飛行機に乗っていただろうな。"

    # say L2640 pla
    old "Well, I guess it's a good thing that you're pregnant then."
    new "まあ、君が妊娠したのは良かったってことか。"

    # say L2641 pla
    old "Does that mean that your parents are going to back off now?"
    new "それって、お前の親が手を引くってことなのか？"

    # say L2642 oli
    old "Well, not really, if anything I think they'll just get even more intense."
    new "まあ、そうでもないわ、むしろもっと激しくなると思う。"

    # say L2644 oli
    old "My dad's incredibly furious right now."
    new "今、私の父親はものすごく怒ってるの。"

    # say L2645 oli
    old "You should've seen him, talking about how his good name is being dragged through the mud."
    new "你应该见过他，说着他的好名声被玷污了。"

    # say L2646 oli
    old "They also told me to let you know that you should get ready for a marriage."
    new "彼らはあなたに結婚の準備をするように伝えてくれたって言ったの。"

    # say L2647 oli
    old "Because there's no way that I'm having a bastard child."
    new "だって私は浮気者の子を産むつもりはないから。"

    # say L2649 pla
    old "W- what? M- marriage?"
    new "えっ、結婚？"

    # say L2650 pla
    old "B- but I thought you said that wasn't going to happen."
    new "でも君はそれが起こらないって言ったじゃん。"

    # say L2652 oli
    old "And it probably won't, because I won't let it come to that."
    new "でも、その前に私が止めるから大丈夫よ。"

    # say L2654 oli
    old "Besides, remember that the plan is to interrupt the pregnancy before it gets to term."
    new "それに、計画は妊娠が長期化する前に中断することだから。"

    # say L2656 oli
    old "So there is some pressure because of it."
    new "だから少しプレッシャーはあるけど。"

    # say L2658 oli
    old "But I don't think my mom's going to consult you about wedding plans anytime soon."
    new "でも、ママが結婚のことを相談してくれるとは思えないわ。"

    # say L2659 pla
    old "I see... I guess that's a little reassuring."
    new "なるほど…少しは安心したか。"

    # say L2660 oli
    old "But anyway, that's not what's most important."
    new "でも、それよりもっと重要なことがあるの。"

    # say L2665 oli
    old "What's most important is what I'm going to do next after this pregnancy."
    new "大事なのは、この妊娠の後私が何をするかだよ。"

    # say L2667 pla
    old "Are you planning something else?"
    new "何か他のことを計画してるのか？"

    # say L2668 oli
    old "Of course, my plan is not to be a young mom."
    new "もちろん、私の計画は若いうちに母親になることじゃないの。"

    # say L2670 oli
    old "And I didn't get pregnant just to get out of an arranged marriage."
    new "妊娠してまで見合い結婚から逃げるつもりはないわ。"

    # say L2671 oli
    old "This whole situation is just to buy some time for me to start doing some things that I want to do."
    new "この状況は、私がやりたいことを始めるための時間を稼ぐためだけよ。"

    # say L2673 oli
    old "I decided that I want to get into college."
    new "私が大学に入りたいって決めたの。"

    # say L2675 oli
    old "I need to get on my mother's good side, and to establish a future for myself."
    new "母親の機嫌を取りながら、自分の未来を築かなくちゃ。"

    # say L2677 pla
    old "That sounds great Olivia, it sounds like a great plan."
    new "オリビア、それはいいね、立派な計画だね。"

    # say L2679 oli
    old "Yeah, but listen..."
    new "うん、でも聞いて...\";"

    # say L2681 oli
    old "I don't really know how to ask you this."
    new "あの、このことどう聞いたらいいかわかんないんだけど。"

    # say L2683 oli
    old "But I was wondering if you could help me study for the college entrance exams."
    new "でも、大学入試の勉強を手伝ってくれないかな。"

    # say L2685 oli
    old "I know that I've already asked way too much of you, more than what would be reasonable."
    new "すでにたくさんお願いしてしまって、申し訳ないけど。"

    # say L2687 oli
    old "But the truth is that you're a very good teacher, and I think that to get into college I will really need your help."
    new "でも、あなたは本当に良い先生で、大学に合格するためにはあなたの手伝いが必要だと思うの。"

    # say L2689 oli
    old "I would understand it if you don't want to do it."
    new "分かっても良いよ、やる気ないなら。"

    # say L2690 oli
    old "But if you will, that would be the greatest thing."
    new "でも、もしよければ、それが一番うれしいな。"

    # say L2692 pla
    old "Oh yeah for sure, I'll help you."
    new "もちろん、手伝うよ。"

    # say L2693 pla
    old "Of course, I don't have a problem with doing that."
    new "もちろん、そんなこと全然問題ないよ。"

    # say L2694 pla
    old "And I think you need it, that would help you to get out from under your parents."
    new "君がそれを必要としてると思うよ、親の元から出ていく手伝いになるだろう。"

    # say L2695 pla
    old "So I'll be more than happy to help you study."
    new "じゃあ、君の勉強を手伝うよ。"

    # say L2697 oli
    old "Oh god [pla] you have no idea how good it is to hear that! Thank you so much!"
    new "神様 [pla] それ聞いてほんと嬉しいよ！本当にありがとう！"

    # say L2698 pla
    old "Glad to help you."
    new "喜んで手伝うよ。"

    # say L2700 pla
    old "Hmm, so I guess we should get going to your house then?"
    new "うん、じゃあ君の家に行こうか？"

    # say L2701 oli
    old "No, I don't think right now would be a good idea."
    new "今はいいタイミングじゃないと思うの。"

    # say L2703 oli
    old "I have to gather some more information about college admission exams and such."
    new "大学入試の情報を集めなきゃならないの。"

    # say L2704 oli
    old "But as soon as I have it I'll let you know."
    new "でも手に入ったらすぐに教えてあげるよ。"

    # say L2706 pla
    old "Alright, I'll be waiting."
    new "分かった、待ってるよ。"

    # say L2707 pla
    old "I guess I'll see you later."
    new "じゃあ、後でな。"

    # say L2725 pla
    old "Hey Olivia."
    new "Hey Olivia。"

    # say L2726 oli
    old "Hey [pla]! How are you doing?"
    new "Hey [pla]！元気にしてる？"

    # say L2727 pla
    old "I'm alright, and you?"
    new "俺は元気だよ、君は？"

    # say L2729 oli
    old "I'm doing well, actually I'm glad that I caught you here."
    new "実はあなたに会えて嬉しいの。調子はどう？"

    # say L2730 oli
    old "I got to checking the information that I told you about."
    new "私が話した情報の確認をしたの。"

    # say L2731 oli
    old "So I was wondering if you could come with me to my house so that we can start studying today."
    new "じゃあ、今日から一緒に勉強するために、家に来てくれない？"

    # say L2733 pla
    old "Sure, I'll gladly come with you to study."
    new "もちろん、喜んで行くよ。"

    # say L2734 oli
    old "Great! Let's go then."
    new "Great！ Let's go then. → グレート！行きましょう。"

    # say L2748 oli
    old "Alright, I think we should get to it, right?"
    new "じゃあ、早速始めましょうか？"

    # say L2759 pla
    old "Alright, so what are we going to study?"
    new "じゃあ、何を勉強するんだ？"

    # say L2761 oli
    old "We're going to be covering the entrance exam for the design school."
    new "デザイン学校の入学試験の内容を勉強するつもりよ。"

    # say L2762 oli
    old "It came to my mind that maybe there could be a couple of previous exams online that I could use to study."
    new "オンラインで過去の試験問題を見つけられて、それを使って勉強できるんじゃないかと思ったの。"

    # say L2764 pla
    old "Hmm, so you want to study design..."
    new "うん、デザインの勉強しようってこと？"

    # say L2765 pla
    old "I mean, do you think I would be the best person to help you with it?"
    new "つまり、君は俺が一番適任だと思ってるのか？"

    # say L2767 pla
    old "I don't know anything about the subject, to be honest."
    new "正直、その話題について何も知らないんだけど。"

    # say L2768 oli
    old "That's alright, you don't actually have to know."
    new "大丈夫、実際には知らなくてもいいの。"

    # say L2769 oli
    old "The college I'm applying to has a fundamental curriculum that every student must complete."
    new "私が応募している大学には、全学生が修了しなければならない基礎カリキュラムがあるの。"

    # say L2771 oli
    old "And it's very heavy on chemistry, math, and sciences."
    new "そして化学、数学、理科がとても重視されるんだ。"

    # say L2772 oli
    old "So it's alright if that's what we study. Because those topics are going to be the focus of the admission exam."
    new "だからそれらを勉強してもいいの。なぜなら入学試験の重点がそれらの分野になるから。"

    # say L2774 pla
    old "Oh, I see, alright, let's get to it then."
    new "分かった、じゃあ始めるか。"

    # say L2785 pla
    old "Uhmm, not much, it's just that you're taking very well to this."
    new "うーん、別に、君がこれにとても上手く対応してるだけだ。"

    # say L2786 pla
    old "But before, you were struggling so much to learn the school topics."
    new "でもさ、前に学校の授業についていくのに苦労してたじゃん。"

    # say L2788 oli
    old "Well, as I told you before, I'm not dumb."
    new "前に言ったけど、私はバカじゃないのよ。"

    # say L2789 oli
    old "It's just that the school topics are so much more boring to me."
    new "ただ学校の授業は私にとってはすごく退屈なだけよ。"

    # say L2790 oli
    old "They're not interesting in any way."
    new "全然面白くないんだよ。"

    # say L2791 oli
    old "I mean, these are most of the same topics."
    new "つまり、これらはほとんど同じテーマだよ。"

    # say L2793 oli
    old "But I'm studying them to get into college and do something that I actually want to do."
    new "でも、大学に入るために、自分がやりたいことをするために勉強してるの。"

    # say L2796 oli
    old "It also has to do with the fact that I kinda know I have to push myself through this."
    new "それに、自分でも分かってるんだよね、この先を進まないとダメだって。"

    # say L2797 oli
    old "With how far I've come already, it would be a real shame if I gave up now."
    new "ここまで来たんだから、今更諦めるのは本当にもったいないよ。"

    # say L2799 pla
    old "I see, that actually makes a lot of sense."
    new "なるほど、それは納得できるな。"

    # say L2800 oli
    old "Come on, let's keep going."
    new "さあ、続けようよ。"

    # say L2808 pla
    old "Alright, I think that should be enough for today."
    new "今日分はこれでいいんじゃないか"

    # say L2810 oli
    old "Really? Already?"
    new "本当に？もう？"

    # say L2812 pla
    old "Yeah sure, this was just an introductory session."
    new "まあ、そうだ。今日は導入のセッションだったんだ。"

    # say L2813 pla
    old "So we should stop before we get too tired."
    new "それじゃ、疲れきる前にやめとこう。"

    # say L2814 oli
    old "Hmm, yeah I guess you're right."
    new "うーん、そうかもしれないね。"

    # say L2823 pla
    old "Alright, that was very good."
    new "良かった、それだけできただけでも。"

    # say L2824 pla
    old "If we keep going like that, I'm sure you'll ace that entrance exam."
    new "そのまま続けていけば、君はきっとその入学試験も見事にパスするよ。"

    # say L2826 oli
    old "For everything, you know?"
    new "全部のこと、知ってるでしょ？"

    # say L2827 oli
    old "I have been coming up with these crazy plans, and you've kept supporting me."
    new "私はいろいろな奇抜な計画を考えついて、あなたはいつも支えてくれた。"

    # say L2828 oli
    old "Thanks a lot."
    new "ありがとう。"

    # say L2830 pla
    old "So, I guess I should get going, but I'll come back soon so that we can keep studying."
    new "じゃあ、そろそろ行くけど、またすぐに戻ってくるからな。勉強のこともだけど、他にも話したいことがあるしさ。"

    # say L2831 pla
    old "And of course, to check on the pregnancy."
    new "もちろん、妊娠の状態も確認しにくるよ。"

    # say L2832 oli
    old "Sure thing [pla], thanks a lot."
    new "もちろん、ありがとうね [pla]。またね。"

    # say L2850 oli
    old "Hey [pla]! Did you come to study again?"
    new "Hey [pla]！また勉強しに来たの？"

    # say L2851 pla
    old "Yeah, I figured that it's time for another session."
    new "そうだな、また一回やる時間だと思ったんだ。"

    # say L2852 oli
    old "Great, let's get to it then."
    new "じゃあ、始めるわ。"

    # say L2853 pla
    old "Alright, where did we leave off last time?"
    new "よし、前回どこまでやったっけ？"

    # say L2854 oli
    old "I think it was this topic here..."
    new "このトピックだったと思います..."

    # say L2856 pla
    old "Oh yeah! For sure!"
    new "ああそうか！間違いない！"

    # say L2858 pla
    old "Alright, let's continue from there then."
    new "よし、そこから続けよう。"

    # say L2895 pla
    old "Alright, that was a good session."
    new "よし、いいセッションだったな。"

    # say L2896 pla
    old "Just a couple more and I know you'll have what it takes to ace those exams."
    new "あとちょっと頑張れば君は試験に見事に合格できるよ。"

    # say L2898 oli
    old "Thanks a lot [pla]..."
    new "ありがとう、[pla]…"

    # say L2899 oli
    old "For everything."
    new "すべてのために。"

    # say L2901 pla
    old "Hey, my pleasure."
    new "Hey、全然問題ないぜ。"

    # say L2902 pla
    old "I have to leave for now, but I'll come back to see you soon, alright?"
    new "俺今帰るけど、またすぐ会いにくるからな。大丈夫だよ。"

    # say L2903 oli
    old "Sure, no problem, see you."
    new "分かった、またね。"

    # say L2944 pla
    old "Hi Mrs. Priya, how are you?"
    new "プリヤさん、元気ですか？"

    # say L2946 vee
    old "Are you here looking for Olivia?"
    new "あなたはオリビアを探しに来たの？"

    # say L2947 pla
    old "Uhh, yeah, I was kinda hoping to catch her here."
    new "うーん、そう、ここであいつに会いたかったんだ。"

    # say L2948 vee
    old "Well, no, she's at school."
    new "まあ、そうじゃないけど彼女は学校にいるの。"

    # say L2949 vee
    old "And you should be there too, you know?"
    new "あなたも学校にいなきゃならないの、知ってるでしょ？"

    # say L2950 pla
    old "Uh, yeah, yeah, you're probably right."
    new "うん、うん、多分そうだな。"

    # say L2951 pla
    old "I'll come by later then."
    new "後で寄るよ。"

    # say L2953 vee
    old "Sure, I'll let her know you stopped by."
    new "わかった、私が伝えておくね。"

    # say L2956 pla
    old "Hi, Mrs. Priya, how are you?"
    new "こんにちは、プリヤさん、お元気ですか？"

    # say L2958 vee
    old "Hello, [pla]. I'm doing fine, and you?"
    new "こんにちは、[pla]。元気にしてる、あなたは？"

    # say L2960 pla
    old "I'm alright, thank you."
    new "元気だ、ありがとう。"

    # say L2962 vee
    old "That's good to hear..."
    new "それは聞いて嬉しいね..."

    # say L2964 vee
    old "So tell me, did you come looking for Olivia?"
    new "じゃあ、オリビアを探しに来たの？"

    # say L2966 pla
    old "That's right. Is she here?"
    new "そうだ、ここにいるのか？"

    # say L2968 vee
    old "Great... Yes, she's in her room."
    new "Great... うん、彼女は部屋にいるよ。"

    # say L2970 vee
    old "You can go in, go ahead, don't mind me."
    new "入っていいよ、遠慮しないで。"

    # say L2971 pla
    old "Uh... S- sure, thank you."
    new "うーん… やるか、ありがとう。"

    # say L2973 pla
    old "I guess I'll see you around, Mrs. Priya."
    new "じゃあ、プリヤ、またね。"

    # say L2974 vee
    old "Yes, of course. Good afternoon, [pla]."
    new "はい、もちろんです。こんにちは、[pla]。"

    # say L2984 pla
    old "Alright, that's good. I think we can move on to something else."
    new "そうだな、じゃあ次の話題にしよう。"

    # say L2985 oli
    old "Ok, that sounds good."
    new "そうね、いいわ。"

    # say L2988 vee
    old "Olivia, are you there? I'm coming in!"
    new "オリビア、いるの？ 入るよ！"

    # say L3000 pla
    old "H- hi Mrs. Priya."
    new "プリヤ、こんにちは。"

    # say L3002 oli
    old "We were just studying, Mom, nothing else."
    new "勉強してただけよ、ママ、他には何もしてないから。"

    # say L3004 vee
    old "Yeah well, I hope it's going better than last time you two studied."
    new "まあ、前回二人が勉強した時よりは上手くいってほしいんだけどね。"

    # say L3007 oli
    old "Anyway, what do you want?"
    new "じゃあ、何欲しそうなの？"

    # say L3009 vee
    old "What do you mean by that? Did you forget that we have a phone call with your father to talk about your pregnancy?"
    new "何それ？お前の妊娠について、お父さんとの電話の約束を忘れたの？"

    # say L3012 vee
    old "And before you ask, no, we cannot reschedule, you know how Vihaan is about his time."
    new "それに聞かれる前に言っておくけど、スケジュール変更は無理だよ、ビハアンの時間管理は厳格だって知ってるでしょ。"

    # say L3013 oli
    old "Oh shoot! I forgot about it!"
    new "あちゃー！それ忘れてた！"

    # say L3017 oli
    old "Listen [pla], I'm going to have to step out for a while, this call with my dad is very important."
    new "[pla]、ちょっと出てるんだけど、パパとの電話が重要だから。"

    # say L3018 oli
    old "But please don't leave."
    new "でも、絶対にいかないで。"

    # say L3020 oli
    old "This isn't going to take too much time. And we have a lot more to cover in today's session."
    new "これにはそんなに時間がかからないわ。今日のセッションではまだたくさんのことを話す予定だから。"

    # say L3022 oli
    old "So, I'll talk to my dad, and I'll come back so that we can keep studying."
    new "じゃあ、パパに話して、戻ってくるから。それからまた一緒に勉強できるよね。"

    # say L3023 pla
    old "Oh, a- alright, sure, no problem."
    new "あ、ああ、分かった、問題ないよ。"

    # say L3025 vee
    old "Come on, we have to go call him now."
    new "さあ、今すぐ彼に電話しないと。"

    # say L3029 oli
    old "Alright, alright, let's go."
    new "わかった、わかった、行こう。"

    # say L3041 pla
    old "Hmm, I mean, I guess I'll just sit here and wait for her to come back."
    new "うーん、まあ、彼女が戻ってくるのを待つしかないか。"

    # say L3049 aye
    old "Hey brother-in-law! How are you?"
    new "おい、義兄！元気か？"

    # say L3050 pla
    old "Uhmm, hi... I'm doing fine."
    new "うーん、こんにちは… 元気だ。"

    # say L3059 aye
    old "But what are you doing here all alone?"
    new "でも、どうして一人でここにいるんだ？"

    # say L3061 pla
    old "Oh, I was helping your sister study."
    new "ああ、お前の妹の勉強を手伝ってたんだ。"

    # say L3063 pla
    old "And you know, spending time with her and checking that the pregnancy is going well."
    new "そして、彼女と一緒に時間を過ごして、妊娠が順調に進んでいるか確認してるんだ。"

    # say L3065 pla
    old "But she had to step out with your mom for a call they had scheduled with your dad."
    new "でも彼女はお母さんと一緒にお父さんとの予定の電話のために出かけちゃったんだ。"

    # say L3066 pla
    old "So I'm just waiting here for her to come back."
    new "だからここで待ってるんだ。"

    # say L3068 aye
    old "I see, hmm, that's interesting, I guess."
    new "なるほど、意外だな。"

    # say L3070 aye
    old "Do you like spending time with her?"
    new "彼女と過ごす時間が好きなのか？"

    # say L3071 pla
    old "Uh, I mean, y- yeah sure."
    new "うーん、まあ、そうかな。"

    # say L3072 aye
    old "I see, I see."
    new "なるほど、なるほど。"

    # say L3074 aye
    old "And you like to do it even though she's just a fat cow?"
    new "お前は彼女がただの太った牛だと思っても、それでも彼女と遊ぶのが好きなのか？"

    # say L3075 pla
    old "W- what? What are you talking about?"
    new "何言ってんのさ？"

    # say L3077 aye
    old "Nothing much, I was just wondering if you still like to spend time with her."
    new "別に、君がまだ彼女と過ごしたいのかなって思っただけだよ。"

    # say L3078 aye
    old "Because she no longer looks as beautiful as she did before."
    new "だって、もう以前ほど綺麗じゃなくなったしな。"

    # say L3080 aye
    old "You know, she's been getting fatter and fatter."
    new "知ってるよ、最近めっちゃ太ってるんだ。"

    # say L3082 aye
    old "I can't imagine that's attractive in any way."
    new "そんなの全然魅力的じゃないと思うけど。"

    # say L3084 pla
    old "Uhmm, to be honest with you that's not even something I had considered."
    new "うーん、正直に言うと、そんなこと考えたこともなかったな。"

    # say L3086 pla
    old "I mean, she just looks a little bit bigger because of the pregnancy."
    new "俺はさ、妊娠してるからちょっと太ってるだけだろ。"

    # say L3088 pla
    old "But that's completely normal, right?"
    new "でも、それ全然普通だよな？"

    # say L3090 aye
    old "Yeah, yeah, as I was saying, she's a fat cow."
    new "そうだ、そう、と言っていたように、彼女は太った牛だ。"

    # say L3092 aye
    old "But anyway, that's not important right now."
    new "でもまあ、それよりも今は重要じゃないな。"

    # say L3093 aye
    old "You know? I've been thinking a lot about you recently."
    new "知ってるか？最近、お前のことばかり考えてるんだ。"

    # say L3094 pla
    old "Y- you have? H- how come?"
    new "ええ、そうなのか？　どうしてそうなったんだ？"

    # say L3095 aye
    old "I just think it's very unfortunate that you had to fall in love with the worst part of our family."
    new "お前が家族の中で最も最悪な部分に恋したってのは、本当に残念だな。"

    # say L3097 aye
    old "I mean sure, my sister's pretty."
    new "まあ、妹はかわいらしいけど。"

    # say L3099 aye
    old "But you know that she doesn't care about you, not really, right?"
    new "でも、彼女は本当のところあなたのことなんて気にしてないって、分かってるよね？"

    # say L3101 aye
    old "She's just using you to get out of going to India."
    new "彼女はただインド行きたくないから、お前を利用してるだけだよ。"

    # say L3102 aye
    old "I'm sorry it has to be like that."
    new "すまないな、そうなっちゃったよ。"

    # say L3103 pla
    old "Uh- I uh-"
    new "うー、あの、俺は-"

    # say L3104 pla
    old "I'm not sure I know what you're talking about..."
    new "俺は君が何を言ってるのかよくわかんないな…"

    # say L3106 aye
    old "Yeah right, of course you don't!"
    new "もちろん知らないってか！"

    # say L3107 aye
    old "But anyway, it's a shame that she's not only using you, but that you also have to have sex with her."
    new "でもな、お前が使われてるだけでなく、セックスまでさせられてるなんて、残念じゃないか。"

    # say L3108 aye
    old "With how bad she is, it surprises me that you're that much into her."
    new "そんなクソ野郎な彼女なのに、お前がそこまで惚れてるなんて意外だな。"

    # say L3109 pla
    old "Uh... W- what do you mean?"
    new "ええと… 何を言ってるんだ？"

    # say L3110 aye
    old "Oh come on [pla]!"
    new "おい、[pla]！"

    # say L3112 aye
    old "You know my sister's nothing special in bed."
    new "お前も知ってるだろ、俺の妹はベッドでは特別なこともないって。"

    # say L3113 aye
    old "It only took me the other day to be sure that she's not any good with sex stuff."
    new "先日やってみて確信したんだ、彼女はセックスの腕が全然ダメだって。"

    # say L3115 aye
    old "She was sucking your dick without any interest in doing it."
    new "彼女はお前のちんこを吸っているのに全く興味がなかったよ。"

    # say L3116 aye
    old "Which is a shame because that big dick of yours deserves better."
    new "それは残念だ、お前のその立派なちんこはもっといい扱いを deserve すべきなんだ。"

    # say L3123 aye
    old "I mean, it's such an amazing dick. So big and so thick."
    new "俺のちんこは本当に素晴らしいんだよ。こんなに大きいし太いんだから。"

    # say L3125 aye
    old "My sister's just wasting it with that sloppy technique of hers."
    new "妹はその下手なテクニックでただ無駄にしてるだけだな。"

    # say L3126 aye
    old "And in bed..."
    new "ベッドでは…"

    # say L3128 aye
    old "I bet she's just a dead fish, she probably isn't anything special there."
    new "多分ただの死に魚だろう、特別なことは何もしないはずだ。"

    # say L3134 aye
    old "I was thinking that it would do you well to have a small tasting of what you've been missing..."
    new "お前が今まで何を逃してたか、ちょっと味わってみるといいだろうな。"

    # say L3135 pla
    old "Uh, I uh..."
    new "うーん、その、"

    # say L3136 pla
    old "I- think you shouldn't be here..."
    new "お前がここにいるべきじゃないと思う…"

    # say L3137 pla
    old "Y- your sister could think the wrong thing."
    new "Ｙ－ 姉さんが変な誤解をするかもしれないよ。"

    # say L3139 aye
    old "And what would that be?"
    new "それが何だ？"

    # say L3145 pla
    old "Y- you know... L- like."
    new "ヤー、知ってるよ… みたいな。"

    # say L3146 aye
    old "Come on brother-in-law, I know you'll love it."
    new "おい、義兄さん、絶対気に入ってくれるよ。"

    # say L3156 pla
    old "W- what are you doing?!!"
    new "何やってんだ？！！"

    # say L3157 aye
    old "Come on! I know you'll love this!"
    new "Come on！ これ好きになるって分かってるぜ！"

    # say L3158 pla
    old "W- what if your sister or your mom comes in here?!"
    new "おい、もしいstersやお母さんがここに入ってきたらどうするんだよ？！"

    # say L3159 aye
    old "Ugh, relax, nothing will happen!"
    new "うっせえ、安心しろ、何も起こらんよ！"

    # say L3170 aye
    old "I'm sure you've never had anything like it."
    new "大丈夫、きっと君はこんな経験したことないだろう。"

    # say L3172 aye
    old "Now you can see what you're missing by doing it with my sister."
    new "今なら、俺の妹とやってる時の損見しているのがわかるだろう。"

    # say L3173 aye
    old "It's a shame that you have to endure something like that."
    new "それは残念だな、そんなのを我慢しなきゃならないなんて。"

    # say L3175 aye
    old "But you never know, maybe you and I can have another one of these sessions sometime."
    new "でもわからないよ、またこんなセッションを一緒にできるかもしれないし。"

    # say L3176 aye
    old "Or maybe we could do something else."
    new "でも、他のことをするかもしれないな。"

    # say L3177 pla
    old "Yeah... That's great."
    new "そうだな… それはいいね。"

    # say L3179 pla
    old "But it might be better if you leave for now, you know?"
    new "でも、今は帰った方がいいかもしれないな。"

    # say L3180 aye
    old "Sure, I guess I will."
    new "行こうかな。"

    # say L3181 aye
    old "But I'll be seeing you later."
    new "でもまた後でな。"

    # say L3188 pla
    old "God... She is something else."
    new "神…彼女は別格だな。"

    # say L3189 pla
    old "Is everyone in this family so brazen?"
    new "この家のみんなこんなに大胆なのか？"

    # say L3190 pla
    old "I'm just glad nobody saw us."
    new "誰も見てくれなかったのが良かったな。"

    # say L3203 oli
    old "Hey [pla], I'm sorry I kept you waiting for so long."
    new "Hey [pla]、待たせちゃってごめんなさい。"

    # say L3205 pla
    old "Hey, it's alright, no problem."
    new "大丈夫だよ、気にしないで。"

    # say L3206 pla
    old "I imagine you had a lot to talk with your dad, didn't you?"
    new "想像すると、お父さんとたくさん話したんだろう？"

    # say L3208 oli
    old "Oh yeah, a lot, he just kept going and going."
    new "ああ、そうよ。父さん、ずーっと話してたわ。"

    # say L3210 pla
    old "I understand. Are you ready to get back to studying?"
    new "分かってる。また勉強に戻れる準備ができてる？"

    # say L3212 oli
    old "You know what? I think we should stop for the day."
    new "知ってる？今日のところはこれで終わりにしようかな。"

    # say L3213 oli
    old "I just had a very bad conversation with my Dad and mom and I don't feel like studying at the moment."
    new "ただいま父と母との会話が悪く、今すぐ勉強する気になれないの。"

    # say L3214 oli
    old "I think I just want to rest a little bit."
    new "ちょっと休みたいだけかな。"

    # say L3215 pla
    old "Oh! Sure, sure, no problem."
    new "オッ、もちろん、問題ないぜ。"

    # say L3248 pla
    old "Hey Oli, how are you?"
    new "Hey Oli、調子はどうだ？"

    # say L3250 oli
    old "Hey [pla], how are you doing right now?"
    new "Hey [pla]、今どうしてる？"

    # say L3252 pla
    old "I'm doing fine, I came for us to continue studying. Are you ready?"
    new "俺は調子いいよ、勉強を続けに来たんだ。準備できてる？"

    # say L3253 oli
    old "You know? I don't think I am."
    new "知ってる？私、実は全然準備できてないかも。"

    # say L3254 oli
    old "I've been feeling really bad all day."
    new "一日中、気分が悪かったの。"

    # say L3255 oli
    old "You know, things from the pregnancy."
    new "妊娠のことなの。"

    # say L3256 oli
    old "So I think I'll just lay down for a while."
    new "だからちょっと横になるわ。"

    # say L3257 oli
    old "I'm sorry that you came all the way here for nothing."
    new "ごめんなさい、わざわざ来てもらったのに。"

    # say L3259 pla
    old "It's alright, I understand."
    new "大丈夫だよ、分かってるから。"

    # say L3260 pla
    old "You're pregnant, it's only natural that the body would feel that way."
    new "君が妊娠してるんだから、体調がそうなるのは当然だよ。"

    # say L3261 pla
    old "The best thing would be for you to rest, and we can see each other later."
    new "君が休むのが一番だよ、後で会おう。"

    # say L3293 pla
    old "Hmm, you know, I think I need to use the bathroom."
    new "俺、トイレ行かなきゃな。"

    # say L3294 oli
    old "Oh, sure!"
    new "オッ、そうね！"

    # say L3295 oli
    old "No problem, it's down the hallway."
    new "大丈夫、廊下を進んで左に曲がってね。"

    # say L3296 pla
    old "Alright, I'll be back in a minute."
    new "分かった、すぐに戻るよ。"

    # say L3305 pla
    old "Hmm, there's a weird sound coming from that room, what's going on in there?"
    new "ん？その部屋から変な音がしてるけど、中で何やってるんだ？"

    # say L3306 pla
    old "I don't think there's any harm in checking, right?"
    new "調査に行っても害はないと思うけど、な？"

    # say L3316 pla
    old "{i}(And she's masturbating!){/i}"
    new "{i}(しかも自慰してる！){/i}"

    # say L3317 pla
    old "{i}(I- I think she's having video sex with her husband.){/i}"
    new "{i}(あ、ああ、多分彼女は夫とビデオセックスしてるんだと思う。){/i}"

    # say L3318 pla
    old "{i}(S- should I leave? But what if I make noise and she catches me?){/i}"
    new "{i}(で、出て行こうかな？でも音立てたら気づかれるかもしれないし…){/i}"

    # say L3319 vee
    old "Oh yes! Yes, do you like what you're seeing honey?"
    new "オoh よし！そう、見ているのが好きかい、ハニー？"

    # say L3320 vih
    old "Of course I do! I love what I'm seeing!"
    new "もちろんよ！見ているのが大好き！"

    # say L3330 vee
    old "What the fuck is wrong with you?"
    new "何てふざけたことしてるの？"

    # say L3332 vee
    old "How long were you there just peeping on me?"
    new "どのくらい見てたの？"

    # say L3334 vee
    old "You are my daughter's fiancé! Have you no shame at all?!"
    new "あなたは私の娘の婚約者だよ！全然恥ずかしいことないの？！"

    # say L3335 pla
    old "I- I'm so sorry Mrs. Priya!"
    new "プリヤさん、本当にすみません！"

    # say L3337 pla
    old "But I swear to god that it wasn't my intention to break your privacy."
    new "でも神様にかけて、君のプライバシーを侵害するつもりは全然なかったんだ。"

    # say L3339 pla
    old "I was just coming back from the bathroom when I heard some weird noise coming from the bedroom."
    new "俺はただトイレから戻ってきただけなのに、寝室から変な音が聞こえてきたんだ。"

    # say L3341 pla
    old "I just wanted to make sure that there wasn't anything wrong in here."
    new "ただ、中に何がおかしいのか確認したかっただけだ。"

    # say L3342 pla
    old "And I accidentally saw you..."
    new "そして俺は君を偶然見てしまった…"

    # say L3344 pla
    old "I thought about leaving, but I didn't want to make any noise that could alert you to my presence."
    new "俺は出て行こうと思ったけど、君に気づかれる音を立てたくなかったんだ。"

    # say L3345 pla
    old "But I swear to god this was just a big misunderstanding ma'am."
    new "でも神にかけて、これはただの誤解だって誓うよ、お姉さん。"

    # say L3347 vee
    old "I mean, I want to believe you but..."
    new "つまり、信じたいんだけど..."

    # say L3353 vee
    old "{i}(How big is he?!){/i}"
    new "{i}(どれくらい大きいの？！){/i}"

    # say L3354 vee
    old "{i}(He must be at least twice as big as Vihaan!){/i}"
    new "{i}(ビハーンの二倍はありそうね！){/i}"

    # say L3356 pla
    old "Uhmm, ma'am? Is everything alright?"
    new "うーん、君？ 大丈夫？"

    # say L3358 vee
    old "What? Oh yeah..."
    new "何？あ、うん…"

    # say L3360 vee
    old "Listen [pla], I'll believe you for now."
    new "[pla]、今度は信じてあげるけど。"

    # say L3362 vee
    old "But it still isn't alright that you were just spying on me like that."
    new "でも、そんな風に勝手に覗いていたのはまだ許せないよ。"

    # say L3364 vee
    old "Next time knock or something, so that I can at least be prepared."
    new "次はノックしてくれればいいのに、そうすれば少なくとも準備できるよ。"

    # say L3365 pla
    old "Yeah, you're right, I'm sorry."
    new "うん、君の言う通りだ、ごめん。"

    # say L3367 vee
    old "Now, my daughter will think something's happening if you take that long to come back from the bathroom."
    new "今、そんなに長くトイレにいたら、私の娘は何かが起こったと思うよ。"

    # say L3368 vee
    old "So go back already."
    new "早く戻ってこい。"

    # say L3369 pla
    old "Uh... S- sure, excuse me."
    new "うーん… 分かった、失礼するな。"

    # say L3375 vee
    old "That was a very unpleasant surprise."
    new "それはとても不快な驚きだったわ。"

    # say L3376 vee
    old "But I guess I'll believe him."
    new "でも信じることにするかな。"

    # say L3377 vee
    old "But I wasn't expecting him to have such a huge boner from seeing me."
    new "でも、彼が私を見てそんなに大きな反応をするとは思わなかった。"

    # say L3378 vee
    old "Is that what Olivia is enjoying?"
    new "それがオリビアが楽しんでいるものなのかしら？"

    # say L3379 vee
    old "Meanwhile all I have is my fingers and a laptop..."
    new "でも私は指とラップトップしかないのね..."

    # say L3384 pla
    old "Damn! I wasn't expecting that!"
    new "くそっ！そんなことになるとは思わなかったな。"

    # say L3385 pla
    old "I guess I'm lucky that she didn't get angrier with me."
    new "彼女がもっと怒らなかったのが幸いだったな。"

    # say L3386 pla
    old "Next time I should just keep walking and mind my own business."
    new "次はただ通り過ぎて自分のことだけ考えよう。"

    # say L3399 oli
    old "Hey, what took you so long? Are you alright?"
    new "hey、何這麼久才來？大丈夫か？"

    # say L3400 pla
    old "Me? O- oh yeah."
    new "俺？あー、うん。"

    # say L3401 pla
    old "I - I think I just ate something bad."
    new "俺 - 俺は何かまずいもの吃了みたいだ。"

    # say L3402 pla
    old "But I'm alright now."
    new "でも今は大丈夫だよ。"

    # say L3404 oli
    old "Well, let's keep studying."
    new "じゃあ、勉強を続けよう。"

    # say L3405 oli
    old "We have a lot more to do. Come on."
    new "まだやることたくさんあるよ。さあ、行こう。"

    # say L3428 pla
    old "Oh! Hi Olivia, how are you today?"
    new "オーリビア、こんにちは、今日どう？"

    # say L3430 oli
    old "I'm doing fine, and you? How are you?"
    new "私は調子いいわ、あなたは？どうしてる？"

    # say L3432 pla
    old "Oh I'm alright, you know, not much is happening."
    new "まあまあだよ、君は？特に何も起こってないね。"

    # say L3433 pla
    old "How are you handling the pregnancy? Is everything alright?"
    new "妊娠の調子はどう？大丈夫なのか？"

    # say L3435 oli
    old "Oh yeah, for the most part it is."
    new "うん、大体は順調よ。"

    # say L3436 oli
    old "My mom's still in a bad mood, but I think she'll come around."
    new "母はまだ機嫌が悪いけど、きっと許してくれると思う。"

    # say L3437 oli
    old "The other thing is that I've been feeling somewhat bad because of nausea and stuff."
    new "他にも、吐き気とかで調子が悪くなることがあるの。"

    # say L3438 oli
    old "You have seen it, how I get, I start to feel bad and my head hurts and stuff."
    new "あなたも見てくれたでしょ、私が具合悪くなって頭痛むの。"

    # say L3439 pla
    old "Yeah, I know, I'm sorry about that."
    new "うん、知ってる、ごめんだけど。"

    # say L3440 pla
    old "I hope that as the pregnancy goes the symptoms will start to decrease."
    new "妊娠が進むにつれて症状が軽くなることを願ってるんだ。"

    # say L3442 oli
    old "Yeah, me too. But I mean is not as if I'm not managing to..."
    new "うん、私もそう願ってる。でも、妊娠してるからって、全然無理してるわけじゃないし。"

    # say L3450 rub
    old "Hey you idiot! What do you think you're doing bothering her this early in the morning?"
    new "Hey you idiot！ 何考えてんの？早朝から彼女を困らせようとしてるのか？"

    # say L3453 rub
    old "What? Did you think that just because Olivia's pregnant now you could just start harassing her like it was nothing?"
    new "何？オリビアが妊娠したからって、勝手に彼女をいじめるつもりだったの？"

    # say L3456 rub
    old "Well think again buddy, because I'm not gonna let you bother her anymore!"
    new "じゃあ考え直しなよ。もう彼女を困らせさせてあげないからね。"

    # say L3459 rub
    old "Actually, why don't you get out of here before I call the teachers of you for harassing Olivia?"
    new "実は、今すぐここから出て行かないなら、先生に通報するわよ。"

    # say L3461 pla
    old "Hey! I'm not harassing anybody!"
    new "Hey！ 俺は誰も困らせてないぞ！"

    # say L3463 rub
    old "Get out of here or I'll call the teachers!"
    new "ここから出て行けよ、先生呼ぶわ！"

    # say L3464 rub
    old "We'll see who they believe more..."
    new "見ればわかるわ、誰の話を信じるかはね..."

    # say L3465 pla
    old "Jeez, I'm leaving then."
    new "まあ、そうしようかな。"

    # say L3471 rub
    old "Hpmh finally that stalker left."
    new "ふーむ、ついにそのストーカーがいなくなったわ。"

    # say L3472 rub
    old "How are you? Are you alright?"
    new "大丈夫？元気？"

    # say L3474 oli
    old "H- hi, I'm doing well, and you?"
    new "あ、こんにちは、元気だよ、君は？"

    # say L3476 rub
    old "Well, I'm alright, you know. There's nothing much going on in my life."
    new "まあ、大丈夫よ。私の生活には特に何も起こってないのさ。"

    # say L3477 rub
    old "Unlike you..."
    new "君と違ってね..."

    # say L3479 rub
    old "I can't believe you didn't tell me about this before."
    new "信じられない、これまで教えてくれなかったの？"

    # say L3481 rub
    old "I'm only finding out because of your belly."
    new "お腹が大きくなってから私だけ気づいたの？"

    # say L3482 rub
    old "Why didn't you let me know before?"
    new "なぜ前に教えてくれなかったの？"

    # say L3484 oli
    old "W- well, the truth is that even though I found out early, I wasn't really sure about who to tell."
    new "うーん、実は早くに気づいたんだけど、誰に話すべきかわからなかったんだ。"

    # say L3485 rub
    old "Why not? Is everything alright?"
    new "なぜ？　大丈夫なの？"

    # say L3486 oli
    old "Uhmm, I guess it is."
    new "うん、まあそうかな。"

    # say L3487 oli
    old "I've just been dealing with my parents. You know how they are."
    new "最近、親と話してるの。君も知ってるでしょ？"

    # say L3489 rub
    old "Hmph, yeah, I have an idea."
    new "ふん、まあ、想像できるわ。"

    # say L3491 rub
    old "And what does the father say? Is he helping you?"
    new "父親はなんて言ってるの？君を助けてくれてるの？"

    # say L3493 oli
    old "Hmm, w- well... W- we're actually not in contact."
    new "うーん、えっと…… 実際には連絡を取ってないの。"

    # say L3495 rub
    old "What? Is that scumbag not planning on answering for what he did?"
    new "何？　そのクソ野郎、自分がしたことに責任を取るつもりじゃないの？"

    # say L3496 rub
    old "Tell me who he is! I'll make him answer!"
    new "誰なのか教えて！私が彼に責任を取らせるから！"

    # say L3497 oli
    old "N- no, it's nothing like what you're imagining."
    new "んー、君が想像してるようなことじゃないの。"

    # say L3498 oli
    old "Is not that he doesn't want to answer for it, is just that..."
    new "彼が答えないんじゃないの、ただ…"

    # say L3499 oli
    old "I don't know who he is."
    new "誰なのか知らないわ。"

    # say L3500 rub
    old "How come?"
    new "どうして？"

    # say L3501 oli
    old "Well, it happened at this party."
    new "まあ、そのパーティーでね。"

    # say L3502 oli
    old "I didn't measure my drinks and got drunk."
    new "飲み物の量を測らずに飲んでしまって、酔っ払っちゃったの。"

    # say L3503 oli
    old "And there was this very tall guy that I thought was cute."
    new "そして、すごく背が高い男の人がいて、かわいかったなと思ったの。"

    # say L3505 oli
    old "I decided to approach him and we ended up spending the night together."
    new "彼に声をかけて、結局その夜を一緒に過ごすことになったの。"

    # say L3507 oli
    old "But I never asked him his name or where he goes to school or anything."
    new "でも、名前も学校も何も聞かなかったんだ。"

    # say L3509 oli
    old "To be honest, I barely remember his face."
    new "正直、彼の顔はほとんど覚えていないの。"

    # say L3511 oli
    old "So you see, there's not much use in worrying about the father."
    new "だからね、父親のことは心配する必要ないんだよ。"

    # say L3513 rub
    old "Hmph, I guess you're right."
    new "ふん、そうかもね。"

    # say L3516 rub
    old "But it doesn't matter, you don't need that deadbeat to answer for anything."
    new "でも気にしないで、あんなクソ親に責任取らせる必要なんてないんだから。"

    # say L3518 rub
    old "You have your family and you have me, that's all you need."
    new "家族がいて、私がいるだけでも充分よ。"

    # say L3519 oli
    old "Thanks Ruby, I know I can always count on you."
    new "ありがとう、ルビー。君に頼りにしてるよ。"

    # say L3521 oli
    old "But to be honest, I don't know yet if I'll be keeping it you know?"
    new "でも正直に言うと、まだ産むかどうか決めてないの。"

    # say L3522 oli
    old "Having a baby is a lot of work, so I'm still figuring out if I'll actually be a mother."
    new "赤ちゃんを育てるのは大変だから、まだ母親になるかどうか決めてないの。"

    # say L3524 rub
    old "I see, I understand... That makes a lot of sense."
    new "なるほど、それはよくわかる… そういう考えも自然だね。"

    # say L3525 rub
    old "And if you decide not to have it, what are you going to do about it?"
    new "そして、もし子供を産まないことに決めたら、どうするつもり？"

    # say L3527 oli
    old "Well, I was thinking that I could just go to the same doctor your friend went to that other time."
    new "あのね、君の友達が行った同じ医者に行こうかなって思ってるの。"

    # say L3528 oli
    old "They did a very good job the last time, didn't they?"
    new "前回はとても良い仕事をしてくれたよね。"

    # say L3529 oli
    old "I think I could go to them."
    new "あのドクターにまた行ってみようかな。"

    # say L3531 rub
    old "I see, I understand... Well, I agree."
    new "そうね、わかったわ… うん、賛成する。"

    # say L3532 rub
    old "You know I'll help you no matter what, right?"
    new "知ってるよね、どんなことでも手伝うから。"

    # say L3533 rub
    old "Whatever you choose to do, I'm here for you."
    new "選んだことを何であれ、私はここにいるよ。"

    # say L3534 oli
    old "I know that thanks."
    new "ありがとう、知ってるよ。"

    # say L3535 rub
    old "Hey, what do you say we skip classes for today?"
    new "ねえ、今日の授業さぼってどう？"

    # say L3536 rub
    old "Come on, let's go to the mall and have some ice cream."
    new "さあ、モールに行ってアイスクリーム食べよう。"

    # say L3537 oli
    old "Haha, alright let's do it."
    new "ははは、いいよ、行こう。"

    # say L3557 mik
    old "Dude! I'm so angry!"
    new "おい！俺、めちゃくちゃ怒ってるんだよ！"

    # say L3558 pla
    old "H- huh? W- what's up?"
    new "えっ？　何があったんだ？"

    # say L3560 mik
    old "{i}'What's up?'{/i} Are you serious?"
    new "{i}何言ってんだよ{/i} 本気で？"

    # say L3561 mik
    old "Olivia's pregnant man!"
    new "オリアンナが妊娠してるんだよ、男！"

    # say L3562 pla
    old "Y- yeah, s- she is, so?"
    new "うん、そう、彼女は妊娠してるんだ、それで？"

    # say L3563 mik
    old "So? Don't you see what's wrong with that?"
    new "そ？　何がおかしいと思ってるんだ？"

    # say L3565 mik
    old "I can't believe this treason!"
    new "この裏切りが信じられない！"

    # say L3566 pla
    old "H- hey man, c- calm down..."
    new "おい、落ち着いてよ..."

    # say L3568 mik
    old "What do you mean calm down? Would you be able to if you were in my shoes?"
    new "お前が落ち着けって？お前の立場なら落ち着けるか？"

    # say L3569 pla
    old "I know man, this doesn't look good."
    new "知ってるよ、この状況は良くないって。"

    # say L3570 pla
    old "B- but I can explain, I swear."
    new "でも説明できるから、信じてよ。"

    # say L3572 mik
    old "Explain? You know who the guy is?"
    new "説明？お前、その男の人が誰なのか知ってるのか？"

    # say L3573 pla
    old "Uhmm... What?"
    new "うーん… 何それ？"

    # say L3575 mik
    old "Yeah, do you know who the guy that got Olivia pregnant is?"
    new "そうだ、オリビアを妊娠させた男のことを知ってるか？"

    # say L3577 pla
    old "Oh! S- so you don't know who the father is."
    new "オッ！　そうなのか、父親が誰なのか知らなかったのか。"

    # say L3579 mik
    old "Of course I don't, there are some rumors that it might be some jock in the football team."
    new "もちろん知らないよ、サッカー部の誰かって噂もあるけどね。"

    # say L3581 mik
    old "But nobody knows."
    new "でも誰も知らないよ。"

    # say L3583 mik
    old "But since you say you can explain, I imagine you know who it is, don't you?"
    new "でも君が説明できるって言うなら、誰なのか知ってるんだろ？"

    # say L3584 pla
    old "Uh... N- no, I- I don't know who the guy is."
    new "うーん… い、いや、その男の人の正体は知らないんだ。"

    # say L3585 mik
    old "Then what did you mean by that?"
    new "じゃあ、その言葉はどういう意味だったんだ？"

    # say L3587 pla
    old "Uhmm... I just thought you were going to get into an argument with Olivia or something."
    new "うーん……ただ、お前がオリビアと喧嘩すると思ったんだよ。"

    # say L3588 pla
    old "And I figured I had to stop you."
    new "お前を止めるしかなかったと思ったんだ。"

    # say L3590 mik
    old "What? Because she's pregnant?"
    new "何？ 妊娠したからって？"

    # say L3591 mik
    old "No man, not at all."
    new "いや、全然そんなことない。"

    # say L3593 mik
    old "I'm hurt by her betrayal that's for certain!"
    new "彼女の裏切りで傷ついてることは間違いないけどな。"

    # say L3595 mik
    old "But there's no way that I would ever be angry or fight with my beloved Olivia."
    new "でも、愛しいオリビアと喧嘩したり怒ったりするなんて絶対にないよ。"

    # say L3597 mik
    old "I love her too much for it."
    new "俺は彼女を愛しすぎて、そんなことできないよ。"

    # say L3598 pla
    old "Is that so?"
    new "そうか"

    # say L3599 mik
    old "Of course, it doesn't matter what she did to me."
    new "もちろん、彼女が俺に何をしたって関係ない。"

    # say L3601 mik
    old "But that son of a bitch that got her pregnant, he's a different story."
    new "でも、あの野郎が彼女を妊娠させたのは別物語だ。"

    # say L3603 mik
    old "When I catch the guy I swear to god that I'll make him pay for getting with my woman!"
    new "あの野郎が俺の女に手を出したって、見つけ次第絶対に仕返してやるよ！"

    # say L3604 mik
    old "And with how close I was to scoring with her."
    new "それに、あんなに彼女とヤれそうだったのに。"

    # say L3606 pla
    old "Yeah, I understand buddy."
    new "うん、分かるよ。"

    # say L3607 pla
    old "Must be rough."
    new "大変だろうな。"

    # say L3609 mik
    old "It's alright dude, nothing I can do about it."
    new "大丈夫だ、何もできるわけじゃないけどな。"

    # say L3610 mik
    old "But anyway this doesn't mean that I won't be there for her anyway."
    new "でもまあ、それでも彼女を支えるつもりだよ。"

    # say L3613 mik
    old "Think about it dude, if no one knows who the father is it means he's a bum or a deadbeat."
    new "考えろよ、誰も父親が誰なのか知らないってことは、その男はクソ野郎かドブネズミってことだ。"

    # say L3614 mik
    old "Which means my poor Olivia is having to go at this by herself."
    new "つまり、可哀想なオリビアはこれに対して一人でやっていかなければならないってことだ。"

    # say L3616 mik
    old "But she won't have to worry about anything man!"
    new "でも心配しなくていいよ、俺が責任持つから！"

    # say L3618 mik
    old "I'll step up! I'll answer for everything the kid needs."
    new "俺が責任を取るよ！子供が必要とするすべてに対応するさ。"

    # say L3620 mik
    old "I'll even give him my last name so that they'll know I'm their father."
    new "俺の名前をあげるよ。そうすれば、自分が父親だってわかるだろう。"

    # say L3621 pla
    old "Oh, I mean, that's great man."
    new "お、そうか、それは良いな。"

    # say L3623 pla
    old "But what does Olivia think about your noble intentions? Have you talked to her?"
    new "でも、オリビアはお前の崇高な意向についてどう思ってるんだ？話したのか？"

    # say L3624 mik
    old "Hmm, no, not really. I haven't been able to talk to her."
    new "うーん、まあ、そうなんだ。彼女とはまだ話せてない。"

    # say L3625 mik
    old "But I will, don't doubt dude!"
    new "でも話すよ、心配すんなよ！"

    # say L3627 pla
    old "I'm sure you will bro, I'm sure you will."
    new "お前が言う通りだ、絶対話すからな。"

    # say L3636 luc
    old "[pla], Mike, class is about to start, why haven't you taken your seats?"
    new "[pla]、マイク、授業が始まるよ、まだ席に座ってないのか？"

    # say L3637 pla
    old "Sorry ma'am."
    new "すみません、先生。"

    # say L3645 luc
    old "This will also be at the end of term exam, so be sure to take good notes."
    new "期末試験にも出題されるから、しっかりメモを取るようにね。"

    # say L3656 luc
    old "Remember to practice the subject at home, the exam is very close, so don't relax too much and forget to study."
    new "家でその科目を練習することを忘れないように、試験はもうすぐだから、油断して勉強を忘れちゃいけないね。"

    # say L3657 luc
    old "I know it sounds like a lot of work, but you have to do this if you want to properly learn all your subjects before the end of term exams."
    new "大変そうに聞こえるけど、期末試験前にすべての科目をちゃんと学ぶなら、これをするしかないんだ。"

    # say L3667 pla
    old "Hmph, that was a surprise."
    new "ふん、それは意外だったな。"

    # say L3668 pla
    old "I thought Mike had figured out it was me who got Olivia pregnant."
    new "マイクがオリアンナを妊娠させたのが俺だって気づいてると思ったんだよ。"

    # say L3669 pla
    old "Thinking about it, now I have two things to keep hidden from him."
    new "考えてみれば、今や隠さなきゃならないことが二つになったな。"

    # say L3670 pla
    old "Ugh, this is so awkward."
    new "うっ、これめっちゃ恥ずかしいな。"

    # say L3684 oli
    old "Hey [pla], did you come to study again?"
    new "Hey [pla]、また勉強しに来たの？"

    # say L3686 pla
    old "Yeah, we've been advancing well lately, I figured we could have another study session."
    new "最近調子が良かったから、また一緒に勉強しようかと思ったんだ。"

    # say L3687 oli
    old "Hmm, that's a good idea."
    new "うん、そうかも。"

    # say L3688 oli
    old "But... To be honest I'm not sure I'm up to it right now."
    new "でも…正直、今は何ともないのかもしれない。"

    # say L3689 pla
    old "Are you feeling bad again because of the pregnancy?"
    new "妊娠のせいで体調が悪いのか？"

    # say L3690 oli
    old "No, it's not that."
    new "いいえ、そうじゃないの。"

    # say L3691 oli
    old "Or rather, I think it is..."
    new "むしろ、そうなのかもしれないけど…"

    # say L3692 oli
    old "I just don't think I can study right now [pla]."
    new "今すぐ勉強する気になれないの [pla]。"

    # say L3694 pla
    old "I see, I understand."
    new "分かった、なるほど。"

    # say L3695 pla
    old "Is there anything I can do to help you?"
    new "何か手伝えることはあるのか？"

    # say L3696 pla
    old "Could I get you something for the discomfort you're feeling?"
    new "君が感じてる不快な症状を和らげるためには何かできるかな？"

    # say L3699 oli
    old "I mean, I'm not in pain or anything like that."
    new "痛みとかそういうわけではないんだけど。"

    # say L3701 pla
    old "I'm asking you in case there's anything I could do to help."
    new "君に何か手伝えることがないかと思ってさ。"

    # say L3703 oli
    old "I don't know [pla]..."
    new "わからないわ [pla]..."

    # say L3704 oli
    old "It's just a little embarrassing, you know?"
    new "ちょっと恥ずかしいんだよね、わかる？"

    # say L3705 pla
    old "Is it? Why? What's happening?"
    new "何だよ、どうしたって？"

    # say L3710 oli
    old "{b}*Sigh*{/b} I guess there's no harm in telling you."
    new "{b}……（ため息）{/b} まあ、君に言ってもいいかな。"

    # say L3711 oli
    old "You know, ever since I got pregnant I've been feeling this kind of..."
    new "私があなたの妊娠してから、この種の……"

    # say L3712 oli
    old "Tiredness? Fatigue?"
    new "疲労感？倦怠感？"

    # say L3713 oli
    old "It's hard to explain, but since the pregnancy started that's how I've been feeling."
    new "説明するのが難しいんだけど、妊娠してからそんな感じがしてるの。"

    # say L3715 pla
    old "{i}(That's similar to what Brixxida told me was going to happen.){/i}"
    new "{i}(ブリクシダも同じようなことを言ってたな。){/i}"

    # say L3716 pla
    old "{i}(I wonder if it's because her body needs more magic.){/i}"
    new "{i}(彼女の体がもっと魔法が必要になったからかもしれないな。){/i}"

    # say L3717 oli
    old "I went to the doctor and asked if that's a normal thing to happen."
    new "医者に行ってそれが普通のことかどうか聞いてみたら。"

    # say L3718 oli
    old "They said that it's uncommon, but I might be experiencing some sort of chronic fatigue because of the pregnancy."
    new "医者には珍しいことだけど、妊娠による慢性疲労の可能性があるって言われた。"

    # say L3719 oli
    old "But they ran several tests and concluded that I'm in good health."
    new "でも、いくつかの検査を受けて、結局は健康だって言われた。"

    # say L3721 pla
    old "Alright, and is it that fatigue the reason why you don't feel like studying?"
    new "大丈夫、その疲れが勉強したくない理由なのか？"

    # say L3723 oli
    old "Not really..."
    new "そうでもないかな..."

    # say L3724 oli
    old "I think it's related, but it's so hard to explain..."
    new "関係があるとは思うけど、説明するのが難しいの..."

    # say L3725 pla
    old "I think you can explain it to me. No problem."
    new "君が説明できると思う。問題ないさ。"

    # say L3726 oli
    old "Hmm, you think so?"
    new "うーん、そう思ってくれるの？"

    # say L3727 oli
    old "Ok, well..."
    new "Ok、まあ…"

    # say L3728 oli
    old "The thing that has me feeling bad is this weird..."
    new "私を不安にさせるのは、この妙な…"

    # say L3730 oli
    old "H- horniness that I've been feeling ever since I got pregnant."
    new "あのう、私、妊娠してから妙に…Ｈな気分になっちゃうの。"

    # say L3731 pla
    old "O- oh! I- I see..."
    new "おっ！そうなのか…"

    # say L3733 oli
    old "Y- yeah... And it's a very weird type of being horny."
    new "うーん… そうね… そしてそれはとても不思議な種類の性欲なんだ。"

    # say L3734 oli
    old "At first I thought it was just because of the hormones."
    new "最初はただホルモンのせいだと思ったの。"

    # say L3735 oli
    old "But as that fatigue that I told you about has kept growing, so has this weird feeling of horniness."
    new "でも、あの疲労感がどんどんでかくなっていくにつれて、この変な性的な感じも強くなっていったの。"

    # say L3736 oli
    old "And lately sex is the only thing that I've been able to think about, you know?"
    new "最近、セックスのことしか考えられなくなって、分かる？"

    # say L3737 pla
    old "I think I understand."
    new "俺も分かるよ。"

    # say L3738 pla
    old "But if that's the case, why didn't you tell me about it before?"
    new "でも、そうならなぜ今まで教えてくれなかったんだ？"

    # say L3739 pla
    old "I mean... It's not as if we don't know each other."
    new "つまり... お互いに知り合ってるわけだ。"

    # say L3740 pla
    old "I could've helped you with it."
    new "手伝えたのにさ。"

    # say L3742 oli
    old "I don't know [pla], you've already done so much for me."
    new "[pla]、あなたにはもうたくさん助けてもらったから、わからないわ。"

    # say L3744 oli
    old "And it's not as if we're a couple, this whole pregnancy thing is just you helping me with a problem that I have."
    new "そして、私たちが恋人同士じゃないんだから、この妊娠の問題はあなたが私を助けてくれてるだけのことよ。"

    # say L3746 oli
    old "I wouldn't even know how to bring up the subject."
    new "そんなこと、どうやって切り出せばいいのかわからないよ。"

    # say L3747 pla
    old "Hey, I get that, but come on, if it's something that you need, I'll be more than happy to help you."
    new "Hey、分かってるけど、本当に必要なら喜んで手伝うよ。"

    # say L3748 pla
    old "So... i- if you think you could use my help, maybe I can do something for you."
    new "じゃあ… もし君が俺の手助けが必要だと思えば、何かできるかもしれないよ。"

    # say L3750 oli
    old "Ok, m- maybe we can give it a go then..."
    new "Ok、もしかしたらやってみようか…"

    # say L3759 oli
    old "Ngnh! Oh god! This is amazing!"
    new "ンンッ！神様！これ、本当にすごいよ！"

    # say L3760 oli
    old "This big dick is just so great!"
    new "この大きなチ○ポ、本当に最高だよ！"

    # say L3761 oli
    old "Oh [pla]! I can't believe how good it feels!"
    new "ああ、[pla]！こんなに気持ちいいなんて信じられない！"

    # say L3770 oli
    old "Oh God [pla]! That feels so much better!"
    new "ああ神様 [pla]！これほど気持ちいいなんて！"

    # say L3771 oli
    old "I don't know why, but it's as if that tiredness had just left my body all of a sudden."
    new "なぜか急にその疲れが体から消えたみたい。"

    # say L3772 oli
    old "If I had known before that it was going to be that way, I would've told you about this sooner."
    new "もし前に知っていたら、もっと早くあなたに教えてあげたのに。"

    # say L3773 pla
    old "I'm very happy that you feel better."
    new "君が元気になったことが嬉しいよ。"

    # say L3774 pla
    old "That was the whole point, it's good that this worked."
    new "それが目的だった、うまくいったのが良かったよ。"

    # say L3776 oli
    old "You're the best, [pla]. Thank you so much."
    new "あなたが最高だよ、[pla]。本当にありがとう。"

    # say L3777 oli
    old "I don't think we'll be able to get to study right now."
    new "今すぐは勉強できないと思うけど。"

    # say L3778 oli
    old "But I think we can do it later."
    new "でも後でできるかな。"

    # say L3779 oli
    old "For now, thank you so much for the help [pla]."
    new "今暫くは、本当に助けてくれてありがとうね [pla]。"

    # say L3781 pla
    old "My pleasure, after all, we're in this together."
    new "もちろんだよ、一緒に頑張る仲だからさ。"

    # say L3782 pla
    old "I guess I'll get going to my house and I'll see you later, alright?"
    new "じゃあ、俺は家に戻るから、また後でな。"

    # say L3812 pla
    old "Oh! Hey Olivia, how are you?"
    new "オッ！オリアナ、元気？"

    # say L3814 oli
    old "Hey [pla], well you know..."
    new "Hey [pla]、まあ、いつも通りさ。"

    # say L3816 pla
    old "What? Did something happen?"
    new "何？何かあったのか？"

    # say L3818 oli
    old "I mean, my family's still a little annoying."
    new "つまり、家族がまだ少しうるさいんだけど。"

    # say L3820 oli
    old "It's been a little hard, you know, all this with my dad and mom..."
    new "最近、パパとママのこととかでちょっと大変なんだよね、"

    # say L3821 oli
    old "And with my body getting fatter and fatter..."
    new "でも、体がどんどんどん太っちゃって…"

    # say L3823 pla
    old "You know... This makes me feel kinda guilty."
    new "君がそんなに苦しいなら、俺もちょっと悪い気分だな。"

    # say L3825 pla
    old "Well... I mean, it is kinda my fault that you're in this situation."
    new "まあ……君がこんな状況になったのは、確かに俺のせいかもしれないな。"

    # say L3827 pla
    old "And I don't only mean the pregnancy."
    new "そして、妊娠だけじゃなくてね。"

    # say L3829 pla
    old "But also what's happening with your family."
    new "でも、君の家族のことだってそうだよ。"

    # say L3830 pla
    old "I can't avoid thinking that this is my responsibility."
    new "この状況が自分の責任だと思っちゃうんだ。"

    # say L3833 oli
    old "I get what you're saying [pla]."
    new "あなたの気持ちはわかります [pla]。"

    # say L3835 oli
    old "But I don't think you should feel any guilt for it."
    new "でも、それについては罪悪感を感じる必要はないと思う。"

    # say L3837 oli
    old "After all, I was the one that came up with this idea."
    new "畢竟、このアイデアは私が出したんだ。"

    # say L3839 oli
    old "Not to mention I'm the one who dragged you into this whole situation."
    new "それに、この状況に引きずり込んだのは私だよ。"

    # say L3840 pla
    old "Well, yeah, but still, you're the one bearing all the weight of this whole thing."
    new "まあ、そうだよ、でも結局、全部の重さを君が背負ってるわけだな。"

    # say L3841 pla
    old "Both figuratively and literally."
    new "両方ともだね。"

    # say L3843 oli
    old "Yeah, but is something that was needed."
    new "うん、でも必要なことだったしね。"

    # say L3844 oli
    old "So don't beat yourself up too much for putting me in this state."
    new "だからあまり自分を責めすぎないで。"

    # say L3846 oli
    old "Besides, it's not as if we didn't both enjoy it, right?"
    new "それに、お互い楽しんでたじゃない。"

    # say L3847 pla
    old "Well, yeah, we did."
    new "まあ、そうさ、楽しんだよ。"

    # say L3848 oli
    old "There you go. So don't beat yourself up over it. There's no problem."
    new "そうだよ。だから気にしないでいい。問題ないんだから。"

    # say L3849 pla
    old "I guess so."
    new "そうか"

    # say L3850 pla
    old "But still, I'd like it if you could feel a little bit more comfortable."
    new "でも、君がもう少しリラックスしてくれたら嬉しいな。"

    # say L3852 oli
    old "Oh, I think there's something that you could do to help me with that."
    new "あ、私が少しでもリラックスできるように、あなたに何かしてもらえると嬉しいな。"

    # say L3854 oli
    old "Come on, don't think too much about me being uncomfortable."
    new "Come on,そんなに気を使うなよ。"

    # say L3857 oli
    old "Now, let's go to my house."
    new "さあ、うちに行こう。"

    # say L3858 oli
    old "The entrance exams are coming, so I want to study a little more."
    new "入学試験が近いから、もう少し勉強したいの。"

    # say L3876 mik
    old "W- w- what was that?! W- what did I just hear?!"
    new "W- 何それ？！ W- 今何聞いた？！"

    # say L3877 mik
    old "[pla]?! H- he got my girl pregnant?!"
    new "[pla]？！ 本気で、彼女を妊娠させたってことかよ！"

    # say L3878 mik
    old "N- no way! I- it can't be..."
    new "N- ありえない！ そんなわけないだろ…"

    # say L3879 mik
    old "No! H- he wouldn't do that!"
    new "ない！ そんなこと、絶対にやらないだろ！"

    # say L3880 mik
    old "With my girl?! What the hell?!"
    new "俺の彼女と？！ 何言ってんだよ？！"

    # say L3898 pla
    old "Oh! Brixxida, hi."
    new "オッ！ブリクシダ、こんにちは。"

    # say L3900 bri
    old "Hey, good morning."
    new "おはよう👋"

    # say L3901 pla
    old "What are you doing here in my room so early?"
    new "何してんだよ、こんな早朝に俺の部屋に？"

    # say L3902 bri
    old "Well, I was about to wake you up actually.."
    new "実は、起こしに来たの。"

    # say L3903 pla
    old "Oh! How come?"
    new "オッ！どうしたんだ？"

    # say L3905 bri
    old "Well, how long has it been since you implanted the magic in that girl?"
    new "魔法をその子に植え付けてから、どのくらい経つのかな？"

    # say L3906 bri
    old "And you haven't given me any update on how things are going with her."
    new "そして彼女の状況について、何も報告してあげてないよね。"

    # say L3907 pla
    old "Uh, well, there haven't been any new updates."
    new "うーん、新しいアップデートは特にないな。"

    # say L3908 pla
    old "The only thing that's happened is what you told me."
    new "君が教えてくれたことだけだ。"

    # say L3909 pla
    old "She's been feeling a little tired, so she asked me to have sex with her."
    new "彼女はちょっと疲れてるみたいだから、セックスしてほしいって言ったんだ。"

    # say L3910 bri
    old "And that's it? How's her pregnancy going?"
    new "それだけ？彼女の妊娠はどう？"

    # say L3911 pla
    old "How's it going?"
    new "どうしてるんだ？"

    # say L3912 pla
    old "Uhmm, it's very advanced, I would say."
    new "うーん、かなり進んでるな。"

    # say L3913 pla
    old "Just as you told me, her belly grew so quickly."
    new "君が言った通り、彼女の腹はすぐに大きくなったよ。"

    # say L3914 pla
    old "You would think she's going to give birth any time now."
    new "いつ産むんじゃないかって思ってるよ。"

    # say L3916 bri
    old "That's exactly what I mean you dimwit!!"
    new "それがまさに私が言いたいことだよ、バカ！！"

    # say L3917 pla
    old "W- why are you angry?"
    new "なんで怒ってるんだ？"

    # say L3919 bri
    old "Why do you think?"
    new "なんでそう思ってるの？"

    # say L3920 bri
    old "I told you [pla]! This isn't a normal human pregnancy!"
    new "[pla]！普通の人間の妊娠じゃないって言ったでしょ！"

    # say L3922 bri
    old "Any moment now she could give birth! And we haven't made the closing ritual for the spell!"
    new "いつでも産まれちゃうかもしれないのに！そして呪文の閉じる儀式もまだやってないんだよ！"

    # say L3923 pla
    old "What are you talking about? Closing ritual?"
    new "何言ってんの？閉じ式って？"

    # say L3924 bri
    old "Yes [pla]! A closing ritual."
    new "うん [pla]！ 終了儀式のこと。"

    # say L3926 bri
    old "In the same way that I had to be there for the implantation of the magic."
    new "同じように、魔法の植え込みの時も私が必要だったの。"

    # say L3930 pla
    old "E- extraction? What are you talking about?"
    new "えー、抽出？何言ってるんだ？"

    # say L3931 pla
    old "You never told me about any kind of extraction!"
    new "君は抽出について何も教えてくれなかったぞ！"

    # say L3933 pla
    old "Where was all of this with Barbie?"
    new "バービーの時はどこにもなかったんだよ？"

    # say L3934 bri
    old "Well, for your information, we were never even close to finishing anything with Barbie because you decided to interrupt the spell!"
    new "まあ、情報提供だけど、バービーとの魔法はあなたが中断したから、何も完成しなかったのよ。"

    # say L3936 bri
    old "Besides, I decided to modify the spell after your stupid tantrum last time with Barbie."
    new "それに、前回バービーとのときにあなたが大騒ぎしたから、私は呪文を改良することに決めたの。"

    # say L3939 pla
    old "Uh, o- ok? But I don't get it, why?"
    new "うーん、おk？でも、それはなぜだ？"

    # say L3940 bri
    old "As I told you, after what happened last time with Barbie, I gave it a thought and decided the best thing to do was modify the spell."
    new "前にも言ったけど、バービーのときのことを考えて、 Spell を改良することに決めたの。"

    # say L3941 bri
    old "This is because last time we ended up losing a lot of magic power."
    new "これは前回、魔法力をかなり失ってしまったからよ。"

    # say L3943 bri
    old "You see, the way it should work is that the condensation spell is over at the same time that the pregnancy is."
    new "つまり、結晶化の呪文が妊娠が終わるのと同じタイミングで終了するようにすべきってこと。"

    # say L3945 bri
    old "But I realized that this approach only works if we let things come to term naturally."
    new "でも、この方法は自然に妊娠が完了する場合だけ有効だと気づいたの。"

    # say L3947 bri
    old "But if it's something like what happened with Barbie were to happen again."
    new "でも、バービーのときのようなことがまた起こったら。"

    # say L3948 bri
    old "We would end up losing all of the already cultivated magic power."
    new "それによってすでに培われた魔力全てを失ってしまうわ。"

    # say L3951 pla
    old "But how did you solve it then?"
    new "でもその問題はどのように解決したんだ？"

    # say L3953 bri
    old "I did it by making a change to the way the spell works."
    new "Spellの仕組みを変更することで解決したの。"

    # say L3955 bri
    old "Instead of letting it end by itself, we're directly extracting the magic power from the girl."
    new "代わりに、魔法の力を女の子から直接取り出すようにしたの。"

    # say L3957 bri
    old "This way it affords me a lot more control over the magic, and the moment it's extracted."
    new "この方法だと、魔法のコントロールがずっと効きやすく、抽出する瞬間も自在にできるから。"

    # say L3958 bri
    old "So, even if something similar to what happened last time with Barbie were to happen again."
    new "そう、前回のバービーのようなことがまた起こっても。"

    # say L3960 bri
    old "We could simply cancel the cultivation process and we wouldn't lose anything."
    new "そうすれば、栽培プロセスを簡単に中止できるし、何も失うものはないわ。"

    # say L3962 pla
    old "That's awesome Brixxida! And it's very reassuring!"
    new "ブリクシダ、それはすごいな！そしてとても安心できるよ！"

    # say L3964 bri
    old "Yeah, it's very good."
    new "うん、それはとてもいいね。"

    # say L3966 bri
    old "But there's a condition to the spell in this new form: there HAS to be an extraction."
    new "でもこの新しい形の呪文には条件があって：絶対に取り出さないといけないの。"

    # say L3968 bri
    old "There's no point if we don't do it and the pregnancy just ends without us doing the extraction! We will lose all the magic!!"
    new "やらないで妊娠が終わっちゃうんじゃ意味がないわ！魔法全部失っちゃうんだから！"

    # say L3969 pla
    old "I- I'm sorry Brixxida, I didn't know."
    new "ブリクシダ、ごめんなさい、知らなかったんだ。"

    # say L3970 bri
    old "Hmph, as long as you understand."
    new "ふん、分かったなら良いわ"

    # say L3972 bri
    old "But then you have to remember, sooner rather than later, we need to extract the magic power from her."
    new "でもね、早いうちに彼女の魔力を取り出さないといけないの。"

    # say L3973 bri
    old "Otherwise, she'll have a human with a magic supercharge."
    new "それじゃ、彼女の中に魔法の力が過剰に充電された人間が生まれちゃうわ。"

    # say L3974 bri
    old "And honestly, I don't know what that means in the long term."
    new "正直、それが長期的に何を意味するのかわからないの。"

    # say L3979 bri
    old "By the way, [pla], there's something else you should know."
    new "その通り、[pla]、知っておくべきことが他にもあるの。"

    # say L3981 bri
    old "Before we do the magic extraction, she has to decide if she wants to be a mother or not."
    new "魔法を抽出する前に、彼女は母親になるかどうか決めないといけないの。"

    # say L3984 bri
    old "This is because when we extract the magic power, I need to know if I'll take it all or just a small part."
    new "これは魔法力を抽出するときに、全部取るのか、それとも一部だけにするのかを知る必要があるからよ。"

    # say L3985 pla
    old "What happens either way?"
    new "どちらのケースでも何が起こるんだ？"

    # say L3987 bri
    old "Well, if she decides not to go through with the whole process, I'll extract all the magic power from her."
    new "もし彼女が全过程を経ないことに決めたら、彼女から全ての魔力を取り出すわ。"

    # say L3989 bri
    old "And her pregnancy will be reversed."
    new "そして妊娠は元に戻るわ。"

    # say L3991 bri
    old "So in the end, it'll be like she was never pregnant."
    new "結局、妊娠したことがなかったみたいになるわ。"

    # say L3993 bri
    old "On the other hand, if she decides to go through the whole process."
    new "一方、彼女が全过程を経験することに決めたら。"

    # say L3995 bri
    old "I'll take most of it, but I'll leave a small amount of power, so a life will be created."
    new "MOST OF IT、でも少しだけ力を残しておくから、命が生まれるわ。"

    # say L3996 pla
    old "I see... So that's how it is."
    new "なるほど… そういうことか。"

    # say L3997 pla
    old "Alright, I'll be sure to talk to her about it."
    new "分かった、ちゃんと話すよ。"

    # say L3999 bri
    old "Good, make sure you do that."
    new "分かった、ちゃんと話すからね。"

    # say L4000 pla
    old "Yeah, I'll do it and let you know."
    new "やるよ、結果も教えて。"

    # say L4014 pla
    old "Alright! That's it!"
    new "よし！それじゃあ！"

    # say L4015 pla
    old "I think that's all the subjects we needed to study for the entrance exam."
    new "俺の思うに、入試のために必要な科目の勉強は全部終わったな。"

    # say L4017 pla
    old "I think with that, you should ace the exam!"
    new "あのさ、これで君なら試験に余裕で合格できるはずだよ！"

    # say L4019 oli
    old "Oh my god! Thank you so much, [pla]!"
    new "おーっ！　本当にありがとう、[pla]！"

    # say L4021 oli
    old "At first, I couldn't believe we would ever manage to cover everything."
    new "最初は、全部をカバーできるなんて信じられなかった。"

    # say L4023 oli
    old "But we did it!"
    new "でもやり遂げた！"

    # say L4025 oli
    old "I can't believe it, this is the best thing ever, [pla]!"
    new "信じられない、これが最高だよ、[pla]！"

    # say L4027 pla
    old "Yeah, for a moment there, I also thought we wouldn't have time to cover everything."
    new "一瞬だけ俺も全部をカバーできる時間がないんじゃないかと思ったけど。"

    # say L4028 pla
    old "But you've been so disciplined, Olivia. It's amazing how much effort you've put in such a short time."
    new "でもオリアナ、君は本当に律儀だね。こんな短い時間にこれだけの努力をしたのはすごいよ。"

    # say L4029 pla
    old "This is definitely all because of your hard work."
    new "これは間違いなく君の努力のおかげだね。"

    # say L4031 oli
    old "Still, you've been an amazing teacher, [pla]."
    new "それでも、[pla]は素晴らしい先生だったね。"

    # say L4032 oli
    old "Thinking about it, we had a very rocky start."
    new "考えてみれば、私たちの始まりはかなり荒れ狂っていたわね。"

    # say L4034 oli
    old "With me blackmailing you with what I saw you do at Mike's house."
    new "私があなたがマイクの家でやったことを見たってことで、脅迫してしまって。"

    # say L4035 oli
    old "I'm sorry about that, by the way."
    new "そのこと、すみませんでしたね。"

    # say L4037 pla
    old "I mean, it's alright, given the situation you were in."
    new "状況を考えれば、まあ仕方ないか。"

    # say L4039 pla
    old "I'm not saying it's okay, but I understand you were in a desperate position."
    new "俺はそれが許せるってわけじゃないけど、お前が必死な状況だったことは理解してるよ。"

    # say L4041 pla
    old "But it's alright."
    new "でもいいさ。"

    # say L4045 oli
    old "Thank you for your understanding."
    new "理解してくれてありがとう。"

    # say L4047 oli
    old "And for being so helpful."
    new "そして、手伝ってくれてありがとう。"

    # say L4048 oli
    old "I came up with such a crazy idea, and you decided to help me with it."
    new "そんな奇抜なアイデアを思いついて、あなたが手伝ってくれたなんて。"

    # say L4050 oli
    old "And on top of that, you even took time to explain all these topics to me."
    new "それに、あなたはこれらのトピックを説明するために時間まで割いてくれたの。"

    # say L4053 oli
    old "I don't know how to show my gratitude."
    new "感謝の気持ちをどう表現していいかわからないの。"

    # say L4055 oli
    old "But I can think of a couple of ways."
    new "でもいくつか思いつくわ。"

    # say L4056 oli
    old "You know, I've been feeling a little tired lately."
    new "最近、ちょっと疲れてるのさ。"

    # say L4057 pla
    old "Y- you are?"
    new "お前？"

    # say L4059 oli
    old "Yeah, I'm not feeling my best lately."
    new "うん、最近調子がよくないの。"

    # say L4060 oli
    old "I was thinking maybe you could help me a bit with that."
    new "ちょっと手伝ってもらえるかもって思ってた。"

    # say L4061 oli
    old "And at the same time, maybe I can show my thanks for everything you've done for me."
    new "そして同時に、あなたに感謝の気持ちを伝えられたらいいな。"

    # say L4063 pla
    old "Uh, y- yeah sure, I don't see why not."
    new "うーん、ええ、いいよ、別に構わないさ。"

    # say L4065 oli
    old "Great! Give me a second to go to the bathroom, and I'll be right back."
    new "Great！ ちょっとトイレに行ってくるから、すぐ戻るね。"

    # say L4066 oli
    old "Don't worry, you won't have to wait long."
    new "心配しないで、そんなに待たせるのは嫌だよ。"

    # say L4068 pla
    old "Oh right! By the way."
    new "ああそういえば、"

    # say L4069 pla
    old "I wanted to ask you something."
    new "君に聞きたいことがあったんだ。"

    # say L4070 pla
    old "Maybe this isn't what you expect right now."
    new "今これが期待されてないかもしれんけど。"

    # say L4072 pla
    old "But I was thinking we still haven't talked about your decision regarding your pregnancy."
    new "でも、君の妊娠についての決断についてまだ話してないな。"

    # say L4074 pla
    old "D- don't get me wrong, I'm not trying to convince you of anything."
    new "誤解しないでくれ、何かを説得しようとしてるわけじゃない。"

    # say L4076 pla
    old "I just want to know where you stand on it, you know?"
    new "ただ、君の立場を知りたいだけだよ、わかる？"

    # say L4077 pla
    old "Just because I worry about you."
    new "心配してるだけでね。"

    # say L4079 oli
    old "Well... I have to say I originally thought about waiting for the entrance exam results."
    new "まあ……最初は入学試験の結果を待とうと思っていたの。"

    # say L4080 oli
    old "You know, because I wanted to know if I got into college."
    new "知ってるでしょ、大学に合格したかどうか知りたかったから。"

    # say L4081 oli
    old "But I thought about it and understood what I want."
    new "でも考えてみたら、自分が何をしたいのかわかったの。"

    # menu L4084 
    old "Extract the whole magic power."
    new "魔力全部取り出す。"

    # say L4087 oli
    old "I've decided that I don't want to be a mother."
    new "私は母親になるのは望んでないんだ。"

    # say L4089 oli
    old "I- it's just that it wasn't my original plan, you know?"
    new "ただ、最初の計画じゃなかったのよ、分かる？"

    # say L4091 oli
    old "When I got myself into this situation, it was only to get my parents off my back."
    new "この状況に自分から入ったのは、親にしつこく言われるのが嫌だったからよ。"

    # say L4093 oli
    old "But I have to say, I've never considered being a mother so young."
    new "でもね、こんな若い頃に母親になるなんて一度も考えたことがないんだよ。"

    # say L4094 oli
    old "There are still so many things I want to do, and being a mother would get in the way of all that."
    new "まだやりたいことがたくさんあるのに、母親になるのはそのすべての邪魔になるわ。"

    # say L4096 oli
    old "Besides, I would be dragging you into this situation too."
    new "それに、あなたまでこの状況に巻き込むことになるわ。"

    # say L4098 oli
    old "You've done a lot for me, [pla], but I can't ask any more from you."
    new "あなたは私のためにたくさんしてくれた、[pla]、でもこれ以上は求められない。"

    # say L4100 oli
    old "So I think it's better if I just leave things as they are."
    new "だから、今のままにしておく方がいいと思うの。"

    # say L4102 pla
    old "You know? I completely understand what you mean."
    new "君の気持ち、完全に理解できるよ。"

    # say L4103 pla
    old "I'm happy you're thinking about your future."
    new "君の未来について考えてくれて嬉しいよ。"

    # say L4104 pla
    old "And hey, thanks for trusting me."
    new "信頼してくれてありがとう。"

    # say L4106 oli
    old "I'm glad you've been my partner through this whole process, [pla]. Thank you so much."
    new "このプロセスを通じて私のパートナーでいてくれて本当に嬉しい、[pla]。ありがとう。"

    # menu L4110 
    old "Extract most of the magic power but leave a small part."
    new "魔力をほとんど取り出すけど、少しだけ残しておく。"

    # say L4112 oli
    old "Well, I don't know how to tell you this."
    new "WELL、このことをどう伝えるべきかわからないの。"

    # say L4114 oli
    old "But I decided that I want to be a mother."
    new "でも、母親になりたいって決めて。"

    # say L4116 oli
    old "I- I don't mean that I want to make you a father or anything, [pla]!"
    new "あのね、私はあなたを父親にしたいわけじゃないのよ、[pla]！"

    # say L4118 oli
    old "It's just that I've been thinking, and I think I want to give it a go."
    new "ただ、最近考えてみて、母親になってみたくなったの。"

    # say L4120 oli
    old "Ever since this happened, I've been feeling better and better about the possibility of being a mother."
    new "このことが起こってから、母親になる可能性についてどんどん良くなってきたの。"

    # say L4121 pla
    old "And you decided that you want to do it?"
    new "それで君はやってみたいと思ったんだ？"

    # say L4122 oli
    old "Well, yeah."
    new "うん、そう。"

    # say L4124 oli
    old "I've been thinking about it and I think it's possible."
    new "考えてみたら、できるかもしれないと思った。"

    # say L4126 oli
    old "Lately, my father has come around to the idea of me being a mom."
    new "最近、父も私が母親になることに賛成してくれるようになって。"

    # say L4128 oli
    old "And my mom's pretty excited about it too."
    new "そして私の母もかなり興奮してるの。"

    # say L4130 oli
    old "So I figured I could try it."
    new "だから試してみようと思ったの。"

    # say L4132 oli
    old "B- but I'm not trying to make you a father!"
    new "でも、君を父親にしようとは思ってないの！"

    # say L4134 oli
    old "I don't expect you to get involved or anything."
    new "私があなたが関与することを期待してるわけじゃないの。"

    # say L4135 oli
    old "It's just what I want to do, [pla]."
    new "ただ私がしたいだけのことだから、[pla]。"

    # say L4137 pla
    old "It's alright, I understand. And I would never try to convince you otherwise."
    new "大丈夫、理解してる。君を説得しようとは決して思わない。"

    # say L4138 pla
    old "I just wanted to know what your plans were."
    new "ただ君の予定を知りたかっただけだよ。"

    # say L4140 pla
    old "And I'm happy you're in a position where you can decide this."
    new "君が自分で決められる立場にあることが嬉しいよ。"

    # say L4141 pla
    old "I'll help you in any way you need me to."
    new "必要なことなら何でも手伝うよ。"

    # say L4146 oli
    old "Thanks for all your support, [pla]!"
    new "あなたのサポート本当に助かる、[pla]！ありがとう！"

    # say L4147 oli
    old "Listen, I have to go to the bathroom."
    new "ちょっと、トイレに行ってくるからね。"

    # say L4148 oli
    old "But when I come back, I want to see you ready."
    new "でも戻ったら、準備できてるのね。"

    # say L4154 pla
    old "Ok, I should take this chance to bring Brixxida here!"
    new "よし、このチャンスにブリクシダを連れてくるぞ！"

    # say L4164 bri
    old "What do you need?"
    new "何が必要なの？"

    # say L4165 bri
    old "That really surprised me."
    new "びっくりしたわ。"

    # say L4166 pla
    old "Well, I think now's the perfect time for you to end the spell."
    new "じゃあ、今が君が呪文を解くのに最適なタイミングだな。"

    # say L4167 bri
    old "That's just perfect. Well done calling me here, [pla]!"
    new "それが完璧ね。呼んでくれてありがとう、[pla]！"

    # say L4175 oli
    old "Alright, let's do this."
    new "よし、行こう。"

    # say L4178 oli
    old "Come on, I want you to fuck me right now."
    new "さあ、今すぐ私を犯してほしい。"

    # say L4179 pla
    old "S- sure, right away!"
    new "分かった、今すぐやるよ！"

    # say L4189 oli
    old "Oh God yes! That's just what I've been missing, [pla]!"
    new "ああ神よ、そうよ！これが欲しくてたまらなかったの、[pla]！"

    # say L4190 bri
    old "Oh yeah, [pla]! That's just what I wanted!"
    new "あहyeah、[pla]！それが欲しかったの！"

    # say L4191 oli
    old "This feels so amazing!"
    new "これ、めちゃくちゃ気持ちいい！"

    # say L4201 oli
    old "That was sooo good, [pla]!"
    new "それがよかったです、[pla]！"

    # say L4202 oli
    old "Just like always, that dick of yours never disappoints."
    new "いつも通り、あなたのチ○ポは期待を裏切らないね。"

    # say L4203 pla
    old "I'm glad you liked it."
    new "良かったな、君が気に入ったなら。"

    # say L4206 oli
    old "Well, mostly, yeah."
    new "まあ、大体そうね。"

    # say L4207 oli
    old "But you know? I still feel a little bit tired."
    new "でもね、まだちょっと疲れてるの。"

    # say L4208 oli
    old "And I feel like I haven't thanked you enough for everything."
    new "でもね、あなたに感謝してるって十分に伝えられてない気がするの。"

    # say L4209 oli
    old "So I have another thing for you. Come here."
    new "だからね、あなたにまた一つあるの。ここに来なさい。"

    # say L4218 oli
    old "Slrrp! Oh yeah!"
    new "スルルッ！ああ、そうよ！"

    # say L4219 oli
    old "Hmm! I wanted to taste this dick again!"
    new "ん！またこのちんこを味わいたかったの！"

    # say L4220 oli
    old "Just relax and enjoy it [pla]!"
    new "リラックスして楽しめよ [pla]！"

    # say L4232 oli
    old "Alright! I think that does it!"
    new "よし！これでいいかな！"

    # say L4233 oli
    old "I hope you liked my way of saying thanks to you, [pla]!"
    new "私の感謝の仕方が気に入ったなら、うれしいな、[pla]！"

    # say L4235 pla
    old "Yeah, I think it was great!"
    new "そうだな、本当に最高だったよ！"

    # say L4237 oli
    old "I'm glad. Thanks again for everything, [pla]."
    new "うれしいな。また感謝してる、[pla]。"

    # say L4239 oli
    old "I'm sure I'm going to do great on those exams."
    new "試験はきっとうまくいくわ。"

    # say L4240 pla
    old "I'm completely sure of it."
    new "絶対に大丈夫だよ。"

    # say L4242 pla
    old "You've worked very hard to get a good result."
    new "君の努力はすごいから、きっといい結果が出るよ。"

    # say L4243 pla
    old "There's no doubt that you'll ace it."
    new "君が合格するってことは間違いないよ。"

    # say L4245 oli
    old "Thanks, [pla]. Your support means everything to me."
    new "ありがとう、[pla]。あなたのサポートは私にとって本当に大切だよ。"

    # say L4247 pla
    old "Hey, I think I should be going home, right?"
    new "俺、帰るか、 oli。"

    # say L4248 pla
    old "So you'll have time to rest properly."
    new "そうしたら、ちゃんと休める時間ができるよ。"

    # say L4250 oli
    old "Sure, thanks again, [pla]."
    new "もちろん、またありがとう、[pla]。"

    # say L4252 pla
    old "You're welcome, Olivia."
    new "どういたしまして、オリビア。"

    # say L4264 pla
    old "Okay, I think that settles everything with the spell, right?"
    new "オッケー、それじゃあ呪文のことは決まったんだ、な？"

    # say L4266 bri
    old "That's right. Now that we stopped the spell, she'll return to normal soon."
    new "そうだね。呪文を止めたから、彼女はすぐに元に戻るよ。"

    # say L4267 bri
    old "And don't worry about her health; she'll be completely fine."
    new "心配しなくていい、彼女は全然大丈夫だから。"

    # say L4268 bri
    old "So it should be all good."
    new "じゃあ、大丈夫ってことね。"

    # say L4272 bri
    old "Now, we can't extract the magic power from you yet."
    new "まだ、あなたの体内から魔力を抽出することはできないわ。"

    # say L4273 bri
    old "Because we need a little bit of time for the magic you extracted from her to settle within you."
    new "因为你从她那里提取的魔力需要一点时间在你体内稳定下来。"

    # say L4292 pla
    old "Hmm? Hello?"
    new "へえ？誰かいる？"

    # say L4293 pla
    old "Yes, this is him speaking."
    new "はい、俺だよ。"

    # say L4294 pla
    old "W- what?! N- now?!"
    new "W- 何だよ？！ 今って？！"

    # say L4295 pla
    old "I- I'll be there right away!"
    new "今すぐ行くよ！"

    # say L4300 pla
    old "I can't believe Olivia's already in the hospital!"
    new "オリビアがもう病院にいるなんて、信じられない！"

    # say L4301 pla
    old "I better hurry!"
    new "急がなきゃ！"

    # say L4314 pla
    old "I- I can't believe you're already here!"
    new "信じられない、もうここにいるんだね。"

    # say L4316 oli
    old "Me too, but my obgyn decided that now was the best time."
    new "私もそうだけど、産婦人科医が今が最適なタイミングだって決めたの。"

    # say L4318 oli
    old "So you know, I guess it's fine."
    new "そうね、いいかな。"

    # say L4320 pla
    old "And how do you feel? Are you ready?"
    new "君の気持ちはどう？準備はできてるかな？"

    # say L4322 oli
    old "I am, thank you, [pla]."
    new "うん、ありがとう、[pla]。"

    # say L4323 oli
    old "And hey, don't worry too much about me."
    new "心配しすぎないで、大丈夫だから。"

    # say L4324 oli
    old "I'm sure of my decision."
    new "私は自分の決断に自信があります。"

    # say L4325 oli
    old "And my mom and sister are already here to help with everything, so don't worry, alright?"
    new "でも心配しなくていい、ママと妹がもうここにいて手伝ってくれるから。"

    # say L4327 pla
    old "Alright, sure."
    new "分かった、大丈夫だ。"

    # say L4334 vee
    old "Honey, the nurse says they have to move you into the operating room."
    new "ハニー、看護師さんが手術室に移動しないといけないって言ってるの。"

    # say L4336 oli
    old "Sure, mom, no problem."
    new "はい、ママ、問題ないよ。"

    # say L4337 oli
    old "Alright, [pla], wish me luck."
    new "頑張って、[pla]、応援してるね。"

    # say L4338 pla
    old "Good luck, I know you've got this."
    new "頑張って、できるって知ってるよ。"

    # say L4348 pla
    old "Alright, that was rather fast."
    new "よし、それ速かったな。"

    # say L4350 oli
    old "I'm doing okay."
    new "大丈夫よ、全然平気だから。"

    # say L4352 oli
    old "Really, [pla], I'm completely fine with this."
    new "本当に、[pla]、これ全然平気だよ。"

    # say L4354 oli
    old "I was a little worried that my mom was going to be all annoying about it."
    new "心配してたの、ママがうるさくならないかって。"

    # say L4356 oli
    old "But she seems to be completely okay with all of this, so there's no problem really."
    new "でも、ママはこれ全部について全然問題ないって言ってるから、実際には問題ないんだ。"

    # say L4358 pla
    old "That sounds alright."
    new "それはいいね。"

    # say L4365 mar
    old "I'm sorry to bother you, sir, but it's time for the patient to rest."
    new "すみません、お邪魔しますが、患者さんには休んでいただく時間です。"

    # say L4367 pla
    old "Alright, I guess I'll see you later then."
    new "分かった、じゃあ後でな。"

    # say L4369 oli
    old "Sure, and hey, [pla], thanks again."
    new "もちろん、あとでね、[pla]、またありがとう。友達でいてくれて本当に感謝してる。"

    # say L4371 oli
    old "This big shift in my life wouldn't have been possible without you."
    new "この人生の大きな変化は、あなたがいなければできなかったわ。"

    # say L4373 oli
    old "I hope we'll continue being friends."
    new "友達の関係が続きますように願っています。"

    # say L4375 oli
    old "And hey, come see me whenever you want. We don't have to stop having fun after this."
    new "ねえ、いつでも遊びに来て。これで楽しくするのをやめる必要はないよ。"

    # say L4376 pla
    old "Sure, I'll do it."
    new "もちろん、君のためにいつでも時間作るよ。"

    # say L4385 pla
    old "Hey, how do you feel?"
    new "hey、どう感じてる？"

    # say L4387 oli
    old "I'm doing alright, it was a lot easier than I expected, you know?"
    new "大丈夫よ、思っていたよりずっと簡単だったのさ。"

    # say L4388 pla
    old "It was?"
    new "そうなのか？"

    # say L4390 oli
    old "Yeah, it was. The doctor really helped me."
    new "うん、そうだった。先生が本当に助けてくれたんだ。"

    # say L4391 oli
    old "So I didn't feel a lot of pain."
    new "だから痛みはそんなに感じなかった。"

    # say L4392 pla
    old "That sounds great, Olivia. That's awesome."
    new "それは良かったな、オリビア。素晴らしいね。"

    # say L4399 mar
    old "Would the new parents like to meet their newborn son?"
    new "新しいパパとママは、生まれたての息子に会いたいですか？"

    # say L4402 oli
    old "But I think I'm a little too tired to hold him right now."
    new "でも今すぐはちょっと疲れているから、抱っこするのは難しいかも。"

    # say L4403 oli
    old "But why don't you do it, [pla]?"
    new "でも、あなたがやってみない？[pla]"

    # say L4419 oli
    old "How about you, [pla]?"
    new "あなたはどう？[pla]"

    # say L4422 pla
    old "I'm actually alright, you know?"
    new "実は大丈夫だって、知ってる？"

    # say L4424 pla
    old "I have to say, I never expected to be a father so soon."
    new "俺も正直、こんなに早く父親になるとは思わなかったな。"

    # say L4426 pla
    old "But I can't say that I feel bad about any of this."
    new "でも、これについては特に悪い気はしないな。"

    # say L4428 pla
    old "I never expected to have all these feelings within me."
    new "こんな気持ちが溢れてくるなんて、全然予想してなかったよ。"

    # say L4430 pla
    old "But I think it's great, really."
    new "でも、俺はこれって最高だと思ってるよ、ほんと。"

    # say L4432 oli
    old "I'm so glad you feel that way, [pla]."
    new "あなたがそう感じているのが、本当に嬉しいわ、[pla]。"

    # say L4433 oli
    old "And by the way, you don't need to worry about anything related to money, you know?"
    new "それに言っておくけど、お金のことなんて心配しなくていいからね。"

    # say L4435 oli
    old "My dad said he's moving here to be closer to his grandson."
    new "お父さんがあなたに近いところに引っ越してくるって言ってたの。"

    # say L4437 oli
    old "So I don't think you'll need to worry about that."
    new "だからそれについては心配しなくていいよ。"

    # say L4439 pla
    old "I see, well, that's good."
    new "なるほど、それは良いね。"

    # say L4441 oli
    old "And by the way, we can still keep in touch."
    new "それにしても、連絡は取れるよ。"

    # say L4442 oli
    old "I'll be expecting some of your visits in the future."
    new "未来には君の訪問を楽しみにしているよ。"

    # say L4443 pla
    old "A- and I'll be sure to visit you."
    new "ああ、ちゃんと君に訪ねに行くよ。"

    # say L4450 mar
    old "I'm sorry, sir, but the mother needs to rest."
    new "申し訳ありませんが、お母さんは休む必要があるみたいです。"

    # say L4451 mar
    old "And visiting hours are almost over."
    new "そして面会時間も終わりに近づいています。"

    # say L4453 pla
    old "No problem, I'll leave right now."
    new "問題ない、今すぐ帰るよ。"

    # say L4456 oli
    old "Sure, and [pla], thanks again. For everything."
    new "もちろん、[pla]、またありがとう。全部のため。"

    # say L4468 bri
    old "Alright, [pla]! You are just on time!"
    new "大丈夫、[pla]！ちょうど間に合ってくれたね！"

    # say L4469 bri
    old "We have to unload the magic from the spell into the magic portal."
    new "魔法を呪文から魔法のポータルに移さないといけないの。"

    # say L4471 pla
    old "Oh right, okay, how do we do that?"
    new "ああ、そうか。どうするんだ？"

    # say L4472 bri
    old "Oh, that's the best part. Come with me."
    new "あ、それが一番楽しいところよ。ついてきて。"

    # say L4478 bri
    old "Alright, here we are, I've prepared the portal to receive the magic power you collected from Olivia."
    new "さあ、ここだよ。オリビアから集めた魔法の力を受けるためのポータルを準備したの。"

    # say L4479 bri
    old "Now, drop your pants."
    new "それじゃ、パンツを脱いで。"

    # say L4480 pla
    old "Oh! So that's how it's done..."
    new "オォ！そうやってやるのか…"

    # say L4481 bri
    old "Of course! Were you expecting anything else? Come on, let me help you."
    new "もちろん！他を期待してたの？さあ、手伝おう。"

    # say L4490 bri
    old "That's it, [pla]!"
    new "それだ、[pla]！"

    # say L4491 bri
    old "Just relax and let me do the work."
    new "リラックスして、あたしがやってあげるから。"

    # say L4492 bri
    old "You just need to focus on enjoying it."
    new "あなたはただ楽しむことに集中すればいいだけよ。"

    # say L4501 bri
    old "Wonderful, [pla]!"
    new "素晴らしい、[pla]！"

    # say L4502 bri
    old "This is the best first experience we could've hoped for."
    new "これが望んでいた最高の初めての体験だわ。"

    # say L4503 bri
    old "But now, don't forget that we need to keep looking for other subjects."
    new "でもね、他の被験者を見つけるのを忘れちゃダメよ。"

    # say L4504 pla
    old "Hmph, yeah sure."
    new "ふん、そうさ。"

    # say L4520 vee
    old "Hi, [pla], how are you doing?"
    new "こんにちは、[pla]、元気？"

    # say L4522 pla
    old "Hi, Mrs. Priya. I'm doing alright, and you?"
    new "こんにちは、プリヤさん。ぼくはまあまあの状態だよ、君は？"

    # say L4524 vee
    old "I'm alright, honey."
    new "大丈夫よ、ハニー。"

    # say L4525 vee
    old "A little busy, but that's normal."
    new "ちょっと忙しいけど、それはいつも通りよ。"

    # say L4529 vee
    old "And tell me, what brings you here today, honey?"
    new "それじゃ、今日は何の用事で来たの、ハニー？"

    # say L4530 pla
    old "Well, not much. I was just passing by and wanted to say hello."
    new "まあ、そんなに忙しくもないな。通りがかりだったから、ちょっと挨拶しに来たんだ。"

    # say L4532 vee
    old "Oh dear, aren't you sweet."
    new "あら、なんて甘いの。"

    # say L4534 vee
    old "It's good to see you."
    new "会えて嬉しいわ。"

    # say L4535 vee
    old "Be sure to come back soon, dear."
    new "またすぐ来てね、親愛なる。"

    # say L4537 vee
    old "With all the help you've given Olivia, you're always more than welcome."
    new "オリビアのためにたくさん手伝ってくれたから、いつでも歓迎よ。"

    # say L4538 pla
    old "Thanks a lot, ma'am."
    new "ありがとう、お姉さん。"

    # say L4541 vee
    old "See you, honey."
    new "またね、ハニー。"

    # say L4545 vee
    old "Hello, [pla]! It's so good to see you. How are you?"
    new "こんにちは、[pla]！会えて嬉しいわ。元気？"

    # say L4548 vee
    old "I'm okay, dear."
    new "元気よ、亲爱的。"

    # say L4550 vee
    old "I've been a little busy ever since the baby came, you know."
    new "赤ちゃんが生まれてからちょっと忙しくなっちゃって、あなたも知ってるでしょ。"

    # say L4552 vee
    old "But he's such a bundle of joy that he's made everything so cheerful around here!"
    new "でもね、彼は本当に元気いっぱいで、ここが明るくなったわ！"

    # say L4554 pla
    old "That's very good to hear, Mrs. Priya."
    new "それはとても嬉しいね、プリヤさん。"

    # say L4555 vee
    old "Tell me, honey, what brings you here today?"
    new "ねぇ、 honey、今日ここに来たの何のために？"

    # say L4557 pla
    old "Oh, I just wanted to say hello."
    new "ああ、ただ挨拶したかっただけだよ。"

    # say L4559 pla
    old "See how you're doing and stuff."
    new "君の状態見に来たんだ、そんな感じ。"

    # say L4561 vee
    old "Aren't you sweet?"
    new "あなたって優しいのね。"

    # say L4563 vee
    old "Well, as you can see, we're doing more than alright."
    new "まあ、見ての通り、全然問題ないわ。"

    # say L4565 vee
    old "It's a shame the baby's sleeping now, otherwise you could see him."
    new "ベイビーが寝ちゃってるの残念ね、見せられたのに。"

    # say L4567 vee
    old "But maybe some other time."
    new "でもまた別の時間にね。"

    # say L4570 pla
    old "Well, it was good seeing you, Mrs. Priya. I'll be sure to come back later."
    new "じゃあ、プリヤさん、また後で来ますね。会えて良かったです。"

    # say L4572 vee
    old "Sure, dear, you're welcome anytime."
    new "もちろん、いつでもwelcome、亲爱的。"

    # say L4574 vee
    old "Nice seeing you."
    new "会えてよかったわ。"

    # say L4576 pla
    old "Thanks, ma'am."
    new "ありがとう、お母さん。"


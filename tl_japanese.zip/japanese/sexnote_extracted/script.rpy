# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/System/script.rpy
translate japanese strings:

    # say L562 ladGuide
    old "Go to Sleep."
    new "寝よう。"

    # say L563 linGuide
    old "Go to sleep."
    new "寝よう。"

    # say L565 belGuide
    old "Go to school in the morning."
    new "朝は学校に行け"

    # say L566 barGuide
    old "Keep progressing with Brixxida."
    new "ブリクシダと進めていくんだよ。"

    # say L568 bilGuide
    old "Keep progressing with other characters."
    new "他のキャラクターとも関係を深めていくんだ"

    # say L584 mom2Rel
    old "step mom"
    new "義母"

    # say L700 sisGuide
    old "Meet her in the hallway."
    new "廊下で会う"

    # say L701 johGuide
    old "Keep progressing with Hinn."
    new "ヒンと進めていくんだ。"

    # say L703 lydGuide
    old "Go to her house."
    new "彼女の家に行く"


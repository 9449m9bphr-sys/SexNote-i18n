# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Mechanics/Interface.rpy
translate japanese strings:

    # say L7 pla
    old "I shouldn't, is weekend."
    new "週末だから、やめておこう。"

    # say L412 bri
    old "This is not what it looks like..."
    new "これは見かけ倒しなのよ…"

    # say L413 bri
    old "This is not a real bug... However it looks like you are using a really old file save..."
    new "これは実際のバグじゃないけど、古いままでセーブデータを使ってるみたいね…"

    # say L414 bri
    old "That's not bad, however as you can see this game has really improved since last months..."
    new "それは悪くないけど、このゲームは先月からかなり進化してるのよね…"

    # say L415 bri
    old "And this version is only compatible with the two last updates 0.14.0 and 0.14.5."
    new "このバージョンは最新の2つのアップデート 0.14.0 と 0.14.5 とのみ互換性があります。"

    # say L416 bri
    old "So, if you use an old save from old versions or an old save bugged it would probably cause bugs in this version..."
    new "古いバージョンのセーブデータやバグってるセーブデータを使っちゃうと、このバージョンでバグが起こる可能性が高いのよね…"

    # say L417 bri
    old "And we don't want to ruin your experience... So, to avoid that, we suggest you try the 'Skip to new content' option."
    new "そしてあなたの体験を台無しにしたくないから……だから、その問題を避けるために、『新しいコンテンツへスキップ』オプションを使ってみてね。"

    # say L418 bri
    old "So you can play a full version of the game with only the new content in this update."
    new "新しく追加されたコンテンツだけを楽しめる完全版のゲームになりますね。"

    # say L419 bri
    old "You just have to play start, name your character and then click the 'Skip to new content' option!"
    new "まずはスタートして、キャラクターの名前を決めてから「新しいコンテンツへスキップ」を選択すればいいだけ！"

    # say L420 bri
    old "And if you want to play an old game that you haven't played before, you can contact the developers on {a=https://www.patreon.com/sexnote}{b}Patreon{/b}{/a}"
    new "そして、プレイしたことのない古いゲームをプレイしたい場合は、{a=https://www.patreon.com/sexnote}{b}Patreon{/b}{/a}で開発者に連絡できます。"

    # say L421 bri
    old "They can give you all the support you need."
    new "彼らがあなたが必要とするサポートを全部提供してくれるわ。"

    # say L422 bri
    old "All right, that's it."
    new "じゃあ、これで終わりね。"

    # say L423 bri
    old "See you soon, here on Sexnote."
    new "またね、Sexnoteで会おう。"

    # say L713 pla
    old "I shouldn't go there right now."
    new "今は行かない方がいいな。"

    # say L731 pla
    old "It's too late... I shouldn't go there right now."
    new "もう遅い……今行っちゃダメだよ。"

    # say L738 pla
    old "I'm already very tired, I should rest and continue tomorrow..."
    new "もう疲れてるし、休んで明日続けるべきだな…"


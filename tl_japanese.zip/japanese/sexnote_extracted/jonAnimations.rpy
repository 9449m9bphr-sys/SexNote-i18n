# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/jonAnimations.rpy
translate japanese strings:

    # say L6 jon
    old "It barely fits in my mouth... My god! You really have something big here."
    new "口に入りきらない……神様！本当に大きいのね。"

    # say L10 jon
    old "It's a massive cock, just like my husband's dick."
    new "それは大きなちんこですね、私の旦那さんのそれと同じくらい大きいわ。"

    # say L11 pla
    old "(Wow! I can see she has some good experience at this...)"
    new "すごいな、経験豊富そうだな…"

    # say L15 jon
    old "It's so big and Mmmm... So good..."
    new "こんなに大きく、そして Mmmm... いい感じ..."

    # say L39 pla
    old "Mrs. Jones I'm cum-"
    new "ジョーンズ夫人、俺が出るぞ…"

    # say L40 jon
    old "Oh Yes! Give me your sacred cum..."
    new "ああん、私の聖なる精液をちょうだい…"

    # say L42 jon
    old "Ahhhhhhhhh!"
    new "アああああああああああ！"

    # say L48 jon
    old "Oh my God, I really need to feel your divine presense inside me..."
    new "ああ、本当にあなたの神々しい存在を感じたいの..."

    # say L50 jon
    old "Come to my bedroom..."
    new "私の寝室へ来てちょうだい..."

    # say L64 pla
    old "I- I'm doing it right?"
    new "俺、ちゃんとやってる？"

    # say L65 jon
    old "My pussy is speaking for me... Just feel how wet it's for you."
    new "私のオマ○コが代わりに話してるの… ただ感じるだけで、あなたのためにどれだけ濡れてるか。"

    # say L69 jon
    old "I haven't felt like this in years !!"
    new "こんなに感じたのは何年も前以来です！"

    # say L70 jon
    old "Being with a young and vigorous man like you, has no comparison."
    new "あなたのような若い力強い男性と過ごすのは、比べものにならないほど素晴らしいです。"

    # say L74 pla
    old "Oh god! Oh God!"
    new "ああ神！ああ神！"

    # say L75 jon
    old "You'll make me come so badly!"
    new "あなたがそうすると、私、絶対にイッちゃう！"

    # say L98 pla
    old "I- I'm cumming-"
    new "俺、出るぞ…"

    # say L99 jon
    old "Ohhh mee too!!!"
    new "ああ、私もだよっ！"

    # say L103 jon
    old "Wow, that was great... We should, get dressed before Billie arrives."
    new "Wow、それ良かった… ビリーが来る前に着替えるべきですね。"

    # say L116 jon
    old "Oh yeah! Fuck my mouth you little boy!"
    new "オーやっぱり！小さな男の子、私の口を犯してちょうだい！"

    # say L117 pla
    old "Oh God!"
    new "おおっ！"

    # say L121 jon
    old "It's so good to have it inside my mouth... I can feel your veins pumping..."
    new "口の中に入ってる感じがいいわ… 脈動きが伝わってくるの…"

    # say L122 pla
    old "Ahhhhhhh! You're so good..."
    new "アHHHHH！君は本当にいい…"

    # say L126 jon
    old "Yes! Faster! Faster I want you to cum on my mouth!"
    new "はい！もっと速く！もっと速くして、私の口でイかせてください！"

    # say L150 jon
    old "Ohh... I can feel your body tensing!"
    new "ああっ…体が緊張してきているのを感じる！"

    # say L151 jon
    old "Fill my mouth with your cum!"
    new "私の口に精液をいっぱい出して！"

    # say L162 jon
    old "I'm so wet... But today I want you to fuck my ass..."
    new "私はもう濡れているの… でも今日だけは私のアナルを犯してほしいの…"

    # say L163 pla
    old "... W- what?"
    new "……えっ、何？"

    # say L164 jon
    old "I just want to remember the good times with my husband ..."
    new "私は夫との良い思い出を残したいだけなの…"

    # say L182 jon
    old "Oh God, it's so big it hurts!"
    new "ああ、神様、大きすぎて痛いです！"

    # say L183 pla
    old "Do you want me to stop?"
    new "止める？"

    # say L184 jon
    old "Ohh no, please don't stop, I want you to fuck my ass just like my husband used to do..."
    new "ああ、お願い、止めてくれないで、夫みたいに私のアナルを犯してほしいの..."

    # say L187 jon
    old "Faster! I want you to fuck me harder!"
    new "もっと速く！もっと強く突いてほしい！"

    # say L193 jon
    old "Oh yes! Just like that! Don't stop, don't stop!!"
    new "ああ、そう！そのまま続けて！やめてくれないで！"

    # say L194 jon
    old "It hurts, but it feels so good!"
    new "痛いけど、感じてるの！"

    # say L217 jon
    old "Oh yeah, fill my ass with your cum!"
    new "ああ、そうよ、私のアナルに精液を注ぎ込んで！"

    # say L220 jon
    old "Oh God, you are definitely better than my husband..."
    new "ああ、神様、あなたは本当に私の旦那より上手だわ…"

    # say L234 bil
    old "Wow, it's bigger than I remember..."
    new "Wow、思った以上に大きいのね…"

    # say L235 jon
    old "Ahhhh! So nice."
    new "アッ！気持ちいい。"

    # say L236 gra
    old "My goddess!"
    new "私の神様！"

    # say L240 jon
    old "Let me give you a hand with this..."
    new "私が手伝うから安心しなさい…"

    # say L243 bil
    old "Oh, it looks so hot!"
    new "あら、すごく熱そうね！"

    # say L247 bil
    old "Yeah! get that cock ready to fuck us!"
    new "はい！そのちんこを準備して、私たちを犯すんだ！"

    # say L248 jon
    old "Oh, Billie, please watch your mouth..."
    new "ビルリー、口のきき方気をつけてください..."

    # say L271 jon
    old "Alright, I guess it's time to start, sister Grace is waiting hun!"
    new "よし、始めようか、グレース姉さんが待ってるわよ！"

    # say L282 gra
    old "Oh my God! It feels amazing inside of me!"
    new "神様！中で感じてます！"

    # say L283 bil
    old "I have a great view of your pussy being fucked sister Grace..."
    new "姉グレースのオマンコが犯されてるの、見えてめちゃくちゃいいよ..."

    # say L285 jon
    old "Billie!"
    new "ビリー！"

    # say L289 gra
    old "My body and soul really needed this ritual."
    new "私の体も心も、この儀式が必要だったの。"

    # say L290 gra
    old "Ahhh!"
    new "アッ！"

    # say L291 jon
    old "More... More..."
    new "もっと... もっと..."

    # say L292 bil
    old "If I had known about these rituals I would have become a nun too!"
    new "もし私がこんな儀式を知っていたら、修道女にもなっていたわね！"

    # say L296 gra
    old "Oh! My dear... You'll make me cum with so much g- grace..."
    new "あらっ、私の親愛なる... こんなに優しく扱われたら、イッちゃいそう..."

    # say L297 gra
    old "Ahhh! I'm about t-"
    new "アッ！出ちゃうっ！"

    # say L298 bil
    old "Fuck! This is so damn good!"
    new "くそっ！これ、めちゃくちゃいいわ！"

    # say L322 jon
    old "So good, my God!"
    new "なんて良いの、神様！"

    # say L323 pla
    old "Fuck! I'm cuming!"
    new "俺もだ！出るぞ！"

    # say L324 gra
    old "Me too... Ahhh!"
    new "私も… アーッ！"

    # say L333 bil
    old "Wow, that was intense..."
    new "おわ、それ強烈だったね…"

    # say L334 gra
    old "My God! Thanks for this..."
    new "おおっ、感謝します…"

    # say L335 jon
    old "[pla], you're my holy savior...  Take me!"
    new "[pla]、あなたが私の救世主です…… 私を取ってください！"

    # say L336 pla
    old "(This is h- heaven... Shit!)"
    new "これは天国だ… くそ！"

    # say L341 bil
    old "Do you like what you see?"
    new "見ている景色が好きですか？"

    # say L343 jon
    old "Come on hun, it's time to give me some blessed cock."
    new "さあ Darling、祝福されたチ○ポを私にちょうだい。"

    # say L344 gra
    old "Oh yeah, guide Mrs. Jones, just like you did with me."
    new "ああ、そうね、ジョーンズ夫人を導いてあげて、私にしてくれたみたいに。"

    # say L359 bil
    old "Do you feel 'God's presence' right now?"
    new "今、神様の存在を感じている？"

    # say L360 jon
    old "Oh yes, I feel it... Very deep inside."
    new "はい、感じています… 奥深くで。"

    # say L361 gra
    old "I feel too so much of your divine presence, my heavenly God!"
    new "私はあなたの神々しい存在を感じています、私の天の神様！"

    # say L366 jon
    old "My God! It feels amazing!"
    new "神様！　感じがすごいです！"

    # say L367 bil
    old "Oh yes, fuck my granny, just like you fucked me!"
    new "ああ、そう、私の婆ちゃんを犯して、私を犯したときみたいに！"

    # say L369 gra
    old "[pla], my spiritual guide, you're the best..."
    new "[pla]、私の霊的ガイド、あなたが最高だわ..."

    # say L373 bil
    old "This is the best religion ever!"
    new "これが一番の宗教よ！"

    # say L374 jon
    old "Oh, you have no idea!"
    new "あなたたちは全然わかっていないわ！"

    # say L375 jon
    old "I'm touching God right now... This is so good..."
    new "私は今神様に触れてるの… これ、すごくいいわ…"

    # say L399 pla
    old "I- I'm cuming again..."
    new "俺、またイクよ…"

    # say L400 jon
    old "Ahhhhhh!"
    new "ア─────ッ！"

    # say L401 bil
    old "Yeesss!"
    new "はいっ！"

    # say L402 gra
    old "We need your cum, right now! We to purify ourselves."
    new "私たちの身体を浄化するために、あなたの精液が必要なの、今すぐ！"

    # say L411 bil
    old "Oh, oh, it's my turn! It's my turn!"
    new "あ、あ、私の番だよ！私の番だよ！"

    # say L412 jon
    old "I'm sorry, my dear, But you must stay a virgin until marriage."
    new "ごめんなさい、私の親愛なる子、でも結婚するまで処女でいなきゃならないのよ。"

    # say L413 bil
    old "W- what the fuck!? But you already had sex with him!"
    new "ワッ、何言ってんの！？でも君はもう彼とSEXしたんでしょ！"

    # say L414 jon
    old "Yes, my dear, I'm a widow..."
    new "はい、私の愛する子、私は未亡人です…"

    # say L415 gra
    old "Don't worry Mrs. Jones I have an idea..."
    new "心配しなくていいですよ、ジョーンズ夫人。私に考えがありますから…"

    # say L429 pla
    old "Wow! it feels great."
    new "Wow！感じがいいなあ。"

    # say L430 bil
    old "Ohhh yeahh, Fuck! This is good!... Thanks sister."
    new "オーッ、イイッ、ファック！これ、最高だよ… 姉さん、ありがとう。"

    # say L431 gra
    old "Enjoy it honey..."
    new "楽しんでね、ハニー…"

    # say L432 gra
    old "You are welcome, we all can get closer to God with [pla]'s help."
    new "どういたしまして、[pla]のお力で私たちは神様に近づけるわ。"

    # say L435 bil
    old "Faster, I need it fater!"
    new "早くして、もっと欲しいの！"

    # say L438 jon
    old "We need you to do more..."
    new "私たちはあなたにもっとしてほしいの…"

    # say L439 bil
    old "The three of us need to get enough of you... Please, keep going!"
    new "私たち三人、君が必要だ… お願い、続けて！"

    # say L440 gra
    old "Don't stop!"
    new "止めてほしくない！"

    # say L444 bil
    old "Yeah, yeah, yeah... Just like this!"
    new "うん、うん、うん… その調子で続けて！"

    # say L445 jon
    old "Oh God! Woww!"
    new "ああん！すごいわ！"

    # say L446 gra
    old "Ahhh! Your cock is so damn good!"
    new "アッ！あなたのペニス、本当に素晴らしい！"

    # say L447 gra
    old "I mean... So divine and big... Ahhh!"
    new "あたし…… そんなに神々しくて大きいの…… アッ！"

    # say L475 gra
    old "I feel your sacred milk..."
    new "あなたの神聖なミルクを感じてる…"

    # say L476 bil
    old "Hmm, big load! Ahhh"
    new "大きな量だわ！アッ"

    # say L477 jon
    old "This is more than enough for the three of us... But we want more..."
    new "これだけあれば三人分は十分だけど… でももっと欲しくなっちゃうの"

    # say L498 bil
    old "Your cock is so big and good!"
    new "あなたのペニス、大きくていいのね…"

    # say L499 gra
    old "Yeah... This is what my soul was asking for..."
    new "うん… これが私の魂が求めていたものよ…"

    # say L505 gra
    old "Uhhh... It's a divine cock... So good..."
    new "うーん… 神々しいちんこ… すごくいい…"

    # say L506 bil
    old "I wanna taste you more and more!"
    new "もっと君の味を味わいたいの！"

    # say L510 bil
    old "Fuck her... She needs more [pla], she wants more of your-"
    new "彼女を犯せ……もっと[pla]が必要だ、彼女は君の聖なる巨根をもっと欲しがってる……"

    # say L511 gra
    old "Of your massive and saint cock..."
    new "あなたの巨大な聖なるチ○ポを…"

    # say L512 bil
    old "Fuck, I need it too.."
    new "ああ、私も欲しい…"

    # say L535 bil
    old "We want your cum in our mouths..."
    new "私たちの口にあなたの精液をください..."

    # say L536 jon
    old "Oh yes hun, give it to us!"
    new "あह、 Darling、私たちにちょうだいな！"


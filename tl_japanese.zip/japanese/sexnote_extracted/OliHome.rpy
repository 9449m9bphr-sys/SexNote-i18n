# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/OliHome.rpy
translate japanese strings:

    # menu L12 
    old "Talk to her."
    new "彼女に話しかける"

    # say L89 oli
    old "Hmm, are we starting or what?"
    new "何 startersの？勉強でも始めるの？"

    # say L90 pla
    old "Uhh... E- excuse me?"
    new "うっ…あの、すみません？"

    # say L92 oli
    old "I'm asking you if we're going to study or something."
    new "勉強するの？何かするの？"

    # say L94 oli
    old "Because you just stayed there staring at me like a creep."
    new "だってあなたはただそこに立って、変な感じで私を見てたから。"

    # say L96 pla
    old "S- sorry, I- I didn't notice I was doing it."
    new "す、すみません、気づいてなかった。"

    # say L97 pla
    old "I was just passing by and wanted to say hello."
    new "ただ通りかかっただけだよ、挨拶したかっただけさ。"

    # say L99 oli
    old "That's it? Alright."
    new "そうなのか。わかった。"

    # say L101 oli
    old "But make sure to come back soon. We’ve got a lot to study."
    new "でもまたすぐ来てね。たくさん勉強するから。"

    # say L102 pla
    old "Sure, don't worry about it. I'll see you soon."
    new "大丈夫、心配しないで。またすぐに会うから。"

    # say L112 oli
    old "Hey, what's up? Did you come to study with me?"
    new "hey、何してるの？一緒に勉強しに来たの？"

    # say L114 pla
    old "Hey, oh no, I can't right now, I just wanted to say hi."
    new "Hey、今ちょっと無理だ、ただ挨拶したかっただけなんだ。"

    # say L116 oli
    old "Hmm, alright, but make sure you come back soon."
    new "うーん、そうね。でもまたすぐ戻ってね。"

    # say L117 oli
    old "So we can hit the books together."
    new "そうしたら一緒に勉強できるよね。"

    # say L119 pla
    old "Sure thing."
    new "分かった、すぐ戻るから。"

    # say L165 vee
    old "Excuse me [pla], do you need anything?"
    new "失礼 [pla]、何か必要なものはある？"

    # say L167 pla
    old "Uhmm, no, sorry ma'am, I- uh- I was just passing by."
    new "うーん、いや、すみませんお姉さん、ただ通りがかっただけだ。"

    # say L169 vee
    old "I see... Well, I guess I'll see you around then."
    new "そうですね… じゃあ、またね。"

    # say L180 vee
    old "Hello [pla], how are you today?"
    new "こんにちは[pla]、今日怎么样？"

    # say L182 pla
    old "Hello Mrs. Priya, I'm fine, how about you?"
    new "こんにちはプリヤさん、元気です、あなたはいかがですか？"

    # say L184 vee
    old "I'm doing alright."
    new "元気だよ。"

    # say L185 vee
    old "Tell me, do you need anything?"
    new "何か必要なの？"

    # say L186 pla
    old "Oh, not really. I just wanted to say hello."
    new "ああ、特に何も要らないけど、ただ挨拶したかっただけさ。"

    # say L188 vee
    old "I see, well, I guess I'll see you around then."
    new "そうね、じゃあまたね。"

    # say L189 pla
    old "Sure thing ma'am, see you."
    new "分かったよ、またね。"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/MiaStory.rpy
translate japanese strings:

    # say L11 mia
    old "Hmph, I see you're late again [pla], you never learn, do you?"
    new "ふん、また遅刻ね [pla]、全然学ばないのよね。"

    # say L12 mia
    old "Although that's not really a surprise, you're always doing this kinda stuff."
    new "驚きじゃないわ、いつもこんなことしてるもんね。"

    # say L13 pla
    old "Uhh... Good morning, Miss Mia."
    new "うーん… おはよう、ミアさん。"

    # say L14 mia
    old "I'm sorry? Don't think that you can be a wise ass with me young man, and get in the classroom already! We're about to start."
    new "申し訳ありません？ 若いの、私に対して生意気な態度を取っても無駄よ。さっさと教室に入りなさい。授業が始まるところだから。"

    # say L15 mia
    old "Don't you see there are some students that DO care about studying?"
    new "あなたは勉強に真剣に取り組んでいる生徒たちがいることに気づいていないの？"

    # say L23 pla
    old "(What the hell got into her?)"
    new "（何が彼女をそんなに怒らせたんだ？）"

    # say L24 pla
    old "(Gosh, this is gonna be a looong day)"
    new "（ああ、今日が長いぞ）"

    # say L29 mia
    old "As you can see, establishing a single reason for the start of world war I is nearly impossible."
    new "あなたがご覧のように、第一次世界大戦の始まりを一つの理由で説明するのはほとんど不可能です。"

    # say L30 mia
    old "Certainly the detonating event was the killing of Archduke Franz Ferdinand."
    new "確かに、第一次世界大戦の引き金となったのはフランツ・フェルディナント大公の暗殺です。"

    # say L31 mia
    old "But as I explained already, this was merely a consequence of the authoritarian rule..."
    new "でも既に説明した通り、これは単に独裁的な統治の結果に過ぎないのです。"

    # say L34 pla
    old "(Geez this is boring... What do I need to know any of this stuff for?)"
    new "(うげぇこれめっちゃ退屈だな... これ知る必要なんてあるのか？)"

    # say L54 pla
    old "(Isn't she wearing underwear?)"
    new "（彼女、下着穿いてるのか？）"

    # say L62 mia
    old "As I was saying, what's most important to remember when examining the causes of the war..."
    new "私が言っていたのは、戦争の原因を検討する際に最も重要なことは..."

    # say L63 mia
    old "It's that the political climate of Europe was tremendously charged..."
    new "それは、ヨーロッパの政治的雰囲気が非常に高揚していたということです…"

    # say L67 pla
    old "{i}Hey Mike, dude! Did you see that?! {/i}"
    new "{i}マイク、おい！それ見たか？！{/i}"

    # say L68 mik
    old "{i}U-uh? Are you talking to me? Did Ms. Mia ask a question?{/i}"
    new "{i}うーん？君、俺のこと呼んでるの？ミア先生が何か質問したの？{/i}"

    # say L69 pla
    old "{i}What? No dude! You didn't see that?{/i}"
    new "{i}何？違うよ！見なかったの？{/i}"

    # say L70 mik
    old "{i}See what?{/i}"
    new "{i}何を見ろって？{/i}"

    # say L71 pla
    old "{i}Nevermind...{/i}"
    new "{i}気にしないで...{/i}"

    # say L72 pla
    old "(Was I the only one that saw that?)"
    new "俺だけがそれを見たのか？"

    # say L73 pla
    old "(I'm sure I saw she wasn't wearing any panties.)"
    new "（俺は確実に彼女がパンツを穿いていないのを見たよ。）"

    # say L75 mia
    old "Ok guys, that's today's class, remember I'm going to need you to write a three-page report on the causes of world war I for the next class."
    new "皆さん、今日の授業はこれで終わりです。次回の授業までに第一次世界大戦の原因について3ページのレポートを書いてきてくださいね。"

    # say L76 mia
    old "And [pla], remember to be on time for next time!"
    new "そして[pla]、次回は遅れないようにしてくださいね！"

    # say L98 mia
    old "Hmm, late again! You just never learn, do you [pla]?"
    new "また遅刻か！全然学ばないのね、[pla]？"

    # say L99 pla
    old "Hi Miss Mia, were you waiting for me? I mean, I'm just on time."
    new "ミアさん、待っててくれたんですか？まあ、私は punctual だって思ってたけど。"

    # say L100 mia
    old "Just on time to interrupt the class by entering late!"
    new "遅刻して授業を中断するタイミングがちょうどいいわね！"

    # say L101 mia
    old "I'm telling you, you better straighten up!"
    new "もっと真面目にしなさいよ！"

    # say L110 dir
    old "Oh! Mia, good morning."
    new "おっ！ミア、おはよう。"

    # say L111 mia
    old "Good Morning ma'am, how are you today?"
    new "おはようございます、お元気ですか？"

    # say L112 dir
    old "I'm pretty good, thank you, just checking up on things before I go to my office to start the day."
    new "俺は元気だ、ありがとう。ただ、出勤前にちょっと確認していただけさ。"

    # say L113 dir
    old "By the way, don't you think it's about time for you to start with your class?"
    new "それにしても、そろそろ授業を始める時間じゃないか？"

    # say L115 mia
    old "You're right, sorry ma'am, I was just waiting for this student, he needs a little extra attention."
    new "はい、その通りです、申し訳ありません。ただ、この生徒が少し特別な配慮が必要で、待っていました。"

    # say L117 mia
    old "This is [pla]."
    new "これは [pla] です。"

    # say L118 pla
    old "Good morning ma'am.."
    new "おはようございます、先生。"

    # say L120 dir
    old "Ah, this is the student you told me about."
    new "ああ、これが君が話していた生徒ですね。"

    # say L122 dir
    old "Well [pla], given what Mia has told me about you, I don't think it's very good that you're arriving this late to class."
    new "WELL [pla]、ミアから君のことを聞いていたけど、授業にこんなに遅刻するのはよろしくないな。"

    # say L123 pla
    old "You're right ma'am, I'm sorry."
    new "そうだな、謝るよ。"

    # say L124 dir
    old "Trust me, you don't want to see your classmates move on and you being stuck here."
    new "信じろ、クラスメイトが先に進んで、お前だけ取り残されるのは欲しくないぞ。"

    # say L125 dir
    old "So, make sure you buckle down and start studying seriously."
    new "だから、本気で勉強に取り組めよ。"

    # say L126 dir
    old "Otherwise you'll have to come here and take extra classes during your Holidays."
    new "それじゃ、休暇中に追加授業を受けに来ることになるぞ。"

    # say L127 pla
    old "You're right, ma'am."
    new "分かった、マ'amの言う通りだ。"

    # say L128 dir
    old "Just keep it in mind. Mia already has an eye on you, be thankful that your teacher cares so much."
    new "分かっておけよ。ミアはもう君のこと見張ってるんだ、教師がこれだけ心配してくれてるのに感謝しろ。"

    # say L129 pla
    old "Hmm... Yes ma'am."
    new "うーん… はい、分かった。"

    # say L130 dir
    old "Good boy."
    new "良い男だね。"

    # say L131 dir
    old "Now Mia, I think it's time for you to start your class."
    new "ミア、お前に授業を始める時間が来たな。"

    # say L132 mia
    old "Yes ma'am, I'm about to."
    new "はい、すぐ始めますね。"

    # say L133 mia
    old "Have a very good day ma'am."
    new "良い一日をお過ごしください、先生。"

    # say L134 dir
    old "You too dear."
    new "君もね。"

    # say L142 mia
    old "You see? That's your second warning about your studies. You better listen!"
    new "見ましたか？これはあなたの勉強についての二度目の警告よ。ちゃんと耳を借した方がいいわ！"

    # say L143 mia
    old "And come in!"
    new "中に入って！"

    # say L149 mia
    old "Ok guys, we'll continue with the world war one chapter."
    new "皆さん、第一次世界大戦の章を続けましょう。"

    # say L150 mia
    old "This time we'll talk about Africa and the Ottoman Empire during this period of time."
    new "今回は、この時代におけるアフリカとオスマン帝国について話しましょう。"

    # say L156 mia
    old "Is it me or is it really hot today? I think I need to get a bit more comfortable."
    new "今日は暑いですよね、ちょっと楽にしないと。"

    # say L160 pla
    old "(What the fuck?! She's not wearing a bra!)"
    new "(おい、マジか！ブラジャーなんてつけてないじゃねえか！)"

    # say L161 pla
    old "(What's happening with her?)"
    new "（彼女、何があったんだ？）"

    # say L169 mia
    old "Phew, too much better, ok, let's continue with the subject..."
    new "ふう、ずいぶんよくなったわね、では続きを始めるかしら…"

    # say L171 mik
    old "{i}Dude! Are you seeing what I'm seeing?{/i}"
    new "{i}おい！お前も見てるか？{/i}"

    # say L173 pla
    old "{i}Yeah, what's up with that?{/i}"
    new "{i}そうだな、それって何なんだ？{/i}"

    # say L174 mik
    old "{i}I don't know, but this is totally rad!{/i}"
    new "{i}知らねえけど、これすげえじゃん！{/i}"

    # say L176 mia
    old "Is there something you want to share with the class? Or can I continue with the class."
    new "何かクラスに伝えることがあったの？それとも授業を続けさせていいの？"

    # say L177 mik
    old "U- uh, sorry Miss Mia."
    new "うーと、すみません、ミア先生。"

    # say L178 pla
    old "Yeah, sorry."
    new "うん、すみません。"

    # say L179 mia
    old "Honestly, I would hope that you of all people should be the one paying the most attention [pla]."
    new "正直に言うと、あなたが一番注意を払うべき人だと思っていたのに [pla]。"

    # say L180 mia
    old "Let me remind you that your grades have been terrible."
    new "成績が最悪だってことを思い出させてあげるわ。"

    # say L181 mia
    old "I imagine that paper you had to write must be excellent, right?"
    new "あの論文、きっと素晴らしいものになったでしょう？"

    # say L182 pla
    old "I said I was sorry..."
    new "ごめんなって言ったろ..."

    # say L183 mia
    old "Hmph, you better be."
    new "ふん、そうよね。"

    # say L184 mia
    old "I'm sorry class, let's just continue, I know some of you actually want to learn."
    new "すみません、クラスのみなさん、続きましょう。みなさんのなかに、本当に学びたいと思っている人もいるから。"

    # say L191 mik
    old "Dude! [pla], did you notice?!"
    new "おい！[pla]、気づいたか？！"

    # say L192 mik
    old "You could see her nipples! It was the best class ever!"
    new "お前ら、彼女の乳首見えたぞ！史上最も興奮した授業だったな！"

    # say L193 pla
    old "Yeah, that was weird."
    new "そうだったな。"

    # say L202 mik
    old "Hey Belle, did you see that?"
    new "ベール、見たか？"

    # say L203 mik
    old "Now we have a new motivation to come to class!"
    new "今度は授業に来る動機ができまったな！"

    # say L205 bel
    old "Yes, I noticed that Miss Mia wasn't wearing a bra... I assume that's what you mean?"
    new "うん、ミア先生がブラジャーをつけてなかったことに気づいたわ…それのことよね？"

    # say L206 pla
    old "That was weird, and it's not the first time, last class I also noticed something."
    new "それは変だったな、それに先週の授業でも何か気付いたんだ。"

    # say L207 bel
    old "Yeah, I also saw that."
    new "うん、私も気づいたわ。"

    # say L210 mik
    old "What? Last class?"
    new "何？前回の授業でも？"

    # say L211 mik
    old "I didn't see anything."
    new "何も見てないな。"

    # say L212 mik
    old "What was it? What was it?"
    new "何だった？何だった？"

    # say L215 bel
    old "There's something odd about Ms. Mia's behavior lately."
    new "ミア先生の最近の態度、何か変だと思わない？"

    # say L216 pla
    old "I know what you mean."
    new "俺もそう思うよ。"

    # say L217 pla
    old "But I guess that's none of our concern."
    new "でも、それって俺たちには関係ないか。"

    # say L220 bel
    old "By the way, I'm going over to Billie's to hang out."
    new "それにしても、ビリーのところに行くわよ。遊ぶためにね。"

    # say L221 bel
    old "You guys wanna come?"
    new "来ない？"

    # say L224 pla
    old "I would love to."
    new "行きたいくせに、次のプロジェクトのことでミアさんに文句言われそうだな。"

    # say L225 pla
    old "But I have to get working on the next project, otherwise Ms. Mia will never get off my back."
    new "でも次のお仕事に取りかからないと、ミアさんが絶対に離れないよ。"

    # say L226 bel
    old "She really doesn't like you, does she?"
    new "彼女は君のこと全然好きじゃないんだね。"

    # say L227 pla
    old "Ha, that's saying little."
    new "ハ、それだけじゃないぜ。"

    # say L229 pla
    old "Oh, damn, I just realized, I forgot my notes in the classroom."
    new "ああ、しまった、ノートを教室に忘れてきたことに気づいた。"

    # say L230 pla
    old "I have to go back and grab them. See you later guys!"
    new "俺が取りに戻らなきゃ。また後でな、みんな！"

    # say L239 mik
    old "So, where are we going Belle?"
    new "じゃあ、どこ行くの、ベール？"

    # say L251 mia
    old "Yeah, yeah, I did what you asked!! Okay?!"
    new "はいはい、頼まれたことはちゃんとやったわ！！ 分かったでしょ？"

    # say L252 mia
    old "Yeah, but I won't be doing that shit again!"
    new "でも、あんなこと二度としないわ！"

    # say L253 mia
    old "This was so embarrassing. You went way overboard with this!"
    new "これは本当に恥ずかしかったわ。あなたは全然やりすぎよ！"

    # say L254 mia
    old "And I'm telling you now, I'm not doing anything more in public!"
    new "そして今あなたに言っているのだけど、これ以上は公共の場で何もしないわ！"

    # say L259 mia
    old "What...?!"
    new "何…？！"

    # say L260 mia
    old "Ugh, great, just what I needed!"
    new "うっ、本当にこれだけは勘弁して欲しかったの！"

    # say L262 pla
    old "Um, sorry, I just came back to pick up my notes, I'm leaving now."
    new "あ、すみません、ただノートを取りに来たんです、今から帰ります。"

    # say L269 mia
    old "Uh? What? Him?"
    new "え？何？彼？"

    # say L270 mia
    old "He's nobody, just another one of my stupid students."
    new "彼は誰でもないわ、ただの馬鹿な生徒の一人よ。"

    # say L271 mia
    old "Nah, he just came in, he heard nothing."
    new "nah、彼はただ今入っただけです、何も聞いていませんよ。"

    # say L272 mia
    old "What does his name have to do with anything?"
    new "名前がどうして関係があるんですか。"

    # say L273 mia
    old "Yeah, I don't like him, so what?"
    new "そう、私は彼のこと好きじゃないって、それがどうしたの？"

    # say L274 mia
    old "What? Listen, that doesn't have anything to do with our conversation."
    new "何？　それと私たちの会話とは関係ないわよ。"

    # say L275 mia
    old "The point is that I'm not doing anything else, so you better stop harassing me, you got that?!"
    new "要点は私が他に何もしていないってことだから、あなたも私をいじめるのをやめてよね、分かったわね？！"

    # say L279 mia
    old "Ughh..."
    new "うっ..."

    # say L284 pla
    old "Hmm, I guess Mike and Belle already left."
    new "うーん、マイクとベールはもう帰ったみたいだな。"

    # say L285 pla
    old "(But what the hell was that phone call about? That was so weird.)"
    new "でもさ、そのスマホの話は何だったんだ？めちゃくちゃ変だったよ。"

    # say L286 pla
    old "(Although I guess it's not my business.)"
    new "（まあ、それは俺の知ったことじゃないけど。）"

    # say L301 mia
    old "All right guys, today we'll talk about American development during the period from 1925 to 1938, the period between the two world wars..."
    new "皆さん、今日は1925年から1938年のアメリカの発展について話し合いましょう。これは第一次世界大戦と第二次世界大戦の間の時期です…"

    # say L302 pla
    old "(God this is so fucking boring.)"
    new "（くそ、これほど退屈なことはないよ。）"

    # say L304 pla
    old "(What?)"
    new "（何？）"

    # say L305 pla
    old "(Is she looking at me?)"
    new "（彼女、俺のこと見てるのか？）"

    # say L306 mia
    old "The European crisis allowed the emergence of powerful industrialists, like Rockefeller and Ford."
    new "ヨーロッパの危機は、ロックフェラーやフォードのような強力な実業家たちの台頭を可能にしました。"

    # say L307 pla
    old "(Why does she look so angry?)"
    new "なぜそんなに怒ってるんだ？"

    # say L313 mia
    old "Ok, guys, that's it for today, for the next class I'll need you to read about the treaty of Versailles."
    new "皆さん、今日の授業はこれで終わりにしましょう、次回はヴェルサイユ条約について読んで来てくださいね。"

    # say L319 mik
    old "Aw, dude, that was so dull!"
    new "あー、マジで退屈だったな！"

    # say L320 mik
    old "I'm exhausted, can't wait for lunch."
    new "俺、疲れたよ。昼休みが待ち遠しいな。"

    # say L330 mia
    old "Hey [pla], I'm going to need you to stay."
    new "Hey [pla]、ちょっと待ってください。先生と話さないといけないんです。"

    # say L332 mik
    old "Uh-oh, you're in trouble dude. I think I better get going home."
    new "おっ、やばいぞ。俺は家に帰った方がいいかもな。"

    # say L334 mik
    old "Good luck dude."
    new "運が良ければいいね、 Dude。"

    # say L336 pla
    old "See you dude."
    new "また会おう、 Dude。"

    # say L343 pla
    old "If this is about the project I-"
    new "もしプロジェクトのことなら、俺は……"

    # say L344 mia
    old "Oh shut up! Just shut up! Who cares about that stupid project?!"
    new "黙って！ただ黙って！そんな馬鹿なプロジェクトなんて誰も気にしないわよ！"

    # say L345 pla
    old "Uh w-what? But you said..."
    new "うわっ、なに？　でも君は言ったじゃないか"

    # say L346 mia
    old "So, it was you, wasn't it?!"
    new "そう、君がそのやつだったのね。"

    # say L347 mia
    old "I see, of course, he had someone on the inside."
    new "なるほど、当然ね、彼には内通者がいたのね。"

    # say L348 mia
    old "You're the bastard that's been verifying that I do his stupid challenges. I should've known."
    new "あなたがその野郎で、私が彼の馬鹿げたチャレンジを確認させられていたんだわ。気づくべきだった。"

    # say L349 pla
    old "Uhmm, what? What are you talking about?"
    new "うーん、何を言っているの？"

    # say L351 mia
    old "Well, I'll let you know I'm tired of this bullshit! You better not think you'll keep getting away with this disgusting behavior."
    new "まあ、私はこれ以上このクソ野郎の仕事に付き合わないわ！ あなたがこんな汚らわしい行為を続けると思っているなら、大間違いよ。"

    # say L352 mia
    old "I was so stupid not to realize it was you, of course, you were the clear option."
    new "私が気づかなかったのが馬鹿だったわ。もちろん、あなたが一番怪しいと思っていたのに。"

    # say L353 mia
    old "I should've known from the beginning. It was obvious."
    new "最初から気づくべきだったわ。明らかだった。"

    # say L354 pla
    old "Excuse me, I don't know what you're accusing me of, but I haven't done anything."
    new "すまない、君が何を言ってるのかわからないけど、俺は何もしてないよ。"

    # say L355 mia
    old "Will you stop playing dumb already?!!! You know very well what I'm talking about!"
    new "もう馬鹿を演じないでください！！！私が何を言っているのか、よくわかってるでしょう！"

    # say L356 mia
    old "Or are you telling me you haven't been following that bastard Denzel's orders to spy on me?"
    new "それとも、デンゼルの命令で私を監視していたなんて言わないの？"

    # say L357 pla
    old "Denzel? What the-"
    new "デニゼル？何言ってるんだよ"

    # say L358 mia
    old "Or that you just happened to come into the classroom just as I was reporting to him?!"
    new "それとも、私が彼に報告している最中に教室に入ってきたのは偶然だって言うの？"

    # say L359 mia
    old "I know you're a bastard, but spare me your stupid lies!"
    new "あなたが野郎だということは知ってるけど、くだらない嘘はやめてくれ！"

    # say L360 pla
    old "I already told you I don't know what you're talking about!"
    new "もう何度も言ったように、何を言ってるのかわからない！"

    # say L361 mia
    old "Ugh, whatever, let's just get this over with."
    new "うっ、いいわ、早く済ませちゃおう。"

    # say L369 pla
    old "Woah! Woah! What do you think you're doing?"
    new "Woah！ Woah！ 何してるつもりだよ？"

    # say L370 mia
    old "Will you stop pretending you don't know what's going on?!!"
    new "あなたが何が起こっているのか知らないふりを続けるのを止めてくれない？！！"

    # say L371 mia
    old "How can you keep acting like this after all that you've made me do?!"
    new "どうして私にこんなことさせておいて、まだそんな顔ができるの？！"

    # say L372 mia
    old "At least pretend you have some decency, will you?!"
    new "せめて見た目だけでも品格を保ってよ！"

    # say L373 pla
    old "I-I don't... W- what do you mean?"
    new "俺は……何を言っているのかわからないよ。"

    # say L374 pla
    old "I already told you, I have no idea what you're talking about."
    new "もう言ったけど、何を言ってるのかさっぱりわからないよ。"

    # say L375 mia
    old "Yeah right... As if I'll believe anything you say."
    new "うん、そうよね…私が信じるはずないじゃない。"

    # say L376 mia
    old "But I'll give you what you want, you sick freak."
    new "でもあなたが欲しがってるものはあげるわ、変態さん。"

    # say L385 mia
    old "Listen, I've had enough of your bullshit for one day."
    new "もういいわ、今日のあなたのウソには本当にうんざりだわ。"

    # say L386 mia
    old "I already sent that asshole the picture. Just leave me alone."
    new "もうそのクソ野郎に送っちゃったの。だから放っておいて。"

    # say L393 pla
    old "What the fuck?!"
    new "何てことだよ！"

    # say L415 mia
    old "Of course, your little accomplice would come!"
    new "もちろん、あなたの小さな仲間が来るわ！"

    # say L416 mia
    old "What are you two, sick freaks, planning now?"
    new "今何を企んでるの、変態たち？"

    # say L417 pla
    old "W- what? I... What are you talking about?"
    new "何言ってるんだ？俺……何の話だ？"

    # say L418 pla
    old "I just came early for class!"
    new "俺はただ授業に早めに来たんだよ！"

    # say L419 mia
    old "Ugh! Denzel, could you tell your little minion to stop acting?"
    new "うっ！デンゼル、あなたの小さな手下に芝居をやめさせるよう言ってくれませんか？"

    # say L421 den
    old "Well, Miss Mia, I must say this is the first time I've seen your student."
    new "ミス・ミア、これは初めてあなたの生徒を見ましたね。"

    # say L422 den
    old "I don't even know his name."
    new "名前すら知らないんだよ。"

    # say L423 mia
    old "What?! What do you mean?"
    new "何ですか？　どういう意味ですか？"

    # say L425 den
    old "Well, I don't think you even have enough in that empty head of yours to remember."
    new "まあ、お前のその空っぽの頭じゃ覚えられるわけないだろうな。"

    # say L426 den
    old "But while you were my teacher, you made my life miserable, absolutely horrible."
    new "でも君が俺の先生だったとき、俺の人生を地獄にして、本当に最悪な日々にしたんだ。"

    # say L427 den
    old "And from what I can see, that's something you're still doing..."
    new "そして、今でもそれを続けてるみたいだな。"

    # say L429 den
    old "Well, I've noticed you always pick on a poor and innocent guy from your classes to torment."
    new "まあ、お前がいつもクラスの中から貧しくて無辜な男の子を選んでいじめるのが目についてるな。"

    # say L430 den
    old "Tremendously immature of you, I must say, someone would think a teacher would be a little bit more... nuanced."
    new "ずいぶんと幼稚だな、俺が思うに、先生ならもう少し... 視点を変えることができると思ったけど。"

    # say L431 den
    old "So, the other day, after listening to your answer when we were talking and you got interrupted by him."
    new "先日ね、お前の答えを聞いていたとき、彼に邪魔されて中断されたんだが。"

    # say L432 den
    old "It came to my mind, why not give the young guy a chance to take some revenge on his horrible teacher?"
    new "俺の頭には、若者にあの最悪の教師への復讐のチャンスを与えてやろうという考えが浮かんだんだ。"

    # say L433 mia
    old "... The fuck?"
    new "何それ？"

    # say L434 pla
    old "W-w-what the hell is happening? What are you guys talking about?"
    new "一体何が起こってるんだ？お前ら何を話してるんだ？"

    # say L436 den
    old "Oh, how rude of me, I went into a monologue without even introducing myself. Apologies buddy."
    new "ああ、失礼しました。自己紹介もせずに独り言を言っちゃった。申し訳ないね。"

    # say L437 den
    old "My name is Denzel, and just like you, I was once a victim of this so-called teacher's horrible personality."
    new "名前はデンゼルだ、君と同じようにこの先生の最悪な性格の犠牲者だったんだ。"

    # say L439 den
    old "She used to be my teacher, and she made my life miserable too."
    new "彼女は俺の先生だったんだ、そして俺の人生を地獄にしたんだ。"

    # say L441 den
    old "I never forgave her, but I didn't actually have any way to get back at her for anything."
    new "俺は彼女を許せなかったけど、実際には彼女に復讐する方法がなかったんだ。"

    # say L442 den
    old "That is, until recently, when I learned a couple of things from her past that she would prefer to have hidden."
    new "それが最近までだったんだが、彼女の過去についていくつかのことを知ったんだ。彼女はそれを隠したがっていることだろう。"

    # say L443 mia
    old "No! Don't say anything about that! Please, I'm already doing whatever you ask me."
    new "いいえ！それについては何も言わないで！お願い、私もうあなたが求める何でもしてるのよ。"

    # say L445 pla
    old "W-what are you talking about?"
    new "何を言ってるんだ？"

    # say L447 den
    old "Go ahead Mia, tell your favorite student all about your past..."
    new "ミア、君の好きな生徒に過去のことを全部話してみてはどうだ？"

    # say L448 mia
    old "Please... No..."
    new "お願い……やめて……"

    # say L450 den
    old "I mean, there's nothing to feel ashamed about, is there?"
    new "俺が言っているのは、恥ずかしいことは何もないとでも思っているかい？"

    # say L455 den
    old "That's right! Can you believe it? She's always so self-righteous, always taking her anger out on other people."
    new "そうだよ！信じられる？彼女はいつも自分を正しいと思い込んでいるくせに、怒りを他の人にぶつけるんだ。"

    # say L456 den
    old "She's offensive, arrogant, and demanding, when she used to be just a whore!"
    new "彼女は攻撃的で傲慢で要求ばかり、昔はただの売春婦だったのに！"

    # say L458 den
    old "Anyway, she got out of that, but I found out and got proof that she used to be a pornstar."
    new "まあ、それからは彼女は抜け出したけど、俺はその証拠を見つけた。彼女が昔ポルノ女優だったってことだ。"

    # say L459 den
    old "And if she doesn't want to be fired, and get her life ruined,  she'll have to do as I say."
    new "そして、馘首になりたいわけじゃないし、人生を台無しにされたくもないだろうから、俺の言うことを聞くしかないんだ。"

    # say L460 den
    old "Or I'll out her as the whore she is, and her life here will be over."
    new "それか、彼女がホステスじゃなくて売春婦だってことをバラすぞ。ここでの人生は終わりだ。"

    # say L461 mia
    old "You fucking bastard!"
    new "あなたこの野郎！"

    # say L463 den
    old "Oh, call me what you want, that only makes it better when I punish you."
    new "お前が何呼ぼうと構わん、それが罰する時の楽しみに加わるだけだ。"

    # say L466 den
    old "By the way... I think it's about time for your next punishment."
    new "それに…次のお前の罰の時間だな。"

    # say L467 den
    old "Oh, sorry, we're calling them challenges. Right?"
    new "ああ、すまん、それらをチャレンジって呼ぶんだっけ。そうだな。"

    # say L468 mia
    old "Challenge? Punishment?!"
    new "チャレンジ？ 惩罰？！"

    # say L469 mia
    old "This is blackmail! And abuse!"
    new "これは脅迫よ！そして虐待だわ！"

    # say L470 den
    old "Call it whatever you want, but you have to do it."
    new "何と呼ぼうと、でもやるしかないんだよ。"

    # say L471 den
    old "And seeing as your favorite student's here, why don't we have you give him a little bit of attention?"
    new "お前の好きな生徒がここにいるんだ、ちょっと気を遣ってあげないか？"

    # say L473 den
    old "Give him a blowjob."
    new "彼にフェラチオしてあげろ。"

    # say L474 mia
    old "What?! You must be kidding me! A blowjob?!"
    new "何っ！冗談じゃない！フェラチオなんて！"

    # say L475 mia
    old "This is going way too far!"
    new "これはやりすぎですね！"

    # say L476 mia
    old "Didn't you have enough with your pictures and stuff?"
    new "写真とかもう十分じゃなかったの？"

    # say L477 den
    old "Oh, I really enjoyed those, but that's not what I want right now."
    new "あの写真は楽しかったけど、今欲しいのはそれじゃないんだよ。"

    # say L478 den
    old "I already told you what to do, take out his dick and suck it!"
    new "もう言った通りにして、彼のちんこを出して舐めろ！"

    # say L479 den
    old "Otherwise I suppose tomorrow the school principal will receive a mail with an interesting video."
    new "それじゃあ、明日には学校の校長先生に面白いビデオが届くことになるだろうな。"

    # say L492 mia
    old "You sick freak..."
    new "あなたって変態ですね…"

    # say L493 mia
    old "I'll do it, ok? Just don't spread anything, ok?"
    new "私、やりますから、いいでしょ？ ただ、何も広めないでね。"

    # say L496 mia
    old "Ugh, come here [pla]... I'll do this quickly."
    new "うっ、来なさい [pla]… 早くやっちゃうから。"

    # say L498 pla
    old "Y- you can't be serious."
    new "まじかよ。"

    # say L499 mia
    old "Well, what do you think stupid?!"
    new "何考えてんの、バカ？！"

    # say L500 mia
    old "I wouldn't joke about this shit."
    new "こんなこと冗談で言うわけないじゃない。"

    # say L501 pla
    old "I- I'm sorry Miss Mia, but I don't have anything to do with this. I should just leave."
    new "申し訳ありません、ミアさん。これには関係ありません。ただ去るべきだと思います。"

    # say L508 den
    old "Well, I guess you could just leave. But if you do, I'll just leak the information I have about her."
    new "まあ、去るっていう選択肢もあるけど、もし去ったら、俺が彼女について持ってる情報を漏らすよ。"

    # say L509 den
    old "That's also an option by the way."
    new "それも一つの選択肢だよ。"

    # say L511 den
    old "After all, she's also been cruel to you all this time, you may as well just let her suffer with this."
    new "結局、彼女は今まで君に冷たくしていたんだ、このまま放っておいてやるのもいいだろう。"

    # say L513 den
    old "Tell you what, maybe you'll change your mind if you see her beg for it. How about it?"
    new "君が彼女の懇願を見て気持ちが変わったらどうだろう？どう思う？"

    # say L515 den
    old "Go ahead Mia, beg him to let you suck his dick, remember what's at stake here for you."
    new "ミア、さあ、彼にちんこをしゃぶらせてって懇願しなさい、ここであなたが何を失うか覚えてるよね。"

    # say L517 mia
    old "Listen, [pla] I don't want this to happen any more than you do."
    new "ねぇ、[pla] 私もあなたと同じようにこの状況を望んでいませんよ。"

    # say L518 den
    old "Ha! What a weird way to beg! heh."
    new "ハ！変なお願いの仕方だな、へhéへ。"

    # say L519 mia
    old "But if we don't do this, he'll just release his disgusting pictures and videos of me."
    new "でも、これをしなければ、彼は私の汚い写真や動画を公開してしまうわ。"

    # say L520 mia
    old "Please, please, please help me out."
    new "お願い、お願い、助けてください。"

    # say L521 mia
    old "After my life went to shit because of what happened before, it's taken me so much work to create something here."
    new "前のことであたしの人生が台無しだった後、ここでの生活を築くのにどれだけ努力したと思ってるの？"

    # say L522 den
    old "Aww, you're breaking my heart."
    new "ああ、君の心を傷つけちゃってるみたいだな。"

    # say L523 mia
    old "Fuck you."
    new "ばか、あなたったら。"

    # say L524 pla
    old "Hmm, ok, I'll do it."
    new "うん、わかった、やるよ。"

    # say L526 den
    old "You will, Ha! I knew it, you also want to get revenge on her, right?"
    new "やるつもりだな、ハ！　俺の勝ちだ、お前も彼女に復讐したがってるだろ？"

    # say L527 pla
    old "No!"
    new "いや！"

    # say L528 pla
    old "I'll do it just to help her, I don't want revenge on anyone."
    new "俺はただ彼女を助けるためにやるんだ、誰かに復讐したいわけじゃない。"

    # say L529 den
    old "Heh, whatever you say, kid."
    new "へえ、お前が言うならな、子供。"

    # say L531 den
    old "All right Mia, it's time to do what you do best!"
    new "よしミア、お前が最も得意なことをしようぜ！"

    # say L542 mia
    old "(I can't believe I'm actually doing this, and to [pla] of all people!)"
    new "信じられないわ、本当にこれをしてるなんて。それに相手が[pla]だなんて。"

    # say L543 den
    old "I bet you actually wanted this, even if you left the porn business."
    new "君がAV業界を辞めたって言っても、本当はこれ欲しかったんだろう。"

    # say L544 den
    old "After all you're just a whore."
    new "結局、お前はただの娼婦だろ。"

    # say L546 mia
    old "Whatever you say, but remember, you won't get away with this for long."
    new "何言ってもいいけど、覚えておきなさい、これで終わりじゃないわよ。"

    # say L547 den
    old "Heh, we'll see."
    new "へへ、見てろよ。"

    # say L557 mia
    old "Woah, what the fuck?!"
    new "おわ、なにそれよ！"

    # say L559 mia
    old "What are you doing? What did you take that picture for?"
    new "何してるの？その写真を撮ったのって、何のために？"

    # say L560 den
    old "Don't worry about it, that's just to..."
    new "心配しないで、それはただ……"

    # say L561 den
    old "Let's say, commemorate the occasion."
    new "まあ、この瞬間を記念するためにさ。"

    # say L563 den
    old "Anyway, I think I should just leave."
    new "まあ、俺が帰るか。"

    # say L564 den
    old "Well done [pla], I bet you liked that."
    new "よくやったな [pla]、きっと気に入っただろうさ。"

    # say L566 den
    old "Until we see each other again, bye."
    new "また会うまで、さよなら。"

    # say L577 pla
    old "U-uh, Miss Mia, I- I think..."
    new "うー、ミア先生、あの、思うんだけど……"

    # say L578 mia
    old "I don't want to talk, or anything. Bye."
    new "話す気もないわ、さよなら。"

    # say L586 pla
    old "Damn."
    new "くそ。"

    # say L587 pla
    old "(What did I get myself into now?)"
    new "今度は何に首を突っこんだんだよ。"

    # say L606 pla
    old "Eh, ehem."
    new "ええと、あhem。"

    # say L611 pla
    old "Hi Miss Mia, good morning."
    new "ミアさん、おはようございます。"

    # say L612 mia
    old "G-good morning."
    new "おはようございます。"

    # say L613 mia
    old "I see you're early today, congratulations."
    new "お早いですね、おめでとうございます。"

    # say L614 mia
    old "The class doesn't start yet, so take a seat and wait for your classmates."
    new "授業が始まるまでなので、席に座ってクラスメイトが来るのを待っていてください。"

    # say L618 pla
    old "Hmm, actually, I was kinda hoping we could talk."
    new "実は、ちょっと話したいんだけど。"

    # say L619 pla
    old "You know, about what happened last time..."
    new "あのさ、前のことについて話したいんだよね。"

    # say L622 mia
    old "Listen, we don't have anything to talk about."
    new "聞いて、私たちには話すことは何もないんです。"

    # say L623 mia
    old "I'm really sorry that you saw yourself being dragged into it, and I thank you for helping me."
    new "あなたが巻き込まれて見てしまったこと、本当に申し訳ありません。そして、私を助けてくれてありがとう。"

    # say L624 mia
    old "But that's all I will say about that issue."
    new "でも、その件についてはこれだけです。"

    # say L625 mia
    old "Which, by the way, it's my own business, so I would appreciate it if you didn't interfere."
    new "それは私の問題なので、介入しないでほしいんです。"

    # say L626 pla
    old "What? You can't be talking seriously."
    new "何？本気で言ってるわけがないだろう。"

    # say L627 pla
    old "Listen, what happened yesterday wasn't ok, and you can't let him keep forcing you into that kind of stuff."
    new "おい、昨日のことは許せないし、君をそんな状況に追い込むのを止めるべきだ。"

    # say L628 pla
    old "It's just not right, you have to do something..."
    new "それは間違ってる、何かしなきゃいけない…"

    # say L629 mia
    old "And you think I don't know that?!"
    new "それが分かってるって思ってるの？！"

    # say L630 mia
    old "Of course it's not right! But I can't do anything, I've racked my brain to come up with a satisfying solution. But nothing."
    new "もちろん間違ってるわ！でも私には何もできないの、頭を悩ませて満足できる解決策を考えたけど、何も思いつかなかったの。"

    # say L631 mia
    old "Otherwise, I wouldn't be stuck following his orders! Don't treat me like an idiot!"
    new "それなら、彼の命令に従わざるを得ないわ！バカにしないでよ！"

    # say L633 pla
    old "I know you're not dumb, but that's why I wanted to talk to you because I think maybe I could help you."
    new "君がバカじゃないことは知ってるよ、だからこそ話し合いたかったんだ。もしかしたら、君を助けることができるかもしれないと考えたからさ。"

    # say L635 pla
    old "Listen, I just don't think it's right that he keeps pushing you around like that."
    new "彼があなたをそんな風に扱うのは納得いかないんだよ。"

    # say L636 pla
    old "I want to do something to help you."
    new "君を助けるために何かしたいんだ。"

    # say L637 pla
    old "I think it's the best thing that I can do. If you'll let me."
    new "それが君のためにできる中最も良いことだと思うんだ。もし許してくれるなら。"

    # say L639 mia
    old "Hmm... I guess you're right."
    new "うーん……そうかもね。"

    # say L640 mia
    old "Listen, Denzel, is a previous student of mine, that apparently recent me from when I was his teacher."
    new "デニゼルは私の元生徒で、私が彼の先生だった頃の私について何か映像を見つけたらしいの。"

    # say L641 mia
    old "And he's decided to get back at me by threatening to release some footage that he found from when I was..."
    new "そして彼は、私が……ときの動画を公開して私に復讐しようと決心した。"

    # say L642 mia
    old "From when I was..."
    new "私が..."

    # say L643 mia
    old "Ugh! It's even hard to talk about it!"
    new "うっ！話すのも恥ずかしいわ。"

    # say L644 mia
    old "From when I was a pornstar, ok?"
    new "私が pornstar だった頃からですよ、OK？"

    # say L646 mia
    old "That was a long time ago, I was just fresh out of high school, and didn't have any money to pay for college."
    new "それはもう昔のことです、私は高校を卒業して間もなく、大学の学費を払うお金がなかったんです。"

    # say L647 mia
    old "Somebody had talked to me about how much money you could make in little time working on porn."
    new "誰かがアダルト業界で働けば、短時間でたくさんのお金を稼げるって教えてくれたんです。"

    # say L648 mia
    old "I was young, so I didn't really think it through, and just decided to do it."
    new "若かったから、よく考えずにそう決めてしちゃった。"

    # say L649 mia
    old "But I regret it so much, it didn't bring anything good to my life. That period gave me very low self-esteem."
    new "でも、そのことはとても後悔しています。良いことは何ももたらさず、その時期は私の自己評価をとても低くしました。"

    # say L650 mia
    old "Besides, it caused me depression and anxiety that lasted for a very long time."
    new "それに、それによって長期間うつ状態と不安が続きました。"

    # say L654 mia
    old "At the end I decided I couldn't take it anymore, so I just got away from it, and did everything I could to conceal that part of my past."
    new "最終的に、これ以上耐えられないと決めて、その過去を隠すためにできることを全部やったの。"

    # say L655 mia
    old "Finally things worked out, but I had to change my entire life, move city, change name, everything. Just to get away from it."
    new "結局、うまくいったけど、人生を全部変えなきゃならなかったの。引っ越しも名前も変えて、全部。ただそれから離れるためだけに。"

    # say L656 mia
    old "You can imagine then how hard it is for me to see that material is still out there, and somebody could see it."
    new "それだから、その素材がまだどこかにあるのが、どれだけ辛いか想像できるでしょ。誰かが見つけるかもしれないんだから。"

    # say L657 pla
    old "I mean, I get that. But what do you mean 'Still out there'?"
    new "つまり、それは分かるけど、「まだ外に存在してる」ってどういう意味？"

    # say L658 pla
    old "I imagine that whatever you filmed before would just be on the internet, right?"
    new "想像するに、君が前に撮影したものはインターネットに出てるってことだよな？"

    # say L659 pla
    old "Why is it weird that Denzel has pictures and videos of you?"
    new "なぜデンゼルが君の写真や動画を持っているのが変なのか？"

    # say L660 mia
    old "Because..."
    new "因为..."

    # say L661 mia
    old "Even though I was working hard, I never actually left college, so when I got out of porn, I wanted to work on what I had studied."
    new "努力してはいたけど、実際には大学を卒業していなかったので、アダルト業界から引退した後は、学んだことを活かしたくて思ったんです。"

    # say L662 mia
    old "It may be because I was so young, but I didn't think my previous job was going to be an issue."
    new "若かったからかもしれないけど、前の仕事が問題になるとは思わなかった。"

    # say L663 mia
    old "Nobody wanted to hire, a lot of parents, teachers, and principals at schools had seen my work."
    new "誰も雇ってくれなかった。学校の先生や校長、親御さんたちが私の作品を見ていたから。"

    # say L664 mia
    old "Ugh, they believed it was inappropriate for me to teach the children..."
    new "うーん、彼らは私が子供たちに教えることにふさわしくないと考えていたんです..."

    # say L665 mia
    old "I suppose it wasn't to jack up to my face."
    new "まあ、直接私に言われるわけじゃなかったけどね。"

    # say L666 mia
    old "Anyway, I decided that since I wasn't working in that industry any longer I didn't want my videos and pictures out there."
    new "それに、その業界で働かなくなったので、私の動画や写真が公開されているのは望んでいなかったんです。"

    # say L667 mia
    old "So, I sued my previous producer, and I managed to get everything taken down."
    new "なので、前のプロデューサーを訴えて、すべてを撤去することができました。"

    # say L668 pla
    old "Wow, that's amazing."
    new "すごいな、ミア。"

    # say L670 mia
    old "But it didn't really fix things where I lived, in the end, I had to move... several times."
    new "でも、それが住んでいたところの問題を解決しなかったの。結局、何度も引っ越しをすることになったの。"

    # say L671 mia
    old "A lot of people in different places knew who I was. Finally, I came to this place, where nobody seems to know me."
    new "いろいろな場所で多くの人が私のことを知っていたわ。最終的に、ここに来て、誰も私のことを知らないところを見つけたの。"

    # say L672 pla
    old "I understand, so you don't want people finding out about it."
    new "なるほど、だから君は誰にも知られたくないんだね。"

    # say L674 mia
    old "Of course not, it's taken me a lot of work to build a life for myself here."
    new "もちろん、ここでの生活を築くのにたくさんの努力をしたから。"

    # say L676 pla
    old "I see, but how did he manage to get that material of you if it was all taken down?"
    new "なるほど、でも全部削除されたはずだよ？どうやってそんな資料を手に入れたのかな？"

    # say L677 mia
    old "Honestly I have no idea, I've looked for hours on end for traces of my material."
    new "正直、さっぱりわからないの。何時間もかけて探したんだけど、私の素材の痕跡は全然見つからないの。"

    # say L678 mia
    old "And I haven't been able to find anything, at all. So, it's a mystery to me that he was able to put his hands on it."
    new "何も見つけることができず、全く手がかりがないんです。どうやって彼がそれを手に入れたのか、私には謎です。"

    # say L679 mia
    old "And now he's using it to blackmail me, either I do what he demands, or he takes it to the principal and outs me in front of everybody."
    new "そして今、彼はそれをネタに私を脅しているの。私が彼の要求に応じなければ、校長先生に持って行って、みんなの前でばらすつもりだわ。"

    # say L680 mia
    old "After all this work! You have no idea how hard it's been for me to rebuild my life!"
    new "これだけの努力をして！私が人生を再建するためにどれだけ苦労したか、あなたにはわからないでしょう！"

    # say L682 mia
    old "How much I enjoy teaching! Instead of...!"
    new "教えていることの楽しさ！代わりに...！"

    # say L683 mia
    old "Instead of letting random actors do what they wanted to me on camera!"
    new "カメラの前で勝手に役者たちに触られたりするよりも！"

    # say L685 mia
    old "What's worse about it, is that ever since he began blackmailing me, I've given him more content to use."
    new "それが最悪なのは、彼が私を脅し始めた後、もっとコンテンツを与えてしまったことです。"

    # say L686 mia
    old "Being that desperate I've been following his orders, and he has a lot of stuff of me doing inappropriate things at school."
    new "必死になって彼の命令に従っていて、学校で不適切なことをしている私の写真や動画がたくさんあります。"

    # say L687 mia
    old "Like that picture he took of us..."
    new "あの写真を撮られちゃったみたいね..."

    # say L689 pla
    old "Listen, Ms. Mia, we'll do everything we can to stop him."
    new "ミアさん、俺たちはできる限りのことをして彼を止めるよ。"

    # say L691 mia
    old "Oh really? How?"
    new "ほんとうに？どうやってするの？"

    # say L692 pla
    old "Uh... I don't really know yet, but there must be a way."
    new "うーん…まだわからないけど、何か方法があるはずさ。"

    # say L694 pla
    old "Maybe we can hack his computer, or follow him and steal it from him."
    new "彼のパソコンをハックするか、つけて彼から奪う手もあるな。"

    # say L695 pla
    old "Or maybe there's something we can use against him, like his place of work, or something like..."
    new "または、彼の職場や何かをネタに使えるかもしれないけどね…"

    # say L696 mia
    old "Ok, enough! Who do you think you're talking to? Don't you think I already thought about every way I could handle this?"
    new "もう十分よ！誰に言っていると思ってるの？私がこんな状況でどんな手段を考えていないと思うの？"

    # say L697 mia
    old "All of these suggestions of yours are very nice, but they amount to nothing."
    new "あなたの提案はどれも素敵ですが、結局は何にもならないわ。"

    # say L698 mia
    old "So, I think it's better if we no longer talk about it, I'll deal with Denzel by myself."
    new "だから、これ以上話すのはやめましょう。私はデニゼルと自分自身で向き合います。"

    # say L699 pla
    old "What? B-but Miss Mia, I really want to help you, and..."
    new "何？でもミアさん、本当に君を助けてやりたいと思ってるんだよ、そして…"

    # say L700 mia
    old "That's very sweet, but there's nothing you can do for me [pla]."
    new "それはとても甘いけど、あなたが私のためにできることはもうないのよ [pla]。"

    # say L701 pla
    old "But."
    new "でも"

    # say L702 mia
    old "Class Is about to start, your classmates will arrive soon and I don't want them catch us talking about this. So drop it!"
    new "クラスが始まるので、クラスメイトが来る前にこの話はやめましょう。だから、これ以上言わないで。"

    # say L722 pla
    old "Fine."
    new "分かったよ。"

    # say L734 mia
    old "Ok, from today on we'll talk about Latin American political history in the twentieth century."
    new "では、今日から20世紀のラテンアメリカの政治史について話していきましょう。"

    # say L735 mia
    old "And we'll start with the Cuban coup d'etat..."
    new "そしてキューバのクーデターから始めましょう。"

    # say L741 mia
    old "Ok, that's all for today, I hope you took proper notes of the class."
    new "では、今日の授業はこれで終わりです。ちゃんとノートを取ったことを確認してくださいね。"

    # say L742 mia
    old "Remember to practice the subject at home, the test is very close, so don't relax too much and forget to study."
    new "家で復習して、テストが近いので油断せずに勉強すること。"

    # say L743 mia
    old "I know it sounds like a lot of work, but you have to do this if you want to properly learn all your subjects before the end of term tests."
    new "大変そうに聞こえますが、期末テストまでにすべての科目をきちんと学ぶためにはこれが必要です。"

    # say L745 mik
    old "See you at the next class guys."
    new "次回の授業で会おうね、みんな。"

    # say L769 pla
    old "Oh! It's you."
    new "お！お前か。"

    # say L772 den
    old "I came to see you, we need to talk."
    new "お前を⾒に来た、話さなきゃならないことがあるんだ。"

    # say L773 pla
    old "Do we?"
    new "話す必要があるのか？"

    # say L774 pla
    old "About what?"
    new "何についての話？"

    # say L775 den
    old "About Mia, of course, I want you to work with me."
    new "もちろんミアのことさ、一緒にやろうって。"

    # say L776 pla
    old "You what?"
    new "何言ってんだよ？"

    # say L777 den
    old "Yeah dude, listen, she has no way to get out of this."
    new "よし、聞いて、彼女には逃げ道はないんだ。"

    # say L778 den
    old "I have all the information, and the videos and pictures. We can both use it to get revenge on her."
    new "俺は全部の情報を握ってるし、動画と写真も持ってる。これを使って二人で彼女に復讐できるんだ。"

    # say L779 pla
    old "Come on, revenge? Really?"
    new "おい、復讐？本気で？"

    # say L781 den
    old "Listen, I know she's been terrible to you, right?"
    new "聞くよ、彼女はお前に対して最悪だったんだろ？"

    # say L782 den
    old "If we both work together, we can make that little bitch pay for everything she's done to us."
    new "一緒にやれば、あの小娘が俺たちにしたことを全部返してやれるんだ。"

    # say L783 den
    old "Besides, imagine all the things you can get her to do to you, just by telling her you'll release the pictures."
    new "それに、写真を流すって言ったら、彼女があなたの言うこと全部聞くだろうさ。"

    # say L784 den
    old "We'll make sure that she pays like the little slut she is."
    new "俺たちで協力すれば、あの小娘が本当に小 sluts になるようにしてやるよ。"

    # say L785 den
    old "What do you say, huh?"
    new "どう思う、な？"

    # say L786 pla
    old "What's wrong with you dude?! Revenge?! Make her pay? Slut?"
    new "何がおかしいんだよ！復讐？罰を与える？スレット？"

    # say L787 pla
    old "Are you really that twisted? The fuck?! This is a person's life you're talking about!"
    new "お前本当にそれほど歪んでるのか？マジかよ！人の人生を軽く見すぎだな！"

    # say L789 pla
    old "You would destroy her life just because she was a little mean to you?"
    new "お前は彼女の人生を台無しにするつもりなのか？ただちょっと意地悪されたからって？"

    # say L790 pla
    old "There's something seriously wrong with you dude..."
    new "お前、マジで病気だな…"

    # say L791 den
    old "Oh, so that's how it is, I thought you would understand, but it turns out you're just one of those moralist idiots."
    new "お、そうか。理解してくれると思ったんだけど、結局お前もただの道徳野郎か。"

    # say L792 pla
    old "I'm an molarist idiot? You're the one who thinks he can destroy someone's life and get away with it."
    new "俺が道徳的なアホか？お前こそ、人の人生を台無しにして平気な顔して逃げられると思ってるんだろ。"

    # say L793 den
    old "Don't give me that bullshit! Listen pal, Mia's just a simple whore who enjoys making others suffer."
    new "そんなウソつくな！聞いてくれ、ミアはただの単純な娼婦で、他人を苦しめるのが好きなんだ。"

    # say L794 den
    old "What's wrong with making her pay for all of the bad shit she does?"
    new "彼女が悪いことした分、払ってもらうって何が悪いんだ？"

    # say L795 den
    old "After all, it's just giving her a taste of her own medicine."
    new "結局、彼女に自分の薬を味合わせてるだけだよ。"

    # say L796 pla
    old "What's wrong with you? I won't do anything like that, you asshole."
    new "お前がどうしたっていうんだ？そんなこと絶対にしないよ、クソ野郎。"

    # say L797 pla
    old "It's true that Mia has a bad temper and a strong character, but not enough for you to justify destroying her life."
    new "ミアの性格が荒いのは事実だけど、それがあなたが彼女の人生を台無しにする理由にはならないよ。"

    # say L798 pla
    old "You're just hung up on some shit that happened a long time ago and you haven't been able to let it go."
    new "お前はただ、昔の出来事に未練があって、それを手放せないだけだな。"

    # say L800 den
    old "You're even more fucking stupid than I thought!"
    new "お前は俺が思ってたよりも、もっと馬鹿だな！"

    # say L801 den
    old "But it's ok dude, you'll understand, after all, I can still punish Mia by myself."
    new "でも大丈夫、理解してくれるさ、結局俺が一人でミアを罰することくらいできるんだから。"

    # say L803 pla
    old "Whatever you say dude, I don't want anything to do with you or your sick plans."
    new "お前が勝手にやれ、俺はお前の変態計画には関わたくない。"

    # say L804 den
    old "Yeah well, remember this, I'll take my revenge on Mia, and one way or another you'll have to do with it."
    new "まあ、覚えておけ、俺はミアに復讐する、君もいずれそのことに巻き込まれるだろう。"

    # say L815 pla
    old "Wow, what is wrong with that guy?"
    new "あの男は一体どうかしてるんだよ。"

    # say L823 pla
    old "Oh, hey Belle, morning."
    new "おっ、ベール、おはよう。"

    # say L824 bel
    old "Hey, who was that guy that was talking with you at the entrance? He looked like he was angry, were you arguing?"
    new "Hey、入口で話してたのは誰？ 怒ってるみたいだったけど、喧嘩してたの？"

    # say L825 pla
    old "Oh, him? He's just some guy I know, don't worry about it."
    new "ああ、彼？ただの知り合いだよ、気にするな。"

    # say L827 bel
    old "Hmm, I thought that maybe he has something to do with Ms. Mia."
    new "うーん、あの人がミアさんと何か関係あるのかなって思って。"

    # say L828 pla
    old "W-why do you think that?"
    new "なんでそう思うんだ？"

    # say L829 pla
    old "Did you hear anything?"
    new "何か聞いたのか？"

    # say L831 bel
    old "Well, it's just that lately, I've seen you talking with Ms. Mia, so I figured that maybe he had something to do with it."
    new "まあ、最近あなたがミア先生と話してるのを見たから、もしかしたら関係あるのかなって思ったのよ。"

    # say L833 pla
    old "Uhhh, no, no, he has nothing to do with it."
    new "うーん、いや、彼とは関係ないよ。"

    # say L834 pla
    old "I've just been talking to Ms. Mia about my grades, you know she's always harping on me."
    new "最近、成績のことだけ話してただよ、ミア先生はいつも俺に文句言ってるからな。"

    # say L836 bel
    old "Oh, I see, I guess you do need to pay attention to your grades."
    new "なるほど、成績には気をつけないとね。"

    # say L846 mia
    old "Hey, it's time for classes, so come in!"
    new "はい、授業の時間なので中に入ってください！"

    # say L851 mia
    old "Ok guys, it's time to start preparing for the midterm test, so today we'll do a couple of mock tests to help you get ready for it."
    new "皆さん、中間テストの準備を始めましょう。今日は模擬テストをいくつかやって、テストに備えましょうね。"

    # say L856 mia
    old "So, I hope you found the excersises useful, remember to practice again at home, the test is very close, so don't relax too much and forget to study."
    new "それでは、今日の練習が役立つことを願っています。家でも練習を続けてくださいね。テストはもうすぐなので、油断せずに勉強を続けてください。"

    # say L892 mia
    old "[pla], wait a minute, I'll need you stay, we need to talk about your grades."
    new "[pla]、ちょっと待って、残ってもらわないと、成績について話す必要があるの。"

    # say L907 mia
    old "What the fuck did you do?!! You idiot! I told you to stay out of it!"
    new "何したのよ！！バカ者！手を出さないでと言ったでしょう！"

    # say L909 mia
    old "Denzel called me and was very fucking angry! He said you were gonna pay him for saying what you said!"
    new "デニゼルが私に電話してきて、ものすごく怒ってたの！ あなたが言ったことの代償としてお金を払うって言ってたわ！"

    # say L910 mia
    old "What did you do?!"
    new "何したの？！"

    # say L911 pla
    old "Nothing, nothing! I swear to God! He's the one that came to talk to me this morning, when I was arriving at school!"
    new "何もしてないよ、何も！神にかけて！彼が今朝、学校に着いたときに俺に話しかけてきたんだ！"

    # say L912 pla
    old "He wanted me to allie with him and help him mess with you."
    new "彼は俺に君と同盟して、君を困らせる手伝いをしようとしたんだ。"

    # say L913 pla
    old "But I told him no, that I wasn't gonna be part of it."
    new "でも俺は断った、そんなことに関わるつもりはないって。"

    # say L914 mia
    old "Oh FUCK! Why did you have to get involved with this!"
    new "おふっかく！なぜあなたがこれに関わらなきゃならなかったの！"

    # say L915 mia
    old "This has nothing to do with you!"
    new "これとは全く関係ないのよ！"

    # say L916 mia
    old "Because of what you told him he's now fucking angry!"
    new "あなたが彼に言ったことで、今怒ってるのよ！"

    # say L917 mia
    old "Listen to me [pla], stay out of this, okay?! This has absolutely nothing to do with you!"
    new "[pla]、聞いてちょうだい、これには全然関係ないからね！関わらないでよね！"

    # say L918 mia
    old "Don't talk to that guy, don't make contact. Nothing!"
    new "その男とは話さないで、接触もしないで。何もかも！"

    # say L919 mia
    old "Do you get it?!"
    new "わかったの？！"

    # say L920 pla
    old "Whatever you say, but that guy is the one that came to me, and you know he's insane."
    new "分かってるけど、その男は俺の方から来たんだし、君も彼が頭がおかしいことは知ってるだろ。"

    # say L936 den
    old "I came to visit, I had to see my favorite teacher."
    new "俺が来たのは、お気に入りの先生に会いたかったからさ。"

    # say L938 den
    old "And look at that! My good friend [pla] is here as well!"
    new "そして見ろ！俺の親友[pla]もいるじゃないか！"

    # say L939 den
    old "Good, good, just what I was expecting."
    new "よしよし、まさに期待通りだね。"

    # say L942 pla
    old "Dude, don't you have anything else to do besides stalking Ms. Mia all day?"
    new "お前、ミス・ミアを一日中尾行してる以外にすることないのか？"

    # say L943 den
    old "Heh, you shouldn't worry that much about what I do to fill my time."
    new "へへ、私が時間どう過ごすくらいで心配するな。"

    # say L944 den
    old "It's more interesting what you're about to do!"
    new "お前がこれからやることのほうが面白いよ！"

    # say L945 den
    old "After all, I think it's about time that you two start."
    new "まあ、二人ともそろそろ始めるべきだね。"

    # say L947 den
    old "'Ms.' Mia, you haven't told him about the new challenge?"
    new "ミア、新しいチャレンジについて彼に話してあげてないの？"

    # say L949 mia
    old "Don't even think about Denzel."
    new "デニゼルのことなんて考えないで。"

    # say L950 mia
    old "It's not happening! No way in hell!"
    new "絶対にあり得ないわ！地獄の底でもない限りは！"

    # say L951 den
    old "Well, that surprises me, I guess that you don't mind then about the school principal receiving an interesting mail, do you?"
    new "まあ、それは意外だな。学校の校長先生に面白いメールが届くことには、特に気にしないってことなのか？"

    # say L953 pla
    old "Wait, what's happening? What did you ask this time."
    new "待て、何が起こってるんだ？今度は何を聞いただの。"

    # say L955 den
    old "Tell him, Mia."
    new "告げてやれ、ミア。"

    # say L956 mia
    old "{i}*Sigh*{/i} The thing is, this sick bastard wants us to have sex."
    new "{i}……{/i} そのことなんだけど、この変態が私たちにセックスをしようとするの。"

    # say L957 pla
    old "What?! What the fuck?!"
    new "何だと？！何という変態野郎だよ？！"

    # say L958 pla
    old "There's something seriously wrong with you pal! That's way too far! I'm going to the police!"
    new "お前さん、本当に頭がおかしいな！ それはやりすぎだ！ 警察に行くぞ！"

    # say L959 den
    old "HA! Do it! Fine by me!"
    new "HA！ やれよ！構わないさ！"

    # say L960 den
    old "I mean, sure, maybe I'll get trial for blackmail, nothing severe 'cause you don't have any evidence..."
    new "まあ、脅迫で裁判になるかもしれないけど、君には証拠がないから大したことはないさ。"

    # say L962 den
    old "But what's gonna happen when they review the photos and videos I got from you, what do you think will happen then, eh [pla]?"
    new "でも、俺が君からもらった写真や動画をレビューしたらどうなると思う？ねえ [pla]？"

    # say L963 den
    old "All of that is gonna come out to the public, and everyone will know Mia used to be a pornstar."
    new "それ全部が公になるんだよ、そしてみんなミアが元ポルノ女優だったことを知るだろう。"

    # say L964 den
    old "But that's not the worst part."
    new "でもそれが最悪の部分じゃない。"

    # say L965 den
    old "What will really make people angry is the fact that she's fucking her students."
    new "本当に怒らせることになるのは、彼女が生徒と寝ているってことさ。"

    # say L966 den
    old "Imagine what will happen then, hahaha."
    new "想像してみて、ははは。"

    # say L967 pla
    old "W-what?! Fucking her student? The hell are you talking about?"
    new "何言ってんだよ？生徒と寝てるってどういうことだ？それともう一つ、何を言っているんだよ？"

    # say L968 den
    old "I suppose you remember that picture I took of you the other day."
    new "あの日、俺がお前を撮った写真のこと覚えてるだろ。"

    # say L969 den
    old "Come on, everybody will believe that you two have been fucking anyway."
    new "おい、みんなは二人が寝てると思ってるんだよ。"

    # say L970 den
    old "I'll just make it a reality."
    new "俺が現実にするだけだよ。"

    # say L971 pla
    old "You're sick dude!"
    new "お前は本当に病気だな。"

    # say L972 mia
    old "Wait [pla], stop... just stop."
    new "待って[pla]、止めて… ただ止めて。"

    # say L973 mia
    old "{i}*Sigh*{/i} All right Denzel, you win... We'll do it."
    new "{i}……{/i} 仕方ないわ、デニzel、あなたの勝ちよ……やるわ。"

    # say L974 pla
    old "You can't be serious!"
    new "冗談じゃないよ！"

    # say L975 pla
    old "You can't let this guy get away with something like that! We have to go to the police!"
    new "そんな男にそんなこと許しちゃダメだよ！ 警察に届け出なきゃ！"

    # say L976 mia
    old "And then what?! You heard him! If we go to the police my life will be ruined!"
    new "それじゃあどうするの？！ 君も聞いただろう？ 警察に行ったら私の人生は台無しだよ！"

    # say L977 mia
    old "Besides, with the other photos that he has, he could also drag you down with me!"
    new "それに、彼が持っている他の写真なら、私と一緒に君も巻き込まれるかもしれないよ。"

    # say L978 pla
    old "Hmph!"
    new "ふん！"

    # say L980 mia
    old "Look, I don't want this, but I really need your help. Please [pla]."
    new "あたし、これほしくないけど、本当にあなたの助けが必要なの。お願い、[pla]。"

    # say L981 pla
    old "{i}*Sigh*{/i} Ok, I guess we have to."
    new "{i}……ふう……{/i} 仕方ないな。"

    # say L983 mia
    old "Ok, Denzel, we'll do it."
    new "デニゼル、わたしたちでやるわ。"

    # say L984 den
    old "Fantastic! I knew you guys would come around!"
    new "素晴らしい！君たちが納得してくれると思ってたよ！"

    # say L985 den
    old "Ok, let's get to it!"
    new "じゃあ、始めよう！"

    # say L986 mia
    old "What? Here? Now?"
    new "何？ここに？今？"

    # say L987 den
    old "What would be better?"
    new "何がいいかって？"

    # say L988 den
    old "It's ok, I don't think the janitor will come anytime soon. So nobody will notice us."
    new "大丈夫、掃除のおじさんはすぐには来ないと思う。だから誰にも気づかれないよ。"

    # say L989 pla
    old "Wait, 'us'? Does that mean you're gonna be here while we do it?"
    new "待て、『私たち』って？それって君もここにいるってことなのか？"

    # say L991 den
    old "Of course I'm serious! What else am I going to do?"
    new "もちろん本気だよ！他に何するんだよ？"

    # say L992 den
    old "Besides, you can't be angry about it Mia, you're used to fucking in front of other people, right? This should be easy for you."
    new "それに、ミア、怒るなよ。お前は他の人の前でセックスすることに慣れてるだろう？これくらい簡単だろ。"

    # say L993 den
    old "Just close your eyes and imagine it's the good old days. You whore."
    new "目を閉じて昔の良い日々を想像しろ。お前は淫乱だな。"

    # say L994 den
    old "Oh, by the way, remember to take your tits out. You've been keeping them hidden, and I think it's time for you to let them out."
    new "おい、そういえば乳出さないとダメだよ。隠してるのもいいけど、そろそろ見せてあげなよ。"

    # say L995 mia
    old "You're fucking pathetic."
    new "あなたは本当に情けない人ね。"

    # say L996 den
    old "Hehehe, sure, sure."
    new "へへへ、そうだね、そうだね。"

    # say L1005 den
    old "I bet you're happy getting drilled by that cock."
    new "君がそのチ○ポで犯されて悦に入ってるんだろうな。"

    # say L1006 mia
    old "Ugh, whatever dude."
    new "うっ、何でもいいわよ。"

    # say L1007 mia
    old "We're only doing this because you're forcing us, you ass."
    new "私たちはあなたに迫られて仕方なくこれをしているだけよ、クソ野郎。"

    # say L1008 den
    old "You know, you're making me sound like the bad guy, but I'm sure you're enjoying this."
    new "君がそう言うと、俺は悪役みたいに見えるけど、君も楽しんでるはずだな。"

    # say L1009 den
    old "You may fool yourself and others with this whole 'teacher' thing, but I know that you're really a whore."
    new "お前はこの「先生」って役割で自分も他人もだませようとしてるけど、本当はただの売春婦だって俺にはわかってるよ。"

    # say L1010 mia
    old "You're sick."
    new "あなたは変態です。"

    # say L1011 den
    old "Hahaha, you keep fucking like the bitch you are."
    new "ははは、お前は相変わらずその通りに犯してるな。"

    # say L1023 mia
    old "Oh come on!"
    new "あら、そう言わないで。"

    # say L1025 pla
    old "Come on dude!"
    new "おい、マジでよ！"

    # say L1026 den
    old "Oh, I'm sorry, I interrupted you guys when you were having such a sweet time together."
    new "すみません、君たちがこんな甘い時間を過ごしているところを邪魔しちゃって。"

    # say L1028 den
    old "I'm so rude."
    new "俺、失礼だな。"

    # say L1029 den
    old "But you see, now I have actual evidence that you guys fucked!"
    new "でも、今なら実際に証拠があるんだ。お前らがセックスしたってことだよ！"

    # say L1030 den
    old "I guess that means that I now have two bitches instead of just one. Am I right?"
    new "じゃあ、俺は今二匹の犬を手に入れたってことか。そうなのか？"

    # say L1031 den
    old "Hahahahahahahaha."
    new "はははははははは。"

    # say L1032 den
    old "I told you you were going to be a part of this [pla]."
    new "俺は言ったろ、君もこれに関わることになるって [pla]。"

    # say L1033 mia
    old "You're really twisted."
    new "あなたってほんと変態ですね。"

    # say L1034 den
    old "I think I should get going, but don't worry guys, I'll be seeing you soon."
    new "俺はそろそろ行くけど、心配するなよ、またすぐに会うからな。"

    # say L1039 pla
    old "There's something seriously wrong with that guy's head."
    new "あの男の頭、相当おかしいよ。"

    # say L1041 mia
    old "{i}*Sigh*{/i} Whatever. For now, let's just get dressed."
    new "{i}……{/i} まあ、いいわ。まずは服を着ましょう。"

    # say L1047 pla
    old "Listen, Ms. Mia, I know that what just happened's disheartening, but I'm sure there must be something we can do."
    new "ミア君、今起こったことが落胆させているのは分かるけど、何か手立てがあるはずだよ。"

    # say L1048 pla
    old "We can't just give in to what that maniac wants."
    new "俺たちがその狂人の要求に屈してちゃダメだ。"

    # say L1049 mia
    old "No, there isn't anything, he's already got us."
    new "いいえ、何もありません、彼はもう私たちを完全に掌握しています。"

    # say L1050 mia
    old "It's just as he says, we're his bitches."
    new "彼の言う通り、私たちはもう彼の玩具同然よ。"

    # say L1051 mia
    old "Let's just leave it at that."
    new "それじゃ、このままにしておきましょう。"

    # say L1056 pla
    old "Damn it, there has to be something I can do, I'm sure of it."
    new "くそ、何かできることがあるはずだ、絶対に。"

    # say L1077 mia
    old "Oh, thanks God, I found you! Please come here for a minute."
    new "ああ、神様ありがとうございます、あなたを見つけることができました！ちょっとこちらに来ていただけますか。"

    # say L1084 mia
    old "Listen, I have to tell you something."
    new "聞いて、教えてあげることがあるの。"

    # say L1085 mia
    old "Denzel called me, he gave us another 'challenge'."
    new "デニゼルから電話があって、また新しい『チャレンジ』をくれたの。"

    # say L1086 pla
    old "What? Are you for real?"
    new "何？本気で？"

    # say L1087 pla
    old "What does he want now?"
    new "今度は何が欲しいんだ？"

    # say L1088 mia
    old "Well, every time he's given me a new 'challenge' to do, they have been getting riskier and riskier."
    new "まあ、彼が私に与えてくれる新しい『チャレンジ』は、次第に危険なものになってきているんです。"

    # say L1089 mia
    old "This time is the same, he wants us to... Have sex in the school bathroom."
    new "今回は同じで、彼は私たちに……学校のトイレでセックスをするように求めているんです。"

    # say L1091 pla
    old "Woah! Really? But that's way too risky!"
    new "Woah！ ほんと？ でもそれ、めっちゃ危険じゃん？"

    # say L1092 pla
    old "I mean, last time everyone had already gone home. What will happen if someone sees us?"
    new "前回はみんな帰ってたけど、誰かに見つかったらどうするんだ？"

    # say L1093 mia
    old "I already thought of that, that's why I'm telling you now because everyone else is in their classrooms."
    new "それ考えたの、だから今みんなが教室にいるときにあなたに言っているの。"

    # say L1094 mia
    old "If we do it now nobody should see us."
    new "今なら誰にも見られずにできるわ。"

    # say L1096 pla
    old "So we should go have sex in the bathroom now?"
    new "じゃあ今すぐトイレでセックスしようってこと？"

    # say L1097 mia
    old "That's right, he said I have to do a video call... for him to see us."
    new "そうです、彼はビデオ通話をしなければならないと言ったの……彼に私たちを見せるためです。"

    # say L1098 pla
    old "Jesus! What the hell is wrong with that freak?!"
    new "Jesus！ その変態は何を考えているんだよ！"

    # say L1099 pla
    old "No way we're doing that."
    new "そんなこと絶対にやらないよ。"

    # say L1100 mia
    old "Not this again..."
    new "またこの話題か…"

    # say L1101 mia
    old "[pla], this is really difficult for me, you know? You know all the stuff he has of us."
    new "[pla]、これって私にとって本当に難しいんですから。あなたも彼が私たちについて持ってるもの全部知ってるでしょう？"

    # say L1102 mia
    old "Please don't make me beg you again, I really need you to help me."
    new "お願い、また私を懇願させるのは止めて、本当にあなたの助けが必要なの。"

    # say L1103 pla
    old "Hmm, yeah, you're right."
    new "うん、そうかも。"

    # say L1104 pla
    old "{i}*Sigh*{/i} Ok, let's go then."
    new "{i}*ため息*{/i} 分かった、行こうじゃねえか。"

    # say L1111 pla
    old "I know I keep putting too many hurdles, but are you sure about this?"
    new "俺はいつも余計な障害を設けすぎてるって分かってるけど、本当にこれでいいのか？"

    # say L1112 mia
    old "As I already told you, we don't have any other choice."
    new "私がすでに言った通り、他に選択肢はありません。"

    # say L1113 pla
    old "Hmph, yeah, yeah, you're right."
    new "ふん、そうさ、そうさ、君が正しい。"

    # say L1115 mia
    old "Ok, let's call this asshole."
    new "はい、じゃあこのクソ野郎に電話しましょう。"

    # narrator L1116 
    old "... Ringing ..."
    new "... 鳴っている ..."

    # say L1117 den
    old "Hello! Wow, you guys are early!"
    new "やあ！すごいな、君たちは早かったな！"

    # say L1118 den
    old "This is the perfect location, isn't it Mia?"
    new "この場所が最高だろ、ミア？"

    # say L1119 den
    old "A dirty little place for a dirty little whore. Hahaha."
    new "汚い小部屋で、汚い小女だな。ハハハ。"

    # say L1121 den
    old "What about you [pla]? Aren't you happy you get to fuck your dear teacher again?"
    new "お前もそうだろ、[pla]？先生とまたセックスできるんだぜ、嬉しくないのか？"

    # say L1122 pla
    old "Fuck you dude! Don't think you can keep getting away with this for too long."
    new "お前もくそ食らえ！　この調子で長くは行かないぞ。"

    # say L1123 den
    old "Hahaha, whatever, let's just get started with this."
    new "ははは、いいじゃん、さっさと始めるぞ。"

    # say L1124 den
    old "Oh! And remember to take your tits out Mia, I'm recording this, so I want it to be good quality."
    new "おっ、ミア、おっぱい出しな、俺が録ってるから、クオリティ良くしたいんだよ。"

    # say L1134 den
    old "Oh yeah, just like that, nice."
    new "オーケー、その調子、いいぞ。"

    # say L1141 bel
    old "My gosh, I hate P.E. so much! I'm so sweaty!"
    new "ああん、本当に体育が嫌い！汗だくになっちゃうよ！"

    # say L1143 mia
    old "{i}Stop, stop! Oh shit! Someone is coming!{/i}"
    new "{i}止めて、止めて！ああ、しまった！誰か来るわ！{/i}"

    # say L1145 bil
    old "Ugh, I know, like, look at my makeup!"
    new "うーん、わかるよ、化粧がボロボロよ！"

    # say L1146 bil
    old "Now I'm gonna have to re-do it all over again!"
    new "また全部やり直さなきゃならないのよ！"

    # say L1147 bel
    old "Hey, by the way, had you noticed how Mia is acting lately?"
    new "Hey、それにしても最近のミアの態度、気付いた？"

    # say L1148 bil
    old "Oh my god yeah! She's acting like a whore, flashing off in front of the whole classroom!"
    new "神様、そうよ！彼女、まるで娼婦みたいにふるまってるわ、クラス全員の前で見せびらかしてるんだから！"

    # say L1152 bil
    old "What was that?"
    new "何それ？"

    # say L1153 bel
    old "Like... a voice?"
    new "なんか...声？"

    # say L1159 bel
    old "Hmm, it's nothing, maybe somebody spoke in the hall."
    new "ん、大丈夫、多分廊下で誰かが話してただけだね。"

    # say L1160 bil
    old "Yeah, you're right."
    new "うん、そうね。"

    # say L1161 bel
    old "Ok, I'm ready."
    new "Ok、準備できました。"

    # say L1162 bil
    old "Yeah, me too, let's go. Anyway, as I was telling you, what the fuck is wrong with Mia?"
    new "うん、私も準備できてるよ。行こう。それに、さっき言っていたけど、ミアに何が起こってるの？一体何が問題なの？"

    # say L1167 pla
    old "Ok, ok, they are gone."
    new "分かった分かった、いなくなったよ。"

    # say L1168 den
    old "Ha! What's the matter Mia? Afraid of getting caught?"
    new "ハ！ミア、どうした？見つかるのが怖いのか？"

    # say L1169 den
    old "But I know you like people seeing your pussy! What's the big deal?"
    new "でもおまえのオマンコを見られるのが好きだって知ってんだよ！何が問題なんだ？"

    # say L1173 mia
    old "Ugh, let's just get this over with [pla]."
    new "うっ、早くこれで終わらせちゃおう [pla]。"

    # say L1182 pla
    old "Fuck, this is getting more and more risky!"
    new "くそ、これ越來越危險了啊！"

    # say L1183 pla
    old "At the end it won't matter if he tells on us or not!"
    new "最終的に、彼が言おうが言わまいが関係ないんだよ！"

    # say L1184 pla
    old "People will end up catching us anyway!"
    new "結局は、捕まってしまうだろう。"

    # say L1186 pla
    old "We have to do something."
    new "何か対策を講じなきゃ。"

    # say L1188 mia
    old "I'm also not happy with this. And It's already started to affect me, I can't even sleep well."
    new "私もこれには満足していません。そして、もう私にも影響が出始めています。よく眠ることもできません。"

    # say L1189 mia
    old "I'm starting to get severe anxiety again, and the nightmares have come back. But what can I do?"
    new "また重度の不安を感じ始めていますし、悪夢も戻ってきました。でも、何ができるっていうの？"

    # say L1190 mia
    old "We can't just go to the police! I don't want to lose my life! And now he has stuff that's even worse!"
    new "警察には行けないわ！ 生命を失いたくないの！ それに今や彼はもっと悪いことを持っているのよ！"

    # say L1191 pla
    old "I know this is hard, but there must be a solution."
    new "知ってるよ、これは大変なことだけど、解決策があるはずさ。"

    # say L1192 mia
    old "Well, if there is one I don't know what it may be."
    new "もし解決策があるなら、私にはそれが何なのかわかりません。"

    # say L1193 mia
    old "Let's just let's get out of here before someone comes again."
    new "ここから早く出ましょう、誰かがまた来る前に。"

    # say L1198 pla
    old "(She's feeling really bad, I'm sorry for her.)"
    new "彼女は今すごく調子が悪そうだな、本当に申し訳ないと思う。"

    # say L1199 pla
    old "I bet there's something else I could do..."
    new "他にも何かできることがあるかもしれないな…"

    # say L1200 pla
    old "Hmmm... But I do have the SexNote..."
    new "うーん… でも俺には SexNote があるんだ…"

    # say L1219 pla
    old "Hey Linett. How are you?"
    new "hey Linett、どうしてる？"

    # say L1220 lin
    old "Oh, [pla] I'm fine, thanks for asking, what about you?"
    new "あ、[pla] 元気だよ、ありがとう。あなたは？"

    # say L1221 pla
    old "Hmm, a little bit worried actually, I have a small problem that I would like you to help me with."
    new "Hmm、ちょっと心配なんだ Actually、小さな問題があって、君の手伝いが必要なんだ。"

    # say L1222 lin
    old "Oh, interesting."
    new "お、興味深いね。"

    # say L1224 pla
    old "Well, I know a person that's being blackmailed."
    new "WELL、知ってる人が脅迫されてるんだ。"

    # say L1226 lin
    old "Blackmailed? What is that?"
    new "黒mailer？それって何？"

    # say L1227 lin
    old "I've never heard of it, is it some type of tradition between humans?"
    new "聞いたことないけど、人間同士の間での伝統的なことなのかしら？"

    # say L1229 pla
    old "Uhh, somebody being blackmailed means that somebody else is threatening them with something that they care about."
    new "うーん、誰かが黒mailされているってことは、その人が気にしている何かで脅されているってことだよ。"

    # say L1230 pla
    old "That can be anything, something that belongs to them, or something they want."
    new "それは何でもいい、彼らのものだったり、欲しいものだったりだ。"

    # say L1231 pla
    old "And if you don't do what that person wants, they'll punish you with what they have against you."
    new "そして、その人が望むことをしなければ、彼らが持っているものを武器にして罰を与えるんだ。"

    # say L1232 lin
    old "Wow, that sounds horrible! You humans really are something else!"
    new "Wow、それって最悪だね！ あなたたち人間は本当に特別ね！"

    # say L1233 lin
    old "The type of things you do to each other is always surprising."
    new "あなたたちがお互いにすることって、いつも驚かされるわ。"

    # say L1234 pla
    old "Yeah, well, this person I know is going through that. So, I'm trying to help her."
    new "そうだな、知ってる人がそんな状況でさ。だから彼女を助けてやろうと思ってる。"

    # say L1235 lin
    old "That's very good, you should do that."
    new "それはとても良いことだね、そうすべきだ。"

    # say L1239 lin
    old "Well, I'm glad I was able to help you [pla]."
    new "まあ、私があなたを手伝うことができて良かったわ [pla]。"

    # say L1242 pla
    old "That wasn't the point."
    new "それは本題じゃなかったんだよ。"

    # say L1243 lin
    old "Oh, ok, so what is it?"
    new "あ、そう、じゃあ何のこと？"

    # say L1245 pla
    old "Uhhh, I'll tell you the story, this person we're talking about is my teacher."
    new "うーん、話すけど、この人の話題は俺の先生なんだ。"

    # say L1246 pla
    old "The thing is that some guy found some 'information' about her that she doesn't want anyone to see."
    new "問題は、誰かが彼女が見られたくない「情報」を見つけたことなんだ。"

    # say L1247 pla
    old "But there's no way of stopping him from putting it out there. At least not through anything we can do."
    new "でも、彼がそれを公開することを止める方法は俺たちにはないんだ。"

    # say L1249 pla
    old "So, I was thinking that maybe there's a way to do it through the SexNote."
    new "じゃあ、SexNoteを使って何とかできるかもしれないと思ってさ。"

    # say L1250 lin
    old "What kind of information is this?"
    new "この情報って何？"

    # say L1251 pla
    old "It's videos and pictures, they must be safe in his computer or something."
    new "ビデオと写真だ、彼のパソコンか何かに保管されてるはずだ。"

    # say L1253 lin
    old "Well, don't you think it would just be easier if you steal his computer and delete that?"
    new "じゃあ、彼のパソコンを盗んで、そのファイルを消す方が簡単じゃない？"

    # say L1255 pla
    old "I don't think that would do anything, he wouldn't be that stupid not to make any copies of it."
    new "そんなことしても無駄だよ、彼がコピーを取ってないわけがないからさ。"

    # say L1256 pla
    old "Besides, he also remembers it all, if he just tells the police or the press or anyone what he knows, they could find something."
    new "それに、彼は全部覚えてる。警察やマスコミに話せば、何か見つかるかもしれない。"

    # say L1257 lin
    old "Hmm, I see what you mean."
    new "うん、わかったような気がする。"

    # say L1258 lin
    old "So basically, what you want is a spell that'll change reality."
    new "つまり、現実を変える魔法が欲しいってことね。"

    # say L1259 pla
    old "U-uh, w-what? I-I don't think..."
    new "うーん、な、何？　俺はそう思ってないけど…"

    # say L1261 lin
    old "Well, that's what you need, isn't it?"
    new "そうじゃないの？　あなたが必要なのはそれじゃない？"

    # say L1262 lin
    old "I mean, you need every version of this information to disappear."
    new "つまり、この情報のすべてのバージョンを消す必要があるのよ。"

    # say L1263 lin
    old "That includes his memories, so that he won't go around telling it to people."
    new "それには彼の記憶も消さないとね、そうすれば彼は周りの人たちに話すこともなくなるだろう。"

    # say L1264 lin
    old "That's a very high requirement for a spell [pla]."
    new "その呪文の要求はかなり高いわね [pla]。"

    # say L1266 lin
    old "But... There's a way..."
    new "でも... 方法はあるの..."

    # say L1268 lin
    old "Something like that, there's a way to erase stuff magically... or at least their 'presence'."
    new "そんな感じで、魔法で消せる方法があるの……少なくとも彼らの‘存在’をね。"

    # say L1270 pla
    old "'Presence'? W- what do you mean?"
    new "「存在」って、何言ってるんだ？"

    # say L1272 lin
    old "I mean just that, you humans live in a world full of traces, all of your technology is marked with traces of who you are."
    new "つまり、あなたたち人間は痕跡に満ちた世界で生きているってこと。あなたの技術はすべて、あなたが誰なのかの痕跡で満ちている。"

    # say L1273 lin
    old "Like those pictures that you take of each other and then you can save or send."
    new "例えば、お互いに撮った写真を保存したり送ったりすることね。"

    # say L1274 lin
    old "But also memories, whatever traces left by time in the mind of someone else. That's also a 'presence'."
    new "でも、記憶もそうよね。時間によって誰かの心に残された痕跡も、それだって「存在」だよ。"

    # say L1275 lin
    old "All of that can be gone. With a big spell."
    new "全部が消えてしまうわ。大きな呪文を使えば。"

    # say L1276 lin
    old "I suppose that's what you mean when you say you want me to help you."
    new "あなたが私を手伝ってほしいって言っている意味だと思う。"

    # say L1277 pla
    old "Uhh, I mean, I think I do, but I'm not sure. I- I don't really understand all what you said."
    new "うーん、つまり、そうしたいとは思うけど、まだ確信ないんだ。君が言ったこと、全部理解できていないんだよ。"

    # say L1278 lin
    old "What I said is that I can use a spell that can erase all information about her, that's what you are asking me, right?"
    new "私が言ったのは、彼女のすべての情報を消去する呪文を使えるってことよ。それが君が欲しがってるものよね？"

    # say L1279 pla
    old "Yes! That's exactly what I need..."
    new "はい！それがまさに俺が必要なものなんだ…"

    # say L1280 pla
    old "And if you have another spell for the bad guy, you know, something to make him forget all about her."
    new "そして、もし悪役用の呪文があれば、你知道、彼が彼女のこと全部忘れちゃうようなやつ。"

    # say L1282 lin
    old "Yeah, with the same spell the bad human doing the 'blackmail' thing, he won't even remember her."
    new "同じ呪文で、悪い人間が‘脅迫’をしているときは、彼女のことすら覚えてないよ。"

    # say L1283 lin
    old "Everything about her would be forgotten."
    new "彼女のことを全部忘れてしまうわ。"

    # say L1284 lin
    old "If he can't remember anything about her, and all the information he has is also gone. That would solve your problem, would it not?"
    new "彼が彼女について何も思い出せなくなって、持っている情報も全部消えたら、あなたの問題は解決するでしょう？"

    # say L1285 pla
    old "Wow! Yeah, that's perfect!"
    new "Wow！ そうだな、それなら最高だ！"

    # say L1286 lin
    old "All right, this spell is somewhat difficult to execute, but is possible."
    new "大丈夫、この呪文は少し難しいけど、可能だよ。"

    # say L1288 pla
    old "Ok, what do I need?"
    new "よし、何が必要なんだ？"

    # say L1290 lin
    old "Hmm, to be honest, you're still not very good with magic..."
    new "うーん、正直に言うと、まだ魔法には慣れてないよね…"

    # say L1291 lin
    old "So, I'll have to prepare a lot of things beforehand to make it easier for you to use that spell."
    new "それなら、私が事前にたくさんの準備をして、あなたがその魔法を使いやすいようにするわ。"

    # say L1292 pla
    old "Oh, it can't be done today? I mean, I have a bit of an urgency with this..."
    new "今日じゃ無理なのか？急いでるんだよ…"

    # say L1293 lin
    old "No, I'll need a couple of days to get everything ready, we can't afford any mistakes with this."
    new "うーん、準備に数日かかるわ。これには失敗が許さないからね。"

    # say L1294 pla
    old "Hmm, I guess that's fine if there's no way to do it now."
    new "Hmm、仕方ないな。今すぐって無理なら、しょうがないよ。"

    # say L1295 pla
    old "Thanks for your help Linnet, I'm counting on you."
    new "リンネット、ありがとうな。君に頼むよ。"

    # say L1296 lin
    old "I'll do my best to help you, don't worry."
    new "心配しないで、私が精一杯手伝うから。"

    # say L1304 pla
    old "I knew it, magic should be useful for something."
    new "魔法が何か役に立つと思っていたんだ。"

    # say L1305 pla
    old "With this I'm sure I'll be able to help Ms. Mia."
    new "これでミア先生のお手伝いができそうだ。"

    # say L1328 mia
    old "[pla]... I'm gonna need you to come to the classroom with me."
    new "[pla]... 教室に連れて行ってくれる？"

    # say L1329 pla
    old "Oh, not Denzel again, come on. What does he want now?"
    new "ああ、またデンゼルかよ、冗談だろ。今何 Want なのか？"

    # say L1330 mia
    old "Just come with me."
    new "一緒に来なさい。"

    # say L1345 mia
    old "Denzel said he wanted to talk to both of us, let me call him and I'll put the call on speaker."
    new "デニゼルが私たち二人と話したいって言ってたから、電話してスピーカーに出すわ。"

    # say L1350 mia
    old "Denzel, hi."
    new "デニゼル、こんにちは。"

    # say L1351 den
    old "Hi there Ms. Mia! How are you? Is my good friend [pla] over there?"
    new "ミアさん、こんにちは！元気ですか？私の親友[pla]はいますか？"

    # say L1352 pla
    old "I'm here."
    new "俺はここにいる。"

    # say L1354 den
    old "Excellent, excellent! Ok, guys, I've been thinking, and I came to a conclusion."
    new "素晴らしい、素晴らしい！みんな、考えていた結果、結論が出たんだ。"

    # say L1356 den
    old "Well, I've decided that it's time for you two to take your relationship to the next level."
    new "まあ、お前ら二人の関係を次のレベルに引き上げる時期が来たと思ったんだ。"

    # say L1357 den
    old "Given that you already consummated your teacher-student love."
    new "既に先生と生徒の愛を成就しているんだからな。"

    # say L1359 den
    old "I think you need to take the next step?"
    new "次のステップを踏むべきだな？"

    # say L1360 pla
    old "The next step? We already had sex, what do you even mean?"
    new "次のステップ？ 俺たちもうセックスしたじゃん、何を言ってるんだよ？"

    # say L1361 pla
    old "Stop beating around the bush and tell us already!"
    new "まわりくさってもしょうがないから、早く言っちまえよ！"

    # say L1362 den
    old "Easy there buddy! Trust me, you'll like what I have in store for you guys today."
    new "落ち着いてくれ、兄貴！ 心配するな、今日の企画は君たちが気に入るはずだ。"

    # say L1365 den
    old "Well, I want you to fuck Mia in the ass. It's time she gets her ass fucked."
    new "まあ、ミアのアナルを犯してほしいんだ。そろそろ彼女もアナルを犯される番だよ。"

    # say L1367 pla
    old "W-what?!"
    new "何？！"

    # say L1368 mia
    old "I-I can't do that, I've never done it before! Not even when I was a porn actress!"
    new "そんなこと、できないわ、私、まだ経験ないのよ！アダルト女優をやってたときでも一度もなかったのよ！"

    # say L1369 den
    old "Well, I guess there's a first time for everything, am I right?"
    new "まあ、すべてには初めてがあるよね？"

    # say L1370 den
    old "Of course you'll do it on video call with me so that I can record it."
    new "もちろん、ビデオ通話でやってくれれば、録画できるんだ。"

    # say L1371 den
    old "We wouldn't want to waste that good material right?"
    new "その良い素材を無駄にするわけにはいかないだろう？"

    # say L1372 pla
    old "You're crazy if you think we'll do this!"
    new "お前がそんなこと考えるなら狂ってるぜ！"

    # say L1374 pla
    old "This is way too much! We're not doing anything!"
    new "これはやりすぎだ！何もする気ないよ！"

    # say L1376 den
    old "Aww, this again dude?"
    new "あー、またこれかよ？"

    # say L1377 den
    old "Come on [pla], don't you ever get bored of this routine? It really annoys me that you say no to everything I tell you to do."
    new "Come on [pla]、このルーチンに飽きないのかよ？ お前が何を言っても否定するのって、本当に我慢ならないんだよ。"

    # say L1378 den
    old "Only to then turn around and do it anyway."
    new "でも結局はやってくれるんだよな。"

    # say L1379 den
    old "It really tests my patience, so shut up and do it!"
    new "本当に我慢の限界だよ、だから黙ってやれ！"

    # say L1380 pla
    old "We're not doing anything!"
    new "何もする気はないって！"

    # say L1381 mia
    old "W- wait [pla]!"
    new "待って、[pla]！"

    # say L1382 mia
    old "You know we have to do it. We have no choice."
    new "私たちに選択肢なんてないの。これをするしかないのよ。"

    # say L1383 mia
    old "If what he has on us comes out we'll both be ruined!"
    new "もし彼が私たちについて持ってる情報が出たら、二人とも台無しだわ！"

    # say L1384 pla
    old "No! Think about it!"
    new "ダメだ！よく考えてみろ！"

    # say L1385 pla
    old "What is it going to be next time?! He already made us do all those things! Next time he'll make us fuck in the principals office!"
    new "次はどんなことさせられるんだよ！？ 既にあれだけのことをさせてきたのに、次は校長室でセックスさせやがるだろう！"

    # say L1386 mia
    old "But we have to!"
    new "でも、やらなくちゃならないじゃない。"

    # say L1387 pla
    old "No we don't, and I won't do anything!"
    new "俺たちはそんなことしなくていい、そして何もするつもりはない！"

    # say L1388 den
    old "That so? Well, then I guess you leave me no choice."
    new "そうか？じゃあ、選択肢はもうないということか。"

    # say L1389 den
    old "I suppose this was gonna happen anyway, I was already getting bored with you two."
    new "まあ、これは予想通りだったな、もう君たちには飽きられていたんだ。"

    # say L1390 mia
    old "Wait! Wait! Give us a minute, I can convince him!"
    new "待って！ 待って！ ちょっとだけ時間をくれない？ 私が彼を説得できるわ！"

    # say L1391 den
    old "You already heard him Mia, he's not gonna do anything."
    new "ミア、彼の言葉はもう聞いただろ、何もしないって言ってるんだ。"

    # say L1392 den
    old "So, I guess he's fine with me sending the information out."
    new "じゃあ、俺が情報を流してもいいってことだな。"

    # say L1393 den
    old "And that's what I will do, I'll send it straight to your school's principal."
    new "そしてそれが俺がやることだ、君の学校の校長に直接送るよ。"

    # say L1394 den
    old "I'll be eager to see how things pan out for you 'Ms.' Mia."
    new "君がどうなっていくのか、楽しみにしてるよ、ミアさん。"

    # say L1395 mia
    old "No, please don't' do this!"
    new "お願い、そんなことはしないでください。"

    # say L1396 den
    old "I have to say it was an honor to be a student of Mia the pornstar."
    new "ミアさんのPornstarとしての授業は光栄でしたね。"

    # say L1397 den
    old "I bet that when things blow out, you'll get that job back in no time."
    new "きっと大騒ぎになったら、すぐに元の仕事に戻れるだろうな。"

    # say L1399 den
    old "And [pla], you see what you fucking did? I hope you're happy with that!"
    new "そして[pla]、お前がやってくれたことを見ろよ。満足したか？"

    # say L1400 mia
    old "Wait... Hello? Denzel?? Hello?"
    new "待って…誰かいる？デンゼル？？聞こえる？"

    # say L1401 mia
    old "Oh, no, no, no, no, no!"
    new "Oh、no、no、no、no、no！"

    # say L1404 mia
    old "What the fuck you did [pla]! I have to call him again..."
    new "何したの、[pla]！また電話しなきゃならないのよ..."

    # narrator L1406 
    old "... Ringing... {w} Ringing..."
    new "... 鳴ってる... {w} 鳴ってる..."

    # say L1408 mia
    old "FUCK! HE DOESN'T ANSWER!"
    new "くそっ！ 全然出ないんだ！"

    # say L1411 mia
    old "Oh my gosh! Why did you do that? You idiot!!"
    new "ああっ！ なんでそんなことしたの？ ばかじゃないの！！"

    # say L1412 mia
    old "Don't you care what will happen to you?! Or me?!"
    new "あなたがどうなるか気にしてないの？ 私のことなんて？！"

    # say L1413 mia
    old "You said you wanted to help me, and this is what you do?!!"
    new "あなたは私を助けるって言ったのに、これがあなたのやること？！！"

    # say L1414 mia
    old "You fucking asshole! What are we going to do now?!"
    new "あなたってほんとクソ野郎だね！これからどうするの？！"

    # say L1415 pla
    old "You know he was going to do this sooner or later. He's that type of bastard."
    new "君が言う通り、彼はそうするタイプの野郎だよ。sooner or later こうするだろうって思ってた。"

    # say L1416 mia
    old "Well, he did it now! So what are we going to do?!"
    new "まあ、彼はやっちゃったわ！じゃあ、私たち何するの？"

    # say L1417 pla
    old "Calm down, listen, look, he kept talking about a mail."
    new "落ちついて、聞いて、見て、彼はメールのことをずっと話してたんだ。"

    # say L1418 pla
    old "Which means he's gonna have to send it through some physical means, a cd or a usb."
    new "つまり、彼はそれを物理的な手段で送らなきゃならないってことだな。CDかUSBを使って。"

    # say L1419 mia
    old "So?!"
    new "そうなの？"

    # say L1420 pla
    old "So, all we have to do is intercept it before it arrives. Even if it's an express delivery, that's going to take a little while."
    new "じゃあ、俺たちはそれを届く前に止めるだけだ。たとえ急ぎの配送でも、少し時間はかかるだろう。"

    # say L1421 mia
    old "And then what? Even if we stop that, he still has copies!"
    new "それからどうするの？ それが止まっても、彼にはコピーがあるのよ！"

    # say L1422 mia
    old "He could just send it to the police! Or the news! Or somewhere else!"
    new "警察に送っちゃうかもしれないし、ニュースにも流すかもしれないし、他のところにも送るかもしれないわ！"

    # say L1423 mia
    old "Then what?!"
    new "それじゃどうするの？！"

    # say L1424 pla
    old "Ha, I've got a way to deal with that."
    new "ハ、心配するな、対策はある。"

    # say L1425 pla
    old "Listen, I'm going to need you to trust me on this, ok?"
    new "聞いてくれ、この件については俺を信じてくれないと困るんだ、いいかな？"

    # say L1426 pla
    old "If everything goes according to my plan, not only will everything remain a secret, you'll never have to worry about it ever again."
    new "計画通りに行けば、秘密は守られるだけでなく、君はこれ以上心配することもないよ。"

    # say L1428 mia
    old "What are you going to do?"
    new "何をするつもりなのかしら？"

    # say L1429 pla
    old "That... I can't tell you, but trust me, everything's going to be alright."
    new "それが…言えないけど、信じてくれ、大丈夫にするから。"

    # say L1430 pla
    old "All I have to do is go check if everything's ready."
    new "準備ができてるかどうか確認に行くだけさ。"

    # say L1432 mia
    old "What are you talking about? You're not making any sense!"
    new "何を言ってるの？全然意味がわからないよ！"

    # say L1433 pla
    old "I know you don't get it right now, but you'll see... Please just trust me."
    new "今すぐは理解できないだろうけど、後でわかるさ… ただ、信じてくれ。"

    # say L1434 mia
    old "I guess I have no choice..."
    new "そうね、仕方ないわね…"

    # say L1435 pla
    old "For now, we have to deal with what Denzel's about to send to the school principal."
    new "今は、デンゼルが校長先生に送ろうとしているものに対処しなきゃならないんだ。"

    # say L1436 pla
    old "That's the priority."
    new "それが最優先だ。"

    # say L1437 mia
    old "What do you propose then?"
    new "それじゃ、何を提案しますか？"

    # say L1438 pla
    old "I think we're gonna have to steal it."
    new "俺たちが盗むしかないと思うよ。"

    # say L1439 pla
    old "For now just stay here and check if a delivery guy comes, I'll go to my house to check on things."
    new "今はここでいて、配達の人来ないか見てろ、俺は家に行って様子を見るよ。"

    # say L1441 mia
    old "Again, what are you talking about?!"
    new "また、何を言っているの？！"

    # say L1442 pla
    old "As I said, you'll understand later."
    new "言った通り、後で分かるよ。"

    # say L1443 pla
    old "But I really have to rush home, will you stay here and check if anything arrives?"
    new "でも本当に急いで帰らないと、君はここにいて何か来たら確認してくれる？"

    # say L1444 mia
    old "Yes, fine, I'll be here. You better know what you're doing."
    new "うん、わかったわ。ここにいるから。あなたが何を考えているのか、ちゃんと分かってるといいけどね。"

    # say L1446 pla
    old "I really think I do. I'll be back soon."
    new "本当にそう思っているよ。すぐに戻るから。"

    # say L1451 mia
    old "I can't believe it, now everything depends on him..."
    new "信じられない、今となっては彼次第になってしまった..."

    # say L1457 pla
    old "Hey! Linnet!"
    new "Hey！ リネット！"

    # say L1458 lin
    old "Oh, hi [pla]."
    new "あ、こんにちは [pla]。"

    # say L1459 pla
    old "I'm going to need that spell of yours right now."
    new "今すぐ君の魔法が必要だな。"

    # say L1460 pla
    old "Do you think we can use it?"
    new "君が使えると思う？"

    # say L1462 lin
    old "No, we can't, this is a process [pla], and we can't just force it out. Sorry."
    new "ダメよ、これにはプロセスが必要で [pla]、無理やり出せないの。ごめんね。"

    # say L1463 pla
    old "Oh really?! Fuck I really need it now..."
    new "ほんとですか？！くそ、今すぐ必要なんだ..."

    # say L1464 pla
    old "When do you think we'll be able to do it?"
    new "いつ頃できると思う？"

    # say L1465 lin
    old "Well, if I'm quick with this, tomorrow, I'll need another day."
    new "ええ、急げば明日にはできるけど、もう一日必要になるかな。"

    # say L1467 pla
    old "Hmm... Are you sure it'll be ready tomorrow?"
    new "うーん… 明日には本当にできるのか？"

    # say L1468 lin
    old "Yeah, it'll be difficult, but I can make it."
    new "大丈夫、難しいけど、何とかなるわ。"

    # say L1469 pla
    old "Ok, then I guess we'll have to find a way to make it tomorrow."
    new "分かった、じゃあ明日までに何とかする方法を見つけないとね。"

    # say L1470 pla
    old "Please help me with that, I really need it as soon as possible."
    new "君の助けが必要だ、できるだけ早く。"

    # say L1471 lin
    old "Ok then I will continue working on the spell."
    new "わかりました、それなら私、呪文の続きを進めるわ。"

    # say L1483 mia
    old "Hey, what happened? I have been waiting for you... Did you get what you need? Is everything solved?"
    new "Hey、何があったの？ 私、あなたを待っていたのよ… 必要なもの手に入れたの？ すべて解決したの？"

    # say L1484 pla
    old "Hmm, n-not really."
    new "うーん、そうでもないな。"

    # say L1485 pla
    old "It's almost ready, but it's still going to take a little while."
    new "もうすぐ完成するんだけど、まだ少し時間かかるよ。"

    # say L1486 pla
    old "At least until tomorrow."
    new "少なくとも明日までだよ。"

    # say L1487 mia
    old "I still don't understand, what's going to take until tomorrow?"
    new "まだよくわからないの、何が明日までかかるの？"

    # say L1489 pla
    old "Just trust me. After tomorrow everything will be solved."
    new "ただ信じてくれ。明日过后一切都将解决。"

    # say L1491 mia
    old "Are you going to kill Denzel?"
    new "デニゼルを殺すの？"

    # say L1492 pla
    old "What?! No! How can you think something like that?"
    new "何っ！？ そんなこと考えたかね！絶対にしないって！"

    # say L1494 pla
    old "Just relax. You'll get it tomorrow.."
    new "ただリラックスして。明日には分かってるよ。"

    # say L1495 pla
    old "But we're gonna have to deal with the delivery."
    new "でも、デリバリーの対処しなきゃならないんだ。"

    # say L1496 pla
    old "We have to find a way to steal away what Denzel sent today."
    new "デニゼルが今日送ったものを手に入れる方法を見つけなきゃならない。"

    # say L1497 pla
    old "So that the principal won't see them."
    new "そうすれば校長先生には見られないね。"

    # say L1498 mia
    old "Well, she's already gone home. So even if it arrives today, she won't see it until tomorrow."
    new "WELL、彼女はもう家に帰っちゃったから。今日届いたとしても、彼女が見るのは明日になるわ。"

    # say L1499 pla
    old "Ok, so I suppose we'll have to steal it tomorrow before she sees it."
    new "分かった、じゃあ明日彼女が見る前に盗むしかないな。"

    # say L1500 pla
    old "We'll have to arrive very early. Before she does."
    new "早朝に到着しないとね。彼女が来る前に。"

    # say L1501 pla
    old "After that everything will be fine."
    new "その後は大丈夫だよ。"

    # say L1503 mia
    old "It will? But what are you going to do?"
    new "そうなの？でも、あなたは何をするの？"

    # say L1504 pla
    old "I just can't tell you."
    new "俺には言えないんだよ。"

    # say L1506 mia
    old "Damn, ok, whatever. You better make whatever you do really work..."
    new "ダメだ、わかった、何でもいいわ。でもあなたがやること、絶対にうまくいくようにしなさいね。"

    # say L1507 pla
    old "Don't worry."
    new "心配しないで。"

    # say L1508 mia
    old "So, we'll meet here tomorrow?"
    new "じゃあ、明日ここで会うわね？"

    # say L1510 pla
    old "Yeah, before classes."
    new "うん、授業の前に会おう。"

    # say L1511 mia
    old "Ok, that's it then. Don't be late."
    new "じゃあ、それじゃあ決まりね。遅れないでね。"

    # say L1512 pla
    old "Of course not."
    new "もちろん、遅れないよ。"

    # say L1513 mia
    old "All right, see you tomorrow then."
    new "では、明日会いましょうね。"

    # say L1514 pla
    old "Ok, don't worry tomorrow this will all be over."
    new "大丈夫、明日には全て終わってるから。"

    # say L1533 pla
    old "Hi, Ms. Mia."
    new "こんにちは、ミアさん。"

    # say L1534 mia
    old "At this point I think just Mia's fine."
    new "この段階では、ミアでいいですよ。"

    # say L1536 mia
    old "Ok, so I came in very early to check that the coast is clear."
    new "はい、そうですね。早朝に来て確認したんです。"

    # say L1537 mia
    old "Nobody's around."
    new "誰もいません。"

    # say L1538 pla
    old "That's perfect, so we should be able to get it with no problem."
    new "それが良かった、だから問題なく手に入れられるだろう。"

    # say L1539 mia
    old "Ok, let's go, we need to check out the principal's office."
    new "じゃあ、行こう。校長先生のオフィスをチェックしなきゃ。"

    # say L1554 pla
    old "Have you found anything?"
    new "何か見つけたか？"

    # say L1555 mia
    old "Nothing, everything look's fine."
    new "何も見つかりませんでした、すべてが普通のようです。"

    # say L1556 pla
    old "Hmm, there must be something."
    new "Hmm、何かあるに違いない。"

    # say L1566 pla
    old "Ah, that must be it."
    new "ああ、それか。"

    # say L1568 pla
    old "Why else would there be a CD on her desk?"
    new "なぜ彼女の机にCDがあるのか？それにはこの理由しかないだろう。"

    # say L1569 mia
    old "Yeah, you're probably right. It must've arrived during the evening and the janitor put it here."
    new "そうね、多分そうよ。夜に届いて、清掃員がここに置いていったのかもしれないわ。"

    # say L1572 mia
    old "Ok, so what do we do now?"
    new "じゃあ、次はどうするの？"

    # say L1573 pla
    old "What we have to do is just..."
    new "俺たちがしなくちゃいけないのはただ…"

    # say L1575 mia
    old "Wait! I just heard something! I think someone's coming."
    new "待って！何か聞こえたわ！誰か来るみたいよ。"

    # say L1576 mia
    old "Quick get in that closet."
    new "早くそのクローゼットに隠れてください。"

    # say L1588 pla
    old "What are we going to do?"
    new "何するんだ？"

    # say L1589 mia
    old "Shhhh, someone's coming, they'll hear us."
    new "シャッ、誰か来るわ、聞かれちゃうよ。"

    # say L1597 dir
    old "Ok, I see some correspondence arrived yesterday. What do we have here?"
    new "分かった、昨日何か手紙が届いていたな。何が書かれてるんだ？"

    # say L1600 dir
    old "Oh! Not the auditing process again!"
    new "ああ！また監査の手続きかよ！"

    # say L1603 dir
    old "The day just started and it's already ruined, everytime they do it we have to jump through so many hurdles."
    new "今日が始まったばかりなのに、もう台無しだな。彼らが来るたびに、こんなに面倒なことになるんだ。"

    # say L1608 dir
    old "{i}*Sigh*{/i} I guess there's nothing to do, I'll just deal with it."
    new "{i}*ため息*{/i} しょうがないな、仕方ないからさ、対処するしかないよ。"

    # say L1609 dir
    old "But first..."
    new "まずは…"

    # say L1615 dir
    old "Nothing wrong with dealing with some stress early before work."
    new "仕事前にストレスを少しでも解消しておくのは悪いことじゃないさ。"

    # say L1616 dir
    old "I don't usually do this here at the office, but what the hell."
    new "ここでは普段しないけど、仕方ないな。"

    # say L1617 dir
    old "It's been quite a while, I think it will be fun."
    new "久しぶりだな、きっと楽しいだろう。"

    # say L1620 mia
    old "What the hell? Do you actually have a boner right now?"
    new "何それ？今、本当に Erect してるの？"

    # say L1621 pla
    old "S- sorry, I just can't help it."
    new "す、すみません、我慢できないんです。"

    # say L1622 pla
    old "It's not my intention."
    new "意図したわけじゃない。"

    # say L1623 mia
    old "Ugh, you're incredible, I can't believe you."
    new "うーん、あなたは本当にすごいわ、信じられない。"

    # say L1633 dir
    old "Mmm, oh yeah, this is just what I needed."
    new "うん、これだ、まさに必要だったんだ。"

    # say L1634 dir
    old "Oh! It's so good!"
    new "ああ！ 素晴らしい！"

    # say L1635 dir
    old "That's it, yeah, yeah."
    new "そうだね、そうだね。"

    # say L1638 pla
    old "Wow, she is..."
    new "すごい、彼女は…"

    # say L1639 mia
    old "Shhh..."
    new "しーっ、静かにしなさい、話していると見つかるわよ。"

    # say L1646 pla
    old "W-what are you doing?"
    new "何してるんだ？"

    # say L1647 mia
    old "Shhh, be quiet, she'll find us if you keep talking."
    new "しーっ、静かにしなさい、話していると見つかるわよ。"

    # say L1648 pla
    old "But you're- ..."
    new "でも君は……"

    # say L1649 mia
    old "Shhh, just shut up!"
    new "しーっ、黙って！"

    # say L1657 dir
    old "Fantastic!"
    new "素晴らしい！"

    # say L1658 dir
    old "But I better go check on things around the school before the students arrive."
    new "でも、学生が来る前に学校の周りをチェックしておいた方がいいな。"

    # say L1667 mia
    old "Mmm! Oh! Oh yeah!"
    new "ああん！　そうよ！"

    # say L1669 pla
    old "Hmm, M-Mia, the principal just left."
    new "俺、校長先生がさっき出て行ったみたいだよ。"

    # say L1670 pla
    old "I think we better get out of here before she or anybody else comes back."
    new "俺たち、早くここから出よう。誰かが戻ってくる前にさ。"

    # say L1671 mia
    old "Uh, what? Oh yeah!"
    new "え、何？ああ、そうね！"

    # say L1672 mia
    old "You're right, l- let's get out of here."
    new "そうですよね、さっさとここから出ましょう。"

    # say L1684 mia
    old "Ok, we have to go then, we can't keep wasting any more time here."
    new "じゃあ、行かないとね、ここで時間を使い果たすわけにはいかないから。"

    # say L1685 pla
    old "Yeah, I guess you're right, don't forget to bring the CD."
    new "そうだな、君が言う通りだ、CDも忘れずに持って行こう。"

    # say L1707 mia
    old "Phew, it's good that we made it."
    new "ふう、無事に来られてよかったわ。"

    # say L1708 mia
    old "I can't believe we almost got caught. Hehe, right?"
    new "信じられないくらい危なかったわね、へへ、そうよ？"

    # say L1709 pla
    old "Eh, yeah, you're right haha, that was close, phew!"
    new "ええ、そうですね、哈哈、危なかったですね、ふう！"

    # say L1711 mia
    old "What now then?"
    new "次は什麼呢？"

    # say L1713 pla
    old "Well, we're relieved, but we're not sure if this really is what we were looking for."
    new "まあ、安心はしてるけど、これが本当に探してたものかどうかはまだ疑問だな。"

    # say L1714 pla
    old "So we better check in the computer to see if it is."
    new "じゃあ、コンピューターで確認した方がいいな。"

    # say L1716 mia
    old "Yeah, you're right, we should check."
    new "うん、そうね、確認した方がいいわ。"

    # say L1722 pla
    old "That's very weird, there only seems to be a single video."
    new "それは変だな、ビデオが一つしかないみたいだ。"

    # say L1723 pla
    old "Nothing else."
    new "他には何もなかった。"

    # say L1724 mia
    old "Well, open it, we need to see if it is."
    new "開けてみましょう、確認が必要ですから。"

    # say L1734 pla
    old "Woah! I wasn't expecting that."
    new "Woah！ そんなのは予想外だったよ。"

    # say L1735 mia
    old "Oh my god! It is."
    new "ああっ！ 本当に。"

    # say L1736 mia
    old "I can't believe he actually found something."
    new "信じられない、彼が本当に何か見つけてしまったのね。"

    # say L1737 mia
    old "It seems the producers didn't get rid of everything as I wanted them to."
    new "プロデューサーたちが、私が望んだ通りすべてを削除しなかったようですね。"

    # say L1738 mia
    old "How did Denzel get his hands on this?"
    new "デニゼルは一体どうやってこれを見つけたのかしら？"

    # say L1753 dir
    old "I need to see you both in my office."
    new "君たち二人を俺のオフィスに来い。"

    # say L1754 dir
    old "So come to my office as soon as you're done working on whatever it is you're working on that computer."
    new "じゃあ、今そのパソコンでやってる仕事終わったら俺のオフィスに来てくれ"

    # say L1761 mia
    old "W-what? Why does she want to see us there?"
    new "えっと、どうして彼女が私たちを呼びたいんでしょうか？"

    # say L1763 mia
    old "Oh no, she found out we were there, or maybe Denzel sent her another thing!"
    new "ああ、やばい、彼女に気づかれたのか、それともデンゼルがまた何か送ったのか！"

    # say L1765 pla
    old "Calm down, calm down, there's no reason why she would know we were in her office."
    new "落ち着け、落ち着け、彼女が俺たちが彼女のオフィスにいたことを知ってる理由なんてないさ。"

    # say L1766 pla
    old "And why would Denzel send her another CD?"
    new "なぜデンゼルがまた彼女にCDを送る必要があるんだ？"

    # say L1767 mia
    old "Then what do you think she wants to talk to us about?"
    new "じゃあ、彼女は私たちと何について話したいと思っているの？"

    # say L1768 pla
    old "I guess we have to talk to her."
    new "俺たちは話すしかないみたいだね。"

    # say L1770 mia
    old "{i}*Sigh*{/i} Ok, let's go then, I guess we'll have to see."
    new "{i}……{/i} 仕方ないわね、行こう。"

    # say L1777 mia
    old "Why aren't you walking?"
    new "なぜ歩かないの？"

    # say L1778 pla
    old "Hmm, the thing is, I-I kinda can't right now."
    new "うーん、実は今ちょっと無理なんだ。"

    # say L1779 mia
    old "Why not?"
    new "なぜなの？"

    # say L1780 pla
    old "Uhhh...I just need a few minutes... I mean after I watched your video."
    new "うーん……ちょっと待っててくれ、ミア。さっき君の動画を見たから、今ちょっと……"

    # say L1784 mia
    old "You're really unbelievable, you know?! I can't believe you actually got a boner from that!"
    new "あなたってほんと信じられないわね！そんなもの見ただけで硬くなっちゃうなんて！"

    # say L1785 pla
    old "Well, I'm still a man, you know? It's not like I want to go around with a boner."
    new "まあ、俺も男だしな？こんな状態で歩き回りたいわけじゃないけど。"

    # say L1786 mia
    old "Ugh, shut up. Just get rid of it, will you?"
    new "うっせーよ、早く片付けてよ。"

    # say L1787 pla
    old "Get rid of it? How?"
    new "消す？どうする？"

    # say L1788 mia
    old "How do you think genius? Jerk off!"
    new "どうやって処理すればいいと思ってるの？ ゲニウス、早く手ぇ動かしなさいよ！"

    # say L1789 mia
    old "And do it quickly the principal is waiting for us."
    new "早くしなさい、校長先生が待ってるんだから。"

    # say L1790 pla
    old "I don't think that will work, I mean, I'm very nervous, and I just don't have my mind in it."
    new "そんなのはうまくいかないと思う、だって緊張してるし、頭が全然それどころじゃないんだ。"

    # say L1791 mia
    old "I just can't believe this."
    new "信じられないわ。"

    # say L1792 mia
    old "Ughh... We have to do it now before he comes back..."
    new "ううっ… 今すぐにやらないとダメよ、彼が戻ってくる前に…"

    # say L1793 pla
    old "Just give me a couple of minutes..."
    new "ちょっと待って、数分だけ…"

    # say L1794 mia
    old "Hmm, you know what, I'll do it then."
    new "うーん、そうね、私がやることにしよう。"

    # say L1804 mia
    old "What do you think genius? I'm making you cum."
    new "何考えてるの、天才？私が君をイかせるわ。"

    # say L1805 mia
    old "We can't take too much time, the principal is waiting for us."
    new "時間を取りすぎちゃダメよ、校長先生が待ってるから。"

    # say L1806 mia
    old "And since you can't do it yourself, I guess I'll have to do it for you."
    new "それなら私があなたのためにやってあげるしかないわね。"

    # say L1808 mia
    old "Come on [pla], it's not something we haven't done before, just focus on finishing quickly."
    new "さあ[pla]、以前やったことがあるんだから、素早く終わらせようね。"

    # say L1825 dir
    old "You took a while to come..."
    new "君が来るのに時間がかかったな…"

    # say L1826 mia
    old "Ah, yeah, sorry. We didn't mean to."
    new "あ、うん、すみません。予定外だったの。"

    # say L1827 mia
    old "It's just that the... thing we were doing took a little longer than expected."
    new "その…やっていたことが思っていたより長くかかっちゃったね。"

    # say L1830 dir
    old "Ok, listen up. Mia, last week you gave me a report..."
    new "おい、聞け。ミア、先週君が俺に提出したレポートについてだが…"

    # say L1832 dir
    old "In which [pla] appeared as someone to pay attention to because he wasn't performing up to the standards of the school. Right?"
    new "その報告で [pla] が注目すべき存在として挙がっていたんだよな、成績が学校の基準に達していなかったからだろ？"

    # say L1834 mia
    old "Y-yeah, that's right. Is there a problem with it ma'am?"
    new "うーん、そうですよ。何か問題があるんですか、先生？"

    # say L1835 dir
    old "Not per se, after all, there's nothing unusual about a student needing to improve his grades."
    new "特にそうじゃないよ、君。生徒が成績を上げる必要があるのは、特別なことじゃないからね。"

    # say L1836 dir
    old "The problem is that this morning I received a letter informing me we're about to be audited by the superintendent."
    new "問題は、今朝、教育長から監査を受けるという手紙を受け取ったことだよ。"

    # say L1838 dir
    old "And it would be very good for us if we don't have a student about to be expelled due to his poor performance."
    new "そして、成績が悪くて退学寸前の生徒がいないのは、私たちにとってとても良いことだよ。"

    # say L1840 dir
    old "So, Mia, I normally wouldn't do this, but I need you to start helping him personally with his studies."
    new "ミア、普段なら言わないんだけど、彼の勉強を個人的に手伝ってくれないか。"

    # say L1842 mia
    old "Sorry? Do you want me to tutor him? Personally?"
    new "すみません？私に彼の勉強を個人的に教えてほしいんですか？"

    # say L1843 dir
    old "Exactly, think of it as extra classes for him. It must be done."
    new "そうだ、特別な補習と考えてくれ。絶対にやってもらう必要があるんだ。"

    # say L1844 dir
    old "We can't have any bad marks for the school qualification."
    new "学校の資格を得るために悪い成績はダメだ。"

    # say L1845 mia
    old "I see, great."
    new "はい、それはいいですね。"

    # say L1846 dir
    old "Great?"
    new "すごい？"

    # say L1847 mia
    old "Uh, I mean, I think it's great that we can get a good score just by doing that."
    new "ええ、つまり、それだけでいい点数が取れると考えてるんです。"

    # say L1849 mia
    old "Actually ma'am, [pla]'s notes have been getting a lot better recently."
    new "実は、[pla]のノートは最近ずいぶん良くなってきています。"

    # say L1851 mia
    old "I'm sure that his grades will be on par with everyone else's when the auditing starts."
    new "審査が始まったら、彼の成績は他のみんなと同等になると思います。"

    # say L1852 dir
    old "Well, that's great to hear. I trust you have this Mia."
    new "なるほど、それは良いニュースだね。ミア、君の言う通りだと思う。"

    # say L1853 dir
    old "Now, I'm very busy, so you two can go back to class."
    new "じゃあ、俺は今すごく忙しいから、君たちは授業に戻っていいぞ。"

    # say L1854 mia
    old "Sure ma'am. Thank you."
    new "はい、そうします。ありがとうございます。"

    # say L1868 mia
    old "{i}*Sigh*{/i} Oh my god, that was very close."
    new "{i}……{/i} ああ、神様、それは危なかったわ。"

    # say L1869 mia
    old "I thought we were done for. I was sure she had received another copy of the video from Denzel or something."
    new "もう終わったと思っていたのに、あのビデオのコピーをデンゼルが送ったのかと思ったわ。"

    # say L1870 pla
    old "Yeah, me too, I'm glad we managed to avoid the trouble."
    new "そうだな、俺もそう思って安心した。無事に事態を収められて良かった。"

    # say L1871 mia
    old "Well, that was just the start of it, we still have to deal with Denzel."
    new "まあ、それが始まりに過ぎないの。デニゼルとの問題はまだ残ってるわ。"

    # say L1872 mia
    old "Which by the way, you still haven't told me anything about how you plan on doing that."
    new "それに言っておくけど、まだどうやって対処するつもりなのか教えてくれてないわね。"

    # say L1873 pla
    old "It's ok, it should be ready by now, I think I just have to go handle that."
    new "大丈夫、今頃は準備できてるはずだ。俺が行って片付けるだけさ。"

    # say L1874 mia
    old "Ready? What do you mean by that?"
    new "準備できてるって何のこと？"

    # say L1875 pla
    old "Don't think too much about it."
    new "考えすぎないでください"

    # say L1876 pla
    old "You just have to know that by this afternoon not only will we have dealt with Denzel."
    new "午後までにはデンゼルの問題は片付けてるよ。"

    # say L1877 pla
    old "There's going to be no way of him or anyone else using anything from your past to try and hurt you."
    new "君の過去を使って君を傷つけるようなことは、誰にもできなくなるんだ。"

    # say L1878 mia
    old "You make it sound so easy."
    new "あなたはそれをすごく簡単そうに言うわね。"

    # say L1879 mia
    old "But you seem to be very confident about this. So, I'll trust you."
    new "でも、あなたはこれについてとても自信そうね。だから、あなたを信じることにするわ。"

    # say L1881 mia
    old "But wait, will you look for me to tell me if whatever it is you plan on doing works?"
    new "でも待って、あなたが計画していることが上手くいくかどうか私に教えてくれるの？"

    # say L1883 pla
    old "Sure, you just focus on getting rid of that CD with your video on it."
    new "もちろん、そのCDの処分に集中しておけ。"

    # say L1884 pla
    old "And I'll handle the rest."
    new "じゃあ、あとは俺がやっておくよ。"

    # say L1885 mia
    old "Ok, whatever you say."
    new "わかりました、そうしましょう。"

    # say L1886 pla
    old "Thank you, I have to go, I'll see you later."
    new "ありがとう、行かなきゃね、後でまた会おう。"

    # say L1906 pla
    old "Hey! Hey! Linett! Are you ready?"
    new "Hey！ Hey！ リネット！準備できてるか？"

    # say L1907 pla
    old "I need to know if the spell's ready to be used!"
    new "魔法が使える状態か教えてくれ！"

    # say L1908 lin
    old "Hi [pla]! Yeah, you're right on time, I just finished it."
    new "嗨 [pla]！うん、ちょうどいいタイミングで、今終わったところ。"

    # say L1909 lin
    old "The spell's ready, so we can now use the SexNote to conjure it."
    new "魔法はもう完成したから、SexNoteを使って召喚できるわ。"

    # say L1911 pla
    old "That's great, so what do we do?"
    new "それはいいな、じゃあ次は何をするんだ？"

    # say L1913 lin
    old "The hard work was already done by me, by focusing the magic power on the person you told me about."
    new "私が既にその人への魔力集中を完了して、準備を整えました。"

    # say L1914 lin
    old "And limiting the reach of the spell."
    new "そして呪文の効果範囲を制限したの。"

    # say L1915 lin
    old "All you have to do is read it from the SexNote, and it will be cast."
    new "あなたがしなきゃいけることは、SexNoteから読むだけよ。それだけで呪文が発動するから。"

    # say L1916 pla
    old "Ok, that's very simple, can we do it now?"
    new "分かった、それなら簡単だな。今すぐできるか？"

    # say L1917 lin
    old "Sure, it should have already appeared in the SexNote, so you just have to read it, and that's it."
    new "もちろん、SexNoteにすでに現れているはずだから、それを読むだけよ。"

    # say L1920 pla
    old "You're right! Is there!"
    new "そうだな！あるぞ！"

    # say L1921 pla
    old "So, all I have to do is read it?"
    new "じゃあ、読むだけなのか？"

    # say L1922 lin
    old "That's it."
    new "それだけよ。"

    # say L1923 pla
    old "Ok, here it goes."
    new "じゃあ、いくぞ。"

    # say L1926 pla
    old "Elementum recolligo Huic Commodo locus mihi vestri vox."
    new "エレメントゥム・レコリゴ・ヒウィ・コンモディ・ロクス・ミヒ・ウェストリ・ヴォックス。"

    # say L1927 pla
    old "Venire ventus venire, sinere solus sentire relaxari."
    new "風よ、吹き荒れ、心を解放させて。"

    # say L1930 lin
    old "I-I think it's starting to take effect!"
    new "効いてきたっぽい…！"

    # say L1931 pla
    old "Accerso alius sententia ut mihi, phasmatis of interregnum ego dico!"
    new "他の感覚も俺に来い、あの時の幻影が言うように！"

    # say L1932 pla
    old "Solvo meus mens mei, ego dico phasmatis audite meus placitum meus mens quod iacio Mia!"
    new "俺の心を解き放て、俺が言う幻影よ、俺の心の言葉を聞け、ミア！"

    # say L1955 pla
    old "What's happening?!!"
    new "何が起こってるんだ？！！"

    # say L1961 pla
    old "Where am I?! What's this place?!"
    new "どこにいるんだ？！ここは何処だ？！"

    # say L1962 pla
    old "What the hell?! What's this?"
    new "何だよ！これは一体何だ？"

    # say L1963 pla
    old "Where are we Linett?"
    new "どこにいるんだ、リネット？"

    # say L1964 lin
    old "Hmmm, it seems something went awry with the spell..."
    new "うーん、呪文に何か問題が生じたみたいね…"

    # say L1965 pla
    old "What?! Can we fix it? What happened and where are we?!"
    new "何だよ！直せるのか？一体何が起こって、どこにいるんだよ？！"

    # say L1966 lin
    old "I don't know, I think we'll just have to wait."
    new "わからないわ、ただ待つしかないみたいね。"

    # say L1967 pla
    old "W- what?..."
    new "W- 何だよ…"

    # say L1972 lin
    old "Oh wow, you look like another person now!"
    new "おわ、全然別人になったみたいね！"

    # say L1977 pla2
    old "The fuck is happening Linett?!"
    new "何が起こってんだよ、リネット？！"

    # say L1978 lin
    old "Well, I told you, something went awry, apparently the energy is fluctuating..."
    new "まあ、言ったでしょう、何かがおかしくなったみたいよ、エネルギーが揺らぎ出してるらしいわ…"

    # say L1980 pla2
    old "I don't know what that means!"
    new "それが何の意味かわからない！"

    # say L1986 pla
    old "Wait, we're back to normal."
    new "待て、元に戻ったんだ。"

    # say L1987 pla
    old "What was that all about Linett? Was there something wrong with the spell?"
    new "リネット、それって何のこと？呪文に何か問題があったのか？"

    # say L1989 lin
    old "It could be, but I don't think so. I think it has more to do with all of the power that it takes to call the spell."
    new "多分そうだけど、そうじゃないと思うの。この呪文を唱えるのに必要な力が原因だと思うの。"

    # say L1990 lin
    old "All of that energy must've caused a tear in our reality that connected us to another one."
    new "そのエネルギーが現実に亀裂を生んで、別の世界と繋がってしまったんだと思う。"

    # say L1991 lin
    old "The energy probably began to flow into the tear, and that made things begin switching places between the two realities."
    new "エネルギーがその裂け目へ流れ込み始めて、それが二つの現実の間で物事が入れ替わる原因になったのだろうね。"

    # say L1993 pla
    old "Uh, sure..."
    new "うーん、そうか..."

    # say L1994 pla
    old "But what does that mean? Is everything alright?"
    new "でもそれって何を意味してるの？大丈夫なのか？"

    # say L1996 lin
    old "There shouldn't be any problem, things must've stabilized after you finished the spell."
    new "問題ないわ、あなたが呪文を完了した後で状況は安定したはずよ。"

    # say L1997 lin
    old "The person you wanted to be forgotten is no longer in the mind of the bad human."
    new "あなたが忘れさせたいと思っていた人は、悪い人の頭から消えています。"

    # say L1998 lin
    old "Also, every single trace of her presence has been removed."
    new "それに、彼女の存在に関するすべての痕跡が消えています。"

    # say L1999 pla
    old "Does that mean no more videos or pictures of anything?"
    new "それってビデオや写真も全部ないってことなのか？"

    # say L2001 lin
    old "Everything has been removed [pla]."
    new "すべてが消えてるよ [pla]。"

    # say L2003 pla
    old "Great! That's awesome, thanks Linett!"
    new "グレート！ありがとう、リンnett！"

    # say L2004 lin
    old "I'm happy to help you [pla], after all, you've done a lot for me and the other shinigamis."
    new "助けてあげられてうれしいわ [pla]、あなたや他の死神たちのためにたくさん助けてもらったからね。"

    # say L2005 pla
    old "I'll go and talk to Mia right now!"
    new "今すぐミアに話に行くよ！"

    # say L2018 pla
    old "Mia! Hey! It's done!"
    new "ミア！おい！もう終わったぞ！"

    # say L2020 mia
    old "What are you talking about? What's done?"
    new "何を言ってるの？何が終わったの？"

    # say L2021 pla
    old "You just have to know that I already took care of your problem with Denzel."
    new "ミア、心配するな、デニゼルの問題はもう解決した。"

    # say L2022 pla
    old "He won't bother you any longer, there are no more videos or pictures or anything!"
    new "もう心配しなくていいよ、デニゼルは君を困らせることはないから。ビデオも写真も何も残ってないんだ、全部消したから安心していい。"

    # say L2023 mia
    old "Uh- I mean, I think that's good, but what about him? He can just go to the press and talk about me."
    new "えっと、それはいいんだけど、でも彼はどうなるの？彼は記者に私について話すかもしれないじゃない。"

    # say L2024 pla
    old "Don't worry about that either, he won't even remember you, trust me."
    new "心配するな、彼は君のことを全然覚えてない、信じろ。"

    # say L2025 mia
    old "What do you mean he won't even remember me?"
    new "彼が私を覚えてないってどういう意味？"

    # say L2026 pla
    old "You know what? Let's check it, why don't you call him?"
    new "知ってる？確認してみよう、彼に電話してみて。"

    # say L2027 mia
    old "Now I really think you have gone insane. Call him?"
    new "今さらあなたが狂ったと思えないわ。彼に電話するの？"

    # say L2028 pla
    old "Just trust me, everything will be fine."
    new "信じてろ、大丈夫だ。"

    # say L2030 mia
    old "I guess we can try."
    new "試してみてもいいかもしれませんね。"

    # say L2034 pla
    old "Yeah, don't worry."
    new "大丈夫、心配しないで。"

    # say L2038 den
    old "Hello, who is this? I don't recognize the number."
    new "もしもし、誰ですか？この番号、知らないんですけど。"

    # say L2039 mia
    old "Wh-?!"
    new "あ、？！"

    # say L2040 mia
    old "Denzel? It's me, Mia... Uhh... from the school...."
    new "デンゼル？私、ミアよ… うーん… 学校のミアだけど…"

    # say L2041 den
    old "Listen, I don't know who you are, if you think you can scam me you better think twice!"
    new "待て、君が誰だか知らないが、俺をだます気なら二度と間違えないようにしろ。"

    # say L2042 mia
    old "What? No! I mean..."
    new "何？いいえ！そうじゃなくて…"

    # say L2044 mia
    old "Hello? Helloo?..."
    new "もしもし？ もしもぉ？..."

    # say L2045 mia
    old "He hung up, he said he didn't know who I was..."
    new "彼は電話を切って、私があたし誰なのか知らないって言ったの..."

    # say L2047 pla
    old "See?"
    new "見ろ"

    # say L2048 mia
    old "What did you do?"
    new "何したの？"

    # say L2049 pla
    old "I'm sorry but I can't tell you that, all that matters is that with that your problem should be taken care of."
    new "ごめん、それは言えないけど、大事なのは君の問題が解決されることさ。"

    # say L2051 mia
    old "I mean, I guess it is, but this is very odd."
    new "つまり、そうかもしれないけど、これはとても変だわ。"

    # say L2053 pla
    old "Listen, all you have to do is trust me, ok?"
    new "君、ただ俺を信じてればいい、分かった？"

    # say L2054 pla
    old "If you think it'll make you feel any safer, why don't we both go tomorrow to the principal's office again?"
    new "もし君が少しでも安心できるなら、明日また二人で校長先生のところに行こうじゃないか。"

    # say L2055 pla
    old "That way we can check if everything will be in order."
    new "そうすれば、すべてが順調かどうか確認できるよ。"

    # say L2058 mia
    old "Ok, let's do as you say."
    new "はい、あなたの言う通りにしましょう。"

    # say L2059 pla
    old "Great, then I'll see you tomorrow."
    new "じゃあ、明日会おうな。"

    # say L2068 mia
    old "I don't know what you did, but thank you."
    new "あなたが何をしたのか知らないけど、ありがとう。"

    # say L2094 pla
    old "Oh, Belle, hi!"
    new "オッ、ベッル、こんにちは！"

    # say L2095 pla
    old "What are you doing here so early?"
    new "ベッル、こんな早朝に何してるの？"

    # say L2097 bel
    old "Hi [pla] good morning."
    new "おはよう、[pla]。"

    # say L2098 bel
    old "I just came because Miss Lucy asked me, I'm helping her with a group project."
    new "ルーシーさんから頼まれて来たの、グループプロジェクトの手伝いよ。"

    # say L2099 pla
    old "Miss Lucy? Who's that? Like a new teacher?"
    new "ミス・ルーシー？誰それ？新しい先生でも来たのか？"

    # say L2100 bel
    old "What? Are you messing with me? Of course, you know Ms Lucy, our teacher."
    new "何？からかってる？もちろん、ミス・ルーシーが先生だって知ってるでしょ。"

    # say L2101 pla
    old "Who?!"
    new "誰？！"

    # say L2103 bel
    old "I mean, I know you two don't like each other [pla] but this is a little childish for you."
    new "つまり、二人はお互いに好きじゃないって知ってるけど [pla] でもこれくらい子供じみてるのはちょっと意外だね。"

    # say L2104 pla
    old "What? I really don't know who she is!"
    new "何？俺は本当に彼女が誰なのか知らないよ！"

    # say L2105 pla
    old "I have no idea what you're talking about."
    new "何言ってるのかさっぱりわからないよ。"

    # say L2115 luc
    old "Hi Belle, how are you today sweetheart?"
    new "ベル、今日も元気そうね、 Darling。"

    # say L2117 luc
    old "Hmph, what are you doing here so early [pla]? I hope you're not planning anything stupid."
    new "ふん、こんなに早く何してるんだ[pla]？ 馬鹿なこと考えてないよね。"

    # say L2118 luc
    old "I also hope you won't corrupt Belle, your are bad influence!"
    new "お前がベッルを腐らせるなよ、お前は悪い影響だぞ。"

    # say L2120 luc
    old "And you Belle, you need better friends."
    new "そしてお前もベール、もっと良い友達が必要だな。"

    # say L2122 pla
    old "... (What the fuck?)"
    new "何てことだよ…"

    # say L2123 luc
    old "Well, see you later in class. Belle, come with me."
    new "じゃあ、後でクラスでね。ベル、ちょっと来なさい。"

    # say L2124 bel
    old "Sorry [pla], see you later!"
    new "ごめんなさい [pla]、また後でね！"

    # say L2133 pla
    old "What te fuck? What is happening?"
    new "何てことだよ？何が起こってるんだ？"

    # say L2140 mia
    old "[pla]! What the hell did you do?!"
    new "[pla]！何をしたのよ？！"

    # say L2142 pla
    old "I mean, as I said, I thought I had fixed the issue. Did Denzel contact you again?"
    new "つまり、先に言った通り、問題は直したと思っていたんだ。デニゼルからまた連絡があったのか？"

    # say L2143 mia
    old "No! Not that."
    new "いいえ！それじゃないわ。"

    # say L2144 mia
    old "Nobody remembers who I am!"
    new "誰も私を覚えていないの！"

    # say L2147 mia
    old "That's right! When I woke up I wasn't in any of the pictures on my wall!"
    new "そうですよ！目覚めたら壁に飾ってある写真の中に私なんて誰もいなかったんです！"

    # say L2148 mia
    old "Even the doorman here didn't want to let me in! He asked if I was someone's parent!"
    new "ここでのコンシェルジュは私を入れてあげたくなかったの！親じゃないの？と聞かれたわ！"

    # say L2149 mia
    old "There's even another teacher giving my class! I already looked at the lists, I don't appear in any of them!"
    new "別の先生が私のクラスを担当しているの！リストも確認したけど、どこにも名前が載ってないのよ！"

    # say L2150 mia
    old "It's like if I didn't ever exist, What did you do [pla]? And how did you do it?!"
    new "まるで私が存在しなかったかのようね、あなたは何をしたの [pla]？ そしてどうやってそんなことしたの？"

    # say L2152 pla
    old "What? But that's... that's..."
    new "何？でもそれって…それって…"

    # say L2153 mia
    old "You know what? Denzel didn't ruin my life, but you did!"
    new "あなたが知ってるでしょ？デンゼルは私の人生を台無しにしなかったけど、あなたがそうしたの！"

    # say L2154 mia
    old "I don't know how you did it, but you blew it! I shouldn't have trusted you!"
    new "どうやってやったのか知らないけど、あなたは台無しにしてしまったわ！ 私があなたを信用しちゃいけなかったのよ！"

    # say L2160 pla
    old "What the- "
    new "何だよ"

    # say L2168 mik
    old "Whoah [pla], Who's that babe?"
    new "誰だ、その美人は？ [pla]"

    # say L2169 mik
    old "She's super hot!"
    new "彼女、超 hottestな！"

    # say L2170 mik
    old "Although she's a little too old for you."
    new "でもお前にはちょっと年上でしょ。"

    # say L2171 mik
    old "You dog, did you get a sugar mommy somewhere?"
    new "お前、どこで金持ちのおばさん見つけたんだ？"

    # say L2173 pla
    old "Don't you know who she is? That's Ms. Mia, our history teacher!"
    new "知らなかったか？それがミア先生、歴史の教師だよ！"

    # say L2174 mik
    old "Well, I had never seen her before."
    new "まあ、俺は彼女を見たことがなかった。"

    # say L2175 mik
    old "But if that babe's gonna be our teacher I wouldn't mind paying a little more attention in class."
    new "でもあの美女が先生なら、授業にちょっとだけ真剣に取り組むかもしんないな。"

    # say L2176 mik
    old "She's looks super hot, like a pornstar!"
    new "あの美人、超sexyだな、アダルトビデオの女優みたいだ！"

    # say L2184 pla
    old "Linett, what the hell happened?! The spell went wrong!"
    new "リネット、何があったんだ？！ 呪文がうまくいかなかった！"

    # say L2185 lin
    old "What? Did that guy appear again?"
    new "何？またその男が現れたの？"

    # say L2186 pla
    old "No! That's not it! He doesn't remember her!"
    new "違う！そうじゃない！彼は彼女のこと覚えてないんだ！"

    # say L2187 lin
    old "Oh."
    new "あら。"

    # say L2188 lin
    old "Then what's the problem?"
    new "じゃあ、何が問題なの？"

    # say L2189 pla
    old "That no one does! Not a single person knows who she is!"
    new "誰も彼女が誰なのか知らないんだよ！"

    # say L2190 lin
    old "Well... yeah."
    new "まあ…そうだね。"

    # say L2192 pla
    old "What? What do you mean..."
    new "何？どういうことだよ…"

    # say L2193 lin
    old "I told you, didn't I? 'Every trace of her presence will be gone.' All of it [pla]."
    new "言ったよね？「彼女の存在のすべての痕跡が消える」って。全部 [pla]。"

    # say L2196 pla
    old "Wait, this can't happen, we need to revert this, how do we do it?"
    new "待て、これってあり得ない、元に戻さないとどうするんだ？"

    # say L2197 lin
    old "I don't know, I don't even think it's possible."
    new "知らないわ、そんなことできるとも思えない。"

    # say L2198 pla
    old "Holly shit..."
    new "ホーリーシャイット…"

    # say L2214 pla
    old "Eh... What's happening?"
    new "ええ……何が起こってるんだ？"

    # say L2221 pla
    old "Where am I? Who are you?"
    new "どこにいるんだ？君は誰だ？"

    # say L2222 pla2
    old "What the fuck? Who are you? And what are you doing in my bedroom?"
    new "何てことだよ？お前は誰だ？そして俺の寝室で何やってんだ？"

    # say L2228 lin
    old "[pla], listen things are alot worse than I thought."
    new "[pla]、聞いて、状況は思っていたよりもずっと悪いの。"

    # say L2229 pla2
    old "Who the hell are you?!"
    new "誰だお前？！"

    # say L2230 pla2
    old "And why are you naked?"
    new "なんで裸なんだよ？"

    # say L2231 lin
    old "Nevermind that... Listen [pla] the tear between realities that we oppenned with our spell was a lot bigger than I thought it would be."
    new "気にしないで…聞いて [pla] 現実の間の裂け目が、私たちの呪文で開いたのが予想以上に大きかったの。"

    # say L2232 pla
    old "What? So? What does that mean?"
    new "何？それじゃあ？それがどういう意味？"

    # say L2233 lin
    old "It means that both realities are about to collapse on each other!"
    new "それは両方の現実が互いに崩れ落ちることを意味してるの！"

    # say L2235 pla
    old "Collapse? You mean like everything will be destroyed?"
    new "崩壊？全部が壊れるって意味？"

    # say L2237 lin
    old "No, fortunately I was able to find the disturbance early, I think I can fix it."
    new "いいえ、幸いにも異常を早期に見つけられたから、直せると思う。"

    # say L2238 lin
    old "And I'll do that right now."
    new "それなら、今すぐやるわ。"

    # say L2239 lin
    old "I'm just not sure if I'll make it on time, but I have to try..."
    new "時間内に間に合うかどうか不安だけど、試してみるしかないね。"

    # say L2240 pla2
    old "Wow, this is a very trippy dream."
    new "おお、これはトリppyな夢だな。"

    # say L2249 pla
    old "Where I am? What is this???"
    new "どこにいるんだ？これは一体何だ？"

    # say L2253 pla
    old "Is he the guy I saw a few moments ago?"
    new "彼はさっき見た男の人かな？"

    # say L2257 pla
    old "Is this a Dream or I'm going crazy?"
    new "これは夢なのか、俺が狂ってるのか？"

    # say L2261 pla
    old "Oh God, this is making me dizzy..."
    new "神様、これでめまいがしてくる..."

    # say L2278 pla
    old "What the fuck was that? Was it all a dream?"
    new "何だったんだよ？全部夢だったのか？"

    # say L2292 mia
    old "All right class, it's time to start."
    new "クラスのみなさん、授業を始めましょう。"

    # say L2293 mia
    old "Today we'll start a new subject, so, take out your textbooks and open them in the next chapter."
    new "今日は新しい単元を始めるので、教科書を取り出して次の章を開いてください。"

    # say L2294 mia
    old "This will also be at the end of term test, so be sure to take good notes."
    new "期末テストにも出題されるので、しっかりとノートを取るように。"

    # say L2295 mia
    old "Belle?"
    new "ベル？"

    # say L2298 mia
    old "Please read the first page of the chapter."
    new "この章の最初のページを読んでください。"


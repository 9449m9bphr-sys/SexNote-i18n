# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/JanStory.rpy
translate japanese strings:

    # say L13 pla
    old "Ugh, finally at home."
    new "うっ、やっと家に帰れた。"

    # say L15 pla
    old "Hmm. What is that noise? It's coming from the living room..."
    new "ん？その音は何か？リビングから聞こえてくるな…"

    # say L19 pla
    old "Woah! Are they... Having sex?"
    new "うわっ！ 二人は… セックスしてるの？"

    # say L35 pla
    old "I... Am... Sorry... I... Just... Heard..."
    new "俺… ごめん… ただ… 聞こえてきたんだ…"

    # say L37 mo2
    old "Weren't you supposed to come back at night?!"
    new "夜に帰ってくるはずじゃなかったの？！"

    # say L39 pla
    old "Yes, but my after school program was canceled..."
    new "はい、でも放課後のプログラムがキャンセルになったから..."

    # say L42 mo1
    old "[pla] is not what it looks like... We were just..."
    new "[pla]じゃないの... 私たちはただ..."

    # say L46 pla
    old "... I'm sorry... I..."
    new "ごめんなさい… 僕…"

    # say L84 pla
    old "I know they are married but... They should do that in their room..."
    new "知ってるけど、結婚してるんだから部屋でやればいいのに…"

    # say L85 pla
    old "Anyway, I have all day to relax..."
    new "まあ、俺には一日中リラックスする時間があるからな…"

    # say L96 mo1
    old "Listen, I want to talk to you about t- the living room"
    new "聞いて、話したいことがあるのだけれど……リビングルームについてね"

    # say L98 pla
    old "Oh, I understand. You are a couple I think is perfectly normal... And you are my [mo1rel], you don't have to give me explanations."
    new "分かってるよ、君たちは普通のカップルだって… それに君は俺の[mo1rel]だ、説明なんてしなくていいよ。"

    # say L100 mo1
    old "I'm glad to hear that. But... I want to apologize. We were a bit careless getting... Intimate in the living room."
    new "そうですか、それは嬉しいです。でも… 謝りたいんです。リビングで少し気を許してしまって… 密着しちゃったみたいですね。"

    # say L106 mo1
    old "Well, I won't bother you anymore. Please keep studying hard, honey."
    new "WELL、もう邪魔しないわ。がんばって勉強してね、ハニー。"

    # say L107 mo1
    old "Oh, by the way, you haven't had breakfast, come downstairs and I'll make you breakfast!"
    new "そういえば、朝ごはんまだよね、下に降りてきて私が作るから！"

    # say L108 pla
    old "Oh right, thank you [mo1rel]."
    new "ああ、そうか。ありがとう [mo1rel]。"

    # say L126 pla
    old "(What the fuck!... what are they doing?)"
    new "何やってんだ、このクソッタレ！…"

    # say L132 pla
    old " (Shit!) Oh, no... Nuh uh... The door was open. I just didn't know someone was in here."
    new "（クソッ！）ああ、しまった… うーん… 門が開いていたから、誰かがここにいるとは思わなかったんだ。"

    # say L133 mo1
    old "[pla], [mo2] and I were just giving each other a little hug, sweetie."
    new "[pla]と[mo2]と私、ただお互いにちょっとした抱擁を交わしていたのよ、親愛なる子。"

    # say L134 mo2
    old "See, I tried to tell you he is a damn pervert!... GO AWAY!"
    new "見なさい、私が言ったでしょう、彼は本当に変態だって… 行きなさい！"

    # say L136 pla
    old "I wasn't... Nevermind... I'll go."
    new "俺じゃないよ… いいや… 行くよ。"

    # say L158 mo1
    old "Oh hi [pla], I'm glad you're here, I wanted to talk to you too."
    new "あら、こんにちは[pla]、来てくれて嬉しいわ、あなたにも話したいことがあったのよ。"

    # say L159 pla
    old "Ehm... Is something happening?"
    new "えっと… 何か起こってるの？"

    # say L160 sis
    old "I don't know, I just arrived."
    new "私は刚到而已です。"

    # say L164 mo1
    old "Hmm... Actually, yes... That's why I need to talk to you both."
    new "実はそうなんですね... そのため、二人と話さなければならなかったんです。"

    # say L166 mo1
    old "We are having some... Uhh, financial issues..."
    new "実は、少し……うーん、お金の問題が出てきちゃって……私たちは、ええと、お金が足りなくて、義務を果たせない状況です……"

    # say L168 mo1
    old "Well, we don't have e- enough money to pay our obligations..."
    new "私たちは、ええと、お金が足りなくて、支払いに困ってるんです…"

    # say L169 pla
    old "Ohh."
    new "オッ"

    # say L170 sis
    old "But why didn't you say anything before?"
    new "でも、なぜ前に何も言わないでいたの？"

    # say L171 mo1
    old "Hmm, I didn't want you to worry about it... It's my obligation to provide for both of you... It's just that our current monetary situation is getting worse and..."
    new "うーん、心配かけたくなかったの…… 私の務めはあなたたち二人を支えることだけど…… ただ、今の経済状況が悪化していて……"

    # say L173 mo1
    old "I- I have been looking at some options and I have applied for different jobs but even that seems to be difficult."
    new "でも、いくつかの選択肢を見て、違う仕事にも応募したの……でも、それすら難しいの。"

    # say L175 mo1
    old "It's not that easy... Since I have been unemployed for so long, now it's much harder for me to find a job."
    new "そう簡単じゃないの... 長期間働いていなかったから、今さら仕事を見つけるのは難しくなってるの。"

    # say L176 mo1
    old "I have already talked to my [mo1rel] and friends but no luck... Nothing yet and only God knows when I'll get something good enough."
    new "もうすでに私の[mo1rel]や友達にも相談したんだけど、まだ何も決まらないの... 神様だけがいつ私が良い仕事を見つけることができるか知っているわ。"

    # say L178 mo1
    old "[mo2] was very generous with us when we were together, she paid for almost everything since she has a high salary income."
    new "[mo2] は私たちと一緒にいたときとても優しかったわ、彼女は高い給料をもらっているのでほとんどすべてを支払ってくれました。"

    # say L179 mo1
    old "Now that she is gone and we are no longer together, we are facing many more issues. I didn't expect the situation to go this way..."
    new "彼女がいなくなって別れた今、私たちはたくさんの問題に直面しています。こんな状況になるとは思わなかったわ…"

    # say L180 pla
    old "You're not alone on this... Kyle and I will help you... Right?"
    new "君ひとりじゃないよ…ケイルと俺が手伝うから…そうだろ？"

    # say L181 sis
    old "Yes, of course! I'm working and you know I can help, don't worry about it [mo1rel]."
    new "もちろん！私は働いているし、手伝えるって知ってるでしょ、心配しないで [mo1rel]。"

    # say L182 mo1
    old "It's not that easy, I know you wanna help but we owe a lot of money... Argh! I- I don't know what to do."
    new "簡単じゃないわ、あなたが手伝いたいのはわかるけど、私たちはたくさんのお金を借りているの… アーッ！ 何をしたらいいのかわからないわ。"

    # say L183 mo1
    old "And [mo2] is gone, she is gone and I'm here..."
    new "そして [mo2] はいなくなった、その人がいなくなって私はここにいるの..."

    # say L184 pla
    old "We'll find the way to solve thi-"
    new "解決する方法を見つけるよ、心配しなくていい。"

    # say L185 mo1
    old "I- I can't now, I better go to take some rest... I can't do this now... Sorry but I can't."
    new "今、無理かも……休んだ方がいいわ……今、これをするのは無理……ごめんなさい、無理なわけ。"

    # say L194 pla
    old "It's the first time I see [mo1rel] this worried and sad, especially sad. We gotta do something to help."
    new "[mo1rel]がこんなに心配して落ち込んでいるの、初めて見るよ。特に落ち込んでいるのが目立つ。何か手助けしないと駄目だな。"

    # say L195 sis
    old "Yeah! I didn't imagine seeing her like this. [pla] find a job and I'll do my part, I'll find a way to help as well, even if she says isn't enough."
    new "うん！こんな彼女を見るのは想像もしなかったよ。[pla]仕事探すから、私もできる限りの手伝いをするよ、たとえ彼女が足りないって言っても。"

    # say L196 pla
    old "Sure! I'll start to look for something immediately... It's too sa-"
    new "そうだな！すぐに何か探し始めるよ… だけどさ。"

    # say L197 sis
    old "Yeah, yeah... I know it's sad but we gotta focus on finding a solution for this..."
    new "うん、うん… 悲しいけど、この問題の解決策を見つけることに集中しなきゃね。"

    # say L198 sis
    old "Tell me once you have found something..."
    new "見つかったら教えてね。"

    # say L199 pla
    old "I will."
    new "分かった、探してくるよ。"

    # say L200 sis
    old "Alright, See ya!"
    new "じゃあ、またね！"

    # say L206 pla
    old "Shit! This is bad... I gotta find a job, my [mo1rel] is gonna get sick and depressed if we don't do something."
    new "くそ！これはまずい... 何かしないと、[mo1rel]は病気になって落ち込むだろう。"

    # say L207 pla
    old "Argh! But where? Really, where can I find a job?"
    new "ああ！でもどこ？本当に、どこで仕事見つけるんだ？"

    # say L208 pla
    old "Maybe at the vet's store... Or with Dr. Johnson... I don't know!"
    new "獣医のところとか、Dr. Johnsonのところとか……でも、わからないよ！"

    # say L209 pla
    old "I know! With Lisa..."
    new "知ってる！ リサのところだよ…"

    # say L210 pla
    old "Or [mo2]... No! What am I thinking about!... [mo2], no!... She would kick out my ass."
    new "または [mo2]... いや！ 何考えてんだ！... [mo2]、いや！... 足蹴にされるぜ。"

    # say L211 pla
    old "I shouldn't keep wasting my time... I'll go to all and see what I find, I need a job, I cannot let my [mo1rel] down... She needs me"
    new "時間の無駄にするのを止めるべきだ… 全部回ってみて、何か見つけてこないと、仕事が必要だ、[mo1rel]をがっかりさせるわけにはいかない… 彼女は俺が必要だって言ってたし"

    # say L229 pla
    old "What a day! Argh! It seems to be impossible to find a job... Don't know what I'm gonna do"
    new "なんて日だ！ああ！仕事を見つけるのは無理そうだな…どうしようか全然わからんよ"

    # say L230 pla
    old "Maybe I should ask at schoo-"
    new "学校で聞いてみるか"

    # say L237 sis
    old "Hey [pla], we have to talk."
    new "Hey [pla]、話があるんだ。"

    # say L239 sis
    old "What happened? Why the sad face?"
    new "何があったの？どうしてそんな悲しい顔してるの？"

    # say L240 pla
    old "Well, I was looking for any job opportunity the whole day but no luck, nobody wants to hire me."
    new "WELL、一日中仕事の機会を探してたけど、ダメだったんだ。誰も俺を雇ってくれないみたいだ。"

    # say L241 sis
    old "That's bad... You know, [mo1rel] was crying a lot today, she is feeling like shit."
    new "それは悪いわ… [mo1rel] は今日ずっと泣いていて、気分が最悪みたい。"

    # say L242 sis
    old "Argh! I can't see her like that... You have to find something, you really have to."
    new "うう！そんな状態でいるのを見るのは耐えられない……何か見つけなきゃ、絶対に見つけなきゃ。"

    # say L243 pla
    old "Did she tell you anything? Did you talk to her?"
    new "何か言ってたか？話したのか？"

    # say L244 sis
    old "No, she doesn't want us to notice how she's feeling, I didn't say anything and that's why I'm telling you."
    new "ううん、彼女は私たちに気付かせたくなかったの。だから何も言わなかったの、それが私が君に言う理由だよ。"

    # say L245 pla
    old "I'll find something, we can't let [mo1rel] down."
    new "何か見つけるよ、[mo1rel]をがっかりさせちゃダメだ。"

    # say L246 sis
    old "No, we can't. You find something tomorrow... Do your best, man! Do something about it because we have serious bullshit here."
    new "ダメよ、明日見つけて……頑張って、男の子！ちゃんと対処しなきゃここは本気の問題だから。"

    # say L247 pla
    old "I know, I know..."
    new "分かってる、分かってる…"

    # say L248 sis
    old "Good, see you tomorrow then..."
    new "じゃあ、明日ね。"

    # say L249 pla
    old "Bye..."
    new "じゃあね。"

    # say L254 pla
    old "Oh my Gosh! Where am I going to find a job now?"
    new "ああ、くそっ！今からどこでバイト探すんだよ？"

    # say L255 pla
    old "I already tried with the best options I had in mind... What abou-"
    new "俺はもう頭の中のベストな選択肢を試したんだ... でも、それ以外には..."

    # say L256 pla
    old "[mo2]? Perhaps she doesn't hate me that much and I could have a chance there... Argh! No! Fuck, I don't wanna ask to her..."
    new "[mo2]？もしかしてそんなに嫌われてないかもしれないし、チャンスがあるかもしれない……でも！ダメだ！くそ、彼女に頼みたくない……"

    # say L258 pla
    old "Fuck it! I'll do it, this is about my [mo1rel], I have to try at least... Tomorrow I'll see [mo2]."
    new "くそっ！やるしかない、これは俺の[mo1rel]のためにだ、少なくとも試さなきゃ... 明日、[mo2]に会いに行くぞ。"

    # say L274 pla
    old "Hi Akita... I'm [pla]"
    new "あきた…俺は[pla]"

    # say L275 aki
    old "Oh! Hey, I remember you, yes... You're the handsome delivery guy..."
    new "あら！こんにちは、覚えてるわ、うん… あなたが handsomeな配達員さんね…"

    # say L276 aki
    old "Tell me... What can I do for you?"
    new "教えて、何をお手伝いできるかな？"

    # say L278 pla
    old "H- Handsome? Haha t- thanks."
    new "へっ、ハンサム？ハハ、ありがとうな。"

    # say L279 pla
    old "Actually I'm here looking for [mo2]."
    new "実は[mo2]を探しに来たんだ。"

    # say L297 mo2
    old "[pla]? What the heck are you doing here?"
    new "[pla]？ここに何してるの？"

    # say L298 pla
    old "H- Hi [mo2], I- I don't want to bother you but I have to talk to you, I- I need to tell you something."
    new "あ、あの、[mo2]、邪魔したくないんだけど、どうしても君に話さなきゃならないことがあるんだ。"

    # say L299 mo2
    old "What do you want?"
    new "何を欲しがっているの？"

    # say L300 pla
    old "I see but I really need to ask you for a favor..."
    new "分かってるけど、実は君に頼みがあるんだ..."

    # say L301 pla
    old "I need a job, I can do whatever you ask me to but I need to work. The situation at home is not ok and we all are worried."
    new "仕事が必要なんだ、君が頼むことを何でもやるけど、働かないとダメなんだ。家での状況がよくなくて、みんな心配してるんだ。"

    # say L303 mo2
    old "So you come to my office and you pretend I give you a job? Why should I do that!?"
    new "だから私のオフィスに来て、私が君を雇うふりをするってわけ？ なぜ私がそんなことするべきなのか！？"

    # say L304 pla
    old "[mo2], please! I know you don't like me but believe you're the last option I have, I don't know what else to do."
    new "[mo2]、お願いします！君は私を好きじゃないのは知ってるけど、君が最後の頼りなんだ。他にどうしたらいいかわからないんだ。"

    # say L305 mo2
    old "Finally you got it! Yes, I don't like you and I won't hire you. Don't be stupid! Now go away! I don't want you here."
    new "ついに気づいたのね！ そう、私はあなたが嫌いだし、雇うつもりもないわ。馬鹿じゃないの！ さあ、出て行って。ここにいてほしくないのよ。"

    # say L306 mo2
    old "Now that you all need me, you come here looking for me! Well, I don't care!"
    new "今更私が必要だって、ここに来て探すなんて！でも、私は興味ないわ！"

    # say L308 mo2
    old "I said get out!"
    new "出ていけって言ったでしょう！"

    # say L317 pla
    old "Now where I'm going to find a job?"
    new "今どこでバイト見つけるんだよ？"

    # say L318 pla
    old "Wait, what is that sound? It comes from the livingroom..."
    new "待て、その音は何か？リビングから聞こえてくるんだが…"

    # say L333 pla
    old "Oh, [mo1rel]? A- Are you fine?"
    new "あ、[mo1rel]？ 大丈夫か？"

    # say L336 pla
    old "Are you crying? I don't want to see you like this [mo1rel]."
    new "君は泣いているのか？こんな姿を見るのは好きじゃない [mo1rel]。"

    # say L337 mo1
    old "I- I know honey but it's hard... I'm feeling so sad, so lonely, I- I."
    new "Honey、分かってるけど……辛くて、悲しくて、寂しくて、私……。"

    # say L338 pla
    old "[mo1rel], you're not alone, we're here for you. I promise you I'll find a job and everything will be fine."
    new "[mo1rel]、君は一人じゃないよ、俺たちがいるから。約束する、仕事見つけて、すべてうまくいくさ。"

    # say L339 mo1
    old "I'm sorry, it's just that it's a bunch of things, I would like to solve our monetary issues without putting pressure on you or your [sisrel]..."
    new "ごめんなさい、ただ色々あって……お金の問題を解決したいけど、あなたやあなたの[sisrel]に負担をかけたくはないの……"

    # say L340 mo1
    old "And... I have to admit... I really miss her... It's been hard to be without her."
    new "そして…私には認めざるを得ないのだけど…彼女を本当に懐かしく思ってるの…彼女がいないのは辛いわ。"

    # say L342 pla
    old "We'll do whatever it takes to make you feel better."
    new "君のために何が必要でもするよ。"

    # say L343 mo1
    old "The only thing that would make me feel better is... Argh!"
    new "私を落ち着かせる唯一の方法は… アーッ！"

    # say L345 mo1
    old "This is hard, you know... It's really hard to feel so helpless, I feel my hands are tied and there is nothing I can do."
    new "これは大変よね… 手が縛られて何もできないって、本当に辛いの。"

    # say L346 pla
    old "I'm so so sorry."
    new "ごめん、本当に申し訳ない。"

    # say L348 mo1
    old "I'll rest for now... I can barely talk..."
    new "今は休むわ… 声も出せないくらい疲れてるの。"

    # say L349 pla
    old "Yes [mo1], just go and try to rest. I'll take care of this."
    new "そうだ [mo1]、休んでくれ。俺がこらえるから。"

    # say L350 mo1
    old "See you hun, thanks for being so good..."
    new "またね、ありがとう、優しくて…"

    # say L355 pla
    old "My [mo1rel] doesn't deserve this, I'll insist to [mo2], she has to help me..."
    new "俺の[mo1rel]はこんな目に遭うべきじゃない、[mo2]に頼み込む、絶対に手伝わなきゃならないんだ…"

    # say L356 pla
    old "It doesn't matter what I have to do to get that job... I don't want to see my [mo1rel] so depressed and worried."
    new "俺がその仕事に就くために何をしてもいいよ… 俺は[mo1rel]がそんなに落ち込んで心配してるのを見たくないんだ。"

    # say L357 pla
    old "I wish I could help her to come back with [mo2], it is obvious how much she misses her..."
    new "彼女がどれだけ会いたがってるか、明らかだよ… [mo2]と再会できるように手助けしたいんだ。"

    # say L374 mo2
    old "This is absurd! What happened to the delivery boy?"
    new "これはおかしいわ！配達の少年はどうしたの？"

    # say L375 aki
    old "I- I'm calling him, but he doesn't answer."
    new "私、彼に電話してるんだけど、全然出ないんです。"

    # say L376 mo2
    old "What? It's incredible how useless everyone in this company is... What am I paying these people for!?"
    new "何？この会社の人たちって、どれだけ役立たずなのか信じられないわ… 私はこれらの人に何のために払っているのかしら！？"

    # say L377 mo2
    old "We should have sent those documents hours ago... "
    new "あの資料は数時間前に送るべきでしたよね…"

    # say L383 pla
    old "[mo2]? Hi..."
    new "[mo2]？嗨……"

    # say L385 mo2
    old "Argh! Again you..."
    new "あら！またあなたね…"

    # say L387 mo2
    old "Akita, I'm waiting for an answer, what happened to the delivery boy? Can we get another one? I need you to solve this fucking issue NOW!"
    new "アキタ、答えを待ってるのよ、配達少年はどうなったの？ 別の人を手配できる？ 今すぐこの問題を解決しなきゃならないのよ！"

    # say L388 aki
    old "It would be hard to find another one right now, it's pretty late and the Mayor's office is waiting for those documents. I don't know  Mrs. [mo2]."
    new "今すぐ別の配達員を見つけるのは難しいです、もう遅いですし、市長のオフィスがその書類を待っています。Mrs. [mo2] のことは私にもわかりません。"

    # say L389 mo2
    old "You don't kno-?"
    new "知らないうちに…？"

    # say L390 pla
    old "I- I could d- deliver t- those d- documents..."
    new "俺が、あの、その書類を届けられるよ..."

    # say L392 mo2
    old "Are you fucking kidding me!? You're an idiot, I won't trust you with those things, just get out, I told you I don't want you here..."
    new "あなたが冗談を言うのを止めて！バカじゃないの、そんな重要なものを任せられないわ、出て行って、私はあなたがここにいるのを望んでいないのよ…"

    # say L394 aki
    old "Mrs. [mo2]! That's actually a good idea and the only option we have if we want those documents to be delivered now."
    new "Mrs. [mo2]！それは実際によいアイデアで、今すぐその書類を届けたいなら唯一の選択肢です。"

    # say L396 mo2
    old "No and no! I don't want him to do anything... Akita, just find another way..."
    new "ダメよ、ダメ！ 私は彼には何もさせたくないわ… アキタ、他の方法を見つけてちょうだい…"

    # say L397 aki
    old "Uhh... I- I'm afraid there is no other way right now..."
    new "うーん… 今のところ他に方法がないんです…"

    # say L398 pla
    old "I'll do it! I can do it well, I promise, please [mo2]... It's just a little help."
    new "俺がやるよ！上手くできるから、約束するよ。[mo2]... ちょっとだけ手伝ってあげるだけさ。"

    # say L400 mo2
    old "Argh! FINE! Go and deliver the documents NOW! If I get to know that you did something wrong, I'll fucking kill you."
    new "あら！いいわ！今すぐその書類を持って行きなさい！もし何か間違えたら、絶対に許さないからね。"

    # say L406 aki
    old "[pla], You have to take the documents to the Mayor's office, please go as fast as you can."
    new "[pla]、市長のオフィスに書類を持っていく必要がありますので、できるだけ早く行ってください。"

    # say L407 pla
    old "Alright, I'm going now..."
    new "よし、行こう..."

    # say L420 pla
    old "H- Hello?"
    new "あ、もし？"

    # say L421 sop
    old "Yes, pardon me?"
    new "えっと、すみません？"

    # say L422 pla
    old "Oh hi! I'm [pla], I'm coming from [mo2]'s office..."
    new "あ、こんにちは！俺は[pla]だ、[mo2]のオフィスから来たんだ..."

    # say L423 sop
    old "Hello! I'm Amy, nice meeting you."
    new "こんにちは！私はエイミーです、お会いできて嬉しいです。"

    # say L424 sop
    old "Do you have the documents? Let me see them, please."
    new "書類は持ってる？見せていい？"

    # say L426 pla
    old "Yes, here they are..."
    new "はい、これだよ..."

    # say L428 sop
    old "Perfect... You came just in time, we were waiting for them."
    new "Perfect... timely ね、待ってたわ。"

    # say L430 pla
    old "Well... Guess that's it... Thank you."
    new "これでいいか... ありがとう。"

    # say L436 sop
    old "Huh! One more thing! Tell [mo2] that everything is in order and that we'll call her back."
    new "へえ！一つ忘れてた！[mo2] にすべて整ってるって伝えて、後で連絡するって言って。"

    # say L437 pla
    old "Alright, have a nice day."
    new "じゃあ、良い一日を。"

    # say L438 sop
    old "Bye! See ya."
    new "バイ！またね。"

    # say L440 pla
    old "Alright, I think that was easier than I expected. Now it's time to go back to [mo2]'s office."
    new "よし、思ったより簡単だったな。次は[mo2]のオフィスに戻る時だ。"

    # say L460 pla
    old "H- Hello A- Akita..."
    new "あー、あきた…"

    # say L462 pla
    old "(I can't even focus...)"
    new "集中できないな..."

    # say L463 pla
    old "Good... I delivered everything."
    new "よし… すべて届けたぞ。"

    # say L469 aki
    old "So apparently you did a good job..."
    new "そうみたいね…"

    # say L470 pla
    old "Y- Yeah... Well, I delivered the documents and the girl said it was fine and that it was in time, so I guess, yeah..."
    new "うん…まあ、書類を届けて、女の子が問題ないって言ってくれて、間に合ったから、多分大丈夫だな…"

    # say L471 aki
    old "I know, I know... And... Hmm."
    new "知ってる、知ってる... でも... うーん。"

    # say L472 pla
    old "Yeah? What happened? Did I do anything wrong?"
    new "何？何があった？何か間違えた？"

    # say L473 aki
    old "Well... Hmm, not here but... Did you notice what you have down there?"
    new "うーん…ここじゃなくて…下のこと気づいた？"

    # say L474 pla
    old "What? What do you mea-"
    new "何？何の事だよ？"

    # say L476 pla
    old "Argh fuck! I- I don't kno- I- I h- have to go."
    new "ああくそ！俺- 俺知らない- 俺- 俺行かないと。"

    # say L493 mo2
    old "You better have done it right!"
    new "ちゃんとやったのね！"

    # say L495 mo2
    old "What's wrong with you? Why are you acting so weird?"
    new "何があったの？どうしてそんな変な態度なの？"

    # say L496 pla
    old "M- me? Uhh, no... Nothing..."
    new "俺？うーん、特に何も……"

    # say L497 mo2
    old "What do you have on your hands? Why are you acting like a freak? You idiot! Tell me what have you done?"
    new "手に何持ってるの？どうしてそんな変な態度なの？バカじゃないの！何したのってば、教えてよ！"

    # say L499 pla
    old "[mo2] I have done nothing... I don't know what you're talking about..."
    new "[mo2] 何もしてないよ……何言ってるのかわからないけど……"

    # say L500 mo2
    old "You're not gonna fool me... Let me see your hands now! What are you hiding?"
    new "あなたは私をだますのは無駄よ… 今すぐ手を見せて！ 何を隠しているの？"

    # say L502 mo2
    old "What the fuck!? You are a fucking pervert!"
    new "何てことだ！？ あなたは本当に変態よ！"

    # say L504 mo2
    old "Why do you have a fucking boner right now?"
    new "今なぜそんなに勃起してるの？"

    # say L505 pla
    old "[mo2]... I- I c- can explai-"
    new "[mo2]… 俺は、俺は説明できるけど…"

    # say L506 mo2
    old "Explain what?"
    new "何を説明するの？"

    # say L507 mo2
    old "That you got fucking horny and now you're having a BONER IN FRONT OF ME!?"
    new "あなたが欲情して、今私の前にビン勃ててるって説明するの？！"

    # say L508 pla
    old "N- not r- really..."
    new "N- なに言ってんの、ほんとじゃないんだよ…"

    # say L509 mo2
    old "Bullcrap!"
    new "うそっ！"

    # say L511 mo2
    old "I've had a pretty shitty day and now this... BUT! You'll see... Little motherfucker... You'll see!"
    new "今日一日散々だったのに、今さらこれか… でもね！ 小鬼が… 見てろよ！"

    # say L512 pla
    old "W- What? "
    new "何だ？"

    # say L513 mo2
    old "Get on the floor... NOW!"
    new "床に伏せ……今すぐ！"

    # say L514 pla
    old "O- On t- the f- floor? W- why?"
    new "オ- オン t- ザ f- フロア？ なんで？"

    # say L515 mo2
    old "I've given you an order! Do it, you are a stupid pervert... Do what I'm telling you and do it now."
    new "私の命令を聞け！すぐに膝をつけて、あなたは変態だから… 私の言うことを聞いて、今すぐやれ。"

    # say L516 pla
    old "(Oh fuck!)"
    new "オッシャッ！"

    # say L517 mo2
    old "Your knees on the floor NOW!"
    new "今すぐ膝を床につきなさい！"

    # say L518 pla
    old "A- alright... Uhh."
    new "あー、分かった……うーん。"

    # say L522 mo2
    old "I'll have fun with you... You get horny here... I give you shit!"
    new "私が楽しむわ… あなた、ここですごく興奮してるわね… 私があなたをいじめるんだから！"

    # say L523 mo2
    old "You will suck my foot!"
    new "足を吸うんだよ！"

    # say L524 pla
    old "W- what!? Do you want me to suck you-"
    new "ワッ、何だよ！君が俺の足コキをしたいって？"

    # say L525 mo2
    old "WHAT? WHY are you questioning me? I've just said, SUCK MY FOOT!"
    new "何？ なぜ私が疑われてるの？ さっき言ったでしょ、私の足を吸うのよ！"

    # say L543 mo2
    old "Go! Disappear from here... I don't want to see you."
    new "行きなさい！ここから消えて……見たくもないわ。"

    # say L544 pla
    old "B- but what about the job? Can I c- come back?"
    new "でも仕事はどうなるんだ？ 戻ってこられるのか？"

    # say L545 mo2
    old "Yes, whatever... Just go away."
    new "はい、何でもいいわ… とにかく出て行って。"

    # say L546 pla
    old "S- So am I hired?"
    new "Ｓ－だから、採用されたわけ？"

    # say L547 mo2
    old "Are you stupid or what? I just said YES! Now, GET OUT!"
    new "あなたがバカなのかどうなのか、私にはよく分かったわ。私ははっきりとYESって言ったでしょう！さあ、出て行って！"

    # say L552 pla
    old "Fuck! That was weird..."
    new "くそ！変な感じだったな…"

    # say L569 pla
    old "Oh, hi [mo1rel], how are you? A bit better?"
    new "お、こんにちは [mo1rel]、元気？少しはマシになった？"

    # say L570 mo1
    old "Hi honey, I'm ok... Not that good but I guess I'll be fine eventually..."
    new "こんにちは亲爱的、私は大丈夫… でもそんなに良くはないけど、最終的には大丈夫になるわ…"

    # say L571 mo1
    old "I'm still worried about our economic situation..."
    new "まだ経済的な状況が心配で……"

    # say L572 pla
    old "No [mo1rel]! You don't have to worry about it... I got a job and I'll be able to help you."
    new "心配するな、[mo1rel]！大丈夫だ、仕事見つけたから、君を助けることができる。"

    # say L573 mo1
    old "A job? How? Where are you working?"
    new "仕事？どうやって？どこで働いてるの？"

    # say L574 pla
    old "Hmm... I'm working in [mo2]'s office... Basically, I just started but yeah... It's good that I'll have some money to help..."
    new "うーん… [mo2]のオフィスで働いてるんだ… 基本的に始めたばかりだけどね… でも、お金を稼げるようになったのは良いことだよ…"

    # say L575 mo1
    old "[mo2]? Are you serious?"
    new "[mo2]？本気ですか？"

    # say L576 pla
    old "Yes, she gave me a chance to work for her..."
    new "はい、彼女が俺に働くチャンスをくれたんだ..."

    # say L578 mo1
    old "And... Is she fine? Hmm, has she asked for me or anything...?"
    new "そして…大丈夫？ねぇ、何か私のこと聞いてきた？"

    # say L579 pla
    old "She's fine [mo1rel]... You know, I haven't really talked much to her..."
    new "大丈夫だよ [mo1rel]... ただ、そんなに話してないんだ..."

    # say L580 mo1
    old "Ok... Yeah, I assume she's fine... Probably better than me..."
    new "うん… 大丈夫だとは思う… 多分、私よりはマシだろうね…"

    # say L583 mo1
    old "Honey, go get some rest... I guess you've been tired since you started working..."
    new "honey、休んでちょうだい… 仕事始めてから、疲れてるよね…"

    # say L584 pla
    old "Kinda, today it's been a very long and hard day... I'm gonna head to my room."
    new "うん、今日はずいぶん長くて大変な一日だったな… 僕の部屋に戻るよ。"

    # say L585 mo1
    old "I imagine how hard it is working with her..."
    new "お仕事大変そうね、特に彼女と一緒だと…"

    # say L586 pla
    old "(Well... It was hard, quite literally...)"
    new "まあ… 確かにハードだった、文字通りに"

    # say L587 pla
    old "If you need anything just tell me, ok? Love you [mo1rel]."
    new "もし何か必要な時は言ってくれ、いいかい？愛してる [mo1rel]。"

    # say L589 mo1
    old "Bye honey, love you too."
    new "バイバイ、私も愛してるわ。"

    # say L595 pla
    old "Hmm, [mo1rel] is feeling really sad for [mo2]..."
    new "うーん、[mo1rel] は [mo2] のことをすごく悲しんでいるみたいだな…"

    # say L596 pla
    old "And the worst part is that she misses her a lot but [mo2] doesn't even ask for her."
    new "最悪なのは、彼女をすごく懐かしがってるのに、[mo2]は彼女のことさえ尋ねてこないことさ。"

    # say L597 pla
    old "I should find the way to talk with [mo2] about my [mo1rel]... I'll see."
    new "[mo2]に[mo1rel]のことを話す方法を見つけないと…見つけ出すよ。"

    # say L603 pla
    old "Hey Kylee! What's up?"
    new "Kylee！どうしてる？"

    # say L604 sis
    old "I'm great. What about You?"
    new "私は元気だよ。YOUは？"

    # say L605 pla
    old "Well, I got a job!"
    new "WELL、俺 仕事見つけたんだ！"

    # say L606 sis
    old "Cool, finally man! What's it about?"
    new "やっとか、いいね！どんな仕事？"

    # say L607 pla
    old "That's the not so cool part... I'm working with [mo2]..."
    new "それがクールじゃないところなんだ... 俺は[mo2]と働かないといけないんだ..."

    # say L608 sis
    old "[mo2]? Really?... But that woman hates you..."
    new "[mo2]？本当に？…でもその女、あなた嫌いじゃない？"

    # say L609 sis
    old "What are you doing for her?"
    new "何を彼女のためにしてるの？"

    # say L611 pla
    old "Hmm... Just l- like... delivery guy...."
    new "うーん… ただの… 配達員みたいな…"

    # say L612 sis
    old "I see... Well you have talent for that, don't you? Hahaha. "
    new "なるほど… でもそれには才能があるんだね？ハハハ。"

    # say L613 pla
    old "Yeah, so funny... "
    new "そうか、めちゃくちゃ面白いな…"

    # say L614 sis
    old "At least you finally got a job."
    new "せめて仕事は見つけたのね。"

    # say L615 pla
    old "Hmm, I know... I know..."
    new "うん、分かってる… 分かってるよ…"

    # say L616 pla
    old "Today was a really weird day, I need some rest, see you."
    new "今日はずいぶん変な日だった、休ませてもらうよ、またね。"

    # say L617 sis
    old "I believe you, Hahaha, see you."
    new "信じてるよ、ハハハ、またね。"

    # say L635 aki
    old "Hi [pla], how's it going?"
    new "おひさしぶり [pla]、調子はどう？"

    # say L636 pla
    old "Hello Akita, all good... Getting involved in the job."
    new "おっすAkita、調子いいよ…仕事に本格的に取り組んでるところだ。"

    # say L637 aki
    old "Oh great, so are you ready to start with the new deliveries?"
    new "じゃあ、新しい配送の準備はできてる？"

    # say L638 pla
    old "Yeah, please explain to me what I have to do."
    new "あき、何をすればいいか教えてくれ。"

    # say L639 aki
    old "Well, it really is very simple, at the moment we must send correspondence from some projects to three specific places."
    new "まあ、とても簡単よ。今のところ、いくつかのプロジェクトの書類を三つの特定の場所に送らなきゃならないの。"

    # say L641 aki
    old "They all have a different format depending on where they should go."
    new "それぞれの場所によってフォーマットが違うの。"

    # say L642 aki
    old "For example, all mayoral documents have a red border."
    new "例えば、市長の文書は赤い枠があるの。"

    # say L643 aki
    old "While the documents that go to the bank are green."
    new "銀行用の書類は緑色だよ。"

    # say L644 aki
    old "And finally the yellow documents for the factory."
    new "そして最後に、工場用の黄色い文書ね。"

    # say L646 pla
    old "Red, green and yellow, got it."
    new "赤、緑、黄色、わかった。"

    # say L647 aki
    old "It shouldn't be difficult at all, you just need to send them quickly to reach all the deliveries of the day."
    new "全然難しくないわ、ただ早く送れば今日の納品全部間に合うだけよ。"

    # say L648 aki
    old "Anyway if you need anything else just let me know."
    new "それじゃ、他に何かあったら言ってね。"

    # say L649 pla
    old "Alright, thank you."
    new "分かった、ありがとう。"

    # say L650 aki
    old "So? Are you ready to start the deliveries?"
    new "それじゃ、配達の準備はできてる？"

    # say L651 pla
    old "Sure! Let's do it."
    new "もちろん！さあ、始めよう。"

    # say L662 mo2
    old "So do you think I'm paying to do a shitty job? Is that what you think?"
    new "そんな私に悪い仕事をさせてると思ってるの？そう思われると困るわよ。"

    # say L663 pla
    old "No! No [mo2]! I'm sorry... I'm still learning but I promise I'll do it better."
    new "いいえ！いいえ [mo2]！ごめんなさい… 僕まだ勉強中だけど、絶対に上手くやるから。"

    # say L664 mo2
    old "You're an idiot... I seriously doubt you'll do it better..."
    new "あなたはバカね… 本当に上手くできると思うの？"

    # say L665 mo2
    old "I can let this go... You gotta learn a lesson out of this."
    new "私はこれくらいで許してあげるけど… これを教訓にしてちょうだい。"

    # say L666 pla
    old "A- A l- lesson? But I just started working with you..."
    new "あ、教訓？でも俺は君と働き始めて間もないじゃないか..."

    # say L667 mo2
    old "And now you're questioning my decisions... You better change that fucking shitty behavior or you'll suffer in this office."
    new "そして今、私の判断を疑うなんて… そんなクソみたいな態度を直さないなら、このオフィスで苦しむことになるわ。"

    # say L668 mo2
    old "Do you understand that?"
    new "分かってるの？"

    # say L670 mo2
    old "DO YOU? I'm asking..."
    new "分かってるの？ 本当に理解しているの？"

    # say L671 pla
    old "Y- Yeah... I do."
    new "Ｙ－ うん… 分かってる。"

    # say L672 mo2
    old "Good! Now get on the floor... You'll see what it's like not doing a good job for me..."
    new "よし！それじゃあ床に這いつくばって……私が満足しないときの罰とはどんなものか味わうわね。"

    # say L680 mo2
    old "I guess lastime wasn't enough for you... You deserve to be on the floor where you belong!"
    new "前回だけでは足りなかったみたいね… お前が本当にあるべき場所、つまり床に這いつくばるべきだということを教えてあげるわ。"

    # say L681 mo2
    old "You're my little bitch on the floor... Waiting for me to feed you."
    new "あなたは私の足元で待つべき小犬よ… 私に食事を与え待っているのね。"

    # say L683 mo2
    old "That's how you should be treated, like the cockroach that you are!"
    new "あなたがゴキブリのように扱われるべきだということよ。"

    # say L687 mo2
    old "You got a hardon?! Ughh... That's disgusting!"
    new "あなたが勃起してるの？！ うっぎゃ… それって気持ち悪いわ！"

    # say L691 mo2
    old "Alright, if this is what a pervert wants, maybe I should use other methods of punishment."
    new "よし、変態が望むなら、他の罰の方法を使ってみるべきかもしれないわ。"

    # say L692 mo2
    old "Let's see if this teaches you a lesson!"
    new "じゃあ、これで教訓になるかどうか見てみましょう！"

    # say L703 pla
    old "[mo2]? Hmm, I- I wanted to tell you something..."
    new "[mo2]？うーん、実は言いたいことがあったんだ…"

    # say L704 mo2
    old "Be quick and get out from here!"
    new "はやく出て行って！"

    # say L705 pla
    old "It's about my [mo1rel], you know she has been asking for you... I don't know if maybe you could call her or you know... Something."
    new "それは俺の[mo1rel]のことなんだけど、彼女が君のことをずっと探してるみたいで… 何か連絡とかしてみる？"

    # say L706 mo2
    old "Oh gosh! Really?"
    new "ほんとうに？"

    # say L707 mo2
    old "I won't talk to her."
    new "私は彼女とは話さない。"

    # say L708 mo2
    old "Now just get out idiot! I feel gross just by seeing you."
    new "さっさと出て行きなさい、バカ！ 見ただけで気持ち悪いわ。"

    # say L714 pla
    old "What am I doing?"
    new "何やってんだ、これ…"

    # say L715 pla
    old "[mo2] is crazy... I can't keep doing whatever she wants."
    new "[mo2]は狂ってる… 俺はもう彼女の言う通りにするわけにはいかない。"

    # say L716 pla
    old "Argh!"
    new "あー！"

    # say L732 pla
    old "Hello Akita, all good..."
    new "アキタ、元気か…"

    # say L733 aki
    old "Great! You know what you've to do... So just let me know if you need help."
    new "Great！ あなたがやるべきことを知ってるんでしょ… 手伝う必要があったら教えてね。"

    # say L738 pla
    old "I would like to know if all the documents that must be sent today are ready?"
    new "今日送らなきゃいけない書類が全部揃ってるかどうか教えてくれない？"

    # say L739 aki
    old "Hmm, There are still several documents missing that [mo2] must sign, if you come in the afternoon I will have them ready for you."
    new "まだいくつか [mo2] が署名しないといけない書類があるの、午後に来てくれれば準備できてるわ。"

    # say L741 aki
    old "Great, see you later."
    new "じゃあ、後でね。"

    # say L746 aki
    old "Yes, I got all of them."
    new "はい、全部揃えました。"

    # say L747 pla
    old "Oh, perfect."
    new "完璧だな。"

    # say L754 pla
    old "Could you please explain to me again the what I have to do."
    new "また説明してくれないか、何をすればいいのか。"

    # say L755 aki
    old "Sure, it's very simple, at the moment we must send correspondence from some projects to three specific places."
    new "もちろん、簡単よ。今のところ、いくつかのプロジェクトから特定の三つの場所に書類を送らなきゃならないの。"

    # say L758 aki
    old "For example, all documents sent to the mayor or his office have a red frame."
    new "例えば、市長や市長のオフィスに送るすべての書類には赤い枠をつけるの。"

    # say L761 pla
    old "Red, green and yellow, got it, "
    new "赤、緑、黄色、わかったよ、アキ。"

    # say L804 aki
    old "Wow, You're good at this!"
    new "すごいね、上手だね！"

    # say L805 pla
    old "Haha, thanks! I'm doing my best..."
    new "ははは、ありがとう！頑張ってるよ..."

    # say L806 aki
    old "Good job, keep it up!"
    new "いいわ、そのまま続けて！"

    # say L807 pla
    old "I've to... You know how [mo2] is..."
    new "俺も頑張ってるけど…君も知ってる通り、[mo2]は…"

    # say L808 aki
    old "Yeah, I totally understand."
    new "うん、全然理解できるよ。"

    # say L809 pla
    old "Hey, do you know if I can talk to [mo2]?"
    new "Hey、[mo2]に話せるのか？"

    # say L810 aki
    old "Uhh, well she is busy all the time, I don't think I will attend to you, unless it's to scold or punish you..."
    new "うーん、彼女はいつも忙しいから、私があなたのことは相手しないと思うわ。叱るか罰する時だけね…"

    # say L811 pla
    old "Hmm, right... Ok, thank you Akita."
    new "うーん、そうか…… 分かった、ありがとう、アキタ。"

    # say L812 aki
    old "Have a good day [pla]."
    new "良い一日を [pla]。"

    # say L814 pla
    old "Hmm maybe, I shouldn't be so good at this, if I want to have the chance to speak with [mo2] whenever she calls me to her office..."
    new "うーん、もしかしたら、上手すぎると [mo2] が俺を呼んでくれないかもしれないな…"

    # say L815 pla
    old "Maybe if I do bad work, [mo2] will call me to break my balls and I'll get the chance to talk to her about [mo1rel]..."
    new "もしかしたら、悪い仕事をすれば、[mo2]がボクの玉を潰しに呼んでくれて、[mo1rel]について話すチャンスが来るかもしれないな…"

    # say L816 pla
    old "Oh man, I'm sure I will regret this."
    new "ああ、これ絶対後悔するな。"

    # say L829 aki
    old "Hmm... Sorry [pla], I hope next time you can do it better."
    new "うーん… 次はもっと頑張ってね、[pla]。ごめんね。"

    # say L830 pla
    old "Argh! Yes... I'll be more focused next time, sorry."
    new "ああ！ 分かった… 次はもっと集中する、ごめん。"

    # say L831 aki
    old "It's fine, just do your best because you know how [mo2] is, she'll give you shit if you keep failing."
    new "大丈夫、ただ頑張って。だって[mo2]は失敗続きだと文句言うから。"

    # say L834 pla
    old "Gulp, I guess it's time."
    new "うーん、そうなるか。"

    # say L835 aki
    old "Good luck..."
    new "頑張ってね..."

    # say L857 mo2
    old "I know you were stupid but I didn't imagine this much."
    new "あなたが愚かだとは知っていましたが、これほどまでとは思わなかったわ。"

    # say L858 pla
    old "Listen, I- I know I did wrong again but... I- I am sorry [mo2]."
    new "聞いて、俺はまた間違えたって分かってるけど… 本当に申し訳ない [mo2]。"

    # say L859 pla
    old "I'll be more careful next time."
    new "次は気をつけるから、モニカ。"

    # say L860 mo2
    old "Yeah... Whatever... I don't care about the next time..."
    new "うん… どうでもいいわ… 次のことなんて気にしないわ…"

    # say L861 mo2
    old "Now you gotta pay for this one."
    new "今のは払わなきゃならないのよ。"

    # say L862 pla
    old "A- Again?"
    new "またか？"

    # say L863 mo2
    old "I have done some stuff wrong with you..."
    new "私があなたに対して間違ったことをしたの…"

    # say L864 mo2
    old "You shouldn't get so much pleasure for all mistakes you've done here..."
    new "あなたがここで犯したすべての間違いのために、そんなに快感を得ちゃダメよ…"

    # say L866 mo2
    old "You have been a lucky idiot!"
    new "あなたは運が良すぎる馬鹿でしたね。"

    # say L867 mo2
    old "But not anymore!"
    new "でも、もうそうはいかないわ。"

    # say L869 mo2
    old "I should get something in return for hiring such a stupid person... And for still paying you."
    new "そんなバカを雇って何か見返りをもらわないとね… それに、まだ給料も払ってるんだから。"

    # say L870 mo2
    old "You have been the worst employee I have ever had... The most useless person I have worked with. You're disgusting."
    new "あなたは私が雇った中で最悪の従業員だったわ… 一緒に働いた中で最も無能な人間だわ。あなたは本当に気持ち悪い。"

    # say L872 mo2
    old "What kind of punishment should I give you this time?"
    new "今度は何の罰を与えるべきかしら？"

    # say L873 mo2
    old "I definitely did wrong giving you pleasure, an idiot like you will only learn the hard way."
    new "間違いなく私が快楽を与えたのは間違いだったわ、あなたのようなバカは苦い経験をしないと何も学ばないからね。"

    # say L874 mo2
    old "Then perhaps the best thing is that this time you are the one who gives pleasure, like the useless little bitch you are."
    new "それなら、今回はあなたが私に快楽を与えるのが最適でしょう、無能な小犬のくせに。"

    # say L875 mo2
    old "I know! Come here!"
    new "分かったわ！ここに来なさい！"

    # say L883 mo2
    old "You'll lick my pussy... Let's see if you can do it well or you're completely useless..."
    new "私のオマンコを舐めるの……上手くできるかどうか、本当に役立たずなのか試してみましょう……"

    # say L884 pla
    old "W- WHAT? Y- Your puss-"
    new "W- 何ですか？ Y- 君のオマ○コを…"

    # say L885 mo2
    old "I don't understand why you keep talking... More licking and less talking. You're my bitch, remember?"
    new "何を言っているのかわからないわ… 舐めることに集中して、話すのはやめなさい。あなたは私の犬だということを忘れずに。"

    # say L901 pla
    old "Well, it's about [mo1], she-"
    new "まあ、それは[mo1]のことさ、彼女-"

    # say L902 mo2
    old "Ohh come on, you again with that?"
    new "あら、またあなたがそれ言うの？"

    # say L903 mo2
    old "I don't care! Don't waste my time with this bullshit."
    new "私は興味ないわ！こんなくだらないことで時間無駄にするつもりはないの。"

    # say L904 mo2
    old "I'm not going to pay again for all of you leechers..."
    new "私はまた払うつもりはないわ、あなたたちのようなサボテンのために…"

    # say L905 pla
    old "No, isn't about paying-"
    new "いや、それは支払いの話じゃないよ"

    # say L906 mo2
    old "Just go away."
    new "行っちゃってください。"

    # say L912 pla
    old "Hmm, this is not working..."
    new "うーん、これじゃうまくいかないな…"

    # say L929 sis
    old "[pla], [mo1rel] has been locked in her room all day long."
    new "[pla]、[mo1rel]は一日中部屋に閉じこもってるの。"

    # say L931 sis
    old "Yes... She's so depressed..."
    new "うん……彼女、ものすごく落ち込んでるみたい……"

    # say L932 pla
    old "This is serious... I don't know, we gotta do something."
    new "これは深刻だな… どうしようか、何か手を打たないと。"

    # say L933 pla
    old "Today I told [mo2] about my [mo1rel] but you know how she is... She refuses to get in touch."
    new "今日、[mo2]に俺の[mo1rel]のことを話したんだけど、お前も知ってる通りさ、彼女は連絡を拒むんだ。"

    # say L934 sis
    old "She's a proud motherfucker!"
    new "彼女はプライドが高いのよ！"

    # say L935 sis
    old "Keep insisting... My [mo1rel] can't be like this... We have to help her."
    new "頑張って説得するの… 私の[mo1rel]はこんな風じゃ駄目だから… 助けないと。"

    # say L936 pla
    old "I know... I will..."
    new "分かってる… 俺がやる…"

    # say L937 pla
    old "Don't worry Kylee, we'll do something."
    new "心配しなくていい、Kylee。何かするから。"

    # say L939 sis
    old "I hope we do... See you, then."
    new "何かしてあげられたらいいな… それじゃ、またね。"

    # say L945 pla
    old "I definitely have to keep trying to talk with [mo2]."
    new "[mo2]と話すのを頑張り続けるよ。"

    # say L962 mo2
    old "It really seems you're a big idiot! You keep making the same mistakes..."
    new "あなたは本当に大バカね！同じ間違いを繰り返してるのよ…"

    # say L964 mo2
    old "I assume you're already imagining how you gonna pay for it..."
    new "あなたがどうやってそれを支払うのか、もう想像しているでしょうね…"

    # say L965 pla
    old "(Oh God, Now what?)"
    new "神様、これまた何だよ…"

    # say L966 pla
    old "[mo2]... I'll try to improve, it's just that... I- I'm worried about other things and it's difficult to focus sometimes."
    new "[mo2]... 僕は改善しようと試みるけど、ただ… 心配事があって、時々集中するのが難しいんだ。"

    # say L967 mo2
    old "I don't CARE! I don't care about your shitty life."
    new "私は気にしないわ！あなたのクソみたいな人生なんて、どうでもいいの。"

    # say L969 mo2
    old "You'll need to focus on this NOW!"
    new "今すぐ集中しなければならないわ！"

    # say L970 mo2
    old "Now you will do what I tell you to do! You'll do whatever I want! I'm your Master, I'm the one paying you and you'll follow my orders!"
    new "今すぐ私が言うことを聞いて！私が何を命じてもいいんだよ！私はあなたの主人で、私が払っているのだから、私の命令に従うんだ！"

    # say L971 mo2
    old "Your job and what you do is shit! Now do what I tell you."
    new "あなたの仕事もやっていることなんてクソくさくてしょうがないわ！さあ、私が言うことを聞いて。"

    # say L972 mo2
    old "Now is the time to pay back the money I'm paying you for all your shitty work."
    new "今こそ、私が払っているお金を返す時よ。あなたの仕事はクソ同然じゃない。"

    # say L979 mo2
    old "Come on, you already know what to do."
    new "さあ、あなたが何をすべきかすでに知っているわ。"

    # say L980 pla
    old "Uhh... A- alright."
    new "うーん… 分かった。"

    # say L994 pla
    old "I know you don't wanna hear about my [mo1rel] but... B- But she is not ok, she keeps crying for you..."
    new "君は俺の[mo1rel]を聞きたくないだろうけど… でも彼女は具合が悪いんだ、君の名前を呼んで泣き続けているんだよ…"

    # say L995 pla
    old "I think she's getting depressed."
    new "彼女が鬱っぽいんじゃないかと思う。"

    # say L996 pla
    old "Why don't you call her? Just to... Argh!"
    new "なぜ彼女に電話しないんだ？ただ……うっ！"

    # say L998 mo2
    old "Crying? Is she that bad?"
    new "泣いちゃってるの？そんなに具合が悪いの？"

    # say L999 pla
    old "I'm not lying, she's feeling like shit."
    new "俺は嘘ついてないよ、彼女は相当落ち込んでるんだ。"

    # say L1000 mo2
    old "I could visi-"
    new "私は訪問しようとしていたのだけれど…"

    # say L1001 mo2
    old "No! Just stop with that bullshit... And get out..."
    new "やめて！その馬鹿げたことを止めて… そして出て行ってちょうだい…"

    # say L1016 pla
    old "What the... W- what are you doing."
    new "何やってんの… 何を…"

    # say L1019 mo2
    old "Well, I knew you wouldn't learn so I'll have to use more drastic methods."
    new "まあ、あなたが学ばないことは分かっていたので、もっと厳しい手段を取らなければならないわ。"

    # say L1020 mo2
    old "So I'm going to give you a couple of new lessons, it seems that with you it will always have to be in the hard way."
    new "だから新しいレッスンをいくつか教えてあげることにしたの、どうやらあなたにはいつも厳しい方法でなければならないようね。"

    # say L1027 mo2
    old "Alright, undress and lie on the floor."
    new "はい、服を脱いで床に寝なさい。"

    # say L1028 pla
    old "B- but... I- I don't-"
    new "でも、でも……そんなの無理だよ。"

    # say L1029 mo2
    old "Are you questioning your master's orders?"
    new "主人の命令に従わないつもりですか？"

    # say L1030 pla
    old "No, no, I'm sorry master."
    new "いいえ、いいえ、すみません、ご主人様。"

    # say L1031 mo2
    old "That sounds a lot better."
    new "そうね、それなら良かったわ。"

    # say L1044 mo2
    old "Again? Let me guess, it's about [mo1], isn't it?"
    new "また？当ててみるけど、[mo1] のことだわね？"

    # say L1045 pla
    old "Well, yes, she is-"
    new "まあ、そうだけど、彼女は-"

    # say L1046 mo2
    old "Not today, I really don't have time, I already wasted it all with you."
    new "今日は無理よ、時間がないの、あなたと話しているだけで時間を使い果たしたわ。"

    # say L1047 mo2
    old "Maybe if you do a good job I wouldn't have to waste time with you."
    new "もしかしたら上手くやれば私の時間無駄にする必要もないのかもしれないわね。"

    # say L1062 mo2
    old "What a surprise, again complaints about your work."
    new "また仕事の文句を言うなんて、意外ね。"

    # say L1063 pla
    old "Could we start, talking about [mo1]?"
    new "それじゃ、[mo1]について話しましょうか。"

    # say L1064 mo2
    old "Do you pretend to be the one who gives the orders?"
    new "あなたが命令を下す立場だと思ってるの？"

    # say L1065 pla
    old "No, I'm sorry, master."
    new "いいえ、すみません、マスター。"

    # say L1066 mo2
    old "That sounds so much better."
    new "そうね、それならよかったです。"

    # say L1067 mo2
    old "Okay, let's not waste any more time, so get naked and lie down on the floor."
    new "では、時間の無駄にしないで裸になって床に寝てください。"

    # say L1068 pla
    old "Yes, master."
    new "はい、マスター。"

    # say L1081 pla
    old "[mo2]... You can hate this... Torture me if you want... B- But my [mo1rel] is really bad, she's not even eating."
    new "[mo2]… これ嫌いだよ… 虐待してくれてもいい… でも俺の[mo1rel]はほんとヤバいんだ、食事も摂らないし。"

    # say L1083 pla
    old "Visit her, please... Make me work more if you want... But just visit her."
    new "訪ねてあげて……お願い……もっと働かせてくれてもいいけど……でも、彼女に会いに行って欲しい。"

    # say L1084 mo2
    old "Argh! Ok... Let's imagine I'll go... When should I pass by."
    new "あー！分かったわ… 行くとして、何時頃行った方がいいのかな。"

    # say L1085 pla
    old "Really? Well... Let me check with her. [mo2], thanks! This will make her so happy."
    new "本当に？じゃあ…彼女に確認してみるよ。[mo2]、ありがとう！これで彼女はすごく喜ぶだろうな。"

    # say L1086 mo2
    old "Listen little bastard! I'll go just because I wanna see if she is really that bad, not because of you. Got it?"
    new "聞きなさい、小鬼野郎！私が行くのは、彼女が本当にそんなに悪いのか見てみたくてであって、君のためじゃないの。わかった？"

    # say L1087 pla
    old "Yes, yes... T- Thanks anyway."
    new "はい、はい… とにかくありがとう。"

    # say L1089 mo2
    old "Ask her when it's a good time to swing by and I'll be there..."
    new "彼女にいつが都合がいいか聞いて、その時間に私が行くから..."

    # say L1090 mo2
    old "I hope you're not lying to me..."
    new "あなたが私を騙っていないことを願っています…"

    # say L1092 pla
    old "N- No."
    new "N- うそじゃないよね。"

    # say L1093 mo2
    old "Fuck! I'll kill you if you're lying to me."
    new "くそっ！ウソをついてたら殺すわよ。"

    # say L1094 mo2
    old "Alright, go away. I have to work."
    new "はい、分かったわ。さっさと出て行って。私は仕事があるの。"

    # say L1096 pla
    old "(At least she'll see [mo1rel]... That's something.)"
    new "せめて [mo1rel] には会えるな… それだけでも良い。"

    # say L1115 pla
    old "Hi [mo1rel]! How are you?"
    new "おう [mo1rel]！元気か？"

    # say L1116 mo1
    old "Hi honey... I'm fine, and you?"
    new "こんにちは、ハニー… 私は元気よ、あなたは？"

    # say L1117 pla
    old "Guess what?"
    new "何を当ててみる？"

    # say L1118 mo1
    old "I don't know, what happened?"
    new "何が起こったの？"

    # say L1119 pla
    old "[mo2] is coming to see you..."
    new "[mo2] が君を見に来るんだよ..."

    # say L1120 mo1
    old "What? [mo2] wants to see me? When?"
    new "何？[mo2]が私を見に来たいの？いつ？"

    # say L1121 pla
    old "Well, I talked to her and she said she will come whenever you want..."
    new "まあ、彼女と話してみたら、君がいつでもいいって言ってたよ..."

    # say L1122 mo1
    old "Oh God! That's great! Tell her to come tomorrow."
    new "ああ神様！ それは素晴らしいわ！ 明日来てって伝えて。"

    # say L1123 mo1
    old "I'll have to wear something nice... Yes, tell her that tomorrow is fine and that I'll be waiting for her."
    new "いい服を着なきゃね… はい、明日ならいいって伝えて、私が待ってるって言ってください。"

    # say L1124 pla
    old "I'll... And I'm glad you're feeling better now."
    new "俺も……君が元気になってくれて嬉しいよ。"

    # say L1125 mo1
    old "Thanks for doing this for me..."
    new "ありがとう、やってくれて..."

    # say L1126 mo1
    old "Get some rest, honey... You've been working a lot."
    new "休んでね、ハニー… 最近、頑張りすぎてるわ。"

    # say L1127 pla
    old "Every day is harder, [mo1rel]... But it's fine as long as you're fine and less worried."
    new "毎日がキツくなってる、[mo1rel]... でも君が元気で心配しなくてすむなら、大丈夫だよ。"

    # say L1128 pla
    old "I'm heading to my room... Love you [mo1rel]!"
    new "俺の部屋に行こう… 愛してるよ、[mo1rel]！"

    # say L1147 mo2
    old "And here you are again... You are definitely a lost cause."
    new "またここにいるのね… あなたは本当に hopeless な子だわ。"

    # say L1148 pla
    old "I know, I know, I'm sorry..."
    new "分かってる、分かってる、ごめん…"

    # say L1149 pla
    old "However, I actually wanted to talk about the visit- "
    new "しかし、実は君に話したいことがあったんだ……"

    # say L1150 mo2
    old "Shut up! I give a shit about what you want. I am your master and it's time for your punishment."
    new "黙って！あなたが何を欲しているかなんて私は興味ない。私はあなたの主人で、今こそあなたの罰の時だ。"

    # say L1151 mo2
    old "Get on the floor... That's your place."
    new "床に這いつくばるの... それがあなたの場所よ。"

    # say L1152 pla
    old "Come on, just a second. I don't want to do this."
    new "ちょっと待て、一瞬だけ。こんなことはしたくない。"

    # say L1153 mo2
    old "Get on the fucking floor now..."
    new "床に這いなさい、今すぐ。"

    # say L1154 pla
    old "I- I'm not gonna do it... No, no more."
    new "俺はそれをしない… もう無理だ。"

    # say L1155 mo2
    old "I'm telling you to get on the fucking floor!"
    new "私が言っているのは床に這うことよ！"

    # say L1156 pla
    old "You can't keep doing this, it's humiliating for me."
    new "これ以上は堪らない、恥ずかしいんだ。"

    # say L1157 mo2
    old "WHAT!? What did you just say to me? Did you say NO to your Master?"
    new "WHAT！？ 何て言ったの？ 主様にノーって言ったの？"

    # say L1162 mo2
    old "Do you think you are better than me? I have kicked bigger butts than yours!"
    new "あなたが私より優れていると思ってるの？私の過去の相手たちはあなたの倍も大きいのに、全部蹴散らしてきたわよ！"

    # say L1163 mo2
    old "You're getting in real trouble with me! I'm commanding you, did you get that part?"
    new "あなたは本気で私に反抗しようとしてるの？命令してるのだから、理解してるよね？"

    # say L1165 mo2
    old "Don't you dare to say NO to me, you obey to whatever I say because I'm your fucking master and you're nothing..."
    new "私にノーとは言わせないわ、私が何を言っても従うべきなのよ、だって私はあなたのクソのような主人で、あなたはただのゴミに過ぎないんだから…"

    # say L1166 mo2
    old "You're my little bitch, a cockroach, my slave..."
    new "あなたは私の小さなビッチ、ゴキブリ、私の奴隷だ…"

    # say L1167 mo2
    old "This time you will really be punished, you must learn to obey your master."
    new "今回は本当に罰を受けるわ、主人の言うことを聞くことくらい覚悟しなさい。"

    # say L1183 pla
    old "Master? May I ask you something?"
    new "マスター？　何か聞いてもいいですか？"

    # say L1184 mo2
    old "Hmm... You're learning... You're starting to understand..."
    new "ふむ…… 分かってきたのね…… 理解し始めているみたいだわ……"

    # say L1185 mo2
    old "It's good that you ask me... You don't do anything without my permission."
    new "あなたが私に尋ねるのは良いことだけど… 私の許可なしには何もしないでよね。"

    # say L1186 mo2
    old "Speak..."
    new "話すことね、私の許可を忘れずに。"

    # say L1187 pla
    old "I spoke to my [mo1rel] and she said you can go and see her today... I- if you want..."
    new "俺の[mo1rel]に話したんだけど、君が今日会いに行っても大丈夫だってさ… 行きたいなら…"

    # say L1188 mo2
    old "Hmm... Fine... I'm going today... Just want to get it over with..."
    new "うーん… 分かったわ… 今日行くから… 早く済ませたいだけだからね…"

    # say L1189 pla
    old "T- Thanks..."
    new "ありがとう……"

    # say L1190 mo2
    old "Alright, now get out!"
    new "さあ、さっさと出ていって。"

    # say L1196 pla
    old "Oh God, what just happened... At least [mo1rel] will be happy today..."
    new "おお、何が起こったんだ… でも少なくとも [mo1rel] は今日満足そうだな…"

    # say L1197 pla
    old "I can't keep working here, I need to get away from [mo2]'s office."
    new "ここではもう働けない、[mo2]のオフィスから離れなくちゃ。"

    # say L1214 mo1
    old "Hi honey, how do I look?"
    new "おひさしぶり Darling、どう思う？"

    # say L1215 pla
    old "Wow, you look gorgeous!"
    new "君、本当に gorgeous だね。美しいよ。"

    # say L1216 mo1
    old "Oh, really? Thank you honey..."
    new "あら、ほんとうに？ ありがとう、はちみつ…"

    # say L1217 mo1
    old "So? Do you have any news about [mo2]?"
    new "そう？ [mo2] のことなら何か新しい情報があるの？"

    # say L1218 pla
    old "Uhh, yes, [mo2] is coming today... If that's what you're asking..."
    new "うーん、そうだ、[mo2] は今日来るんだ… それが聞きたいことなら。"

    # say L1219 mo1
    old "Great! I'm gonna get ready for her."
    new "素晴らしい！彼女が来る準備をしておくわ。"

    # say L1220 pla
    old "I hope you enjoy seeing her... And if you need anything, just let me know, [mo1rel]..."
    new "君が会えて楽しいといいな…何か必要なことがあれば教えてくれ、[mo1rel]…"

    # say L1221 pla
    old "Now I gotta go, I need to take a nap..."
    new "じゃあ、俺は寝るよ。ちょっと小休止が必要そうだ..."

    # say L1222 mo1
    old "Sure, take care, honey."
    new "もちろん、気をつけてね、ハニー。"

    # say L1230 pla
    old "(Huh? What's that noise?)"
    new "へ？何の音だ？"

    # say L1235 pla
    old "It's on my [mo1rel]'s bedroom..."
    new "それは俺の [mo1rel] の寝室に…"

    # say L1242 pla
    old "Wow, they are having sex!"
    new "おい、セックスしてるんだな！"

    # say L1243 pla
    old "Oh my God, I have never been so happy to see someone having sex!"
    new "お gode、こんなに幸せな気持ちになったのは初めてだよ！"

    # say L1251 pla
    old "Fuck! This is great! I won't have to work for [mo2] anymore..."
    new "くそ！これでいいんだ！[mo2]の仕事から解放される..."

    # say L1252 pla
    old "They're back together, everything will be fine and I won't have to go back to her office."
    new "彼らがまた一緒に戻った、すべてがうまくいくだろうし、もう彼女のオフィスに戻らなくて済むんだ。"

    # say L1270 pla
    old "From now on, I am free! I will no longer have to bear Jane's humiliations!"
    new "これからは自由だ！ジェーンの屈辱から解放されるぞ！"

    # say L1281 pla
    old "H- Hey... [mo2], h- how are you?"
    new "Hey… [mo2]、お前はどうしてる？"

    # say L1282 mo2
    old "Don't pretend to be a good guy... I know how shitty you're and how pervert you can be."
    new "いい人を装わないで…私はあなたの本性を知っていますから。あなたがどれだけクソ野郎で、どれだけ変態か、よくわかっていますよ。"

    # say L1284 mo2
    old "I have a business trip, but I'll see you in the office in a few weeks..."
    new "出張に行くんだけど、数週間後にオフィスで会うわ…"

    # say L1285 pla
    old "B- But..."
    new "だけど"

    # say L1286 mo2
    old "Excuse me!?"
    new "失礼ですが？"

    # say L1287 mo2
    old "Did I hear a BUT?"
    new "でもって言いましたか？"

    # say L1288 mo2
    old "I thought you had already learned how you have to talk to me..."
    new "あなたはもう、私にどのように話すべきか学んだと思っていたのに…"

    # say L1289 pla
    old "S- Sorry..."
    new "すみません…"

    # say L1291 pla
    old "Master... May I talk to you?"
    new "マスター… 話せていいですか？"

    # say L1292 mo2
    old "Now you can, slave."
    new "今から話せるわね、奴隷。"

    # say L1293 pla
    old "You said that we'll see each other in the office bu-"
    new "君が言ったように、オフィスで会うってことだな。"

    # say L1294 mo2
    old "Yes, I said it!"
    new "はい、そう言ったわ！"

    # say L1295 mo2
    old "You'll do whatever I want, nothing's gonna change..."
    new "あなたは私が望むことを全部してくれるわ、何も変わらないわ…"

    # say L1297 mo2
    old "Don't forget that... Now you are my bitch."
    new "忘れないで… 今あなたは私の犬だよ。"

    # say L1299 pla
    old "Y- Yes..."
    new "Ｙ－はい…"

    # say L1301 pla
    old "Oh God... "
    new "ああ…神様"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Institute.rpy
translate japanese strings:

    # say L15 pla
    old "I should go to the garage to talk with Brixxida first."
    new "まずはブリクシダと話さないとね。"

    # say L53 hin
    old "Well, she is in the classroom right now. You should go and show her."
    new "今は教室にいるわ。行って見せてあげて。"

    # say L55 pla
    old "Ok. Doing it now."
    new "わかった、今行くよ。"

    # say L174 pla
    old "Nothing much, it’s just that I haven’t seen you when I’ve gone to your home to do the repairs on the bathroom."
    new "別に、ただ君の家で風呂場の修理をした時に君に会えなかっただけさ。"

    # say L175 hin
    old "Yeah, I’m sorry about that."
    new "うん、すみません。"

    # say L176 hin
    old "This whole extracurricular work has been keeping me busy."
    new "この部外活動の仕事で忙しくてね。"

    # say L177 hin
    old "But it’s supposed to count for extra credit for college, so, I guess that’s alright."
    new "でも、大学の追加単位のために必要なんだから、まあいいか。"

    # say L178 pla
    old "Of course, of course, I totally get it."
    new "もちろん、全然わかるよ。"

    # say L179 hin
    old "I’ll make it up to you once I’m done with all of this."
    new "私が全部終わったら、ちゃんとお詫びするからね。"

    # say L180 hin
    old "We’ll also have some time to ourselves once you’re done with the bathroom."
    new "あなたがトイレを済ませたら、私たちもゆっくりできる時間ができるわ。"

    # say L181 pla
    old "Yeah, I guess I better hurry to finish with that. The sooner the better."
    new "早く済ませた方がいいな。早ければ早いほど良いよ。"

    # say L182 hin
    old "It’s very kind of you to do that for us."
    new "そんなに気を使ってくれて、本当に感謝してるわ。"

    # say L183 pla
    old "No problem, it’s rather easy."
    new "問題ないよ、わりと簡単なことさ。"

    # say L184 pla
    old "By the way, I think I’ll go work on that right now."
    new "それじゃ、今すぐその作業に取りかかるよ。"

    # say L185 pla
    old "See you later Hinn."
    new "じゃあ、後でな、Hinn。"

    # say L187 hin
    old "Sure, see you later."
    new "うん、またね。"

    # say L203 pla
    old "Hey, Hinn"
    new "Hey, Hinn、ちょっと待って。"

    # say L207 pla
    old "Do you have a therapy appointment today with Dr. Johnson?"
    new "今日、Dr. Johnsonとのカウンセリングがあるのか？"

    # say L209 hin
    old "No, actually I think we should work on the class project today."
    new "実は今日、クラスのプロジェクトに取り組む方がいいと思うの。"

    # say L211 pla
    old "You are right, we have work to do."
    new "君が言う通りだ、やるべきことがあるな。"

    # say L213 hin
    old "If we make a good progress I could set an appointment for tomorrow."
    new "もし進捗がよければ、明日の予定を立てられるわ。"

    # say L215 pla
    old "Always that responsible. That sounds good to me."
    new "いつもそんなに責任感が強いんだな。それはいいよ。"

    # say L218 hin
    old "Hehehe... Great, see you in my house."
    new "へへへ… じゃあ、明日私の家でね。"

    # say L220 pla
    old "Perfect. See you then."
    new "完璧だな。じゃあ、その時間に会おう。"

    # say L250 bel
    old "Hey, [pla]!"
    new "Hey、[pla]！"

    # say L252 pla
    old "Hi Bell."
    new "こんにちは、ベル。"

    # say L254 bel
    old "Did you start to work on your project?"
    new "プロジェクトの準備は始めてるの？"

    # say L256 pla
    old "Well, I talked to Hinn, I think we're going to start this afternoon..."
    new "WELL、ヒンと話したんだ、今日の午後に始めるつもりだよ..."

    # say L258 bel
    old "Lucky you, I got paired with that asshole Mike this time. I don't know how everything is going to work out..."
    new "運がいいね、私はまたあのクソ野郎のマイクと組まされるんだよ。どうなるかわからないけど..."

    # say L260 pla
    old "Don't worry, Mike is good whenever he tries."
    new "心配しなくていい、Mikeは真剣になればいい奴だよ。"

    # say L262 bel
    old "Hmm... I sure hope so..."
    new "うーん……そうであってほしいな……"

    # say L264 pla
    old "Ok... Bell, I have to go to meet with Hinn. Bye."
    new "Ok... Belle、ヒンと会いに行くんだ。じゃな。"

    # say L266 bel
    old "See you later, [pla]..."
    new "またね、[pla]..."

    # say L274 bel
    old "Hey, [pla]! How did it go with your project?"
    new "Hey、[pla]！プロジェクトどうだった？"

    # say L276 pla
    old "Actually, great! Hinn is quite good and she has taught me a lot..."
    new "実は、すごく良かったんだ！ヒンはかなり優秀で、教えてくれることがたくさんあったよ..."

    # say L278 bel
    old "Hmm... Right, Hinn is a pretty nerd... Mine is an ugly asshole..."
    new "うーん… そうよね、Hinnはわりと勉強熱心だもん… 私のはクソ野郎だよ…"

    # say L280 pla
    old "It can't be that bad ..."
    new "そんなに悪くないだろう…"

    # say L282 bel
    old "It can't be that bad?... We went to my house to study and he tried to look in my underwear drawer... Three times!"
    new "そんなに悪いわけないって？… 勉強しに家に来たのに、下着の引き出しを覗こうとしたの… 三回も！"

    # say L284 pla
    old "Really?... Uhh weird..."
    new "本当に？… うーん、変だな…"

    # say L286 bel
    old "Tell me about it... I have to do everything by myself."
    new "言ってみろ……全部自分でやってるの。"

    # say L288 pla
    old "Too bad... Fortunately, you are smart and you can actually do it alone. I really couldn't without help."
    new "残念だけど... 幸い、君は頭がいいから一人でできるんだ。俺は絶対に無理だな。"

    # say L290 bel
    old "... Seriously, every time I see Mike, I just want to kill him..."
    new "... 本気で、毎回マイクを見ると殺したい気持ちになるの..."

    # say L292 pla
    old "Damn... Well, Bell, I have to go. I will see you later..."
    new "くそ……まあ、ベル、俺は行くぞ。後でな……"

    # say L294 bel
    old "See you later, [pla]!"
    new "またね、[pla]！"

    # say L297 bel
    old "Hey, [pla]! How's it going?"
    new "Hey、[pla]！どうしてる？"

    # say L299 pla
    old "Hi Belle, I'm doing great!"
    new "嗨ベル、元気だよ！"

    # say L300 pla
    old "A little busy with school work and stuff, you know."
    new "学校の勉強とかもあってちょっと忙しいんだ、わかってるよね。"

    # say L302 bel
    old "Yeah, I get it."
    new "うん、わかるよ。"

    # say L303 pla
    old "How about you?"
    new "君はどう？"

    # say L305 bel
    old "Well, I guess I'm ok."
    new "まあ、いいかんじかな。"

    # say L307 bel
    old "Lately my mom has been a little intense."
    new "最近、ママがちょっとハリキってるんだよね。"

    # say L308 bel
    old "She's always coming and going from home."
    new "最近、家に出入りが頻繁なの。"

    # say L310 bel
    old "And every time she's home she wants to see me or talk to me "
    new "家にいるときもいつも私と会いたがるのよ。"

    # say L312 pla
    old "Hmm... I can imagine how annoying it must be."
    new "うるさく感じてるだろうな。"

    # say L314 bel
    old "I guess I'll have to deal with it."
    new "しょうがないね、我慢するしかないみたいだ。"

    # say L315 bel
    old "She's been handling a lot because of her job."
    new "彼女は仕事のせいでかなり大変な思いをしてるんだよね。"

    # say L316 bel
    old "So, I guess that when the whole thing is over she'll be right back to normal."
    new "そうね、全部終われば元に戻るだろうね。"

    # say L317 pla
    old "Yeah, I'm sure she will."
    new "うん、きっと元に戻るよ。"

    # say L318 pla
    old "Hey, I have to run, but I'll see you later."
    new "Hey、ちょっと行かなきゃだけど、後でまた会うよ。"

    # say L320 bel
    old "Sure, see you."
    new "じゃあね、またね。"

    # say L323 pla
    old "Hi Belle, good morning."
    new "嗨ベル、おはよう。"

    # say L325 bel
    old "Hi [pla]..."
    new "おはよう、[pla]..."

    # say L326 bel
    old "How are you?"
    new "おはよう、元気？"

    # say L327 pla
    old "I'm ok, how are you doing?"
    new "俺は大丈夫、君はどう？"

    # say L329 bel
    old "Well, I'm fine I think."
    new "まあ、大丈夫かなと思うわ。"

    # say L330 bel
    old "The situation has been tense with my mom since our fight."
    new "ママとのケンカ以来、家の中は緊張が走ってるの。"

    # say L332 bel
    old "So we're not actually talking right now."
    new "だから今 practically話してないの"

    # say L334 bel
    old "But other than that I'm doing well."
    new "でも、それ以外は調子いいよ。"

    # say L335 bel
    old "Since I moved with Amorette, and I've been able to work from her home."
    new "アモレッテと引っ越してから、彼女の家で働けるようになったの。"

    # say L337 bel
    old "So on that end, everything's fine."
    new "その点では、すべて順調よ。"

    # say L339 pla
    old "Ok, I see, well, I guess that's fine."
    new "分かった、まあ、それならいいだろう。"

    # say L340 pla
    old "As long as you're ok, I suppose everything's alright."
    new "君が大丈夫なら、まあいいか。"

    # say L342 bel
    old "Yeah."
    new "うん。"

    # say L343 pla
    old "Alright, it was nice to see you. See you later, Belle."
    new "そうだな、会えて良かった。またね、ベール。"

    # say L345 bel
    old "Sure. See you later, [pla]."
    new "うん、またね、[pla]。"

    # say L375 pla
    old "Uhh... Nothing. I was just heading out. Sorry."
    new "うーん… 何もなかったよ。ただ出かけるところだったんだ。ごめん。"

    # say L402 mia
    old "What do you want [pla]?"
    new "何をしたいの、[pla]？"

    # say L405 pla
    old "I... wanted to talk about the final project."
    new "俺... 最終プロジェクトについて話したかったんだ。"

    # say L406 mia
    old "Is it ready? Do you have any progress to show?"
    new "準備できましたか？進捗を見せられるところはありますか？"

    # say L416 mia
    old "Wow, I can't believe it. You guys did it..."
    new "Wow、信じられないわ。あなたたち、本当にやったのね…"

    # say L418 pla
    old "And... How was it?"
    new "そして… どうだったか？"

    # say L420 mia
    old "Your project is... Good... I guess..."
    new "あなたのプロジェクトは… 良かった… と思いますね…"

    # say L435 mia
    old "You have completed a lot. I have to say I am surprised..."
    new "あなたがこれだけ完成させていたとは驚きました..."

    # say L437 mia
    old "By the way, I talked with your partner... And she said you have been working hard... I wasn't sure, but I have to believe her... Maybe I underestimated you, [pla]."
    new "それにしても、あなたのパートナーと話したのだけれど… 彼女いわく、あなたは頑張っているそうよ… 私は少し疑っていたけど、彼女を信じるしかないわ… 多分、あなたを見くびっていたのかもしれないわね、[pla]。"

    # say L439 pla
    old "Thank you!"
    new "ありがとうございます。"

    # say L441 mia
    old "Don't get too excited. You still have a lot of work to do before it is done."
    new "興奮しすぎないで。まだ完成するまでにたくさんの仕事があるわ。"

    # say L457 mia
    old "I can't believe you did something of this... I need to talk with your partner, tell her to come and talk with me... ALONE!"
    new "これほどまでに…信じられないわ。パートナーと話さないと。彼女に来て、私とひとりで話すように伝えて。"

    # say L459 pla
    old "Hmm... Ok... I will tell her..."
    new "うーん… 分かった… 言っておくよ…"

    # say L474 mia
    old "Ok, now this is getting really suspicious..."
    new "はい、これで本当に怪しい雰囲気になってきたわね。"

    # say L478 mia
    old "Anyway, I'm busy to worry about you..."
    new "とにかく、私は忙しくてあなたのことは気にかけられないわ。"

    # say L480 pla
    old "Hmmm ok."
    new "うーん、そうか。"

    # say L494 mia
    old "Oh? Have you made more progress? Is your partner doing everything?"
    new "Oh？進展があったの？パートナーは全部やってくれてるの？"

    # say L496 pla
    old "What?! Of course not! This is all team work."
    new "何だって！？ もちろんそんなことないよ！これは全部チームワークさ。"

    # say L498 mia
    old "Hmm... You haven't screwed it up yet. I will keep waiting."
    new "ふむ……まだ失敗してないのね。待ってるわ。"

    # say L511 mia
    old "Oh, you have started... But you still have a lot of work to do before you are done..."
    new "お、始めてるのね… でも、まだ終わるまでにはたくさんの仕事があるわよ…"

    # say L513 pla
    old "But?... How is it?"
    new "でも？… どうなってるんだ？"

    # say L515 mia
    old "For now, it's ok. But I'm sure you will screw it up, sooner or later."
    new "今のところは大丈夫よ。でもきっと、いずれ失敗するわ。"

    # say L526 mia
    old "As I thought... then don't bother me. Talk to me when you've made some progress... if you even can, of course..."
    new "思ってた通り…邪魔しないで。進展があったら私に話しかけて。もちろん、できるかどうかは別だけど…"

    # say L537 mia
    old "Yeah, yeah congratulations, your project was good, are you happy?"
    new "はいはい、おめでとう、あなたのプロジェクトは良かったわね、満足してるの？"

    # say L539 pla
    old "Thanks! see you!..."
    new "ありがとう！またね！"

    # menu L573 
    old "Start the Class"
    new "授業を始める"

    # say L593 luc
    old "The class will start soon, [pla]."
    new "授業始まるよ、[pla]。"

    # say L594 luc
    old "Just take a seat."
    new "座ってください。"

    # say L595 pla
    old "... Uhhh sure."
    new "うーん、そうか。"

    # say L755 mia
    old "Well, ladies and gentlemen. Please remember the final project you have to do..."
    new "皆さん、最後のプロジェクトのことをお忘れなく…"

    # say L757 pla
    old "(Hmm... The final project... one of the hardest and boringest things ever!)"
    new "うーん… 最終課題か… 一番難しいし退屈なやつだな…"

    # say L758 pla
    old "(I mean, research? Bibliographies? Theoretical framework?... All that work on stuff I'll never use...)"
    new "（研究だの、参考文献だの、理論的枠組みだの……使わなさそうなことにそんなに労力を使うなんて……）"

    # say L764 pla
    old "(I really want to graduate and be free from all of this crap…)"
    new "（俺は卒業して、このクソから解放されたいよ…）"

    # say L773 pla
    old "Where did it fall from?... An airplane?"
    new "どこから落ちてきたの？... 飛行機から？"

    # say L777 pla
    old "Sorry, Mrs. Mia. I'm listening. I was just... looking through the window..."
    new "すみません、ミア先生。聞いてましたよ、ただ…窓の外を見ていただけで…"

    # say L778 mia
    old "Oh really? Then please tell us all the project requirements that I just explained..."
    new "あらほんと？ それなら私が説明したプロジェクトの要件を全部教えてちょうだい。"

    # say L789 pla
    old "Ughh... Finally free!..."
    new "うげっ… やっと自由か…"

    # say L791 pla
    old "(I don't know how I'm going to get that project done.)"
    new "あのプロジェクト、どうやって完成させられるか全然わからないな。"

    # say L798 bel
    old "Hey [pla]!"
    new "Hey [pla]！"

    # say L800 pla
    old "Hey, Bell! I wanted to ask you... if we... could work together in the class project?"
    new "ベール！ちょっと聞いてさ、クラスのプロジェクトで一緒にやらない？"

    # say L802 bel
    old "You wasn't paying attention, huh?"
    new "あなた、授業中ぼけちゃってたんでしょ？"

    # say L804 pla
    old "What?... What you mean?"
    new "何？… 何それ？"

    # say L806 bel
    old "This project is for couples and your partner is Hinn."
    new "このプロジェクトはカップル向けで、あなたのパートナーはヒンよ。"

    # say L808 pla
    old "Really? OK, thanks anyway."
    new "ほんと？ 分かった、ありがとう。"

    # say L813 mik
    old "Heyyy guys! Did you notice  Mia`s neckline, every day she gets hotter and hotter."
    new "へええ、みんな！ミアの襟元に気づいた？毎日エロくなっていくな。"

    # say L816 bel
    old "Really Mike? She could be your mother ... "
    new "Really Mike？ 她はお前の母親くらいの歳かもしれないよ ..."

    # say L818 mik
    old "That makes it even more sexy. A hot ass milf teaches us. Sounds nice, aye, [pla]?"
    new "それが逆にセクシーだよ。エロい熟女先生に教えてもらうんだ。いいじゃん、[pla]？"

    # say L820 pla
    old "I only know that she hates my guts and each day it gets worse. I just hope I'm alive at the end of the school year."
    new "俺はただ、彼女が俺のことを嫌いになっていて、毎日それが悪化しているってことだけ知ってんだ。学校が終わるまでに生き残れることだけを願ってる。"

    # say L822 bel
    old "Well, I'm leaving. I have things to do. And I don't want to stay here and keep listening to Mike's perversions."
    new "まあ、私は行くわ。やることあるし。それに、マイクの変態発言を聞いてるのも飽きたわ。"

    # say L824 pla
    old "Bye, Belle. See you around."
    new "バイ、ベール。またな。"

    # say L831 mik
    old "Have you noticed how hot Belle is gettin'?"
    new "ベールが最近、めちゃくちゃかわいくなってきただろ？"

    # say L833 pla
    old "Dude... Damn, you should calm down a little."
    new "おい… ちょっと落ち着けよ。"

    # say L835 mik
    old "Why? Are you gay or something?"
    new "なんで？お前、ゲイとか？"

    # say L837 pla
    old "Bye, Mike. I'll talk to you later"
    new "バイ、マイク。後でな"

    # say L839 mik
    old "So I'm right, huh? But she is hot, isn't she?"
    new "じゃあ俺の予想が当たってたのか。でも、彼女は hott だろ？"

    # say L856 pla
    old "Wait... Is this...?"
    new "待て……これって……？"

    # say L858 pla
    old "The book that fell from the sky?"
    new "空から落ちてきた本？"

    # say L860 pla
    old "SexNote?  What could it be about?"
    new "SexNote？　何について書いてあるんだ？"

    # say L862 pla
    old "Weeeell, finders-keepers. Hehe."
    new "まあ、見つけたものは自分のものだな。へへ。"

    # say L864 pla
    old "Maybe I can think of something interesting to draw in it."
    new "何か面白いものを描けるかもしれないな。"

    # say L883 mik
    old "Hey, wait! Before you go... I have something to show you that will surely blow your mind."
    new "おい、待て！ 行く前に……俺が見せたいものがあるんだ。絶対に驚くぞ。"

    # say L885 pla
    old "Now what weird thing do you have in mind?"
    new "今度は何の変なこと考えてんだ？"

    # say L887 mik
    old "Listen... Just go to my house and look for me in my room. I'll show you."
    new "待て、待て... 家に来て俺の部屋で探してみろ。見せてやるよ。"

    # say L889 pla
    old "Hmm, alright... I will see you then."
    new "うん、わかった… それじゃあ待ってるぞ。"

    # say L891 mik
    old "Seriously, [pla].I assure you it will be worth it!"
    new "本気で、[pla]。絶対に見てくれって言うだけの価値があるよ。"

    # say L908 pla
    old "I shouldn't enter. This isn't my classroom."
    new "入っちゃいけない。これは俺の教室じゃない。"


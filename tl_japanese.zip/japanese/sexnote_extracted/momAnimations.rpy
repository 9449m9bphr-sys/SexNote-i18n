# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/momAnimations.rpy
translate japanese strings:

    # say L7 mo1
    old "Oh yes, just like that. Does it feel nice hun?"
    new "そうですの、その調子で。気持ちいいわよね、親愛なる？"

    # say L8 pla
    old "Mmmm yeah, it feels really nice."
    new "うん、本当に気持ちいい。"

    # say L9 mo1
    old "Great, just relax and enjoy the... Uhmm massage."
    new "Great、ゆっくりリラックスしてマッサージを楽しんでみてくださいね。"

    # say L13 mo1
    old "Let me do it a bit faster."
    new "少し速くやってみようか。"

    # say L17 mo1
    old "Uhmm? does it hurt darling??"
    new "うん？　痛いの？　Darling？"

    # say L18 pla
    old "No, no, don't worry. It feels better."
    new "大丈夫、心配しなくていい。もっと気持ちいいよ。"

    # say L19 mo1
    old "Ohh, ok, I'm glad."
    new "あら、そうね、安心したわ。"

    # say L23 pla
    old "Hmm, [mo1rel]? Would you please do it faster?"
    new "うーん、[mo1rel]？もっと速くしてもらえる？"

    # say L24 mo1
    old "Ohh, of course hun."
    new "もちろん、甘いの。"

    # say L28 pla
    old "Ohhh yes, yes, just like this."
    new "オーッ、そうそう、これでいいんだ。"

    # say L29 mo1
    old "I can feel that body is tensing up. You can release your load whenever you want, darling."
    new "その体の緊張を感じてるわ。 Darling、いつでも出してもいいのよ。"

    # say L53 pla
    old "Mmmm, [mo1rel] I- I feel like I'm going to explode..."
    new "うん、[mo1rel] 俺、俺が爆発しそうだ…"

    # say L54 mo1
    old "It's alright honey, just let it all go."
    new "大丈夫よ、全部出していいのよ。"

    # say L55 pla
    old "Ahhh... Ahhhh!"
    new "アーッ… アーッ！"

    # say L60 mo1
    old "Mmmm, good job honey. You did it just great."
    new "いい仕事したわね、よくできました。"

    # say L61 pla
    old "-Sigh- Thanks [mo1rel]."
    new "あー、ありがとう[mo1rel]。"

    # say L66 mo1
    old "Okay, this will definitely help."
    new "これで絶対に良くなるわね。"

    # say L67 pla
    old "Thanks."
    new "ありがとう。"

    # say L68 mo1
    old "You are welcome honey, I hope you feel better now."
    new "大丈夫よ、今すぐ休んでね。早く良くなってほしいわ。"

    # say L69 pla
    old "Yes, I do. although I'm feeling a bit tired."
    new "うん、ありがとう。でもちょっと疲れてるな。"

    # say L70 mo1
    old "Aww, don't worry hun, just rest a little."
    new "あら、心配しないで、少し休んであげるから。"

    # say L72 mo1
    old "Oh, and remember, don't tell anyone. Especially [mo2]! She wouldn't understand and would kill us!"
    new "あ、それとね、誰にも言わないで。特に[mo2]には絶対にダメよ。彼女は理解しないわよ、私たちを殺してしまうかもしれないし。"

    # say L73 pla
    old "Ok [mo1rel]."
    new "分かった、[mo1rel]。"

    # say L74 mo1
    old "You know you can always count on me."
    new "あなたが私をいつでも頼りにできるってことはわかってるわ。"

    # say L75 pla
    old "Yes, thank you [mo1rel]."
    new "はい、ありがとう [mo1rel]。"

    # say L76 mo1
    old "You are welcome. Well, if you need me, you know where to find me."
    new "どういたしまして。必要であれば、私を見つける場所は知っているでしょう。"

    # say L98 mo1
    old "Oh my God, I can't believe how big it is."
    new "おおっ、これほど大きいなんて信じられない。"

    # say L100 mo1
    old "Is the biggest I have ever seen."
    new "私が見た中で一番大きいのよ。"

    # say L105 mo1
    old "Do you like how I'm jerking you off?"
    new "私が你を手伝っているのが好きですか？はい、それが正しい文脈ではありません。私はあなたを手伝っているのではなく、あなたをオナホしているのです。"

    # say L106 pla
    old "... Y- yes it feels nice."
    new "…うん、気持ちいい。"

    # say L107 mo1
    old "Mmm, your cock looks really tasty."
    new "うん、あなたのチ○ポ、とっても美味しそうね。"

    # say L113 mo1
    old "Are you getting close?"
    new "もうすぐいきそうですか？"

    # say L114 pla
    old "Uhh y- yes."
    new "うーん、はい。"

    # say L115 mo1
    old "Would you like to cum for me?"
    new "あなた、私にイッてあげたい？"

    # say L155 pla
    old "Mmmm, [mo1rel] I- I gonna cum..."
    new "うん、[mo1rel] もうイキそう…"

    # say L156 mo1
    old "Oh yeah, cum for mommy."
    new "あらそう、ママの中に出して。"

    # say L162 pla
    old "Ughh, that was so intense, [mo1rel]."
    new "うげっ、それがあまりにも強烈だったな、[mo1rel]。"

    # say L163 mo1
    old "Mmmm, I'm glad you liked it..."
    new "うふふ、良かったみたいね…"

    # say L164 mo1
    old "But... Now, let's finish watching this movie."
    new "でも……これからは、この映画を最後まで見ましょう。"

    # say L165 pla
    old "For sure."
    new "もちろん。"

    # say L178 mo1
    old "Mmmm, it tastes really good."
    new "うーん、本当に美味しいです。"

    # say L179 mo1
    old "Does it feels better than my hand, isn't it?"
    new "手よりもずっといい感じがするわね。"

    # say L180 pla
    old "Uhhh, yeah."
    new "うーん、そうか。"

    # say L185 mo1
    old "Do you like to feel my warm and wet mouth?"
    new "私の温かく濡れた口が好きですか？"

    # say L186 pla
    old "Ohhh, y- yes it feels amazing."
    new "オッ、うん、はい、すごく気持ちいい。"

    # say L187 mo1
    old "Then there is something that you are going to enjoy even more."
    new "それなら、もっと楽しめるものがあるわ。"

    # say L192 mo1
    old "Mmmm, I love to suck your cock!"
    new "んん、あなたのチ○ポを吸うのが大好きです！"

    # say L193 mo1
    old "Would you like to cum in my mouth?"
    new "ハニー、私の口でイきたい？"

    # say L194 pla
    old "Wow, can I?"
    new "Wow、本当にいいのか？"

    # say L195 mo1
    old "Mmmm, please honey. I would love to taste all your load."
    new "まmmm、お願いね honey。あなたの精液全部味わいたいわ。"

    # say L234 pla
    old "Mmmm, [mo1rel], I feel like..."
    new "んん、[mo1rel]、感じてきてるけど…"

    # say L237 mo1
    old "Glurpp... Wow, it was a huge load."
    new "グルップ… すごい量だったわ。"

    # say L239 mo1
    old "Glup... Whew, I had to swallow a lot."
    new "グルッ… ふう、たくさん飲みましたね。"

    # say L243 pla
    old "It was AMAZING [mo1rel]."
    new "それは最高だったね [mo1rel]。"

    # say L244 mo1
    old "Well, I'm glad you loved it..."
    new "まあ、あなたがそれを楽しんでくれて嬉しいわ..."

    # say L245 mo1
    old "But now let's continue the movie."
    new "でも今から映画を続けましょう。"

    # say L267 pla
    old "Is this a dream?"
    new "これは夢か？"

    # say L268 pla
    old "Oh my gosh! My [mo1rel] it's fucking hot!"
    new "俺の[mo1rel]、めっちゃ熱いぞ！"

    # say L273 pla
    old "Holly shit! Look at those tits bouncing!"
    new "ホーリー・シット！そのおっぱい跳ねてるぞ！"

    # say L274 pla
    old "This view is amazing."
    new "この景色は最高だな。"

    # say L303 pla
    old "Wow... That was a dream?"
    new "Wow... それって夢だったのか？"

    # say L305 pla
    old "It was very strange because it felt very real..."
    new "不思議な夢だったな、現実のようだったから…"

    # say L307 pla
    old "Anyway, I better go to sleep..."
    new "まあ、寝た方がいいな…"

    # say L326 pla
    old "Mmmm, it feels really nice."
    new "ん〜、すごく気持ちいいな。"

    # say L327 mo1
    old "Sorry, did you say something?"
    new "すみません、何かおっしゃいましたか？"

    # say L328 pla
    old "Uhmm, no, no sorry."
    new "うーん、いいえ、すみません。"

    # say L329 pla
    old "(Shit I better stay quiet)"
    new "（しまった、黙っとかなきゃ）"

    # say L369 mo1
    old "Wow honey, did you spill more sunscreen in my legs?"
    new "Wow honey, did you spill more sunscreen in my legs？"

    # say L370 pla
    old "(Oh shit...) Yes, I spilled more to make sure, you don't get sunburned."
    new "（しまった…）うん、確実に日焼けしないようにもっと塗ったんだ。"

    # say L373 mo1
    old "Aww, you are a sweetheart."
    new "あら、あなたって優しいのね。"

    # say L374 pla
    old "(Oh fuck that was close... Should I make another try?)"
    new "（クソ、危なかった……また試してみるか？）"

    # say L380 pla
    old "{color=#00b8e7}{b}(-SAURON'S MOUTH POWER ACCOMPLISHED-){/b}{/color} (I can't waste this chance.)"
    new "{color=#00b8e7}{b}(サウロンの口の力が完成した){/b}{/color} このチャンスを無駄にはできないな。"

    # say L385 pla
    old "{b}Sauron's mouth:{/b} Now is your turn... Use your feet to massage me, ok?"
    new "{b}サウロンの口：{/b} 今こそ君の番だ… 足でマッサージして、いいかい？"

    # say L393 pla
    old "(Holly shit! Is working.)"
    new "くそ、効いてるぞ。"

    # say L398 pla
    old "{color=#d74627}{b}(-INSUFFICIENT SAURON'S MOUTH POWER-){/b}{/color} (No, I shouldn't take risks.)"
    new "{color=#d74627}{b}(-INSUFFICIENT SAURON'S MOUTH POWER-){/b}{/color} いや、リスクは取らない方がいいと思う。"

    # say L399 pla
    old "Well is done, I think you are perfect now."
    new "WELL DONE、君はもう完璧になったな。"

    # say L400 mo1
    old "Aww, thank you so much, see you later sweetheart."
    new "あら、ありがとう。またね、甘いもの。"

    # say L445 pla
    old "Holy shit, I can't help it anymore..."
    new "Holy shit、我慢できねぇよ…"

    # say L496 mo1
    old "What the fuck?"
    new "何だこれは！"

    # say L497 pla
    old "(Oh... Shit.)"
    new "オッシャイ。"

    # say L505 mo1
    old "What the fuck were you doing [pla]!?"
    new "何してたの [pla]！"

    # say L506 pla
    old "Sorry I... I..."
    new "ごめん、俺… 俺…"

    # say L508 mo1
    old "You were rubbing your... With my ass?"
    new "あなたが私の... とこすってたの？"

    # say L512 mo1
    old "I can't believe it! What's wrong with you?"
    new "信じられないわ！一体何考えてるの？"

    # say L513 pla
    old "Sorry... It was not my intention..."
    new "ごめん... 意図したわけじゃなかったんだ..."

    # say L515 mo1
    old "It wasn't your intention? What the fuck?..."
    new "それはあなたの意図じゃなかったの？何言ってるの？"

    # say L516 mo1
    old "I... I'll clean it myself, I don't want to see you anymore..."
    new "私が自分で片付けます、あなたとはもう会いたくないですね。"

    # say L519 pla
    old "Oh shit, I messed it up."
    new "ああシャレオツ、またやっちまった。"

    # say L527 mo1
    old "Again?"
    new "また？"

    # say L533 mo1
    old "Oh honey again?"
    new "またね、ハニー？"

    # say L534 pla
    old "I'm sorry I couldn't resist, I can't control it"
    new "ごめん、我慢できなかった。止めるのが難しいんだよ。"

    # say L536 mo1
    old "Mmm... It's alright, just please try not to rub your... against my ass, ok?"
    new "mmm… 大丈夫よ、でもせめて私の尻に…こすりつけるのは控えてね？"

    # say L540 mo1
    old "If you need to release it, you can ask my help or do it by yourself."
    new "もし出したいなら、自分でやっても良いし、私の手を借りてもいいわよ。"

    # say L542 pla
    old "You're right... It was not my intention..."
    new "君が言う通りだ… 意図したわけではないけど…"

    # say L544 mo1
    old "I know sweetheart don't worry..."
    new "Darling、心配しなくていいのよ..."

    # say L546 mo1
    old "I'm going to clean myself."
    new "お風呂に入ります。"

    # say L562 mo1
    old "{i}Does it turn you on?{/i}"
    new "{i}それが興奮する？{/i}"

    # say L563 pla
    old "{i}W- what?{/i}"
    new "{i}えっ、何？{/i}"

    # say L570 mo1
    old "{i}If she caught us, she will kill us.{/i}"
    new "{i}もし見つかったら、殺されちゃうわよ。{/i}"

    # say L572 mo1
    old "{i}Oh no, all of this is making me horny.{/i}"
    new "{i}ああ、これ全部が私を興奮させちゃってるのよ。{/i}"

    # say L577 mo1
    old "{i}Oh yeah, I'm gonna make you cum in front of [mo2].{/i}"
    new "{i}あら、そうね、あなたを[mo2]の前でイかせちゃうわよ。{/i}"

    # say L604 mo1
    old "{i}Cum quietly!{/i}"
    new "{i}静かにイクの！{/i}"

    # say L608 mo1
    old "{i}Wow, you still hard... We will need to do something else, right?{/i}"
    new "{i}あら、まだ固いのね…何か別のことをしないと、ダメよね？{/i}"

    # say L609 pla
    old "{i}Oh come on... No, please we should stop now...{/i}"
    new "{i}ああ、お願い……もうやめよう……{/i}"

    # say L612 mo1
    old "{i}You will love this...{/i}"
    new "{i}あなたはこれ好きになるわ…{/i}"

    # say L624 pla
    old "{i}Holy Shit!{/i}"
    new "{i} Holy Shit！ {/i}"

    # say L627 pla
    old "Uhhh... No, no, I- I'm just excited by the movie..."
    new "うーん… いいえ、いいえ、ただ映画が興奮させてるだけだよ…"

    # say L628 mo2
    old "Can't you see a movie quietly?"
    new "映画を静かに見られないの？"

    # say L629 pla
    old "Yes, yes I- I'm sorry."
    new "うん、うん、ごめん。"

    # say L631 mo1
    old "{i}Shhh, just relax and enjoy...{/i}"
    new "{i}静かにして、リラックスして楽しんで…{/i}"

    # say L648 mo1
    old "{i}Do you realize I'm giving you a blowjob almost in front of [mo2]?{/i}"
    new "{i}あなたが気づいてるかどうかわからないけど、私はほとんど [mo2] の前でフェラチオをしているのよ…{/i}"

    # say L649 pla
    old "{i}Yeah, that's crazy.{/i}"
    new "{i}そうだね、それってすごいことだよな。{/i}"

    # say L651 pla
    old "{i}How much did you drink?{/i}"
    new "{i}どれだけ飲んだの？{/i}"

    # say L655 mo1
    old "{i}Are you ready for my oral creampie?{/i}"
    new "{i}あなたは私のオーラルクレampieに準備できていますか？{/i}"

    # say L683 mo1
    old "{i}Wow it was a lot... Did you like it?{/i}"
    new "{i}わぁ、たくさん出てきたね…気に入った？{/i}"

    # say L684 pla
    old "{i}Hell yeah, it was great...{/i}"
    new "{i}もちろん、最高だったよ...{/i}"

    # say L685 mo1
    old "{i}Let's clean this mess quietly.{/i}"
    new "{i}静かにこの片付けをしましょうね。{/i}"

    # say L694 mo1
    old "Wow the movie was great, right [pla]?"
    new "映画、凄かったよね [pla]？"

    # say L696 pla
    old "Oh yes, it was awesome."
    new "おう、最高だったな。"

    # say L698 mo2
    old "I thought it was stupid... Anyway I'm going bed."
    new "私はそれが馬鹿げていたと思ったの… とにかく、寝るから。"

    # say L701 mo1
    old "Yes, good night honey, sleep well."
    new "はい、おやすみなさい Darling、よく眠ってね。"

    # say L703 pla
    old "Good night"
    new "おやすみください"

    # say L718 mo1
    old "Do you like my tits, isn't it?"
    new "私の胸が気に入ったでしょう、そうでしょう？"

    # say L719 mo1
    old "Well, I think you deserve a great titjob."
    new "まあ、あなたが素晴らしい乳コキを受けるのは当然だと思います。"

    # say L725 mo1
    old "How does it feel to have your [mo1rel] tits around your cock?"
    new "あなたの[mo1rel]のおっぱいに包まれて感じる気分は？"

    # say L726 pla
    old "Uhh... It feels amazing!"
    new "うーん…最高だ！"

    # say L727 mo1
    old "Mmmm, I'm enjoying it too."
    new "うん、私も感じてるわ。"

    # say L732 mo1
    old "Would you like to cum on my tits?"
    new "tetasに射精したいですか？"

    # say L733 pla
    old "Oh yeah."
    new "ああ、そういえば。"

    # say L734 mo1
    old "So, cum on your [mo1rel]'s tits."
    new "じゃあ、あなたの[mo1rel]の胸に射精して。"

    # say L759 pla
    old "Ughhh... Ahhh!"
    new "うっ……あっ！"

    # say L760 mo1
    old "Oh yes! Cum all over me!"
    new "ああ、そうよ！全部私に出して！"

    # say L764 mo1
    old "Wow you came a lot..."
    new "すごい出てるね…"

    # say L765 mo1
    old "I'm glad you're still hard, because I need you inside of me now."
    new "まだ硬いのが嬉しいわ、今すぐに中に入りたいの。"

    # say L767 mo1
    old "Come with me to the bed"
    new "ベッドに来なさい"

    # say L786 mo1
    old "Uhhh, yes, just like that."
    new "うっ、そうよ…"

    # say L787 mo1
    old "I'm I can feel your cock inside me, and it feels amazing!"
    new "私の中であなたのチ○ポが感じられて、すごく気持ちいいです！"

    # say L792 mo1
    old "Mmmm, it feels so nice!"
    new "んん、すごく気持ちいいです…"

    # say L793 mo1
    old "Oh yeah, don't stop baby, don't stop!"
    new "あぁ、止めてBaby、止めて！"

    # say L798 mo1
    old "Ahhh, ahhh, yeah fuck me, fuck me!"
    new "アーッ、アーッ、はい、私を犯して、もっと激しく！"

    # say L799 mo1
    old "Yess! Fuck your [mo1rel] harder!"
    new "はい！私の[mo1rel]をもっと激しく犯して！"

    # say L800 mo1
    old "Mmmm... I'm getting close, don't stop."
    new "んん… もうすぐイキそう、止めてないで…"

    # say L828 mo1
    old "God, that was awesome."
    new "神様、それ最高だったわ。"

    # say L835 mo1
    old "Let's rest a little."
    new "少し休もう。"

    # say L845 mo1
    old "That was a fantastic night honey."
    new "それは素晴らしい夜だったわ、Darling。"

    # say L847 pla
    old "Yes, I really enjoyed it."
    new "そうだな、本当に楽しかったよ。"

    # say L849 mo1
    old "Remember we must be careful, no one can know... Ok?"
    new "覚えておきなさい、気をつけてね、誰にも知られちゃダメよ… 分かった？"

    # say L851 pla
    old "Yes, don't worry."
    new "心配するな、大丈夫だ。"

    # say L853 mo1
    old "Go to your room quietly to avoid suspicion."
    new "静かに部屋に戻って、疑われないようにしましょう。"

    # say L855 pla
    old "You're right! I will."
    new "そうだな！行こう。"

    # say L864 mo1
    old "Oh no... I'm sorry, I'm really sorry ..."
    new "あら、ごめんなさい、本当に本当にごめんなさい…"

    # say L866 pla
    old "What? Why?"
    new "何？どうして？"

    # say L868 mo1
    old "For what happened last night, it was definitely very bad, I drank too much and-"
    new "昨晚のこと、本当に悪かったわ、飲みすぎちゃって-"

    # say L870 pla
    old "No, we both decided to do it, I also agreed."
    new "いや、お互いで決めたことだ、俺も同意した。"

    # say L873 mo1
    old "But I am your [mo1rel]."
    new "でも私はあなたの[mo1rel]です。"

    # say L875 pla
    old "(Hmmm... I could need a bit of help here ...)"
    new "うーん……ちょっと手伝ってほしいな。"

    # say L879 mo1
    old "Yes, we are both adults ..."
    new "はい、私たちは大人同士ですね。"

    # say L881 mo1
    old "You know what, what the hell, I'm not going to keep worrying about [mo2]."
    new "知ってるわ、もういいや、[mo2]について心配するのをやめるわ。"

    # say L883 mo1
    old "If you're okay with this, I think I'm fine too, right?"
    new "あなたがよければ、私も大丈夫だと思いますよ。"

    # say L887 mo1
    old "Also yesterday I really enjoyed it and can't believe I haven't done it in so many years!"
    new "昨日も本当に楽しくて、こんなに長い間やってなかったなんて信じられないの。"

    # say L889 pla
    old "I also enjoyed it a lot."
    new "俺もすごく楽しんだよ。"

    # say L891 mo1
    old "Just be careful, I don't want anyone to notice, ok?"
    new "気をつけてね、誰にも気づかれないようにしてほしいな。"

    # say L895 mo1
    old "Great honey, let's go, I have to prepare breakfast."
    new "あたし、朝ごはんの準備しなきゃ。さあ行くわ。"

    # say L902 pla
    old "Well, that was insane... I had sex with [mo1rel]..."
    new "WELL、それは狂気的だったな… 僕は[mo1rel]とセックスしたんだ…"

    # say L904 pla
    old "Cool."
    new "クールだね。"

    # say L993 mo1
    old "Ahhhh... It's so big"
    new "アーッ……そんなに大きいの……"

    # say L994 mo1
    old "Mmmm, it feels amazing!"
    new "んん、すごく気持ちいいです。"

    # say L999 mo1
    old "Uhhh yeah, baby I love your cock."
    new "うーん、そうよ、ベイビー、あなたのチ○ポが大好き。"

    # say L1000 mo1
    old "Oh God, oh God! I'm so wet."
    new "ああ神様、ああ神様！ 私、もうびしょびしょです。"

    # say L1005 mo1
    old "Yeah, yeah, I love having your cock inside me."
    new "うんうん、あなたのチ○ポが中に入ってるの好き。"

    # say L1006 mo1
    old "Ohh yeah, just like this..."
    new "ああ、そう、これでいいわ…"

    # say L1041 mo1
    old "Ahhh... Ahhh! I- I'm cumming!"
    new "アッ… アッ！イ、イクッ！"

    # say L1042 pla
    old "Ughhhh m- me too."
    new "うっぐっ 俺もだ。"

    # say L1047 mo1
    old "Oh yes... It was really good."
    new "ああ、そう…… 本当に良かったわ。"

    # say L1048 mo1
    old "But I want more!"
    new "でももっとほしいの！"

    # say L1067 mo1
    old "Ohhh God!"
    new "あぁっ、神様！"

    # say L1068 mo1
    old "This is amazing!"
    new "これが素晴らしいわ！"

    # say L1073 mo1
    old "Uhh, I'll never get tired of this."
    new "うーん、これには飽きることがないわ。"

    # say L1074 mo1
    old "Mmmm, do you like your [mo1rel] riding you?"
    new "んんん、私の[mo1rel]に乗りられること好き？"

    # say L1075 pla
    old "Ohhh yes."
    new "オッ、そうか。"

    # say L1080 mo1
    old "Yeah! Fuck me [pla], Fuck your [mo1rel]!"
    new "はい！[pla]で犯して、あなたの[mo1rel]を犯して！"

    # say L1081 mo1
    old "Ohhh my God!"
    new "ああっ、神様！"

    # say L1107 mo1
    old "Mmmm, let me try something."
    new "んん、何か試してみるわ。"

    # say L1108 mo1
    old "I'm sure you will enjoy this."
    new "このきっと楽しんでいただけると思いますよ。"

    # say L1116 mo1
    old "Uhhh this feels even better."
    new "うーん、これ、もっと感じがいいわ。"

    # say L1117 mo1
    old "Ohhh myy-"
    new "オーッ、マイイー"

    # say L1122 mo1
    old "Mmmm, I learned this in college."
    new "んん、これは大学で学んだのよ。"

    # say L1123 mo1
    old "Do you like how I'm moving?"
    new "私はこんな動きが好きですか？"

    # say L1129 mo1
    old "Ahhh... Oh my God it feels so fucking goood!"
    new "アーッ… 神様、気持ち良すぎます！"

    # say L1130 mo1
    old "Yeah, yeah, I'm getting close!"
    new "はい、はい、私ももうすぐイキそう！"

    # say L1154 mo1
    old "Yeah yeah! Let's cum together!"
    new "はいはい！一緒にイこうね！"

    # say L1156 mo1
    old "Yes, cum with mommy baby! Cum with me!"
    new "はい、ママと一緒にイッちゃおう！私と一緒にイって！"

    # say L1160 mo1
    old "Holly shit, that was amazing!"
    new "おお、それってすごかったわ！"

    # say L1161 pla
    old "Pheww... Ohh yeah."
    new "ふう……ああ、そうか。"

    # say L1176 mo1
    old "It's getting better and better!"
    new "それはますます良くなっていくわね。"

    # say L1177 mo1
    old "Ohh my God!"
    new "ああ、神様！"

    # say L1182 mo1
    old "It's so big! Oh God I feel it so deep!"
    new "大きいの！神様、奥まで感じちゃう！"

    # say L1183 mo1
    old "Oh yes, fuck me [pla], fuck me!"
    new "ああ、はい、[pla]、もっと激しく犯して！"

    # say L1188 mo1
    old "Oh yeah, faster, faster! Fuck me harder!"
    new "ああ、そう、もっと速く、速く！ 更に強く、私を犯して！"

    # say L1189 mo1
    old "Uhhh, yes, yes, fuck your mommy!"
    new "うーん、はい、はい、お父さん、お母さんを犯して！"

    # say L1214 mo1
    old "Ohhhh m- my God! I'm cumming!"
    new "ああっ、神様っ！ 私、イッちゃう！"

    # say L1215 pla
    old "Ughhh mee too!"
    new "うっぐhhh 僕もだ！"

    # say L1220 mo1
    old "Wow it was a huge load"
    new "すごい量だったわ"

    # say L1221 mo1
    old "Mmmm, you cum all over me."
    new "まmmm、全部私にかかっちゃったわ。"

    # say L1222 mo1
    old "Let's clean this up before someone comes."
    new "それじゃ、誰かが来る前に片付けましょう。"


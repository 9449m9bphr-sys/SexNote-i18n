# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/barAnimations.rpy
translate japanese strings:

    # say L53 pla
    old "Uhmm... I- I don't think that was in the script Barbie."
    new "うーん… そのセリフは脚本になかったような気がするな、Barbie。"

    # say L112 pla
    old "B- barbie! I- I'm about to...!"
    new "バービー！俺、もうすぐ…！"

    # say L123 pla
    old "Yeah... I'm glad."
    new "うん… 嬉しいな。"

    # say L124 pla
    old "But I wasn't expecting that."
    new "でも、そんな展開は予想外だったな。"

    # say L125 pla
    old "Maybe you should be careful when you drink..."
    new "お前、飲むとき気をつけた方がいいな…"

    # say L153 pla
    old "I- I do!"
    new "俺は気をつけてるよ！"

    # say L176 pla
    old "B- barbie I- I can't hold it in anymore!"
    new "バ- バービー、もう我慢できないっす！"

    # say L188 pla
    old "Uhmm, yeah... But we really can't right now."
    new "うん、でも今は無理だな。"

    # say L189 pla
    old "So how about you get up? So I can get my pants up."
    new "じゃあ、起きてくれる？ そうすりゃ俺のパンツも上げられるし。"

    # say L239 pla
    old "B- Barbie! I- I'm about to cum!"
    new "Ｂ－バービー！ イ－イくところだよ！"

    # say L409 joh
    old "[pla]? What are you doing here?"
    new "[pla]？ここにどうしていらっしゃるんですか？"

    # say L410 joh
    old "Are you here to see somebody?"
    new "誰かに会いに来たんですか？"

    # say L411 joh
    old "Is Hinn with you?"
    new "ヒンは一緒ですか？"

    # say L413 pla
    old "D- Dr. Johnson! H- hi!"
    new "ドクター・ジョンソン！ あ、こんにちは！"

    # say L414 pla
    old "N- no, I'm not here with anybody."
    new "いいえ、誰とも来ていません。"

    # say L415 pla
    old "I- uh- Ugh-"
    new "あー、うー、うっ、"

    # say L416 pla
    old "I'm here to deal with some things of my own!"
    new "俺は自分の用事を片付けるために来たんだ！"

    # say L417 joh
    old "Why are you panting?"
    new "なぜ息を荒げているのですか？"

    # say L419 joh
    old "I see you have your business in something here."
    new "なるほど、ここであなたの用事があるんですね。"

    # say L420 joh
    old "I- I'll let you be."
    new "それでは、お任せします。"

    # say L421 joh
    old "Have fun..."
    new "楽しんでください..."

    # say L435 pla
    old "B- Barbie! You have to stop!"
    new "Ｂ－バービー！やめないとダメだよ！"

    # say L436 pla
    old "Someone already saw us!"
    new "誰かに見られちゃった！"

    # say L472 pla
    old "What are you talking about!"
    new "何言ってんだよ！"

    # say L473 pla
    old "I'm sure Dr. Johnson caught us!"
    new "俺、Dr. Johnsonに見られたって確信してる！"

    # say L474 pla
    old "What if she says something to the building administrators?!"
    new "もし彼女が建物の管理者に何か言うようになったらどうする？！"

    # say L594 pla
    old "Barbie I-!"
    new "バービー、俺も！"

    # say L654 pla
    old "B- Barbie - I feel like I'm cumming!"
    new "B- バービー - 出ちゃいそうなんだ！"

    # say L665 pla
    old "I- I'm glad you enjoyed it."
    new "嬉しいよ、楽しんでくれて。"

    # say L666 pla
    old "But hey, what do you say we get up and get dressed?"
    new "でもさ、起きて服を着ようか。"


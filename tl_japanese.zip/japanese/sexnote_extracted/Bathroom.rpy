# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Bathroom.rpy
translate japanese strings:

    # menu L11 
    old "Look at her better"
    new "彼女をよく見てみろ"

    # say L19 pla
    old "I should leave... I don't want to make her think I'm perverted."
    new "俺は行こう… 彼女に変な男と思われたくない。"


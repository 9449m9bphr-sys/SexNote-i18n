# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/JohStory.rpy
translate japanese strings:

    # say L6 joh
    old "Oh, hi [pla], I‘m glad you came. Are you ready to start?"
    new "あ、こんにちは [pla]、来てくれて嬉しいです。準備はできましたか？"

    # say L7 pla
    old "Uhh... Hi, yes, sure."
    new "うーん… はい、準備はできました。"

    # say L8 joh
    old "Ok, as we discussed last time, I'll need your help with some of my patients."
    new "では、前回話した通り、私の患者さんの手伝いをお願いします。"

    # say L9 joh
    old "However, you will need a bit of instruction to gain more experience and do a better job."
    new "しかし、より多くの経験を積んでより良い仕事をするためには、少し指導が必要です。"

    # say L10 pla
    old "Hmm, ‘Instruction'? What do you mean?"
    new "へえ、‘インストラクション’？何のこと？"

    # say L11 joh
    old "Just think about it like a class made just for you, I'll provide you with the proper training and tell you what to do."
    new "ただ考えてみて、君だけのために作られたクラスのようなものだよ。私は適切なトレーニングを提供し、何をすべきか教えてあげる。"

    # say L12 pla
    old "Hmm, ok..."
    new "へえ、なるほど…"

    # say L14 joh
    old "Ok, to start you need to know I assist some patients who have, most of the time, some... Hmm, ‘sexual difficulties'..."
    new "はい、まずは知っておいてほしいことがあります。私がサポートしている患者さんの中には、多くの場合、えっと、『性的な悩み』がある方もいらっさいます。"

    # say L15 joh
    old "Some of them are married women that don't enjoy their sexuality, this brings a lot of problems to their lives."
    new "その中には結婚している女性で、自分の性生活を楽しめていない人もいます。これによって彼女たちの人生に多くの問題が生じています。"

    # say L16 pla
    old "Hmm, I see."
    new "なるほど、そうか。"

    # say L17 joh
    old "In other words, I help them to discover and enjoy their sexuality and have more pleasant moments with their partners."
    new "つまり、彼女たちが自分の性を発見し、楽しむ手助けをして、パートナーとの時間をより快適にするお手伝いをするんです。"

    # say L18 pla
    old "Ok, I got it, but... What do I have to do?"
    new "分かった、でも… 俺に何をすればいいんだ？"

    # say L19 joh
    old "Well, I know you can support me to achieve success in a lot of patients' treatment like you did with Hinn."
    new "WELL、あなたがヒンの治療でサポートしてくれたように、多くの患者さんの治療に成功するために協力していただけると確信しています。"

    # say L20 pla
    old "L- like I did with... H- Hinn?"
    new "あの、あのう…… ヒンみたいに……？"

    # say L21 joh
    old "It's ok, I am pretty conscious about the process we will need to go through so you can do it well."
    new "大丈夫です、私たちが経てねばならない過程について十分に理解しているので、あなたはそれを上手にこなせますよ。"

    # say L23 joh
    old "Don't worry, we will have some lessons to teach you."
    new "心配しないで、いくつかのレッスンをさせてもらうから。"

    # say L24 joh
    old "Also, I'll be with you at all times, you just have to follow the instructions, okay?"
    new "大丈夫、常に一緒にいますから、指示に従ってくださいね。"

    # say L25 pla
    old "Hmm, got it."
    new "わかった、了解。"

    # say L26 joh
    old "I really want you to perform the best way possible and I will ensure you develop the skills you need."
    new "あなたが最高のパフォーマンスを発揮できるようにしたいですし、必要なスキルを身につけることを保証します。"

    # say L27 joh
    old "So, let's not waste any more time and let's go to the practice room!"
    new "それじゃ、時間の無駄をしないように、練習室に行きましょう！"

    # say L34 joh
    old "Well, to start, do you remember that Hinn learned how to please a man? Well, now is your turn!"
    new "それじゃ、まずヒンが男を悦ばせる方法を学んだことを覚えてる？ 今度は君の番だよ！"

    # say L36 joh
    old "What I meant [pla] is, I'll teach you how to fuck like a pro..."
    new "私が言いたいのは [pla] プロ並みのセックスの仕方を教えてあげるということだよ…"

    # say L38 joh
    old "At this point I think you must take it more natural since I've already sucked your cock several times so just relax."
    new "この段階では、もう少し自然に受け入れてほしいな。僕のチ○ポを何度も吸ったことがあるんだから、リラックスして。"

    # say L40 joh
    old "We are going to start with some oral sex, I want you to show me those skills, so I can be sure my patients are going be satisfied."
    new "まずはオーラルセックスから始めましょう、あなたのテクニックを見せてください。そうすれば、私の患者たちが満足するかどうか確認できます。"

    # say L41 pla
    old "W- what? Do you mean you want me to give you... O- oral sex?"
    new "え、つまり俺が君に… 口コキをするってこと？"

    # say L42 joh
    old "Yes, remember, just relax and follow my instructions."
    new "はい、リラックスして私の指示に従ってくださいね。"

    # say L43 joh
    old "We are learning and this is part of your process, so, come here and get on your knees."
    new "私たちは学んでいるところであなたの過程の一部です。だから、ここに来て膝をついてください。"

    # say L52 joh
    old "I can assure you this lesson is going to be useful for you."
    new "このレッスンがあなたにとって役立つことを保証します。"

    # say L53 joh
    old "And it will be necessary for my patients, and of course, should be amusing for both of us, so, let's start."
    new "そして、私の患者のために必要となるでしょうし、もちろん、お互いに楽しむことができるはずです。それでは、始めましょう。"

    # say L56 joh
    old "I want you to kiss me, like if that were my mouth, move your tongue carefully, slowly..."
    new "あなたが私の口をキスしているように、舌を慎重に、ゆっくりと動かしてみてください..."

    # say L69 joh
    old "Just like that, try to keep it wet, and slowly move your tongue a bit faster..."
    new "その通り、湿ったままにしながら舌を少し早く動かしてみてください…"

    # say L71 joh
    old "Keep doing it like that... Ahh."
    new "そのまま続けて……アッ。"

    # narrator L95 
    old "Try Again"
    new "もう一度やってみる"

    # narrator L97 
    old "Next Round"
    new "次の回"

    # say L109 joh
    old "Oh careful!"
    new "気をつけてください！"

    # say L111 joh
    old "Ouch!"
    new "いたっ！"

    # say L113 joh
    old "NO! NO! STOP!"
    new "NO！ NO！ 止めてください！"

    # say L119 pla
    old "Did I do something wrong?"
    new "何か間違ったんですか？"

    # say L120 joh
    old "Hmm, I think you could do it a lot better..."
    new "Hmm、もっと上手にできると思いますが、ソフトに…患者が快感を感じて不快な経験をしないようにすることが目的です。"

    # say L121 joh
    old "Softer, the idea is to make the patient experience a lot of pleasure and not the opposite, but we can work on that."
    new "ソフトに、患者さんが快感を感じて不快な経験をしないことが目的です。でもそれは練習すれば上手くなるでしょう。"

    # say L122 pla
    old "Hmm... Ok."
    new "うーん… わかってる。"

    # say L123 joh
    old "Listen, that is something normal, we can always improve our abilities, don't feel bad about this particular moment where it was not as expected, it's ok."
    new "聞いてください、これは普通のことです、私たちの能力は常に向上できます、この特定の瞬間が期待通りでなかったとしても落ち込む必要はありません、大丈夫ですよ。"

    # say L126 joh
    old "Unfortunately, our time is up. I think you need to learn a couple of things more before continuing."
    new "残念ですが、時間は尽きました。もう少し学んでから続けるのが良いでしょう。"

    # say L129 joh
    old "Perfect, see you later [pla]."
    new "では、またね [pla]。"

    # say L130 pla
    old "See you too, bye!"
    new "じゃあ、またね！バイバイ！"

    # say L144 joh
    old "Congratulations, you definitely have what it takes, so, we can do a perfect team."
    new "おめでとう、君には確かに必要なものが全てあるね、だから私たちは完璧なチームになることができるよ。"

    # say L145 joh
    old "I can see you have other talents and they are pretty valuable."
    new "あなたの持っている他の才能も見ることができましたね、それらは非常に価値がありますよ。"

    # say L147 joh
    old "Yes, I'm very satisfied, you did just fine."
    new "はい、非常に満足しています、よくやったね。"

    # say L148 pla
    old "I am glad you liked it."
    new "嬉しいよ、君が気に入ったってことについて"

    # say L149 joh
    old "It can be better but I am proud of you, I can count on you to make the best for my patients."
    new "もっと良くはなるけど、君のことを誇りに思うよ。君なら私の患者のために最善を尽くしてくれるだろうね。"

    # say L150 joh
    old "The great news is that these lessons are going to be quite fascinating for me."
    new "素晴らしいニュースは、これらのレッスンが私にとって非常に興味深いものになるということですね。"

    # say L159 joh
    old "I think that's all, you need to rest a bit, I am exhausted but I have some patients I have scheduled."
    new "じゃあ、これで全部だと思う。少し休んだ方がいいよ。私は疲れたけど、予約している患者さんがいるんだ。"

    # say L160 pla
    old "Ok, thank you."
    new "はい、ありがとうございます。"

    # say L161 joh
    old "It was a pleasure... I hope you're on time tomorrow."
    new "それは楽しくて… 明日は遅れないでくださいね。"

    # say L163 joh
    old "I'll be waiting for you, there are some lessons we need to have go through."
    new "待っていますよ、いくつかのレッスンを通じて学ぶ必要がありますから。"

    # say L165 joh
    old "Perfect, see you tomorrow."
    new "では、明日お会いしましょう。待っています。"

    # say L181 joh
    old "Hi [pla], glad to see you. There's no time to lose, let's go to the room."
    new "こんにちは [pla]、お会いできて嬉しいです。時間がないので、部屋に行きましょう。"

    # say L182 pla
    old "Uhhh... Ok!"
    new "うーん… 分かった！"

    # say L188 joh
    old "We need to repeat the session we were practising last time, I need you to finish it successfully."
    new "前回練習したセッションを繰り返さなければならない、成功するよう協力してください。"

    # say L190 joh
    old "I have to budget my time because I have a couple of patients coming earlier, so please help me to finish on time."
    new "時間の配分が必要なので、早めに終わらせられるように協力してください。"

    # say L192 joh
    old "Let's start, you already know how to do it, so please do your best."
    new "それじゃ、始めましょう。もうやり方をご存じでしょうから、頑張ってください。"

    # say L193 pla
    old "Uhh, Ok..."
    new "うーん、わかった…"

    # say L207 joh
    old "Keep doing it like that... Ahh..."
    new "そのまま続けて… アhh…"

    # say L262 joh
    old "Welcome [pla], I'm happy to have you here, we have a lot of things to work on."
    new "ようこそ [pla]、あなたがここに来てくださって嬉しいです。たくさんお仕事を進めていきましょう。"

    # say L263 pla
    old "Hi... Uhh, ok, ok, I- I am ready."
    new "こんにちは… うーん、そうだ、そうだ、俺は準備できてるよ。"

    # say L264 joh
    old "Wonderful! Today we have a new goal I want you to work on."
    new "素晴らしいですね！今日は新しい目標に取り組んでほしいんです。"

    # say L265 pla
    old "Ok, what is it?"
    new "はい、何ですか？"

    # say L266 joh
    old "I think it's something kind of new for you but I can walk you through it. It's related to self-mastery."
    new "新しいことかもしれませんが、一緒に進めていきましょう。自己 Mastery に関するものです。"

    # say L268 pla
    old "'Self-mastery'?"
    new "「自己掌握」？"

    # say L269 joh
    old "Yeah, let me explain it to you, most of the time our desires or emotions can be really difficult to control..."
    new "はい、説明しましょう。ほとんどの場合、私たちの欲望や感情は本当にコントロールするのが難しいんです..."

    # say L270 joh
    old "Once you can defeat them, you will be strong enough to act without their control."
    new "一度それらを制覇できれば、あなたはそのコントロールから自由に行動するだけの強さを持ちます。"

    # say L271 joh
    old "The most visible aspect of this exercise will be that you can last longer during any kind of sexual interaction."
    new "この練習の最も目に見える効果は、どのような性的な行為でも長く持つことができるようになることです。"

    # say L272 pla
    old "Hmm interesting..."
    new "へえ、興味深いな…"

    # say L273 joh
    old "Talking about our sexual performance, we need to be sure we can control our body to react the exact way we want..."
    new "性的なパフォーマンスについて話すと、自分の体を正確にコントロールできるようにすることが大切です。"

    # say L274 joh
    old "That way we can guarantee your sexual partner reaches the orgasm before you do."
    new "その方法で、あなたのセックスパートナーがあなたより先にオルガスムに達することを保証できます。"

    # say L277 joh
    old "That's cool, so today we are going to see if your performance can be mastered without cumming."
    new "それじゃ、今日は射精せずにパフォーマンスをコントロールできるかどうか確認しましょう。"

    # say L278 joh
    old "Or we will need to work on it harder so you can perform better with the patients."
    new "それでは、より効果的に患者さんと関われるよう、もっと練習が必要かもしれませんね。"

    # say L279 pla
    old "Ok, and how are we going to verify that?"
    new "はい、じゃあどうやって確認するんですか？"

    # say L280 joh
    old "That's an interesting part, I want you to relax and just be yourself, I will do the rest of the job, let's go to the room."
    new "それは面白い部分ですね、リラックスしてそのままのあなたでいてください、後は私がやりますから、部屋に行きましょう。"

    # say L281 pla
    old "Uhh... Ok."
    new "うーん… 分かった。"

    # say L287 joh
    old "Please take off your pants, so we can start..."
    new "ズボンを脱いでください、そうすれば始めましょうから..."

    # say L289 joh
    old "I want to test how long you can last, so, get ready because I will use my mouth, I will give you the best blowjob of your entire life."
    new "テストの時間だよ、どれだけ耐えられるか見せてほしいの。だから準備して、僕の口で君の人生で最高のフェラチオを味わってもらうよ。"

    # say L291 joh
    old "So, come on, take off your pants, I'm going to make myself comfortable too."
    new "それじゃ、さっさとズボンを脱いで、私もくつろぐからね。"

    # say L316 pla
    old "WOW!"
    new "ワオ！"

    # say L317 joh
    old "I am glad you like them because I want you to look at them carefully."
    new "あなたが気に入ってくれて嬉しいです、よく見てください。"

    # say L318 joh
    old "I need you to be very stimulated to test your endurance."
    new "あなたが非常に興奮した状態で、耐久力をテストする必要があります。"

    # say L320 joh
    old "The idea is that, even though all sensorial stimulation you feel, you can control your body and don't cum."
    new "アイデアは、感じるすべての感覚的な刺激に対して、体をコントロールして射精しないこと。"

    # say L321 pla
    old "Are you serious?"
    new "本気だよ？"

    # say L322 joh
    old "Absolutely, under any circumstance you must not cum, until I say you can, ok?"
    new "絶対に、私が許すまで射精してはいけませんよ、わかりましたか？"

    # say L323 pla
    old "Hmm ok..."
    new "うーん、分かった…"

    # say L368 joh
    old "Ok now it comes the hard part, I will suck your entire dick, are you ready?"
    new "では次が難しい部分ですが、あなたの Entire Dick を全部舐めますよ、準備はできましたか？"

    # say L374 pla
    old "(Oh God, it feels so good...)"
    new "ああ、神様、感じてます..."

    # say L379 pla
    old "Dr. Johnson I- I- ... Ughhhh..."
    new "ドクター・ジョンソン、あ、あ、……うぐっ……"

    # say L386 joh
    old "OH NO! You came before!"
    new "ああ、先生、早くもイッちゃいましたね…"

    # say L392 pla
    old "I- I am... Sorry..."
    new "すみません、俺は..."

    # say L393 joh
    old "It's ok, it's something we knew could happen so calm down, what a mess you did..."
    new "大丈夫です、予想されたことなので落ち着いてください、随分と乱れてしまいましたね…"

    # say L394 pla
    old "I'm sorry, it was my fault."
    new "すみません、俺のせいです。"

    # say L395 joh
    old "It's ok, it wasn't that bad, the thing is that we now need to have this in mind to make sure you can control yourself."
    new "大丈夫です、そんなに悪くなかったですね。ただ、今後はこれを念頭に置いて、自分をうまくコントロールできるようにしなければなりません。"

    # say L396 joh
    old "We can't have this mess with a patient..."
    new "患者さんとの間にこんな混乱は避けなければなりませんね。"

    # say L398 pla
    old "How can I do it better?"
    new "上手くやるにはどうすればいいですか？"

    # say L400 joh
    old "I will help you, don't worry."
    new "心配しないで、お手伝いしますから。"

    # say L402 joh
    old "But, I am running out of time, the patients are about to arrive and I need to clean this mess..."
    new "でも、時間が迫っています、患者さんが来る前にこの片付けをしなければなりません…"

    # say L403 joh
    old "I hope you be on time tomorrow, We need to correct this behavior."
    new "明日は時間に来られるようにお願いします、この行動を改善する必要がありますから。"

    # say L404 pla
    old "I am very sorry to disappoint you."
    new "申し訳ありません、失望させてしまったようです。"

    # say L405 joh
    old "There is nothing we can't improve, I'm sure next time it will be different."
    new "改善できないことは何もないと思います、次はきっと違いますね。"

    # say L406 joh
    old "I think that's all, you need to rest a bit, I have some patients scheduled, so, see you later."
    new "それでは、少し休んでください。予約のある患者さんがいるので、また後でね。"

    # say L409 joh
    old "We will need to repeat this exercise, I'll be waiting for you."
    new "この練習をまた繰り返す必要がありますね、待っていますよ。"

    # say L410 pla
    old "Ok, see you later..."
    new "分かった、また後でね。"

    # say L425 joh
    old "Oh great! That was good, you have surprised me! What a huge load, it's delicious."
    new "おお、素晴らしい！ びっくりしたよ！ こんなに大量の精液、美味しそうだね。"

    # say L427 joh
    old "Congratulations, I can see that you havea lot more control of body."
    new "おめでとうございます、体のコントロールがずいぶん上手になったようですね。"

    # say L432 joh
    old "All right, I'm gonna clean this mess. My next patient is about to arrive... I hope you be on time tomorrow."
    new "では、この後片付けをしますね。次の患者さんが来るので……明日はちゃんと時間通りに来てください。"

    # say L435 joh
    old "Ok, there are some lessons we need to have to go through."
    new "では、いくつかのレッスンを進めていきましょう。"

    # say L436 pla
    old "Got it, see you tomorrow then."
    new "分かった、じゃあ明日な。"

    # say L452 pla
    old "Fine! Thanks for asking, hope you are doing good too."
    new "Fine！ ありがとう、元気でいてね。"

    # say L453 joh
    old "Oh absolutely! But I can tell you it will be better just in a moment, Are you ready?"
    new "もちろん！でもすぐにさらに良くなることをお伝えします、準備はできていますか？"

    # say L454 pla
    old "Ready? For what?"
    new "準備はいいのか？ 何のために？"

    # say L456 joh
    old "Well, today we will continue your process to make you able to control yourself, the main focus for today will be performance."
    new "では、今日はあなたが自分をコントロールできるようにするための過程を続けましょう。今日の主な焦点はあなたのパフォーマンスです。"

    # say L457 pla
    old "Performance?"
    new "パフォーマンス？"

    # say L458 joh
    old "Yes, we need to test your capabilities to accomplish the tasks that you will have..."
    new "はい、あなたが達成しなければならないタスクをこなす能力をテストする必要があります。"

    # say L459 joh
    old "So, you need to work not only on the time you can last, but the quality of that time."
    new "なので、時間だけでなくその質も向上させる必要がありますね。"

    # say L460 pla
    old "Oh... I understand."
    new "了解しました。"

    # say L462 joh
    old "Today we have a very nice exercise, so I hope you put all your effort to make a successful session."
    new "今日はとても良いエクササイズを用意しましたので、成功させるために全力を尽くしてください。"

    # say L463 joh
    old "Remember, focus on the rhythm and performance."
    new "リズムとパフォーマンスに集中することを忘れないでください。"

    # say L464 pla
    old "Uhh, ok."
    new "うーん、わかった。"

    # say L465 joh
    old "So, let's go, we will have sex now."
    new "それじゃ、始めましょう。今からセックスをします。"

    # say L466 pla
    old "I will hav-... W- wait, what? Sex?"
    new "待って、何言ってるの？セックス？"

    # say L467 joh
    old "Of course, that is how we can practice, besides, I need to test the quality of my assistant."
    new "もちろん、それが練習方法です。それに、私の助手の質を確かめる必要があります。"

    # say L469 joh
    old "Great, let's get started, first we need to go to the practice room."
    new "では、始めましょう。まずは練習室に行きましょう。"

    # say L476 joh
    old "From this particular exercise and on, we will need to guarantee your partner reaches the orgasm, that is the key."
    new "このエクササイズから先は、パートナーが絶頂に達することを保証することが重要です。"

    # say L477 pla
    old "Ok, I will focus on that."
    new "わかった、そのことに集中するよ。"

    # say L478 joh
    old "But, anyways remember to enjoy what you are doing, let's get prepared. Take off your clothes."
    new "でも、とにかく楽しんでください。準備をしましょう。服を脱いで。"

    # say L482 joh
    old "Perfect, now that you are ready let's fuck!"
    new "パーフェクト、準備はできてるね。それじゃあ、さっそく始めよう。"

    # say L538 pla
    old "Ohhh... Ohhh... I- I-"
    new "オッホ… オッホ… イ、イきそう…"

    # say L552 joh
    old "Huh, you finished quite earlier..."
    new "へえ、ずいぶんと早く終わったんだね…"

    # say L553 joh
    old "I know you are doing a great effort, but I need you to take control of yourself and wait for the right moment."
    new "あなたが頑張っているのは分かりますが、自分を抑えつつ適切なタイミングを待つようにしましょう。"

    # say L554 pla
    old "I- I'm trying to focus-"
    new "俺、集中しようとしてるんだけど…"

    # say L556 joh
    old "I know, we only need to work harder. "
    new "分かっています、もっと頑張らなければなりません。"

    # say L557 joh
    old "I think you need to do some workout, so, you can keep your body up until I reach the orgasm."
    new "あなたが少し運動した方がいいと思います、そうすれば私がイクまで体を保てますから。"

    # say L559 pla
    old "I will improve, I think I was tired because of the rhythm."
    new "俺は改善するよ、リズムのせいであんまり疲れちゃったみたいだ。"

    # say L560 joh
    old "Sure you will improve, that's why we are doing this together, so you can develop all the skills you have."
    new "もちろん、あなたは上達するでしょう。それが私たちが一緒にやっている理由で、あなたの持っているすべてのスキルを磨くことができるからです。"

    # say L562 joh
    old "Don't mention it, let's clean this mess, I have to continue working..."
    new "気にしないで、この乱れを片付けよう。私は仕事に戻らなければならない…"

    # say L577 joh
    old "I'm very impressed, you are quite awesome at this, let me tell you the exercise was a complete success."
    new "非常に感心しました、あなたはこれに関してかなり素晴らしいですね、この演習は完全な成功でしたよ。"

    # say L578 pla
    old "T- thanks... I did all that I could."
    new "ありがとうございます… 僕ができたことは全部やりました。"

    # say L579 joh
    old "Hahaha good job kid, you are doing the exercises very consciously."
    new "ははは、よくやったね、君は練習をとても意識的に行っているね。"

    # say L581 joh
    old "Keep working, the benefits will be incredible and remember the benefits won't be only yours..."
    new "頑張ってください、効果は素晴らしいものになるでしょうし、その恩恵はあなただけにとどまらないことを覚えておいてください..."

    # say L582 joh
    old "It was a very productive session, so, I hope next time we keep the level as high as today."
    new "今日はとても生産的なセッションでしたね、次回も今日と同じレベルを保てるよう頑張りましょう。"

    # say L583 pla
    old "Sure, I will keep working hard."
    new "はい、頑張ります。"

    # say L585 joh
    old "Yes... really Hard."
    new "はい…本当にハードです。"

    # say L601 joh
    old "Oh, you are here! Quite on time."
    new "お、あなたがここにいるのね！ちょうどいい時間だ。"

    # say L602 pla
    old "Yes, I came a bit earlier."
    new "はい、少し早めに来ました。"

    # say L603 joh
    old "That's perfect, we have a lot to work on."
    new "それがぴったりですね、今日たくさん仕事がありますから。"

    # say L604 pla
    old "Ok, I am ready."
    new "はい、準備できました。"

    # say L605 joh
    old "Great, today we will work on your strength, the power given on every sexual encounter."
    new "素晴らしい、今日はあなたの体力を鍛えましょう、セックスのたびに必要な力です。"

    # say L606 pla
    old "Hmm... Strength? What do you mean?"
    new "へえ… 体力って？どういう意味ですか？"

    # say L607 joh
    old "Sex requires a lot of power if you really want to satisfy, I need you to start doing the process beyond the limits."
    new "Seksは多くの力を必要としますよ、本当に満足させたいならね。限界を超えてプロセスを始める必要があります。"

    # say L609 pla
    old "Wow, And how can I achieve that?"
    new "へえ、それをどうやって達成すればいいんだ？"

    # say L610 joh
    old "Well, I need you to focus because you are going to use your dick quite differently."
    new "WELL、まずは集中してほしいんだ。君のチ○ポを今までとは違う方法で使うことになるから。"

    # say L611 joh
    old "You must control your body so you can give a hardcore sex experience."
    new "体をコントロールして、ハードコアなセックス体験ができるようにしなくちゃ。"

    # say L612 pla
    old "Hmm, ok."
    new "うーん、分かった。"

    # say L613 joh
    old "Let's go ahead to the practice room, I can't wait to get fucke- ... I mean to start the new exercise..."
    new "それじゃ、練習室に行きましょう、早く新しいエクササイズを始めるのが待ち遠しいんですが..."

    # say L620 joh
    old "Ok, previous lesson was focused on endurance and lasting as much as I wanted."
    new "前回のレッスンは、自分の望むだけ持続する持久力に重点をおきましたが。"

    # say L621 joh
    old "This time I need you to keep this in mind, I want you to be hardcore hitting my pussy really hard."
    new "今回はこれを頭に入れておいてください、私のマ○コを激しく突いてほしいんです。"

    # say L623 joh
    old "Let's do it, please take off your clothes and get ready."
    new "それじゃ、服を脱いで準備してください。"

    # say L682 pla
    old "Oh God! This is too much!"
    new "おおっ！これはやりすぎだよ！"

    # say L695 pla
    old "Did I cum quick, right?"
    new "早く射精したな、そうだったろ？"

    # say L696 joh
    old "Not just that... I'm afraid you are not strong enough, you need to hit harder, some girls will like to be pounded really hard."
    new "それだけじゃない… 恐らくあなたはまだ十分に強くない。もっと激しくしないと、一部の女性は本当にハードなプレイを好むんだ。"

    # say L698 joh
    old "[pla], we need to satisfy certain preferences..."
    new "[pla]、特定の好みを満たす必要がありますね。"

    # say L699 joh
    old "This is not a regular sexual encounter you will find really demanding girls that want something harder, and you need to provide that."
    new "これは単なる性行為ではありません、かなり要求の厳しい女性もいるので、あなたはそれに応じてより強引に対応する必要があります。"

    # say L700 pla
    old "You are right, I'm sorry.."
    new "すみません、それは正しいですね。"

    # say L701 joh
    old "Don't worry I know you can learn... But today I need to get ready for my next patient, so next time we will practice this lesson again."
    new "心配しないで、君には学べると信じてる… でも今日は次の患者さんのための準備があるので、次回またこのレッスンを練習しよう。"

    # say L703 joh
    old "See you later kido."
    new "じゃあまたね、キド。"

    # say L704 pla
    old "See you doctor."
    new "じゃあ、また後で先生。"

    # say L718 joh
    old "You are doing great! Congratulations for this improvement, you definitely approved, my patients will love you."
    new "あなたは素晴らしいですね！この改善を称えたいと思います、間違いなく合格しました。私の患者さんたちはきっとあなたを気に入ります。"

    # say L719 pla
    old "Thank you, I appreciate it."
    new "ありがとうございます、評価していただけて嬉しいです。"

    # say L720 joh
    old "The process has been successful, I want you to keep working..."
    new "プロセスは成功しました、これからも続けていきましょう..."

    # say L723 joh
    old "I guess in the mornings we can continue with these lessons, because I want to... Hmm, help you practice more..."
    new "朝のこれらのレッスンを続けましょう、あなたがもっと…うーん…練習するのを手伝いたいからです…"

    # say L724 pla
    old "Oh, ok that sounds good to me..."
    new "うん、それは俺にとっても良いね。"

    # say L725 joh
    old "Perfect, I'm looking forward to seeing your progress, there are many things we can improve."
    new "完璧です、あなたの進歩を見るのが楽しみです、改善できることがたくさんあります。"

    # say L726 pla
    old "I appreciate your help."
    new "あなたの手伝いに感謝します。"

    # say L727 joh
    old "In our next session we will have a patient to put what we have learned into practice."
    new "次回のセッションでは、患者さんを対象に学んだことを実践します。"

    # say L729 joh
    old "Don't worry, I will walk you through so we can do an outstanding job."
    new "心配しないでください、私が丁寧に指導しますので、素晴らしい仕事をすることができます。"

    # say L733 joh
    old "All right, I need you to leave so I can get ready for my next patient, thanks for your great job, it was remarkable."
    new "それじゃ、次の方の準備をするためにはじめに出て行ってください、お疲れさまでした、素晴らしい仕事をしてくれてありがとう。"

    # say L737 pla
    old "Bye!"
    new "じゃあ、また！"

    # say L747 joh
    old "(I can't believe myself, that dick is driving me so crazy...)"
    new "自分を信じられない、あのチ○ポがこんなに僕を狂わせてしまうなんて..."

    # say L761 joh
    old "Oh, [pla], I'm glad you came early, there's something I needed to talk to you about before we start."
    new "Oh、[pla]、早めに来てくれてありがとう。始める前に話しておきたいことがあるんです。"

    # say L763 joh
    old "Well, today we're going to work with Angelina, she is a patient who doesn't enjoy having sex."
    new "今日はAngelinaさんと作業をしますが、彼女はセックスを楽しむことができない患者です。"

    # say L764 joh
    old "I have tried with several exercises, but she is kind of stuck in the process..."
    new "いくつかのエクササイズを試しましたが、彼女はなかなか進展しないようです..."

    # say L765 joh
    old "Also, her marriage is in danger, because she doesn't want to have sex with her husband."
    new "また、彼女の結婚が危機に瀕しています。なぜなら彼女は夫とのセックスを望んでいないからです。"

    # say L767 pla
    old "Oh, that's really bad."
    new "ああ、それは本当に悪いね。"

    # say L768 joh
    old "Yes, so we need to have noticeable progress as soon as possible, and we are going to achieve that with your help."
    new "はい、できるだけ早く目に見える進歩が必要で、そのためにあなたの協力が必要になります。"

    # say L769 pla
    old "With m- my... Help?"
    new "僕の… 助けで？"

    # say L770 joh
    old "Well, with the training you've been through we can help..."
    new "WELL、あなたが受けたトレーニングを活かして、私たちは彼女を助けることができます。"

    # say L771 joh
    old "We will need to apply all the concepts that we have worked on so that she can discover how pleasurable sex is."
    new "私たちはこれまで学んできたすべての概念を適用して、彼女がセックスの快楽を発見できるようにしなければなりません。"

    # say L774 joh
    old "Then everything she learns here, she can put into practice with her husband, and our treatment will be successful."
    new "ここで学んだことを夫と実践することで、私たちの治療は成功するでしょう。"

    # say L775 pla
    old "Ohhh, that makes sense..."
    new "オーッ、なるほど..."

    # say L776 joh
    old "Ok, so, please stay in the practice room and I will let you know when to come in to get involved with the session."
    new "では、練習室でお待ちください。私が呼ぶ時間をお知らせします。"

    # say L778 joh
    old "I will need you to be ready, I mean to have your cock prepared when I call you."
    new "準備ができていることを確認してください、つまり私が呼んだときにあなたのペニスが準備されていることです。"

    # say L781 joh
    old "Remember to stay focused on her pleasure, you'll have to practice everything we've learned, once Angelina is ready I'll let you know."
    new "アンジェリーナが準備でき次第、あなたに知らせますので、彼女の快楽に集中することを忘れないでください。これまで学んだことをすべて練習してください。"

    # say L783 joh
    old "Ok, now go to the practice room, she could arrive at any time."
    new "では、練習室に行ってくれ。いつでも彼女が来るかもしれないからね。"

    # say L796 joh
    old "Welcome Angelina, it's pretty nice to have you here again."
    new "アンジェリナさん、また来てくださってありがとうございます。"

    # say L797 ang
    old "Thank you doctor Johnson is good to see you again."
    new "ありがとうございます、ドクター・ジョンソン。またお会いできて嬉しいです。"

    # say L798 joh
    old "I'm very happy to hear that, how is it going?"
    new "それはとても嬉しいですね、調子はどうですか？"

    # say L799 ang
    old "Everything is fine I guess, except for what you already know."
    new "すべては順調だと思います、ただあなたが既に知っていること以外は特に問題ありません。"

    # say L800 joh
    old "Tell me about that please, did you see any improvement since the last session?"
    new "それについて詳しく聞かせてください、前回のセッション以降に何か改善はありましたか？"

    # say L801 ang
    old "Hmm... Well, I'm doing the things that you told me to, but I'm not really comfortable when I'm doing it..."
    new "うーん……先生が教えてくれたことはやってるんだけど、正直、やっているときに落ち着かないの……"

    # say L802 ang
    old "I have tried all the ways but it feels really disgusting."
    new "試してはいるんですが、本当に気持ち悪いんです。"

    # say L803 joh
    old "No worries darling, I understand and it's totally ok, it's part of the expectations we had set previously, so it's ok to feel that way..."
    new "心配しないで Darling、君の気持ちを理解してるよ。これは私たちが以前に設定した期待の一部だから、そう感じるのは全然仕方ないんだ。"

    # say L805 ang
    old "You are the only person I feel free to share this with."
    new "あなたが唯一私があんなこと話せる相手だから。"

    # say L806 joh
    old "And I'm here for you, and I'll see to it that we get through this problem once and for all."
    new "そして君のためにここにいるよ、この問題を完全に解決するまで見守るからね。"

    # say L807 ang
    old "I really appreciate that, because I have nothing else to do and..."
    new "それが本当に嬉しいの。だって他にすることないし…"

    # say L810 joh
    old "And? Is it everything ok Angelina?"
    new "そして？アンジェリナ、すべて大丈夫なのか？"

    # say L811 ang
    old "I think it is not."
    new "私はそうとは思わないんです。"

    # say L812 joh
    old "Is there something else you think I need to know?"
    new "他に私が知るべきことが何かあるの？"

    # say L813 ang
    old "Well, lately we have been fighting a lot because of that."
    new "最近、そのことでよくケンカしてるの。"

    # say L815 joh
    old "Oh, darling, I understand how hard it must be, it's not your fault of course."
    new "Darling、それがどれほど大変なことか理解しているよ、もちろん君のせいじゃないよ。"

    # say L816 ang
    old "I'd love to think it's not my fault, but I know it is, it's me not working the way it should."
    new "そう思いたいけど、自分が原因だって分かってるの。ちゃんと働いてないのが。"

    # say L817 joh
    old "Honey, I know how you feel, but I've seen the progress from a different perspective and I can assure you that you've been doing your best."
    new "ハニー、君の気持ちわかるけど、私は別の視点から進展を見ていて、君が最善を尽くしていることを確信しているよ。"

    # say L819 ang
    old "I'm not sure about that..."
    new "そうかしら..."

    # say L820 joh
    old "Angelina remember we talked about it at the beginning."
    new "アンジェリナ、最初に話し合ったことを覚えてるよね。"

    # say L821 joh
    old "Some treatments may take longer than expected and the results won't be seen in the short term, you have to be patient."
    new "いくつかの治療は予想以上に時間がかかることがありますし、短期間では結果が見えないこともあります、我慢が必要です。"

    # say L822 ang
    old "I know, I know, you are right-"
    new "うん、うん、分かってる、先生が言う通りだね。"

    # say L823 joh
    old "This is one of the stages we can be on, the treatment is working..."
    new "これは治療の過程の一つで、効果が出始めているんだ..."

    # say L824 joh
    old "We need to keep calm and keep working. I know today's session will show some improvements."
    new "落ち着いて、続けていこう。今日のセッションでは改善が見られると思うよ。"

    # say L826 joh
    old "I am sure of it."
    new "それは確かなことです。"

    # say L827 ang
    old "Oh, great please, I need to get this resolved as soon as possible."
    new "あたし、これはできるだけ早く解決したいんです。"

    # say L828 joh
    old "Ok, so let's get started. We don't have time to lose."
    new "では、始めましょう。時間がないですからね。"

    # say L829 ang
    old "Perfect! Thank you."
    new "パーフェクト！ありがとうございます。"

    # say L830 joh
    old "Okay, let's start with the previous exercise, remember? The one with the dildo?"
    new "では、前回のエクササイズから始めましょう、覚えてるでしょう？ディルドを使ったやつですけど。"

    # say L831 ang
    old "Hmm, I'm not sure, I mean, it's quite different when I do it with a dildo than it is with a real one, you know?"
    new "うーん、ディルドを使うのと本物を使うのとは全然違うんです、分かるよね？"

    # say L832 joh
    old "Of course, and that is why today we are going to do the exercise bandaged."
    new "もちろん、それが今日のバンドエイジッドを使った練習の理由だよ。"

    # say L833 joh
    old "I want you to focus on the sensations, your caresses, and your mouth."
    new "君は感覚に集中して、自分の愛撫と口に意識を向けてほしいんだ。"

    # say L834 ang
    old "Hmm ok, that sounds interesting..."
    new "うーん、そうですね。それなら興味ありますね。"

    # say L835 joh
    old "It is, and today I bring you a new toy, this one is particularly realistic, and this would help us take big steps in treatment..."
    new "今日は君のために新しい玩具を持ってきました。これは特に現実的で、私たちの治療に大きな進展をもたらすでしょう..."

    # say L836 ang
    old "Huh! That sounds really nice."
    new "へえ！それはすごくいいですね。"

    # say L837 joh
    old "Ok, let's get comfortable, and start with the session."
    new "では、リラックスして、セッションを始めましょう。"

    # say L849 joh
    old "I want you to play with it, rediscover its shape, I want you to immerse yourself in it, discover the textures, the flavors, the sensations."
    new "それを触って、形を再発見してほしいんだ。その中に浸かって、質感や味、感じ方を探ってみて。"

    # say L851 joh
    old "Remember that the main objective is to replicate this moment with your husband, try to enjoy it, and focus on pleasure."
    new "主な目的はご主人様との時間を再現することです、楽しんでくださいそして快感に集中してください。"

    # say L852 joh
    old "Keep in mind, his pleasure will also be your satisfaction."
    new "彼の喜びもあなたの満足につながることを忘れないでください。"

    # say L854 joh
    old "Is it good?"
    new "気持ちいいですか？"

    # say L855 ang
    old "Yes."
    new "はい。"

    # say L856 joh
    old "Use your whole mouth, your lips, moistened enough that you can move them freely and seductively."
    new "君の口全体を使って、唇を十分に濡らして、自由にそして誘惑的に動かして。"

    # say L857 ang
    old "I- I think I like it... a bit."
    new "あ、あたし、ちょっと気に入ったかも…。"

    # say L858 joh
    old "That is perfect, now let's move on."
    new "それは完璧です、次に進みましょう。"

    # say L864 joh
    old "{i}Pss! Pss! Come here, it is your turn.{/i}"
    new "{i}プス！プス！こちらへ来てください、次はあなたの番です{/i}"

    # say L865 pla
    old "(Oh God...){i} I- I'm coming.{/i}"
    new "（神様…）{i} 行くよ…{/i}"

    # say L869 joh
    old "Ok, please hold on, here is the new toy. We are going to do the same process we were doing with the previous one."
    new "では、お待ちください。新しいおもちゃを用意しました。前回と同じように進めさせていただきます。"

    # say L875 joh
    old "Enjoy this new toy I have for you, the exercise will be better, and you will find it almost real, so please let me know what you think."
    new "この新しいおもちゃを楽しんでください、エクササイズがより良くなるだけでなく、ほとんど本物のような感覚が得られるはずです。感想をお聞かせください。"

    # say L877 ang
    old "Oh yes, this texture is really different... Something tasty, warm and the texture is flexible."
    new "この質感は本当に違う…何か美味しい、温かいそれに、触り心地が柔らかいです。"

    # say L878 joh
    old "I'm glad you like it, please do it like we have learned."
    new "君が気に入ってくれて嬉しいな、学んだ通りにやってみてください。"

    # say L888 joh
    old "Yeah, please enjoy it, let's do the exercise, imagine it's natural, think he needs to feel really pleased..."
    new "はい、楽しんでください、練習を進めて、自然な感じで考えて、彼が本当に満足するようにしましょうね。"

    # say L889 joh
    old "Remember to change the rhythm and to use the fluids to make it easier."
    new "リズムを変えて、分泌液を使って滑らかに動かすようにしてね。"

    # say L891 joh
    old "Do you think the bandage on your eyes is helping?"
    new "目を覆っているバンデージが役立っていると思いますか？"

    # say L892 ang
    old "Absolutely, I'm just thinking on what you are saying and focus on the exercise and the sensations."
    new "はい、あなたが言っていることを考えながら、エクササイズと感覚に集中していますね。"

    # say L893 joh
    old "Perfect, I knew it was going to work..."
    new "パーフェクト、そうなると思ってた。"

    # say L894 ang
    old "This one is pretty nice, it tastes really good."
    new "これいいですね、味も本当にいいです。"

    # say L895 joh
    old "That's great, I want you to enjoy it, try a little harder, and think of it as a real one."
    new "それは素晴らしい、楽しんでほしいんだ。もう少し力を入れて、本物だと思ってみて。"

    # say L908 joh
    old "Angelina, relax. This is part of the treatment."
    new "エンジェリナ、リラックスして。これは治療の一環だよ。"

    # say L910 ang
    old "What?! B- But- Who is he? D- Did I sucked his- ? Why didn't you tell me?"
    new "何ですか！？ でも、彼は誰ですか？ 私が彼の…を吸ったんですか？ なぜ教えてくれなかったんですか？"

    # say L911 joh
    old "He is one of my assistants and is specifically trained for this."
    new "彼は私の助手の一人で、これ専門に訓練を受けています。"

    # say L912 joh
    old "This was necessary, we were stuck for weeks, you needed a shock therapy to progress."
    new "これは必要だったんだ、数週間も進展がなかったから、君にはショック療法が必要だったんだよ。"

    # say L913 ang
    old "What? B- but... I- I cheated on my husband because of you!"
    new "何？でも… 私、夫に不倫しちゃったじゃない！"

    # say L914 joh
    old "Again, calm down Angelina..."
    new "落ち着いてくれ、Angelina..."

    # say L915 joh
    old "This wasn't cheating, everything was done professionally, in a controlled environment and under my supervision."
    new "これは不倫じゃない、すべてはプロフェッショナルに、制御された環境で、私の監督のもとに行われたんだ。"

    # say L917 ang
    old "B- but I sucked another guy's cock and I don't even know him! I can't understand, I didn't want to do this to my husband..."
    new "でも、他の男の人のおちんちんを吸っちゃったのよ、しかも全然知らない人だよ！これ、理解できないわ、こんなこと旦那様にはしたくないのに…"

    # say L918 joh
    old "Listen Angelina, this is part of the treatment, we have been going through a long process."
    new "アンジェリナ、これは治療の一環なんだ、長い過程を経ているんだよ。"

    # say L919 joh
    old "And this was a great step, and it's the right one to solve your problem."
    new "そしてこれは大きな一歩で、君の問題を解決する正しい方法なんだ。"

    # say L920 ang
    old "I- I just-"
    new "あ、あの、ただ、"

    # say L921 joh
    old "Do you realize the results of this session?"
    new "君はこのセッションの結果を理解してるかい？"

    # say L922 joh
    old "You did great, you were very confident, you enjoyed the session, everything went just as planned."
    new "君は素晴らしい仕事をしたね、とても自信に満ちていて、セッションも楽しんでいたし、すべてが計画通りに進んだよ。"

    # say L923 ang
    old "B- but... I- I- ... and He... Who is-"
    new "でも… 私… そして彼… 誰が…"

    # say L924 joh
    old "Don't worry, [pla] is a very well-trained member of my team."
    new "心配しないで、[pla]は私のチームの中でも非常に訓練を受けたメンバーだ。"

    # say L925 joh
    old "He has been prepared by me and has followed the treatments of another patient, he is very professional and trustworthy."
    new "彼は私が準備し、他の患者の治療にも従ってきました。とてもプロフェッショナルで信頼できる人物ですよ。"

    # say L928 ang
    old "I'm sorry, but I can't accept this, I feel like I'm betraying my husband..."
    new "すみません、でもこれを受け入れられないです、夫に裏切っているような気分になります…"

    # say L929 ang
    old "I think there was a misunderstanding about this... I need to go."
    new "誤解があったと思います…… 私、行かなければなりません。"

    # say L937 pla
    old "Wow, she has left!"
    new "Wow、彼女はいなくなっちゃったな。"

    # say L938 joh
    old "It's okay, she has a lot of emotions to think about."
    new "大丈夫です、彼女には考えなければならない感情がたくさんありますから。"

    # say L939 joh
    old "So she's going to need some time to process what happened and understand what was necessary within his process."
    new "なので、彼女は起こったことを処理し、彼のプロセスの中で必要だったことを理解するのに時間がかかるでしょう。"

    # say L941 joh
    old "Absolutely! That's what is called 'shock therapy'."
    new "絶対ですね！それが『ショック療法』と呼ばれるものです。"

    # say L942 pla
    old "But, looks like she feels pretty bad."
    new "でも、彼女はかなり落ち込んでるみたいだな。"

    # say L944 joh
    old "Well, it is something that needs to happen."
    new "それは起こらなければならないことです。"

    # say L945 joh
    old "She is dealing with changing the most ingrained ideas about her sexuality and the way she expresses her love, so she needs time."
    new "彼女は自分の性癖や愛情表現の最も根深い部分と向き合っているので、時間が必要です。"

    # say L947 joh
    old "The only thing we can do is wait until she internalizes these new emotions and figure out how to deal with them."
    new "私たちができるのは、彼女が新しい感情を内面化し、それに対処する方法を見つけるまで待つことだけです。"

    # say L948 pla
    old "I understand."
    new "わかりました。"

    # say L949 joh
    old "I appreciate your commitment, you did an amazing job today."
    new "あなたの献身に感謝します。今日は素晴らしい仕事をされました。"

    # say L950 joh
    old "I'm sorry, but I have to go, another patient should be here in a few minutes."
    new "申し訳ありませんが、もう帰らなければなりません。次の患者さんが数分後に来られるからです。"

    # say L951 pla
    old "Oh ok... But when should I come again?"
    new "オッケー……でも次はいつ来ればいいんだ？"

    # say L952 joh
    old "Once Angelina books her next session I will let you know, for now you can come in the morning to continue training."
    new "一度アンジェリーナが次の予約を入れたらお知らせしますので、それまで朝に来てトレーニングを続けましょう。"

    # say L954 joh
    old "Thank you and see you later [pla]."
    new "ありがとうございます、また後で [pla]。"

    # say L955 pla
    old "Ok, see you doctor."
    new "はい、じゃあまた後で先生。"

    # say L973 roo
    old "No Angelina, I can't tolerate this anymore!"
    new "アンジェリーナ、これ以上我慢できないわ！"

    # say L974 ang
    old "I'm doing all what I can, just to make you happy."
    new "私ができる精一杯やってるのに、あなたを幸せにするためには。"

    # say L975 roo
    old "I don't see the effort you make, and I'm tired of waiting so long for you."
    new "君がどれだけ努力してるのか見えないし、これほど長い間待つのは疲れた。"

    # say L976 ang
    old "Why are you such a prick? You can't see how much I love you..."
    new "なんでそんなにムカつくの？　君には私がどれだけ君を愛してるか分かってないの…"

    # say L977 roo
    old "I know that but I need a real woman, not a beautiful doll beside me..."
    new "それが分かってるけど、本物の女性が欲しいの。美しい人形じゃ満足できないわ…"

    # say L978 roo
    old "I have been really patient... But I can't wait anymore... Look for me when you are ready to have sex like a normal person."
    new "私は我慢してきたけど…もう待てないの…準備ができたら、普通にセックスできるようになったら、また探してね。"

    # say L979 ang
    old "Come on darling... Please, you know this is hard for me..."
    new "Darling… お願い、これって私にとって本当に難しいのよ…"

    # say L980 roo
    old "Are you serious? Listen 5 months without sex I- I... You know what? I will not discuss it anymore, see you later at home..."
    new "本気？　5ヶ月も我慢したのに、あたし… もう話さない、家で待ってるから…"

    # say L987 ang
    old "Wait! Roonnie- !"
    new "待って！ルーニー！"

    # say L994 pla
    old "I'm sorry..."
    new "ごめん..."

    # say L999 ang
    old "It's ok, welcom-"
    new "大丈夫、どういたしまして"

    # say L1000 ang
    old "(WHAT IS HE DOING HERE?.)"
    new "ここにいるの？何してるの？"

    # say L1001 pla
    old "Huh, t- thank you."
    new "へえ、ありがとう。君"

    # say L1002 ang
    old "N- nice to see you again... Ehh-"
    new "また会えて嬉しい… ええと"

    # say L1004 ang
    old "Yes, the doctor Johnson's... assistant, right?"
    new "はい、ドクター・ジョンソンの… アシスタントですね。"

    # say L1006 pla
    old "Right, is Roonnie your husband?"
    new "そう、ルーニーは君の旦那さんなのか？"

    # say L1008 ang
    old "Hmm it seems like not for long... Anyway, how are you?"
    new "うーん、そう長くは続かないみたいね… でも、元気？"

    # say L1010 pla
    old "I'm fine, thanks for asking..."
    new "俺は元気だ、心配してくれてありがとう..."

    # say L1011 ang
    old "Great, and what are you doing here?"
    new "Great、ここでは何してるの？"

    # say L1012 pla
    old "I'm sorry, I was not aware you were here-"
    new "ごめん、君がここにいることには気づかなかったんだ-"

    # say L1013 ang
    old "Oh no don't worry, actually, I'm sorry that you had to listen to all of... This."
    new "大丈夫、気にしないで。実際、私がこんな……話を聞かせてしまってごめんなさい。"

    # say L1014 pla
    old "Oh no, it wasn't my intention, I- I didn't know-"
    new "ああ、すまない、そんなつもりじゃなかった、気づかなかっただけだ-"

    # say L1015 ang
    old "Never mind, though, I've been thinking about last time and wanted to apologize for the incident in Dr. Johnson's office."
    new "気にしないで、でも先日のことを考えていて、ジョンソン先生のオフィスでの出来事について謝りたいと思って。"

    # say L1016 pla
    old "Oh, no worries about that, I'm sorry about you and husband, I know it's something hard to deal with."
    new "気にしないで、君と旦那さんのこと、心配してる。そんな状況、よくわかるよ。"

    # say L1017 ang
    old "Yes, he is lovely but he is also tired, he is right about what he says, I can't satisfy his needs..."
    new "うん、彼は sweet だけれど、疲れてるのよね。彼の言うことも正しいの。彼の欲求を満たせてないの…"

    # say L1019 ang
    old "I'm sorry to tell you all this, I don't even know you..."
    new "すみません、こんなこと言っちゃって、あなたのこと全然知らないのに…"

    # say L1020 pla
    old "It's ok, don't worry."
    new "大丈夫、気にしないで。"

    # say L1021 ang
    old "I appreciate that... And I still embarrassed about the last time-"
    new "ありがとう……でも、前回のことまだ恥ずかしいのね"

    # say L1022 pla
    old "Oh please forget it, it's not important."
    new "お願い、忘れて それほどのことじゃないよ"

    # say L1023 ang
    old "It is, I was disrespectful to both of you and left the place without any explanation, and it's not your fault of course."
    new "それはそうよ、二人に対して失礼なことをして、何も説明せずにその場を去ってしまったし、もちろんあなたのせいじゃない。"

    # say L1025 ang
    old "I felt like I was betraying my husband, I had never cheated on him and I really love him..."
    new "私は夫を裏切ってるような気がして、今まで一度も浮気したことがないし、本当に彼のことを愛してるんだ..."

    # say L1026 ang
    old "I still don't know why doctor Johnson did something like that."
    new "まだドクター・ジョンソンがなぜそんなことをしたのかわからないの。"

    # say L1027 pla
    old "I understand your point, I can't say too much because I was part of the session but..."
    new "君の気持ちわかるよ、詳しくは言えないけど、俺もそのセッションに参加してたからな..."

    # say L1028 pla
    old "I know she is quite good at what she does, I have seen the progress of other patients."
    new "彼女の腕は相当なものだ、他の患者の進歩を見届けてきたからな。"

    # say L1031 pla
    old "Yes, that is why I met her, because one of my friends needed help."
    new "そうだ、それが俺が彼女と会った理由だ。友達が助けが必要だったからさ。"

    # say L1032 pla
    old "And it was a very surprising thing to see how she changed and how positive it was for her."
    new "そして彼女の変化を見て、それが彼女にとってどれだけ positivesな影響を与えたか、本当に驚いた。"

    # say L1033 ang
    old "Hmm, I don't know..."
    new "うーん、私にもよくわからない..."

    # say L1034 pla
    old "I know, at the beginning I was sceptical..."
    new "知ってるよ、最初は疑いだったけど…"

    # say L1035 pla
    old "But later on, my friend was improving so much that I had to be honest and recognize how amazing she did it with her treatment."
    new "でも後になって、友達がどんどん良くなっていったから、正直に彼女の治療法がどれだけ素晴らしいか認めざるを得なかったんだ。"

    # say L1036 ang
    old "I think I am sceptical now..."
    new "今でも少し疑わしい気分だな…"

    # say L1037 pla
    old "It is pretty normal, your process is not easy and these experiences are new for everyone."
    new "それはまあ普通だよ、君の过程は簡単なものじゃないし、この経験はみんなにとって新しいんだからね。"

    # say L1038 pla
    old "However, if she dares to try this method, it is because she knows you well enough."
    new "しかし、彼女がこの方法に挑戦するなら、それは君のことよく知ってるからだよ。"

    # say L1040 pla
    old "I must confess that I was a bit nervous, but we were in a very professional environment."
    new "正直、少し緊張したけど、プロの環境だったから大丈夫だったよ。"

    # say L1041 pla
    old "Everything was planned to make sure that you could overcome your fear."
    new "全ては君が恐怖を克服できるように計画されたんだ。"

    # say L1042 ang
    old "Hmm, I thinnk you are right, maybe I overreacted that day, my marriage needs whatever effort I can make."
    new "うーん、そうかもしれないね。あの日は過敏に反応しちゃったかもしれない。結婚のためにできることは何でもするべきだね。"

    # say L1043 pla
    old "I know you were confused but I am sure doctor Johnson is expecting to see you again no matter what happens before."
    new "君が混乱してたのは分かるけど、ドクター・ジョンソンはどんなことがあっても君とまた会いたがってるはずだよ。"

    # say L1044 ang
    old "I owe her an apology, but yes I need to solve this problem as soon as possible."
    new "彼女に謝らないとね、でもこの問題をできるだけ早く解決しないと。"

    # say L1045 pla
    old "She will be very happy to see you and the most important thing you can continue the process you are in, you need to trust her."
    new "彼女は君を見たらとても喜ぶだろうし、君が今進めている過程を続けることが一番重要だ、彼女を信じなさい。"

    # say L1046 ang
    old "You're right, I need this now more than ever, my husband is about to dump me, so I'll do whatever it takes."
    new "そうだね、今よりもっと必要なんだ、夫に捨てられそうだから、何でもするわ。"

    # say L1047 pla
    old "Don't worry, visit doctor Johnson, she will help you."
    new "心配しなくていい、ドクター・ジョンソンを訪ねて、彼女が君を助けてくれるよ。"

    # say L1048 ang
    old "Hmm alright, I will do an appointment,  I think I need to continue with my treatment, thank you so much for your words."
    new "うん、そうね、予約を入れるわ、治療を続けるべきだと思うの、本当にありがとう。"

    # say L1049 pla
    old "You are welcome,I hope things improve soon."
    new "どういたしまして、君のことが早く良くなりますように。"

    # say L1050 ang
    old "I appreciate it."
    new "それは嬉しいです。"

    # say L1051 pla
    old "Good bye."
    new "じゃあ、またな。"

    # say L1052 ang
    old "Bye Bye."
    new "さよなら"

    # say L1076 joh
    old "Welcome back Angelina, I am very happy to have you here again."
    new "アンジェリーナさん、またお越しいただいてありがとうございます。私、とても嬉しいです。"

    # say L1077 ang
    old "Hi doctor, I'm terribly sorry for my behavior last time..."
    new "博士、前回の私の態度について大変申し訳ありません..."

    # say L1078 joh
    old "Listen, the past is just a page we can't see anymore. Now tell me, how is everything going?"
    new "君の過去はもう見られないページさ。それよりも、今はどうしてるの？"

    # say L1079 ang
    old "I need your help, my husband will dump me anytime because of my problem and I don't know what to do."
    new "ドクター、私の問題で夫がいつ離婚してもおかしくないんです。何をすればいいのか分かりません。"

    # say L1080 joh
    old "Hmm, okay, we have to think carefully because we'll need something that will deliver immediate results."
    new "Hmm、そうですね、慎重に考えなければなりませんね。すぐに結果が出る方法が必要です。"

    # say L1091 joh
    old "Oh, [pla], welcome, I'm glad to see you here."
    new "Oh、[pla]、いらっしゃいませ、お会いできて嬉しいです。"

    # say L1092 pla
    old "Hello Dr. Johnson, hi Angelina."
    new "ドクター・ジョンソン、こんにちは、アンジェリナもこんにちは。"

    # say L1093 ang
    old "Hi... [pla], nice to see you again."
    new "こんにちは… [pla]、また会えて嬉しいです。"

    # say L1095 joh
    old "Well, now that [pla] is here, I have an idea to go ahead with the treatment."
    new "それでは、[pla]が来られたことですし、治療を進める方法がありますが。"

    # say L1096 joh
    old "But how do you feel about what happened last time with [pla]?"
    new "でも、前回の[pla]とのことがどう感じていますか？"

    # say L1097 ang
    old "Hmm, I had a chance to talk to him and now I feel much better."
    new "うーん、彼と話す機会があって、今は随分と楽になりました。"

    # say L1098 joh
    old "Oh really? Well, that makes things a lot easier for us."
    new "そうか？　なら、私たちにとってはずいぶん楽になるね。"

    # say L1099 joh
    old "All right, then, today we are going to continue the treatment."
    new "では、今日は治療を続けましょう。"

    # say L1100 joh
    old "So, [pla] remember that we will need to apply all the concepts you have learned."
    new "それでは、[pla] これまで学んだことを全部適用する必要がありますので、覚えておいてください。"

    # say L1102 joh
    old "But before we start I want you to help her to get relaxed a bit so please give her a massage."
    new "では、始める前に彼女が少しリラックスできるようにマッサージをしてあげてください。"

    # say L1104 joh
    old "Also, Angelina, I want you to become more familiar with the image of your husband."
    new "また、アンジェリナ、あなたが夫のイメージに慣れることを望みます。"

    # say L1105 joh
    old "So, [pla] will help us with that, he will play the role of your husband."
    new "それでは、[pla] がその役割を果たしてくれます。彼はあなたの夫の役を演じます。"

    # say L1107 joh
    old "We will start with a basic exercise, this will prepare your mind and body, then we will have the real session."
    new "まずは基本的なエクササイズから始めましょう、これで心と体を準備し、その後本番のセッションに入ります。"

    # say L1108 joh
    old "So, let's begin, please take off your shirt."
    new "では、始めましょう、シャツを脱いでください。"

    # say L1109 ang
    old "But... I- I'm not wearing a bra..."
    new "でも… 私、ブラジャーをつけてないんです…"

    # say L1110 joh
    old "I know that darling."
    new "それは知ってるよ、ダーリング。"

    # say L1111 ang
    old "So, do you mean stay topless?"
    new "そう、トップレスでいるってこと？"

    # say L1112 joh
    old "That's correct, he will give you a little breasts massage, so, you can relax and get in the mood for the next exercise."
    new "そうです、彼はあなたに少しの乳房マッサージをしてくれるので、リラックスして次のエクササイズの気分を盛り上げてください。"

    # say L1115 ang
    old "I- I am not... Sure about it..."
    new "私は……それについてまだ少し不安です……"

    # say L1116 joh
    old "Oh, darling, don't worry, we're already working on that, right? You shouldn't feel insecure about your body..."
    new "Oh、 Darling、心配しないで、もうその部分は手掛けている最中だよ。君の体について不安に思う必要はないよ…"

    # say L1117 ang
    old "I know, but... Having a man in the room makes this a little more difficult..."
    new "そうよね、でも… 男の人が部屋にいると、ちょっと難しくなるの…"

    # say L1119 joh
    old "I know you had a tough adolescence, your body grew fast and you didn't feel comfortable about it..."
    new "君の思春期は大変だったよね、体が急に大きくなって、自分自身に自信が持てなかったんだよね..."

    # say L1120 joh
    old "But, you already know that your body is beautiful, all men love it, your husband loves it, right?"
    new "でも、君は自分の体が美しいことは知ってるよね、男の人たちはみんなそれを愛してるし、あなたの旦那も大好きだって。"

    # say L1121 ang
    old "Yes, but he doesn't care..."
    new "はい、でも彼は気にしてないんです…"

    # say L1123 joh
    old "Of course not, you are very hot, you are incredible, what do you think [pla]? You like them? Those are bigger than mine, aren't they?"
    new "もちろん、あなたはとてもセクシーで、素晴らしい体をしているんだ。[pla]、あなたは好きだよ？それらは私のよりも大きいよね？"

    # say L1125 pla
    old "... Y- yes... I think you have a hug-... Beautiful boobs..."
    new "... よ、よさ... 君の胸は... 美しい..."

    # say L1127 joh
    old "Honey, I can tell you that I have not seen a more beautiful breast."
    new "ハニー、もっと美しい胸を見たことがありません。"

    # say L1128 ang
    old "It's the first time someone tells me that..."
    new "初めてそんな風に言われました…"

    # say L1129 joh
    old "It's not going to be the last time. I'm sure, now please get comfortable because our session about to begins."
    new "それは最後じゃないよ。これからもきっとそう思うから、今からリラックスしてね。セッションが始まるから。"

    # say L1130 joh
    old "I told you and I want you to enjoy it a lot... [pla], please!"
    new "あなたに伝えた通り、とても楽しんでほしいんです… [pla]、お願いします！"

    # say L1131 pla
    old "Of course!"
    new "もちろん！"

    # say L1132 ang
    old "Thank... You..."
    new "ありがとう…"

    # say L1133 joh
    old "Alright, let's take out those big babies..."
    new "では、その大きなお友達を取り出してみましょうか…"

    # say L1139 joh
    old "Ohhh, they are really beautiful... Don't you think [pla]?"
    new "おお、本当に美しいですね… そう思わないですか [pla]？"

    # say L1141 joh
    old "Hahaha, you see Angelina, now he is speechless... Come on, [pla] please have a seat, and you Angelina, have a seat over his lap."
    new "ははは、アンジェリーナ、今度は彼が言葉を失ってるね… さあ、[pla]、どうぞお座りください、そしてあなたアンジェリーナも、彼の膝の上に座って。"

    # say L1151 joh
    old "Ok, [pla] to start, do it gently..."
    new "はい、[pla] まずは優しくやってください…"

    # say L1152 pla
    old "Ok, like this?"
    new "はい、こんな感じでいいですか？"

    # say L1153 joh
    old "Yeah, how do you feel Angelina?"
    new "はい、アンジェリナ、どう感じますか？"

    # say L1154 ang
    old "I- It's ok... I'm fine..."
    new "あ、大丈夫です…でも少し緊張してます…"

    # say L1165 ang
    old "Next exercise?"
    new "次は何のエクササイズにしましょう？"

    # say L1166 joh
    old "It's ok, You just follow [pla], he will walk you through. Now please take off your clothes."
    new "大丈夫、君はただ[pla]についていけばいい。それから服を脱いでくれ。そしてベッドに横になってください..."

    # say L1167 ang
    old "Do you want me to take off everything?"
    new "全部脱いじゃってもいいですか？"

    # say L1169 joh
    old "Yes, please, and then lie on the bed..."
    new "はい、それからベッドに横になってください..."

    # say L1170 ang
    old "... Hmm alright."
    new "わかったわ..."

    # say L1172 joh
    old "Ohh, look at that, you so thick girl... Ok [pla], now is your turn."
    new "おお、見ろ、君は本当に大きいね… オッケー[pla]、次は君の番だよ。"

    # say L1173 pla
    old "My... T- turn? What do you mean?"
    new "俺の… ターン？ どういう意味だよ？"

    # say L1174 joh
    old "I'm sorry, I meant it's your turn to please Angelina. Now give oral sex to her."
    new "申し訳ありません、あなたの番だということは、エンジェリナを悦ばせる番だということです。今度は彼女に口淫をしてあげてください。"

    # say L1175 ang
    old "O- oral sex?"
    new "オーラルセックス？"

    # say L1177 joh
    old "Ok, Angelina, please remember this is part of the treatment for you, and your marriage."
    new "アンジェリナ、これはあなたの治療の一環であり、結婚生活のために必要なことだということを覚えておいてください。"

    # say L1178 ang
    old "You are right, I'm sorry."
    new "はい、その通りです。ごめんなさい。"

    # say L1179 joh
    old "It's ok, let's move on, [pla] do your job, please."
    new "大丈夫、次に進もう、[pla]、君の役割を果たしてくれ。"

    # say L1187 joh
    old "[pla] please do it as soft as possible, she must just feel you over there."
    new "[pla] できるだけ優しくやってください、彼女にはそこをただ感じさせるだけでいいんです。"

    # say L1189 joh
    old "Close your eyes Angelina, focus on the sensations, and enjoy the experience."
    new "目を閉じて、感覚に集中して、その体験を楽しんでください、Angelina。"

    # say L1190 ang
    old "I will try..."
    new "試してみようと思います..."

    # say L1199 joh
    old "Keep focused [pla], use your tongue like we have learned."
    new "集中して [pla]、舌の使い方を思い出してみて。"

    # say L1211 ang
    old "Wow, you can't imagine how happy I feel."
    new "Wow、あなたが想像できるよりもずっと幸せな気分です。"

    # say L1213 joh
    old "Well, that's fantastic because it means the process is working out."
    new "その過程がうまくいっているということは素晴らしいですね。"

    # say L1214 joh
    old "If you feel more confident to have sexual interactions, it means you are ready to try this with your husband with no fears."
    new "性的な交流に自信を持てるようになったということは、夫との関係で恐れることなく試す準備ができているということだね。"

    # say L1216 joh
    old "Great, so let's get dressed and go to the therapy bedroom."
    new "じゃあ、着替えてから療法用の寝室に行きましょう。"

    # say L1217 ang
    old "Ok!"
    new "はい、わかりました！"

    # say L1226 joh
    old "Ok, it was everything for today, but we need to continue working pretty hard."
    new "では今日のところはこれで終わりですが、これからも頑張っていきましょうね。"

    # say L1227 joh
    old "Next session is really important, so, guys please get ready and see you soon."
    new "次回のセッションはとても重要なので、皆さん準備をしてくださいね。またすぐにお会いできるのを楽しみにしています。"

    # say L1229 ang
    old "Oh thank you, I will be here on time, bye bye!"
    new "はい、ありがとうございます。時間通りに来ますので、またすぐにお会いできるのを楽しみにしています、バイバイ！"

    # say L1230 pla
    old "Good bye!"
    new "じゃあね！"

    # say L1245 joh
    old "Hi Angelina, how is everything going?"
    new "アンジェリーナ、お元気ですか？"

    # say L1246 ang
    old "Wonderful! I applied what we did with my husband and he was really happy, now I just want to learn more."
    new "素晴らしいです！主人と試してみてとても喜んでもらえて、もっと学びたいと思っています。"

    # say L1247 joh
    old "And you will, our session today is aimed at helping you do more exercises with your husband."
    new "そしてあなたができるように、今日のセッションはご主人とのエクササイズをさらに充実させるためです。"

    # say L1248 ang
    old "Sounds great!"
    new "素晴らしいですね！"

    # say L1258 pla
    old "Hi, how are you doing?"
    new "こんにちは、アンジー、元気ですか？"

    # say L1259 ang
    old "Hi [pla], I'm doing amazing."
    new "こんにちは [pla]、私は調子が最高です。"

    # say L1260 joh
    old "Welcome [pla], good to see you again, are you ready to start the new session?"
    new "ようこそ [pla]、またお会いできて嬉しいです。新しいセッションを始める準備はできていますか？"

    # say L1261 pla
    old "Yes, I am ready."
    new "はい、準備できてるよ。"

    # say L1265 joh
    old "Ok, Angelina, this time we are going to practice a fellation, this time with no fears and doing your best, ok?"
    new "はい、アンジェリナ、今回はフェラチオの練習をします。怖がらずに、最善を尽くしましょうね。"

    # say L1266 ang
    old "Oh... I had to... S- suck his cock?"
    new "あっ… 私が… その… ち、ちんこを… 吸うの？"

    # say L1268 joh
    old "Of course, last time you received all the pleasure, today we will make sure that you are able to provide it too."
    new "もちろん、前回は君が全ての快楽を受け取った。今日は君がそれを提供できるようにするんだ。"

    # say L1269 joh
    old "So that we can guarantee that your husband will also be satisfied."
    new "そうすれば、あなたの夫も満足できることが保証されます。"

    # say L1271 ang
    old "Hmm, I guess you are right..."
    new "うーん、そうかも…"

    # say L1272 joh
    old "Great, just remember what we had practiced before with the dildo, and by the way you already sucked his cock before, so don't worry."
    new "じゃあ、ディルドで練習したことを覚えておいてね。それに、君はもう彼のちんこを吸ったことがあるから、心配しなくていいよ。"

    # say L1274 joh
    old "Ok, our time is short we need to work, so, let's start. [pla], take off your pants and Angelina, please start the fellation."
    new "では、時間がないので早速始めましょう。[pla]、パンツを脱いで、アンジェリナ、フェラチオを始めてください。"

    # say L1286 ang
    old "Hmm... "
    new "うーん…"

    # say L1288 joh
    old "Please enjoy it Angelina, try to focus only on what you feel, like last time, don't think about [pla], just enjoy what you can feel."
    new "アンジェリナ、楽しんでください、先ほどと同じように感じることだけに集中して、[pla] のことは考えないで、ただ感じられるものだけを楽しんで。"

    # say L1300 joh
    old "Alright, now let's continue with the next exercise."
    new "では、次の練習に進みましょう。"

    # say L1303 ang
    old "NEXT EXERCISE?"
    new "次のエクササイズ？"

    # say L1305 joh
    old "Of course, you're the one asking for faster improvement, aren't you?"
    new "もちろん、早く上達したいのは君だね？"

    # say L1306 joh
    old "Also, we need you to be able to have sex with your husband as soon as possible, so your marriage can be saved."
    new "また、あなたが夫とできるだけ早く性行為ができるようになることが必要です。そうすれば、あなたの結婚を救うことができます。"

    # say L1307 ang
    old "Hmm, you're right..."
    new "うーん、そうですね…"

    # say L1308 joh
    old "Alright, let's go to the bedroom, so you can have sex with [pla]."
    new "それじゃ、寝室に行こう。[pla]とセックスするんだ。"

    # say L1310 ang
    old "Sex?"
    new "セックス？"

    # say L1311 joh
    old "Oh, relax, you are going to love it."
    new "Oh、リラックスして。君はきっと気に入るよ。"

    # say L1318 joh
    old "Alright, [pla] I need you to remember your trainin."
    new "それじゃ、[pla] 訓練の内容を思い出してね。"

    # say L1319 joh
    old "You're going to have sex but you can't stop until she has reached the orgasm."
    new "セックスはするが、彼女がオーガズムに達するまで止められない。"

    # say L1323 joh
    old "Angelina, I need you to understand this, in your treatment, there is no way to learn about sex without having sex."
    new "アンジェリナ、これはあなたの治療の一環だから、セックスを通じて学ぶしかないんだよ。"

    # say L1324 joh
    old "That is why we are here in a safe therapy so that you learn to enjoy it."
    new "それが安全な治療の一環だから、君がそれを楽しむ方法を学ぶためここにいるんだ。"

    # say L1325 ang
    old "... Ok, thank you doctor Johnson."
    new "はい、ありがとうござました、ジョンソン先生。"

    # say L1326 joh
    old "Alright, please, both get naked and let's start."
    new "では、二人とも裸になって、始めましょう。"

    # say L1352 ang
    old "Wow, that was really good, I thank you so much doctor Johnson."
    new "Wow、それは本当に良かったです、ドクター・ジョンソン、本当に感謝しています。"

    # say L1353 joh
    old "You still have a lot to learn, but now you are open to new experiences, and [pla] you did an outstanding job."
    new "まだ学ぶことはたくさんありますが、新しい経験に開かれるようになりましたね、そして [pla] あなたは素晴らしい仕事をしました。"

    # say L1355 ang
    old "Yes, you [pla], you made me feel things I've never felt before with any man."
    new "はい、あなたが [pla] で、私には今までの男性では感じたことのない感情を教えてくれたわ。"

    # say L1356 pla
    old "... I- I'm glad everything turned out okay..."
    new "…俺も、無事に終わったことにホッとしてるよ…"

    # say L1358 joh
    old "Alright, get dressed and let's go to the therapy room, I have a new patient in a few minutes."
    new "では、服を着てください。セラピールームに行きましょう。新しい患者さんが数分後に来られますので。"

    # say L1368 joh
    old "Alright, please apply these exercises with your husband."
    new "では、ご主人様とこれらのエクササイズをしてください。"

    # say L1369 joh
    old "Focus on enjoying, but don't push it, as you will see the changes gradually."
    new "楽しむことに集中して、でも無理をしないで。徐々に変化が現れてくるから。"

    # say L1370 ang
    old "Ok, I will have that in mind."
    new "はい、そのことを心に留めておきます。"

    # say L1371 joh
    old "I'm glad to see you happy, I can't wait to hear how it went with your husband."
    new "君が幸せそうで嬉しいよ、夫との時間がどうだったか聞いてみたいね。"

    # say L1372 ang
    old "Yes, I am a little anxious to try it as soon as possible."
    new "はい、早速試してみたいので少し緊張しています。"

    # say L1373 joh
    old "Okay, then don't waste any more time and go home. See you at the next session, darling."
    new "じゃあ、時間の無駄にしないで早く帰ろう。次回のセッションでまた会えるのを楽しみにしているわ、Darling。"

    # say L1374 ang
    old "Alright, thank you so much!"
    new "わかりました、本当にありがとうございます！"

    # say L1375 joh
    old "See you. And please, have fun!"
    new "じゃあね、楽しんでくださいね。"

    # say L1385 joh
    old "That was a significant step with her therapy."
    new "それは彼女の治療にとって大きな一歩でしたね。"

    # say L1387 joh
    old "And you, Congratulations on such a fantastic performance, I can see that my lessons were very helpful, maybe better than I thought."
    new "そしてあなた、素晴らしいパフォーマンスでしたね、私のレッスンがとても役立ったようで、思っていた以上にね。"

    # say L1388 pla
    old "Thank you, I appreciate all your patient with me."
    new "ありがとうございます、先生の耐心に感謝しています。"

    # say L1389 joh
    old "You are welcome. Anyway, I have to get ready for my next patient, so, see you at the next session."
    new "どういたしまして。ともかく、次の患者さんの準備をしなければならないので、次回のセッションでお会いしましょう。"

    # say L1390 pla
    old "Sure, good bye Dr. Johnson."
    new "はい、また次回に、Dr. Johnson。"

    # say L1406 joh
    old "Welcome Angelina, how is everything going?"
    new "アンジェリーナさん、お越しいただきありがとうございます。お元気ですか？"

    # say L1407 ang
    old "I couldn't be happier."
    new "私はとても幸せな気持ちです。"

    # say L1408 joh
    old "So, were you able to do the exercises with your husband without problems? "
    new "それじゃ、夫とエクササイズを問題なくできましたか？"

    # say L1409 ang
    old "That's right! And my husband is really happy, your work is incredible!"
    new "そうですよ！そして私の夫も本当に幸せです、あなたの仕事は素晴らしいです！"

    # say L1410 joh
    old "I'm so happy to hear that! I've prepared a new lesson today, you'll love it..."
    new "それはうれしいですね！今日は新しいレッスンを用意しました、きっと気に入ってくれると思いますよ..."

    # say L1421 joh
    old "Welcome [pla], we are happy to have you here."
    new "ようこそ、[pla]さん、お越しいただいてありがとうございます。"

    # say L1422 pla
    old "Hello!"
    new "こんにちは！"

    # say L1423 ang
    old "Hi, [pla]!!"
    new "こんにちは、[pla]！！"

    # say L1425 joh
    old "Well guys, now [pla] is here, there's no time to lose, so, let's go to the room."
    new "皆さん、[pla]が来られたので、時間がないですね。さあ、部屋に行きましょう。"

    # say L1426 ang
    old "Perfect!"
    new "パーフェクト！"

    # say L1434 joh
    old "According to the advances that you mentioned that sex with your husband is reaching... Let's practice again with a sexual exercise."
    new "君が夫とのセックスで進展しているという話を聞いたが……またセックスの練習をしよう。"

    # say L1436 joh
    old "But, before we start, I want you to practice oral sex, that will drive your husband crazy."
    new "でも、始める前に、夫を狂わせるようなフェラチオの練習をしてほしいんです。"

    # say L1437 ang
    old "Got it! I want to make sure I'm doing this the right way for my husband."
    new "わかりました！夫のために正しい方法でやってみたいと思います。"

    # say L1454 joh
    old "Now that we are ready, I have a special task for you Angelina."
    new "それじゃ、準備はできているね、アンジェリナ。特別な課題があるんだ。"

    # say L1455 ang
    old "Ok, I'm ready for whatever you want."
    new "はい、何でもしてください。"

    # say L1456 joh
    old "I love that enthusiasm! I want you to take the lead and fuck him wild, I want you to be the one to say what to do."
    new "その熱意が大好きだ！君がリードして激しく彼を犯すんだ、何をするかの指示は君が出すんだ。"

    # say L1457 joh
    old "So, I want you to get on him and take the rhythm and intensity, I want you to take an active role in sex..."
    new "それじゃ、君が上に乗ってリズムと強さをコントロールして、セックスで積極的に動いてほしいんだ…"

    # say L1459 ang
    old "Hmm... I- I will try, get ready [pla]."
    new "うん… 私、試してみるから、準備してね [pla]。"

    # say L1476 ang
    old "You are the most amazing therapist I've ever had."
    new "あなたは私が今までにいた最高のセラピストです。"

    # say L1477 joh
    old "I appreciate all the effort you did, I know it was not easy but now you can see the results."
    new "あなたの努力を本当に感謝しています、簡単なことではなかったけど、今その成果が見えてきましたね。"

    # say L1478 ang
    old "Doctor, I have, no words to say how much I thank you for all the knowledge and patience you invested..."
    new "ドクター、言葉にできないほど感謝しています。あなたが投資してくださった知識と耐心に、本当に心からです。"

    # say L1480 ang
    old "And I thank you too [pla], you really help me with your... Abilities."
    new "そして私も感謝しています [pla]、あなたの...能力のおかげで本当に助かりました。"

    # say L1481 pla
    old "It's a pleasure, I'm glad to have helped you."
    new "それが喜びです、君の役に立てて良かったです。"

    # say L1483 joh
    old "Ok, it's time guys, get dressed and let's go to the therapy bedroom..."
    new "では、皆さん、服を着て、治療のための寝室に行きましょう..."

    # say L1494 joh
    old "Ok, today we finished our team practice sessions. Angelina, you and I will continue the process together with therapy."
    new "では、今日でチーム練習は終了です。Angelinaさん、今後はあなたと私が一緒に治療を続けていきます。"

    # say L1495 ang
    old "Oh... So, there are no more sessions with [pla]?"
    new "あ、そう… [pla]とのセッションはもうないのね。"

    # say L1497 joh
    old "No, he did his job and now we can continue with therapy. Now is the moment to put all of this in practice with your husband."
    new "いいえ、彼は役割を終えたんです。これからは治療に専念しましょう。今こそあなたの旦那さんと一緒にこの経験を生かすときです。"

    # say L1498 ang
    old "Oh, alright..."
    new "そうですの、わかりました..."

    # say L1499 joh
    old "Remember we have other things to work on together. If we see we would need [pla]'s help again, I would bring him to therapy."
    new "他のことも一緒に取り組んでいくことを忘れないでください。もしまた[pla]の助けが必要になったら、彼を治療に連れてきましょう。"

    # say L1501 ang
    old "Oh, great, I'm glad to hear that. Anyway, I can't describe how happy I am and how happy I will make my husband..."
    new "そうですか、それは良かったです。でも、どれだけ幸せか、そして旦那様をどれだけ幸せにするかは、言葉にできないくらいです..."

    # say L1502 ang
    old "I will practice a lot with him! Thank you doctor Johnson, I will call you to make a new appointment."
    new "私はたくさん練習します！ジョンソン先生、ありがとうございまして、新しい予約を入れさせていただきます。"

    # say L1503 joh
    old "Ok, please have fun, it was nice to walk you through this process."
    new "では、存分にお楽しみください。このプロセスを説明することができて嬉しかったです。"

    # say L1506 pla
    old "Uhh... Goodbye Angelina."
    new "うーん… さようなら、Angelina。"

    # say L1514 joh
    old "Well, [pla], I really appreciate your job, you did amazing, every single session, I'm very proud of you."
    new "WELL、[pla]、あなたの仕事は本当に素晴らしかったですね、毎回のセッションで素晴らしい仕事をしてくれて、とても誇りに思います。"

    # say L1515 pla
    old "Oh, t- thank you, I just followed all your instructions."
    new "あ、た- ありがとう、指示通りにやっただけです。"

    # say L1516 joh
    old "I know. By the way,  I want to have another session, just for you and me..."
    new "知っていますよ。ところで、あなたと私だけのもう一つのセッションをしたいんです..."

    # say L1517 joh
    old "But I have another patient coming, it's too late to cancel it..."
    new "でも次の患者さんが来るので、キャンセルするのは今更ですね..."

    # say L1518 pla
    old "Another session, what do you mean?"
    new "別のセッションって、何のこと？"

    # say L1520 joh
    old "Hmm, I mean I need to check something, so let's call it another lesson..."
    new "うーん、確認する事があるので、また別のレッスンとしてみましょう..."

    # say L1521 pla
    old "... Hmm ok, sure."
    new "うん、わかった、いいよ。"

    # say L1522 joh
    old "I know next session is going to be pretty fun, so please sleep well."
    new "次回のセッションはきっと楽しいので、よく休んでくださいね。"

    # say L1524 joh
    old "I am considering giving you a prize before we start another treatment, just because you were amazing with Angelina..."
    new "次回の治療を始める前に、君がアngelinaと素晴らしいことをしたので、君に賞をあげようかと考えているんだ。"

    # say L1526 joh
    old "Just come see me tomorrow and don't be late."
    new "明日来てください、遅れないでね。"

    # say L1527 pla
    old "Alright, I will be here."
    new "はい、ここにいます。"

    # say L1528 joh
    old "Great, see you!"
    new "では、明日お会いできるのを楽しみにしています。"

    # say L1543 joh
    old "Hi, I was waiting for you desperately."
    new "こんにちは、あなたを心待ちにしていました。"

    # say L1544 pla
    old "Good morning, thank you I tried to be on time-"
    new "おはよう、ありがとう。遅れないように頑張ったんだけど-"

    # say L1545 joh
    old "You are, don't worry! It's just that I don't want to talk."
    new "心配しないでください！ただ、話したくないだけなんです。"

    # say L1546 pla
    old "Uhh, w- wha-?"
    new "うっ、わっ、何それ？"

    # say L1548 joh
    old "Let's go to the room, there is no time to lose."
    new "部屋に行きましょう、時間は惜しいですから。"

    # say L1555 joh
    old "Well, I want to fuck you right now, no lessons, no patients just hard sex."
    new "WELL、今すぐあなたを犯したいんです、レッスンも患者も関係ありません、ただ激しいセックスだけが欲しいんです。"

    # say L1557 joh
    old "Why don't you make yourself comfortable and let me suck your dick?"
    new "なぜリラックスして私のちんこを吸ってあげてくれないかな？"

    # say L1580 joh
    old "Yummy!"
    new "うまい！"

    # say L1587 joh
    old "It's delicious, do you like the way I suck it?"
    new "美味しくて、この吸い方があなたの好みですか？"

    # say L1598 joh
    old "Wow, I needed that session. You can't imagine how hot it was, you did amazing."
    new "Wow、そのセッションが必要でしたね。どれだけ熱かったか想像もつきません、あなたが素晴らしい仕事をしてくれました。"

    # say L1599 pla
    old "I did my best."
    new "俺、精一杯やったぞ。"

    # say L1600 joh
    old "Absolutely, you fucked me as I needed to.  I think I need a little more, though..."
    new "絶対に、あなたが必要とした通りに犯したわ。でも、もう少し欲しいかもしれないね…"

    # say L1601 joh
    old "Just keeps coming over sometimes just to... You know, have some fun lessons."
    new "時々来て、ちょっと楽しいレッスンをしてあげるんです。"

    # say L1603 joh
    old "Perfect, and when I need your help again with another patient, I'll let you know."
    new "完璧です、また別の患者さんのためにあなたの助けが必要になったら、連絡します。"

    # say L1605 joh
    old "Ok, now I have to get ready for the session with my next patient, see you soon [pla]."
    new "では、次の患者さんとのセッションの準備をしなければなりませんね、またすぐにお会いできるのを楽しみにしています [pla]。"

    # say L1606 pla
    old "Got it. See you, doctor Johnson."
    new "わかった、またね、ジョンソン先生。"

    # say L1629 pla
    old "Oh, wow."
    new "おお、わお。"

    # say L1630 roo
    old "Hey buddy! What's up?"
    new "Hey buddy！ What's up？ → ヘイ、元気？何してるの？"

    # say L1632 pla
    old "H- Hi."
    new "お、お前。"

    # say L1633 ang
    old "Hey [pla], how are you doing?"
    new "Hey [pla]、元気にしてる？"

    # say L1634 roo
    old "Oh, so you guys know each other?"
    new "あ、そうなんだ。あなたたち知り合いだったの？"

    # say L1636 pla
    old "Uhh... W- well- "
    new "うっ… ええと…"

    # say L1638 ang
    old "Yes! He is the assistant of doctor Johnson... He helped us with... With the treatment..."
    new "はい！彼はジョンソン博士の助手で……私たちの治療を手伝ってくれたの……"

    # say L1639 roo
    old "Wow, you are quite young, I didn't know you had such wonderful therapy abilities. You must know buddy, you saved my marriage!"
    new "Wow、あなたは若いのにこんな素晴らしい治療能力を持ってるなんて知りませんでした。友達、あなたが私たちの結婚を救ってくれたの本当に感謝してるよ！"

    # say L1641 roo
    old "You don't know how important was this, I feel so thankful that I hope you go to the store so I can give an enormous discount."
    new "あなたがどれだけ重要だったか言葉にできないわ、感謝の気持ちを伝えたくて、お店に行ってくれたら大きな割引をするつもりよ。"

    # say L1642 pla
    old "Oh, thanks."
    new "あ、ありがとう。"

    # say L1643 roo
    old "I have no words to tell how I appreciate what you did for me, look Angelina is pregnant and we are very happy about it."
    new "あなたがしてくれたことの感謝の言葉もありません、見て、エンジェリナが妊娠していて、私たちはとても幸せです。"

    # say L1646 roo
    old "I know the universe will reward you for this magnificent help and-"
    new "この素晴らしい手伝いに対して、宇宙があなたを報いてくれることを知っていますよ。"

    # say L1647 ang
    old "We really appreciate your help. Darling we need to go, I want to get some fresh air."
    new "私たち、あなたの手伝いが本当にうれしいわ。ダーリング、行かなきゃ。新鮮な空気を吸いたいの。"

    # say L1648 pla
    old "Oh sure, it was nice to see that you guys are happy."
    new "もちろん、君たちが幸せそうで良かったな。"

    # say L1649 roo
    old "We are very happy to see you too, now excuse us, we have to go."
    new "私たちもあなた方を見てとても幸せです、でもちょっと失礼します、行かないと。"

    # say L1650 pla
    old "... Sure."
    new "...まあ。"

    # say L1651 ang
    old "Have a nice day [pla]!"
    new "良い一日をね [pla]！"

    # say L1652 roo
    old "Yes buddy! Have a great day."
    new "はい、いいね！良い日をね。"

    # say L1653 pla
    old "See you!"
    new "また会おうな"

    # say L1658 pla
    old "Wow... So, she is pregnant..."
    new "Wow... そうか、彼女は妊娠しているんだ..."

    # say L1674 pla
    old "Hi Dr. Johnson, how are you?"
    new "Dr. Johnson、こんにちは。お元気ですか？"

    # say L1675 joh
    old "Hi [pla], I'm excellent, thanks for asking. What about yourself, young man?"
    new "こんにちは [pla]、私は元気です、ありがとうございます。あなたはいかがですか、若者さん？"

    # say L1676 pla
    old "I'm good, thanks! And hmm, I would like to talk about s- something with you, it would take just a couple of minutes."
    new "元気だ、ありがとう！実はちょっと相談したいことがあるんだ、数分だけ時間を使ってもらえるか？"

    # say L1677 joh
    old "Sure, what is it about?"
    new "もちろんです、何についてですか？"

    # say L1678 pla
    old "I wouldn't like to bother you but I'm f- facing a tough situation now and I'm l- looking for a job."
    new "迷惑をかけたくはないんだけど、今ちょっと厳しい状況で、仕事を探しているんだ。"

    # say L1679 pla
    old "You know I'm a hard worker and I would do whatever you assign to me."
    new "知ってるだろ、俺は一生懸命働くし、君が何をやらせてもやる。"

    # say L1681 joh
    old "I see, but... I can't offer you anything right now."
    new "分かりましたけど…今のところ何もお仕事はお任せできませんね。"

    # say L1682 joh
    old "I don't have any patients for you at the moment..."
    new "現在はあなたに患者さんを割り当てられませんね…"

    # say L1684 pla
    old "R- really? I had some hopes on you."
    new "ほんとですか？　俺は君に少し期待してたんだけど。"

    # say L1685 pla
    old "Maybe if you think of somethin-"
    new "何か考えてみるかもしれないけど…"

    # say L1686 joh
    old "[pla], I really don't have anything since I don't have many patients now, however, if I get to need you, I'll reach you out."
    new "[pla]、最近患者さんが少ないので特に何もありませんが、必要になったら連絡いたします。"

    # say L1688 joh
    old "You have been very well trained and you were exceptional at your duties with the last patient."
    new "あなたは非常に良く訓練されており、前の患者さんとの仕事でも優秀でした。"

    # say L1689 joh
    old "I'll call you when I need you..."
    new "必要になったら連絡しますね。"

    # say L1691 pla
    old "I see... Hmm, alright... I'll keep looking for it. Thanks Dr. Johnson, I appreciate your time."
    new "わかった……うん、そうするよ……探しつづけるから。ありがとう、Dr. Johnson、時間を作っていただいて感謝してる。"

    # say L1692 pla
    old "Goodbye and keep me posted in case you have jobs for me, I would appreciate it."
    new "さようなら、もし仕事があったら連絡してください、助かります。"

    # say L1693 joh
    old "Sure I will, have a nice day."
    new "もちろんです、良い一日を。"


# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/SisStory.rpy
translate japanese strings:

    # say L9 sis
    old "Hey [pla], I heard [mo1] and [mo2] arguing about you last night."
    new "Hey [pla]、[mo1]と[mo2]が昨夜、あなたのことを言い争ってたって聞いたの。"

    # say L10 sis
    old "Do you know what happened?"
    new "知ってるの？何が起きたの？"

    # say L11 pla
    old "About me? Oh, fuck... "
    new "俺について？おい、くそ..."

    # say L12 sis
    old "What? Do you know what it was about?"
    new "何？それについて何だったの？"

    # say L13 pla
    old "No, no I don't know. I, uh... I have to go."
    new "知らねえよ、知らねえ。あのさ、行かなくちゃならないんだ。"

    # say L18 sis
    old "Wait, don't leave yet! I kinda need your help... "
    new "待って、まだ行かないで！ちょっと手伝ってほしいんだ..."

    # say L22 sis
    old "Well, you know all the nerdy shit, right?"
    new "WELL、あなたは全部のオタクな知識を持っているよね？"

    # say L23 pla
    old "... What are you trying to say?"
    new "何を言いたいんだ？"

    # say L24 sis
    old "What I mean is, do you know how to make a website?"
    new "私が言いたいのは、ウェブサイトを作れるかどうかなの。"

    # say L25 pla
    old "Well, yes, I know how to do it."
    new "まあ、そうだよ、できるさ。"

    # say L26 sis
    old "See, that's nerdy shit... "
    new "見ろ、それがオタクのすることだよ…"

    # say L27 pla
    old "Come out with it. What do you need?"
    new "何だよ、言ってみろ。何が必要なんだ？"

    # say L28 sis
    old "Haha. Ok, just come to my room in the afternoon and I will explain everything..."
    new "ははは、分かったわ。午後に部屋に来てくれたら、全部説明するから..."

    # say L60 pla
    old "Oh, shit..."
    new "オッシャイト..."

    # say L64 sis
    old "(GOD that's his... It's huge...)"
    new "神様、それが彼の… 本当に大きい…"

    # say L70 pla
    old "No... It's... Not... What... It seems..."
    new "いや... そうに見えるけど... 実際は... 別のものだ..."

    # say L87 pla
    old "Oh shit, did she see you?"
    new "オッシャイ、見ちゃったか？"

    # say L89 bri
    old "Of course not. No one but you can see me..."
    new "もちろん啦。君以外には誰も見えない啦..."

    # say L91 pla
    old "Yeah... But she saw me... Like this... Fuck..."
    new "うん... でも彼女に見られちゃった... こんな格好で... シット..."

    # say L93 pla
    old "Now what? It doesn't go down..."
    new "今どうすりゃいいんだ？これさげないよ…"

    # say L95 bri
    old "Well, I think that interrupting the process of transferring magic power so abruptly was not a good thing..."
    new "急に魔法力を移転するのを止めるのはよくなかったと思うの…"

    # say L97 pla
    old "So, now what do I do to get this thing down?"
    new "じゃあ、この状態から脱するには何すればいいんだ？"

    # say L99 bri
    old "Well... It would be best to wait for your body to process all the magical power it received for the first time."
    new "まあ……初めて受け取った这么多魔法力を体が処理するには時間がかかるよね。"

    # say L101 pla
    old "Okay. It's probably best to go to my room before someone else comes in and sees me with this..."
    new "分かった。誰かが入ってきてこれを見つける前に部屋に戻る方がいいだろうな。"

    # say L103 bri
    old "Ok, I'll rest and try to recover some magical energy."
    new "わかった、休んで魔力を回復するね。"

    # say L130 pla
    old "Oh... Hi, [sis]... "
    new "おっ…こんにちは、[sis]…"

    # say L131 sis
    old "I've been waiting for you. Let's jump right into it, shall we?"
    new "待ってたわ。さあ、早速始めるか？"

    # say L132 pla
    old "... Sure, I guess."
    new "…まあ、いいよ。"

    # say L134 sis
    old "Now, pay attention... As you know, I have been selling clothes to friends and acquaintances."
    new "それじゃ、よく聞いて……あなたも知っている通り、私は友達や知り合いに服を売ってるの。"

    # say L135 sis
    old "But now I want to sell them on the internet! That's why I need you to help me make a website."
    new "でもね、今度はインターネットで売ることに決めたの！だからウェブサイト作る手伝いをしてほしいの。"

    # say L136 pla
    old "Well, I've never done a storefront site before... But it should be easy enough."
    new "WELL、店舗サイトを作るのは初めてだけど… でもそれほど難しくないだろう。"

    # say L137 sis
    old "Perfect! Good nerd! Because I will need it ready for next week. I have a lot of items to post."
    new "完璧！いいね、お兄さん！来週までに準備できなきゃならないの。たくさんの商品を出品するから。"

    # say L138 pla
    old "What? That's gonna be pretty hard to make it that fast, [sis]."
    new "何？そんな短期間に作るのは相当難しいぞ、[sis]。"

    # say L139 pla
    old "Making a good website takes time. You'd have to work on it for days, sometimes weeks. And then it could be buggy and-."
    new "良いサイトを作るには時間がかかるんだよ。数日から数週間は必要で、それにバグが出たりして-"

    # say L140 sis
    old "Oh, come on, [pla]! You're a nerd. King nerd, in fact. I trust you can whip my site up in no time."
    new "あら、Come on、[pla]！お前はオタクだろ、それも王様級の。私が頼むサイトなら、すぐに作れるだろ。"

    # say L141 pla
    old "It's just not as simple as you think. Actually, I'm going to need you to work closely with me to tell me how you want it designed."
    new "そんなに簡単な話じゃないんだよ。実際、君がどうデザインしたいのかを詳しく教えてくれないと、一緒に作業しないと駄目なんだ。"

    # say L142 sis
    old "Alright, but how long will this take? And I'm not trying to just get this for free. I'm willing to pay a small fee for your help."
    new "分かったけど、どれくらいかかるの？それに、ただで手伝ってほしいわけじゃなくて、少しだけ報酬を払うつもりよ。"

    # say L143 pla
    old "Really? Hmmm... Maybe we can work in the afternoons and see how far we can go with it."
    new "本当に？ふむ……午後に一緒に作業してみて、どれくらい進められるか見てみようか。"

    # say L144 sis
    old "That's the spirit, little dude. And hey, if it all works out well, I could share some of the profits."
    new "その調子、ちびくん。そして、うまくいけば利益を分けてあげるよ。"

    # say L145 pla
    old "Nice. Sounds good to me."
    new "いいね、俺もその方がいいと思うよ。"

    # say L146 sis
    old "Perfect! Then I will wait for you in the afternoon in my room so we can start working. And don't have me waiting like you did yesterday."
    new "完璧！それじゃあ午後に私の部屋で待ってるから、一緒に作業始めよう。でも昨日みたいに待たせないでね。"

    # say L147 pla
    old "Ok, I will see you in the afternoon to help you."
    new "分かった、午後に君の部屋で手伝うからね。でも昨日みたいに待たせないでくれよ。"

    # say L148 sis
    old "Thank you so much! By the way, what have you been doing in the garage?"
    new "ありがとう！それにしても、ガレージで何してたの？"

    # say L149 pla
    old "Well... Uhh... A school project... "
    new "まあ... うーん... 学校のプロジェクトだよ..."

    # say L150 sis
    old "And what's so exciting in the project that's making your dick so hard?"
    new "そのプロジェクトで何がそんなに興奮させて、あんなにペニスを硬くしてるの？"

    # say L151 pla
    old "What? Uhh... I don't know... What are you're talking about... "
    new "何？うーん…わからない…何言ってるの…"

    # say L152 sis
    old "Haha. Yeah, right. You know I saw it?"
    new "ははは、そうよね。私が見ちゃったこと、知ってるでしょ？"

    # say L154 sis
    old "Ok, ok, don't answer me. I was just being curious... If you need to go ahead with your project, do your thing."
    new "分かった、分かった、答える必要ないよ。ただ気になったのさ… あなたのプロジェクトを進めるなら、好きなようにやって。"

    # say L155 sis
    old "Just don't forget me in the afternoons."
    new "でも、午後のことは忘れちゃダメね。"

    # say L185 sis
    old "Damn, it's late. I didn't realize how much time has passed."
    new "うわ、遅いわ。時間の経つのを全然気づかなかった。"

    # say L189 pla
    old "Yup, we did a lot of work today."
    new "今日もよく働いたな。"

    # say L190 sis
    old "That's right, you deserve a break today. Thanks for your hard work."
    new "そうね、今日もよく頑張ったわ。お疲れさま。"

    # say L191 pla
    old "Ok, you are very welcome... See you later, good night."
    new "いいよ、どういたしまして… またね、おやすみ。"

    # say L200 pla
    old "Yeah, but we are making so much progress."
    new "そうだ、でも進捗がめっちゃ良くなってるじゃん。"

    # say L201 sis
    old "Right! I like this kind of work. You typing all of those codes and me saying what to do... "
    new "うん！ この仕事、好きだな。あなたがコードを打って、私が指示するの、楽しいんだ…"

    # say L202 pla
    old "Yeah... That was really fun... "
    new "そうだな… それは本当に楽しかった…"

    # say L203 sis
    old "Oh, come on, it wasn't that bad and I will pay you... "
    new "ええ、そんなに悪くないし、ちゃんと払うからね…"

    # say L204 pla
    old "You are right about that. We are a good team."
    new "君が言う通りだな。いいチームだな。"

    # say L205 sis
    old "That's better! Ok, let's link back up tomorrow to keep working!"
    new "それじゃあ、明日また一緒に頑張ろうね！"

    # say L206 pla
    old "Ok, see you later, [sis]. Have a good night."
    new "じゃあまた明日、[sis]。おやすみ。"

    # say L220 pla
    old "What the fuck! What is this?"
    new "何てことだ！これは何だよ！"

    # say L227 sis
    old "NOTHING... NOTHING! (Shit!) I THINK WE'RE DONE FOR TODAY!"
    new "何もかも... 何もかも！（くそ！）今日はこれで終わりにしよう！"

    # say L228 pla
    old "But... There is still so much to do."
    new "でも……まだやることたくさんあるよ。"

    # say L229 sis
    old "A Virus! My laptop has a virus and I need to fix it... Come tomorrow. Leave now."
    new "ウイルス！私のラップトップにウイルスが入っちゃって、直さなきゃならないの… 明日来なさい。今すぐ帰って。"

    # say L230 pla
    old "... (Hmm, that was weird.)"
    new "……（なんだか変だな。）"

    # say L247 pla
    old "I should check if [sis] needs help with the website."
    new "俺、[sis]のサイトの手伝いが必要かどうか確認しとくべきだな。"

    # say L256 pla
    old "Oh wow!"
    new "おわっ！"

    # say L259 pla
    old "I- I'm sorry, I didn't k- know..."
    new "あー、ごめん、知らなかった…"

    # say L260 sis
    old "Oh, come on... This isn't what you wanted to see?"
    new "あら、そう言うの？…でも見たくなかったの？"

    # say L262 sis
    old "Turn around [pla], I want you to see me..."
    new "振り向いて [pla]、見てほしいの…"

    # say L265 sis
    old "Ohh... Look what we have here... You definitely have a huge cock..."
    new "おお……これを見てごらん……ずいぶん大きいんだね……"

    # say L267 sis
    old "You have worked very, very hard for me, maybe you deserve a small reward."
    new "あなたはとても頑張ってくれたわ、ちょっとした報酬をあげてもいいかもしれないね。"

    # say L269 sis
    old "Well I think you have something for me down there, maybe I should take care of it."
    new "下には私にくれるものが何かあるみたいね、私が手伝うべきかもしれないわ。"

    # say L271 sis
    old "I know you want to fuck me... I think I could let you fuck my mouth, would you like that?"
    new "あなたが私を犯したいのはわかってるわ… 口なら犯させてもいいけど、それってどう思う？"

    # say L273 sis
    old "Yes, I'll let you fuck my mouth, with that huge cock..."
    new "はい、その大きなチ○ポで私の口を犯していいわよ…"

    # say L274 sis
    old "Now, take out that cock and come here!"
    new "さあ、そのチ○ポ出してきて、こっちに来い！"

    # say L292 pla
    old "Wow! That was just a dream..."
    new "Wow！ あれって夢だったのか…"

    # say L293 pla
    old "I should definitely stop playing visual novels..."
    new "絶対にビジュアルノベルを辞めなきゃいけないな…"

    # say L294 pla
    old "Working with her so much is affecting me in some way."
    new "彼女と一緒にいる時間が長くなって、何か影響を受けているみたいだな。"

    # say L325 pla
    old "Ufff finally... I think that's it, we are done."
    new "うっす、やっと終わったな。これで一区切りだ。"

    # say L326 sis
    old "Really? Finally? Excellent!!! So, how do we start selling products?"
    new "本当に？やっと？最高！！！じゃあ、商品の販売はどうやって始めるの？"

    # say L327 pla
    old "Hmm... I'm a bit tired because of all I have done, we can check tomorrow."
    new "うーん…疲れたけど、明日にするか。"

    # say L328 sis
    old "What?! I've been waiting for weeks! I need to sell my products as fast as I can, it will take just a moment and you're not going die for that... "
    new "何よ？！ 何週間も待ってたんだよ！ 商品を早く売りたいのに、ちょっとだけ手伝ってよ、死ぬわけじゃないでしょ…"

    # say L329 pla
    old "Ok, I will explain, pay attention to this."
    new "分かって、説明するからちゃんと聞いてろ。"

    # say L336 pla
    old "Oh, this is a very interesting part on web designing, I used javascript in order to make your webpage responsive, I apply the layouts and-"
    new "この部分はウェブデザインでとても興味深いんだ、JavaScriptを使ってページをレスポンシブにしたんだよ、レイアウトも適用して"

    # say L337 sis
    old "Come On! straight to the point nerd! How do I upload the content?"
    new "Come On！ 本題に入りなよ、オタク！ 内容をアップロードするにはどうすればいいの？"

    # say L338 pla
    old "Ok, well, to upload the pics and info, you need to access with the admin account, open the products window and there you can upload, item by item... "
    new "じゃあ、写真と情報をアップロードするには、管理者アカウントでログインして、製品ウィンドウを開いて、アイテムごとにアップロードすればいいんだよ…"

    # say L339 pla
    old "The description needs a title, detailed info of the product, the pics and finally the price, and there you go!"
    new "商品の説明にはタイトルと詳細情報、写真、最後に価格を入れて、それであとはOK！"

    # say L340 sis
    old "Woow, amazing, let me try myself... "
    new "わお、すごい、自分で試してみる…"

    # say L344 pla
    old "Ok... "
    new "Ok..."

    # say L345 sis
    old "It's not as hard as you said, actually it's pretty simple... "
    new "意外と難しくないわ、実際には簡単だよ…"

    # say L346 pla
    old "Well, it's because the hardest part was done already with the coding... "
    new "まあ、一番大変な部分はすでにコーディングで済ませちゃったからね…"

    # say L347 sis
    old "Suuuuure. Now, how can an user make a purchase?"
    new "ユーザーが購入するにはどうすればいいの？"

    # say L348 pla
    old "Well, everything is done thru the security framework-"
    new "まあ、すべてはセキュリティフレームワークを通じて行われるんだけど-"

    # say L349 sis
    old "BORING! just tell me how I can see the money. "
    new "BORING！ お金を見られる方法だけ教えて。"

    # say L350 pla
    old "Hmm ok. You need to go to the sales window, here you will see the customer info, products and money."
    new "うーん、わかった。販売ウィンドウに行って、そこで顧客情報や商品、お金が見られるぞ。"

    # say L351 sis
    old "Wujuu! If you behave I think, there is an option to make you my partner."
    new "ワッショイ！素直にいれば、パートナーにしてあげるかもよ。"

    # say L352 pla
    old "Yeah right. Well I think that's all for today, need anything else?"
    new "そうだな。じゃあ今日の分はこれで終わりだけど、他に何か必要なことはある？"

    # say L353 sis
    old "No, if I need something I'll reach out to you... You better not doing something weird... "
    new "いいえ、必要なら連絡するから……変なことしちゃダメよ……"

    # say L355 sis
    old "Nevermind... I will be busy, doing my work, see you later... "
    new "気にしないで… 私は仕事で忙しいから、またね…"

    # say L356 pla
    old "Hmm, Ok... (You are welcome, by the way... )"
    new "うん、わかった…（ちなみに、 Welcome だよ…）"

    # say L374 pla
    old "(Oh shit! My [sisrel] is taking a shower... )"
    new "（しまった！[sisrel] がシャワーを浴びてる…）"

    # say L375 pla
    old "(She's got such an amazing body... )"
    new "彼女のかわりない身体だな…"

    # say L387 pla
    old "(I should leave... I don't want to make her think I'm perverted.)"
    new "俺は出て行こう… 女の子に変なヤツと思われたくないんだ。"

    # say L391 pla
    old "(I should leave... I don't want to make her think I'm a pervert.)"
    new "俺、行こう… 好きな子に変なヤツと思われたくなくて。"

    # say L396 sis
    old "What the fuck! What are you doing, [pla]?"
    new "何してんの、[pla]！"

    # say L397 pla
    old "Sorry, I was-."
    new "ごめん、俺が-。"

    # say L398 sis
    old "COME IN... AND CLOSE THE DOOR."
    new "入ってきて、ドア閉めて。"

    # say L399 pla
    old "(Shit!)"
    new "くそっ！"

    # say L405 pla
    old "Look I... "
    new "見ろ、俺が..."

    # say L406 sis
    old "Shut up... You just saw me... Now it's my turn."
    new "黙って... あなた刚看到的... 今度は私の番よ。"

    # say L407 pla
    old "(Gulp) What? What do you mean?"
    new "（ゴクリ）何？　どういう意味だ？"

    # say L408 sis
    old "I mean, show me what you got in those shorts."
    new "短パンの中を見せてくれよ。"

    # say L409 pla
    old "Whaat?... "
    new "何だよ…"

    # say L410 sis
    old "Well, if you don't show me, I'm going to scream and tell [mo1] and [mo2] you were peeping on me."
    new "もし見せてくれないなら、叫んで[mo1]と[mo2]にあなたが覗いていたって言うわ。"

    # say L411 pla
    old "B- but... Why do you want to see me naked?"
    new "でも……なんで裸を見たいんだ？"

    # say L412 sis
    old "Is justice for a pervert... And I'm just curious about what I saw in the garage last time... So show me... Now!"
    new "変態の報いだよ… それに先日ガレージで見たのが気になってさ… だから見せて… 今すぐ！"

    # say L413 pla
    old "Alright, alright... "
    new "分かった、分かった..."

    # say L421 sis
    old "(Mmm... It's bigger than some pornstars I use to see.)"
    new "（ん……これ、昔見ていたアダルトビデオの男の子より大きいの。）"

    # say L422 sis
    old "And... Why were you so excited at the garage?"
    new "そして…車庫でそんなに興奮してたのはなぜ？"

    # say L423 pla
    old "Hmm... I- I don't know what you're talking about."
    new "Hmm... 俺、何のことかわからないな。"

    # say L424 sis
    old "Ugh. Ok, nevermind... I should go... "
    new "うーん、いいわ、気にしないで… 行くわ…"

    # say L428 pla
    old "Wait... That's my? "
    new "待て……それが俺の？"

    # say L429 sis
    old "Bye... "
    new "さよなら..."

    # say L436 pla
    old "What the hell! She took my clothes!"
    new "何だよ！服を取っちゃったぞ！"

    # say L437 pla
    old "Oh shit! What do I do now?"
    new "オッシャイ！今からどうすりゃいいんだ？"

    # say L438 pla
    old "I gotta get to my room really fast!"
    new "早く部屋に戻らなきゃ！"

    # say L443 pla
    old "Ok I don't see anyone nearby, now is my chance... "
    new "よし、近くに誰もいない。今がチャンスだ…"

    # say L453 mo2
    old "WHAT THE FUCK?!"
    new "何てことしてんの？！"

    # say L454 pla
    old "(... Oh god..) Sorry... "
    new "（ああ神よ...）ごめん..."

    # say L465 mo2
    old "YOU ARE A FUCKING PERVERT AND AN EXHIBITIONIST!!!"
    new "あなたは本当に変態で露出狂ですね！"

    # say L466 pla
    old "(Oh shit, oh shit. I almost died! Fuck!)"
    new "オッシャイ、オッシャイ。死にかけたぜ！クソ！"

    # say L467 pla
    old "It's probably best to stay here until tomorrow... "
    new "明日までここにいるのがいいだろうな…"

    # say L490 sis
    old "Well, I am kind of ok."
    new "まあ、ちょっとは大丈夫だけど。"

    # say L491 pla
    old "Hmm... Is everything alright?"
    new "ん……大丈夫じゃないの？"

    # say L492 sis
    old "Not really, the website is not working and I don't know what's wrong."
    new "全然ダメ、サイトが動かないの。何が悪いのかわからないの。"

    # say L493 pla
    old "Is not working? You wanna check it together to see what the problem could be?"
    new "動かないって？一緒に見てみよう、何が問題なのか。"

    # say L494 sis
    old "Oh please, because I feel a bit down, you know."
    new "お願い、ちょっと落ち込んどるんだもん。"

    # say L495 pla
    old "Don't worry, we can find a solution."
    new "心配しなくていい、解決策を見つけるよ。"

    # say L502 pla
    old "I can see that your webpage has been visited several times, so there are actually people looking at it."
    new "ウェブページが何度も見られてるから、実際には見ている人がいるみたいだね。"

    # say L503 sis
    old "I think the clothes are nice, but do you think they're maybe too expensive?"
    new "服はいいと思うけど、ちょっと高すぎるかな？"

    # say L504 pla
    old "Hmmm, I think you have a good variety of prices, so I don't think that is the problem."
    new "うーん、価格帯はいいと思うよ、だからそれが問題じゃないと思うな。"

    # say L505 sis
    old "Could it be that the products aren't that nice?"
    new "商品自体がそれほど良くないのかな？"

    # say L506 pla
    old "I actually like them, I've seen you wearing some of the clothes, they look cool."
    new "実際いいよ、君が着てるのを見たことがあるけど、かっこいいじゃん。"

    # say L507 sis
    old "Is the website running correctly?"
    new "サイトはちゃんと動いてるの？"

    # say L508 pla
    old "What do you mean? Sure! it works, I made it myself."
    new "何言ってるの？もちろん動くよ、自分で作ったんだから。"

    # say L509 sis
    old "Let's try to make a purchase to see if the website is ok."
    new "購入を試してみましょう、サイトが大丈夫かどうか確認できるから。"

    # say L510 pla
    old "I did everything carefully... Hmm, but we can double check."
    new "ちゃんと全部やってるけど…でも、確認してみるのもいいかもね。"

    # say L511 sis
    old "Perfect, select that shirt, then those pants, add them to the shopping cart."
    new "完璧、そのシャツを選んで、それからあのパンツも、カートに入れて。"

    # say L512 sis
    old "What's next?"
    new "次は？"

    # say L513 pla
    old "The delivery info"
    new "配送情報だね"

    # say L514 sis
    old "Ok, let's use ours."
    new "じゃあ、私たちのを使おう。"

    # say L515 pla
    old "Oh, payment options, let's put the card in."
    new "支払い方法、カードを入れておこう。"

    # say L517 pla
    old "Finally, summary cart."
    new "ついに、カートのサマリー。"

    # say L518 pla
    old "Order went through successfully, the website works perfectly. That's not the problem."
    new "注文はちゃんと通ったよ、サイト自体は問題ないんだ。それが問題じゃないってことだ。"

    # say L519 sis
    old "Cancel the order."
    new "注文をキャンセルして"

    # say L520 sis
    old "I don't get it... What am I doing wrong?"
    new "分かんないの…何を間違ってるの？"

    # say L521 sis
    old "What do other people do to sell?"
    new "他の人はどうやって売るの？"

    # say L522 pla
    old "Huh! that's brilliant."
    new "へえ！それ良いじゃん。"

    # say L523 sis
    old "Really? Wait... What's brilliant?"
    new "本当に？待って…何が素晴らしいの？"

    # say L524 pla
    old "A very good idea could be to check how other people do it."
    new "他の人がどうやってるか見てみるのもいい案だな。"

    # say L525 pla
    old "Let's compare ours with other websites, that way we can take some ideas too."
    new "他のサイトと比べてみよう、そうすればアイデアも手に入るだろう。"

    # say L526 pla
    old "Let's check a big one like... Hmm I don't know, Calvin Klown."
    new "大きなサイトで……うーん、カルビン・クラウンとか見てみよう。"

    # say L527 sis
    old "Yeah, that could work."
    new "うん、それも良いわ。"

    # say L528 pla
    old "They are really good, this looks amazing."
    new "これ、めちゃくちゃいいな。見てみ。"

    # say L529 sis
    old "Yeah, it's very depressing."
    new "うん、すごく depressive だね。"

    # say L531 sis
    old "Just look! They are just so gorgeous, mine doesn't look even close."
    new "見てよ！彼らは本当に Gorgeous で、私のものとは比べものにならないわ。"

    # say L532 pla
    old "Well, it's not fair if you compare yourself with them, this is a worldwide fashion business!"
    new "まあ、自分を彼らと比べるのはフェアじゃないよ。これは世界中で行われてるファッションビジネスだぜ。"

    # say L533 pla
    old "Consider, that they invest millions on advertisement, Internet, TV characters, even music videos and artists."
    new "考えてみろ、広告やインターネット、テレビキャラクター、さらにはミュージックビデオやアーティストにまで何千万も投資してるんだ。"

    # say L534 sis
    old "Yeah, that's very impressive."
    new "うん、それはすごいね。"

    # say L535 pla
    old "Alright, that was enough Calvin Klown for one day."
    new "よし、今日の分はこれで十分だな、Calvin Klownも。"

    # say L541 pla
    old "Hmm... I have something in mind."
    new "ん……何か思いついた。"

    # say L542 pla
    old "Well, we could, and I am not sure... But try some options to show the clothes like they do."
    new "まあ、できるけど、ちょっと迷ってるんだ... でも服をモデルが着て写真を撮るような方法を試してみるのはどう？"

    # say L543 sis
    old "You mean the way they use models and take the pics?"
    new "モデルを使って写真を撮るって意味？"

    # say L544 pla
    old "Yes, it could look more... Interesting? I guess so?"
    new "そうだな、もっと... 興味深い感じになるのかな？多分そうだろうな。"

    # say L545 pla
    old "We can give it a try, doing the pics instead of using the ones you're using."
    new "写真を撮るのを試してみるのもいいかも、今使ってる画像とは違う感じになるかもね。"

    # say L546 sis
    old "Hmm but we'll need a model and we can't afford that... "
    new "うーん、でもモデルが必要になるし、お金がないから困るな……"

    # say L547 sis
    old "Wait a minute... I could be the model, can't I?"
    new "ちょっと待って… 私がモデルになったらどう？"

    # say L548 pla
    old "I considered that an option at first, but I saw there are some clothes where you would be almost naked."
    new "最初はその手も考えたけど、いくつかの衣装はほとんど裸同然だからな。"

    # say L549 pla
    old "I mean some clothes are 'sexy' and a lot of people would watch them... Are you sure you are ok with that?"
    new "つまり、いくつかの衣装は『セクシー』で、たくさんの人が見るだろうな… それでも大丈夫なのか？"

    # say L550 sis
    old "Actually, I like the idea... I think it's kind of exciting!"
    new "実はそのアイデア気に入ってるの… 楽しそうじゃない？"

    # say L551 pla
    old "Well, if you'd like we would have covered an important part of the problem and if you are the model that would be very useful to have a defined market image."
    new "もし君がいいって言うなら、問題の重要な部分は解決できるし、君がモデルなら市場のイメージを明確にするのに役立つよ。"

    # say L552 sis
    old "Ok, so, what do we need?"
    new "じゃあ、何が必要なの？"

    # say L553 pla
    old "We will for sure need a photographer."
    new "写真撮影は絶対必要だな。"

    # say L554 sis
    old "Wait a minute! A photographer could be really expensive."
    new "ちょっと待って！ 写真家は結構高そうよ。"

    # say L555 sis
    old "Why don't you take the pics instead?"
    new "私が写真を撮るのどうですか？"

    # say L556 pla
    old "Technically, I could but I have no camera."
    new "技術的にはできるけどカメラを持ってないんだ。"

    # say L557 sis
    old "I think I can handle that. But can you use a professional camera?"
    new "私がやれると思うけど、プロ用のカメラは使える？"

    # say L558 sis
    old "What I'm asking for of course a nerd knows."
    new "もちろん、オタクならそんなこと知ってるわ。"

    # say L560 sis
    old "That's great, so if you take the pictures, we can save a little without asking for the help of a photographer."
    new "それはいいわ、写真を撮ってくれれば、カメラマンに頼む手間が省けて少し節約できるから。"

    # say L561 sis
    old "So, I will use all my money to buy a lot of clothes, so we can take tons of pics."
    new "じゃあ、私が全部のお金を服をたくさん買うのに使うから、たくさんの写真を撮れるわ。"

    # say L562 pla
    old "Wait what? No, no, no, calm down! It isn't convenient to use all the money you have."
    new "待て待て、落ち着け！全部のお金を使うのは Convenientじゃないよ。"

    # say L563 sis
    old "But we will need the clothes for the pics... "
    new "でも写真のために服は必要になるよね…"

    # say L564 pla
    old "Yes, we do, however, we have to do some baby steps to check if it works."
    new "そうだ、でも一歩ずつ進めて効果を見てみよう。"

    # say L565 pla
    old "If we can see some progress then you can invest more to see an improvement."
    new "進展が見れそうなら、もっと投資して改善を図れるよ。"

    # say L566 sis
    old "Hmm... Yeah, I think you're right."
    new "うーん……そうかもね。"

    # say L567 sis
    old "Ok, I need time now, to get all of this ready. thanks for your help, I really appreciate it."
    new "ちょっと時間が必要だよ、全部準備するから。ありがとう、本当に助かったわ。"

    # say L568 sis
    old "I will let you know as soon as I have everything ready."
    new "準備が整ったらすぐに知らせるね。"

    # say L569 pla
    old "Cool, I'll see you then."
    new "分かった、その時まで待ってろ。"

    # say L589 sis
    old "[pla], where were you? I've been looking for you."
    new "[pla]、どこにいたの？探してたのよ。"

    # say L590 sis
    old "Let's go, the delivery has just arrived."
    new "行こう、配達が刚好ちよく来たところだよ。"

    # say L591 sis
    old "You can't imagine how excited I am, I almost jumped from the window when I saw the driver."
    new "あなたが想像できないほど興奮してるの、運転手を見たとき窓から飛び出しちゃいそうだったよ。"

    # say L592 pla
    old "I can see that, you're all anxious to start."
    new "分かってる、早く始めるのが待ちきれないんだね。"

    # say L593 sis
    old "Yes, we can't waste time, I have been waiting for this, the website needs this."
    new "はい、時間は無駄にできないわ、これのためにずっと待ってたの、サイトもこれが必要なの。"

    # say L594 sis
    old "Let's go to my bedroom."
    new "私の寝室に行こう。"

    # say L602 sis
    old "Give me a moment, I don't know where to start. "
    new "ちょっと待って、どこから始めればいいのかわからないの。"

    # say L603 pla
    old "Ok, just calm down a bit."
    new "大丈夫、ちょっと落ち着いて。"

    # say L613 sis
    old "I'm pretty impatient we can start right away."
    new "急いでるから今すぐ始めていいわよ。"

    # say L614 sis
    old "This is for you."
    new "これはあなたのために用意したのよ。"

    # say L619 pla
    old "Wow, this is huge, looks like a very good camera."
    new "すげえ、これ大きくて良さそうなカメラだな。"

    # say L620 sis
    old "I am sure you will figure out how it works."
    new "きっとすぐ使い方わかるわよ。"

    # say L621 sis
    old "Bear with me a moment while I get ready. You should try the cam in the meantime."
    new "ちょっと待ってて、準備するから。その間カメラ試してみて。"

    # say L622 pla
    old "Ok, Sure, I will start checking (It doesn't look so hard.)"
    new "分かった、試してみるよ（そんなに難しそうじゃないな）。"

    # say L628 pla
    old "(I think auto mode should work just fine to start, I'll give a further review later.)"
    new "自動モードでまず試してみるよ、後で詳しくレビューするさ。"

    # say L629 pla
    old "(Let's check... She bought really nice clothes.)"
    new "（チェックしてみよう……いい服を買ったな。）"

    # say L636 pla
    old "(This is very short and tiny. How does she fit in?)"
    new "これはすごく短くて小さいな。どうやって着てるんだ？"

    # say L642 pla
    old "(This is a great color for a pic, I think I have a couple of ideas.)"
    new "この色は写真にとっていいね、いくつかアイデアが浮かんだな。"

    # say L648 pla
    old "(What is this?)"
    new "（これは何だ？）"

    # say L651 pla
    old "(Ohh... This is a...)"
    new "オッ……これは……"

    # say L654 sis
    old "Wow,wow, wow. GET AWAY FROM MY STUFF... You little snoopy."
    new "わお、わお、わお。私のものから離れて… 小さなスヌーピー。"

    # say L660 sis
    old "Where did you get it?"
    new "どこで手に入れたの？"

    # say L661 sis
    old "I mean why are you looking through my stuff?"
    new "何で私のものを勝手に見ているの？"

    # say L662 pla
    old " I... I- I just... "
    new "俺... 俺、 juste..."

    # say L663 sis
    old " I... I... I... What?"
    new "あたし…あたし…あたし…何？"

    # say L664 pla
    old "I was checking the clothes you bought, and it was just there."
    new "俺が君が買った服をチェックしてたら、そこにあったんだ。"

    # say L665 pla
    old "I was not snooping, just checking the clothes and that appeared out nowhere."
    new "俺はただ服を見ていただけだよ、そしたら突然そこに現れたんだ。"

    # say L666 sis
    old "THERE'S NO TIME TO WASTE, WE CAME TO WORK, LET'S GET STARTED."
    new "時間ないわ、来たのは仕事のためだからさっさと始めるわ。"

    # say L667 pla
    old "You're right, I'm sorry."
    new "分かった、ごめん。"

    # say L668 sis
    old "Alright, just get everything ready while I change."
    new "分かった、私が着替える間に全部準備しておいて。"

    # say L676 sis
    old "Well... How do I look?"
    new "WELL... どう見えた？"

    # say L677 pla
    old "Gulp... Y-you look ho- nice, you look pretty nice."
    new "うーん… よ、よく見えるね、めっちゃカッコいい。"

    # say L678 sis
    old "Let's start, we have already wasted enough."
    new "始めるわ、もう十分浪費したし。"

    # say L693 pla
    old "Ok, let me try... I will stay here to catch you better, stay right there."
    new "分かった、試してみる… 俺がここにいて、君を捕まえやすいように、そのままそこにいて。"

    # say L700 pla
    old "(Oh shit.. It's not as easy as I thought...)"
    new "あぁ…思ってたより難しいな…"

    # say L702 pla
    old "Ehh... Just give me a second... I- I'm finding your best... Angle."
    new "ええ……ちょっと待って……俺は君の最高の……角度を見つけてるんだ。"

    # say L703 pla
    old "(Shit! I must take the picture when it's fully focused...)"
    new "くそっ！完全にピントが合った瞬間に撮らなきゃならないんだ…"

    # say L741 pla
    old "Ehmm... Fine, we could check it at the end of the session..."
    new "ええと……いいな、セッションの終わりに確認すればいいさ。"

    # say L742 sis
    old "You're right, sorry I'm just a bit anxious."
    new "うん、ごめん。ちょっと緊張してるの。"

    # say L743 pla
    old "Don't worry, relax a bit to look more natural."
    new "心配しなくていい、リラックスして自然な感じを出そう。"

    # say L744 sis
    old "Okay, so for the next photo what should I do?"
    new "次のお写真は、どんなポーズすればいいかな？"

    # say L745 pla
    old "Hmm, I think we should take a picture from behind to show the back of the dress..."
    new "うーん、後ろからドレスの背中を映した写真を撮るかね…"

    # say L746 sis
    old "Oh right! So what position should I take?"
    new "なるほど！じゃあ、どんなポーズをすればいいの？"

    # say L747 pla
    old "Hmm, I think we could use the bed, what about if you lean on the edge of the bed with you back pointing to me in a... Sexy way."
    new "ベッドを使ってみようか。君がベッドの端に寄りかかって、背中を向けてセクシーなポーズを取ってくれたらいいな。"

    # say L748 sis
    old "Alright ..."
    new "分かった、そうするね。"

    # say L758 sis
    old "So, do I look good like this?"
    new "じゃあ、この姿でいいかしら？"

    # say L759 pla
    old "(Wow) Yeah... You look, great, let me focus on the camera ..."
    new "うわ、そうか……君、めちゃくちゃいいな、カメラに集中させてくれ……"

    # say L760 pla
    old "(Oh shit, I'm getting hard. She looks really hot.)"
    new "（しまった、硬くなっちゃった。彼女、めちゃくちゃsexyだな。）"

    # say L792 pla
    old "(I hope she doesn't notice my hardon...)"
    new "（彼女に気づかれないうちに済ませないと…）"

    # say L795 pla
    old "Ok... I- I think that's enough, for now."
    new "よし… これで十分だろ、今のところ。"

    # say L796 sis
    old "What? Just two pics? No, I actually have an idea for a next photo..."
    new "何？たった2枚？でも、次の写真のアイデアがあるんだよ…"

    # say L797 pla
    old "R- really? With a front and backside photo of the dress is not... Enough?"
    new "本当に？ドレスの前と後ろの写真じゃ... 十分じゃないの？"

    # say L798 sis
    old "(Why is he acting so strange.) No, let's take one last photo, ok?"
    new "うーん、最後にもう一枚撮ろうよ、どう？"

    # say L800 sis
    old "Let me try something I saw."
    new "ちょっと見せて、私が見た方法で試してみるから。"

    # say L813 sis
    old "(Is he ok?, he's walking different) Do you think this looks good?"
    new "（大丈夫？歩き方が変）これ、いい感じに見える？"

    # say L814 pla
    old "(Shit... I'm so hard right now...)"
    new "くそ… 今めちゃくちゃ硬いんだが…"

    # say L815 pla
    old "Y- yes, you look great..."
    new "Ｙ－うん、君はすごくいいよ…"

    # say L816 sis
    old "(What he gots there? Ohh! He has a boner. How could I not realize it before?)"
    new "何それ？あ、彼、立ってるの。気づかなかったわ…"

    # say L817 sis
    old "(Well, I need to let him work, he is very focused, and don't want to make him feel uncomfortable.)"
    new "（まあ、彼が集中してるんだから、邪魔しちゃだめよね。気を遣わせたくはないし。）"

    # say L851 sis
    old "Alright, I think that's enough for now..."
    new "よし、これでいいかな…"

    # say L852 pla
    old "Oh, great, so it's done then see you later..."
    new "オーケー、じゃあこれで終わりか。またね。"

    # say L856 sis
    old "Wait a minute..."
    new "ちょっと待って…"

    # say L858 sis
    old "You said we could check the photos at the end of the session..."
    new "あなたが言ってたよね、セッションの終わりに写真を見られるって..."

    # say L860 pla
    old "You're right..."
    new "君が言う通りだ…"

    # say L863 pla
    old "Ok... L- let's see the photos..."
    new "いいか… リ、写真見せるか..."

    # menu L883 
    old "Watch again"
    new "またか"

    # menu L887 
    old "Not Again"
    new "またか"

    # say L900 sis
    old "These photos are out of focus! They look really bad..."
    new "この写真、ボケてて全然使い物にならないよ..."

    # say L901 pla
    old "I am sorry, I think I need to practice more."
    new "ごめん、もっと練習が必要みたいだな。"

    # say L902 sis
    old "Oh no, this is not good, I wanted to have this material for the website really soon."
    new "あら、これは困ったわ、ウェブサイトに早く使いたかったのにな。"

    # say L903 pla
    old "I can make it better, just need some time."
    new "もっと上手くできる、ただ時間が少々必要だ。"

    # say L904 sis
    old "So you need time but a moment ago you were snooping through my personal stuff."
    new "時間が必要だって？でもさっきは私の個人的なものを見てたじゃないの。"

    # say L905 sis
    old "I can't believe it."
    new "信じられない。"

    # say L906 pla
    old "I'm sorry, I will practice more."
    new "ごめん、もっと練習するよ。"

    # say L907 sis
    old "All right, take the cam with you, and next time you better do it right."
    new "よし、カメラを持って行け。次はちゃんとやってくれないとね。"

    # say L931 sis
    old "Well, I am not surprised."
    new "まあ、驚かないね。"

    # say L932 pla
    old "Why, don't you like them?"
    new "なんで、好きじゃないのか？"

    # say L933 sis
    old "Yep, I look gorgeous, I mean what could I expect from the 'nerd'."
    new "うん、私は gorgeous だし、‘nerd’ から何を期待するの？"

    # say L934 pla
    old "I just wanted to help you."
    new "ただ君を手伝うだけだったのに。"

    # say L935 sis
    old "You did well nerd."
    new "よくやったね、 nerd。"

    # say L936 sis
    old "I didn't mean they are not good, don't take me the wrong way, I meant I knew it."
    new "悪 intentions つ もりじゃなかったの、誤解しないで、私が知っていたって意味よ。"

    # say L937 sis
    old "I appreciated it."
    new "感謝してるよ。"

    # say L938 sis
    old "Time is money, let me upload this material, I need to sell."
    new "時間はお金よ、この素材をアップロードして売らないとね。"

    # say L939 pla
    old "Ok, I guess I'm leaving then."
    new "分かった、じゃあ帰るよ。"

    # say L971 sis
    old "Ready to repeat the last photoshoot?"
    new "前回の撮影を繰り返すの？"

    # say L972 pla
    old "Yes, I practiced and I know I'll do better now..."
    new "はい、練習したから今度はうまくいくはずだよ、姉さん。"

    # say L973 sis
    old "You better do it right this time... Don't waste more time. Get ready while I get changed."
    new "今回はちゃんとやってね… 時間を無駄にしないで。私が着替える間に準備して。"

    # say L978 sis
    old "Oh, by the way, do you need some help before we start?"
    new "始める前に手伝ってあげる？"

    # say L984 pla
    old "Well... Ok."
    new "まあ... 分かったよ。"

    # say L985 sis
    old "Hahaha, I'm going to make you cum fast..."
    new "ははは、早くイかせちゃうよ…"

    # say L995 sis
    old "I'm gonna get changed. You get the camera and stay ready."
    new "着替えるから、カメラを用意して待ってて。"

    # say L1000 pla
    old "It's ok, I think I will be fine."
    new "大丈夫、多分大丈夫だ。"

    # say L1002 pla
    old "Yes, don't worry. I appreciate your help."
    new "大丈夫、心配しないで。君の手伝いが嬉しいよ。"

    # say L1003 sis
    old "Perfect! then let's go, we have so much to do!"
    new "完璧！じゃあ行こう、やることが山ほどあるよ！"

    # say L1004 sis
    old "I am excited, I just want to upload the new pics to get more sales!"
    new "わくわくしてる、新しい写真をアップロードしてもっと売上を上げたい！"

    # say L1033 sis
    old "Alright, let's start! "
    new "よし、始めましょう！"

    # say L1059 sis
    old "I already know all the positions. You just focus on taking good pictures this time..."
    new "もう全部のポーズは知ってるから、今回はいい写真を撮ることだけに集中してね。"

    # say L1112 pla
    old "Ehmm... Done..."
    new "ええっと… 撮り終わったよ…"

    # say L1113 sis
    old "Alright, next one. You know what to do."
    new "次ね、何すればいいのわかってるでしょ。"

    # say L1169 sis
    old "Very well, last one. I hope all the photos are perfect, right?"
    new "よし、最後の一枚ね。写真全部、完璧なはずよね。"

    # say L1170 pla
    old "Yes, don't worry..."
    new "心配しないで、大丈夫だよ。"

    # say L1223 sis
    old "Ok, let's see the new photos!"
    new "じゃあ、新しい写真見せて！"

    # say L1281 sis
    old "Really [pla]?! Again out of focus... I can't believe it..."
    new "本当に[pla]？またボケてるの…信じられない…"

    # say L1282 pla
    old "I-it wasn't my fault, I really tried to improve..."
    new "ほんとによく頑張ったけど、俺のせいじゃないよ…"

    # say L1283 sis
    old "Well, it wasn't enough... And you are making me lose money!"
    new "全然足りてないわ…それに、私に損失をもたらしてるのよ！"

    # say L1284 sis
    old "Get out... Come back when you learn to use that damn camera..."
    new "出ていって... そのカメラを使いこなせるようになったら戻ってきてね..."

    # say L1317 sis
    old "Well, finally! These photos are great."
    new "やっとだわ！これらの写真、素晴らしいわ。"

    # say L1318 sis
    old "I hope next time we don't have to do the photoshoot twice again..."
    new "次は写真撮影を二度と繰り返さないでほしいな..."

    # say L1319 pla
    old "Don't worry..."
    new "心配するな、次は上手くいくさ。"

    # say L1320 sis
    old "Hmm... Time is money, let me upload this material, I need to sell."
    new "時間はお金だから、この素材をアップロードして売らないと。"

    # say L1321 pla
    old "Ok, leaving now."
    new "分かった、今行く。"

    # say L1395 pla
    old "(Holy shit! If I get caught she'll kill me!)"
    new "クソッ！見つかったら俺は殺されるぞ！"

    # say L1398 sis
    old "Hey, big boy. Do you need some help?"
    new "HEY、お兄さん。手伝う？"

    # say L1407 pla
    old "Oh, god. Thanks. If she would have caught me, I'd be a goner."
    new "ああ、感謝。助かる。見つかってたら俺は終わりだったよ。"

    # say L1408 sis
    old "It's ok! you are saved now, just relax."
    new "大丈夫！今なら助かったから、リラックスして。"

    # say L1409 pla
    old "Yes, I appreciate it, you saved my ass."
    new "ありがとう、本当に助かった。"

    # say L1410 sis
    old "I feel thankful too, last time you were great with the pics."
    new "私も感謝してるの、前は写真撮影で大活躍だったね。"

    # say L1411 sis
    old "Haven't given you a proper reward."
    new "まだちゃんとしたお礼をしてないね。"

    # say L1412 pla
    old "Wh- What... Do you mean?"
    new "何… どういうこと？"

    # say L1413 sis
    old "What I mean is... Take off those pants and show me that dick."
    new "私が言いたいのは… そのズボンを脱いで、チンポ見せてよ。"

    # say L1414 pla
    old "Oh, come on, [sis]..."
    new "おい、ちょっと待ってよ、[sis]..."

    # say L1415 sis
    old "Just do it... Your [mo2rel] is close. And you don't want me to call her..."
    new "JUST DO IT... あなたの[mo2rel]は近いんだから。そして、彼女を呼ぶのは避けたいよね..."

    # say L1416 pla
    old "Really?… Ugh... Ok."
    new "本当に？…うーん… 分かった。"

    # say L1423 sis
    old "I knew it! It's fucking huge..."
    new "分かってたわ！ ほんとデカいね…"

    # say L1425 sis
    old "Just let me turn on the lights to get a better look at it."
    new "明かりをつけさせて、もっとよく見よう。"

    # say L1444 sis
    old "Hey buddy, guess what?"
    new "ねえ、見てみて、これって？"

    # say L1446 sis
    old "Your idea was a big noise, it pulled off selling!"
    new "あなたのアイデア、大ヒットだったよ。売れたんだ！"

    # say L1448 sis
    old "Yep, come to my bedroom I need your help with something..."
    new "ええ、私の寝室に来なさい、何か手伝ってほしいことがあるの..."

    # say L1455 sis
    old "Well, besides the messages I have now. We actually got a new customer, she was pretty interested in the last pics we did, remember?"
    new "まあ、それ以外にもね。新しいお客様が来たの、最後に撮った写真にすごく興味があったわ、覚えてる？"

    # say L1456 pla
    old "Yeah! I know which ones."
    new "そうだ！どの写真のことかわかるよ。"

    # say L1457 sis
    old "Anyway, I need your help now, we have several customers' messages."
    new "でも、今すぐあなたの手伝いが必要なの。何人かのお客様からメッセージが来てるの。"

    # say L1458 sis
    old "I'll need to answer them as some of them are very potential purchases."
    new "いくつかはかなり有望な購入になりそうだから、返事を書かなきゃ。"

    # say L1459 sis
    old "Need you to take one package to a customer."
    new "お客様に一つの荷物を持っていってほしいの。"

    # say L1460 pla
    old "You mean today?"
    new "今日って？"

    # say L1461 sis
    old "Oh no, I mean right now."
    new "今すぐって意味よ。"

    # say L1462 pla
    old "I am kind of busy now."
    new "今ちょっと忙しいんだ。"

    # say L1463 sis
    old "That's not a business wise decision."
    new "それはビジネス的に賢い選択じゃないわ。"

    # say L1465 sis
    old "You know this is not actually a favor, it's included in the money you are expecting."
    new "知ってるでしょ、これは実際にお願い事じゃなくて、あなたが期待してるお金に含まれてるのよ。"

    # say L1466 pla
    old "Hmm... I know, but I can't do it right away... We never discussed these kind of things."
    new "うーん……分かってるけど、すぐにってわけにはいかないんだ……こんなこと、話し合ったことなかったし。"

    # say L1467 sis
    old "Yes, I know but we have to be committed to make this business grow."
    new "うん、それは分かってるけど、このビジネスを成長させるためにはお互い本気にならないとね。"

    # say L1468 pla
    old "Come on, almost everybody knows about me here in town, it's not comfortable."
    new "Come on, 町ではほとんどみんなが俺のこと知ってるんだ、落ち着かないよ。"

    # say L1469 pla
    old "I don't want to be embarrassed delivering sexy panties to a classmate's mother."
    new "クラスメイトの母親にセクシーなパンティを届けるのは恥ずかしいんだよ。"

    # say L1470 sis
    old "Why would you be embarrassed, it isn't like you're the one wearing it."
    new "なぜ恥ずかしがるの、あなたが着けるわけじゃないんだから。"

    # say L1471 sis
    old "Here is the thing, do you still wanna be helped like the other night?"
    new "ここが大事なところよ、先日のように手伝ってほしいの？"

    # say L1472 sis
    old "So, think about the 'business', if you help me I'll help you. I think my help is amazing, don't you like it?"
    new "じゃあ、この‘ビジネス’について考えてみて。あなたが手伝ってくれたら私も手伝うわ。私の手伝いは最高だと思うの、気に入ってるよね？"

    # say L1473 pla
    old "Hmm... Fine, but don't take me wrong, It's for business!"
    new "うーん… いいけど、誤解しないでね、これはビジネスのためだよ。"

    # say L1474 sis
    old "Hehehe, yeah sure! The business..."
    new "へへへ、そうね！ビジネスのことね…"

    # say L1475 sis
    old "You will find all the info you need on the package."
    new "必要な情報は全部パッケージに書いてあるわよ。"

    # say L1477 pla
    old "Hmm alright..."
    new "うん、そうか…"

    # say L1482 pla
    old "I think it's here... I hope it's not someone I know."
    new "ここにあると思う……知ってる人じゃないと良いけど。"

    # say L1485 jon
    old "Yes, sir, how can I help you?"
    new "はい、何をお手伝いしましょうか？"

    # say L1486 pla
    old "(For real? Is she wearing this?)"
    new "マジで？これ着てるの？"

    # say L1487 pla
    old "Hmmm, I think this package is for you."
    new "うーん、この荷物は君へのものじゃないかな。"

    # say L1488 jon
    old "(Wow! I know this young man, I met him in church.) "
    new "わあ！この若者のことを知ってる、教会で会ったの。"

    # say L1489 jon
    old "For me?"
    new "私に？"

    # say L1490 pla
    old "Yes, we had your order record, let me confirm, it is the Ultra short skirt, marvelous night surprise dress."
    new "はい、君の注文記録があったので確認したんだ、ウルトラミニスカート、夜の驚きドレスだね。"

    # say L1491 jon
    old "... What? This must be a mistake."
    new "... え？これ間違いじゃないの？"

    # say L1492 pla
    old "(Of course is yours, who else could be, has your name on it.)"
    new "もちろん君のものさ、他の誰がいるっていうんだ、名前も書いてあるし。"

    # say L1493 pla
    old "It could be, however, you're Mrs. Jones, right?"
    new "でも、君はジョーンズ夫人だよな？"

    # say L1494 jon
    old "Yes, that's me..."
    new "はい、それが私です..."

    # say L1495 pla
    old "Well, we have all your information here, and the payment was done online... So..."
    new "じゃあ、あなたの情報は全部揃ってて、支払いもオンラインで済んだんで……"

    # say L1496 jon
    old "(Hmm... I need to make up something, he knows me...)"
    new "うーん…何か言い訳を考えないと、彼は私を知っているから…"

    # say L1497 jon
    old "Oh! I remembered now, this is for my daughter, I forgot completely, hehehe."
    new "あっ！思い出しました、これは娘のために買ったもので、すっかり忘れていました、へへへ。"

    # say L1498 pla
    old "Hmm... It's ok, I understand, hope you daughter likes it."
    new "うーん……大丈夫だよ、分かってるよ。君の娘が気に入ってくれることを願ってる。"

    # say L1503 jon
    old "Ok... Thank you! Bye bye."
    new "はい、ありがとう！さようなら。"

    # say L1511 pla
    old "It's done!"
    new "終わったぞ！"

    # say L1512 sis
    old "Awesome, What happened? I wanna know everything."
    new "すごい、何があったの？全部教えてよ。"

    # say L1513 pla
    old "It was ok, gave her the package, that was it."
    new "まあまあだった、パッケージ渡しただけさ。"

    # say L1514 sis
    old "Was she excited about the purchase?"
    new "彼女はその購入で興奮してた？"

    # say L1515 pla
    old "Couldn't tell you, she was kind of reserved."
    new "分かんないよ、彼女はちょっと内気だったしな。"

    # say L1516 sis
    old "Did you see if she liked it?"
    new "彼女が気に入ったかどうか見ただろ？"

    # say L1517 pla
    old "No, I just gave her the package and she said thank you."
    new "いや、ただ荷物を渡しただけで、「ありがとう」と言われただけだ。"

    # say L1518 sis
    old "I need you to pay careful attention to those details in future deliveries. "
    new "今後の配達の際は、そんな細かいところにも気をつけてよね。"

    # say L1519 pla
    old "What do you mean by future deliveries?"
    new "Future deliveriesって何のこと？"

    # say L1520 sis
    old "I have more merchandise coming so get prepare for another photoshoot session. "
    new "今後も商品が入るので、また撮影の準備をしておいて。"

    # say L1521 pla
    old "Hmm... All right."
    new "へえ… 分かった。"

    # say L1522 sis
    old "Now leave me alone. It's late and I have a lot to do... "
    new "それじゃ、私に任せて。もう遅いし、やることたくさんあるから…"

    # say L1544 sis
    old "Hey!, You won't believe the great news I have, I am so excited, this is working really well."
    new "Hey！信じられないくらい良いニュースがあるの、めっちゃ興奮してるの、これって本当にうまくいってるみたい。"

    # say L1545 sis
    old "We have a new customer, she ordered almost the entire website catalogue."
    new "新しいお客様がいて、ほぼサイトの全商品を注文したの。"

    # say L1546 pla
    old "Wow, that's great!"
    new "Wow、それは凄いね！"

    # say L1547 sis
    old "The order already went through, soooo... I need your help!"
    new "注文はすでに通っちゃったから、手伝ってもらえる？"

    # say L1548 pla
    old "Let me guess, you want me to make the delivery?"
    new "予想通り、君は俺に配達させたいんだな？"

    # say L1549 sis
    old "Yes, but if you go right now, you won't have to do it later, huh?"
    new "そう、でも今すぐ行くなら、後でしなくていいよ、ね？"

    # say L1550 pla
    old "Well, it's still me doing the delivery!"
    new "まあ、結局は俺が配達するんだよな！"

    # say L1551 sis
    old "I love how engaged you are, this is why we are growing and growing!"
    new "あなたの積極性が大好き、だからこそ私たちのビジネスは成長し続けているのよ！"

    # say L1552 pla
    old "Hmm, alright, I'll do the damn delivery... "
    new "うーむ、分かったよ、配達するよ…"

    # say L1553 sis
    old "Hahaha remember is for the ‘business'."
    new "ははは、これは『ビジネス』のためにやってるのよ。"

    # say L1555 sis
    old "Alright, let me know when it's done, see you later."
    new "分かったわ、終わったら連絡するからね、後でね。"

    # say L1558 pla
    old "(Hmmm I hope it isn't anyone I know like last time.)"
    new "（ほんと、また知り合いじゃないといいけどな。）"

    # say L1562 pla
    old "(Alright, is here...)"
    new "（よし、ここに...)"

    # say L1564 ana
    old "Good morning, how can I help you?"
    new "おはよう、何かお手伝いできることがありますか？"

    # say L1567 pla
    old "G-good morning, Mrs. Anastasia? Here is your package!"
    new "あ、あん녕ございます、アナスタシアさん。こちらがお荷物です！"

    # say L1568 ana
    old "Oh, Thank you so much! So? Are you the business guy behind this?"
    new "あら、ありがとうございます！そういえば、このビジネスの裏で動いているのはあなたですか？"

    # say L1569 pla
    old "Oh no, this is my [sisrel] business, I'm just helping."
    new "ああ、いいえ、これは俺の [sisrel] のビジネスで、ただ手伝ってるだけさ。"

    # say L1570 ana
    old "That's so sweet, She is very lucky to have a handsome young man like you helping."
    new "それはとっても素敵ね、彼女はあなたのようなハンサムな若者に手伝ってもらえるなんて、本当に幸せよね。"

    # say L1571 pla
    old "Thanks... We are trying to get some extra income."
    new "ありがとう… 頑張ってるんだ、収入を増やしてさ。"

    # say L1574 ana
    old "I like your products, surely I will look forward to knowing more about you guys."
    new "あなたの商品、気に入りました。これからもっと詳しく知りたいですね。"

    # say L1575 ana
    old "Specially you, sweety."
    new "特にあなたね、スイート-heart"

    # say L1576 pla
    old "Hmmm... T-thanks."
    new "うーん… ありがとう、君。"

    # say L1577 ana
    old "My pleasure, see you later sweetheart..."
    new "私の喜びよ、またね、甘い人…"

    # say L1579 pla
    old "(What a nice lady.)"
    new "いい女性だな。"

    # say L1585 pla
    old "Well, I am back."
    new "じゃあ、戻ってきたよ。"

    # say L1586 sis
    old "How was it? I'm kind of busy, but let me know everything."
    new "どうだった？忙しいんだけど、全部教えて。"

    # say L1587 pla
    old "She was very interested in the clothes."
    new "彼女は服にとても興味があったよ。"

    # say L1588 sis
    old "Great, what did you tell her?"
    new "良かった、彼女に何を話したの？"

    # say L1589 pla
    old "The common stuff, you know, I said hello, the information of the delivery."
    new "普通の話題で、挨拶して配達の情報を伝えた。"

    # say L1590 pla
    old "She mentioned she will order more."
    new "彼女はもっと注文するって言ってたよ。"

    # say L1591 sis
    old "Fantastic, I will need your help next time, so she feels engaged with the purchase."
    new "素晴らしい、次は君の手伝いが必要だから、彼女が購入に関わるようね。"

    # say L1592 sis
    old "Let me continue... I have more and more customers messaging."
    new "続けさせて……お客様からのメッセージが増えているの。"

    # say L1595 pla
    old "Sure, you are very welcome!"
    new "もちろん、喜んで手伝うよ。"

    # say L1615 sis
    old "You ready for the pics? I've been waiting for you."
    new "準備できてる？私、あなたを待ってるの。"

    # say L1616 pla
    old "Oh right, I'm going for the camera, I'll see you in your bedroom."
    new "よし、カメラを持っていくから、君の寝室で会おう。"

    # say L1624 pla
    old "(Holy shit!)"
    new "（やべえ！）"

    # say L1625 sis
    old "Finally, I have good ideas for today's session."
    new "ついに、今日のセッションのためにいいアイデアが浮かんだの。"

    # say L1626 sis
    old "What do you think? Do I look beautiful?"
    new "どう思う？ 私、綺麗に見える？"

    # say L1627 pla
    old "Gulp... (Wow, she is really hot) I think you look very... N-nice."
    new "ゴクリ…（うわ、本当に hott だな）君はとても…ええと、hott だな。"

    # say L1628 sis
    old "Great... But, before we start do you think, you need any... Help?"
    new "グレート…でも、始める前に何か…リラックスが必要かな？"

    # say L1629 pla
    old "What do you mean? I have the camera and everything..."
    new "何の意味？カメラも全部用意したけど……"

    # say L1630 sis
    old "I mean if you need to 'relax' before we start..."
    new "私が言いたいのは、始める前にリラックスするために何か必要なことあるの？"

    # say L1631 pla
    old "I-I don't understand..."
    new "分かんないけど…"

    # say L1632 sis
    old "I mean, don't be flushed I know you got hard last time and is totally normal..."
    new "つまり、赤くなっても大丈夫よ。前にも硬くなっちゃったんでしょ？全然普通のことだから…"

    # say L1634 sis
    old "It's because of the clothes I'm wearing, I think it's fair, you know, you help me, I can help you too and I already did, didn't I?"
    new "着てる服のせいかな、公平だと思うよ。お互いに助け合ってるし、私だってもう手伝ったでしょ？"

    # say L1635 pla
    old "I'm not sure if it's okay..."
    new "俺がいいのかどうかちょっと不安だな..."

    # say L1636 sis
    old "Oh come on, you're not going to take good pictures if you're hard the whole session..."
    new "ほら、ずっと硬いままじゃ良い写真は撮れないよ…"

    # say L1637 sis
    old "It's because of business, remember?"
    new "仕事だからって、覚えてるでしょ？"

    # say L1639 sis
    old "Great, take off your pants I'm going to suck you off..."
    new "よし、パンツ脱いで。私が咥えてあげるから…"

    # say L1640 pla
    old "W-WHAT?! Are you going to suck-..."
    new "な、何言ってんの？君が吸うって…"

    # say L1641 sis
    old "Well... You did a great job with the deliveries, I think you deserve a reward, don't you think?"
    new "WELL... 配達頑張ったわね、報酬くらいあげてもいいと思わない？"

    # say L1643 sis
    old "By the way, I'll have to take off my clothes, just to be sure I don't stain the clothes for the photos..."
    new "それにしても、服を脱がないと写真を撮るときに服を汚してしまうかもしれないから…"

    # say L1644 sis
    old "Does it bother you?"
    new "気にならない？"

    # say L1646 sis
    old "Hahaha you will love it..."
    new "ははは、これ好きになるわ..."

    # say L1663 sis
    old "I hope you are relaxed now, so let's do it!"
    new "リラックスできてるかな、それじゃあ始めよう！"

    # say L1678 sis
    old "You think this way it looks good?"
    new "この角度から見ると、いい感じに見えると思う？"

    # say L1679 pla
    old "Absolutely."
    new "絶対だよ。"

    # say L1680 pla
    old "Let me be sure the skirt stands out. I will take a pic of entire clothes."
    new "スカートがよく見えるように確認するよ。全身の写真も撮るから。"

    # say L1715 pla
    old "Yes, let's do the next one from another position."
    new "次は別の角度から撮ろう。"

    # say L1716 sis
    old "Great! I saw one I want to try."
    new "いいね！試したいのがあるの。"

    # say L1717 pla
    old "Sure, what do you have on mind?"
    new "もちろん、何を考えているんだ？"

    # say L1718 sis
    old "I want to take some pics on the bed."
    new "ベッドで写真を撮りたいの。"

    # say L1719 pla
    old "Well, we haven't done anything like that before. Let's do it!"
    new "俺たち、そんなことしたことがないけど、やってみよう！"

    # say L1720 pla
    old "Lay down on the bed but leave the legs out of the bed so we can see your butt."
    new "ベッドに寝て、足はベッドから出しっぱなしにしておいて。そうすればお尻が見えるから。"

    # say L1721 sis
    old "Nicee."
    new "いいね。"

    # say L1731 sis
    old "I hope it looks sexy."
    new "セクシーに見えるといいな。"

    # say L1732 pla
    old "(Holy shit...) I-I am sure you're gonna love these."
    new "（Holy shit...）君が気に入るに決まってるよ。"

    # say L1733 pla
    old "But let me try to catch a bit more, your legs must look huge."
    new "でもちょっともっと捉えさせて、君の足はデカく見えるだろう。"

    # say L1759 pla
    old "I think I have it."
    new "俺はもういいと思う。"

    # say L1768 pla
    old "Ok, for the next picture I need you to turn around please, I want to try an option like the last time but slightly different."
    new "次は向いてくれ、前回のポーズを少し変えてみようと思うんだ。"

    # say L1769 pla
    old "Do not look at the camera and try to lift a bit more your butt, hold your hair with one hand."
    new "カメラを見ないで、お尻を少し上げて、片手で髪を掴んで。"

    # say L1770 sis
    old "Ohh, I like it!"
    new "オッ、これいい感じ！"

    # say L1781 pla
    old "It's perfect."
    new "完璧だな。"

    # say L1806 pla
    old "Ok, I think we are done."
    new "よし、これで完成だな。"

    # say L1814 sis
    old "Awesome!!! Let me see them!"
    new "Awesome！！！ 見せてぇ！！！"

    # say L1819 pla
    old "Ok... Gallery... Done"
    new "よし…ギャラリー…完了"

    # say L1854 pla
    old "I do not know what's happening today, these photos are not sharp enough."
    new "今日どうしたのかわからないけど、この写真はボケてるな。"

    # say L1855 sis
    old "We will need to try again, this material is important. "
    new "また試してみる必要があるわ、この素材は重要だから。"

    # say L1856 pla
    old "Yes, I am sure we can make it a lot better."
    new "そうだな、もっと良くできるはずだ。"

    # say L1857 pla
    old "I just need to practice more."
    new "もっと練習するだけだ。"

    # say L1858 sis
    old "I need you to put more effort, we can't keep wasting time like this."
    new "もっと努力してほしいの、こんなに時間浪費してるわけにはいかないよ。"

    # say L1859 pla
    old "It won't happen again!"
    new "またやらないよ！"

    # say L1884 sis
    old "Wow, we're on fire!"
    new "燃えているわ！"

    # say L1885 sis
    old "Look at me, so hot. I like your job and I'm not talking about the pics only."
    new "見て、こんなに熱くなってる。あなたの仕事、写真だけじゃなくて好きよ。"

    # say L1886 pla
    old "We are doing a great job."
    new "俺たち、かなりいい仕事をしてるな。"

    # say L1887 sis
    old "Yes, everyday I have more customers, you're a big help."
    new "うん、毎日お客さんが増えてるの、あなたのおかげで大助かり。"

    # say L1888 sis
    old "I will go ahead to upload this content on the website."
    new "このコンテンツをウェブサイトにアップロードするね。"

    # say L1889 pla
    old "Ok, bye."
    new "分かった、じゃあね。"

    # say L1910 sis
    old "Hey, now that you are here, do you remember Mrs Anastasia? Well, she placed another order, it was mostly the last ones we took pics of!"
    new "ねえ、あなたがここにいるなら、アナスタシアさん覚えてる？ そう、彼女また注文を入れたの。ほとんど私たちが撮影した最後のものたちよ！"

    # say L1911 sis
    old "Need you to be really nice with her, I'm sure, she will buy anything we post later!"
    new "彼女に超親切にしてね、きっと後で載せるもの全部買うよ！"

    # say L1912 sis
    old "So you better give her amazing customer service, don't want you to mess things up with her."
    new "だから彼女には最高のおもてなしをして、失敗しないでね。"

    # say L1913 pla
    old "Ok... I'll go right away."
    new "分かった…今すぐ行くよ。"

    # say L1914 sis
    old "Don't forget to be really kind, she is a very important client."
    new "優しくすることを忘れずに、彼女はとても大切なお客様なの。"

    # say L1916 pla
    old "Yes, yes, I know!"
    new "はいはい、分かってるよ！"

    # say L1922 pla
    old "Good morning Mrs, I have another package for you!"
    new "おはよう、奥様。また荷物が届いたよ！"

    # say L1923 ana
    old "Oh, it's you again, you came really fast, Thank you very much!"
    new "またあなたね、本当に早かったわ、ありがとうございます！"

    # say L1924 pla
    old "We really appreciate your purchase."
    new "購入していただいて、本当にありがとうございます。"

    # say L1925 ana
    old "I do appreciate how much of a gentleman you are."
    new "あなたの紳士なところ、本当に感謝してるわ。"

    # say L1926 pla
    old "Hmmm, thank you... Uhh this is your package."
    new "うん、ありがとう… これは君の荷物だね。"

    # say L1927 ana
    old "Thank you sweety!"
    new "ありがとう、スイート！"

    # say L1932 ana
    old "You know what? you deserve a tip."
    new "あなたは-tip-を deserve-するわ。"

    # say L1933 pla
    old "Oh please don't worry..."
    new "心配するな、アナ。"

    # say L1934 ana
    old "Give me just a second, your kindness deserves compensation."
    new "ちょっと待って、あなたの優しさには報酬が必要ね。"

    # say L1935 pla
    old "It's not necessary, I am very glad to bring your package."
    new "必要ないよ、君の荷物を持ってきてとても嬉しいんだ。"

    # say L1936 ana
    old "Do not dare to leave!"
    new "行っちゃダメよ！"

    # say L1948 ana
    old "I beg your pardon... Can't find my purse."
    new "ごめんなさい…財布が見つからないの。"

    # say L1949 pla
    old "Do not worry, it's not a problem."
    new "心配しなくていい、大丈夫だよ。"

    # say L1950 ana
    old "Oh no, you deserve it."
    new "あら、そんなに思わないで。あなたが受け取る deserve べきよ。"

    # say L1951 ana
    old "Let me see if I could have something here... Hope you like it."
    new "見てみましょう、何かあるといいんだけど… 好きなものが見つかるといいな。"

    # say L1953 pla
    old "(Wow) ..."
    new "（すごい…）"

    # say L1954 ana
    old "(He's so shy... Hehehe, can't even speak.)"
    new "（彼、めっちゃ恥ずかしがり屋ね… ヘヘヘ、言葉も出ないみたい。）"

    # say L1955 pla
    old "Gulp, tha-... Thank you."
    new "gulp、あの… ありがとう。"

    # say L1957 ana
    old "Hehehe, You are kind of tender."
    new "へへへ、あなたってちょっと繊細な感じね。"

    # say L1958 ana
    old "I hope I can see you next time, I'll have cash handy. Bye handsome!"
    new "次に会えるのを楽しみにしてる、現金も用意しておくから。さよなら、ハンサム！"

    # say L1966 sis
    old "Was everything alright?"
    new "全然大丈夫だった？"

    # say L1967 pla
    old "Definitely, she is amazing!"
    new "もちろん、彼女は最高だ！"

    # say L1968 sis
    old "(Amazing?) Hmm ok, thank you!"
    new "（すごい？）うん、ありがとう！"

    # say L1969 sis
    old "Does she like the products."
    new "彼女は商品を気に入ったの？"

    # say L1970 pla
    old "She seemed to be very interested about the new products."
    new "彼女は新製品にとても興味があったようだな。"

    # say L1971 sis
    old "That's fascinating."
    new "それは面白いわ。"

    # say L1972 sis
    old "Hope you are doing your part, so she definitely keeps her business with us."
    new "あなたの役割を果たして、彼女がずっと私たちと取引してくれるようにね。"

    # say L1974 sis
    old "Besides, I need you to get prepared, we have more products coming."
    new "それに、準備しておいて。新しい商品が入るから。"

    # say L1976 sis
    old "Yes, we need to work hard."
    new "はい、頑張らないとね。"

    # say L1977 pla
    old "Uhh, let's see what happens."
    new "うーん、どうなるか見てみるか。"

    # say L1978 sis
    old "You can be sure it's worth."
    new "安心して、絶対に価値あるわ。"

    # say L2002 sis
    old "Come on [pla]! Time is money and you're late, let's go to the pool."
    new "さあ、[pla]！ 時間はお金だから、遅いよ。プールに行こう。"

    # say L2003 pla
    old "To the p-pool?"
    new "プールに？"

    # say L2004 sis
    old "Yep, the pool. Summer is coming, bikinis are amazing so I need all your effort today."
    new "うん、プールだよ。夏が近づいてきて、ビキニが最高だから、今日一日全力で頑張ってね。"

    # say L2005 sis
    old "We are selling new things and people are crazy with the new summer alternatives."
    new "新しい商品を売って、みんな夏の新商品に熱狂してるの。"

    # say L2007 sis
    old "Do you need some help before we start?"
    new "手伝うの手伝わないの？"

    # say L2009 sis
    old "I mean do you want me to suck your dick, because at the pool it's not that easy. "
    new "おちんちんを吸ってあげるの？だってプールじゃそう簡単じゃないし。"

    # say L2010 sis
    old "And don't beat around the bush!"
    new "とぼけないでよ！"

    # say L2016 pla
    old "I-I am not sure."
    new "俺、まだちょっと迷ってるんだ。"

    # say L2017 sis
    old "Do you want it or not?"
    new "欲しくないの？"

    # say L2019 sis
    old "We don't have time to lose I will take it as a yes..."
    new "時間がないから肯定と取るわ..."

    # say L2020 sis
    old "I'm going to make you cum fast..."
    new "早めにイかせちゃうからね…"

    # say L2044 sis
    old "I hope you're better now, let's do it!"
    new "調子は良くなった？さあ、始めるわ！"

    # say L2052 sis
    old "Oh, I will love the pics today, look at the sun, the pool, everything in its right place."
    new "今日の写真、大好きだわ。太陽もプールも、すべてがぴったりと整ってるわ。"

    # say L2053 pla
    old "Yeah I couldn't ask for a better light and place."
    new "そうだな、これ以上いい光と場所は望めないな。"

    # say L2054 sis
    old "Don't lose more time, let's start."
    new "時間無駄にしないで、始めるよ。"

    # say L2055 pla
    old "You're right. Stay right there, let me start with a full body!"
    new "君が言う通りだ。そのままじゃ、まずは全身から始めよう。"

    # say L2056 sis
    old "Ok, I will stay like this."
    new "わかった、このままいるね。"

    # say L2057 pla
    old "I think you should look to the right, to get a better perspective..."
    new "右を向いた方がいいと思う、そうすればもっと良い感じになるよ、Kylee。"

    # say L2058 sis
    old "Alright, you are the nerd..."
    new "分かったわ、あなたがオタクね。"

    # say L2073 pla
    old "Wonderful, the light is perfect, your hair looks very bright."
    new "素晴らしい、光が最高だね、君の髪がとても明るく見えるよ。"

    # say L2074 sis
    old "Perfect, make sure I look sexy."
    new "完璧、セクシーに見えるようにしてね。"

    # say L2102 pla
    old "Got it!"
    new "分かった！"

    # say L2111 pla
    old "It would be more interesting if we take advantage of some elements of the place."
    new "場所の要素を活かすと、もっと興味深いと思うよ。"

    # say L2112 sis
    old "Hmmm, what do you think about the pool?"
    new "ねぇ、プールはどう思う？"

    # say L2113 pla
    old "I don't think so, we need the clothes dry."
    new "そう思うか？服乾かす必要があるだろ。"

    # say L2114 pla
    old "You now what? Go to the chair, something casual, let's use those glasses you have."
    new "君、椅子に座って、カジュアルな感じで、あのグラスを使ってみよう。"

    # say L2115 sis
    old "Yes, just like that, that's perfect."
    new "うん、そう、それが perfect だよ。"

    # say L2126 pla
    old "Perfect, try to hold the glasses with your hands."
    new "完璧、手でグラスを握ってみて。"

    # say L2127 sis
    old "Try to show my boobs a bit more, I want them to stand out."
    new "もっと胸を見せて、目立つようにしたいな。"

    # say L2128 pla
    old "I think this is the pic you're looking for."
    new "この写真が君が欲しかったものだと思うよ。"

    # say L2153 pla
    old "Ok, next photo..."
    new "次だな、次の写真にしようか。"

    # say L2161 pla
    old "I have a great idea, let's show a different emotion."
    new "いいアイデアだ、違う感情を表現しよう。"

    # say L2162 sis
    old "I am listening..."
    new "聞ってるわ…"

    # say L2163 pla
    old "Let's take advantage of the pool but I don't want the same poses we already tried before, I want to do something unexpected."
    new "プールを使ってみよう、でも同じポーズはもういいかな、何か予想外のことをしたいんだ。"

    # say L2164 pla
    old "Hmm, turn around and try to look at me, but close your eyes..."
    new "うん、体を回して目を閉じて俺を見てみろ…"

    # say L2165 sis
    old "With my eyes closed? Alright, let me try it."
    new "目を閉じて？わかった、やってみる。"

    # say L2176 pla
    old "keep that smile, do not change your face."
    new "その笑顔を保って、顔の表情を変えないで。"

    # say L2177 pla
    old "That's a plot twist."
    new "それは展開の Surprise だな。"

    # say L2178 pla
    old "I like it."
    new "好きだな。"

    # say L2202 pla
    old "Ok, I think that's it."
    new "じゃあ、これでいいかな。"

    # say L2214 pla
    old "Ok... Here they are."
    new "Ok... ここにあるよ。"

    # say L2247 pla
    old "I don't know what's happening today, they are not sharp enough."
    new "今日のはちょっと鈍いな、何が起こってるのかさっぱりわからない。"

    # say L2251 sis
    old "I need you to put more effort, we can't waste time like today."
    new "もっと力を入れて、今日みたいに時間を無駄にしてちゃダメよ。"

    # say L2253 sis
    old "Hmm, look for me to repeat the sesion again..."
    new "うーん、またセッションを繰り返してみてくれない？"

    # say L2276 sis
    old "I like them, but there's something not working."
    new "好きだけど、何かうまくいかないの。"

    # say L2277 pla
    old "What's not working? I can check, so you like them more."
    new "何がうまくいかないの？俺がチェックするから、もっと好きになるようにするよ。"

    # say L2278 sis
    old "Oh no, it's not you, I need some sunbathing."
    new "あら、あなたじゃないの、日光浴が必要なのよ。"

    # say L2279 sis
    old "Don't you think so?"
    new "そう思わない？"

    # say L2280 pla
    old "I think you look great."
    new "君はもう十分sexyだよ。"

    # say L2281 sis
    old "Hehehe of course... "
    new "へへへ、もちろんよ…"

    # say L2282 sis
    old "Anyway, I'm going work on the website, have a good one."
    new "でも、ウェブサイトの作業に戻るわ、良い一日をね。"

    # say L2310 sis
    old "Glad that you came, quite on time to apply my sunscreen, can you help me?"
    new "来て嬉しいわ、日焼け止めを塗る手伝ってくれる？ちょうどいいタイミングだと思ったの。"

    # say L2312 sis
    old "I can show you how to do it... Let's start with my boobs."
    new "私が教えてあげる… まずは私の胸からね。"

    # say L2313 pla
    old "Your... Wh- What?"
    new "お前が… 何言ってんだよ？"

    # say L2314 sis
    old "My boobs, I need to show the bikinis, so my boobs are important. And you see them all the time in the photoshoots."
    new "私の胸よ、ビキニを着せるために、私の胸は重要なんだ。それに君も写真撮影でいつも見ているよね。"

    # say L2315 pla
    old "Hmmm... Alright..."
    new "うーん… 分かったよ…"

    # say L2319 pla
    old "Wow! What are you doing?"
    new "Wow！ 何やってんの？"

    # say L2320 sis
    old "Taking off my bra, you weren't pretending to tan my breasts with it on, did you?"
    new "ブラジャーを外してるの、あなたブラジャー着たまま胸に日焼け止め塗ろうとしてたわけじゃないよね？"

    # say L2321 pla
    old "So you want me to apply the sunscreen like thi-"
    new "じゃあ、こんな風に日焼け止めを塗ってあげるのか？"

    # say L2322 sis
    old "Oh, shut up... You and I both know you're dying to touch them..."
    new "あら、黙って…… あなたも私も、触れたくて仕方ないってこと、お互い知ってるわね"

    # say L2323 sis
    old "And I just want a good massage and sunbathe to get a tan."
    new "ただいいマッサージをして日向ぼっこして日焼けしたいだけよ。"

    # say L2325 sis
    old "So stop acting like an idiot and play with my babies..."
    new "だからバカなふりしないで、私の赤ちゃんをいじってよ…"

    # say L2336 sis
    old "Do you want more, [pla]?"
    new "もっと欲しくないの、[pla]？"

    # say L2338 sis
    old "Don't try to hide it from me... I know you're hard already."
    new "隠そうとしても無駄よ… すでに硬くなってるのわかってるから。"

    # say L2339 pla
    old "I-I don't know what you mea-"
    new "俺、君の言ってることがわからんよ…"

    # say L2340 sis
    old "Let me give you a clue... I've heard cum is a great treatment for the skin, so I wanted to test it on my boobs."
    new "ヒントをあげるわ… 私、精液が肌にいいって聞いたから、自分の胸で試してみたかったの。"

    # say L2341 pla
    old "W-What!?... "
    new "W-何！？…"

    # say L2342 sis
    old "Shut up and come here..."
    new "黙ってこっちに来なよ..."

    # say L2358 sis
    old "Did you enjoy it?"
    new "楽しんだ？"

    # say L2359 pla
    old "Yeah!"
    new "うん！"

    # say L2360 sis
    old "I would love to have this skin care therapy more often."
    new "このスキンケア療法をもっと頻繁に受けられたらいいな。"

    # say L2361 sis
    old "I'll enjoy the sun, thank you."
    new "日向ぼっこを楽しむわ、ありがとう。"

    # say L2362 pla
    old "You're welcome, see you later!"
    new "どうも、またね！"

    # say L2385 sis
    old "Oh, you came at the right time."
    new "あら、ちょうどいいタイミングで来たわ。"

    # say L2387 sis
    old "Fortunately there is good news, I want to tell you something to cheer you up a bit."
    new "幸いなことに良い知らせがあるの、少し元気づけたくて。"

    # say L2389 sis
    old "The bikini session was great, Anastasia ordered again."
    new "ビキニの撮影は最高だったわ、アナスタシアがまた注文したの。"

    # say L2391 sis
    old "I need you to be nice with her again, so she feels comfortable."
    new "また彼女と仲良くしてあげて、リラックスできるようにね。"

    # say L2392 pla
    old "Ok, I will."
    new "分かった、また仲良くするよ。"

    # say L2393 sis
    old "You already know her place, remember, that everything you do is really important."
    new "もう彼女のことを知ってるでしょ、覚えておいて、君がすること全部がすごく大事なんだよ。"

    # say L2401 pla
    old "Good morning Mrs."
    new "おはよう、奥さん。"

    # say L2402 ana
    old "Oh what a nice surprise, It's my favorite delivery boy!"
    new "おっ、何だか嬉しいサプライズね、私の大好きな配達の少年が来たわ！"

    # say L2403 pla
    old "Hehehe, Thank you, I am glad to see you too."
    new "へへへ、ありがとう、君も会えて嬉しいよ。"

    # say L2404 pla
    old "Here you are!"
    new "ここに来たよ！"

    # say L2409 ana
    old "Thank you, you're so kind."
    new "ありがとう、本当に優しいね。"

    # say L2410 pla
    old "I hope you enjoy your purchase, have a nice day!"
    new "購入して良かったらいいな、良い一日をね！"

    # say L2411 ana
    old "Oh, are you planning on leaving already? Actually I was considering to ask you for a big favor and I have nobody else to help me."
    new "あ、もう帰るの？実は、あなたに大きなお願いをしようと思っていたの。他に手伝ってくれる人がいないの。"

    # say L2412 ana
    old "I think since you're a man you could help me."
    new "男の人が手伝ってくれそうだから、手伝ってもらえるかな？"

    # say L2413 pla
    old "(I have to make her feel comfortable, she's our best client.)"
    new "あんまり長くはならないって約束するから、手伝ってくれない？"

    # say L2414 ana
    old "It won't take you too long, I promise."
    new "それほど時間はかからないから、約束する。"

    # say L2415 pla
    old "Oh, sure, how can I help you?"
    new "もちろん、何を手伝えばいい？"

    # say L2416 ana
    old "Please come in."
    new "どうぞ中に入ってください。"

    # say L2424 ana
    old "Just wait a second, I will be right back."
    new "ちょっと待って、すぐ戻るから。"

    # say L2438 pla
    old "(Wow, Wow!)"
    new "わお、わお！"

    # say L2439 ana
    old "I needed a second opinion, and I just thought you could help."
    new "ちょっと意見を聞きたいと思って、あなたに手伝ってほしいと思ったの。"

    # say L2440 ana
    old "Please be honest, do you like it?"
    new "正直に言って、好きかな？"

    # say L2441 pla
    old "Gulp, You look..."
    new "君が… ZZZ…ZZZ 本当にすごいな。"

    # say L2443 pla
    old "No, no, no, of course not, You look... A-amazing."
    new "いや、いや、もちろんじゃない、君は… あ、凄いな。"

    # say L2445 pla
    old "Y-Yes... I- I am being really honest."
    new "Ｙ－Ｙｅｓ... Ｉ－Ｉ本当に本気だよ。"

    # say L2448 pla
    old "(Oh shit... I'm getting hard.)"
    new "オッシャク、硬くなってきちゃった..."

    # say L2449 ana
    old "Wow dear, what you got in there?"
    new "おや、そこには何が入ってるの？"

    # say L2450 pla
    old "I'm sorry, I didn't mean to-"
    new "ごめん、そうなるつもりはなかったんだけど-"

    # say L2451 ana
    old "Ohh, You are very sweet, I apologize for this, I didn't mean to make you feel uncomfortable."
    new "あら、あなたはとても優しいわね。申し訳ない、あなたの気を悪くさせるつもりはなかったの。"

    # say L2453 pla
    old "I-I am sorry, I-I... Just should leave."
    new "ごめん、俺… さっさと帰るしかないな。"

    # say L2454 ana
    old "Oh no, please let me apologize correctly, you can't leave like that."
    new "あら、そんなに言わないで、ちゃんとしてお詫びさせてください、こんなふうに帰っちゃダメよ。"

    # say L2456 ana
    old "I think you deserve a bigger tip this time due to this big inconvenience."
    new "今回は大きな不便をかけてしまったので、もっと大きいチップをあげようかしら。"

    # say L2459 ana
    old "How about if you just relax a little bit on the couch and let me fix this with my own hands. "
    new "ちょっとソファーでリラックスして、私が直接手で直すから。"

    # say L2466 ana
    old "Please, relax and let me compensate for the situation, just close your eyes and enjoy."
    new "どうぞリラックスして、目を閉じて楽しんでみて。"

    # say L2478 ana
    old "I hope you liked it..."
    new "良かったね..."

    # say L2479 pla
    old "Uhh... Y-yes, thank you"
    new "うーん… や、yeah、ありがとう"

    # say L2480 ana
    old "Alright sweetie, thanks for your help, it was very clear to me that this bikini suits me very well... I hope to see you in my next delivery."
    new "大丈夫よ、ありがとう、お手伝いしてくれて助かったわ。このビキニがとても似合うってことがよくわかったから……次のお届けも楽しみにしてるわ。"

    # say L2481 pla
    old "(Wow, I'm starting to love this job)"
    new "うわ、この仕事がどんどん好きになってきたな"

    # say L2482 pla
    old "Of course, I'll bring your next purchase."
    new "もちろん、次のもってくるよ。"

    # say L2483 ana
    old "That sounds great..."
    new "それはいいな..."

    # say L2492 sis
    old "Hey, you are back."
    new "ねえ、戻ってきちゃったの。"

    # say L2493 pla
    old "Yep."
    new "うん。"

    # say L2494 sis
    old "So? Everything went alright?"
    new "そう？全部上手くいったの？"

    # say L2495 pla
    old "It was... Wonderful."
    new "それは…最高だった。"

    # say L2496 sis
    old "(Wonderful?) Hmm, ok thanks for your help."
    new "（素晴らしい？）ふむ、ありがとう。"

    # say L2497 sis
    old "Did she like it?"
    new "彼女は気に入ったのかな？"

    # say L2498 pla
    old "Yeah, she loved it."
    new "まあ、彼女は大好きだったな。"

    # say L2499 sis
    old "How are you so sure about it?"
    new "どうしてそんなに確信してるの？"

    # say L2500 pla
    old "Well... Is the second time she purchases, so she liked the first one."
    new "まあ……二回目を購入したってことは、最初のは気に入ったんだろ。"

    # say L2501 sis
    old "Ok... I'll let you know once we are ready for the next photography session."
    new "分かった…次の中撮りが準備できたら教えてあげるね。"

    # say L2502 pla
    old "I'll look forward to it."
    new "楽しみに待ってるよ。"

    # say L2529 sis
    old "Uhh... I am so horny, I'll need more."
    new "うーん……私、めちゃくちゃ欲しくなるから、もっと必要だな。"

    # say L2531 pla
    old "(Oh shit... She saw me!)"
    new "おっシャイティ... 見られちまったか。"

    # say L2539 sis
    old "I know you have been there for a while."
    new "知ってるよ、ずいぶん長い間いたんだね。"

    # say L2540 pla
    old "Sorry... I-I was just-"
    new "ごめん… ただ-"

    # say L2541 sis
    old "It's ok dummy! I think it is time to get paid back."
    new "大丈夫よバカ！返してもらう時が来たと思うの。"

    # say L2543 sis
    old "I mean, I need you to pay me back, I know that you have more than enough to give."
    new "つまり、あなたに返してもらう必要があるの、あなたには十分な余裕があるって知ってるわ。"

    # say L2545 sis
    old "Come here, let me suck that big dick."
    new "ここへ来て、この大きなちんこを吸ってあげる。"

    # say L2550 sis
    old "Grab my head and fuck my mouth!"
    new "頭をつかんで私の口を犯して！"

    # say L2560 sis
    old "Oh, shit. I can't handle it anymore... Want you to fuck me, I need you inside of me now."
    new "ああ、もう我慢できない… あなたに犯されてほしい、今すぐ中に入れて。"

    # say L2562 sis
    old "Come here and fuck your [sisrel]... Fuck me hard [pla]!"
    new "ここに来て、あなたの[sisrel]で私を犯して… 強く犯して[pla]！"

    # say L2578 sis
    old "Wow, you did great!"
    new "すごいね、本当に上手かったわ！"

    # say L2580 sis
    old "Ugh, I got really tired, that was pretty intense."
    new "うーん、疲れた、それかなり激しかったもんね。"

    # say L2582 sis
    old "Anyway, I'm gonna need some of your skills tomorrow too."
    new "でも、明日もあなたのスキルが必要になるのね。"

    # say L2584 sis
    old "Hahaha, I'm talking about the photshoot, dummy. I'm preparing a new one, so, I count on you."
    new "ははは、写真撮影のことよ、バカ。新しいのを準備してるから、あなたに任せるわ。"

    # say L2585 pla
    old "Sure, I'll be ready."
    new "分かった、準備しておくよ。"

    # say L2586 sis
    old "Now leave me alone. I just want to rest..."
    new "じゃあ、邪魔しないで。ちょっと休みたいだけだから…"

    # say L2587 pla
    old "Hmm, alright... See you later."
    new "うん、わかった… 後でな。"

    # say L2609 sis
    old "Hey, did you sleep well?"
    new "hey、よく眠れた？"

    # say L2610 pla
    old "Yeah, pretty well!"
    new "うん、わりとよく眠れた！"

    # say L2611 sis
    old "Good, that means we're gonna rock today!"
    new "良かった、今日もがんばるわね！"

    # say L2644 sis
    old "I will be at the pool, don't be late."
    new "プールで待ってるから、遅れないでね。"

    # say L2645 pla
    old "I'm going to pick up the camera and see you there."
    new "カメラを持っていくから、そこで会うよ。"

    # say L2652 sis
    old "This is the newest collection, what do you think?"
    new "これは最新のコレクションよ、どう思う？"

    # say L2653 pla
    old "Really? It's pretty nice!"
    new "本当に？なかなかいいじゃん！"

    # say L2654 pla
    old "I have some ideas for today."
    new "今日の撮影についていくつかアイデアがあるんだ。"

    # say L2655 sis
    old "Awesome, what are we waiting for?"
    new "すごい、何を待ってるの？"

    # say L2656 pla
    old "Ok, let's start with you standing up in front of the pool for a full body one."
    new "じゃあ、まずは君がプールの前に立って、全身を撮ろう。"

    # say L2669 sis
    old "Ok, do I look good like this?"
    new "こんな感じでいい？"

    # say L2670 pla
    old "Yeah, keep your hand there, do not move... It looks more fancy."
    new "うん、手はそのままで動かないで… もっと華やかに見えるよ。"

    # say L2706 pla
    old "Now I want try something special."
    new "今特別なこと試してみ wanna"

    # say L2707 sis
    old "Tell me what to do."
    new "何すればいいの教えて？"

    # say L2708 pla
    old "Please get on your knees, looking at me very very enticingly and to move your shoulders a bit ahead of your body..."
    new "膝をついて、俺を見つめながらとても魅力的に、体を少し前に傾けて肩を動かしてみて..."

    # say L2719 sis
    old "Do you like it this way?"
    new "この感じが好き？"

    # say L2745 pla
    old "Oh boy, this is by far one of the best ones."
    new "おっ、これは間違いなく最高の一つだな。"

    # say L2753 pla
    old "Hmm I think would be great another one on the floor, but you turning around."
    new "うーん、床に一つ追加するのがいいと思うけど、君が向いてくるように。"

    # say L2754 sis
    old "Alright, but what kind of position should I do?"
    new "わかったわ、でもどんな体位がいいの？"

    # say L2755 pla
    old "Let's see if we can make it a bit hotter..."
    new "もっと熱くしてみようか"

    # say L2756 pla
    old "Try to spread a bit your legs... And look at the camera. Also lift up your butt a bit more but try to keep your breast lower."
    new "足を少し開いて……カメラを見て。あとお尻を少し上げて、でも胸は低く保とう。"

    # say L2757 sis
    old "Hmm, let me try."
    new "うーん、試してみる。"

    # say L2768 pla
    old "Oh perfect! let me take the picture."
    new "よし、完璧だ！写真を撮るぞ。"

    # say L2792 pla
    old "This looks amazing."
    new "これ、めちゃくちゃいい感じだな。"

    # say L2799 pla
    old "Ok, I really think we are done..."
    new "よし、本当にこれで終わりだな…"

    # say L2801 sis
    old "Really? Yayyy! let me see them."
    new "本当に？やったー！見せて。"

    # say L2802 pla
    old "Of course..."
    new "もちろん…"

    # say L2839 pla
    old "I do not know what's happening today, they are not sharp enough."
    new "今日どうしたのかな、シャープじゃないみたいだ。"

    # say L2857 pla
    old "Hmm, again with that..."
    new "またかよ…"

    # say L2858 sis
    old "Hahaha, You did it well nerd."
    new "ははは、よくやったね、オタク。"

    # say L2867 sis
    old "Anyway, I'm going to upload more material, I need to sell."
    new "まあ、もっと素材をアップロードするわ、売らなきゃならないの。"

    # say L2869 sis
    old "Oh by the way... I'm considering bringing some sexy friends so we can make pics with new models."
    new "それにしても……エッチな写真を撮る新しいモデルを連れてくることを考えているの。"

    # say L2870 sis
    old "It would help us get everybody's attention and it means more sales, more money."
    new "みんなの注目を集められて、売上も上がり、お金ももっと入るわ。"

    # say L2872 sis
    old "Sure, you are gonna like it!"
    new "もちろん、あなたはきっと気に入るわよ！"

    # say L2873 sis
    old "Well time is money, see you around..."
    new "時間はお金さ、またね。"

    # say L2875 pla
    old "New models, uh?"
    new "新しいモデルか？"

    # say L2898 sis
    old "Well you're on time, wanna have fun? I need help with my sunscreen again."
    new "WELL、時間通りだね、遊ぼう？日焼け止めの手伝いが必要なの。"

    # say L2900 sis
    old "Let's start with my butt."
    new "まずはお尻からね。"

    # say L2904 sis
    old "I love the sun, it feels great and makes me look better, don't you think."
    new "日焼けが大好き、気持ちいいし、肌も美しく見えるでしょ。"

    # say L2906 sis
    old "Please pay attention, I need you to spread it aaaaall over my butt while giving a slow massage."
    new "注意してね、私のお尻全体にゆっくりとマッサージしながら塗ってほしいの。"

    # say L2924 sis
    old "You know what? Let's fuck right now!"
    new "ねえ、今すぐセックスしようよ！"

    # say L2925 pla
    old "Wha-? But... Someone could see us."
    new "何っ？でも……誰かに見られるかもな。"

    # say L2926 sis
    old "People are busy, nobody is gonna come, I already checked."
    new "人が忙しくて誰も来ないわ、確認済み。"

    # say L2927 sis
    old "Last time you weren't so worried about that!"
    new "前はそんな心配してなかったじゃない！"

    # say L2929 sis
    old "Don't worry about the people, think just about my ass"
    new "心配しなくていいから、私のアナルのことだけ考えて"

    # say L2941 sis
    old "I really liked it, you are by far much better than my toy."
    new "本当に良かったわ、あなたは私のおもちゃよりもずっと上手いよ。"

    # say L2942 sis
    old "It's like a super toy, delicious!"
    new "それは超おもちゃみたい、おいしい！"

    # say L2943 sis
    old "Hope you liked it too, gonna take a shower."
    new "よかったらいいな、シャワーに入ってくる。"

    # say L2944 sis
    old "Bye now."
    new "じゃあね。"

    # say L2968 pla
    old "Yep, how bout you?"
    new "うん、お前はどうだった？"

    # say L2969 sis
    old "Amazing, sun makes me feel good."
    new "日光が当たると気分が良いの。"

    # say L2970 sis
    old "I want to share some news to you."
    new "あなたに知らせたいことがあるの。"

    # say L2972 sis
    old "Sure, meet me in my bedroom."
    new "もちろん、私の寝室に来なさい。"

    # say L2973 pla
    old "Coming."
    new "来るよ。"

    # say L2980 sis
    old "Well, being honest, the business is running pretty good."
    new "正直に言うと、ビジネスはかなり上手くいっているよ。"

    # say L2981 sis
    old "Part of this success has been your help with the website, the pics, and your effort."
    new "この成功の一部は、あなたがウェブサイトや写真、そして努力してくれたおかげだよ。"

    # say L2982 sis
    old "I know you have been more than the 'nerd' with the website, but also the one who delivers, photographer, market couch, you name it."
    new "あなたがウェブサイトの『オタク』以上の存在だったことは知ってるわ。配達も、写真撮影も、マーケティングのアドバイスも、何でもやってくれたのよ。"

    # say L2983 pla
    old "Well, that is not true, but thanks."
    new "まあ、全然そうじゃないけど、ありがとう。"

    # say L2984 sis
    old "I think it would be fair if we split the incomes instead of just giving you part of it, because you are more like my partner."
    new "収入を分けるのが公平だと思う、あなたはもう私のパートナーみたいなものだから。"

    # say L2985 pla
    old "Wow... I am glad to hear that."
    new "うわ... 嬉しいな。"

    # say L2986 sis
    old "To be honest, there is more you should know."
    new "正直に言って、知るべきことが他にもあるの。"

    # say L2987 sis
    old "This is just part of the incomes, there is something you should be more excited about."
    new "これは収入の一部だけよ、もっと興奮するべきことがあるの。"

    # say L2989 sis
    old "Lay on the bed, I will show you."
    new "ベッドに寝て、見せてあげるね。"

    # say L2992 sis
    old "Let me give you something money can't buy."
    new "私がお金では買えないものをあげるわ。"

    # say L3001 sis
    old "Ohh, I love this taste..."
    new "ああ、この味が大好き…"

    # say L3002 sis
    old "Now, let's fuck! I'm going to ride you..."
    new "さあ、今度はセックスだよ！私が乗るから…"

    # say L3015 sis
    old "That was intense... What a mess we've made."
    new "それが激しかった… なんて散らかしちゃったわ。"

    # say L3022 pla
    old "Hell yeah."
    new "やべえ"

    # say L3023 sis
    old "I think this is how a very successful partnership starts!"
    new "これこそが大成功のパートナーシップの始まりだわ！"

    # say L3024 sis
    old "I appreciate your hard work especially in this extra activity."
    new "あなたの頑張り、特にこの特別な活動での努力は本当に感謝してるわ。"

    # say L3025 sis
    old "From now you can ask anything from me. I mean we are partners."
    new "これから何でも聞いていいわ。パートナー同士なんだから。"

    # say L3027 sis
    old "I need a bit of rest... See you later [pla]"
    new "ちょっと休みたいな… 後でね [pla]"

    # say L3028 pla
    old "See you later [sis]."
    new "また後で [sis]"

    # say L3029 sis
    old "I really love your cock, Nerd!"
    new "あなたのちんこ、本当に好きよ、オタク！"

    # say L3061 sis
    old "I asked you to come to my bedroom in the afternoons, dummy..."
    new "午後の私の寝室に来るように言ったのにな、バカ…"

    # say L3063 pla
    old "Oh, my bad. I will be in the garage studying then."
    new "あー、悪い。その時間はガレージで勉強してるんだ。"

    # say L3068 sis
    old "Studying in the garage?... (Hmm, I wonder what he's really doing in there.)"
    new "ガレージで勉強？…（んー、本当にそこで何してるのかな。）"

    # say L3098 pla
    old "Oh... sorry. I was just thinking of something..."
    new "あー、ごめん。ただ何か考えてただけだよ…"


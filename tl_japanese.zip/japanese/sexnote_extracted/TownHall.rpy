# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/TownHall.rpy
translate japanese strings:

    # menu L10 
    old "Talk"
    new "話す"

    # say L11 sop
    old "Hello, Can I help you?"
    new "こんにちは、何かお手伝いできることはありますか？"

    # say L12 pla
    old "Oh, no, sorry for bothering you."
    new "ああ、ごめん、迷惑かけちゃって。"

    # say L37 sop
    old "Hmm, Can I help you?"
    new "うーん、何かお手伝いできるの？"


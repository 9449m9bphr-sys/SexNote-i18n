# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Animations/graAnimations.rpy
translate japanese strings:

    # say L6 gra
    old "I feel I'm in heaven just by touching it! Oh my Father, I'm so grateful."
    new "ただ触れるだけでも天国にいるような気分です！お父様、本当に感謝しています。"

    # say L7 pla
    old "(My God!...)"
    new "神様！…"

    # say L12 gra
    old "The feeling of your big grace on my hands, it's so pure."
    new "あなたの大きな恵みを手に感じただけで、こんなに純粋な気持ちになります。"

    # say L17 gra
    old "My heavenly God!... It's so... S- So great and big, divine!"
    new "私の天の神様！… これほど… す- すごいと大きくて、神聖な…！"

    # say L41 gra
    old "I feel that grace is going to come in my fac- Ahhhhhh!!!"
    new "その恵みが顔に来ちゃいそう……アaaaaaaaaa！！！"

    # say L58 gra
    old "Your divine phallus is precious, just by seeing it I can feel the glory in him."
    new "あなたの神聖なペニスは尊い、ただ見ているだけでその栄光を感じることができます。"

    # say L59 pla
    old "(Wow is s- she... S- sucking it...)"
    new "（すごい……彼女……吸ってる……）"

    # say L63 gra
    old "Your divine phallus tastes like heaven... Oh my Father, I'm so grateful."
    new "あなたの神聖なペニスは天国の味… オーマイファーザー、本当に感謝しています。"

    # say L67 gra
    old "My soul is silent and my door is open for you, I need your sacred water in my mouth, I have said many wrong things lately and I gotta clean that."
    new "私の魂は静かで、扉はあなたのために開かれています。あなたの聖なる水を私の口に注いでください。最近、多くの間違いを犯したので、それを浄化しなければなりません。"

    # say L68 gra
    old "I wanna feel it in my tongue... My tongue is thirsty of you..."
    new "舌で感じたいの……私の舌はあなたを求めているの……"

    # say L91 gra
    old "I feel that grace is going to come... To come in my lips!!!"
    new "私はその恵みが唇にやってくるのを感じる…！！！"

    # say L95 gra
    old "Ahhhhhhhh!!"
    new "アァァァァァァン！！"

    # say L96 gra
    old "(My Godness!... This is heaven, divine!)"
    new "神様！… これが天国、神聖さそのものよ！"

    # say L108 pla
    old "(Wow is s- she... S- sucking it again...)"
    new "（す、すごい……また吸ってる……）"

    # say L116 gra
    old "I need your sacred water in my mouth, I have said many wrong things lately and I gotta clean that."
    new "私の口にあなたの聖なる水をください、最近悪いことを言ってしまったので、それを洗い流さなければなりません。"

    # say L147 gra
    old "Oh father, my soul is silent and my door is open for you, I need you inside of me cleaning my impure soul."
    new "お父様、私の魂は静かで、扉はあなたのために開いています。あなたの力で私の不純な魂を清めてください。"

    # say L148 pla
    old "Does she wants me to f- fuck... her?"
    new "彼女は俺に…セックスして欲しがってるのか？"

    # say L167 gra
    old "Ohhh father, I can feel your grace inside me!"
    new "あぁ、父様、あなたの恵みが私の中にあるのを感じます！"

    # say L168 gra
    old "And it feels sooo goood!"
    new "そして、それがとっても気持ちいいんです！"

    # say L169 pla
    old "(Ohh yeah...)"
    new "オッ、そうよ..."

    # say L173 gra
    old "Yes, father! Please clean all my sins harder!"
    new "はい、お父様！もっと私の罪を強く洗い清めてください！"

    # say L174 gra
    old "Ohhh God! Oh God!"
    new "ああっ神様！神様！"

    # say L178 gra
    old "Ahhh Ahhh father. Yes, give me more! MORE!"
    new "アーッ アーッ お父様、はい、もっと与えてください！もっと！"

    # say L201 gra
    old "(My heavenly God!... I'm seeing the heaven!)"
    new "私の天の神様！… 天国が見えてくるわ！"

    # say L202 gra
    old "I feel that grace is going to come... To come insid- Ahhhhhh!!!"
    new "その恵みが来そう…… 中に入っちゃう……アaaaaaaaaa！！！"

    # say L219 gra
    old "My heavenly God, it's so big."
    new "私の天の神様、こんなに大きいです。"

    # say L224 gra
    old "Oh God! It tastes like heaven..."
    new "神様！これは天国の味がする…"

    # say L228 gra
    old "I need to purify my soul with your holy milk."
    new "私はあなたの聖なるミルクで魂を清めなくてはならないの。"

    # say L251 pla
    old "Sister Grace... I- I-"
    new "グレース姉さん… 俺- 俺-"

    # say L252 gra
    old "Oh yeah! I want to feel that grace in my mouth-"
    new "あहゃहゃहゃ！あなたの恵みを私の口で感じたいのよ-"

    # say L268 gra
    old "Ahhhhhh!!! I can feel the greatness of your body inside me..."
    new "アァAAAA！！！ あなたの身体の素晴らしさが中から感じられる..."

    # say L273 gra
    old "I wanted this so badly... There is no pain I can't bear for God."
    new "この瞬間をどれほど待ち望んでいたか… 神のために耐えられない苦しみなんてありません。"

    # say L274 gra
    old "Harder! Harder! I want you to make me feel more pain!"
    new "もっと強く！もっと強く！もっと痛みを感じさせてください！"

    # say L279 gra
    old "Ahhhhhh! Ahhhhh! Ahhh!"
    new "アアアアアア！アアアアアア！アアア！"

    # say L280 gra
    old "My soul needs as much forgiveness as my body needs punishment."
    new "私の魂は、私の体が罰を必要とするのと同じくらい赦しを必要としています。"


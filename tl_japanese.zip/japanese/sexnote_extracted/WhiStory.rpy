# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/WhiStory.rpy
translate japanese strings:

    # say L9 rub
    old "What the fuck? I just can't believe it!"
    new "何てことだよ、信じられない！"

    # say L10 oli
    old "Ruby please! Just listen to me."
    new "ルビー、お願い！ちょっとだけ聞いてよ。"

    # say L11 rub
    old "Listen, to what?"
    new "何を聞くの？"

    # say L18 rub
    old "What explanation could you possibly have to go around making friends with that loser?!"
    new "そんな負け组と友达になる理由がどこにあるの？！"

    # say L19 oli
    old "You don't understand, I need his help, my grades have been low."
    new "分かってないよね、彼の助けが必要なの、成績が悪くて。"

    # say L20 oli
    old "So, he's going to help me study for my tests. If he doesn't I'll fail my classes."
    new "だから、テストの勉強を手伝ってくれるの。手伝ってもらわないと留年しちゃうんだよ。"

    # say L21 rub
    old "And? Who cares?! You can't just hang out with that disgusting nerd!"
    new "で？誰が気にしてるのよ！そんな汚らしいオタクと遊ぶなんてダメよ！"

    # say L22 rub
    old "Listen, you better find another way other than spending time with that loser."
    new "君、そのクソ野郎と過ごす以外の方法を見つけなきゃならないわ。"

    # say L23 oli
    old "B- b- but..."
    new "でも、でも！待って！"

    # say L27 rub
    old "Ugh, look at that, now the fucking nerds are even eavesdropping our conversations."
    new "うっせえ、見てよ、今度はクソオタクまで私たちの会話を盗み聞きしてるんだよ。"

    # say L33 oli
    old "But Ruby! Wait!"
    new "でもルビー！待って！"

    # say L48 pla
    old "Oh hey Mike, what's up?"
    new "おっす、マイク、どうした？"

    # say L49 mik
    old "Hmph..."
    new "ふん…"

    # say L62 bel
    old "Hmm, that was weird."
    new "Hmm、変な感じだったわ。"

    # say L63 pla
    old "Yeah, it was. What's up with him, is he angry about something?"
    new "そうだな、変だったな。彼に何か怒ってることがあるのか？"

    # say L65 bel
    old "Well, now that you mention it. He's been acting odd recently."
    new "そう言われてみれば、最近妙な感じをしているわね。"

    # say L66 bel
    old "I don't really know why though."
    new "でも、なぜなのかはよくわからないの。"

    # say L68 pla
    old "Hmm, I see. I guess I'll have to speak with him."
    new "うん、そうか。なら、話してみるか。"

    # say L69 bel
    old "I think so. He'll probably tell you what's his deal."
    new "そうよ。彼はきっとあなたに自分の事情を話すでしょう。"

    # say L70 pla
    old "Yeah, well, see you later then."
    new "じゃあ、また後でな。"

    # say L90 whi
    old "Oh hi [pla]!"
    new "あら、こんにちは[pla]！"

    # say L91 whi
    old "Uhh, what a nice surprise...It's so good to see you, how are you?"
    new "あら、何だか嬉しいサプライズですね…お会いできて嬉しいです、お元気ですか？"

    # say L92 pla
    old "Hi Mrs. White, nice to see you."
    new "こんにちは、ホワイトさん、お会いできて嬉しいです。"

    # say L93 pla
    old "Hey, I came looking for Mike, is he around? I wanted to talk to him."
    new "Hey、マイクを探して来たんだ。いるか？話したいことがあるんだ。"

    # say L94 whi
    old "Hmm, well, he is here, but... I don't think he wants to see you."
    new "うーん、ええ、彼はいますけど……会いたくないって言ってるみたいですね。"

    # say L95 pla
    old "Really, why?"
    new "本当にか？なぜ？"

    # say L96 whi
    old "Well, he's been a little... Uhh, unwell these past few days, so he doesn't really want to talk to anybody."
    new "うーん、彼はここにいるんですが… 最近ちょっと体調が悪くて、誰とも話したくないみたいです。"

    # say L98 pla
    old "Unwell? Is he ok?"
    new "体調不良？大丈夫なのか？"

    # say L100 whi
    old "He's fine, but... Uhh, not really in a good mood."
    new "大丈夫だけど、うーん、気分がよくないみたいね。"

    # say L101 pla
    old "Hmm, is there something I can help with?"
    new "ん、何か手伝えることはあるのか？"

    # say L103 whi
    old "Listen, he asked me not to tell anybody about this. But since you're one of his best friends I'll let you know."
    new "彼は私に誰にも言わないようにって頼まれたの。でもあなたは彼の親友だから、知らせてあげるわ。"

    # say L105 whi
    old "The thing is, his birthday was a couple of days ago... and nobody seemed to remember."
    new "実は、彼の誕生日が数日前だったの……でも誰も覚えていなかったみたいね。"

    # say L106 pla
    old "Ohhh, damn! I totally forgot about it. Shit!"
    new "オーッ、しまった！全然忘れていたよ。クソ！"

    # say L107 whi
    old "Yes well, not one of his friends gave him a call, or even said happy birthday to him."
    new "はい、彼の友達の誰も彼に電話をかけなかったし、お誕生日おめでとうとも言わなかったんです。"

    # say L108 pla
    old "Damn it, of course, he's angry."
    new "くそ、当然彼は怒っているに決まってる。"

    # say L109 whi
    old "The reason I tell you this is because Mike is always talking about you, he says you're his best friend."
    new "私がこれをあなたに言うのは、マイクがいつもあなたのことばかり話しているからです。彼はあなたを最高の友達だと言っています。"

    # say L112 whi
    old "He admires you a lot, you know..."
    new "彼はあなたを本当に尊敬していますよ…"

    # say L113 pla
    old "D- do you think he'll talk to me if I try?"
    new "もし俺が話しかけたら、彼は話してくれるかな？"

    # say L114 whi
    old "Hmm, I don't really know... But I guess you can try. I actually think it would be good for him."
    new "Hmm、私にはよくわからないけど……でも、試してみるといいかもしれないわ。実際、彼にとって良いことだと思うの。"

    # say L115 whi
    old "He's been really depressed lately. So, it would be good if you could help him out with that."
    new "最近、彼はとても落ち込んでいるんです。だから、あなたが彼を助けてあげられると良いですね。"

    # say L117 pla
    old "Sure, sure, don't worry, I'll do my best to fix this."
    new "大丈夫、大丈夫、心配しないで、俺が全力で直すよ。"

    # say L118 whi
    old "Ok,  then he's in his room. Good luck."
    new "では、彼は部屋にいます。頑張ってくださいね。"

    # say L133 mik
    old "Ugh, did my mom let you in?"
    new "うげえ、母さんが君を入れたのか？"

    # say L134 pla
    old "Hey man, listen, I'm really sorry. I've been dealing with some stuff, so, I forgot about your birthday."
    new "おい、聞いてくれ、ほんと申し訳ない。色々あってさ、君の誕生日のこと忘れちゃった。"

    # say L135 pla
    old "But I totally care about it, really."
    new "でも本当に関ってるぞ。"

    # say L136 mik
    old "Oh yeah, you care?"
    new "おう、本当に気にしてるのか？"

    # say L137 mik
    old "That's funny, you seem to care a lot more about the girls' birthdays..."
    new "おもしろいね、君は女の子たちの誕生日のことの方がずいぶん気にしてるみたいだな…"

    # say L138 mik
    old "But I guess it's no surprise since I'm always the one who's left out..."
    new "でも、いつも俺が置いてけぼりにされるのは驚かないよ。"

    # say L139 pla
    old "Aww, come on dude, you know it's not like that."
    new "あー、COME ON、そんなことないって。"

    # say L140 pla
    old "It's just that recently I've been kinda busy."
    new "最近ちょっと忙しくてさ。"

    # say L141 mik
    old "Yeah, yeah, yeah, you're always busy. I get it, you're Mr. important."
    new "うんうん、忙しいっていつも言ってるじゃん。分かってるよ、お前は偉い男だね。"

    # say L142 pla
    old "Hey Mike, come on man, listen to me."
    new "マイク、おい、ちょっと聞いてくれよ。"

    # say L143 mik
    old "No! You listen. It's just unbelievable man, like, wow."
    new "いいえ！俺の言うことを聞け。ほんと信じられないよ、マジで。"

    # say L144 mik
    old "You know, I've always been there for you when you needed it!"
    new "知ってるだろ、お前が困ったときいつも俺がいたんだよ！"

    # say L146 pla
    old "I know dude, I'm sorry."
    new "知ってるよ、ごめん。"

    # say L148 mik
    old "You know what? It's ok, it's not like it's the first time anyway. So I'm used to it. I really don't have any friends."
    new "知ってるよ？大丈夫、初めてじゃないしな。だから慣れてるよ。本当に友達なんていないけど。"

    # say L149 pla
    old "Hey don't say that, you know very well I'm your friend."
    new "Hey、そんなこと言わないで、お前が友達だってことは分かってるよ。"

    # say L150 pla
    old "And what do you mean it's not the first time, it was just this year that I forgot your birthday."
    new "何を言ってんだよ、初めてじゃないってどういう意味だ？今年こそは誕生日を忘れちゃったけどさ。"

    # say L151 mik
    old "Oh shut up! I'm not talking about my birthday. Remember Halloween?"
    new "おう、黙れ！俺が言ってるのは誕生日のことじゃないんだ。ハロウィンのことを覚えてるか？"

    # say L152 mik
    old "When we were playing that game you guys made fun of me. And had me leave with that stupid challenge."
    new "あのゲームでみんなにからかわれて、バカなチャレンジで帰されちゃったんだよ。"

    # say L153 mik
    old "Of course, you didn't want me there."
    new "もちろん、お前は俺がいなきゃ困るだろ。"

    # say L156 pla
    old "Listen dude..."
    new "聞くよ、お前..."

    # say L157 mik
    old "Shut up! Keep your excuses to yourself."
    new "黙れ！言い訳は自分でしとけ。"

    # say L158 mik
    old "And get the hell out of here. I'm busy."
    new "とっととここから消えてくれ。忙しいんだよ。"

    # say L159 pla
    old "Mike, please, calm down."
    new "マイク、落ち着いてくれ。"

    # say L160 pla
    old "Thinking about it, I can see your point, you're absolutely right."
    new "考えてみれば、君の言うことも理解できる。完全に正しいな。"

    # say L161 pla
    old "I've been a really shitty friend."
    new "俺、本当にクソ友達だったな。"

    # say L162 pla
    old "So... I'm really sorry bud, and I hope you can forgive me."
    new "だから... 本当に申し訳ないよ、友達。許してくれ。"

    # say L163 mik
    old "Pfff! Get out of here!"
    new "プッ！出ていけ！"

    # say L164 mik
    old "Do you really think you can get out of this with a simple apology?"
    new "簡単な謝罪で済むと思ってるか？"

    # say L165 pla
    old "Hmm... You're right... And I think I can do something to show you I'm your friend."
    new "うーん……君の言う通りだな……でも、友達だって証明できる方法があると思うんだ。"

    # say L166 pla
    old "And this is kinda risky, so I know you'll believe me once you see it."
    new "これちょっとリスキーだけど、見せたら信じるだろう。"

    # say L169 pla
    old "Come with me for a second."
    new "ちょっと来てくれ"

    # say L170 mik
    old "Where?"
    new "どこ？"

    # say L171 pla
    old "I have to show you something."
    new "見せなきゃならないことがあるんだ。"

    # say L172 pla
    old "Just shut up and come with me."
    new "黙ってついて来い。"

    # say L173 pla
    old "If afterwards you're still mad at me I'll leave you alone."
    new "その後も俺のこと恨んでるなら、一人にしてあげるよ。"

    # say L174 pla
    old "But this is worth it."
    new "でもこれだけは価値があるよ。"

    # say L176 mik
    old "Hmm, ok, let's go."
    new "うん、いいよ、行こう。"

    # say L192 mik
    old "What's this? Where are you taking me?"
    new "何これ？どこ連れて行くの？"

    # say L193 pla
    old "It's ok dude. Just trust me, you'll like this."
    new "大丈夫だよ、信じて。気に入るさ。"

    # say L218 mik
    old "What the fuck? This is my neighbor's house. What are we doing here?"
    new "何てことだよ？これは隣の家の前だぞ。ここに来るのは何なのか？"

    # say L219 pla
    old "Chill out dude. It's ok, I know her."
    new "落ち着けよ、大丈夫、知ってるんだ。"

    # say L220 pla
    old "Just as I thought, If she's not here, that means she'll be probably with a customer upstairs."
    new "思った通りだな。彼女がここにいなければ、多分上の部屋で客と一緒だろう。"

    # say L223 pla
    old "I think I can show you something worthwhile. Just hush and follow me."
    new "俺が見せるものがあると思う。黙ってついて来い。"

    # say L247 pla
    old "Great, they're in there."
    new "よし、いるじゃねえか。"

    # say L248 mik
    old "They? What's happening?"
    new "彼ら？何が起こってるんだ？"

    # say L249 pla
    old "Listen man, this is something I'm doing only this one time."
    new "聞いてくれ、これは一回きりのことでな。"

    # say L250 pla
    old "Take it as my birthday gift to you."
    new "これを誕生日プレゼントと思ってくれ"

    # say L251 pla
    old "Now come here and take a peek."
    new "今こっち来て、ちょっと覗いてみろ。"

    # say L260 mik
    old "Dude! Wow!"
    new "お前！すげえ！"

    # say L261 mik
    old "I would never have been able to see this through my telescope!"
    new "この望遠鏡じゃ決して見られなかったよ！"

    # say L262 mik
    old "How did you know she does this kind of stuff?"
    new "どうやって彼女がこんなことするって知ったんだ？"

    # say L263 pla
    old "Just shut up and enjoy it."
    new "黙って楽しめよ。"

    # say L264 mik
    old "I will man, you're the best."
    new "俺が言うじゃねえか、お前最高だよ。"

    # say L274 mik
    old "Dude, that was the best birthday present ever!"
    new "おい、これが今までで一番の誕生日プレゼントだったよ！"

    # say L275 pla
    old "Well, I'm glad you liked it."
    new "まあ、君が気に入ったなら嬉しいよ。"

    # say L276 pla
    old "I just wanted to say sorry again for being such a lousy friend."
    new "ただ、こんなに最悪な友達だったことまた謝りたいんだ。"

    # say L277 pla
    old "And listen, man, I know you think you're all alone, but that's not true."
    new "でもな、お前が一人ぼっちだって思ってるけど、そうじゃないんだ。"

    # say L278 pla
    old "I really do think of you as my best friend, and I'm sure the girls... Uhh, they find you as a good classmate..."
    new "お前を本当の親友だと思ってるんだ、そして女子たちも……うーん、お前を良いクラスメイトだって思ってるはずさ。"

    # say L279 pla
    old "It's just that lately we all have been dealing with some stuff."
    new "最近はみんなそれぞれに抱えていることがあるんだ。"

    # say L280 pla
    old "But I want you to know that I would never take you for granted."
    new "でも、君が大切なことは決して忘れねえよ。"

    # say L282 mik
    old "It's ok man, I was angry, but you've more than made up for it with that awesome gift."
    new "大丈夫だよ、怒ってたけど、その超クールなプレゼントで十分補われたから。"

    # say L283 mik
    old "It was so fucking rad."
    new "それがめちゃくちゃかっこよかったよ。"

    # say L284 pla
    old "Well I'm happy we're ok now. But I kinda have to leave."
    new "よし、仲直りできて良かったけど、ちょっと出かけなきゃな。"

    # say L285 pla
    old "I have to do a couple of things, but I'll swing by later."
    new "いくつか用事があるんだが、後で寄るよ。"

    # say L286 mik
    old "Wait, Dude!"
    new "待って、ダチ！"

    # say L288 mik
    old "Before you leave, there's something I have to ask you."
    new "待ってくれ、Dude！出る前に聞いておくことがあって。"

    # say L289 pla
    old "Hmm, sure, tell me."
    new "うん、いいよ、何でも言え。"

    # say L290 mik
    old "Hmm, the thing is... I don't really know how to say this..."
    new "うーん、実はね…どう言ったらいいかわかんないんだけど…"

    # say L291 mik
    old "I'm gonna need you to help me study for a subject..."
    new "俺、ある科目の勉強を手伝ってほしいんだ…"

    # say L292 pla
    old "What? Haha! But you've never wanted to study with us before."
    new "何？ははは！でも今まで一緒に勉強したいって言ったことなかったじゃん。"

    # say L293 pla
    old "Why now all of a sudden?"
    new "急に何で？"

    # say L295 mik
    old "It's because it's super lame."
    new "それは超ダサいからだよ。"

    # say L296 mik
    old "But you see, this time is not really for me."
    new "でもさ、今回は俺のためじゃなくて。"

    # say L297 mik
    old "I told Olivia I would help her with her studies, so I kinda have to learn the subject."
    new "オリアンナに勉強を手伝うって約束したから、ちょっとこの科目を勉強しないとね。"

    # say L298 pla
    old "Oh, really? Hahahahahaha!"
    new "お、本当か？ははははは！"

    # say L299 mik
    old "Dude! Don't laugh, this is important, ok?"
    new "おい！笑うな、これは本気なんだよ。"

    # say L300 pla
    old "Heh, s- sure, sorry."
    new "へへ、そ、そうだね。すみません。"

    # say L302 mik
    old "Well anyway, the point is that I'm gonna need your help to learn the subjects."
    new "まあ要するに、俺が科目を学ぶために君の手伝いが必要だってことだ。"

    # say L303 mik
    old "'Cause you'll help me out, right? I mean, we're friends..."
    new "だって手伝ってくれるよね？ 俺たち友達だしね..."

    # say L304 pla
    old "*Sigh*"
    new "*ため息*"

    # say L305 pla
    old "I mean, sure, if you really need it I'll help you out."
    new "まあ、本当に必要な時は手伝うよ。"

    # say L306 pla
    old "But dude, isn't she always super mean to us?"
    new "でも、あの子っていつも俺たちに超キツくない？"

    # say L307 pla
    old "You've heard the way she and Ruby talk to us."
    new "お前もheard the way彼女とルビーが俺たちに話しかける様子を聞いたことがあるだろ。"

    # say L308 pla
    old "Like... You know?"
    new "Like... 知ってるよな？"

    # say L309 mik
    old "I know, I know. But the thing is..."
    new "知ってる、知ってる。でも問題があってね、"

    # say L310 mik
    old "I actually like that, a lot if I can be honest."
    new "実際、それが好きなんだよ、正直に言うとね。"

    # say L311 pla
    old "What? Are you for real right now?"
    new "何？今マジで言ってんの？"

    # say L312 pla
    old "What could you possibly like about that?"
    new "何が気に入ったっていうんだ？"

    # say L313 mik
    old "To be honest, I don't know why, but I love it when girls are mean to me. It's so hot!"
    new "正直、理由はわからないけど、女の子にキツく言われるのが好きなんだ。超エロいんだよ！"

    # say L314 mik
    old "Mmm, even the other day when they were insulting us in the hallway."
    new "うん、先日も廊下で𠮟り倒されてたときも、めちゃくちゃ興奮したんだ。"

    # say L315 mik
    old "Uhh man, I almost got a hard-on!"
    new "うわ、マジで硬くなっちゃいそうだったよ！"

    # say L317 pla
    old "Ok, I get it, you're a freak. But it's fine I guess."
    new "分かった、お前は変態だな。でもまあ、仕方ないか。"

    # say L318 pla
    old "Ok man, I guess I can help you, I'm not sure what you need exactly though."
    new "分かったよ、手伝うけど、具体的に何が必要か教えてくれ。"

    # say L319 mik
    old "Well, I have to give her classes on those subjects. So, something that will help me with that."
    new "俺は彼女にその科目の授業をしなきゃならないんだ。だから、それを手助けしてくれる何かが必要なんだ。"

    # say L320 pla
    old "Hmm, I think I know what we can do."
    new "うん、何か思いついたぞ。"

    # say L321 pla
    old "How about I give you the classes, and you just repeat them to Olivia?"
    new "じゃあ、俺が授業をして、お前はそれをオリビアに繰り返すってのはどうだ？"

    # say L323 mik
    old "Ohh, that sounds perfect."
    new "オッ、それならぴったりだな。"

    # say L324 pla
    old "But, you're gonna have to pay a lot of attention to everything I tell you."
    new "でも、俺が言うこと全部にちゃんと注意してないとダメだぞ。"

    # say L325 pla
    old "After all it won't be useful if she asks you a question and you can't answer ir properly."
    new "まあ、質問されたのに答えられなかったら意味ないしな。"

    # say L326 mik
    old "Sure, sure, sure. No problem man, I'm sure I'll learn it all."
    new "わかった、わかった、わかった。問題ないよ、ぜったい全部覚えられるさ。"

    # say L328 pla
    old "Well, with that sorted out, I'll go home. And we can meet after class to study."
    new "じゃあ、それじゃ、俺は家に帰るよ。授業後にはまた会って勉強しよう。"

    # say L330 mik
    old "No problem. Thank you so much dude! You're the best."
    new "問題ないよ。本当にありがとう、お前が最高だ。"

    # say L332 pla
    old "Yeah, yeah, but don't be so quick to thank me. We don't know if this will work."
    new "まあ、まあ、でも急に感謝されてもな。これでうまくいくかどうかまだわからんけど。"

    # say L333 mik
    old "I'll do my best, I promise!"
    new "頑張るよ、約束する！"

    # say L334 pla
    old "Alright, see you later."
    new "じゃあ、またね。"

    # say L360 whi
    old "Hi [pla]! How are you? It's so nice to see you."
    new "こんにちは、[pla]！お元気ですか？お会いできてうれしいわ。"

    # say L361 pla
    old "Hi Mrs. White, nice seeing you too."
    new "白さん、お会いできて嬉しいです。"

    # say L362 whi
    old "Let me tell you something. I don't know what you said to Mike."
    new "私に何か教えてあげるわ。あなたがマイクに何を言ったのか知らないけど。"

    # say L363 whi
    old "But since you two talked, he's been in a much better mood. Thank you so much for that."
    new "でも二人で話してから、マイクの気分がずいぶん良くなったわ。本当に感謝してる。"

    # say L364 pla
    old "No problem, I'm happy we got to sort things out."
    new "全然問題ないよ、話せて良かった。"

    # say L365 whi
    old "You did a great job."
    new "あなたはとてもよくやったわ。"

    # say L366 whi
    old "So good that I've been thinking maybe I should give you a small reward."
    new "あたし、ちょっとあなたにご褒美をあげたくなっちゃったのね。"

    # say L367 pla
    old "Oh, I appreciate it, but you really don't have to."
    new "ああ、感謝してるけど、特に何もする必要はないよ。"

    # say L368 pla
    old "I was just trying to be a good friend, and help him out."
    new "ただ友達として彼を助けてあげようと思っただけだ。"

    # say L369 pla
    old "Also, I don't want it to be of any trouble."
    new "それに、君に迷惑をかけたくないな。"

    # say L370 whi
    old "Oh, but it's no trouble sweety, you've been very good to Mike."
    new "あら、でも全然問題ありませんよスイート、あなたはマイクのためにとてもよくしてくれました。"

    # say L371 whi
    old "And I believe that deserves a good reward."
    new "そして、それには良い報酬がふさわしいと思います。"

    # say L372 pla
    old "Uhh, I'm very thankful Mrs. White, but I think I'm ok."
    new "うーん、とても感謝しています、ホワイトさん。でも、大丈夫ですよ。"

    # say L373 pla
    old "And... uh, I kinda have to go study with Mike now, so..."
    new "あの… うーん、今からマイクと勉強しなきゃいけないんで…"

    # say L374 whi
    old "Hmm, yeah, that's right, you two have to study. Go ahead."
    new "そうですよね、二人で勉強しなきゃならないわ。行ってらっしゃい。"

    # say L375 whi
    old "In the meantime I'll think of something."
    new "その間は何か考えますね。"

    # say L376 whi
    old "And I'm sure you'll love it."
    new "そしてきっと気に入ってくれるわね。"

    # say L377 whi
    old "I see you later sweety."
    new "またね、スイート-heart."

    # say L378 pla
    old "See you later Mrs. White."
    new "またね、ホワイト夫人。"

    # say L388 mik
    old "[pla] dude! Hi!"
    new "[pla] だよ！元気？"

    # say L389 mik
    old "Did you come to study?"
    new "勉強しに来たのか？"

    # say L390 pla
    old "Yeah dude, I figured you'd want to start as soon as possible."
    new "そうだな、早めに始める方がいいと思ったんだ。"

    # say L391 mik
    old "For sure, my first session with Olivia's coming soon."
    new "そうだよ、オリビアとの最初のセッションが近いんだ。"

    # say L392 mik
    old "And I don't know shit about the subject."
    new "俺はその話題について何も知らないんだ。"

    # say L393 pla
    old "Don't you say..."
    new "言うなよ..."

    # say L394 pla
    old "But that's why I'm here, so let's get to it."
    new "でもそのため俺がいるんだから、さっそく始めよう。"

    # say L396 mik
    old "Let's do it dude..."
    new "じゃあ、やるぞ兄貴…"

    # say L410 whi
    old "Oh, [pla]! Did you and Mike finish already? How did it go?"
    new "Oh、[pla]！マイクとあなたはもう終わったの？どうだったの？"

    # say L411 pla
    old "That's right Mrs. White, we actually progressed quite a bit."
    new "そうですよ、ホワイト夫人。かなり進展しましたよ。"

    # say L412 pla
    old "Mike has been putting in quite some effort to study, so he caught the lesson really quick."
    new "マイクは勉強にかなり力を入れていて、授業の内容をすぐに理解したんだ。"

    # say L414 whi
    old "But wait, leaving so soon?"
    new "でも、そんなに早く帰るの？"

    # say L415 pla
    old "Well, yeah, since we're done, and it's getting kinda late."
    new "まあ、そうですね、授業も終わったし、時間も遅くなってきましたから。"

    # say L416 pla
    old "I thought it would be better to go home."
    new "家に帰るのが良いと思ったんだ。"

    # say L418 whi
    old "Oh no, no, no. I just finished making dinner. Stay and have dinner with us."
    new "あらあら、そんなに急がなくても。今ちょうど夕飯を作り終わったところなの。一緒にご飯を食べませんか。"

    # say L420 pla
    old "Hmm, I don't know Mrs. White, I'm very thankful, but I don't want it to be of any trouble."
    new "うーん、ホワイトさん、本当に感謝してるんだけど、迷惑かけたくはないな。"

    # say L421 whi
    old "Don't be silly"
    new "馬鹿なこと言ってないでくださいよ"

    # say L422 whi
    old "It's only an extra plate, besides you must be tired from studying with Mike."
    new "追加の皿くらいのことよ、それにマイクと勉強して疲れているでしょう。"

    # say L423 whi
    old "And you've been so good, not only did you talk to Mike when he was angry."
    new "そして、あなたはとても良い子で、マイクが怒っているときも彼と話してくれましたよね。"

    # say L424 whi
    old "You're also helping him study."
    new "あなたは彼の勉強を手伝ってくれてるんですから。"

    # say L425 whi
    old "The least I can do is invite you to have some dinner with us."
    new "私がするべきことは、あなたを夕食に招待することでしょう。"

    # say L426 whi
    old "I can't just let you leave like that."
    new "そんな風に帰らせるわけにはいきませんよね。"

    # say L433 mik
    old "Hey, mom, I'm hungry. It's dinner ready?"
    new "お母さん、お腹空いた。夕飯は Ready？ ではなく、できてる？に変更する必要があります。"

    # say L435 mik
    old "Oh [pla], you're still here?"
    new "おっ [pla]、まだここにいるのか？"

    # say L436 whi
    old "Dinner's ready honey, I was just telling your friend that he should stay for it."
    new "ご飯の準備ができてるわ、親愛なる人。友達にも一緒に食べさせてあげなさいね。"

    # say L437 mik
    old "For sure dude! You should totally stay."
    new "絶対だぜ！君は絶対に残った方がいいよ。"

    # say L438 mik
    old "My mom makes the best pot roast you'll ever try, trust me you'll like it."
    new "俺のママが作るポットローストは最高だよ、絶対気に入ってくれるさ。"

    # say L439 whi
    old "Oh he's gonna love it."
    new "あら、きっと気に入ってくれるわね。"

    # say L441 pla
    old "All right, if you insist, I can't say no..."
    new "よし、そう insistence と言うなら断るわけにもいかないな…"

    # say L442 pla
    old "Thanks a lot Mrs. White, I really appreciate it."
    new "ありがとうございます、ホワイト夫人。本当に感謝しています。"

    # say L443 mik
    old "Let's go then!"
    new "それじゃ、行こう！"

    # say L457 whi
    old "So tell me, how are your studies going? And your grades?"
    new "それじゃ、お勉強はどうですか？ 成績はいかがでしょうか？"

    # say L458 whi
    old "I hope everything's going well with your exams."
    new "試験は順調にいっているといいですね。"

    # say L459 mik
    old "Well, Belle and I are doing well on our end of term project."
    new "ベールと俺は期末プロジェクトで好調だよ。"

    # say L460 mik
    old "She's really smart, and has helped me a lot with that."
    new "彼女は本当に頭がよくて、そのプロジェクトで俺を助けてくれたよ。"

    # say L464 mik
    old "Oh right [pla], you did yours with Hin, right?"
    new "ああそうか [pla]、お前はヒンとやってたんだな？"

    # say L465 mik
    old "How did that go?"
    new "どうだったんだ？"

    # say L467 pla
    old "Uhh... W- well, it went really... well."
    new "うーん… まあ、かなり… 上手くいったよ。"

    # say L468 pla
    old "Really well actually, Hin is a very good student, so we flew through it."
    new "本当に良かったよ、ヒンは優秀な生徒だから、すぐこなせた。"

    # say L470 mik
    old "Uh, that makes sense, of course she would do a good job."
    new "うん、そうさ、当然の話だよ。"

    # say L471 mik
    old "Specially since she's so into you."
    new "特に君のこと好きだからな。"

    # say L474 mik
    old "Please dude, don't play fool, she's sooo got a thing for you."
    new "Dude、馬鹿らしくないか、彼女はお前のことめっちゃ意識してるじゃん。"

    # say L475 pla
    old "I don't know what you're talking about, we're just friends..."
    new "何言ってるんだよ、ただの友達ってことだよ..."

    # say L476 whi
    old "Hinn is Jade's daugther, right? She's such a nice, smart girl."
    new "ヒンはジェイドの娘さんですよね？とても良い子で、頭も良いわ。"

    # say L477 whi
    old "Are you two dating?"
    new "あなたたち、お付き合いしているの？"

    # say L479 pla
    old "No, we're not. Mike's just messing with me."
    new "いいえ、そうではありません。マイクがただからかってるだけです。"

    # say L480 mik
    old "Come on, she totally likes you..."
    new "おい、彼女は君のことが全然好きだってばよ。"

    # say L483 pla
    old "She's just a good friend. That's all there is to it."
    new "ただの良い友達だよ。それだけのことさ。"

    # say L485 whi
    old "Hmm, I see [pla] is a total succes with girls, isn't he?"
    new "Hmm、[pla]は女の子たちに大人気なんですね、そうですね？"

    # say L486 mik
    old "Only Hin."
    new "ただヒンだけさ。"

    # say L487 mik
    old "I don't know what she see's in you dude."
    new "俺にはわかんないけど、君が彼のどこを見つけるのかな。"

    # say L489 whi
    old "Oh, but he's a total heartthrob."
    new "あら、でも彼は完全なイケメンですよ。"

    # say L490 whi
    old "Hin's very bright for liking you [pla]."
    new "ヒンがあなたのことが好きだって、ずいぶん賢明ね [pla]。"

    # say L491 pla
    old "Uhhh, yeah... yeah she's really smart, but just a good friend."
    new "うーん、そうだな… 僕とヒンはただの友達だよ。でも、彼女は本当に頭がいい。"

    # say L493 whi
    old "I see, that's very good."
    new "そうですか、それは良いですね。"

    # say L494 whi
    old "By the way what are your projects about?"
    new "それとも、あなたのプロジェクトはどのようなものですか？"

    # say L495 mik
    old "Ugh, some online content creation thing Belle said we should do."
    new "うーん、ベッリーが言うんだよ、オンラインで何かコンテンツ作成するってやつさ。"

    # say L496 mik
    old "It's a research project."
    new "研究プロジェクトだ。"

    # say L497 mik
    old "She's very into those subjects."
    new "彼女はその手の話題にめちゃくちゃハマってるんだ。"

    # say L498 whi
    old "And you [pla]? What are you and your friend Hin doing?"
    new "そしてあなた [pla]？あなたとヒンくんはどんなことをしているの？"

    # say L499 pla
    old "We... Uhh, we have a psychology project."
    new "俺たち… うーん、心理学のプロジェクトをしてるんだ。"

    # say L500 pla
    old "About personal development and self confidence and stuff."
    new "個人の成長や自己信頼についてのものさ。"

    # say L502 whi
    old "Oh, I see, interesting."
    new "なるほど、興味深いですね。"

    # say L509 whi
    old "It sounds like a very, very HARD subject."
    new "それはとてもとても難しいテーマですね。"

    # say L510 pla
    old "I- it kind of is..."
    new "うーん、そうかもな…"

    # say L529 whi
    old "I imagine you must be working very very... hard."
    new "想像すると、あなたはとてもとても…頑張っているんですね。"

    # say L531 mik
    old "Yes, we really are."
    new "はい、本当にそうです。"

    # say L544 pla
    old "The food was delicious Mrs. White, thanks a lot."
    new "白さん、お食事ありがとうございました。"

    # say L545 pla
    old "But it's getting kinda late. So, if you'll excuse me I should go home."
    new "でも、もう遅いので、失礼します。家に帰ります。"

    # say L546 pla
    old "But I'll be back soon to keep studying, Mike."
    new "でもすぐに戻って勉強しに来るから、マイク。"

    # say L547 whi
    old "That's ok sweety, I'm glad to hear you liked dinner."
    new "それはいいの、スイートピー。ディナーを気に入ってくれてうれしいわ。"

    # say L548 whi
    old "And I'm also glad you had a good time."
    new "そしてあなたが楽しんでくれたのも嬉しいです。"

    # say L549 pla
    old "Yes, it was... very good. You've got marvelous hands Mrs. White... For the kitchen of course..."
    new "はい、それは…とても良かったです。白さん、手が素晴らしいですね…もちろん、キッチンでのことですよ。"

    # say L550 whi
    old "You should stay for dinner more often.."
    new "もっとよく夕食を食べに来てくださいね。"

    # say L551 whi
    old "So, you don't have to worry about coming here, and spending all the time you want."
    new "なので、ここに来る心配はいりませんわ。好きなだけ時間を使ってください。"

    # say L552 pla
    old "Thanks a lot Mrs. White, that's very kind of you."
    new "ありがとうございます、ホワイトさん。とても親切なご配慮をありがとうございます。"

    # say L553 whi
    old "I'm always happy to have some extra company here. And you know you're more than welcome."
    new "こちらに来てくれるのはいつでも嬉しいわ。あなたがいつでも歓迎であることは知っててよ。"

    # say L554 pla
    old "Uhh, sure, thank you."
    new "うーん、そうですね、ありがとうございます。"

    # say L555 pla
    old "I think I should go now."
    new "今帰る方がいいと思う。"

    # say L557 whi
    old "Get home safe. See you later sweetie."
    new "お家に安全に帰ってね。またね、甘いの。"

    # say L559 mik
    old "Later dude."
    new "後でな、お兄さん。"

    # say L560 pla
    old "Ok, bye..."
    new "Ok、バイ..."

    # say L577 mik
    old "[pla] dude! Hi! What's up?"
    new "[pla] だよ！元気？"

    # say L578 mik
    old "Did you come to help me study?"
    new "手伝いに来たのか？"

    # say L579 pla
    old "Yeah dude, that's right."
    new "そうだよ、その通りだ。"

    # say L580 mik
    old "Oh thank god, my next session with Olivia's coming soon."
    new "おお、神様ありがとうございます。次のオリビアとのセッションが近づいてるんだ。"

    # say L581 mik
    old "And I was getting worried, because I'm not ready for her class."
    new "心配してた、彼女の授業にまだ準備できとらんからね。"

    # say L582 pla
    old "Well that's why I'm here. Are you ready to start?"
    new "それだから俺がここにいるんだ。準備はできてるか？"

    # say L583 mik
    old "Yeah I'm ready, let's do this!"
    new "よし、準備はできてる、始めよう！"

    # say L594 pla
    old "Wow! Dude! You got it right! I didn't know you were so good at this!"
    new "おわっ！お前、正解したぞ！俺、お前がこんなに上手いとは思わなかったよ！"

    # say L595 pla
    old "I mean, if you studied like that more often you'd have straight A's."
    new "まあ、そんな風に勉強すれば全教科優等だな。"

    # say L596 mik
    old "Hehe, thanks man, I've tried to pay attention to what you've taught me."
    new "へへ、ありがとうな。教えてくれたことはちゃんと意識してきたぜ。"

    # say L597 mik
    old "So that I can teach it to Olivia."
    new "そうやってオリビアに教えてやるんだ。"

    # say L598 pla
    old "Well I'm sure it's gonna go great if you keep going like that."
    new "まあ、その調子で続けばきっとうまくいくさ。"

    # say L599 pla
    old "So, listen dude, it's getting kinda late, so, I should go home."
    new "よし、聞いてくれ。だいぶ遅くなってきたから、俺は帰るよ。"

    # say L600 pla
    old "But I'll be back before your next session with Olivia."
    new "でも次のオリビアとのセッションの前に戻ってくるよ。"

    # say L602 mik
    old "Sure man, thanks a lot. See you later."
    new "もちろん、ありがとう。またね。"

    # say L652 mik
    old "Damn, I'm sorry dude. I suck at this so much."
    new "俺、すまん。全然ダメだな。"

    # say L653 mik
    old "I think I'm just wasting your time."
    new "俺が時間だけ無駄にしてるな。"

    # say L654 pla
    old "Nah, it's ok, this isn't an easy topic anyway."
    new "Nah、大丈夫だよ。この話題は簡単じゃないしな。"

    # say L655 pla
    old "We still got some time before you have to teach Olivia. So let's just relax."
    new "まだオリビアに教える時間があるさ。だからちょっとリラックスしよう。"

    # say L656 mik
    old "I can't relax dude! I told Olivia I was gonna teach her and I'm not ready."
    new "リラックスできるわけないだろ！オリアンナに教えるって約束したのに、全然準備できていないんだ。"

    # say L657 pla
    old "I know, man, I know."
    new "分かってるよ、マネ、分かってる。"

    # say L658 pla
    old "I'm sure you'll get it before the day."
    new "大丈夫、きっとその前に準備できるぜ。"

    # say L659 mik
    old "Hmm... You're probably right [pla], sorry I got a little anxious."
    new "うーん…多分君の言う通りだ[pla]、ちょっと焦っちゃった。"

    # say L660 mik
    old "Let's just try again, I'm sure I'll do better this time."
    new "もう一回やってみよう、今度は上手くいくはずだ。"

    # say L662 pla
    old "Nah, I don't think we should keep going today"
    new "今日はもうやめとこうか"

    # say L663 pla
    old "We're already tired, and just forcing this won't help."
    new "もう疲れてるし、無理に続けるのも意味ないよ。"

    # say L664 pla
    old "Besides, it's kinda late, so I think I better go home for now."
    new "それに、もう遅いし、俺は一旦家に帰るよ。"

    # say L665 pla
    old "And we can pick it up another time."
    new "また今度 continuationしよう。"

    # say L667 mik
    old "Sure, you're probably right."
    new "うん、そうかもな。"

    # say L686 whi
    old "Hello [pla] I'm so glad to see you."
    new "こんにちは[pla] 私もあなたに会えて嬉しいです。"

    # say L687 pla
    old "Hi Mrs. White, how are you?"
    new "こんにちは、ホワイト夫人。お元気ですか？"

    # say L688 whi
    old "I'm fine sweetie, and you?"
    new "私は元気です、あなたは元気ですか？"

    # say L690 whi
    old "Let me guess, you came to see Mike, right?"
    new "私が予想通りね、マイクに会いに来たんでしょ？"

    # say L691 pla
    old "That's right, we'd planned another study session for today."
    new "そうだ、今日も勉強の約束してたんだ。"

    # say L692 whi
    old "Well sweetie, I'm sorry to tell you he isn't here."
    new "まあ、お sweetheart、申し訳ありませんが、彼はここにはいません。"

    # say L693 whi
    old "I don't know if he forgot to tell you, but he said he was meeting a girl to study."
    new "彼が教えてくれなかったのかしら、でも彼は女の子と勉強するって言ってたわ。"

    # say L694 pla
    old "Oh right! Damn, I totally forgot about that."
    new "ああ、そうだったか！くそ、完全に忘れてた。"

    # say L695 pla
    old "He did say something about it."
    new "彼はそんなこと言ってたな。"

    # say L696 pla
    old "Well, I guess I'm gonna have to come back later. Please tell him I came by."
    new "じゃあ、後でまた来ることになるな。彼に会いに来たって伝えてくれる？"

    # say L702 whi
    old "But, wait [pla]!"
    new "でも、ちょっと待って [pla]！"

    # say L706 pla
    old "Y- yes?"
    new "ええ？"

    # say L707 whi
    old "Sweetie it would be a shame if you left just after getting here."
    new "スイートピー、来たばかりなのに帰っちゃうのはもったいないわ。"

    # say L708 whi
    old "Why don't you stay for a little while?"
    new "どうして少し滞在しないんですか？"

    # say L709 whi
    old "You can make me some company."
    new "あなたがいてくれると嬉しいですね。"

    # say L711 whi
    old "I actually was about to move around the furniture in my room."
    new "実は私の部屋の家具を移動しようと思っていたんです。"

    # say L712 whi
    old "I could use your help and I thought maybe a big and strong guy like you could help me out."
    new "手伝ってくれると助かるわ。あなたのような大きい方なら、きっと役に立つと思ったの。"

    # say L713 pla
    old "Heh, sure, I can help you out."
    new "へへ、もちろん、君の手伝いをするよ。"

    # say L715 whi
    old "Come on up, I'll show you what I need."
    new "上がってきて、私が必要なことを教えてあげるから。"

    # say L726 pla
    old "Ok, Mrs. White, what do you want me to help you with?"
    new "はい、ホワイトさん、何を手伝えばいいんですか？"

    # say L733 pla
    old "Oh, wow!"
    new "お、すごい！"

    # say L734 whi
    old "You see... I figured, since we're alone."
    new "あなたを見ると……二人きりだし、ちょっと楽しくならない？"

    # say L735 whi
    old "Why don't we have a little bit of fun?"
    new "ちょっとだけ楽しくしてみましょう？"

    # say L736 pla
    old "B- But, Mrs. White, what happens if Mike catches us?"
    new "でも、ミス・ホワイト、もしマイクに見つかったらどうしますか？"

    # say L737 whi
    old "You worry too much."
    new "心配しすぎよ。"

    # say L738 whi
    old "He won't be home for a while, besides, this is my room. So he won't come in without knocking first."
    new "大丈夫、マイクはしばらく帰ってこないし、ここは私の部屋だから、ノックしないで入ってくることはないわ。"

    # say L739 whi
    old "We have time and privacy."
    new "時間とプライバシーがあるのね。"

    # say L740 whi
    old "So don't worry and let's just enjoy."
    new "心配しないで、楽しく過ごしましょう。"

    # say L741 pla
    old "I mean, I- I understand what you're saying, but I think it's too risky."
    new "君の言うことは理解してるんだけど、ちょっとリスクが高いと思うな。"

    # say L742 whi
    old "Oh please, don't act like you don't want it."
    new "お願い、そんなふりしないでちょうだい。"

    # say L743 whi
    old "I know you're turned on right now, so come here."
    new "あなたが今興奮しているのはわかっているから、ここに来なさい。"

    # say L745 whi
    old "You know, I know you enjoyed dinner last time."
    new "あなたが先日のディナーを楽しんだこと、私は知っていますよ。"

    # say L746 whi
    old "But I'm still not satisfied."
    new "でもまだ満足してないの。"

    # say L747 whi
    old "I want to taste something a little better."
    new "私は少しより良いものを感じたいの。"

    # say L754 whi
    old "Mmm, look at that big cock of yours."
    new "ふむ、その大きなちんこを見ているわ。"

    # say L755 whi
    old "I told you I knew you were getting turned on and very, very hard by the looks of it...."
    new "あなたが興奮していて、見た目によるとずいぶん硬くなっていること、私はわかっていたのよ。"

    # say L757 whi
    old "I've been wanting to taste this big dick since last dinner."
    new "この大きなちんこ、前から味わってみたくてたまらなかったのよ。"

    # say L767 mik
    old "Dude, you were here?"
    new "お前、ここに居たのか？"

    # say L768 whi
    old "Yes, he came looking for you, but you weren't home, so I asked him to stay."
    new "はい、彼はあなたを探しに来たんですが、あなたがいなかったので、私が一緒にいてもいいか聞いたんです。"

    # say L770 mik
    old "Stay? What for?"
    new "泊まる？何のために？"

    # say L771 pla
    old "Uhhh... W- well... you know..."
    new "うーん… あの… 分かってるよ…"

    # say L772 whi
    old "Well, if you remember, there were some stuff in my room that I wanted to move to the attic."
    new "ええ、覚えていますけど、私の部屋に attic に移動させたいものがいくつかありましたね。"

    # say L773 whi
    old "And I've been telling you for a while to help me, but you haven't done anything."
    new "そして、私が何度も手伝ってほしいと言っているのに、あなたは何もしてないのね。"

    # say L774 whi
    old "So you're friend here was kind enough to help me. You could learn one or two things from him, you know young man?"
    new "なので、あなたの友達が親切に手伝ってくれたのね。あなたも彼から一つや二つ学ぶべきだと思うわ、若者よ。"

    # say L775 mik
    old "Hmm, yeah, uh, I forgot about that stuff."
    new "うーん、そうか、ああ、そのことを忘れてたな。"

    # say L778 pla
    old "... No problem."
    new "全然問題ないよ。"

    # say L779 whi
    old "Well, I have to clean up some things, and start making dinner. So I'll leave you two alone."
    new "私が片付けをして、夕飯の準備を始めないといけませんので、お二人はゆっくりしてくださいね。"

    # say L780 whi
    old "Thanks again for your help [pla]."
    new "またのお手伝い本当にありがとうございました [pla]。"

    # say L781 pla
    old "Sure Mrs. White."
    new "はい、ホワイトさん。"

    # say L788 mik
    old "Sorry you had to see that dude."
    new "すまなかった、それを見せちゃって。"

    # say L789 mik
    old "My mom is very annoying, sometimes she won't stop nagging me."
    new "俺のママはめちゃくちゃうざいんだ、ときどき文句ばっかり言いつづける。"

    # say L790 pla
    old "Don't worry about it... My mom's the same."
    new "気にするな... 僕のママも同じだ。"

    # say L791 mik
    old "Well anyway, come to my room, I have to tell you something."
    new "まあいいや、部屋に来い、話があるんだ。"

    # say L800 mik
    old "Dudeee! Things went so well with Olivia!"
    new "デュード！オリビアとの授業、めちゃくちゃうまくいったんだ！"

    # say L802 mik
    old "Yeah! She said I helped her a lot and that I'm a very good tutor."
    new "よし！彼女は俺がかなり手伝って、すごく良い家庭教師だって言ってくれた。"

    # say L803 mik
    old "And it's all thanks to you dude. Thank you!"
    new "ありがとうな、お前。助かったよ。"

    # say L804 pla
    old "You're welcome man, I'm glad to be able to help."
    new "どういたしまして、お前が成長していくのを見るのは嬉しいよ。"

    # say L805 pla
    old "So you're gonna keep seeing her?"
    new "じゃあ、これからも会い続けるの？"

    # say L806 mik
    old "Yeah, but she says she's going to come here next time."
    new "うん、でも彼女は次はここに来るって言ってた。"

    # say L807 mik
    old "Because she says she's embarrassed to be seen with me, so it's better to come here instead."
    new "彼女は俺と一緒だと恥ずかしいって言うから、ここに来るのがいいらしい。"

    # say L808 pla
    old "Whoa! What?! That's awful!"
    new "誰あ！何それ！最悪じゃないか！"

    # say L809 pla
    old "And you're ok with that?"
    new "それでいいのか？"

    # say L811 mik
    old "Sure, why wouldn't I be? That means she wants to spend time with me. right?"
    new "もちろん、なぜそうじゃないって言うんだ？それは彼女が俺と時間を過ごしたいってことだろ？"

    # say L814 pla
    old "I mean, that's one way to put it..."
    new "つまり、そう言うことができるけどね…"

    # say L815 mik
    old "Come on man, she's gonna be here... in my room!"
    new "おい、彼女来るんだよ… 俺の部屋に！"

    # say L816 mik
    old "That's an opportunity to get closer with her!"
    new "それが彼女と距離を縮めるチャンスだよ！"

    # say L817 mik
    old "And I don't really care what people think, you know? So what the hell."
    new "人の目なんて気にしないよ、知るか。だからさ、何だって。"

    # say L818 pla
    old "Well... as long as you're happy."
    new "まあ…君が幸せならいいけど。"

    # say L819 pla
    old "And you're positive about it. So, sure."
    new "君が納得してるなら、いいさ。"

    # say L822 pla
    old "Listen man, I came to help you study, but it's kinda late."
    new "おい、俺は君の勉強を手伝いに来たんだが、もう遅い時間だな。"

    # say L823 pla
    old "So, what do you say if we leave it for next time."
    new "じゃあ、次回に持ち越すってどうだよ。"

    # say L824 pla
    old "Besides, you must be tired from studying with Olivia."
    new "それに、オリビアと勉強して疲れてるだろうな。"

    # say L825 mik
    old "Sure dude, to be honest I was afraid you were gonna say we had to study."
    new "もちろん、正直に言うと、勉強する羽目になるんじゃないかと思ったけど。"

    # say L826 mik
    old "So I'm ok with doing it another time."
    new "じゃあ、また今度にしよう。"

    # say L827 pla
    old "Cool, see you later then."
    new "じゃあ、またな。"

    # say L829 mik
    old "Later bro."
    new "後でな、お兄ちゃん。"

    # say L848 whi
    old "Oh [pla] wait!"
    new "あら、[pla]、待って！"

    # say L849 pla
    old "Yes Mrs. White?"
    new "はい、ホワイト夫人？"

    # say L850 whi
    old "It's very late, so I figured you were gonna stay for dinner."
    new "もう遅い時間なので、夕飯に残っていただくと思っていました。"

    # say L851 whi
    old "The food is served already, so you can't say no."
    new "食事はもう用意できていますから、断るわけにはいきませんよね。"

    # say L853 pla
    old "Oh, all right, thank you."
    new "ああ、そうですね、ありがとうございます。"

    # say L869 whi
    old "Do you like today's dinner?"
    new "今日の晩御飯はお気に召しましたか？"

    # say L871 pla
    old "Yeah, it's very good Mrs. White, thanks a lot."
    new "はい、とても美味しいです、ホワイトさん。ありがとうございます。"

    # say L872 mik
    old "He's right mom, it's really good."
    new "そうですね、母さん、本当に美味しくて。"

    # say L874 mik
    old "Excuse me, let me go to the bathroom real quick."
    new "失礼、ちょっとトイレに行ってくるな。"

    # say L888 pla
    old "Woah! What are you doing Mrs. White?"
    new "Woah！ホワイト夫人、何やってるんですか？"

    # say L889 pla
    old "We're in the middle of dinner! Mike could come back at any second!"
    new "食事の最中だよ！マイクがすぐに戻ってくるかもしれないぞ！"

    # say L890 whi
    old "Oh relax, Mike always takes his time in the bathroom."
    new "あら、落ち着いて、マイクはいつもお風呂場で時間がかかるのよ。"

    # say L891 whi
    old "I don't know exactly what he does there, but he'll be there for a while."
    new "彼がそこで何をしているのかは知らないけど、しばらくはいなくなりそうね。"

    # say L892 pla
    old "Still, we're in the dining room..."
    new "それでも、ダイニングルームにいるんだけど..."

    # say L893 whi
    old "So? Nobody will see us, just enjoy it."
    new "だから？誰も見つけることはないし、楽しんじゃっていいのよ。"

    # say L909 pla
    old "Uhh, Mrs. White you have some... Uhh... In your face..."
    new "うーん、ホワイト夫人、あなたの顔にちょっと… うーん… ついてますね…"

    # say L915 whi
    old "It's ok honey, [pla] and I had a chance to have a very nice conversation."
    new "大丈夫よ、ハニー、[pla]と私たちはとても良い会話をしたの。"

    # say L917 whi
    old "Right, [pla]?"
    new "そうです、[pla]？"

    # say L918 mik
    old "Mom, why do you have so much mayo all over your face?"
    new "ママ、なぜ顔にこんなにマヨネーズが付いているの？"

    # say L919 whi
    old "Oh! Heh silly me. I just love the taste of it!"
    new "あら！へへ、バカね。その味が大好きなんだよ！"

    # say L926 mik
    old "I know mom, we all know you really like mayo"
    new "知ってるよ、ママ。みんなマヨネーズが大好きだって知ってんだから。"

    # say L927 whi
    old "Yeah, mayo. Of course..."
    new "うん、マヨネーズね。もちろん..."

    # say L937 pla
    old "Once again, it was all very good Mrs. White."
    new "またしても、とても美味しかったです、ホワイト夫人。"

    # say L938 pla
    old "Thanks a lot!"
    new "ありがとう、ホワイト夫人。"

    # say L939 whi
    old "My pleasure sweety, it was good seeing you again."
    new "私の喜びこそです、スイートピー。また会えてうれしかったわ。"

    # say L940 whi
    old "And as you could see, I also think everything was delicious..."
    new "そしてご覧の通り、私もすべてがとても美味しかったと思いますよ…"

    # say L941 pla
    old "...Sure."
    new "...そうだな。"

    # say L942 pla
    old "Mike, I think I'll head home dude, I'll come back another time to keep studying."
    new "マイク、俺は家に帰るよ、また今度勉強しに来るから。"

    # say L943 mik
    old "Sure dude, have a good night."
    new "そうだよ、ゆっくり休んでね。また来てね。"

    # say L944 whi
    old "And remember to come back soon... You're always welcome."
    new "そしてまたすぐに来てね… いつでも歓迎よ。"

    # say L945 pla
    old "Uuuh... thank you."
    new "うーん… ありがとう。"

    # say L963 pla
    old "Hi Mrs. White, is Mike around?"
    new "白さん、マイクはいますか？"

    # say L964 whi
    old "Hi [pla] is good to see you sweetie."
    new "こんにちは [pla] あなたを見ると嬉しいわ 甜心。"

    # say L965 whi
    old "Well, Mike is in the house. But I don't think he can see you right now."
    new "マイクは家にいますが、今会うのは難しいと思います。"

    # say L966 pla
    old "What? Why not?"
    new "何だ？どうして？"

    # say L967 whi
    old "Well, he's got some company."
    new "彼は今、誰かと一緒ですね。"

    # say L968 whi
    old "A girl came to see him, and they locked themselves in his room."
    new "女の子が彼を見に来て、二人で部屋に鍵をかけてしまったんです。"

    # say L969 whi
    old "He told me that I shouldn't bother him or even knock on the door."
    new "彼は私に、邪魔しないで、ドアをノックすらしないでと言いました。"

    # say L970 pla
    old "Ohh, that's right, he told me Olivia was gonna come today, I don't know how I forgot about it."
    new "ああ、そうだった、オリビアが今日来るって言ってたのに、どうして忘れてたのかな。"

    # say L971 pla
    old "Ok, then I guess I'll come later, see you Mrs. White."
    new "じゃあ、後で来ますね、ホワイトさん。"

    # say L972 whi
    old "Wait a minute!"
    new "ちょっと待って！"

    # say L973 pla
    old "Uhh... yes?"
    new "うーん…はい？"

    # say L974 whi
    old "How are you leaving after you just arrived? Don't be silly."
    new "どうして今来たばかりなのに帰ろうとするの？ばかじゃないの。"

    # say L975 whi
    old "You're going to help me move some other boxes in my room."
    new "あなたが私の部屋の他の箱を運んでくれるのよ。"

    # say L976 pla
    old "What? What are you talking about? Mike's here!"
    new "何言ってるの？マイクがいるじゃん！"

    # say L977 whi
    old "So? They just went up to his room a couple of minutes ago."
    new "そうよ？彼らは数分前に彼の部屋に上がっただけなの。"

    # say L978 whi
    old "How long do you think the study session will last?"
    new "どのくらい長く勉強すると思うかしら？"

    # say L979 pla
    old "Well... It should take a while, because the subject is a little long."
    new "まあ… 科目が長いから、少し時間がかかるだろうね。"

    # say L981 whi
    old "See? Nothing's going to happen."
    new "見？？？ 何も起こらないわ。"

    # say L982 whi
    old "Besides, if they finish early, all I have to do is tell him I'm in my room and don't want him to go in."
    new "それに、早く終わったとしても私が部屋にいるって言えば、入らないでくれるんですから。"

    # say L983 pla
    old "Still, I don't think we..."
    new "それでも、あまりいいとは思えないけど……"

    # say L984 whi
    old "Enough talking, you worry too much. Just come with me to the room."
    new "もう話すのはよしにして、心配しすぎだわ。部屋に来なさい。"

    # say L985 whi
    old "I know you'll love it."
    new "あなたが好きになると思いますよ。"

    # say L997 pla
    old "(Oh man, I just fucked my best friend's mom... I can't believe I'm doing this to Mike.)"
    new "（おいよ、マイクの母さんと寝ちゃったのか……信じられない、こんなのやってる自分が）"

    # say L998 pla
    old "(Jeez, honestly... I'm ok with helping Mike, but damn, this is getting dangerous.)"
    new "（正直、マイクのために手伝うのはいいけど、これって危険になってきちゃってるよな。）"

    # say L999 pla
    old "(I mean, I just can't even imagine what would happen if Mike caught us one day)"
    new "俺は正直、マイクが俺たちを捕まえた日に何が起こるか想像もつかないよ。"

    # say L1006 oli
    old "Ah! W- What are you doing here?"
    new "あっ！　何してるのここに？"

    # say L1009 pla
    old "Uhh... Well, this is my friend's house."
    new "うーん… これは友達の家だよ。"

    # say L1010 pla
    old "So, I came to see him."
    new "じゃあ、俺は彼を見に来たんだ。"

    # say L1011 pla
    old "And you? Did you come to study with him, right? "
    new "君は？彼と勉強しに来たんだろ？"

    # say L1013 oli
    old "I... uhh..."
    new "あたし……うーん……"

    # say L1014 oli
    old "What do you care? I can come and go wherever I want."
    new "何に関心があるのよ？どこにいようと自由よね。"

    # say L1015 oli
    old "And I'm leaving now!"
    new "そして今から帰るよ！"

    # say L1026 oli
    old "By the way! You better not tell anybody about me being here!"
    new "それに！ここにいたこと、誰にも言うなよ！"

    # say L1027 oli
    old "Or you'll hear about me, you got that fucking nerd?"
    new "それじゃあ聞かされるぞクソオタク分かったな？"

    # say L1028 pla
    old "Sure, sure whatever you say."
    new "分かった分かった、お前が言うならな。"

    # say L1044 mik
    old "Oh [pla], what's up man? I didn't know you were here."
    new "オッ [pla]、どうしたんだ？君がここにいるとは知らなかったよ。"

    # say L1045 pla
    old "Uh, yeah, I came to see you."
    new "うん、そう。君に会いに来たんだ。"

    # say L1046 pla
    old "I forgot that you were going to see Olivia today."
    new "俺、お前が今日オリビアに会うってのを忘れてたよ。"

    # say L1047 pla
    old "By the way, how did it go?"
    new "それじゃ、どうだった？"

    # say L1049 mik
    old "Aww man! It was awesome!"
    new "あー、最高だったよ！"

    # say L1050 mik
    old "She said I'm being very helpful."
    new "彼女は俺がとても役立ってるって言ったよ。"

    # say L1051 mik
    old "I'm telling you [pla], I'm winning her over."
    new "お前にも言わせるよ [pla]、彼女を落とすところだ。"

    # say L1053 mik
    old "But anyway, we can keep talking about it while we have dinner."
    new "でもまあ、食事しながら話せるよ。"

    # say L1054 pla
    old "Uh what? Dinner? I- I don't think I can."
    new "え？ディナー？俺、多分無理だな。"

    # say L1055 mik
    old "Come on, you know it's no trouble. My mom will be happy to have you here."
    new "Come on, 俺が誘うんだから大丈夫だよ。俺のママも喜ぶさ。"

    # say L1056 pla
    old "I'm sure she will. But I promised my mother I would have dinner at our house tonight."
    new "俺もそう思うけど、母に今夜は家で食事すると約束したんだ。"

    # say L1057 pla
    old "I've been eating out too much, so I can't miss it tonight."
    new "最近外食ばっかりだから、今夜は欠かせないんだ。"

    # say L1059 mik
    old "Uhh, all right, next time then."
    new "うーん、そうか、次にしよう。"

    # say L1060 mik
    old "See you later then bud."
    new "じゃあ後でな、お兄さん。"

    # say L1061 pla
    old "Sure man, see you."
    new "分かった、またね。"

    # say L1079 whi
    old "Hi [pla] are you two done studying today?"
    new "こんにちは [pla] 二人とも今日の勉強は終わったの？"

    # say L1080 pla
    old "Yes Mrs. White, we just finished."
    new "はい、ホワイト先生、ちょうど終わったんです。"

    # say L1081 pla
    old "So I figured I should go."
    new "じゃあ、俺は帰るよ。"

    # say L1082 whi
    old "Oh don't be silly!"
    new "あら、そんなに急がなくてもいいですよ。"

    # say L1083 whi
    old "I already finished the dinner."
    new "もう夕飯は作っちゃったんです。"

    # say L1084 whi
    old "And you know I want you to stay."
    new "あなたが泊まることを望んでいるのは知ってますよ。"

    # say L1086 pla
    old "L- Listen Mrs. White, I already told my mom I was going to have dinner with her and sh..."
    new "白さん、もう母には彼女と夕飯を食べるって言っちゃったんですけど…"

    # say L1087 whi
    old "I'm sure your mother will understand that I invited you."
    new "あなたの母親はきっと私があなたを招待したことを理解してくれるでしょう。"

    # say L1088 whi
    old "Come on. Let's have dinner."
    new "さあ、一緒に夕飯を食べましょう。"

    # say L1103 mik
    old "This is really good mom."
    new "これは本当に美味しいよ、ママ。"

    # say L1104 mik
    old "I don't know what's happened, but you've been making some awesome food these days."
    new "最近どうしたのか知らないけど、お母さんの料理上手くなったね。"

    # say L1105 whi
    old "I don't know what you mean by that, my food is always delicious."
    new "何を言っているのかわからないわ、私の料理はいつも美味しいのに。"

    # say L1106 whi
    old "You're going to make your friend think that my cooking is usually bad."
    new "友達に私の料理が普段はまずいと思わせちゃうじゃないですか。"

    # say L1107 mik
    old "What? Of course not."
    new "何？もちろんそんなつもりはない。"

    # say L1108 mik
    old "All I'm saying is the meals are extra special these days."
    new "最近の食事は特別だって言ってるだけさ。"

    # say L1110 whi
    old "Well, I have to put in some effort, we've been having an extra special guest..."
    new "まあ、特別なゲストがいるから、少し頑張ってるのよ…"

    # say L1111 mik
    old "Ha! My mom likes you dude."
    new "はは！俺のママ、君のこと気に入ってるよ。"

    # say L1112 pla
    old "(You have no idea...)"
    new "君にはわからないだろうな…"

    # say L1113 whi
    old "I'm just being nice to your friend."
    new "私はただあなたの友達に優しくしているだけです。"

    # say L1114 whi
    old "Are you enjoying it too [pla]?"
    new "あなたも楽しんでるの？ [pla]？"

    # say L1117 pla
    old "I like it a lot. It's delicious, thank you."
    new "俺はとても気に入ってるよ。美味しいし、ありがとう。"

    # say L1119 mik
    old "By the way [pla], Belle told me to ask you about th..."
    new "それとも [pla]、Belleが君に聞きたいことがあるって言ってたんだけど…"

    # say L1123 mik
    old "Hold it right there, I'm gonna take this call."
    new "待て、ここで電話を取るよ。"

    # say L1130 pla
    old "Oh come on..."
    new "おい、待てよ…"

    # say L1139 pla
    old "W- What are you doing Mrs. White?"
    new "W- 何してるんですか、ホワイトさん？"

    # say L1140 whi
    old "What? This is just like last time."
    new "何ですか？これは前と同じですよ。"

    # say L1141 whi
    old "You know he'll take a while."
    new "あなたも知ってるでしょう、彼は時間がかかるから。"

    # say L1142 whi
    old "So, we can have a little bit of fun."
    new "それなら、ちょっとだけ楽しくできますね。"

    # say L1143 pla
    old "No, no, no. This isn't like last time. He only left to pick up a call."
    new "いや、いや、いや。これは前回と違う。彼はただ電話を取りに行くだけだ。"

    # say L1144 pla
    old "Which means it won't be long."
    new "それなら長くは続かないだろう。"

    # say L1145 pla
    old "Mrs. White please stop!"
    new "白さん、お願いだから止めて！"

    # say L1146 whi
    old "Well, I could stop."
    new "まあ、やめる事もできるけどね。"

    # say L1147 whi
    old "But this hard dick tells me you want me to do it anyway."
    new "でもこの硬いチ○ポは、あなたが続けて欲しがってるみたいよ。"

    # say L1149 whi
    old "Just relax, it won't take long."
    new "リラックスして、すぐ終わるから。"

    # say L1171 mik
    old "Where did my mom go?"
    new "母さんがどこ行った？"

    # say L1172 pla
    old "Uhhh... S- she went to the... bathroom. Yeah, she said she needed to go."
    new "うーん… 彼女は… トイレに行ったって言ってたよ。そうだ、そう言ったんだ。"

    # say L1173 mik
    old "But I came from there, and I didn't see her enter."
    new "でも俺がそこから来たんだよ、入って行くところ見なかったけど。"

    # say L1176 pla
    old "She... must be using the one in her bedroom."
    new "彼女は…多分寝室のトイレを使ってるんだろ。"

    # say L1177 pla
    old "I think she went upstairs."
    new "upstairs に上がったんだな。"

    # say L1178 mik
    old "Hmm."
    new "うーん。"

    # say L1180 mik
    old "Yeah you're right."
    new "そうだな。"

    # say L1197 pla
    old "(Damn, I can't believe she actually gave me a blowjob and made me cum with Mike here!)"
    new "（くそ、マイクがいる前で実際に彼女がフェラして、俺をイカせたなんて信じられない。）"

    # say L1198 pla
    old "(I need to think about something or Mike will really catch us.)"
    new "（何か考えないと、マイクに本当に気づかれちゃうな。）"

    # say L1199 pla
    old "You know what Mike? I think I could really use a headache pill."
    new "マイク、頭が痛くなってきたんだ。頭痛薬を飲むと助かるな。"

    # say L1200 pla
    old "If you have anything here that I could take it would be good."
    new "もし何か持ってるなら、飲ませてもらえれば助かるな。"

    # say L1201 mik
    old "Hmm, let me check the cabinet in the bathroom."
    new "うん、ちょっとバスルームの棚を見てくる。"

    # say L1209 whi
    old "A headache? That was a good idea."
    new "頭痛？それは良い考えですね。"

    # say L1210 pla
    old "Why are you so chirpy? I told you he was going to come back!"
    new "なんでそんなに元気にしてるんだよ？僕が言ってたじゃない、彼は戻ってくるって。"

    # say L1211 whi
    old "Awww, my baby boy was scary, don't worry sweetie."
    new "あら、私の赤ちゃんが怖かったのね、安心しなさい亲爱的。"

    # say L1212 whi
    old "Next time I see you I'll give you something in return for this."
    new "次に会ったときは、これの見返りに何かあげるわ。"

    # say L1213 pla
    old "Hmph, this isn't about that."
    new "ふん、それとは関係ないんだよ。"

    # say L1218 mik
    old "Sorry dude, we don't have anything like that."
    new "すみません、そんなものはありませんよ。"

    # say L1219 mik
    old "Mom, you're back."
    new "お母さん、帰ってきたのね。"

    # say L1221 mik
    old "I thought you had gone to sleep."
    new "寝たと思っていたんだよ。"

    # say L1223 whi
    old "Oh no, it's just that I had to go to the bathroom. But I came back to finish my dinner."
    new "あら、ただトイレに行っていただけよ。でも、戻って夕飯を食べに戻ったの。"

    # say L1224 whi
    old "By the way, you should finish yours too, before it gets cold."
    new "それに、あなたも冷めないうちに食べ終えた方がいいですよ。"

    # say L1225 mik
    old "I know, I know, I was just getting a pill for [pla], where do we keep then?"
    new "知ってるよ、ただ[pla]の薬を取りに行こうとしただけだ、どこに置いてあるんだ？"

    # say L1227 pla
    old "You know what, dude?"
    new "知ってるか、兄貴？"

    # say L1228 pla
    old "I don't think I'll need it, the headache is gone."
    new "俺は大丈夫だ、頭痛は治ったから。"

    # say L1230 whi
    old "Yeah, all you needed was to relax and release everything as Mike said."
    new "そうね、マイクが言った通り、リラックスしてすべてを解放することが必要だったのよ。"

    # say L1232 mik
    old "Yeah, that's what I sai-... Wait how do you know-"
    new "そうだよ、そう言ったんだけど… 待って、どうして君が知ってるんだ？"

    # say L1233 whi
    old "Oh, honey, I'm really hungry and the food is gonna get cold. Why don't we finish this delicious dinner?"
    new "お Gł、お腹が空いちゃったの。でも食事が冷めちゃうわ。この美味しいディナーを食べ終えましょうよ。"

    # say L1234 pla
    old "Yeah, dude, just enjoy the dinner."
    new "そうだ、兄さん、食事だけ楽しもう。"

    # say L1242 pla
    old "As always Mrs. White, your food is always the best."
    new "いつもそうだけど、ホワイトさん、あなたの料理は最高です。"

    # say L1244 whi
    old "It's very good that you always enjoy... Everything I give you sweety."
    new "いつも楽しんでくれてうれしいわ… 私があげるものは全部ね、スイーティ。"

    # say L1245 whi
    old "It always makes me want to give you some more..."
    new "いつもあなたに喜んでいただけると、もっとあげたくなるのよ…"

    # say L1246 pla
    old "Uh... yeah, thank you."
    new "うーん……ありがとうございます。"

    # say L1247 pla
    old "Well, it's very late, so I shold go now."
    new "まあ、もう遅いので、帰りますね。"

    # say L1248 mik
    old "Sure man, no problem. Thanks for today."
    new "もちろん、問題ないよ。今日ありがとう。"

    # say L1267 pla
    old "Hi Mrs.White, how are you?"
    new "白さん、お元気ですか？"

    # say L1268 whi
    old "Hi sweetie, I'm very well, thank you."
    new "こんにちはsweetie、私はとても元気です、ありがとう。"

    # say L1269 whi
    old "Let me guess, you came to study with Mike again."
    new "お察ししましたけど、またマイクと勉強しに来たのね。"

    # say L1270 pla
    old "Yeah, is he here?"
    new "うん、彼はここにいるのか？"

    # say L1271 whi
    old "I'm sorry, but he isn't, he went out with that girl Olivia."
    new "申し訳ありませんが、いませんよ、オリビアさんと外出ています。"

    # say L1273 pla
    old "Hmm... I see."
    new "うーん……そうか。"

    # say L1274 pla
    old "I suppose I should come later then, right?"
    new "じゃあ、後で来るのがいいな、そうだろう？"

    # say L1275 whi
    old "Oh, why do you ask that when you already know the answer?"
    new "あなたがすでに答えを知っているのに、なぜそんなことを聞くの？"

    # say L1276 whi
    old "No my sweet boy, you're not going anywhere."
    new "いいえ、甘い子、どこにも行かないわ。"

    # say L1277 whi
    old "We're going to finish what we started the other night at dinner."
    new "私たちは先日の夕食で始めたことを終わらせるわ。"

    # say L1279 whi
    old "Come here sweetie, I want you right now."
    new "来てちょうだい、甘いの。今すぐあなたが欲しくて仕方ないの。"

    # say L1280 pla
    old "What? Here?"
    new "何？ここで？"

    # say L1281 whi
    old "Sure! Why not? We're alone and Mike will take his time."
    new "もちろん！どうしていいの？咱たちは二人きりだし、マイクは時間かかるわ。"

    # say L1282 pla
    old "B- but... I- I mean, he could come back early... or he could"
    new "でも... 俺が早めに帰ってきちゃうかもしれないし... または彼が"

    # say L1284 whi
    old "That's enough, Mike doesn't even suspect a thing and you're always worrying."
    new "もういいわ、マイクは全く疑ってないのに、あなたばかり心配してるのよ。"

    # say L1285 whi
    old "So stop thinking so much and just get naked."
    new "だからそんなに考えずにさっさと裸になって。"

    # say L1286 whi
    old "I want that big cock now!"
    new "今すぐにその大きなちんこが欲しがっているの！"

    # say L1295 whi
    old "Ah yes! Look at how hard you already are."
    new "あらそう！ 既にこんなに硬くなっちゃってるわ。"

    # say L1296 whi
    old "That big long dick."
    new "その大きな長いちんこ。"

    # say L1297 whi
    old "I want you to put in me."
    new "私の中に入れてください。"

    # say L1298 whi
    old "I can't wait!"
    new "待ってられません！"

    # say L1313 pla
    old "Hi Mrs. White. It's good seeing you again."
    new "白さん、また会えて嬉しいです。"

    # say L1314 whi
    old "Hi sweety, are you here to see Mike?"
    new "こんにちはスイートピー、マイクに会いに来たの？"

    # say L1316 whi
    old "Well, I'm sorry to tell you that he's not available."
    new "申し訳ありませんが、彼は今いないんです。"

    # say L1317 whi
    old "That girl Olivia came a while ago, and he was very clear that they shouldn't be interrupted."
    new "オリビアさんが少し前に来たんですが、マイクさんははっきりと邪魔されたくないって言いました。"

    # say L1320 whi
    old "But don't be sad, because you know what that means."
    new "でも悲しまないで、それが意味するものはあなたと私が楽しく過ごせるということだから。"

    # say L1321 whi
    old "It means you and I get to have some fun."
    new "それはあなたと私が楽しく過ごせるということです。"

    # say L1322 pla
    old "What?! Are you kidding me?!!"
    new "何っ？冗談じゃないよ？！！"

    # say L1323 pla
    old "After what happened last time. You still want to do it?!"
    new "前回のことがあったのに、まだやる気なのか？！"

    # say L1324 whi
    old "Aww, my baby boy is worried."
    new "あら、私の赤ちゃんが心配しているのね。"

    # say L1325 whi
    old "Don't worry, this time we'll do it in my bedroom, so what happened last time won't happen again."
    new "心配しないで、今度は私の寝室でやるので、前回のようなことは二度とないわ。"

    # say L1326 pla
    old "Hmm, but what happens if they finish before us and they hear us?"
    new "でも、もし彼らが先に終わって私たちの声が聞こえたらどうする？"

    # say L1327 pla
    old "I mean... How long have they been up there?"
    new "つまり... 彼らはどれくらい上にいるんだ？"

    # say L1328 whi
    old "Hmm, to be honest I didn't really look at the clock."
    new "正直、時計を見ていなかったんです。"

    # say L1329 pla
    old "I don't think we should do anything without knowing how long they'll be there."
    new "彼らがどのくらいいるのか分かんないのに、何もせずに待つのは危険だと思ったんだ。"

    # say L1331 whi
    old "You're thinking too much, just relax a little."
    new "考えすぎだわ、ちょっとリラックスして。"

    # say L1332 pla
    old "I can't, after what happened last time, we need to be sure... And I have an idea."
    new "前回のことがあって、無理だ… でも、一つアイデアがあるんだ。"

    # say L1333 pla
    old "Let me go upstairs and check on them first."
    new "俺が上に上がって先に確認してくるよ。"

    # say L1334 whi
    old "Hmm, ok. Do that and let me know."
    new "うーん、そうね。行ってみて結果を教えてちょうだい。"

    # say L1346 pla
    old "Damn, I didn't think Mike and Olivia were really going to do anything."
    new "俺もマイクとオリビアが本気で何かするとは思ってなかったな。"

    # say L1347 pla
    old "Well, I guess all that work really paid off. I'm happy for him."
    new "まあ、その努力が報われたみたいだな。彼の幸せを心から願ってる。"

    # say L1356 whi
    old "So? What topic are they on?"
    new "何ですかそれ？どんな話題を話しているんですか？"

    # say L1357 pla
    old "Hmm, let's just say they'll be busy for a while."
    new "まあ、しばらくは忙しいだろうね。"

    # say L1358 pla
    old "So, I think we'll be fine."
    new "大丈夫だと思う、心配しなくていいよ。"

    # say L1360 whi
    old "Really? Perfect! Let's go to my room then!"
    new "本当に？ぴったりだわ！それじゃ、私の部屋に行きましょう！"

    # say L1378 oli
    old "Whoa! Whoa! Whoa!"
    new "Whoa！ Whoa！ Whoa！ → ワオ！ワオ！ワオ！"

    # say L1385 pla
    old "Fuck! She saw us, I have to go after her!"
    new "くそっ！見られちまった、追いかけていかないと！"

    # say L1397 pla
    old "Olivia! Wait!"
    new "オリビア！待って！"

    # say L1400 oli
    old "Dude! What the fuck!"
    new "マジで！何言ってんの！"

    # say L1401 oli
    old "You're fucking your friend's mother?! What the fuck is wrong with you."
    new "友達の母親とハメてんの？一体何考えてんのよ。"

    # say L1403 pla
    old "It's not what you think! We're just..."
    new "待ってくれ、違うんだ！ただ…"

    # say L1404 oli
    old "You're just what? I saw you dude!"
    new "何だって？見たわよ、あなた！"

    # say L1405 oli
    old "I saw your big coc-... your penis hanging out, and jizz everywhere."
    new "あなたの大きなコッコ……って言おうとしたけど、あなたのペニスが出てて、精液がいた处に飛び散ってたわ。"

    # say L1406 pla
    old "Ok, listen, I was doing that, but please you can't tell Mike."
    new "おい、聞いてくれ、やってたけど、マイクには絶対言っちゃダメだ。"

    # say L1407 pla
    old "Please! I'm begging you! He'll never forgive me!"
    new "お願いだよ！頼むから！彼には決して言わないでくれ！許さないだろうよ！"

    # say L1408 oli
    old "Well, maybe you should've thought about that before fucking his mom."
    new "まあ、それをする前に彼のママと寝ることを考えるべきだったのかもしれないわね。"

    # say L1409 pla
    old "Oh, come on! You wouldn't get anything by telling him that!"
    new "おい、 Come on！ そんなこと言ったって何も得しないだろう。"

    # say L1410 oli
    old "Perhaps I would, who knows?"
    new "もしかしたらね。誰も知らないわ。"

    # say L1411 oli
    old "I guess you would be willing to do anything in exchange for me not telling him anything, right?"
    new "あなたがマイクに何も言わない代わりに、私は何でもするわ、そうよね？"

    # say L1413 oli
    old "Right?!!!!"
    new "そうだろ！！！！"

    # say L1414 pla
    old "I would, I would, I'd do anything, just please don't tell Mike."
    new "俺は、俺は、何でもするから、お願いだからマイクには言わないで。"

    # say L1417 oli
    old "Listen, I'm leaving now, I can't waste my time on you."
    new "聞いて、今から出かけるの、君のことなんか時間の無駄よ。"

    # say L1418 oli
    old "I'm not going to tell him anything... For now."
    new "何も言わないわ… 今のところは。"

    # say L1419 oli
    old "We'll see if that changes later."
    new "後でどう変わるか見てみましょう。"

    # say L1425 pla
    old "Oh, gosh, I'm fucked.."
    new "おい、やばいな…"

    # say L1426 pla
    old "(Damn it! She just saw me fucking my best friends mom!)"
    new "くそっ！彼女に親友の母親とセックスしてるところを見られてしまった！"

    # say L1427 pla
    old "(I have to do something...)"
    new "（何かしなきゃ）"

    # say L1428 pla
    old "(I have to try and convince her someway not to tell Mike.)"
    new "（何とかしてミケに言わないように説得しないと。）"

    # say L1435 mik
    old "Hey man, what's up?"
    new "おい、何してる？"

    # say L1437 mik
    old "Did you run into Olivia again?"
    new "お前、またオリビアに会ったのか？"

    # say L1438 pla
    old "Uhh, yeah... Sorry dude."
    new "うーん、そうですね... ごめん、お兄ちゃん。"

    # say L1439 mik
    old "It's ok dude."
    new "大丈夫だ、気にすんな。"

    # say L1440 mik
    old "I already talked to her about it."
    new "もうそれについて話してあるよ。"

    # say L1441 mik
    old "I told her that you've been helping me. So don't worry, we're fine."
    new "俺が手伝ってくれてるって伝えたよ。だから心配するな、大丈夫だ。"

    # say L1442 pla
    old "I see... well, that's very cool dude."
    new "なるほど… なら、それはいいね。"

    # say L1443 mik
    old "Yeah... I guess it is."
    new "そうだな…まあ、そうだろう。"

    # say L1444 pla
    old "Hey man, listen, today is a little late, so how about we study another time?"
    new "おい、今日ちょっと遅いし、また今度勉強しようよ。"

    # say L1446 mik
    old "Actually, we don't have to do that for now."
    new "実際、今はしなくてもいいよ。"

    # say L1447 pla
    old "Really? Why?"
    new "本当に？なんで？"

    # say L1448 mik
    old "Olivia's going on a trip."
    new "オリビアが旅行に行くんだ。"

    # say L1449 mik
    old "She's going to be out of time for a while."
    new "彼女はしばらく時間がないんだ。"

    # say L1451 mik
    old "So I don't think you don't have to worry for now."
    new "だから今は心配しなくてもいいと思うな。"

    # say L1453 pla
    old "That's a relief, I gues..."
    new "それは一安心だな、 guess..."

    # say L1455 pla
    old "I- I mean... I see... Um, sorry dude. That sucks."
    new "あー、そうか…… 分かった、ごめん。つらそうだな。"

    # say L1457 mik
    old "Are you kidding me? Dude, it has been awesome spending time with her."
    new "冗談だろ？ Dude、彼女と一緒に過ごせたのが最高だったんだよ。"

    # say L1458 mik
    old "And I know for a fact that she likes me."
    new "そして、彼女が俺のこと好きだってことは確実だ。"

    # say L1459 mik
    old "So, I'm sure I'll see her again when this is over."
    new "だから、これ終わったらまた会えるはずだ。"

    # say L1460 pla
    old "So am I..."
    new "俺もそうみたいだ..."

    # say L1468 whi
    old "[pla]! Did you talk to her? What did she say?"
    new "[pla]！彼女とお話ししましたか？何をおっしゃったんですか？"

    # say L1469 pla
    old "Yeah, I did Mrs. White, and I know you're worried about that."
    new "そうだよ、ホワイト先生と話したし、君が心配してるってことも知ってる。"

    # say L1470 pla
    old "But she said she wasn't going to tell anything to him."
    new "でも、彼女は彼に何も言わないと言ったよ。"

    # say L1471 pla
    old "At least for now..."
    new "少なくとも今は..."

    # say L1472 whi
    old "I don't know, what if she tells him? He's going to kill me!"
    new "わからないけど、もしいいこと話したらどうするの？彼は私を殺すわ！"

    # say L1473 pla
    old "Hey, it's ok, let me handle it. Ok?"
    new "大丈夫、心配しなくていい。俺が対処するから。いいな？"

    # say L1475 whi
    old "Ok, I trust you."
    new "大丈夫、あなたを信じるわ。"

    # say L1477 pla
    old "Listen, it's very late already, and my mom wants me to eat with her."
    new "ねぇ、もう時間も遅いし、母さんが一緒に食事したいって言ってるんだ。"

    # say L1478 pla
    old "So I'll be on my way home, and I'll see you later."
    new "じゃあ、家に帰るけど、また後でな。"

    # say L1479 pla
    old "Just try not to worry too much and just let me handle this. Ok?"
    new "心配しすぎないで、俺が対処するから。わかった？"

    # say L1481 whi
    old "Ok, ok, I'll try not to think about it."
    new "うんうん、なるべく気にならないようにする。"

    # say L1482 whi
    old "Bye. I'll see you later baby boy."
    new "バイバイ、あとでまたね、ベイビー。"


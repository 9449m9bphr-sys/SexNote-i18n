# SexNote japanese — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate japanese strings:  (old/new) — required for Ren'Py overlay
# Font: SEXNOTE_FONT_JP (NotoSansJP)

# Source: code/Story/ChristmasEvent2.rpy
translate japanese strings:

    # say L7 pla
    old "Hmm, what is this?"
    new "ん、これは何だ？"

    # say L8 pla
    old "What's this feeling?"
    new "この感じは何だ？"

    # say L9 pla
    old "I- I have a hard-on?!"
    new "えっ、俺、勃起してる？！"

    # say L22 pla
    old "Lydia?! W- what are you doing?"
    new "リディア？！ な、何やってるの？"

    # say L28 lyd
    old "Good morning hon! Great, you finally wake up!"
    new "おはよう！良かった、やっと起きたのね！"

    # say L29 pla
    old "W- what's happenning? What's this?!"
    new "何が起こってるんだ？これって何だ？！"

    # say L30 pla
    old "And what is that you're wearing?!"
    new "その格好は何だよ？！"

    # say L34 lyd
    old "Do you like it? It's my Mrs. Claus outfit for the day!"
    new "好き？　今日の格好はサンタクロースの奥さん風よ！"

    # say L35 lyd
    old "You know, to get in the spirit of Christmas."
    new "クリスマスの雰囲気出そうと思って。"

    # say L36 pla
    old "Whatever! What are you doing in my room, and giving me a blowjob?!"
    new "何だよ！お前が俺の部屋に来て、こんなことするなんて！"

    # say L37 lyd
    old "Well, I came to spend Christmas with you guys."
    new "まあ、クリスマスを一緒に過ごしに来たの。"

    # say L38 lyd
    old "But when I arrived I saw that you were still sleeping."
    new "でも、来たときにはまだ寝てたから。"

    # say L42 lyd
    old "Then I decided to wake you up in a special way!"
    new "じゃあ、特別な方法で起こすことにしたの！"

    # say L43 lyd
    old "I guess you can say it is my early Christmas present to you!"
    new "まあ、これは早いクリスマスプレゼントみたいなものかもね！"

    # say L44 pla
    old "What are you talking about?!"
    new "何を言ってるんだよ？！"

    # say L45 pla
    old "Do you know what my [mo1rel]'s going to do if she sees what you're doing?!"
    new "君がやってることを俺の[mo1rel]が見たら、どうなるか知ってるのか？！"

    # say L46 pla
    old "What's gotten into you all of a sudden?"
    new "急にどうしたんだよ？"

    # say L50 lyd
    old "Oh, don't say that."
    new "あら、そんなこと言わないでよ。"

    # say L51 lyd
    old "Nothing got into me."
    new "何も入ってないわ。"

    # say L55 lyd
    old "I just wanted to start Christmas the right way."
    new "ただ、クリスマスを Proper な形で始めたくて思っただけよ。"

    # say L59 lyd
    old "I bet you can help me with that."
    new "あなたが手伝ってくれるよね。"

    # say L63 lyd
    old "After all, you have something I want in me..."
    new "結局、あなたには私が欲しくて仕方ないものがあるんだから…"

    # say L64 pla
    old "W- what? You must be kidding me!"
    new "ワッ、冗談じゃないよ？"

    # say L68 lyd
    old "Don't be so shy baby"
    new "そんなに恥ずかしがらないでよ、ベイビー"

    # say L69 lyd
    old "After all, it's not like you haven't done it before."
    new "結局、前にもやってるじゃない。"

    # say L73 lyd
    old "Besides, I can see very clearly that you want it."
    new "それに、あなたが欲しがってるのがよくわかるわ。"

    # say L74 pla
    old "T- that's just because you woke me up that way!"
    new "それは君がそう起こしたからだよ！"

    # say L75 pla
    old "It- it will go down in a minute."
    new "ちょっと待って、すぐ下がるよ。"

    # say L79 lyd
    old "Oh, but I can't let that happen!"
    new "あら、でもそんなのは許さないわ！"

    # say L80 lyd
    old "I haven't had any breakfast yet, and I think I want some of your eggnog!"
    new "朝ごはんまだだから、あなたのエッグノッグ飲みたい！"

    # say L87 lyd
    old "My god, I love the taste and smell of your dick!"
    new "神様、あなたのちんこの味と香りが大好き！"

    # say L88 lyd
    old "I'm already so wet!"
    new "もうずいぶん濡れちゃってるの"

    # say L89 lyd
    old "What a shame we don't have much time."
    new "時間がないのは残念ね。"

    # say L90 lyd
    old "Otherwise I'd like to do something else..."
    new "それなら他のこともしたいな…"

    # say L99 lyd
    old "Well, that was a great way to start the day, right [pla]?"
    new "じゃあ、これで一日の始まりは最高だったわね、[pla]？"

    # say L101 lyd
    old "I'll go say good morning to the rest of the family."
    new "家族の皆さんに挨拶に行ってくるわ。"

    # say L102 lyd
    old "So, you can get dressed in peace."
    new "じゃあ、ゆっくり着替えてね。"

    # say L103 pla
    old "Uhh... sure."
    new "うーん…いいよ。"

    # say L113 pla
    old "W- what? What was that? What's happening?"
    new "えっ、何？　何が起こった？　何のこと？"

    # say L114 sis
    old "I was asking you if you had a minute, I have something to show you..."
    new "ちょっと時間ある？見せたいものがあるのけど…"

    # say L116 sis
    old "Excuse me?"
    new "すみません？"

    # say L117 pla
    old "Uhh, nevermind... Uhh, what do you want to show me?"
    new "うーん、いいや… うーん、何を見せたいんだ？"

    # say L119 sis
    old "Hmm, come to my bedroom with me."
    new "うん、私の寝室に来なよ。"

    # say L120 pla
    old "Uh, sure."
    new "うーん、いいよ。"

    # say L137 sis
    old "So, I wanted to show you the new Christmas clothes that just arrived."
    new "それじゃ、新しく届いたクリスマス用の服を見せてあげるわ。"

    # say L138 sis
    old "They're for the shop."
    new "ショップ用よ。"

    # say L141 pla
    old "That's great [sis]."
    new "それはいいね [sis]。"

    # say L142 sis
    old "Do you want to see them?"
    new "見たい？"

    # say L145 sis
    old "Great! Just wait here."
    new "Great！ ちょっと待ってて。"

    # say L157 sis
    old "Ok, this is the first one, what do you think?"
    new "じゃあ、これが最初のものだよ、どう思う？"

    # say L158 pla
    old "I think it's great, very festive, it suits you."
    new "いいね、とても華やかだよ、君にぴったりだ。"

    # say L159 pla
    old "I'm sure it's going to sell great."
    new "きっと売れるだろうな。"

    # say L160 sis
    old "That's just what I thought."
    new "そう思ったのよ。"

    # say L161 sis
    old "Let me show you the other one."
    new "他のも見せてあげるね。"

    # say L177 sis
    old "So, what about this one?"
    new "じゃあ、この方はどう？"

    # say L178 sis
    old "This one is my favorite."
    new "この方が私のお気に入り。"

    # say L180 pla
    old "I- I mean, it looks great on you."
    new "あー、つまり、君に似合ってるな。"

    # say L181 pla
    old "I'm not sure this counts as an outfit per se."
    new "これって服として成立するかどうか微妙だな。"

    # say L185 pla
    old "But maybe it will sell well as lingerie."
    new "でも、ランジェリーとして売れそうかな。"

    # say L186 pla
    old "This one could also be good for the ladies that want to surprise their husbands and boyfriends."
    new "このデザインなら、夫や彼氏にサプライズしたい女性にもいいかもしれないな。"

    # say L187 sis
    old "Yeah, and it's very comfortable too."
    new "そうね、それにとても快適よ。"

    # say L188 sis
    old "The fabric's very soft."
    new "生地がとても柔らかいよ。"

    # say L201 pla
    old "Uhhh... What are we doing [sis]?"
    new "うーん… 何やってるんだよ [sis]？"

    # say L202 sis
    old "Oh well, I just want you to feel the fabric."
    new "まあ、ただ生地の触り心地を感じてほしいだけよ。"

    # say L203 sis
    old "What do you think? Isn't it soft?"
    new "どう思う？ 柔らかくない？"

    # say L204 pla
    old "I- I guess it is, yeah..."
    new "うーん、まあ柔らかいね..."

    # say L206 sis
    old "But how much do you like it?"
    new "でもどれくらい好きなのか見せて？"

    # say L207 sis
    old "Let me see how you feel down here..."
    new "ここを触ってみてどう感じるか見せてちょうだい..."

    # say L213 pla
    old "W- What are you doing [sis]?!"
    new "W- 何やってるの [sis]？！"

    # say L214 sis
    old "I just wanted to see how much you like my outfit..."
    new "ただ、私の服があなたにどれだけ気に入ったのか見てみたくなったの..."

    # say L220 sis
    old "And oh my god! Look at that!"
    new "お ancor 神様！見てみて！"

    # say L221 sis
    old "You clearly really like it!"
    new "あなた、本当に気に入ってくれたみたいね！"

    # say L222 pla
    old "Uh... I- I mean."
    new "うーん… あの、つまり。"

    # say L223 sis
    old "It's ok [pla] I know you love it."
    new "大丈夫よ [pla] あなたが好きだってわかってるの。"

    # say L224 sis
    old "Just look at that big cock!"
    new "そんな大きなちんぽ、見てごらん。"

    # say L225 sis
    old "What I could with it..."
    new "これでできることは…"

    # say L239 sis
    old "I'm sure the clients will love this new line!"
    new "お客様たちはきっとこの新商品を気に入ってくれるわね。"

    # say L240 pla
    old "Umm, yeah, I guess they will."
    new "うーん、多分そうだろうな。"

    # say L241 pla
    old "Hey, listen [sis]... Do you feel well?"
    new "Hey、聞いて [sis]... 元気なのか？"

    # say L242 sis
    old "Me? I feel great!"
    new "私？全然元気だよ！"

    # say L246 sis
    old "Why do you ask?"
    new "何でそんなこと聞くの？"

    # say L247 pla
    old "No reason, it's just a strange feeling..."
    new "特に理由はないんだ、ただ変な感じがするさ..."

    # say L248 pla
    old "You know what? Forget it, it must be my imagination."
    new "知ってる？忘れるよ、きっと俺の気のせいだ。"

    # say L250 sis
    old "Well, I have to work on some things for the website, you can leave now."
    new "WELL、ウェブサイトのことを進めるから、今すぐ帰っていいわ。"

    # say L252 pla
    old "Uhh, right..."
    new "うーん、そうか…"

    # say L262 pla
    old "Uhh... That was weird..."
    new "うーん… ちょっと変な感じがしたな…"

    # say L263 pla
    old "I still has that strange feeling... What was that?"
    new "まだあの変な感じがするな… 一体何だったんだ？"

    # say L264 pla
    old "Anyway, I better go downstairs and see what happened with Lydia..."
    new "まあ、とりあえず下に降りてリディアの様子を見に行ってくるよ。"

    # say L286 mo1
    old "Ah! [pla] honey!"
    new "あら！[pla] ハニー！"

    # say L287 mo1
    old "You've arrived, wonderful!"
    new "あなたが来たの、素晴らしいわ！"

    # say L288 mo1
    old "We're opening our Christmas gifts, you're just in time."
    new "クリスマスのプレゼントを開けてるところよ、ちょうど良かったわ。"

    # say L290 mo2
    old "It's your turn now [mo1], and this one's from me, why don't you open it?"
    new "あなたの番ね [mo1]、これは私が用意したプレゼントだから、開けてみない？"

    # say L298 mo1
    old "Oh! Honey! Thank you!"
    new "あら！ハニー！ありがとう！"

    # say L299 mo1
    old "I can't wait to see what it is!"
    new "早く開けてみたいな！何が入ってるのか楽しみだわ。"

    # say L306 mo1
    old "Oh my god [mo2]! This is just what I wanted!"
    new "Oh my god [mo2]！これ私が欲しかったものよ！"

    # say L308 pla
    old "(Is that a bottle of lube?)"
    new "（それがローションのボトルなのか？）"

    # say L313 mo1
    old "Of course I do! This is my favorite brand!"
    new "もちろんよ！これは私の大好きなブランドだから。"

    # say L314 mo2
    old "You know, this lube is very good because it enhance all sensations."
    new "このローションはとても良いのよ、すべての感覚を高めてくれるから。"

    # say L315 pla
    old "(Holy shit, yes it is...)"
    new "（Holy shit、本当にか...）"

    # say L319 mo2
    old "So, when we use it you can feel even harder when you're getting railed."
    new "そう、これを使うとあなたが突かれているときに、もっと強く感じるわ。"

    # say L320 pla
    old "(What the... Why are they talking like that in front of Lydia...)"
    new "（何だよ… なんでリディアの前でそんな話をしてるんだよ…）"

    # say L324 mo1
    old "Oh honey! That sounds fantastic! We have to use it as soon as we can!"
    new "あらほんらい！それは素晴らしいわ！早速使ってみなくちゃね！"

    # say L325 mo2
    old "Off course! I really enjoy this one, is really warm..."
    new "もちろん！この方法は本当に温かくて、私はとても気に入っています…"

    # say L326 mo2
    old "We have to put it to the test to see if you like it."
    new "テストしてみないと、君が気に入るかどうかわからないわ。"

    # say L331 lyd
    old "Oh please, stop..."
    new "お願い、止めて…"

    # say L337 lyd
    old "Come on [mo2], is this a gift for [mo1], or is it a gift for you?"
    new "お願い、[mo2]、これは[mo1]への贈り物なのか、それともあなたのための贈り物なのかしら？"

    # say L339 pla
    old "(What the...)"
    new "何これ…"

    # say L344 mo1
    old "There's no reason why it couldn't be for the both of us!"
    new "私たち二人のためにだっていいんじゃない！"

    # say L345 mo1
    old "As long as we both enjoy it, who cares who it is for!"
    new "私たちが楽しめれば、誰のためにだっていいじゃない！"

    # say L350 mo2
    old "That's right Lydia, relax."
    new "そうだわリディア、リラックスしなさい。"

    # say L356 mo2
    old "After all, I can fuck [mo1] with it, but she can also rail me later."
    new "結局これで[mo1]とセックスできるし、後で彼女にも乗ってもらえるわ。"

    # say L357 lyd
    old "I guess you're right [mo1], [mo2]."
    new "そうだよ、[mo1]、[mo2]。"

    # say L358 lyd
    old "All gifts should be enjoyed equally."
    new "全ての贈り物は同じように楽しむべきだと思います。"

    # say L359 lyd
    old "I think everybody should get to have a good time with these gifts."
    new "みんながこれらのプレゼントを楽しむべきだと思います。"

    # say L360 mo1
    old "Oh, I agree with that."
    new "そうですよね、私もそう思います。"

    # say L362 pla
    old "Uhh... W- what is happening?"
    new "うっ…… 何が起こってるんだ？"

    # say L367 mo1
    old "Thinking about it... [pla], you haven't opened your presents yet."
    new "考えてみれば… [pla]、まだプレゼントを開けてないのね。"

    # say L368 pla
    old "M- me?"
    new "僕？"

    # say L369 pla
    old "{i}(I don't think I like where this is going.){/i}"
    new "{i}(これって、何か変な方向に進んでる気がする。){/i}"

    # say L370 pla
    old "I think I'm ok for now."
    new "俺は今のところ大丈夫だな。"

    # say L371 pla
    old "I'll open my gifts later."
    new "後でプレゼントを開くね。"

    # say L372 lyd
    old "Don't be foolish sweetie! You have to open them right now!"
    new "甘えてるんじゃないわ Darling！今すぐ開けなきゃ駄目よ！"

    # say L373 mo2
    old "Otherwise it is no fun."
    new "それじゃあ楽しくないわ。"

    # say L374 mo1
    old "That's right [pla], come honey, open your presents."
    new "そうですわ [pla]、来なさい、プレゼントを開けてください。"

    # say L382 pla
    old "I- I'm not sure I should."
    new "ちょっと迷ってるんだよ。"

    # say L387 mo2
    old "Don't be a brag and do it!"
    new "自慢しないで、やってみて。"

    # say L401 pla
    old "W- WHAT THA FUCK? THIS WEIRD THING AGAIN???"
    new "Ｗ－ＷＨＡＴ　ＴＨＡ　ＦＵＣＫ？　またこの変なことか？"

    # say L402 mo1
    old "Oh, don't worry honey, this is just one of your Christmas gifts."
    new "あら、心配しないで亲爱的，这只是你圣诞礼物中的一个而已哦。"

    # say L403 mo1
    old "After all you have been such a good boy this year."
    new "今年は本当に良い子だったわ。"

    # say L404 mo2
    old "And we have been such naughty girls."
    new "そして私たちはとてもいたずらな女の子たちだったわ。"

    # say L405 lyd
    old "So, just relax and let us take care of you for a chance."
    new "だから、リラックスして私たちに甘えてみてください。"

    # say L406 pla
    old "{i}(What the hell is happening with them?){/i}"
    new "{i}(一体何が起こってるんだ？){/i}"

    # say L407 pla
    old "{i}(Lydia had already been acting weird since this morning.){/i}"
    new "{i}(リディアは朝から妙な行動を取っていた。){/i}"

    # say L409 pla
    old "{i}(Not to mention the way [sis] was acting when I went into her room...){/i}"
    new "{i}(それに、[sis]の部屋に入ったら、その態度も...){/i}"

    # say L412 pla
    old "{i}(I guess I can just enjoy it, right?){/i}"
    new "{i}(なら、楽しめばいいんだろ？){/i}"

    # say L430 pla
    old "Woww... That thing again... I'm starting to feel dizzy..."
    new "ワオッ… またその感覚か… もうめまいがしてきた…"

    # say L431 sis
    old "God [pla], you're so hard!"
    new "神 [pla]、 あなたはもう全然硬いのね！"

    # say L432 pla
    old "(What the fuck?? Now is [sis] here too?)"
    new "何だよ、今度は [sis] まで来てるのか？"

    # say L433 pla
    old "{i}(I guess I was right, this must be a dream.){/i}"
    new "{i}(俺の予想通り、これは夢なんだな。){/i}"

    # say L434 sis
    old "And your cock is so big!"
    new "あなたのちんぽ、こんなに大きいの！"

    # say L435 lyd
    old "And your tongue is so good baby!"
    new "あなたの舌が本当に上手ですね、ベイビー！"

    # say L436 mo1
    old "Oh! [mo2] honey, I love how you eat me out!"
    new "Oh！ [mo2] ハニー、あなたが私を舐めてくれるのが大好きです！"

    # say L437 pla
    old "{i}(Well, I think I just should just keep enjoying it.){/i}"
    new "{i}(まあ、このまま楽しんでいこうかな。){/i}"

    # say L438 pla
    old "{i}(When am I going to have another dream like this?){/i}"
    new "{i}(こんな夢、またいつ見られるかな？){/i}"

    # say L449 pla
    old "L- Linett, whoah! You're in my dream too?"
    new "$L- リネット、おわっ！君も俺の夢に出てきたのか？$"

    # say L450 pla
    old "Did you come to join in on the fun?"
    new "お前も楽しむためには参戦したのか？"

    # say L451 pla
    old "I mean, I haven't done it with shinigamis and humans simultaneously."
    new "つまり、俺はまだ死神と人間と同時にやったことがないんだ。"

    # say L452 pla
    old "But it could be interesting! Hop in!"
    new "でも面白そうじゃない？　入ってみろよ。"

    # say L453 lin
    old "What? What are you talking about?"
    new "何言ってんの？"

    # say L454 pla
    old "Oh come on, you don't have to act like you don't want it."
    new "おい、そんな顔しないでよ、君が欲しがってるのが見え見えだよ。"

    # say L455 pla
    old "This is a dream after all."
    new "これは夢なんだよ。"

    # say L456 lin
    old "This isn't a dream you dumbass!"
    new "これは夢なんかじゃないわよ、バカ！"

    # say L457 pla
    old "W- What? What do you mean?"
    new "W- 何？ どういう意味だよ？"

    # say L458 lin
    old "As you heard, this isn't a dream!"
    new "聞こえた通り、これは夢じゃないのよ！"

    # say L459 lin
    old "This is all real [pla]!"
    new "これ全部リアルよ [pla]！"

    # say L460 lin
    old "Apparently the magic concentrating spell we did in the church."
    new "教会で行った魔力集中の呪文が、予想外の影響を与えたみたい。"

    # say L464 lin
    old "Seems to have affected reality in a way we couldn't predict."
    new "予想外の影響を現実に与えているみたい。"

    # say L465 lin
    old "The ritual was successful but it's now starting to gather magic from all around."
    new "儀式は成功したけど、今さら周囲から魔力を集め始めてるの。"

    # say L466 lin
    old "And given that most magic in this world is stored in human bodies, it's trying to force it out!"
    new "そしてこの世界のほとんどの魔力が人間の体内に蓄えられているので、それを無理やり引き出そうとしているんだ！"

    # say L470 lin
    old "When that happens to human bodies they start to feel their life energy deplete."
    new "人間の体でそれが起こると、生命力が奪われていく感じがするの。"

    # say L474 lin
    old "So, all the weird human behavior is caused because of the magic power..."
    new "だから、変な行動は全部魔法の力のせいなんだよ…"

    # say L475 lin
    old "They're not really themselves, they're in a sort of magically unconscious state..."
    new "彼らは本当の自分じゃなくて、魔法によって意識が朦朧とした状態になっているの…"

    # say L476 lin
    old "And if it isn't stopped now it will wreak havoc in this world."
    new "そして、これを今すぐに止めなければ、この世界に大混乱をもたらすだろう。"

    # say L477 lin
    old "Although it already started. So, we have very little time."
    new "でも、すでに始まってるからね。だから、時間はほとんどないわ。"

    # say L481 lin
    old "Truth be told, when we did the last ritual I noticed something was odd."
    new "正直に言うと、前回の儀式をしたとき何か変だなって思ったの。"

    # say L482 lin
    old "I probably should've done something about it then."
    new "あの時何か対処すべきだったのかもしれない。"

    # say L483 lin
    old "But I didn't expect anything like this to happen."
    new "でも、こんなことになるとは思わなかった。"

    # say L484 pla
    old "I- I- I'm not getting it at all..."
    new "全然わかんないよ..."

    # say L488 lin
    old "What I'm telling you is that reality is starting to fragment!"
    new "私が言っているのは、現実が崩れ始めているということよ。"

    # say L489 lin
    old "So, we have to hurry and do something about it!"
    new "だから、急いで何かしなきゃ！"

    # say L493 lin
    old "The ritual we did was successful."
    new "私たちが行った儀式は成功した。"

    # say L494 lin
    old "The problem  is that there's not enough magic density in this world to just create a portal."
    new "この世界の魔力密度が足りないのが問題なの。"

    # say L499 pla
    old "What can we do about it?"
    new "じゃあ、どうすればいいんだ？"

    # say L503 lin
    old "I have a couple ideas."
    new "いくつかアイデアがあるの。"

    # say L504 lin
    old "Honestly I don't know if what I'm thinking off will work."
    new "正直、今考えていることがうまくいくかどうかわからないけど。"

    # say L505 lin
    old "So, we'll have to try a couple of things to see what sticks."
    new "じゃあ、いくつか試してみて、何が効くか見てみよう。"

    # say L506 lin
    old "But whatever it is we do."
    new "でも、何をするにしても。"

    # say L510 lin
    old "I'm sure we'll need the other three shinigami for it, so, let's go."
    new "他の三つの死神もいるだろうから、行こう。"

    # say L528 lin
    old "W- What? Who are you?!"
    new "えっ、誰だ？"

    # say L529 bri
    old "What the fuck is going on here?!"
    new "一体何が起こってるのよ！"

    # say L530 lin
    old "Uh- Listen, I don't know who you are."
    new "えっと、君が誰なのか全然知らないんだけど。"

    # say L535 lin
    old "I didn't even know there was another shinigami around."
    new "他の死神がいることさえ知らなかったんだよ。"

    # say L536 lin
    old "But nice to meet you... I guess. I'm Linnet."
    new "でも会えて嬉しいわ…多分。私はリンネット。"

    # say L540 lin
    old "Listen, right now there's no time for us to talk."
    new "今は話してる時間ないわよ。"

    # say L541 lin
    old "In case you haven't noticed, reality is tearing itself apart!"
    new "現実が壊れ Going apart てるって気づいてないの？！"

    # say L542 lin
    old "Are you going to help us or not?!"
    new "助けてくれるのか？！"

    # say L543 bri
    old "Oh, I know full well who you are!"
    new "あたしはあなたが誰なのか、よく知ってるわよ！"

    # say L547 bri
    old "You're that idiot that keeps messing with the magic of this world!"
    new "あなたがこの世界の魔法をいじくってるアホじゃないの！"

    # say L553 bri
    old "Look at the mess you've made!"
    new "見てごらん、この有様！"

    # say L558 bri
    old "Not to mention that you keep setting [pla] down the wrong path!"
    new "それに、[pla]を間違った道に導き続けているわ！"

    # say L559 bri
    old "Don't you see you're screwing our only chance of fixing the magical world?"
    new "あなたが魔法の世界を直す唯一のチャンスを台無しにしてるって分かってないの？"

    # say L563 bri
    old "I'M NOT GOING TO LET YOU CONTINUE RUINING EVERYTHING!"
    new "私は絶対にあなたがすべてを台無しにするのを許さない！"

    # say L583 pla
    old "B- Brixxida! W- What are you doing? She's an ally!"
    new "ブリクシダ！　何やってんだよ？　彼女は味方だぞ！"

    # say L587 bri
    old "Oh! You shut up! Enough with the stupidities!"
    new "お前黙ってろ！もうバカなこと言わないで！"

    # say L588 bri
    old "You've already ruined too many things."
    new "あなたがもうたくさんのことを台無しにしてしまったんだから。"

    # say L589 bri
    old "And I won't keep risking my life, this world, and the magic world."
    new "そして私の命も、この世界も、魔法の世界も危険にさらすつもりはないわ。"

    # say L590 bri
    old "Because of the actions of a group of stupid inexperienced shinigamis."
    new "バカな未熟な死神たちの行動のために。"

    # say L599 bri
    old "There, you take care of that."
    new "そこに、あなたが見てあげて。"

    # say L600 bri
    old "Put her some place where she won't be a bother."
    new "彼女を邪魔にならないところに置いて。"

    # say L601 bri
    old "And come with me [pla], I'll fix this quickly."
    new "じゃあ、私と来なさい [pla]、すぐに片付けちゃうから。"

    # say L634 pla
    old "So, what are we doing here?"
    new "じゃあ、ここであんたと何するんだ？"

    # say L635 pla
    old "I don't see anything wrong..."
    new "何も問題ないみたいだな..."

    # say L636 bri
    old "Oh really? Use your Eye of Agamotto..."
    new "ほんと？アガモットの目を使ってみてよ…"

    # say L637 pla
    old "Uhh... Alright..."
    new "うーん… 分かった…"

    # say L647 pla
    old "Woah! What's this? What's happening?"
    new "Woah！これは何？何が起こってる？"

    # say L648 bri
    old "This is what you and that idiot did!"
    new "これがあなたとあのバカがやったことよ！"

    # say L652 bri
    old "What you're seeing is the result of a difficult spell being casted by an inexpert hand."
    new "あなたが見ているのは、素人による難易度の高い呪文の結果だよ。"

    # say L656 bri
    old "This is why you should've come to me with these things [pla]!"
    new "これが、あなたが私に相談すべきだった理由よ [pla]！"

    # say L657 bri
    old "But it's ok, I'm here now."
    new "でも大丈夫、私がここにいるから。"

    # say L658 pla
    old "Ok, but what's your plan to fix all this?"
    new "分かったけど、君の計画は？"

    # say L659 bri
    old "Just watch."
    new "ただ見てて。"

    # say L665 bri
    old "Now! Quick! We have to go to your house to stabilize it!"
    new "今！急いで！あなたの家に行かないと安定させられないの！"

    # say L667 pla
    old "Woah, Woah! What do you mean?!"
    new "Woah, Woah！ どういう意味だよ？！"

    # say L668 pla
    old "Are you planning on putting that in my house?"
    new "お前の家にそれを入れようってのか？"

    # say L669 bri
    old "Don't worry nothing will happen."
    new "心配しないで、何も起こらないから。"

    # say L670 bri
    old "Unlike your little friend, I know how to do things properly."
    new "あなたの小さな友達とは違って、私はちゃんとできるわ。"

    # say L672 bri
    old "So, let's hurry and go to your house!"
    new "じゃあ、早く家に行こう！"

    # say L674 pla
    old "R- Right!"
    new "R- やった！"

    # say L680 pla
    old "So, what now?"
    new "じゃあ、次は什麼する？"

    # say L681 bri
    old "I'm going to invoke the portal here."
    new "ここにポータルを召喚するわ。"

    # say L682 pla
    old "Oh wow..."
    new "おわっ…"

    # say L702 bri
    old "{b}*Sigh*{/b} That was dangerous."
    new "{b}……{/b} それって危険だったわね。"

    # say L703 bri
    old "But at least we now have a portal."
    new "でも、少なくともポータルは手に入れたわ。"

    # say L707 pla
    old "Uhh... So, does that mean that we can go to the magical world now?"
    new "うーん……つまり、今すぐ魔法の世界に行けるってことなのか？"

    # say L709 bri
    old "Of course not. Going from one world to another is not that easy!"
    new "もちろんそんなに簡単じゃないわ。"

    # say L710 bri
    old "To work, this portal needs a massive amount of magic to finish its development."
    new "このポータルを完成させるには、莫大な魔力が必要なんだ。"

    # say L711 bri
    old "What it was doing before was sucking all of the magic power around, without any control or direction."
    new "そのままでいたのは、周囲の魔法力を制御なしで吸い取るだけだったの。"

    # say L715 bri
    old "That could've ended the world."
    new "それって世界を終わらせちゃうところだったの。"

    # say L719 bri
    old "I just stabilized it so that it wouldn't continue extracting magic from all around and destroy the world."
    new "私が安定させただけで、それ以上周囲の魔法力を吸い取って世界を破壊しないようにしたの。"

    # say L724 bri
    old "What we must do now is feed it magic power in a more controlled way."
    new "これからは魔法力をより制御された方法で供給しなければならないわ。"

    # say L728 pla
    old "Uh... ok."
    new "うーん… 分かった。"

    # say L732 pla
    old "So, how do we feed it magic power now?"
    new "じゃあ、どうやって魔力を供給するんだ？"

    # say L736 bri
    old "Well, normally it would be just a simple issue of using the eye of Agamoto to stock up in magic power."
    new "通常なら、アガモトの目を使って魔力をためるだけのことよ。"

    # say L737 bri
    old "And then just release it in the portal."
    new "そしてその魔力をポータルに解放するだけ。"

    # say L741 bri
    old "But now, due to you and your little friend messing up."
    new "でもね、あなたたちとあなたの小さな友達が邪魔をしたせいで。"

    # say L742 bri
    old "It extracted a lot of free-flowing energy from the world."
    new "世界からたくさんの流れやすいエネルギーが取り出されてしまった。"

    # say L744 bri
    old "We can get it back, but it's going to take a longer time. And it will be a lot more dangerous."
    new "取り戻せるけど、時間がかかるわ。それに危険も増えるわ。"

    # say L748 bri
    old "All thanks to you and that stupid little shinigami with which you have been playing."
    new "全部あなたのせいよ、あのバカな死神と遊んでばかりいたから。"

    # say L749 pla
    old "I'm sorry Brixxida, all I wanted was to help, you know?"
    new "すみません、ブリクシダ。ただ君を助けるつもりだったんだよ、分かるよね？"

    # say L753 bri
    old "Hmph."
    new "ふん。"

    # say L754 pla
    old "So, what can we do to make the portal work?"
    new "じゃあ、ポータルを動かすためには何ができる？"

    # say L755 bri
    old "Well, the only way is to seed the magic power..."
    new "魔法力を種まくしかないのよ。"

    # say L757 pla
    old "Seed the magic power? What's that?"
    new "魔力の種をまくって？　それって何？"

    # say L758 bri
    old "It's a magic ritual we use to concentrate magic power."
    new "それは魔法力を集中させるための儀式なの。"

    # say L759 bri
    old "By incubating it inside the bodies of humans."
    new "人間の体内で育てることで、力が集中していくの。"

    # say L760 bri
    old "The power grows and concentrates over time. Until it finally flows out and into the portal."
    new "力は時間とともに成長し、凝縮されていくの。最終的に流れ出て、ポータルへと入るの。"

    # say L762 pla
    old "Ok, I think I get it. So, how do we do it?"
    new "分かった、じゃあ具体的にはどうするんだ？"

    # say L763 bri
    old "There's only one real way to do it. You have to plan the seed inside the body."
    new "本当の方法は一つだけよ。体内に種を植え付けるしかないの。"

    # say L764 bri
    old "Once inside it gestates and grows, until it's time to come out."
    new "体内で育っていくの。時間になったら出て来るわ。"

    # say L766 pla
    old "Ok, but how do I do it?"
    new "分かったけど、どうやってやるんだ？"

    # say L768 bri
    old "Well, you have to seed them the same way you gather and give magic power out."
    new "ええ、魔力を集めて与えるのと同じように種をまかなくちゃならないの。"

    # say L769 pla
    old "Woah! Woah! Woah! You mean I have to impregnate them?!"
    new "Woah！ Woah！ Woah！ お前は俺が妊娠させなきゃならないって意味なのか？！"

    # say L771 bri
    old "In human terms, that's what it's called, yeah."
    new "人間の言葉で言うと、そう呼ばれるのよ。"

    # say L773 pla
    old "What the fuck? Are you for real?"
    new "何だよ、本気で言ってんのか？"

    # say L774 pla
    old "I'm way too young to have children!"
    new "俺はまだ子供を持つには若いよ！"

    # say L782 bri
    old "But don't worry, it's not the way you think."
    new "でも心配しなくていい、あなたが思ってるようなわけじゃない。"

    # say L784 bri
    old "During the growing period, the magic power will concentrate without a particular form."
    new "成長期には、魔力は特定の形を持たずに集中する。"

    # say L787 bri
    old "And it will only change if, you decide it to be anything in particular."
    new "そして、それが何か特定の形を持つようになるのは、あなたがそれを何か特定のものに決めたときだけよ。"

    # say L789 bri
    old "It means that if you just take out all of the magic power from these women it will just be energy."
    new "それって、これらの女性から魔力を全部取り出したら、ただエネルギーになるってことね。"

    # say L790 bri
    old "Pure magic energy, without any form in particular."
    new "純粋な魔力エネルギー、特定の形がないままね。"

    # say L791 bri
    old "And it will only take the shape of a human infant if you decide that you will leave energy remains behind."
    new "そして、あなたがエネルギーの残骸を残すと決めた場合だけ、人間の赤ん坊の形を取ります。"

    # say L793 bri
    old "Otherwise there won't be any reproduction between you and the humans we use for this ritual."
    new "それ以外は、あなたと私たちがこの儀式で使う人間との間に生殖は起こらないわ。"

    # say L795 pla
    old "I- I see, I guess that's..."
    new "分かった、なるほど..."

    # say L796 pla
    old "Fine, I guess?"
    new "分かった、そうなのか。"

    # say L798 bri
    old "However, until the magic power is ready to be taken out of their bodies and we do it."
    new "しかし、魔力が体から取り出せる状態になるまで、そしてそれを実行するまで。"

    # say L799 bri
    old "They will look like they are pregnant."
    new "彼らは妊娠しているように見えるわ。"

    # say L801 bri
    old "The entire process it's going to be very similar to the way you humans gestate your infants."
    new "その過程は、あなた方人間が子供を妊娠するのととても似ているわ。"

    # say L802 bri
    old "Is just that at the end of it, there won't necessary be another human."
    new "ただ、最終的に必ずしも別の人類が生まれるわけではないの。"

    # say L803 bri
    old "So, their bodies will just go back to how they were before the ritual started."
    new "そう、儀式が始まる前の状態に戻るだけなの。"

    # say L805 pla
    old "I get it now."
    new "分かったよ。"

    # say L806 bri
    old "Listen, I know you don't like it."
    new "聞いて、あなたが好きじゃないのはわかってるけど。"

    # say L807 bri
    old "But for now, that's the only way we have to power up the portal and return the magic world to what it was before."
    new "でも今は、その方法でしかポータルを強化して魔法の世界を元に戻せないんだ。"

    # say L808 bri
    old "Not to mention avoiding the destruction of yours."
    new "それに、あなたの世界が破壊されることを避けるためにも必要なんだよ。"

    # say L809 pla
    old "I get it."
    new "分かったよ。"

    # say L810 pla
    old "If I have to do it, I guess there's no choice."
    new "やるなら仕方ないな。"

    # say L811 bri
    old "By the way; from now on, I will be in charge of everything, you get that?"
    new "それからね、これからは全部私が責任を持つから、分かった？"

    # say L815 bri
    old "No more running around like an idiot with you dumbass shinigami friends messing everything up!!"
    new "もうバカな死神の友達と何もかもめちゃくちゃにするの止めるのよ！！"

    # say L816 pla
    old "Uh. I- sure..."
    new "うーん、分かったよ…"

    # say L817 bri
    old "Good, I'm glad you understand that."
    new "よし、理解してくれて良かった。"

    # say L819 bri
    old "Now, get ready, because there are a lot of things you will need to learn about all of this."
    new "それじゃ、準備して。これについて学ぶことは山ほどあるから。"

    # say L820 pla
    old "Oh, man... Alright..."
    new "お、俺… 分かったよ…"

    # say L828 pla
    old "I guess I'll leave you here for now..."
    new "じゃあ、ここであんたを置いていくとするな。"

    # say L829 pla
    old "I'm so sorry, about this Linnet."
    new "俺、本当に申し訳ない、リンネット。"

    # say L830 pla
    old "I promise that I will help you to get free from this."
    new "約束する、君をこの状況から解放する手伝いをするよ。"

